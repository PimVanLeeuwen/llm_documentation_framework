**normalization_tanh**: The function of `normalization_tanh` is to normalize a value using the hyperbolic tangent (tanh) function.

**Parameters**:
- `float stack`: This parameter represents the base or denominator value used in the normalization calculation.
- `float ev`: This parameter represents the event or numerator value used in the normalization calculation.
- `float ratio`: This parameter represents the scaling factor applied to the event value before normalization.

**Code Description**: The `normalization_tanh` function takes three parameters: `stack`, `ev`, and `ratio`. It calculates a new value `x` by dividing `ev` by `stack` and then multiplying it by `ratio`. This new value is then passed through the tanh function, which returns the hyperbolic tangent of `x`. The result is further normalized by adding 0.5 (half) to half of the tanh result. The final output is a float representing the normalized value. \\
 ## Code: 
 ```
float normalization_tanh(float stack,float ev,float ratio){
    float x = ev / stack * ratio;
    return tanh(x) / 2 + 0.5;
}
```