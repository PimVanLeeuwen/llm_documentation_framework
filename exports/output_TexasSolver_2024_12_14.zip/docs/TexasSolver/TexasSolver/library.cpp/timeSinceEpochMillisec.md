`timeSinceEpochMillisec`: The function returns the number of milliseconds since the epoch (January 1, 1970).

**Code Description**: This method uses the C++11 chrono library to get the current system time and calculate the difference in milliseconds from the Unix epoch. It utilizes the `system_clock::now()` function to retrieve the current time point, then applies the `time_since_epoch()` function to obtain a duration representing this instant as a whole number of seconds since the epoch. The result is cast to `milliseconds` using `duration_cast`, and finally, the count() method is called on the resulting duration to extract its value as an integer. This integer represents the total milliseconds elapsed since the Unix epoch. \\
 ## Code: 
 ```
uint64_t timeSinceEpochMillisec() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
}
```