`random`: The function of `random` is to generate a random integer within a specified range.

**Parameters**:
`int min`: The minimum value (inclusive) in the range from which to select the random number.
`int max`: The maximum value (exclusive) in the range from which to select the random number.

**Code Description**: 
The `random` function takes two parameters, `min` and `max`, representing the lower and upper bounds of a range. It uses the `rand()` function to generate a random integer within this range. The generated random number is then returned by adding the result of `rand() % (( max ) - min)` to `min`. This ensures that the generated random number falls within the specified range `[min, max)`, meaning it can be any value from `min` up to but not including `max`. \\
 ## Code: 
 ```
int random(int min, int max) //range : [min, max)
{
    return min + rand() % (( max ) - min);
}
```