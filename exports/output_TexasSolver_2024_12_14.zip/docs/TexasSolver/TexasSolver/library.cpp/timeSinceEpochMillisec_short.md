This method returns the number of milliseconds since the Unix epoch, which is January 1, 1970.

It uses the `system_clock` class to get the current time and converts it to milliseconds using `duration_cast`.