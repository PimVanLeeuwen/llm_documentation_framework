**Expected Output**

`string_split`: The function of `string_split` is to split a given string into substrings based on a specified delimiter character.

**Parameters**:

`string strin`: This parameter represents the input string that needs to be split.
`char split`: This parameter specifies the delimiter character used to separate substrings in the input string.

**Code Description**: The `string_split` method iterates through the input string, using the delimiter to separate substrings and adds them to a vector. It utilizes a stringstream to efficiently process the string and extract tokens based on the specified delimiter. The resulting substrings are stored in a vector, which is then returned as output. \\
 ## Code: 
 ```
vector<string> string_split(string strin,char split){
    vector<string> retval;
    stringstream ss(strin);
    string token;
    while (getline(ss,token, split))
    {
        retval.push_back(token);
    }
    return retval;
}
```