`indPlayer2Player`: The function of `indPlayer2Player` is to find the index of a private card in the preflop cards of one player that corresponds to a specific card in another player's hand.

**Parameters**:
- `int from_player`: The ID of the player whose preflop cards are being searched.
- `int to_player`: The ID of the player whose hand is being matched against the preflop cards.
- `int index`: The index of the private card in the preflop cards of the `from_player` that should be found.

**Code Description**: 
The method first checks if the provided index is within the valid range for the preflop cards of the specified player. If not, it throws a runtime error. It then retrieves the hash code of the private card at the given index in the preflop cards of the `from_player`. This hash code is used to find the corresponding index in the hand of the `to_player` by looking up the `card_player_index` array. If no match is found, it returns -1; otherwise, it returns the index of the matching card in the `to_player`'s hand. \\
 ## Code: 
 ```
int PrivateCardsManager::indPlayer2Player(int from_player, int to_player, int index) {
    if(index < 0 || index >= this->getPreflopCards(from_player).size()) throw runtime_error("index out of range");
    //PrivateCards player_combo = this->getPreflopCards(from_player)[index];
    int to_player_index = this->card_player_index[this->private_cards[from_player][index].hashCode()][to_player];
    if(to_player_index == -1){
        return -1;
    }else {
        return to_player_index;
    }
}
```