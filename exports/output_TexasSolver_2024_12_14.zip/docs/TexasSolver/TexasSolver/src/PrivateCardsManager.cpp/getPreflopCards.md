`getPreflopCards`: The function of `getPreflopCards` is to retrieve the private cards for a specific player in the preflop stage.

**Parameters**:
`int player`: The ID or index of the player for whom to retrieve the private cards.

**Code Description**: 
The `getPreflopCards` method returns a reference to a vector of `PrivateCards` objects, which represents the private cards held by the specified player in the preflop stage. It does this by directly accessing the `private_cards` member variable, which is an array of vectors, where each index corresponds to a specific player. The method takes an integer parameter `player`, which is used as an index to access the corresponding vector of private cards for that player. \\
 ## Code: 
 ```
vector<PrivateCards>& PrivateCardsManager::getPreflopCards(int player) {
    return this->private_cards[player];
}
```