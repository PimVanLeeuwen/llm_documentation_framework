`getInitialReachProb`: The function of `getInitialReachProb` is to calculate the initial reach probability for a given player based on their private cards and the initial board state.

**Parameters**:
`int player`: The index of the player for whom to calculate the reach probability.
`uint64_t initialboard`: The current state of the poker board as a 64-bit unsigned integer.

**Code Description**: 
The `getInitialReachProb` function takes in an `int player` and a `uint64_t initialboard` as parameters. It first retrieves the private cards for the specified player from the `private_cards` data structure. The function then iterates over each card in the player's hand, checking if the board has any intercepts with the card's hands using the `Card::boardsHasIntercept` method. If an intercept is found, the corresponding reach probability is set to 0; otherwise, it is set to the weight of the private card. The function returns a vector of reach probabilities for each card in the player's hand.

The code calls two other methods within the repository: `get_hands` and `boardInts2long`. The `get_hands` method returns a reference to a vector of integers representing private cards, while the `boardInts2long` method converts a vector of integers representing a poker board into a single 64-bit unsigned integer. These methods are used in conjunction with the `Card::boardsHasIntercept` method to determine the reach probability for each card in the player's hand. \\
 ## Code: 
 ```
vector<float> PrivateCardsManager::getInitialReachProb(int player, uint64_t initialboard) {
    int cards_len =  this->private_cards[player].size();
    vector<float> probs = vector<float>(cards_len);
    for(int i = 0;i < cards_len;i ++){
        PrivateCards pc = this->private_cards[player][i];
        if(Card::boardsHasIntercept(initialboard,Card::boardInts2long(pc.get_hands()))) {
            probs[i] = 0;
        }else{
            probs[i] = this->private_cards[player][i].weight;
        }
    }
    return probs;
}
```