`PrivateCardsManager`: The function of `PrivateCardsManager` is to manage and calculate relative probabilities for private cards in a poker game.

**Parameters**:
`vector<vector<PrivateCards>> private_cards`: A 2D vector containing the private card combinations for each player.
`int player_number`: The number of players participating in the game.
`uint64_t initialboard`: The initial state of the board, which is used to calculate relative probabilities.

**Code Description**: This class initializes a `PrivateCardsManager` object by setting up data structures to store and manage private card combinations for each player. It uses a 2D vector `card_player_index` to keep track of the index of each private combo in the `private_cards` vector, making it easier to find corresponding cards from other players' hands. The `setRelativeProbs()` method is called to calculate relative probabilities for private cards based on the weights and combinations of other players' cards. \\
 ## Code: 
 ```
PrivateCardsManager::PrivateCardsManager(vector<vector<PrivateCards>> private_cards, int player_number,
                                         uint64_t initialboard) {
    this->private_cards = private_cards;
    this->player_number = player_number;
    this->card_player_index = vector<vector<int>>(52 * 52);
    for(int i = 0;i < 52 * 52;i ++){
        this->card_player_index[i] = vector<int>(this->player_number,-1);
    }

    // 用一个二维数组记录每个Private Combo的对应index,方便从一方的手牌找对方的同名卡牌的index
    for(int player_id = 0;player_id < player_number;player_id ++){
        vector<PrivateCards> privateCombos = private_cards[player_id];
        for(std::size_t i = 0;i < privateCombos.size();i ++){
            PrivateCards one_private_combo = privateCombos[i];
            this->card_player_index[one_private_combo.hashCode()][player_id] = i;
        }
    }

    this->initialboard = initialboard;
    this->setRelativeProbs();
}
```