`setRelativeProbs`: The function of `setRelativeProbs` is to calculate and assign relative probabilities to each private card in the game, considering the cards held by other players.

**Code Description**: 
The `setRelativeProbs` method calculates the relative probability for each private card in the game. It iterates through each player's private cards, and for each card, it calculates the sum of weights of all cards held by the opposing player (i.e., the player with the index 1 - current_player_id). The weight of a card is multiplied by the sum of weights of all cards held by the opposing player to get the relative probability. This process is repeated for all private cards in the game, and finally, each card's relative probability is normalized by dividing it by the total sum of relative probabilities for all cards held by the current player.

The method uses several helper methods from other classes:

* `get_hands` returns a reference to a vector of integers representing private cards.
* `boardInts2long` converts a vector of integers representing a poker board into a single 64-bit unsigned integer.
* `boardsHasIntercept` checks if two boards have an intercept, i.e., if they share any common cards.

The method iterates through each player's private cards and for each card, it calculates the sum of weights of all cards held by the opposing player. The weight of a card is multiplied by the sum of weights of all cards held by the opposing player to get the relative probability. This process is repeated for all private cards in the game, and finally, each card's relative probability is normalized by dividing it by the total sum of relative probabilities for all cards held by the current player.

The method also uses a TODO comment indicating that it currently only considers two-player situations. \\
 ## Code: 
 ```
void PrivateCardsManager::setRelativeProbs() {
    int players = this->private_cards.size();
    for(int player_id = 0; player_id < players;player_id ++){
        // TODO 这里只考虑了两个玩家的情况
        int oppo = 1 - player_id;
        float player_prob_sum = 0;

        for(std::size_t i = 0;i < this->private_cards[player_id].size();i ++) {
            float oppo_prob_sum = 0;
            PrivateCards* player_card = &this->private_cards[player_id][i];
            uint64_t player_long = Card::boardInts2long(player_card->get_hands());

            //
            if (Card::boardsHasIntercept(player_long,this->initialboard)){
                continue;
            }

            for (auto oppo_card : this->private_cards[oppo]) {
                uint64_t oppo_long = Card::boardInts2long(oppo_card.get_hands());
                if (Card::boardsHasIntercept(oppo_long,this->initialboard)
                    || Card::boardsHasIntercept(oppo_long,player_long)
                        ){
                    continue;
                }
                oppo_prob_sum += oppo_card.weight;

            }
            player_card->relative_prob = oppo_prob_sum * player_card->weight;
            player_prob_sum += player_card->relative_prob;
        }
        for(std::size_t i = 0;i < this->private_cards[player_id].size();i ++) {
            this->private_cards[player_id][i].relative_prob = this->private_cards[player_id][i].relative_prob / player_prob_sum;
            //player_card.relative_prob = player_card.relative_prob / player_prob_sum;
        }

    }
}
```