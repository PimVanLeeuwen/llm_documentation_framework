`build_tree`: The function of `build_tree` is to build a game tree for the specified poker mode, either Texas Hold'em or Short Deck.

**Code Description**: 
The `build_tree` method initializes a game tree data structure based on the current poker mode. It calls the `build_game_tree` method from the PokerSolver class, passing in various parameters such as the current round, raise limit, small and big blinds, stack size, and all-in threshold. The `build_game_tree` method creates a shared pointer to a GameTree object with specified settings and assigns it to the solver's internal game tree member. This process is repeated for both Hold'em and Short Deck modes, depending on the value of the mode variable. The method logs messages indicating the start and completion of the tree building process using qDebug(). \\
 ## Code: 
 ```
void QSolverJob::build_tree(){
    qDebug().noquote() << tr("building tree..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        ps_holdem.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }else if(this->mode == Mode::SHORTDECK){
        ps_shortdeck.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }
    qDebug().noquote() << tr("build tree finished");//.toStdString() << endl;
}
```