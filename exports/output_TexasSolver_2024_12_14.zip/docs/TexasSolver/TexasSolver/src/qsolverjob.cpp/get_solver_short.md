The `get_solver` method returns a pointer to a specific poker solver based on the job mode.
It throws a runtime error if the mode is unknown or unsupported.