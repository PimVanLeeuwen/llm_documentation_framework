`get_solver`: The function of `get_solver` is to return a pointer to the PokerSolver object associated with the current mode of operation.

**Code Description**: 
The `get_solver` method returns a reference to a PokerSolver object based on the current mode of operation. It checks if the mode is HOLDEM or SHORTDECK, and if so, it returns a reference to either ps_holdem or ps_shortdeck respectively. If the mode is neither HOLDEM nor SHORTDECK, it throws a runtime_error with an "unknown mode" message. This suggests that the method is designed to provide access to a PokerSolver object tailored to the specific game variant being played in the TexasSolver application. \\
 ## Code: 
 ```
PokerSolver* QSolverJob::get_solver(){
    if(this->mode == Mode::HOLDEM){
        return &this->ps_holdem;
    }else if(this->mode == Mode::SHORTDECK){
        return &this->ps_shortdeck;
    }else throw runtime_error("unknown mode in get_solver");
}
```