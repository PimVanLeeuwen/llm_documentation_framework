`saving`: The function of `saving` is to save game data in a JSON file based on the current game mode and settings.

**Code Description**: 
The `saving` method is responsible for saving the game state to a JSON file. It starts by logging a message indicating that it's saving the JSON file. Then, it retrieves the value of "dump_round" from the QSettings object, which stores the game settings, and assigns it to the `this->dump_rounds` variable.

The method then checks if the current mode is HOLDEM or SHORTDECK and calls the corresponding dump_strategy function on the respective poker strategy object (ps_holdem or ps_shortdeck) with the savefile path and dump_rounds value as arguments. This suggests that the game data being saved includes the poker strategy for the current game mode.

If the `dump_rounds` value is 3, it logs a warning message indicating that saving at this level could be slow or even cause memory issues due to poor optimization of the "dump to river" feature.

Finally, the method logs another message indicating that saving is complete. \\
 ## Code: 
 ```
void QSolverJob::saving(){
    qDebug().noquote() << tr("Saving json file..");//.toStdString() << std::endl;

    QSettings setting("TexasSolver", "Setting");
    setting.beginGroup("solver");
    this->dump_rounds = setting.value("dump_round").toInt();

    qDebug().noquote() << tr("Dump round: ") << this->dump_rounds;
    if(this->dump_rounds == 3){
        qDebug().noquote() << tr("This could be slow, or even blow your RAM, dump to river is not well optimized :(");
    }
    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.dump_strategy(this->savefile,this->dump_rounds);
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.dump_strategy(this->savefile,this->dump_rounds);
    }
    qDebug().noquote() << tr("Saving done.");//.toStdString() << std::endl;
}
```