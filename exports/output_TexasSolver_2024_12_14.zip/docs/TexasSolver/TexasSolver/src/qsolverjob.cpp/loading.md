**loading**: The function of `loading` is to initialize a poker game environment by loading poker hand strength data from files for Hold'em and Shortdeck modes.

**Code Description**: 
The `loading` method initializes the poker solver job by loading poker hand strength data from files for both Hold'em and Shortdeck modes. It creates instances of the `PokerSolver` class, which is responsible for generating a deck of cards and loading poker hand strength data from files. The method loads the necessary resources, including card ranks and suits, and initializes the poker solver objects with the loaded data. The process involves creating a string representation of the card ranks and suits, specifying the resource directory path, and then instantiating the `PokerSolver` class for each mode (Hold'em and Shortdeck) by passing in the required parameters such as card ranks, suits, file paths, and line counts. \\
 ## Code: 
 ```
void QSolverJob::loading(){
    string suits = "c,d,h,s";
    string ranks;
    this->resource_dir =  ":/resources";
    string compairer_file, compairer_file_bin;
    int lines;
    qDebug().noquote() << tr("Loading holdem compairing file");//.toStdString() << endl;
    //if(mode == "holdem"){
    ranks = "2,3,4,5,6,7,8,9,T,J,Q,K,A";
    compairer_file = this->resource_dir + "/compairer/card5_dic_sorted.txt";
    compairer_file_bin = this->resource_dir + "/compairer/card5_dic_zipped.bin";
    //qDebug().noquote() << compairer_file_bin.c_str();
    lines = 2598961;
    this->ps_holdem = PokerSolver(ranks,suits,compairer_file,lines,compairer_file_bin);

    qDebug().noquote() << tr("Loading shortdeck compairing file");//.toStdString() << endl;
    //}else if(mode == "shortdeck"){
    ranks = "6,7,8,9,T,J,Q,K,A";
    compairer_file = this->resource_dir + "/compairer/card5_dic_sorted_shortdeck.txt";
    compairer_file_bin = this->resource_dir + "/compairer/card5_dic_zipped_shortdeck.bin";
    lines = 376993;
    this->ps_shortdeck = PokerSolver(ranks,suits,compairer_file,lines,compairer_file_bin);
    qDebug().noquote() << tr("Loading finished. Good to go.");//.toStdString() << endl;
}
```