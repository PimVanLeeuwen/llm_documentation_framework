The `estimate_tree_memory` method estimates the memory required to build a decision tree for a given poker game scenario.

This method takes three parameters: `range1`, `range2`, and `board`, which represent the current state of the game, and returns an estimated memory usage in bytes.