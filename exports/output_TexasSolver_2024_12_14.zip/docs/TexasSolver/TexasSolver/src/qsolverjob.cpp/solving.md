`solving`: The function of `solving` is to initiate a poker game solver training process based on the specified mode and parameters.

**Code Description**: 
The `solving` method in the QSolverJob class is responsible for starting the training process of a poker game solver. It takes into account the current mode (HOLDEM or SHORTDECK) and calls the corresponding train method on either ps_holdem or ps_shortdeck objects, respectively. The train method initializes a PCfrSolver object with the provided inputs and performs the actual training process using the specified algorithm parameters. The method also logs messages to indicate the start and completion of the solving process. \\
 ## Code: 
 ```
void QSolverJob::solving(){
    // TODO  为什么ui上多次求解会积累memory？哪里leak了？
    // TODO  为什么有时候会莫名闪退？
    qDebug().noquote() << tr("Start Solving..");//.toStdString() << std::endl;

    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }
    qDebug().noquote() << tr("Solving done.");//.toStdString() << std::endl;
}
```