`run`: The function of `run` is to execute a specific mission type based on the current state of the QSolverJob object.

**Code Description**: 
The `run` method in the QSolverJob class determines which action to take based on the current mission type. It checks if the current mission is SOLVING, LOADING, BUILDTREE, or SAVING and calls the corresponding method (solving, loading, build_tree, or saving) to perform the respective task. If an unsupported mission type is encountered, it throws a runtime_error with a descriptive message. The method also catches any runtime errors that may occur during execution and logs the error using qDebug(). \\
 ## Code: 
 ```
void QSolverJob::run()
{
    //QDebugStream qout(qDebug().noquote(), this->textEdit);
    try{
        if(this->current_mission == MissionType::SOLVING){
            this->solving();
        }else if(this->current_mission == MissionType::LOADING){
            this->loading();
        }else if(this->current_mission == MissionType::BUILDTREE){
            this->build_tree();
        }else if(this->current_mission == MissionType::SAVING){
            this->saving();
        }else{
            throw runtime_error("unsupported mission type");
        }
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```