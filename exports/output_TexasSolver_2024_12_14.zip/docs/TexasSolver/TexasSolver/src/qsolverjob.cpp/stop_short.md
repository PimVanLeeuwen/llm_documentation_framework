The `stop` method in QSolverJob stops a solver based on its current mode, either HOLDEM or SHORTDECK.

It calls the `stop` methods on the corresponding poker strategy objects (`ps_holdem` and `ps_shortdeck`).