`estimate_tree_memory`: The function of `estimate_tree_memory` is to estimate the memory required for a tree in a poker solver job.

**Parameters**:
- `QString range1`: The first betting range.
- `QString range2`: The second betting range.
- `QString board`: The current state of the board.

**Code Description**: 
The `estimate_tree_memory` function is used to estimate the memory required for a tree in a poker solver job. It takes three parameters: `range1`, `range2`, and `board`. 

Based on the mode of the poker game, it calls either `ps_holdem.estimate_tree_memory` or `ps_shortdeck.estimate_tree_memory` to perform the estimation.

If the mode is HOLDEM, it uses the `ps_holdem` object to estimate the tree memory. If the mode is SHORTDECK, it uses the `ps_shortdeck` object for the estimation.

The function returns the estimated tree memory as a long long integer value. If the mode is neither HOLDEM nor SHORTDECK, it returns 0. \\
 ## Code: 
 ```
long long QSolverJob::estimate_tree_memory(QString range1,QString range2,QString board){
    qDebug().noquote() << tr("Estimating tree memory..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        return ps_holdem.estimate_tree_memory(range1,range2,board);
    }else if(this->mode == Mode::SHORTDECK){
        return ps_shortdeck.estimate_tree_memory(range1,range2,board);
    }
    return 0;
}
```