The `solving` method initiates a poker game solver training process based on specified parameters.
It calls the `train` method to perform the actual training, depending on the selected game mode.