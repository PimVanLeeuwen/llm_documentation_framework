`stop`: The function of `stop` is to terminate the solver job, stopping any ongoing calculations or processes associated with it.

**Code Description**: 
The `stop` method in the QSolverJob class is responsible for halting the solver's activity. It first logs a message indicating its attempt to stop the solver using qDebug(). If the current mode of operation is HOLDEM, it calls the stop method on the ps_holdem object. Similarly, if the mode is SHORTDECK, it stops the ps_shortdeck object. This suggests that the solver job has different components or modes (HOLDEM and SHORTDECK) that need to be stopped individually when the overall job is terminated. The use of if-else statements implies a clear distinction between these modes, with each having its own set of processes or calculations that must be halted. \\
 ## Code: 
 ```
void QSolverJob::stop(){
    qDebug().noquote() << tr("Trying to stop solver.");
    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.stop();
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.stop();
    }
}
```