`GameTreeBuildingSettings`: The function of `GameTreeBuildingSettings` is to initialize and set up the game tree building settings for a Texas Hold'em poker game.

**Parameters**:

`StreetSetting flop_ip`: The initial setting for the flop street, which represents the first three community cards dealt in a Texas Hold'em game.

`StreetSetting turn_ip`: The initial setting for the turn street, which represents the fourth community card dealt in a Texas Hold'em game.

`StreetSetting river_ip`: The initial setting for the river street, which represents the final fifth community card dealt in a Texas Hold'em game.

`StreetSetting flop_oop`: The out-of-position (oopp) setting for the flop street, which is used to determine the player's position relative to the community cards.

`StreetSetting turn_oop`: The oopp setting for the turn street, which is used to determine the player's position relative to the community cards.

`StreetSetting river_oop`: The oopp setting for the river street, which is used to determine the player's position relative to the community cards.

**Code Description**: This constructor initializes a `GameTreeBuildingSettings` object by taking in six parameters: three initial settings (`flop_ip`, `turn_ip`, and `river_ip`) and three out-of-position settings (`flop_oop`, `turn_oop`, and `river_oop`). Each parameter is assigned to a corresponding member variable of the class, allowing for easy access and modification of these settings throughout the game tree building process. \\
 ## Code: 
 ```
GameTreeBuildingSettings::GameTreeBuildingSettings(
        StreetSetting flop_ip,
        StreetSetting turn_ip,
        StreetSetting river_ip,
        StreetSetting flop_oop,
        StreetSetting turn_oop,
        StreetSetting river_oop):flop_ip(flop_ip),turn_ip(turn_ip),river_ip(river_ip),flop_oop(flop_oop),turn_oop(turn_oop),river_oop(river_oop) {
}
```