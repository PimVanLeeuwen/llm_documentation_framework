`get_setting`: The function of `get_setting` is to retrieve a specific StreetSetting object based on the given player and round.

**Parameters**:
`string player`: This parameter specifies the type of player, either "ip" (inner position) or "oop" (outer position).
`string round`: This parameter specifies the current round in Texas Hold'em poker, which can be "flop", "turn", or "river".

**Code Description**: The `get_setting` function takes two string parameters, `player` and `round`, and returns a reference to a StreetSetting object. It uses if-else statements to determine which StreetSetting object to return based on the combination of `player` and `round`. If an invalid combination is provided, it throws a runtime error. The function appears to be part of a larger system for building game trees in Texas Hold'em poker, where different settings are required for each player position and round. \\
 ## Code: 
 ```
StreetSetting& GameTreeBuildingSettings::get_setting(string player,string round){
    if(player == "ip" && round == "flop") return flop_ip;
    else if(player == "ip" && round == "turn") return turn_ip;
    else if(player == "ip" && round == "river") return river_ip;
    else if(player == "oop" && round == "flop") return flop_oop;
    else if(player == "oop" && round == "turn") return turn_oop;
    else if(player == "oop" && round == "river") return river_oop;
    else throw runtime_error("get_setting not valid");
}
```