The `get_setting` method retrieves a specific game setting based on the player type and round in Texas Hold'em poker.

It returns a reference to a `StreetSetting` object, or throws an exception if the input parameters are invalid.