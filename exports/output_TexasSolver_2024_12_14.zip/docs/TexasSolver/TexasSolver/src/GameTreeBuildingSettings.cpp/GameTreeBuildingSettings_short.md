The `GameTreeBuildingSettings` class initializes its member variables using provided settings for different stages of a game, specifically flop, turn, and river.

This constructor takes six StreetSetting parameters to set up the game tree building settings for both inner (ip) and outer (oop) positions on the flop, turn, and river.