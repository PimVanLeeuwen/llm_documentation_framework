`getType`: The function of `getType` is to return the type of a ShowdownNode in the TexasSolver project structure.

**Code Description**: 
The `getType` method is a part of the `ShowdownNode` class within the `TexasSolver` project. It returns the type of the current node, which is specifically defined as `SHOWDOWN`. This indicates that the node represents a showdown state in the game tree, where players are competing against each other directly. The method simply returns this predefined value without any complex calculations or logic. Its purpose is to provide a clear and concise identification of the node's type within the game tree structure. \\
 ## Code: 
 ```
GameTreeNode::GameTreeNodeType ShowdownNode::getType() {
    return SHOWDOWN;
}
```