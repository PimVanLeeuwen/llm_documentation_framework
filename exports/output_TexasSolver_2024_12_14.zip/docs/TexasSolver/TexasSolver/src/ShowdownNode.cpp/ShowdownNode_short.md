The `ShowdownNode` class initializes game tree nodes for showdown scenarios in a Texas Hold'em game, handling tie payoffs and player payoffs.

This constructor sets up a `ShowdownNode` object with given parameters, including tie payoffs, player payoffs, round information, pot size, and parent node reference.