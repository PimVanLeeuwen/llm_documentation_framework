`ShowdownNode`: The function of `ShowdownNode` is to initialize a node in the game tree for a showdown scenario, where multiple players have the same payoffs.

**Parameters**:

`vector<double> tie_payoffs`: A vector of double values representing the payoffs that all players are tied with.

`vector<vector<double>> player_payoffs`: A 2D vector of double values representing the payoffs for each player in the game, where each inner vector represents a player's payoffs.

`GameTreeNode::GameRound round`: An object of type `GameTreeNode::GameRound` representing the current round of the game.

`double pot`: The total pot value at this point in the game.

`shared_ptr<GameTreeNode>parent`: A shared pointer to the parent node in the game tree, which represents the previous state of the game.

**Code Description**: 
The `ShowdownNode` constructor initializes a new node in the game tree by calling the base class constructor `GameTreeNode(round,pot,std::move(parent))`. It then assigns the provided `tie_payoffs`, `player_payoffs`, and other parameters to the corresponding member variables of the `ShowdownNode` object. The `std::move` function is used to transfer ownership of the vectors `tie_payoffs` and `player_payoffs` to the `ShowdownNode` object, which takes ownership of these resources. This ensures that the `ShowdownNode` object manages the memory for these vectors and can properly clean up when it is destroyed. \\
 ## Code: 
 ```
ShowdownNode::ShowdownNode(vector<double> tie_payoffs, vector<vector<double>> player_payoffs,
                           GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode>parent):
                           GameTreeNode(round,pot,std::move(parent)) {
    this->tie_payoffs = std::move(tie_payoffs);
    this->player_payoffs = std::move(player_payoffs);
}
```