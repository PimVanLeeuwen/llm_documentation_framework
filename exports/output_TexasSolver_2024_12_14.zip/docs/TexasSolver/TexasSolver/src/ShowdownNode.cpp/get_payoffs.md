`get_payoffs`: The function of `get_payoffs` is to retrieve the payoffs for a given showdown outcome.

**Parameters**:
`ShowdownNode::ShowDownResult result`: This parameter specifies the result of the showdown, which can be either a tie or not a tie.
`int winner`: This parameter indicates the winner of the showdown, where -1 represents a tie and a non-negative integer represents the player who won.

**Code Description**: The `get_payoffs` function takes in two parameters: `result` and `winner`. It first checks if the result is not a tie (`ShowDownResult::NOTTIE`). If so, it then checks if the winner is -1 (indicating a tie). If this condition is met, it throws a runtime error. Otherwise, it returns the payoffs for the specified winner from the `player_payoffs` vector.

If the result is a tie (`ShowDownResult::TIE`), it checks if the winner is not -1 (indicating that the result should be a tie). If this condition is met, it throws a runtime error. Otherwise, it returns the payoffs for a tie from the `tie_payoffs` member variable.

In summary, the `get_payoffs` function retrieves the payoffs based on the outcome of a showdown and the winner (or lack thereof) in a concise and efficient manner. \\
 ## Code: 
 ```
vector<double> ShowdownNode::get_payoffs(ShowdownNode::ShowDownResult result, int winner) {
    if(result == ShowDownResult::NOTTIE){
        if(winner == -1) throw runtime_error("winner == -1 in tie");
        vector<double> retval = player_payoffs[winner];
        return retval;
    }else{
        // if the showdown is a tie
        if(winner != -1) throw runtime_error("winner != -1 in not tie");
        return this->tie_payoffs;
    }
}
```