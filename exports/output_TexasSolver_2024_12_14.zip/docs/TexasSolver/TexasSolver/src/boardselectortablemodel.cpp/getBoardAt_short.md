This method retrieves a float value from a 2D grid at specified coordinates.
It checks for valid row and column indices before returning the value.