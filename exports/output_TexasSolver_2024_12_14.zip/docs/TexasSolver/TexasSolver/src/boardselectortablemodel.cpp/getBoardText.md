`getBoardText`: The function of `getBoardText` is to generate a string representation of the board, where each cell's value is included if it has a non-zero grid float value.

**Code Description**: 
The `getBoardText` method iterates through two-dimensional arrays (`suitlist`, `ranklist`, `grids_float`, and `grids_string`) to construct a comma-separated string. It checks for non-zero values in the `grids_float` array, and if found, appends the corresponding value from the `grids_string` array to the result string. If the result string is empty initially, it sets the initial value; otherwise, it appends the new value with a comma separator. The method returns this constructed string as the board text representation. \\
 ## Code: 
 ```
QString BoardSelectorTableModel::getBoardText(){
    QString retval = "";
    for(int i = 0;i < this->suitlist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            if(this->grids_float[i][j] == 0)continue;
            QString one_board_str = QString("%1").arg(this->grids_string[i][j]);
            if(retval == ""){
                retval = one_board_str;
            }else{
                retval = retval + "," + one_board_str;
            }
        }
    }
    return retval;
}
```