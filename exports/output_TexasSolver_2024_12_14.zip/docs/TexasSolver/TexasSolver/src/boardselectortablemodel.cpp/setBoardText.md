`setBoardText`: The function of `setBoardText` is to update the Texas Hold'em poker board with a new set of boards from a given string.

**Parameters**:
`QString input_board`: A string containing comma-separated board values, where each value represents a specific position on the board.

**Code Description**: 
The `setBoardText` method takes a string `input_board` as an argument and updates the Texas Hold'em poker board accordingly. It first clears any existing data in the board using the `clear_board` method. Then, it iterates through each value in the input string, splitting it into individual boards using the comma as a delimiter.

For each board, it checks if the format is correct by checking if the string contains a space or is empty. If not, it skips to the next iteration. It then checks if the board is already present in the `string2ij` map. If not, it prints an error message and continues to the next iteration.

If the board is valid, it extracts the coordinates of the board from the `string2ij` map and sets the corresponding value in the `grids_float` 2D grid to a float value of 1.0. This effectively updates the poker board with the new set of boards provided in the input string. \\
 ## Code: 
 ```
void BoardSelectorTableModel::setBoardText(QString input_board){
    this->clear_board();
    for(QString one_board:input_board.split(",")){
        float board_float = 1.0;


        if(one_board.count(" ") == one_board.length() || one_board == "")continue;
        if(!this->string2ij.count(one_board)){
            qDebug().noquote() << QString(tr("skipping board %1, format error")).arg(one_board);
            continue;
        }
        pair<int,int> cord = this->string2ij[one_board];
        this->grids_float[cord.first][cord.second] = board_float;
    }
}
```