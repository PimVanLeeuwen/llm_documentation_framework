`rowCount`: The function of `rowCount` is to return the total number of rows in a table model.

**Parameters**:
`const QModelIndex &parent`: This parameter represents the parent index of the item for which the row count is being requested. It is used to determine the scope of the row count, i.e., whether it should include child items or not.

**Code Description**: The `rowCount` function returns the size of the `suitlist` vector in the `BoardSelectorTableModel` class. This suggests that the table model represents a list of suits, and the row count is determined by the number of suits available. \\
 ## Code: 
 ```
int BoardSelectorTableModel::rowCount(const QModelIndex &parent) const {
    return this->suitlist.size();
}
```