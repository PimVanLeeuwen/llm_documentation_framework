`setBoardAt`: The function of `setBoardAt` is to set the value at a specific position on a board.

**Parameters**:
- `int i`: The row index of the grid where the value will be set.
- `int j`: The column index of the grid where the value will be set.
- `float value`: The value that will be set at the specified position.

**Code Description**: 
The `setBoardAt` function checks if the provided indices `i` and `j` are within valid ranges for the suitlist and ranklist, respectively. If they are not, it logs an error message using qDebug(). If the indices are valid, it sets the value at the specified position in the grids_float array to the provided float value. \\
 ## Code: 
 ```
void BoardSelectorTableModel::setBoardAt(int i, int j,float value){
    if(i < 0 || i >= this->suitlist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::setBoardAt i not valid: " << i;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::setBoardAt j not valid: " << j;
    }
    else{
        this->grids_float[i][j] = value;
    }
}
```