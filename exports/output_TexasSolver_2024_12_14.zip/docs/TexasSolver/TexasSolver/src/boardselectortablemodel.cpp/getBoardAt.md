`getBoardAt`: The function of `getBoardAt` is to retrieve the value at a specific position on a grid.

**Parameters**:
`int i`: The row index of the grid.
`int j`: The column index of the grid.

**Code Description**: 
The `getBoardAt` method retrieves the value at a specified position (i, j) on a grid. It first checks if the provided indices are within valid ranges for both rows and columns. If either index is out of range, it logs an error message using `qDebug()` and returns 0. Otherwise, it returns the value stored in the grid at the specified position (i, j). The grid values are accessed through the `grids_float` member variable, which is a 2D array representing the grid. \\
 ## Code: 
 ```
float BoardSelectorTableModel::getBoardAt(int i, int j){
    if(i < 0 || i >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::getBoardAt i not valid: " << i;
        return 0;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::getBoardAt j not valid: " << j;
        return 0;
    }
    else{
        return this->grids_float[i][j];
    }
}
```