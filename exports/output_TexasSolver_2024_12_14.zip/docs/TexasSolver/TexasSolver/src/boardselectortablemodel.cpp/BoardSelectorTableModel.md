`BoardSelectorTableModel`: The function of `BoardSelectorTableModel` is to initialize and configure a table model for displaying poker board data.

**Parameters**:
`QStringList ranks`: A list of poker card ranks.
`QString initial_board`: A comma-separated string representing the initial state of the poker board.
`QObject *parent`: The parent object of the table model, which can be used to establish relationships between objects in the application.

**Code Description**: 
The `BoardSelectorTableModel` constructor initializes a table model by setting up data structures and populating them with information from the input parameters. It takes three inputs: a list of poker card ranks, an initial board state as a comma-separated string, and a parent object for the table model.

Upon initialization, the constructor sets up two 2D vectors, `grids_string` and `grids_float`, to store string and float representations of the poker board grid cells. It then populates these vectors by iterating through each rank and suit combination, using the `get_ij_text` method to generate a string representation for each cell.

The constructor also calls the `setBoardText` method to populate the table model with data from the initial board state input string. This involves converting each substring in the input string into a coordinate pair and assigning a float value to the corresponding grid cell in the `grids_float` vector.

Finally, the constructor initializes the `string2ij` map to store the mapping between string representations of grid cells and their corresponding integer coordinates. \\
 ## Code: 
 ```
BoardSelectorTableModel::BoardSelectorTableModel(QStringList ranks,QString initial_board,QObject *parent):QAbstractItemModel(parent){
    this->ranklist = ranks;
    this->suitlist = QString("c,d,h,s").split(",");

    this->grids_string = vector<vector<QString>>(this->suitlist.size());
    for(int i = 0;i < this->suitlist.size();i ++){
        this->grids_string[i] = vector<QString>(this->ranklist.size());
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_string[i][j] = this->get_ij_text(i,j);
            this->string2ij[this->get_ij_text(i,j)] = pair<int,int>(i,j);
        }
    }

    this->grids_float = vector<vector<float>>(this->suitlist.size());
    for(int i = 0;i < this->suitlist.size();i ++){
        this->grids_float[i] = vector<float>(this->ranklist.size(),0.0);
    }
    this->setBoardText(initial_board);
}
```