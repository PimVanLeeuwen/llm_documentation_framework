**toString**: The function of `toString` is to return a string representation of the game action, including the poker action and amount (if applicable).

**Code Description**: 
The `toString` method in the `GameActions` class returns a string representation of the game action. If the `amount` member variable is -1, it calls the `pokerActionToString` method to convert the `action` enum value into its corresponding string representation and returns this result. Otherwise, it appends the string representation of the `amount` (converted using `to_string`) to the result of calling `pokerActionToString` on the `action` enum value. This allows for a concise and human-readable display of game actions in the Texas Solver application. \\
 ## Code: 
 ```
string GameActions::toString() {
    if(this->amount == -1) {
        return this->pokerActionToString(this->action);
    }else{
        return this->pokerActionToString(this->action) + " " + to_string(amount);
    }
}
```