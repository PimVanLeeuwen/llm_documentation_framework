The `toString` method in the `GameActions` class returns a string representation of its current state, including any poker action and amount.

This method uses the `pokerActionToString` helper function to convert the poker action into a string, and appends the amount (if applicable) to create the final output.