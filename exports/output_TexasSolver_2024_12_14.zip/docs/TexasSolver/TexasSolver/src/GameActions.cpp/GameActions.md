`GameActions`: The function of `GameActions` is to initialize a game action object with the specified poker action and amount.

**Parameters**:
`GameTreeNode::PokerActions action`: This parameter specifies the type of poker action, which can be RAISE, BET, CHECK, FOLD, or CALL.
`double amount`: This parameter represents the amount associated with the poker action. A value of -1 indicates a specific condition for certain actions.

**Code Description**: The `GameActions` constructor initializes an object to represent a game action in a Texas Hold'em game. It takes two parameters: `action`, which specifies the type of poker action, and `amount`, which represents the associated amount. The code checks if the `amount` is valid based on the specified `action`. If the `action` is RAISE or BET and the `amount` is -1, it throws a runtime error. Similarly, if the `action` is CHECK, FOLD, or CALL and the `amount` is not -1, it also throws a runtime error. The constructor then assigns the provided values to the object's properties. \\
 ## Code: 
 ```
GameActions::GameActions(GameTreeNode::PokerActions action, double amount) {
    this->action = action;
    if (action == GameTreeNode::PokerActions::RAISE || action == GameTreeNode::PokerActions::BET ) {
        if (amount == -1) throw runtime_error(tfm::format("raise/bet amount should not be -1, find %s",amount));
    } else {
        if (amount != -1) throw runtime_error(tfm::format("check/fold/call amount should be -1, find %s",amount));
    }
    this->amount = amount;
}
```