`getAction`: The function of `getAction` is to retrieve the current action from the game state.

**Code Description**: 
The `getAction` method returns an instance of `GameTreeNode::PokerActions`, which represents the current action in the game. This method simply retrieves and returns the value of the `action` member variable, indicating that it does not perform any complex calculations or operations but rather serves as a getter for the existing action data. The purpose of this method is to provide access to the current state of the game, allowing other parts of the program to utilize this information as needed. \\
 ## Code: 
 ```
GameTreeNode::PokerActions GameActions::getAction() {
    return this->action;
}
```