`getAmount`: The function of `getAmount` is to return the current amount value stored in the object.

**Code Description**: 
The `getAmount` method is a simple getter function that returns the current amount value. It does not modify or update any values, but rather provides access to the existing amount data. This method can be used by other parts of the program to retrieve and utilize the amount value as needed. The implementation is straightforward, directly returning the `amount` member variable stored within the object. \\
 ## Code: 
 ```
double GameActions::getAmount() {
    return this->amount;
}
```