The `ActionNode` class initializes a new game node in the Texas Solver project, representing a specific action taken by a player.

This constructor sets up the necessary attributes for the `ActionNode`, including actions, children nodes, player information, and game round details.