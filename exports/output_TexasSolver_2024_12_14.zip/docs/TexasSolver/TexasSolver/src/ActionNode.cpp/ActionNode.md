Here is the completed template:

`ActionNode`: The function of `ActionNode` is to represent a node in the game tree that corresponds to an action taken by a player.

**Parameters**:
`vector<GameActions> actions`: A list of possible actions that can be taken at this point in the game.
`vector<shared_ptr<GameTreeNode>> childrens`: A list of child nodes, each representing a possible outcome of the current action.
`int player`: The ID or index of the player who is taking the action.
`GameTreeNode::GameRound round`: The current round number in the game.
`double pot`: The current size of the pot (the amount of money at stake).
`shared_ptr<GameTreeNode> parent`: A reference to the parent node, representing the previous state of the game.

**Code Description**: 
The `ActionNode` constructor initializes a new node with the given parameters. It takes ownership of the provided `actions`, `childrens`, and `parent` vectors, and assigns them to member variables. The `player`, `round`, and `pot` values are also assigned directly to their respective member variables. This allows for efficient creation of game tree nodes that represent specific actions taken by players in a Texas Hold'em game. \\
 ## Code: 
 ```
ActionNode::ActionNode(vector<GameActions> actions, vector<shared_ptr<GameTreeNode>> childrens, int player,
                       GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent) :GameTreeNode(round,pot,std::move(parent)){
    this->actions = std::move(actions);
    this->player = player;
    this->childrens = std::move(childrens);
    //cout << "ActionNode created" << endl;
}
```