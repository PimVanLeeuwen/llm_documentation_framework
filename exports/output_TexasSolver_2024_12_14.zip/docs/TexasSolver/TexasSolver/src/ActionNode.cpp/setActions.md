`setActions`: The function of `setActions` is to assign a list of game actions to the current ActionNode.

**Parameters**:
`const vector<GameActions> &actions`: A reference to a vector of GameActions objects, which represents a collection of game-related actions.

**Code Description**: 
The `setActions` method takes a constant reference to a vector of GameActions as input and assigns it to the member variable `actions` within the ActionNode class. This allows the ActionNode to store and manage a list of game actions, potentially used for decision-making or other purposes within the TexasSolver project. The method does not modify the original vector; instead, it copies the reference to the vector's contents into the ActionNode's own data structure. \\
 ## Code: 
 ```
void ActionNode::setActions(const vector<GameActions> &actions) {
    ActionNode::actions = actions;
}
```