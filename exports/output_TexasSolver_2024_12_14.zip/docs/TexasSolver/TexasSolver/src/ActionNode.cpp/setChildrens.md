`setChildrens`: The function of `setChildrens` is to set the children nodes for an ActionNode.

**Parameters**:
`const vector<shared_ptr<GameTreeNode>> &childrens`: A reference to a vector of shared pointers to GameTreeNode objects, representing the child nodes to be assigned to the ActionNode.

**Code Description**: 
The `setChildrens` method takes a vector of shared pointers to GameTreeNode objects as input and assigns it to the `childrens` member variable of the ActionNode class. This allows an ActionNode object to manage its child nodes, which are instances of the GameTreeNode class. The method does not perform any validation or processing on the input children; it simply copies the reference to the vector of shared pointers into the `childrens` member variable. \\
 ## Code: 
 ```
void ActionNode::setChildrens(const vector<shared_ptr<GameTreeNode>> &childrens) {
    ActionNode::childrens = childrens;
}
```