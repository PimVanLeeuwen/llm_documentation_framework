`getActions`: The function of `getActions` is to retrieve a reference to the vector of game actions associated with this ActionNode object.

**Code Description**: 
The `getActions` method is a simple accessor that returns a reference to the internal `actions` vector. This allows external code to access and utilize the list of game actions stored within the current ActionNode instance without modifying it directly. The method does not perform any data processing or manipulation; its sole purpose is to provide read-only access to the existing collection of game actions. \\
 ## Code: 
 ```
vector<GameActions>& ActionNode::getActions() {
    return this->actions;
}
```