`getType`: The function of `getType` is to return the type of an action node in a game tree.

**Code Description**: 
The `getType` method is a part of the `ActionNode` class within the TexasSolver project. It returns the type of the current node, which is specifically defined as `ACTION`. This indicates that the node represents an action or decision point in the game tree, rather than a terminal state or other type of node. The return value of `ACTION` suggests that this method is used to identify and differentiate between different types of nodes within the game tree structure. \\
 ## Code: 
 ```
GameTreeNode::GameTreeNodeType ActionNode::getType() {
    return ACTION;
}
```