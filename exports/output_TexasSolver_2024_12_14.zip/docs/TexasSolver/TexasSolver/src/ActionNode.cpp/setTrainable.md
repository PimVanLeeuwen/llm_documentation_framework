`setTrainable`: The function of `setTrainable` is to set the trainable objects and private cards for an ActionNode.

**Parameters**:
`vector<shared_ptr<Trainable>> trainables`: A vector of shared pointers to Trainable objects, which are set as the trainable objects for the ActionNode.
`vector<PrivateCards>* player_privates`: A pointer to a vector of PrivateCards, which represents the private cards of the player.

**Code Description**: The `setTrainable` function takes two parameters: `trainables` and `player_privates`. It sets the `trainables` member variable of the ActionNode to the provided vector of Trainable objects. Additionally, it sets the `player_privates` member variable to the provided pointer to a vector of PrivateCards. This allows the ActionNode to keep track of the trainable objects and private cards associated with it. \\
 ## Code: 
 ```
void ActionNode::setTrainable(vector<shared_ptr<Trainable>> trainables,vector<PrivateCards>* player_privates) {
    this->trainables = trainables;
    this->player_privates = player_privates;
}
```