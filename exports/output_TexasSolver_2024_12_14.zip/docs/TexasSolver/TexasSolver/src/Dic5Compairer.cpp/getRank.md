`getRank`: The function of `getRank` is to calculate the minimum rank among all possible 5-card combinations from a given set of cards.

**Parameters**:
`vector<Card> cards`: A vector of Card objects representing the set of cards to generate combinations from.

**Code Description**: 
The `getRank` method takes a vector of Card objects as input and returns an integer value representing the minimum rank among all possible 5-card combinations. The method first converts each Card object in the input vector into its corresponding integer representation using the `getCardInt` method, storing these values in a separate vector called `cards_int`. It then calls another instance of itself with the `cards_int` vector as input, which calculates and returns the minimum rank among all possible 5-card combinations from the converted card integers. The returned value is then passed back to this instance, where it is ultimately returned as the result of the original `getRank` method call. \\
 ## Code: 
 ```
int Dic5Compairer::getRank(vector<Card> cards) {
    vector<int> cards_int(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_int[i] = cards[i].getCardInt();
    }
    return this->getRank(cards_int);
}
```