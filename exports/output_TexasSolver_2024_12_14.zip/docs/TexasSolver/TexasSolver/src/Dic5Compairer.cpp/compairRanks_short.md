The `compairRanks` method compares the ranks of two cards in a TexasSolver game, returning the result as either larger, smaller, or equal.

This method takes two integer parameters representing the ranks of the former and latter cards, respectively.