`get_rank`: The function of `get_rank` is to determine the rank of a poker hand given a private hand and a public board.

**Parameters**:
- `uint64_t private_hand`: A 64-bit unsigned integer representing the player's private cards.
- `uint64_t public_board`: A 64-bit unsigned integer representing the community cards on the table.

**Code Description**: 
The `get_rank` function takes two parameters, `private_hand` and `public_board`, both represented as 64-bit unsigned integers. It first calls the `long2board` method from the `Card.cpp` file to convert these integers into vectors of card indices. The converted private hand and public board are then passed to another instance of the `get_rank` function, which is presumably responsible for determining the rank of the poker hand based on the combined cards. \\
 ## Code: 
 ```
int Dic5Compairer::get_rank(uint64_t private_hand, uint64_t public_board) {
    return this->get_rank(Card::long2board(private_hand),Card::long2board(public_board));
}
```