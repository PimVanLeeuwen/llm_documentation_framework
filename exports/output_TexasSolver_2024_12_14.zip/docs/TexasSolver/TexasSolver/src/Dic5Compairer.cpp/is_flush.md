`is_flush`: The function of `is_flush` is to determine whether a given poker hand represented by its hash value is a flush.

**Parameters**:
`uint64_t hash`: A 64-bit unsigned integer representing the hash value of a poker hand, where each bit corresponds to a specific suit (0-3) in a standard deck of cards.

**Code Description**: The `is_flush` function takes a `uint64_t` hash as input and returns a boolean indicating whether the corresponding poker hand is a flush. It does this by counting the number of bits set in the hash value that correspond to specific suits (0-3). If more than one suit has a bit set, it means the hand is not a flush, so the function returns `false`. Otherwise, if only one or no suits have a bit set, the function returns `true`, indicating that the hand is indeed a flush. \\
 ## Code: 
 ```
bool is_flush(uint64_t hash) {
    int cnt = (hash & SUIT_0_MASK) != 0;
    cnt += (hash & SUIT_1_MASK) != 0;
    if (cnt > 1) return false;
    cnt += (hash & SUIT_2_MASK) != 0;
    if (cnt > 1) return false;
    cnt += (hash & SUIT_3_MASK) != 0;
    return cnt > 1 ? false : true;
}
```