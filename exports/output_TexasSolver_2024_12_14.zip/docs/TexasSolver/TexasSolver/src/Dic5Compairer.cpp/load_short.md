The `load` method loads data from a file into two maps, `flush_map` and `other_map`, using binary read operations.

This method returns true if the loading process is successful, indicating that the maps have been populated with data from the file.