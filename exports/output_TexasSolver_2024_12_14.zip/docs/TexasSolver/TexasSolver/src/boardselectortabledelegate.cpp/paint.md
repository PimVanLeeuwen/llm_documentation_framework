`paint`: The function of `paint` is to draw a table item in the BoardSelectorTableDelegate, representing a card from a deck.

**Parameters**:
`QPainter *painter`: A pointer to a QPainter object used for drawing.
`const QStyleOptionViewItem &option`: A reference to a QStyleOptionViewItem object containing information about the item being painted.
`const QModelIndex &index`: A reference to a QModelIndex object representing the index of the item in the model.

**Code Description**: The `paint` function is responsible for rendering a table item that displays a card from a deck. It takes three parameters: a QPainter pointer, a QStyleOptionViewItem reference, and a QModelIndex reference. 

The function first saves the current painter state using `painter->save()`. Then it initializes a new QStyleOptionViewItem object with the provided index using `initStyleOption(&options, index)`. A QRect is created to represent the item's rectangle.

A gray brush is used to fill the entire item rectangle. The function then retrieves a float value from a 2D grid at specified coordinates using `boardSelectorTableModel->getBoardAt(index.row(),index.column())`.

This value is used to calculate the height of the disabled area, which is filled with a yellow brush. A QTextDocument object is created and set to display HTML-formatted text for the card.

The card's text is drawn within the item rectangle using `doc.drawContents(painter, clip)`. Finally, the painter state is restored using `painter->restore()`. \\
 ## Code: 
 ```
void BoardSelectorTableDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const{

    painter->save();
    auto options = option;
    initStyleOption(&options, index);

    QRect rect(option.rect.left(), option.rect.top(),\
             option.rect.width(), option.rect.height());
    QBrush brush(Qt::gray);
    painter->fillRect(rect, brush);

    float board_float = this->boardSelectorTableModel->getBoardAt(index.row(),index.column());

    float fold_prob = 1 - board_float;
    int disable_height = (int)(fold_prob * option.rect.height());
    int remain_height = option.rect.height() - disable_height;

    rect = QRect(option.rect.left(), option.rect.top() + disable_height,\
     option.rect.width(), remain_height);
    brush = QBrush(Qt::yellow);
    painter->fillRect(rect, brush);

    QTextDocument doc;
    doc.setHtml(Card(options.text.toStdString()).toFormattedHtml());

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
    painter->restore();
}
```