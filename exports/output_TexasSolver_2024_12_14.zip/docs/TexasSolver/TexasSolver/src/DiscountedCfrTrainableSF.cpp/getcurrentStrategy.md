`getcurrentStrategy`: The function of `getcurrentStrategy` is to retrieve the current strategy without using cache.

**Code Description**: This method, `getcurrentStrategy`, simply calls another method named `getcurrentStrategyNoCache` and returns its result. The actual calculation of the current strategy is performed by the `getcurrentStrategyNoCache` method, which sums up r_plus values for each private ID, normalizes them to obtain the strategy values, and returns these values as a vector of floats. \\
 ## Code: 
 ```
const vector<float> DiscountedCfrTrainableSF::getcurrentStrategy() {
    return this->getcurrentStrategyNoCache();
}
```