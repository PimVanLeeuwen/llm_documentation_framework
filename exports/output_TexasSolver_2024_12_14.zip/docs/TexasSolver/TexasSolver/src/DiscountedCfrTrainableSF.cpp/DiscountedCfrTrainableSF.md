`DiscountedCfrTrainableSF`: The function of `DiscountedCfrTrainableSF` is to initialize the object's properties for training a discounted CFR (Counterfactual Regret Minimization) algorithm.

**Parameters**:
`vector<PrivateCards> *privateCards`: This parameter represents a pointer to a vector of private cards, which are the cards held by each player in the game.
`ActionNode &actionNode`: This parameter is a reference to an ActionNode object, which represents a node in the game tree.

**Code Description**: The `DiscountedCfrTrainableSF` constructor initializes several member variables:
- It sets up the `privateCards` and `action_node` member variables by copying the input parameters.
- It calculates the number of actions (`action_number`) and cards (`card_number`) based on the input parameters.
- It creates vectors to store the expected values (`evs`), R+ values (`r_plus`), and cumulative R+ values (`cum_r_plus`) with dimensions equal to the product of `action_number` and `card_number`. The initial values in these vectors are set to 0.0.

This constructor is used to initialize the object's properties for training a discounted CFR algorithm, which is a popular method for solving large-scale imperfect information games like Texas Hold'em. \\
 ## Code: 
 ```
DiscountedCfrTrainableSF::DiscountedCfrTrainableSF(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();
    this->evs = vector<EvsStorage>(this->action_number * this->card_number, (EvsStorage) 0.0);
    this->r_plus = vector<RplusStorage>(this->action_number * this->card_number, (RplusStorage) 0.0);
    this->cum_r_plus = vector<CumRplusStorage>(this->action_number * this->card_number, (CumRplusStorage) 0.0);
}
```