`getAverageStrategy`: The function of `getAverageStrategy` is to calculate the average strategy for a given set of actions and cards.

**Code Description**: 
The `getAverageStrategy` method calculates the average strategy by iterating over each private card and action combination. For each combination, it sums up the cumulative regret plus values (`cum_r_plus`) across all actions. It then divides the cumulative regret plus value for each action by this sum to obtain the average strategy probability. If the sum is zero, it assigns a uniform distribution (1.0 / `action_number`) to each action. The method returns a vector of these calculated probabilities, representing the average strategy. \\
 ## Code: 
 ```
const vector<float> DiscountedCfrTrainableSF::getAverageStrategy() {
    vector<float> average_strategy;
    average_strategy = vector<float>(this->action_number * this->card_number);
    for (int private_id = 0; private_id < this->card_number; private_id++) {
        float r_plus_sum = 0;
        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            r_plus_sum += this->cum_r_plus[index];
        }

        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            if(r_plus_sum) {
                average_strategy[index] = this->cum_r_plus[index] / r_plus_sum;
            }else{
                average_strategy[index] = 1.0 / this->action_number;
            }
        }
    }
    return average_strategy;
}
```