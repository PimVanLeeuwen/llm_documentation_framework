`PrivateCards`: The function of `PrivateCards` is to initialize a private cards object with two card values and a weight.

**Parameters**:
`int card1`: The value of the first card.
`int card2`: The value of the second card.
`float weight`: The weight associated with these two cards.

**Code Description**: 
The `PrivateCards` constructor initializes an object to represent two private cards in a poker game. It takes three parameters: `card1`, `card2`, and `weight`. 

- It sets the values of `this->card1` and `this->card2` to the input `card1` and `card2`, respectively.
- The `weight` parameter is stored as `this->weight`.
- A vector `card_vec` containing both card values is created.
- If `card1` is greater than `card2`, it calculates a hash code by multiplying `card1` by 52 (the number of cards in the deck) and adding `card2`. Otherwise, it does the same but with `card2` being multiplied by 52. This hash code is stored as `this->hash_code`.
- Finally, it calls the `boardInts2long` method from the `Card` class to convert the `card_vec` into a single 64-bit unsigned integer, which is stored as `this->board_long`. \\
 ## Code: 
 ```
PrivateCards::PrivateCards(int card1, int card2, float weight) {
    this->card1 = card1;
    this->card2 = card2;
    this->weight = weight;
    this->relative_prob = 0;
    this->card_vec = vector<int>{this->card1,this->card2};
    if (card1 > card2){
        this->hash_code = card1 * 52 + card2;
    }else{
        this->hash_code = card2 * 52 + card1;
    }
    this->board_long = Card::boardInts2long(this->card_vec);
}
```