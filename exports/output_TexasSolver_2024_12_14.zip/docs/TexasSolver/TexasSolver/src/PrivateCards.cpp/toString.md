`toString`: The function of `toString` is to return a string representation of two private cards in the TexasSolver, with the cards ordered alphabetically.

**Code Description**: 
The `toString` method in the `PrivateCards` class takes no arguments and returns a string. It first checks if the card1 value is greater than card2 value. If true, it calls the `intCard2Str` method from the `Card` class twice, once for each card, but with the cards ordered alphabetically (card1 being the lower rank). The returned strings are then concatenated and returned as the result of the `toString` method. If false, it does the same but with the cards in reverse order (card2 being the lower rank). This ensures that the output string always represents the two private cards in alphabetical order. \\
 ## Code: 
 ```
string PrivateCards::toString() {
    if (card1 > card2) {
        return Card::intCard2Str(card1) + Card::intCard2Str(card2);
    }else{
        return Card::intCard2Str(card2) + Card::intCard2Str(card1);
    }
}
```