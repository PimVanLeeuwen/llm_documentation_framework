The `toBoardLong` method returns a 64-bit unsigned integer representing the private cards' state.
This method directly accesses and returns the pre-computed `board_long` value stored in the object.