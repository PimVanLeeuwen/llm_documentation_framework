The `toString` method in the `PrivateCards` class returns a string representation of two private cards, sorted in ascending order.

This method calls the `intCard2Str` method from the `Card` class to convert each card's integer value to its corresponding string representation.