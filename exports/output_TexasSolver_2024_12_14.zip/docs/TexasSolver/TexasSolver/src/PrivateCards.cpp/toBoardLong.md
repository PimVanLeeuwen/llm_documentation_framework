**toBoardLong**: The function of `toBoardLong` is to return the board long value.

**Code Description**: 
The `toBoardLong` method in the `PrivateCards` class returns the current state of the board as a 64-bit unsigned integer. This value represents the combination of cards on the board, likely used for tracking or comparison purposes within the TexasSolver project. The method directly accesses and returns the `board_long` member variable, indicating that this value is already computed and stored within the object. \\
 ## Code: 
 ```
uint64_t PrivateCards::toBoardLong() {
    return this->board_long;
    //return Card::boardInts2long(this->card_vec);
}
```