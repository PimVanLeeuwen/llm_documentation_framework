`StreetSetting`: The function of `StreetSetting` is to initialize a Street Setting object with specified betting, raising, and donking sizes, as well as an all-in flag.

**Parameters**:
`vector<float> bet_sizes`: A vector of floating-point numbers representing the different betting sizes.
`vector<float> raise_sizes`: A vector of floating-point numbers representing the different raising sizes.
`vector<float> donk_sizes`: A vector of floating-point numbers representing the different donking sizes.
`bool allin`: A boolean flag indicating whether the street setting is all-in or not.

**Code Description**: The `StreetSetting` method initializes a Street Setting object by assigning the provided vectors and boolean value to its corresponding member variables. This allows for the creation of a Street Setting object with customized betting, raising, and donking sizes, as well as an all-in flag. \\
 ## Code: 
 ```
StreetSetting::StreetSetting(vector<float> bet_sizes, vector<float> raise_sizes, vector<float> donk_sizes,
                             bool allin) {
    this->bet_sizes = bet_sizes;
    this->raise_sizes = raise_sizes;
    this->donk_sizes = donk_sizes;
    this->allin = allin;
}
```