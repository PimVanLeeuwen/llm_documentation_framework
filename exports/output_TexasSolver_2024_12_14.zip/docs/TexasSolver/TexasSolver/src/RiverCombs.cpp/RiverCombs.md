`RiverCombs`: The function of `RiverCombs` is to initialize an object with a given board, private cards, rank, and reach probability index.

**Parameters**:
- `vector<int> board`: A vector representing the current state of the game board.
- `PrivateCards private_cards`: An object containing information about the player's private cards.
- `int rank`: The current rank or position in the game.
- `int reach_prob_index`: The index corresponding to the reach probability.

**Code Description**: 
The `RiverCombs` method is a constructor for an object of the same name. It takes four parameters: `board`, `private_cards`, `rank`, and `reach_prob_index`. These parameters are assigned directly to member variables within the class, effectively initializing the object with the provided values. This allows for easy creation of objects that can be used throughout the program with a specific set of characteristics. \\
 ## Code: 
 ```
RiverCombs::RiverCombs(vector<int> board, PrivateCards private_cards, int rank, int reach_prob_index) {
    this->board = board;
    this->rank = rank;
    this->private_cards = private_cards;
    this->reach_prob_index = reach_prob_index;
}
```