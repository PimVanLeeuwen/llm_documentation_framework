`startWorking`: The function of `startWorking` is to continuously read input from the standard input and process each line as a command.

**Code Description**: 
The `startWorking` method in the `CommandLineTool` class is responsible for reading user input and processing it as commands. It uses a loop that continues until the end of the input is reached (indicated by the `cin` object). Within this loop, it reads each line from the standard input using `getline(cin, input_line)`, and then calls the `processCommand(input_line)` method to process the command. This allows the program to continuously accept and execute commands until it is terminated. \\
 ## Code: 
 ```
void CommandLineTool::startWorking() {
    string input_line;
    while(cin) {
        getline(cin, input_line);
        this->processCommand(input_line);
    };
}
```