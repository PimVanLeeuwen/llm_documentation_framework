`split`: The function of `split` is to split a given input string into substrings based on a specified delimiter character and store the resulting substrings in a vector.

**Parameters**:

`const string& s`: This parameter represents the input string that needs to be split. It is a constant reference to a string, which means it can be any valid string value.

`char c`: This parameter specifies the delimiter character based on which the input string will be split. For example, if `c` is a comma (`,`), the function will split the input string at each occurrence of a comma.

`vector<string>& v`: This parameter represents the vector where the resulting substrings will be stored. It is a reference to a vector of strings, which means it can modify the original vector.

**Code Description**: The `split` function uses a while loop to find all occurrences of the delimiter character in the input string. For each occurrence, it extracts the substring between the current and next delimiter characters using the `substr` method, and adds this substring to the vector. If there are any remaining characters at the end of the string (i.e., after the last delimiter), these characters are also added as a separate substring to the vector. The function continues this process until all occurrences of the delimiter have been found, resulting in a vector containing all substrings split from the original input string. \\
 ## Code: 
 ```
void split(const string& s, char c,
           vector<string>& v) {
    string::size_type i = 0;
    string::size_type j = s.find(c);

    while (j != string::npos) {
        v.push_back(s.substr(i, j-i));
        i = ++j;
        j = s.find(c, j);

        if (j == string::npos)
            v.push_back(s.substr(i, s.length()));
    }
}
```