The `execFromFile` method reads commands from a specified file and processes each line as a separate command.
It uses the `processCommand` method to execute each command read from the file.