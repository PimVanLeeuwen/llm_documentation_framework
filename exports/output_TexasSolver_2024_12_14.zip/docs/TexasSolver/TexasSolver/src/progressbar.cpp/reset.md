`reset`: The function of `reset` is to reset the progress bar's state to its initial condition, effectively restarting the progress tracking process.

**Code Description**: 
The `reset` method resets the progress bar's internal variables to their default values. It sets the `progress` variable to 0, indicating that no progress has been made yet. The `update_is_called` flag is also reset to false, suggesting that the progress bar has not been updated since its last call. Additionally, the `last_perc` variable is set to 0, which likely represents the last percentage value displayed on the progress bar. This method returns immediately after resetting these variables, allowing the progress bar to be reused for a new task or process. \\
 ## Code: 
 ```
void progressbar::reset() {
    progress = 0,
            update_is_called = false;
    last_perc = 0;
    return;
}
```