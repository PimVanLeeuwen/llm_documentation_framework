`progressbar`: The function of `progressbar` is to initialize a progress bar object with the specified number of cycles and display option.

**Parameters**:
`int n`: This parameter specifies the total number of cycles for the progress bar.
`bool showbar`: This boolean parameter determines whether the progress bar should be displayed or not.

**Code Description**: The `progressbar` constructor initializes an instance of the `progressbar` class with the specified parameters. It sets up internal variables to track the current progress, total cycles, and display settings. The constructor also initializes character strings for displaying completed and pending tasks within the progress bar. \\
 ## Code: 
 ```
progressbar::progressbar(int n, bool showbar) :
        progress(0),
        n_cycles(n),
        last_perc(0),
        do_show_bar(showbar),
        update_is_called(false),
        done_char("#"),
        todo_char(" "),
        opening_bracket_char("["),
        closing_bracket_char("]") {}
```