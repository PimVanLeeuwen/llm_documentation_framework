`set_niter`: The function of `set_niter` is to set the number of iterations for a progress bar.

**Parameters**:
`int niter`: The number of iterations to be performed, which must be a positive integer.

**Code Description**:
The `set_niter` method sets the value of `n_cycles` to the specified number of iterations (`niter`). It checks if `niter` is less than or equal to 0 and throws an `invalid_argument` exception if true. If `niter` is a positive integer, it assigns the value to `n_cycles`. The method then returns without any further action. \\
 ## Code: 
 ```
void progressbar::set_niter(int niter) {
    if (niter <= 0) throw std::invalid_argument(
                "progressbar::set_niter: number of iterations null or negative");
    n_cycles = niter;
    return;
}
```