`ChanceNode`: The function of `ChanceNode` is to create a new node in the game tree that represents a chance event, such as drawing cards or resolving a random outcome.

**Parameters**:

`const shared_ptr<GameTreeNode> children`: A pointer to the child nodes of this chance node, representing the possible outcomes of the chance event.

`GameTreeNode::GameRound round`: The current game round being played, indicating the stage at which the chance event occurs.

`double pot`: The current pot value, representing the stakes involved in the game.

`shared_ptr<GameTreeNode> parent`: A pointer to the parent node of this chance node, linking it to the previous decision or action in the game tree.

`const vector<Card>& cards`: A reference to a vector of cards that have been drawn or are relevant to the chance event, providing context for the outcome.

`bool donk`: A boolean flag indicating whether the chance event is a "donk" (a specific type of action or decision), which may affect the game's progression or outcome.

**Code Description**: The `ChanceNode` constructor initializes a new node in the game tree by setting its properties based on the provided parameters. It takes ownership of the child nodes, parent node, and card vector, and stores them as member variables. The `donk` flag is also stored as a member variable to indicate whether this chance event is a donk or not. This constructor is used to create new nodes in the game tree that represent chance events, allowing the game to progress through random outcomes or uncertain situations. \\
 ## Code: 
 ```
ChanceNode::ChanceNode(const shared_ptr<GameTreeNode> children, GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent,
                       const vector<Card>& cards,bool donk): GameTreeNode(round,pot,std::move(parent)),cards(cards) {
    this->children = children;
    this->donk = donk;
}
```