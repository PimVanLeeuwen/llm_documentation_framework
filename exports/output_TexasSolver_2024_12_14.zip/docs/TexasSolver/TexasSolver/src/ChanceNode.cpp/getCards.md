`getCards`: The function of `getCards` is to return a reference to the vector of cards associated with this ChanceNode object.

**Code Description**: 
The `getCards` method is a simple getter function that returns a constant reference to the internal vector of cards (`this->cards`) stored in the ChanceNode object. This allows other parts of the program to access and utilize the cards without modifying them, as indicated by the `const` keyword. The method does not take any parameters and its sole purpose is to provide read-only access to the cards collection. \\
 ## Code: 
 ```
const vector<Card>& ChanceNode::getCards() {
    return this->cards;
}
```