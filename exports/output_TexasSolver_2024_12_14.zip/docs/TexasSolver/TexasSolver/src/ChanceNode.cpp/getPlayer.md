`getPlayer`: The function of `getPlayer` is to return the current player associated with the ChanceNode object.

**Code Description**: 
The `getPlayer` method in the `ChanceNode` class returns an integer value representing the player currently associated with the node. This method simply retrieves and returns the `player` attribute stored within the `ChanceNode` object, indicating which player is involved in the current game state or scenario being represented by this node. \\
 ## Code: 
 ```
int ChanceNode::getPlayer() {
    return this->player;
}
```