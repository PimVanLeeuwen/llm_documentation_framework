The `getCards` method returns a reference to a vector of `Card` objects stored in the `ChanceNode` object.
This method provides access to the collection of cards associated with the node.