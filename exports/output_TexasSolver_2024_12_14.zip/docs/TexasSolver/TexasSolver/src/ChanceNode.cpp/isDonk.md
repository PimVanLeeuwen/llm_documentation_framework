`isDonk`: The function of `isDonk` is to check if the current chance node represents a "donk" situation.

**Code Description**: 
The `isDonk` method in the `ChanceNode` class returns a boolean value indicating whether the current chance node is a donk. A donk occurs when a player checks (or bets) after their opponent has checked, typically in a bluffing or trapping strategy. The method simply returns the value of the `donk` member variable, which suggests that this information is stored and managed elsewhere within the class. \\
 ## Code: 
 ```
bool ChanceNode::isDonk(){
    return this->donk;
}
```