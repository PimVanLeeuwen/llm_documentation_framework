`getType`: The function of `getType` is to return the type of a ChanceNode in the TexasSolver game tree.

**Code Description**: 
The `getType` method is a part of the `ChanceNode` class within the TexasSolver project. It is used to determine and identify the specific type of node it represents, which in this case is a CHANCE node. The method simply returns the predefined value `CHANCE`, indicating that the current node is a chance node. This information can be crucial for the game tree's traversal and decision-making processes. \\
 ## Code: 
 ```
GameTreeNode::GameTreeNodeType ChanceNode::getType() {
    return CHANCE;
}
```