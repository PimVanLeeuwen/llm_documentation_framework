`updateRegrets`: The function of `updateRegrets` is to update the regrets and cumulative regrets values based on the provided regrets, iteration number, and reach probabilities.

**Parameters**:

`const vector<float>& regrets`: A vector of float values representing the regrets for each action and private card combination.

`int iteration_number`: An integer value indicating the current iteration number.

`const vector<float>& reach_probs`: A vector of float values representing the reach probabilities for each action and private card combination.

**Code Description**: The `updateRegrets` function updates the regrets and cumulative regrets values by iterating over the provided regrets, reach probabilities, and iteration number. It first checks if the length of the regrets vector matches the expected size (action_number * card_number), throwing an error if it does not match. Then, it initializes the r_plus_sum and cum_r_plus_sum arrays to zero using the `fill` function from the C++ Standard Library.

The function then iterates over each action and private card combination, updating the regrets and cumulative regrets values based on the provided regrets and reach probabilities. For each combination, it calculates the new regrets value by taking the maximum of the current regrets value and the sum of the current regrets value and the previous regrets value (one_reg + this->r_plus[index]). It then updates the r_plus_sum array with the new regrets value for the corresponding private card.

Finally, the function updates the cumulative regrets values by multiplying the new regrets value by the iteration number and adding it to the cumulative regrets value. The updated cumulative regrets value is stored in the cum_r_plus array, and the sum of the cumulative regrets values for each private card is stored in the cum_r_plus_sum array. \\
 ## Code: 
 ```
void CfrPlusTrainable::updateRegrets(const vector<float>& regrets, int iteration_number, const vector<float>& reach_probs) {
    this->regrets = regrets;
    if(regrets.size() != this->action_number * this->card_number) throw runtime_error("length not match");

    //Arrays.fill(this.r_plus_sum,0);
    fill(r_plus_sum.begin(),r_plus_sum.end(),0);
    fill(cum_r_plus_sum.begin(),cum_r_plus_sum.end(),0);
    for (int action_id = 0;action_id < action_number;action_id ++) {
        for(int private_id = 0;private_id < this->card_number;private_id ++){
            int index = action_id * this->card_number + private_id;
            float one_reg = regrets[index];

            // 更新 R+
            this->r_plus[index] = max((float)0.0,one_reg + this->r_plus[index]);
            this->r_plus_sum[private_id] += this->r_plus[index];

            // 更新累计策略
            this->cum_r_plus[index] += this->r_plus[index] * iteration_number;
            this->cum_r_plus_sum[private_id] += this->cum_r_plus[index];
        }
    }
}
```