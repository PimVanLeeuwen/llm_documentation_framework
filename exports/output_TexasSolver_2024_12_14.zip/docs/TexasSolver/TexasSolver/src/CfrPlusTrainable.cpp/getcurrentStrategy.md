`getcurrentStrategy`: The function of `getcurrentStrategy` is to return the current strategy vector, which represents the probability distribution over all possible actions.

**Code Description**: 
The `getcurrentStrategy` method returns a vector of floats representing the current strategy. It first checks if the `r_plus_sum` vector is empty. If it is, it initializes the `retval` vector with equal probabilities for each action (1.0 / action_number). Otherwise, it iterates over all possible actions and private card combinations, calculating the probability for each combination based on the values in `r_plus` and `r_plus_sum`. The calculated probabilities are stored in the `retval` vector. If a NaN value is encountered during calculation, an exception is thrown. Finally, the `retval` vector is returned as the current strategy. \\
 ## Code: 
 ```
const vector<float> CfrPlusTrainable::getcurrentStrategy() {
    if(this->r_plus_sum.empty()){
        fill(retval.begin(),retval.end(),1.0 / this->action_number);
    }else {
        for (int action_id = 0; action_id < action_number; action_id++) {
            for (int private_id = 0; private_id < this->card_number; private_id++) {
                int index = action_id * this->card_number + private_id;
                if(this->r_plus_sum[private_id] != 0) {
                    retval[index] = this->r_plus[index] / this->r_plus_sum[private_id];
                }else{
                    retval[index] = 1.0 / this->action_number;
                }
                if(this->r_plus[index] != this->r_plus[index]) throw runtime_error("nan found");
                /*
                if(this.r_plus_sum[private_id] == 0)
                {
                    System.out.println("Exception regret status, r_plus_sum == 0:");
                    System.out.println(String.format("r plus length %s , card num %s",r_plus.length,this.card_number));
                    for(int i = index % this.card_number;i < this.r_plus.length;i += this.card_number){
                        System.out.print(String.format("%s:%s ",i,this.r_plus[i]));
                        if(i == index){
                            System.out.print("[current]");
                        }
                    }
                    System.out.println();
                    System.out.println();
                    throw new RuntimeException();
                }
                 */
            }
        }
    }
    return retval;
}
```