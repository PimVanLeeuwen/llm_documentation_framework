`CfrPlusTrainable`: The function of `CfrPlusTrainable` is to initialize the object's internal data structures for a CFR+ (Counterfactual Regret Minimization) algorithm.

**Parameters**:
`shared_ptr<ActionNode> action_node`: A shared pointer to an ActionNode object, which represents the current state of the game.
`vector<PrivateCards> privateCards`: A vector of PrivateCards objects, representing the player's private cards.

**Code Description**: The `CfrPlusTrainable` constructor initializes several internal data structures:
- It sets up vectors (`r_plus`, `cum_r_plus`, and `retval`) to store values with a size equal to the product of the number of actions and card numbers.
- It also initializes two more vectors (`r_plus_sum` and `cum_r_plus_sum`) with a size equal to the number of card numbers.
- The constructor populates these vectors with default values, likely zeros or other initial values specific to the CFR+ algorithm.

The provided code snippet calls the `getChildrens` method from the `ActionNode` class, which returns a reference to a vector of shared pointers to GameTreeNode objects. This suggests that the `CfrPlusTrainable` object is designed to work with a game tree structure, where each node represents a possible state or action in the game.

The constructor's purpose is to set up the internal data structures necessary for the CFR+ algorithm to operate on the provided game state and private cards. The specific details of how these vectors are used within the CFR+ algorithm are not shown in this code snippet. \\
 ## Code: 
 ```
CfrPlusTrainable::CfrPlusTrainable(shared_ptr<ActionNode> action_node, vector<PrivateCards> privateCards) {
    this->action_node = action_node;
    this->privateCards = privateCards;
    this->action_number = action_node->getChildrens().size();
    this->card_number = privateCards.size();

    this->r_plus = vector<float>(this->action_number * this->card_number);
    this->r_plus_sum = vector<float>(this->card_number);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number);
    this->cum_r_plus_sum = vector<float>(this->card_number);
    this->retval = vector<float>(this->action_number * this->card_number);
}
```