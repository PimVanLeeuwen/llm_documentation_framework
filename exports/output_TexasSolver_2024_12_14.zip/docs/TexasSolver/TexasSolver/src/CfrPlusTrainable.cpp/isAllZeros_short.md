This method checks if all elements in a given array are zero.
It returns true if all elements are zero, false otherwise.