`isAllZeros`: The function of `isAllZeros` is to check if all elements in the given array are zero.

**Parameters**:
`vector<float> input_array`: A vector containing a list of floating-point numbers that needs to be checked for zeros.

**Code Description**: 
The `isAllZeros` method iterates through each element in the provided `input_array`. If any element is not equal to zero, it immediately returns `false`, indicating that not all elements are zeros. If the loop completes without finding a non-zero element, the method returns `true`, signifying that all elements in the array are indeed zero. This function provides a simple and efficient way to verify if an entire array consists of zeros. \\
 ## Code: 
 ```
bool CfrPlusTrainable::isAllZeros(vector<float> input_array) {
    for(float i:input_array){
        if (i != 0)return false;
    }
    return true;
}
```