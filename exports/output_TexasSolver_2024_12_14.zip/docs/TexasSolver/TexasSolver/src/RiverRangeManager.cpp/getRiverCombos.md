`getRiverCombos`: The function of `getRiverCombos` is to retrieve a list of river combinations for a given player, board state, and preflop hand combinations.

**Parameters**:
- `int player`: The ID of the player for whom to retrieve river combinations.
- `const vector<PrivateCards> &riverCombos`: A reference to a vector of private cards used as input for retrieving river combinations.
- `const vector<int> &board`: A reference to a vector of integers representing the current state of the poker board.

**Code Description**: The `getRiverCombos` method first converts the input `board` vector into a 64-bit unsigned integer using the `Card::boardInts2long` function. It then calls itself with this converted value, passing it along with the other parameters (`player` and `riverCombos`). This approach suggests that the method uses a cache to store and retrieve river combinations efficiently, updating the cache as necessary. The actual retrieval of river combinations is handled by the recursive call to `getRiverCombos`, which takes the converted board state as an input. \\
 ## Code: 
 ```
const vector<RiverCombs> &
RiverRangeManager::getRiverCombos(int player, const vector<PrivateCards> &riverCombos, const vector<int> &board) {
    uint64_t board_long = Card::boardInts2long(board);
    return this->getRiverCombos(player,riverCombos,board_long);
}
```