`RiverRangeManager`: The function of `RiverRangeManager` is to manage the river range in a Texas Hold'em game, likely involving calculations and comparisons using a hand evaluator.

**Parameters**:
`shared_ptr<Compairer> handEvaluator`: A shared pointer to a Compairer object, which is used for evaluating hands in the game. This parameter is required for the RiverRangeManager to function properly.

**Code Description**: The `RiverRangeManager` constructor initializes two member variables: `handEvaluator` and `maplock`. It takes a shared pointer to a Compairer object as input, assigns it to the `handEvaluator` member variable using `std::move`, and creates a new shared pointer to a mutex (a synchronization primitive) using `std::make_shared<std::mutex>`. The resulting shared pointer is assigned to the `maplock` member variable. This constructor sets up the RiverRangeManager object with the necessary dependencies for its operations, specifically the hand evaluator and a lock for synchronizing access to a map or other data structure. \\
 ## Code: 
 ```
RiverRangeManager::RiverRangeManager(shared_ptr<Compairer> handEvaluator) {
    this->handEvaluator = std::move(handEvaluator);
    this->maplock = std::make_shared<std::mutex>();
}
```