`getAverageStrategy`: The function of `getAverageStrategy` is to calculate the average strategy for a given game state in Texas Hold'em.

**Code Description**: 
The `getAverageStrategy` method calculates and returns the average strategy for a given game state. It does this by iterating over all possible private cards (card_number) and actions (action_number), and then normalizing the cumulative regret sums (cum_r_plus) to obtain the average strategy probabilities. The result is a vector of floats representing the average strategy, where each element corresponds to a specific action-private card combination. \\
 ## Code: 
 ```
const vector<float> DiscountedCfrTrainableHF::getAverageStrategy() {
    vector<float> average_strategy;
    average_strategy = vector<float>(this->action_number * this->card_number);
    for (int private_id = 0; private_id < this->card_number; private_id++) {
        float r_plus_sum = 0;
        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            average_strategy[index] = this->cum_r_plus[index];
            r_plus_sum += average_strategy[index];
        }

        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            if(r_plus_sum) {
                // we stored this->cum_r_plus[index] in average_strategy[index] above
                // this is to avoid converting from half float twice
                average_strategy[index] = average_strategy[index] / r_plus_sum;
            }else{
                average_strategy[index] = 1.0 / this->action_number;
            }
        }
    }
    return average_strategy;
}
```