`copyStrategy`: The function of `copyStrategy` is to copy the strategy from another trainable object.

**Parameters**:
`shared_ptr<Trainable> other_trainable`: A shared pointer to a Trainable object, which contains the strategy to be copied.

**Code Description**: 
The `copyStrategy` method takes a shared pointer to a Trainable object as input and copies its strategy into the current object. It uses dynamic casting to ensure that the input object is of type DiscountedCfrTrainableHF, and then assigns the r_plus and cum_r_plus vectors from the other_trainable object to the corresponding vectors in the current object. This allows for the sharing of strategies between different trainable objects, enabling efficient training and updating of the strategy. \\
 ## Code: 
 ```
void DiscountedCfrTrainableHF::copyStrategy(shared_ptr<Trainable> other_trainable){
    shared_ptr<DiscountedCfrTrainableHF> trainable = dynamic_pointer_cast<DiscountedCfrTrainableHF>(other_trainable);
    this->r_plus.assign(trainable->r_plus.begin(),trainable->r_plus.end());
    this->cum_r_plus.assign(trainable->cum_r_plus.begin(),trainable->cum_r_plus.end());
}
```