`getcurrentStrategyNoCache`: The function of `getcurrentStrategyNoCache` is to calculate and return the current strategy without using any cache.

**Code Description**: This method calculates the current strategy by iterating over all possible actions and private IDs, computing the maximum value for each index in the r_plus array, and then normalizing these values based on the sum of maximum values for each private ID. The result is a vector of floats representing the current strategy, where each element corresponds to an action-private ID combination. \\
 ## Code: 
 ```
const vector<float> DiscountedCfrTrainableHF::getcurrentStrategyNoCache() {
    vector<float> current_strategy;
    current_strategy = vector<float>(this->action_number * this->card_number);
    // calculate r_plus_sum on the fly, store r_plus as floats locally
    vector<float> r_plus_sum = vector<float>(this->r_plus.size());
    vector<float> r_plus = vector<float>(this->r_plus.size());
    fill(r_plus_sum.begin(),r_plus_sum.end(),0);
    for (int action_id = 0;action_id < action_number;action_id ++) {
        for(int private_id = 0;private_id < this->card_number;private_id ++){
            int index = action_id * this->card_number + private_id;
            float this_r_plus_of_index = this->r_plus[index];
            r_plus_sum[private_id] += max(float(0.0),this_r_plus_of_index);
            r_plus[index] = this_r_plus_of_index;
        }
    }

    for (int action_id = 0; action_id < action_number; action_id++) {
        for (int private_id = 0; private_id < this->card_number; private_id++) {
            int index = action_id * this->card_number + private_id;
            if(r_plus_sum[private_id] != 0) {
                current_strategy[index] = max(float(0.0),r_plus[index]) / r_plus_sum[private_id];
            }else{
                current_strategy[index] = 1.0 / (this->action_number);
            }
#ifdef DEBUG
            if(this->r_plus[index] != this->r_plus[index]) throw runtime_error("nan found");
#endif
        }
    }
```