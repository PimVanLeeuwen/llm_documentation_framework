`isAllZeros`: The function of `isAllZeros` is to check if all elements in the given array are zero.

**Parameters**:
`const vector<float>& input_array`: A reference to a vector containing floating-point numbers, which will be checked for zeros.

**Code Description**: 
The `isAllZeros` method iterates through each element in the provided `input_array`. If any element is not equal to zero (`i != 0`), it immediately returns `false`, indicating that not all elements are zero. If the loop completes without finding a non-zero element, the method returns `true`, signifying that all elements in the array are indeed zero. This approach ensures efficient checking of the entire array for zeros by stopping as soon as a non-zero value is encountered. \\
 ## Code: 
 ```
bool DiscountedCfrTrainableHF::isAllZeros(const vector<float>& input_array) {
    for(float i:input_array){
        if (i != 0)return false;
    }
    return true;
}
```