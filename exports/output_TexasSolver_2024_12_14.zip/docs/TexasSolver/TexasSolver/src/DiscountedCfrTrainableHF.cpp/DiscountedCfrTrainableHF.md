`DiscountedCfrTrainableHF`: The function of `DiscountedCfrTrainableHF` is to initialize the object's properties for training a discounted CFR (Counterfactual Regret Minimization) algorithm.

**Parameters**:
`vector<PrivateCards> *privateCards`: A pointer to a vector of private cards, which represents the hidden information of each player.
`ActionNode &actionNode`: A reference to an ActionNode object, which contains information about the current game state and possible actions.

**Code Description**: The `DiscountedCfrTrainableHF` constructor initializes several member variables:
- It sets up the `privateCards` vector from the input parameter.
- It retrieves the number of children nodes from the `actionNode` and stores it in `action_number`.
- It retrieves the number of private cards from the input parameter and stores it in `card_number`.
- It creates vectors to store the expected values (`evs`), R+ values (`r_plus`), and cumulative R+ values (`cum_r_plus`) for each possible action and card combination, with sizes determined by `action_number` and `card_number`. The initial values of these vectors are set to 0.0.

This constructor sets up the necessary data structures for training a discounted CFR algorithm, which is used in game theory to compute optimal strategies for players. \\
 ## Code: 
 ```
DiscountedCfrTrainableHF::DiscountedCfrTrainableHF(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();
    this->evs = vector<EvsStorage>(this->action_number * this->card_number, (EvsStorage) 0.0);
    this->r_plus = vector<RplusStorage>(this->action_number * this->card_number, (RplusStorage) 0.0);
    this->cum_r_plus = vector<CumRplusStorage>(this->action_number * this->card_number, (CumRplusStorage) 0.0);
}
```