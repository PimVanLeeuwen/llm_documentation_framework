This method retrieves a specific value from a 2D grid based on its indices.
It checks for valid index ranges before returning the corresponding float value.