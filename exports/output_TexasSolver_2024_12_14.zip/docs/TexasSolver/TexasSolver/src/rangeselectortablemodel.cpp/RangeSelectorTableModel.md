`RangeSelectorTableModel`: The function of `RangeSelectorTableModel` is to initialize and configure a table model for range selection, handling rank list data and grid updates.

**Parameters**:
`QStringList ranks`: A list of string values representing the rank list.
`QString initial_board`: An input string specifying the initial board configuration.
`QObject *parent`: The parent object for the table model (optional).
`bool thumbnail`: A boolean flag indicating whether to display a thumbnail or not.

**Code Description**: 
The `RangeSelectorTableModel` constructor initializes the table model by setting up internal data structures and calling other methods to populate them. It takes four parameters: `ranks`, `initial_board`, `parent`, and `thumbnail`. The constructor first sets up the rank list and grid data structures, then calls the `setRangeText` method to parse the input string and update the grid accordingly. This process involves creating a 2D grid of float values and populating it with the specified range values. The `get_ij_text` method is used to generate formatted strings representing the rank list values at specific positions. \\
 ## Code: 
 ```
RangeSelectorTableModel::RangeSelectorTableModel(QStringList ranks,QString initial_board,QObject *parent,bool thumbnail):QAbstractItemModel(parent){
    this->ranklist = ranks;
    this->thumbnail = thumbnail;

    this->grids_string = vector<vector<QString>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_string[i] = vector<QString>(this->ranklist.size());
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_string[i][j] = this->get_ij_text(i,j);
            this->string2ij[this->get_ij_text(i,j)] = pair<int,int>(i,j);
        }
    }

    this->grids_float = vector<vector<float>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_float[i] = vector<float>(this->ranklist.size(),0.0);
    }
    this->setRangeText(initial_board);
}
```