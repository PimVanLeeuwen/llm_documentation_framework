`getRangeText`: The function of `getRangeText` is to generate a string representation of the ranges in the grid, where each range is defined by its minimum and maximum values.

**Code Description**: 
The `getRangeText` method iterates through a 2D array (`grids_float`) representing a grid of floating-point numbers. For each cell in the grid that contains a non-zero value, it constructs a string representation of the range as "minimum_value:maximum_value" (e.g., "1.000:3.000"). The method then concatenates these strings with commas to form a single string containing all the ranges. If no ranges are found, an empty string is returned. \\
 ## Code: 
 ```
QString RangeSelectorTableModel::getRangeText(){
    QString retval = "";
    for(int i = 0;i < this->ranklist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            if(this->grids_float[i][j] == 0)continue;
            QString one_range_str = QString("%1:%2").arg(this->grids_string[i][j],QString::number(this->grids_float[i][j],'f',3));
            if(retval == ""){
                retval = one_range_str;
            }else{
                retval = retval + "," + one_range_str;
            }
        }
    }
    return retval;
}
```