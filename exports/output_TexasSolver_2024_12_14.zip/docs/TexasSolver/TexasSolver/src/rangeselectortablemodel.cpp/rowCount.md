`rowCount`: The function of `rowCount` is to return the total number of rows in the table model.

**Parameters**:
`const QModelIndex &parent`: This parameter represents the parent index, which is used to determine the scope of the row count. It can be an empty model or a specific section within the model.

**Code Description**: The `rowCount` function returns the size of the `ranklist` vector, indicating the total number of rows in the table model. This suggests that the `ranklist` vector contains all the data for the rows in the table, and its size is used to determine the row count. \\
 ## Code: 
 ```
int RangeSelectorTableModel::rowCount(const QModelIndex &parent) const {
    return this->ranklist.size();
}
```