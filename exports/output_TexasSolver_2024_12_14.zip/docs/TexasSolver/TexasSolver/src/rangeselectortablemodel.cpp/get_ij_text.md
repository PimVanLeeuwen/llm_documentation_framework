`get_ij_text`: The function of `get_ij_text` is to generate a string representation of the ranklist values at positions `i` and `j`, with an "o" or "s" character indicating whether `i` is greater than, less than, or equal to `j`.

**Parameters**:
`int i`: The row index.
`int j`: The column index.

**Code Description**: 
The `get_ij_text` function takes two integer parameters, `i` and `j`, representing the row and column indices respectively. It calculates the larger and smaller values between `i` and `j`, then uses these values to retrieve the corresponding ranklist values from the `ranklist` array. The retrieved values are concatenated with an "o" or "s" character, depending on whether `i` is greater than, less than, or equal to `j`. The resulting string is returned as the output of the function. \\
 ## Code: 
 ```
QString RangeSelectorTableModel::get_ij_text(int i,int j){
    int row = i;
    int col = j;
    int larger = row > col?row:col;
    int smaller = row > col?col:row;
    QString  retval = QString("%1%2%3")\
            .arg(QString(this->ranklist[smaller]))\
            .arg(QString(this->ranklist[larger]));
    if(row > col){
        retval = retval.arg("o");
    }else if(row < col){
        retval = retval.arg("s");
    }else{
        retval = retval.arg("");
    }
    return retval;
}
```