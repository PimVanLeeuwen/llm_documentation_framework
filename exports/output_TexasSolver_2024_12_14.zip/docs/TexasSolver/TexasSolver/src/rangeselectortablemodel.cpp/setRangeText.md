`setRangeText`: The function of `setRangeText` is to set the text range for a grid data structure.

**Parameters**:
`QString input_range`: A string containing comma-separated ranges in the format "key1:value1,key2:value2", where key is a column name and value is a float number representing the range value.

**Code Description**: 
The `setRangeText` function takes an input string of comma-separated ranges, splits it into individual ranges using the `split` method, and then iterates over each range. For each range, it checks if the format is correct (i.e., it contains a key and a value separated by a colon). If the format is incorrect, it prints an error message and skips that range.

If the format is correct, it extracts the key and value from the range string, converts the key to its corresponding integer coordinates using the `string2ij` map, and then sets the grid value at those coordinates to the specified range value. If the range has a value part (i.e., it's not just a key), it uses that value; otherwise, it defaults to 1.0.

The function also clears any existing ranges in the grid data structure before setting new ones using the `clear_range` method. \\
 ## Code: 
 ```
void RangeSelectorTableModel::setRangeText(QString input_range){
    this->clear_range();
    for(QString one_range:input_range.split(",")){
        if(one_range.trimmed() == "")continue;
        QStringList one_range_list = one_range.split(":");

        if(one_range_list.size() > 2 || one_range_list.size() < 1){
            qDebug().noquote() << QString(tr("skipping range %1, format error, range list should contain two part seperate by ':'")).arg(one_range);
        }

        float range_float = 1.0;
        QString key_range = one_range_list[0];
        QStringList keys;
        if(this->string2ij.count(one_range_list[0])){
            keys.append(key_range);
        }else{
            keys.append(key_range + "o");
            keys.append(key_range + "s");
        }

        for(QString one_key: keys){
            if(one_key.count(" ") == one_key.length() || one_key == "")continue;
            if(!this->string2ij.count(one_key)){
                qDebug().noquote() << QString(tr("skipping range %1, format error")).arg(one_range);
                continue;
            }
            pair<int,int> cord = this->string2ij[one_key];
            if(one_range_list.size() > 1)range_float = one_range_list[1].toFloat();
            this->grids_float[cord.first][cord.second] = range_float;
        }
    }
}
```