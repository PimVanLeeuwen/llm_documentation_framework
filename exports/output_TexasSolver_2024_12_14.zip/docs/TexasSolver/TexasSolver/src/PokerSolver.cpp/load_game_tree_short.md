The `load_game_tree` method loads a game tree for Texas Hold'em poker from a file, initializing it based on given parameters and rules.

This method creates a shared pointer to a `GameTree` object, passing in the game tree file path and the solver's deck, then assigns this pointer to the solver's `game_tree` member variable.