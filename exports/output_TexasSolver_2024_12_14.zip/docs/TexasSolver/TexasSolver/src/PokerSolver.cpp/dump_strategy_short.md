The `dump_strategy` method saves the solver's strategy to a file in JSON format.
It takes two parameters: the file path and the number of rounds to dump.