`build_game_tree`: The function of `build_game_tree` is to construct a game tree data structure for Texas Hold'em poker, representing possible game outcomes based on given parameters and rules.

**Parameters**:

`float oop_commit`: The out-of-position commitment value, which represents the amount committed by an opponent in a hand.

`float ip_commit`: The in-position commitment value, which represents the amount committed by the player themselves in a hand.

`int current_round`: The current round number of the game, used to determine the game's progression and possible actions.

`int raise_limit`: The maximum allowed raises for a given action, ensuring that the game does not become too complex or unbalanced.

`float small_blind`: The value of the small blind, which is one of the forced bets in Texas Hold'em poker.

`float big_blind`: The value of the big blind, which is another forced bet in Texas Hold'em poker.

`float stack`: The player's current stack size, representing their available funds for betting and playing.

`GameTreeBuildingSettings buildingSettings`: A settings object containing parameters for building the game tree, such as depth limits or node pruning strategies.

`float allin_threshold`: The threshold value above which a player is considered to be "all-in," meaning they have committed their entire stack to the hand.

**Code Description**: This function creates a shared pointer to a `GameTree` object and assigns it to the `game_tree` member variable of the `PokerSolver` class. The `GameTree` constructor takes various parameters, including the deck, commitment values, current round number, raise limit, small and big blind values, stack size, building settings, and all-in threshold. This allows for the construction of a game tree data structure that can be used to analyze and simulate Texas Hold'em poker hands based on the provided parameters and rules. \\
 ## Code: 
 ```
void PokerSolver::build_game_tree(
        float oop_commit,
        float ip_commit,
        int current_round,
        int raise_limit,
        float small_blind,
        float big_blind,
        float stack,
        GameTreeBuildingSettings buildingSettings,
        float allin_threshold
){
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(
            this->deck,
            oop_commit,
            ip_commit,
            current_round,
            raise_limit,
            small_blind,
            big_blind,
            stack,
            buildingSettings,
            allin_threshold
    );
    this->game_tree = game_tree;
}
```