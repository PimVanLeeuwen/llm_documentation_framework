`load_game_tree`: The function of `load_game_tree` is to load a pre-existing game tree from a file into the PokerSolver object.

**Parameters**:
`string game_tree_file`: A string representing the path to the file containing the game tree data.

**Code Description**: 
The `load_game_tree` method initializes a shared pointer to a GameTree object using the provided file path and the current deck of cards. The loaded game tree is then assigned to the PokerSolver's game_tree member variable, effectively replacing any previously loaded game tree. This allows the PokerSolver to utilize the pre-existing game tree for decision-making purposes in Texas Hold'em poker games. \\
 ## Code: 
 ```
void PokerSolver::load_game_tree(string game_tree_file) {
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(game_tree_file,this->deck);
    this->game_tree = game_tree;
}
```