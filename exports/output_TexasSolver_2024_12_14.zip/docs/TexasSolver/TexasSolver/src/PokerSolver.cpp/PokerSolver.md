`PokerSolver`: The function of `PokerSolver` is to initialize a poker solver object.

**Parameters**:
- `string ranks`: A string containing comma-separated card ranks.
- `string suits`: A string containing comma-separated card suits.
- `string compairer_file`: A file path for the poker hand strength data comparison file.
- `int compairer_file_lines`: The number of lines in the comparison file.
- `string compairer_file_bin`: A binary file path for loading poker hand strength data.

**Code Description**: 
The `PokerSolver` constructor initializes a poker solver object by splitting input strings into vectors of ranks and suits, creating a deck of cards from these vectors, and loading poker hand strength comparison data from the specified files. It utilizes the `Deck` class to generate a deck of cards based on the provided ranks and suits, and it uses the `Dic5Compairer` class to load and process poker hand strength data for comparison purposes. The `string_split` method is used to split input strings into vectors using commas as delimiters. \\
 ## Code: 
 ```
PokerSolver::PokerSolver(string ranks, string suits, string compairer_file,int compairer_file_lines, string compairer_file_bin) {
    vector<string> ranks_vector = string_split(ranks,',');
    vector<string> suits_vector = string_split(suits,',');
    this->deck = Deck(ranks_vector,suits_vector);
    this->compairer = make_shared<Dic5Compairer>(compairer_file,compairer_file_lines,compairer_file_bin);
}
```