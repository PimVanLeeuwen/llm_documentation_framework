`noDuplicateRange`: The function of `noDuplicateRange` is to remove duplicate and non-intersecting private card ranges from a given set, based on the provided poker board.

**Parameters**:
- `const vector<PrivateCards> &private_range`: A reference to a vector of PrivateCards objects representing the set of private card ranges.
- `uint64_t board_long`: A 64-bit unsigned integer representing the poker board.

**Code Description**: 
The `noDuplicateRange` function iterates over each PrivateCards object in the provided vector. It checks for duplicates by using an unordered map to store hash codes and their corresponding boolean values, indicating whether they have been encountered before. If a duplicate is found, it throws a runtime error with a message indicating the duplicated key.

For each unique PrivateCards object, it calculates the long integer representation of its private cards using the `Card::boardInts2long` method and checks if this hand intersects with the provided board using the `Card::boardsHasIntercept` method. If there is no intersection, the PrivateCards object is added to a new vector called `range_array`.

Finally, the function returns the `range_array`, which contains the filtered set of unique and intersecting private card ranges. \\
 ## Code: 
 ```
vector<PrivateCards> noDuplicateRange(const vector<PrivateCards> &private_range, uint64_t board_long) {
    vector<PrivateCards> range_array;
    unordered_map<int,bool> rangekv;
    for(PrivateCards one_range:private_range){
        if(rangekv.find(one_range.hashCode()) != rangekv.end())
            throw runtime_error(tfm::format("duplicated key %s",one_range.toString()));
        rangekv[one_range.hashCode()] = true;
        uint64_t hand_long = Card::boardInts2long(one_range.get_hands());
        if(!Card::boardsHasIntercept(hand_long,board_long)){
            range_array.push_back(one_range);
        }
    }
    return range_array;
}
```