`get_commit`: The function of `get_commit` is to return the commit value for a given player.

**Parameters**:
`int player`: The ID of the player for whom to retrieve the commit value. It can be either 0 or 1, representing two different players.

**Code Description**: 
The `get_commit` method takes an integer `player` as input and returns a float value representing the commit for that player. If the `player` is 0, it returns the value of `ip_commit`. If the `player` is 1, it returns the value of `oop_commit`. However, if the `player` is neither 0 nor 1, it throws a runtime error with the message "unknown player". This suggests that the method is designed to handle two specific players and will fail for any other input. \\
 ## Code: 
 ```
float Rule::get_commit(int player) {
    if (player == 0) return this->ip_commit;
    else if(player == 1) return this->oop_commit;
    else throw runtime_error("unknown player");
}
```