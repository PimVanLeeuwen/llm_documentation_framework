`get_pot`: The function of `get_pot` is to calculate the total potential (pot) by adding the out-of-pocket (oop) commitment and the interest payment (ip) commitment.

**Code Description**: 
The `get_pot` method in the `Rule` class returns a float value representing the sum of two member variables: `oop_commit` and `ip_commit`. This suggests that the total potential or "pot" is determined by combining these two financial commitments. The method does not take any arguments, implying it is a simple accessor function to retrieve the calculated pot value. \\
 ## Code: 
 ```
float Rule::get_pot() {
    return this->oop_commit + this->ip_commit;
}
```