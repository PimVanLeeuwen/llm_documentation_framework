The `get_commit` method returns a float value representing a player's commitment, based on their ID.

It throws a runtime error if the provided player ID does not match any known players.