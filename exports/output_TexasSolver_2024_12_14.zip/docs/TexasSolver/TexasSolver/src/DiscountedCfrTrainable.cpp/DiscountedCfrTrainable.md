`DiscountedCfrTrainable`: The function of `DiscountedCfrTrainable` is to initialize and set up the necessary data structures for training a CFR (Counterfactual Regret Minimization) algorithm in a discounted setting.

**Parameters**:
`vector<PrivateCards> *privateCards`: A pointer to a vector of private cards, which represents the hidden information of each player.
`ActionNode &actionNode`: A reference to an ActionNode object, which represents the current state of the game tree.

**Code Description**: The `DiscountedCfrTrainable` constructor initializes several data structures:
- It sets up vectors (`evs`, `r_plus`, `r_plus_sum`, and `cum_r_plus`) with specific sizes based on the number of actions and private cards.
- These vectors are used to store values related to the CFR algorithm, such as expected values, regrets, and cumulative regrets.
- The constructor also initializes an ActionNode object (`action_node`) by taking a reference to it in the parameter list.

The `getChildrens` method is called on the `actionNode` object to retrieve its child nodes. This information is used to determine the size of the vectors initialized within this constructor, specifically the number of actions and private cards involved in the game tree. \\
 ## Code: 
 ```
DiscountedCfrTrainable::DiscountedCfrTrainable(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();

    this->evs = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus_sum = vector<float>(this->card_number,0.0);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number,0.0);
    //this->cum_r_plus_sum = vector<float>(this->card_number);
}
```