`copyStrategy`: The function of `copyStrategy` is to copy the strategy from another `DiscountedCfrTrainable` object.

**Parameters**:
`shared_ptr<Trainable> other_trainable`: A shared pointer to a `Trainable` object, which must be castable to a `DiscountedCfrTrainable` object in order for this function to work correctly.

**Code Description**: The `copyStrategy` function takes another `DiscountedCfrTrainable` object as input and copies its internal data structures (`r_plus` and `cum_r_plus`) into the current object. This is done by using a dynamic pointer cast to ensure that the input object is indeed of type `DiscountedCfrTrainable`, and then assigning the contents of the other object's vectors to the corresponding vectors in the current object. \\
 ## Code: 
 ```
void DiscountedCfrTrainable::copyStrategy(shared_ptr<Trainable> other_trainable){
    shared_ptr<DiscountedCfrTrainable> trainable = dynamic_pointer_cast<DiscountedCfrTrainable>(other_trainable);
    this->r_plus.assign(trainable->r_plus.begin(),trainable->r_plus.end());
    this->cum_r_plus.assign(trainable->cum_r_plus.begin(),trainable->cum_r_plus.end());
}
```