The `GameTreeNode` class initializes a new game tree node with specified attributes.
This constructor sets up a node in the game tree, linking it to its parent and defining its round and pot values.