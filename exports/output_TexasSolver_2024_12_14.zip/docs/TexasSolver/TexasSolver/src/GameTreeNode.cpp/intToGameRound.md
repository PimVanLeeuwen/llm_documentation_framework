Here's the completed template:

`intToGameRound`: The function of `intToGameRound` is to convert an integer game round value into a GameTreeNode::GameRound enumeration.

**Parameters**:
`int round`: An integer representing the game round, where 0 represents PREFLOP, 1 represents FLOP, 2 represents TURN, and 3 represents RIVER. If the input value does not match any of these cases, it throws a runtime error.

**Code Description**: The `intToGameRound` function uses a switch statement to map the integer game round value to its corresponding GameTreeNode::GameRound enumeration. It returns the matched GameRound value if found, and throws a runtime error with a descriptive message if the input value is not recognized. \\
 ## Code: 
 ```
GameTreeNode::GameRound GameTreeNode::intToGameRound(int round){
    GameTreeNode::GameRound game_round;
    switch(round){
        case 0:{
            game_round = GameTreeNode::GameRound::PREFLOP;
            break;
        }
        case 1:{
            game_round = GameTreeNode::GameRound::FLOP;
            break;
        }
        case 2:{
            game_round = GameTreeNode::GameRound::TURN;
            break;
        }
        case 3:{
            game_round = GameTreeNode::GameRound::RIVER;
            break;
        }
        default:{
            throw runtime_error(tfm::format("round %s not found",round));
        }
    }
    return game_round;
}
```