`GameTreeNode`: The function of `GameTreeNode` is to represent a node in the game tree, encapsulating information about the current round, pot, and its parent node.

**Parameters**:

`GameTreeNode::GameRound round`: This parameter represents the current round being played in the game, indicating the progression of the game state.

`double pot`: The `pot` parameter represents the current amount of money at stake in the game, which is a crucial aspect of the game's economics and decision-making process.

`shared_ptr<GameTreeNode> parent`: This parameter points to the parent node in the game tree, establishing a hierarchical relationship between nodes that reflects the game's progression and history.

**Code Description**: The `GameTreeNode` constructor initializes an instance of the class by setting its round, pot, and parent attributes. It takes three parameters: `round`, `pot`, and `parent`, which are assigned to the corresponding member variables using the `this->` syntax for clarity. The `std::move` function is used to transfer ownership of the `parent` node from the caller to the newly created instance, ensuring efficient memory management and avoiding unnecessary copies. This constructor provides a straightforward way to create new game tree nodes with their respective attributes, facilitating the construction of complex game trees that can be traversed and analyzed. \\
 ## Code: 
 ```
GameTreeNode::GameTreeNode(GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent) {
    this->round = round;
    this->pot = pot;
    this->parent = std::move(parent);
}
```