`getRound`: The function of `getRound` is to retrieve the current round number of a game tree node.

**Code Description**: 
The `getRound` method is a simple getter function that returns the value of the `round` member variable of the `GameTreeNode` class. It does not perform any calculations or operations, but rather directly returns the stored round number. This suggests that the `round` variable is used to keep track of the current round in a game tree, and this method provides a way to access this information from within the class. The return type is `GameRound`, indicating that the function returns an object representing the current round. \\
 ## Code: 
 ```
GameTreeNode::GameRound GameTreeNode::getRound() {
    return this->round;
}
```