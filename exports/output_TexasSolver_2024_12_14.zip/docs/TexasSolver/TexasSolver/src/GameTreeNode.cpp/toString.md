`toString`: The function of `toString` is to generate a string representation of the current game tree node, including its parent node and relevant information.

**Code Description**: 
The `toString` method in the `GameTreeNode` class appears to be incomplete. However, based on the provided code snippet, it seems that this method was intended to return a string describing the relationship between the current node and its parent node. The method checks if the parent node is an action or chance node and prints out relevant information such as player actions or deal card details. If the parent node is null, it returns a message indicating the start of a new round. However, the method currently returns an empty string. \\
 ## Code: 
 ```
string GameTreeNode::toString(){
    /*
    shared_ptr<GameTreeNode>parent_node = node->parent;
    string round;
    if (parent_node == nullptr) return tfm::format("%s begin",round);
    if(parent_node->getType() == GameTreeNodeType::ACTION){
        ActionNode action_node = (ActionNode)parent_node;
        for(int i = 0;i < action_node.getActions().size();i ++){
            if(action_node.getChildrens().get(i) == node){
                System.out.print(String.format("<- (player %s %s)",
                           action_node.getPlayer(),
                           action_node.getActions().get(i).toString()
                    ));
        }
        }
    }else if(parent_node->getType() == GameTreeNodeType::CHANCE){
        ChanceNode chance_node = (ChanceNode)parent_node;
        for(int i = 0;i < chance_node.getChildrens().size();i ++){
            if(chance_node.getChildrens().get(i) == node){
                System.out.print(String.format("<- (deal card %s)",
                       chance_node.getCards().get(i).toString()
            ));
        }
    }
    */
    return "";
}
```