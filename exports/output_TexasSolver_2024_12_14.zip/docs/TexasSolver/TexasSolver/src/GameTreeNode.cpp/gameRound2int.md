`gameRound2int`: The function of `gameRound2int` is to convert a given game round into an integer representation.

**Parameters**:
`GameTreeNode::GameRound gameRound`: This parameter takes an enumeration value of type `GameRound` from the `GameTreeNode` class, which represents different stages of a poker game.

**Code Description**: 
The function uses a series of if-else statements to check the input `gameRound` against predefined values. If the input matches one of the specified rounds (PREFLOP, FLOP, TURN, or RIVER), it returns an integer value corresponding to that round (0, 1, 2, or 3 respectively). If the input does not match any of these rounds, it throws a runtime error with the message "round not found". \\
 ## Code: 
 ```
int GameTreeNode::gameRound2int(GameTreeNode::GameRound gameRound) {
    if(gameRound == GameRound::PREFLOP) {
        return 0;
    }else if(gameRound == GameRound::FLOP){
        return 1;
    } else if(gameRound == GameRound::TURN) {
        return 2;
    } else if(gameRound == GameRound::RIVER) {
        return 3;
    }
    throw runtime_error("round not found");
}
```