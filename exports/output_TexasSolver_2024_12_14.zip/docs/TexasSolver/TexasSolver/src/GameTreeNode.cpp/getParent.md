`getParent`: The function of `getParent` is to retrieve the parent node from a GameTreeNode object.

**Code Description**: 
The `getParent` method returns the parent node associated with the current GameTreeNode instance. It utilizes a shared_ptr (a type of smart pointer) to manage memory and ensure thread safety. The `lock()` method is used to acquire exclusive access to the parent node, preventing concurrent modifications or access issues. This approach allows for efficient retrieval of the parent node while maintaining data integrity and consistency within the TexasSolver project structure. \\
 ## Code: 
 ```
shared_ptr<GameTreeNode>GameTreeNode::getParent() {
    return this->parent.lock();
}
```