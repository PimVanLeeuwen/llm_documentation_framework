This method converts a game round enum value to an integer representation.
It returns a specific integer for each game round, or throws an error if the round is unknown.