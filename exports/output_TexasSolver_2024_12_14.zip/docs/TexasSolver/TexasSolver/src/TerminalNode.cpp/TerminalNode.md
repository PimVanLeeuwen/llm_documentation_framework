`TerminalNode`: The function of `TerminalNode` is to represent a terminal node in the game tree, where the game has reached its final outcome.

**Parameters**:

`vector<double> payoffs`: A vector of double values representing the payoffs for each player at this terminal node.

`int winner`: An integer value indicating which player won the game at this terminal node.

`GameTreeNode::GameRound round`: An object of type `GameTreeNode::GameRound` representing the current round of the game when this terminal node was reached.

`double pot`: A double value representing the total pot size at this terminal node.

`shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node in the game tree, which led to this terminal node.

**Code Description**: The `TerminalNode` constructor initializes a new terminal node object with the given payoffs, winner, round, pot, and parent node. It sets the corresponding member variables of the `GameTreeNode` class to these values, effectively creating a terminal node in the game tree that represents the final outcome of the game. \\
 ## Code: 
 ```
TerminalNode::TerminalNode(vector<double> payoffs, int winner, GameTreeNode::GameRound round, double pot,
                           shared_ptr<GameTreeNode> parent):GameTreeNode(round,pot,parent){
    this->payoffs = payoffs;
    this->winner = winner;
}
```