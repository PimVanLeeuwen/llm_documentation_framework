**GameTree**: The function of `GameTree` is to initialize and build a game tree for the Texas Solver project, representing the possible outcomes of a poker game.

**Parameters**:

* `Deck deck`: A reference to the deck of cards used in the game.
* `float oop_commit`: The out-of-position commitment value.
* `float ip_commit`: The in-position commitment value.
* `int current_round`: The current round number.
* `int raise_limit`: The maximum number of raises allowed.
* `float small_blind`: The amount of the small blind.
* `float big_blind`: The amount of the big blind.
* `float stack`: The effective stack size for each player.
* `GameTreeBuildingSettings buildingSettings`: Settings used to build the game tree.
* `float allin_threshold`: The threshold value for an all-in action.

**Code Description**: The `GameTree` constructor initializes a new game tree by creating a `Rule` object based on the input parameters, and then uses this rule to build the game tree. It starts with an initial node representing the current player's action, and recursively builds the tree by calling the `__build` method. The resulting game tree is stored in the `root` member variable. \\
 ## Code: 
 ```
GameTree::GameTree(Deck deck,
                   float oop_commit,
                   float ip_commit,
                   int current_round,
                   int raise_limit,
                   float small_blind,
                   float big_blind,
                   float stack,
                   GameTreeBuildingSettings buildingSettings,
                   float allin_threshold
){
    Rule rule = Rule(deck,oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,buildingSettings,allin_threshold);
    int current_player = 1;
    this->deck = deck;
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(rule.current_round);
    shared_ptr<ActionNode> node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(),current_player, round, (double) rule.get_pot(),
                                 nullptr);
    this->__build(node,rule);
    this->root = node;
}
```