`recurrentSetDepth`: The function of `recurrentSetDepth` is to recursively set the depth and subtree size of a game tree node.

**Parameters**:
- `shared_ptr<GameTreeNode> node`: A shared pointer to a GameTreeNode object, representing the current node in the game tree.
- `int depth`: An integer value representing the current depth level in the game tree.

**Code Description**: 
The `recurrentSetDepth` function takes a GameTreeNode and an integer depth as input. It sets the depth of the given node to the provided depth. If the node is an ActionNode, it recursively calls itself for each child node, incrementing the depth by 1 and summing up the subtree sizes. For ChanceNodes, it calculates the subtree size based on the number of children and cards. The function returns the total subtree size of the given node. \\
 ## Code: 
 ```
int GameTree::recurrentSetDepth(shared_ptr<GameTreeNode> node, int depth) {
    node->depth = depth;
    if(node->getType() == GameTreeNode::ACTION) {
        shared_ptr<ActionNode> actionNode = std::dynamic_pointer_cast<ActionNode>(node);
        int subtree_size = 1;
        for(shared_ptr<GameTreeNode> one_child:actionNode->getChildrens()){
            subtree_size += this->recurrentSetDepth(one_child,depth + 1);
        }
        node->subtree_size = subtree_size;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chanceNode = std::dynamic_pointer_cast<ChanceNode>(node);
        int subtree_size = 1;
        subtree_size += this->recurrentSetDepth(chanceNode->getChildren(),depth + 1) * chanceNode->getCards().size();
        node->subtree_size = subtree_size;
    }else{
        node->subtree_size = 1;
    }
    return node->subtree_size;
}
```