`recurrentPrintTree`: The function of `recurrentPrintTree` is to recursively print the game tree, starting from a given node.

**Parameters**:
- `const shared_ptr<GameTreeNode>& node`: This parameter represents the current node in the game tree that the function will start printing from.
- `int depth`: This parameter keeps track of the current depth level in the game tree as the function recursively calls itself to print child nodes.
- `int depth_limit`: This parameter specifies a maximum allowed depth for the recursive call, preventing infinite recursion.

**Code Description**: The `recurrentPrintTree` function takes a node and its associated depth information. It checks if the current depth exceeds the specified limit; if so, it returns without further action. Otherwise, it proceeds to print the details of the current node based on its type (Action, Showdown, Terminal, or Chance). For each child node of an Action node, it recursively calls itself with increased depth and within the same depth limit. The function uses dynamic casting to access specific node types and their associated data. It prints relevant information such as player actions, showdown outcomes, terminal payoffs, and chance events in a formatted manner. \\
 ## Code: 
 ```
void GameTree::recurrentPrintTree(const shared_ptr<GameTreeNode>& node, int depth, int depth_limit) {
    if(depth_limit != -1 && depth >= depth_limit){
        return;
    }

    if(node->getType() == GameTreeNode::ACTION){
        shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
        vector<shared_ptr<GameTreeNode>> childrens = action_node->getChildrens();
        vector<GameActions> actions = action_node->getActions();

        for(std::size_t i = 0;i < childrens.size();i++){
            shared_ptr<GameTreeNode> one_child = childrens[i];
            GameActions one_action = actions[i];

            string prefix;
            for(int j = 0;j < depth;j++) prefix += "\t";
            cout << (tfm::format(
                    "%sp%s: %s",prefix,action_node->getPlayer(),one_action.toString()
            )) << endl;
            recurrentPrintTree(one_child,depth + 1,depth_limit);
        }
    }else if(node->getType() == GameTreeNode::SHOWDOWN){
        shared_ptr<ShowdownNode> showdown_node = std::dynamic_pointer_cast<ShowdownNode>(node);
        string prefix;
        for(int j = 0;j < depth;j++) prefix += "\t";
        cout << (tfm::format(
                "%s SHOWDOWN pot %s ",prefix,showdown_node->getPot()
        )) << endl;

        prefix += "\t";
        for(std::size_t i = 0;i < showdown_node->get_payoffs(ShowdownNode::ShowDownResult::TIE,-1).size();i++) {
            cout << (tfm::format("%sif player %s wins, payoff :", prefix,i));
            vector<double> payoffs = showdown_node->get_payoffs(ShowdownNode::ShowDownResult::NOTTIE, i);

            for (std::size_t player_id = 0; player_id < payoffs.size(); player_id++) {
                cout << (
                        tfm::format(" p%s %s ", player_id, payoffs[player_id])
                );
            }
            cout << endl;
        }
        cout << (tfm::format("%sif Tie, payoff :", prefix));
        vector<double> payoffs = showdown_node->get_payoffs(ShowdownNode::ShowDownResult::TIE, -1);

        for (std::size_t player_id = 0; player_id < payoffs.size(); player_id++) {
            cout << (
                    tfm::format(" p%s %s ", player_id, payoffs[player_id])
            );
        }
        cout << endl;
    }else if(node->getType() == GameTreeNode::TERMINAL){
        shared_ptr<TerminalNode> terminal_node = std::dynamic_pointer_cast<TerminalNode>(node);
        string prefix;
        for(int j = 0;j < depth;j++) prefix += "\t";
        cout << (tfm::format(
                "%s TERMINAL pot %s ",prefix,terminal_node->getPot()
        )) << endl;

        prefix += "\t";
        cout << (tfm::format("%sTerminal payoff :", prefix));
        vector<double> payoffs = terminal_node->get_payoffs();

        for (std::size_t player_id = 0; player_id < payoffs.size(); player_id++) {
            cout <<(
                    tfm::format("p%s %s ", player_id, payoffs[player_id])
            );
        }
        cout << endl;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
        shared_ptr<GameTreeNode> children = chance_node->getChildren();

        string prefix;
        for(int j = 0;j < depth;j++) prefix += "\t";
        cout << (tfm::format(
                "%s%s",prefix,"CHANCE"
        )) << endl;
        recurrentPrintTree(children,depth + 1,depth_limit);
    }
}
```