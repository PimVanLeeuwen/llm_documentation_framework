The `GameTree` class initializes a game tree data structure for Texas Hold'em poker, representing possible game outcomes based on given parameters and rules.

This initialization process involves creating a root node and recursively building the game tree by calling the `__build` method, which populates the tree with child nodes and actions.