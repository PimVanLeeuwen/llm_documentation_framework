**readAllBytes**: The function of `readAllBytes` is to read all bytes from a file specified by the given file path.

**Parameters**:
- `const string& filePath`: A constant reference to a string representing the path to the file that needs to be read.

**Code Description**:
The `readAllBytes` method opens an input stream (`ifstream`) object and initializes it with the specified file path. It then returns this input stream object, which can be used to read all bytes from the file. The returned input stream is not necessarily closed by this function; its usage depends on how it's handled in the calling code. This approach allows for flexibility in handling file operations, as the caller can choose when and if to close the stream. \\
 ## Code: 
 ```
ifstream GameTree::readAllBytes(const string& filePath) {
    ifstream input_file(filePath);
    return input_file;
}
```