The `__build` method constructs a game tree node based on its type, calling specific methods to build action or chance nodes.

This method takes in parameters such as the node type, rule, last action, check and raise times, and returns the constructed node.