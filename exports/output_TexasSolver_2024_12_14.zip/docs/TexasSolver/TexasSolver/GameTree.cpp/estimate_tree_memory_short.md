This method estimates the memory required for a game tree in TexasSolver.
It does so by delegating the actual estimation to another method, re_estimate_tree_memory.