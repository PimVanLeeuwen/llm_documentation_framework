This method converts a string representation of a game round to its corresponding enum value in the GameTree class.
It throws an exception if the input string does not match any known game round.