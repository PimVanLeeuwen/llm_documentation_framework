`re_estimate_tree_memory`: The function of `re_estimate_tree_memory` is to estimate the memory usage of a game tree.

**Parameters**:
`const shared_ptr<GameTreeNode>& node`: A reference to a shared pointer to a GameTreeNode object, representing the current node in the game tree.
`int deck_num`: An integer representing the number of decks used in the game.
`int p1range_num`: An integer representing the range of possible values for player 1's hand.
`int p2range_num`: An integer representing the range of possible values for player 2's hand.
`int num_current_deal`: An integer representing the current deal number.

**Code Description**: The `re_estimate_tree_memory` function estimates the memory usage of a game tree by recursively traversing the tree and calculating the memory usage of each node. It takes into account the type of node (Action or Chance), the number of decks, player ranges, and the current deal number to estimate the total memory usage.

The function first checks if the current node is an ActionNode. If it is, it calculates the memory usage by recursively calling itself for each child node, adding the memory usage of the action node itself, and multiplying the result by the number of current deals, player ranges, and a constant factor. If the node is a ChanceNode, it simply calls itself with the children of the chance node and multiplies the result by the deck number.

The function returns an estimate of the total memory usage of the game tree as a long long integer. \\
 ## Code: 
 ```
long long GameTree::re_estimate_tree_memory(const shared_ptr<GameTreeNode>& node,int deck_num,int p1range_num,int p2range_num,int num_current_deal){
    if(node->getType() == GameTreeNode::ACTION){
        shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
        vector<shared_ptr<GameTreeNode>> childrens = action_node->getChildrens();
        vector<GameActions> actions = action_node->getActions();

        long long retnum = 0;
        for(std::size_t i = 0;i < childrens.size();i++){
            shared_ptr<GameTreeNode> one_child = childrens[i];
            retnum += re_estimate_tree_memory(one_child,deck_num, p1range_num, p2range_num, num_current_deal);
        }
        if(action_node->getPlayer() == 0){
            retnum += num_current_deal * p1range_num * (childrens.size() + 1) * 3;
        }else{
            retnum += num_current_deal * p2range_num * (childrens.size() + 1) * 3;
        }
        return retnum;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
        shared_ptr<GameTreeNode> children = chance_node->getChildren();
        return re_estimate_tree_memory(children,deck_num, p1range_num, p2range_num, num_current_deal * (deck_num));
    }
    return 0;
}
```