`getSettings`: The function of `getSettings` is to retrieve the settings for a specific game round and player.

**Parameters**:
- `int int_round`: An integer representing the current game round.
- `int player`: An integer indicating which player's settings are being retrieved (0 or 1).
- `GameTreeBuildingSettings& gameTreeBuildingSettings`: A reference to an object containing various game tree building settings.

**Code Description**: 
The `getSettings` method takes in three parameters: the current game round (`int_round`), the player number (`player`), and a reference to the game tree building settings (`gameTreeBuildingSettings`). It first converts the integer game round to its corresponding enum value using the `GameTreeNode::intToGameRound` method. The method then checks if the provided player number is valid (either 0 or 1). If not, it throws a runtime error with an appropriate message.

Based on the converted game round and player number, the method returns the corresponding IP address from the `gameTreeBuildingSettings` object. For example, if the game round is RIVER and the player is 0, it returns the `river_ip` value; if the game round is FLOP and the player is 1, it returns the `flop_oop` value.

If the method cannot determine which settings to return (i.e., an invalid combination of game round and player), it throws a runtime error with a message indicating that the player and round are not known. \\
 ## Code: 
 ```
StreetSetting GameTree::getSettings(int int_round, int player,GameTreeBuildingSettings& gameTreeBuildingSettings){
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(int_round);
    if(!(player == 0 || player == 1)) throw runtime_error(tfm::format("player %s not known",player));
    if(round == GameTreeNode::GameRound::RIVER && player == 0) return gameTreeBuildingSettings.river_ip;
    else if(round == GameTreeNode::GameRound::TURN && player == 0) return gameTreeBuildingSettings.turn_ip;
    else if(round == GameTreeNode::GameRound::FLOP && player == 0) return gameTreeBuildingSettings.flop_ip;
    else if(round == GameTreeNode::GameRound::RIVER && player == 1) return gameTreeBuildingSettings.river_oop;
    else if(round == GameTreeNode::GameRound::TURN && player == 1) return gameTreeBuildingSettings.turn_oop;
    else if(round == GameTreeNode::GameRound::FLOP && player == 1) return gameTreeBuildingSettings.flop_oop;
    else throw new runtime_error(tfm::format("player %s and round not known",player));
}
```