Here's the completed template:

`generateShowdownNode`: The function of `generateShowdownNode` is to generate a Showdown node in the game tree based on the given meta data, round information, and parent node.

**Parameters**:
- `json meta`: A JSON object containing payoff information for each player.
- `string round`: A string representation of the current game round.
- `shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node in the game tree.

**Code Description**: The function first extracts tie payoffs and player payoffs from the given meta data. It then constructs a ShowdownNode object with the extracted payoffs, the given round information, pot size, and reference to the parent node. The function uses the `strToGameRound` method to convert the input string representation of the game round to its corresponding enum value. If the input string does not match any known game round, it throws a runtime error. Finally, the function returns a shared pointer to the constructed ShowdownNode object. \\
 ## Code: 
 ```
shared_ptr<ShowdownNode> GameTree::generateShowdownNode(json meta, string round, shared_ptr<GameTreeNode> parent) {
    json meta_payoffs = meta["payoffs"];
    vector<double> tie_payoffs = meta_payoffs["tie"];

    // meta_payoffs 的key有 n个玩家+1个平局,代表某个玩家赢了的时候如何分配payoff
    vector<vector<double>> player_payoffs(2);
    double pot = meta["pot"];

    for(auto one_player_meta=meta_payoffs.begin(); one_player_meta!=meta_payoffs.end(); one_player_meta++){
        const string& one_player = one_player_meta.key();
        if(one_player == "tie"){
            continue;
        }
        // 获胜玩家id
        int player_id = atoi(one_player.c_str());
        if(player_id < 0 or player_id > 1) throw runtime_error("player id json convert fail");

        // 玩家在当前Showdown节点能获得的收益
        //List<Object> tmp_payoffs =  (List<Object>)meta_payoffs.get(one_player);
        vector<double> player_payoff = one_player_meta.value();

        player_payoffs[atoi(one_player.c_str())] = player_payoff;
    }
    GameTreeNode::GameRound game_round = strToGameRound(std::move(round));
    return make_shared<ShowdownNode>(tie_payoffs,player_payoffs,game_round,pot,parent);
}
```