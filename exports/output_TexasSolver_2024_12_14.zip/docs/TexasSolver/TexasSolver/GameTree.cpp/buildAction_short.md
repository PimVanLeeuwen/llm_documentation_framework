This code appears to be part of a Texas Hold'em poker game solver, implementing various classes and methods for game tree construction, node management, and rule enforcement.

The code provides a structured representation of the game state, allowing for the calculation of possible bets, determination of valid actions, and evaluation of potential outcomes.