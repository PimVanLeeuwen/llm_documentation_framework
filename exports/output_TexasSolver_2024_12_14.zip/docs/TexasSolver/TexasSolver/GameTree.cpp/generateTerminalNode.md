Here's the completed template:

`generateTerminalNode`: The function of `generateTerminalNode` is to generate a terminal node in the game tree, representing a state where a player has won or lost.

**Parameters**:
- `json meta`: A JSON object containing metadata about the game, including the player's payoff and pot.
- `string round`: A string representation of the current game round.
- `shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node in the game tree.

**Code Description**: The function generates a terminal node by copying the player's payoff from the metadata into a vector, then creates a new TerminalNode object with the payoff, winner (determined from the metadata), round, pot, and reference to the parent node. \\
 ## Code: 
 ```
shared_ptr<TerminalNode> GameTree::generateTerminalNode(json meta, string round, shared_ptr<GameTreeNode> parent) {
    vector<double> player_payoff_list = meta["payoff"];
    vector<double> player_payoff(player_payoff_list.size());
    for(std::size_t one_player = 0;one_player < player_payoff_list.size();one_player ++){

        double tmp_payoff = player_payoff_list[one_player];
        player_payoff[one_player] = tmp_payoff;
    }

    //节点上的下注额度
    double pot = meta["pot"];

    GameTreeNode::GameRound game_round = this->strToGameRound(std::move(round));
    // 多人游戏的时候winner就不等于当前节点的玩家了，这里要注意
    int player = meta["player"];

    return make_shared<TerminalNode>(player_payoff,player,game_round,pot,parent);
}
```