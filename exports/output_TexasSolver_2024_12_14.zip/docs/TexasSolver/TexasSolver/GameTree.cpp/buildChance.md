`buildChance`: The function of `buildChance` is to construct a game tree node representing a chance event in Texas Hold'em poker.

**Parameters**:
- `shared_ptr<ChanceNode> root`: A shared pointer to the current ChanceNode object, which serves as the parent node for the newly constructed node.
- `Rule rule`: An instance of the Rule class, containing information about the current game state, including the round number and player commitments.

**Code Description**: The `buildChance` function takes in a shared pointer to a ChanceNode object (`root`) and an instance of the Rule class (`rule`). It then checks if the current round is greater than 3, throwing an exception if this condition is met. If the round is valid, it proceeds to construct a new game tree node based on the provided rule.

If the player commitments are equal and match the effective stack value, it constructs a ShowdownNode object with tie payoffs and player payoffs calculated from the commit values. Otherwise, it creates an ActionNode object or a ChanceNode object depending on the current round number.

The function then calls the `__build` method to recursively construct the game tree node hierarchy. Finally, it sets the children of the provided root ChanceNode object to the newly constructed node using the `setChildren` method. \\
 ## Code: 
 ```
void GameTree::buildChance(shared_ptr<ChanceNode> root,Rule rule){
    //节点上的下注额度
    double pot = (double)rule.get_pot();
    Rule nextrule = Rule(rule);
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));

    shared_ptr<GameTreeNode> one_node;
    if(rule.oop_commit == rule.ip_commit && rule.oop_commit == rule.stack) {
        if(rule.current_round >= 3){ // 3 is river
            double p1_commit = rule.ip_commit;
            double p2_commit = rule.oop_commit;
            double peace_getback = (p1_commit + p2_commit) / 2;


            vector<vector<double>> payoffs(2);
            payoffs[0] = {p2_commit, -p2_commit};
            payoffs[1] = {-p1_commit, p1_commit};
            vector<double> peace_getback_vec = {peace_getback - p1_commit, peace_getback - p2_commit};
            one_node = make_shared<ShowdownNode>(peace_getback_vec, payoffs, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
        }else {
            nextrule.current_round += 1;
            if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
            one_node = make_shared<ChanceNode>(nullptr, GameTreeNode::intToGameRound(rule.current_round + 1), (double) rule.get_pot(), root, this->deck.getCards());
        }
    }else {
        one_node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(), 1, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
    }
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
    this->__build(one_node,nextrule,"begin",0,0);
    root->setChildren(one_node);
}
```