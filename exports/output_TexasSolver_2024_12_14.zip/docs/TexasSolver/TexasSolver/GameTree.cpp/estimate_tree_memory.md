**estimate_tree_memory**: The function of `estimate_tree_memory` is to estimate the memory required for a game tree.

**Parameters**:
- **int deck_num**: The number of decks used in the game.
- **int p1range_num**: The number of possible ranges for player 1's hand.
- **int p2range_num**: The number of possible ranges for player 2's hand.
- **int num_current_deal**: The current deal number.

**Code Description**: 
The `estimate_tree_memory` function is a method of the `GameTree` class. It takes four parameters: `deck_num`, `p1range_num`, `p2range_num`, and `num_current_deal`. This function calls another method, `re_estimate_tree_memory`, which is not shown in this code snippet, to estimate the memory required for a game tree. The estimated memory is then returned by the `estimate_tree_memory` function.

The purpose of this function appears to be to calculate the memory requirements for a game tree based on various parameters such as the number of decks and possible hand ranges for both players. This information can be useful in determining system resources needed to handle complex game scenarios. \\
 ## Code: 
 ```
long long GameTree::estimate_tree_memory(int deck_num,int p1range_num,int p2range_num,int num_current_deal){
    return this->re_estimate_tree_memory(this->root,deck_num, p1range_num, p2range_num, num_current_deal);
}
```