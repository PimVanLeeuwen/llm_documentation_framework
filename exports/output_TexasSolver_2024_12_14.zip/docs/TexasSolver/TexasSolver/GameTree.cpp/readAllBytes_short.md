This method reads all bytes from a file specified by its path.
It returns an ifstream object containing the read data.