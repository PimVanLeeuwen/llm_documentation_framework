The `round_nearest` method rounds a given number to the nearest multiple of another specified number.

This method takes two parameters: the number to be rounded and the rounding factor, and returns the rounded result.