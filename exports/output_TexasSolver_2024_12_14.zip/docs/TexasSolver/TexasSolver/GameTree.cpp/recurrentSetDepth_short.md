This code calculates the depth and subtree size of a game tree node in the Texas Solver project.
It recursively traverses the game tree, updating node depths and subtree sizes based on node types.