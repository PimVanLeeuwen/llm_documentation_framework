Here is the completed template:

`__build`: The function of `__build` is to build and initialize a game tree node.

**Parameters**:
- `shared_ptr<GameTreeNode> node`: A shared pointer to a GameTreeNode object, which represents a node in the game tree.
- `Rule rule`: An enumeration value representing the current rule being applied in the game.
- `string last_action`: A string indicating the last action taken by a player.
- `int check_times`: An integer representing the number of times a player has checked during their turn.
- `int raise_times`: An integer representing the number of times a player has raised during their turn.

**Code Description**: The `__build` function takes in various parameters to initialize and build a game tree node. It uses a switch statement to determine the type of node being built, which can be one of four types: ACTION, SHOWDOWN, TERMINAL, or CHANCE. Depending on the node type, it calls specific methods (e.g., `buildAction` for ACTION nodes) to set up the necessary attributes and children nodes. If an unknown node type is encountered, it throws a runtime error. The function returns the built game tree node. \\
 ## Code: 
 ```
shared_ptr<GameTreeNode> GameTree::__build(shared_ptr<GameTreeNode> node, Rule rule, string last_action,
                                           int check_times, int raise_times) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            this->buildAction(std::dynamic_pointer_cast<ActionNode>(node),rule,last_action,check_times,raise_times);
            break;
        }case GameTreeNode::SHOWDOWN: {
            break;
        }case GameTreeNode::TERMINAL: {
            break;
        }case GameTreeNode::CHANCE: {
            this->buildChance(std::dynamic_pointer_cast<ChanceNode>(node),rule);
            break;
        }default:
            throw runtime_error("node type unknown");
    }
    return node;
}
```