`generateChanceNode`: The function of `generateChanceNode` is to generate a chance node in the game tree.

**Parameters**:
- `json meta`: A JSON object containing metadata for the chance node, including the pot.
- `const json& child`: A reference to a JSON object representing the child node of the chance node.
- `string round`: The string representation of the current game round.
- `shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node of the chance node.

**Code Description**: 
The `generateChanceNode` function generates a chance node in the game tree by creating a new `ChanceNode` object. It takes the provided metadata, child node, game round, and parent node as parameters. The function uses the `recurrentGenerateTreeNode` method to generate a single child node for the chance node. It then creates a new `ChanceNode` object with the generated child node, current game round, pot, parent node, and deck cards. Finally, it returns a shared pointer to the newly created chance node. The function also sets the parent of the child node to the chance node using the `setParent` method. \\
 ## Code: 
 ```
shared_ptr<ChanceNode>
GameTree::generateChanceNode(json meta, const json& child, string round, shared_ptr<GameTreeNode> parent) {
    //节点上的下注额度
    double pot = meta["pot"];
    shared_ptr<GameTreeNode> one_child = recurrentGenerateTreeNode(child, nullptr);
    GameTreeNode::GameRound game_round = strToGameRound(std::move(round));
    shared_ptr<ChanceNode> chanceNode = make_shared<ChanceNode>(one_child,game_round,pot,parent,this->deck.getCards());
    shared_ptr<GameTreeNode> gameTreeNode = chanceNode->getChildren();
    gameTreeNode->setParent(chanceNode);
    return chanceNode;
}
```