Here's the completed template:

`recurrentGenerateTreeNode`: The function of `recurrentGenerateTreeNode` is to recursively generate a game tree node based on the provided JSON metadata.

**Parameters**:
- `json node_json`: A JSON object containing metadata about the game tree node, including its round and type.
- `const shared_ptr<GameTreeNode>& parent`: A reference to the parent game tree node.

**Code Description**: 
The `recurrentGenerateTreeNode` function takes a JSON object representing a game tree node and an optional parent node reference as input. It extracts metadata from the JSON object, such as the round and type of the node. Based on this information, it determines which type of game tree node to generate (Terminal, Showdown, Action, or Chance). If the node is an Action node, it generates a list of child actions and corresponding children nodes. The function then calls other methods (`generateActionNode`, `generateShowdownNode`, `generateTerminalNode`, or `generateChanceNode`) to create the actual game tree node based on its type. \\
 ## Code: 
 ```
shared_ptr<GameTreeNode> GameTree::recurrentGenerateTreeNode(json node_json, const shared_ptr<GameTreeNode>& parent) {
    json meta = node_json["meta"];
    string round = meta["round"];
    if(round.empty()){
        throw runtime_error("node json get round null pointer");
    }

    if(! (round == "preflop"
          || round == "flop"
          || round == "turn"
          || round == "river"
          )
            ){
        throw runtime_error(tfm::format("round %s not found",round));
    }

    string node_type = meta["node_type"];
    if(node_type.empty()){
        throw runtime_error("node json get round null pointer");
    }
    if (! (   node_type == "Terminal"
           || node_type == "Showdown"
           || node_type ==  "Action"
           || node_type ==  "Chance"
    )
            ){
        throw runtime_error(tfm::format("node type %s not found",node_type));
    }

    if(node_type == "Action") {
        // 孩子节点的动作，存在list里
        auto childrens_actions = node_json["children_actions"].get<std::vector<string>>();
        // 孩子节点本身，同样存在list里,和上面的children_actions 一一对应,事实上两者的长度一致
        vector<json> childrens = node_json["children"].get<std::vector<json>>();
        if (childrens.size() != childrens_actions.size()) {
            throw runtime_error("action node child length mismatch");
        }
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateActionNode(meta, childrens_actions, childrens, round,parent));
    }
    else if(node_type == "Showdown") {
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateShowdownNode(meta, round,parent));
    }
    else if(node_type == "Terminal") {
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateTerminalNode(meta, round,parent));
    }
    else if(node_type == "Chance") {
        auto childrens = node_json["children"].get<std::vector<json>>();
        if(childrens.size() != 1) throw runtime_error("Chance node should have only one child");
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateChanceNode(meta, childrens[0], round,parent));
    }
    else{
        throw runtime_error(tfm::format("node type %s not found",node_type));
    }
}
```