`round_nearest`: The function of `round_nearest` is to round a given number to the nearest multiple of another specified number.

**Parameters**:
`double number`: The input number that needs to be rounded.
`double round_num`: The number to which the input number should be rounded to, and also used as the divisor for scaling the result.

**Code Description**: 
The `round_nearest` function takes two parameters: `number` and `round_num`. It first scales the `round_num` by taking its reciprocal. Then it multiplies the `number` with this scaled `round_num`, rounds the product to the nearest integer using the `round()` function, and finally divides the result by the scaled `round_num` to obtain the final rounded value of the input number. \\
 ## Code: 
 ```
double GameTree::round_nearest(double number, double round_num) {
    round_num = 1 / round_num;
    return round((number * round_num)) / round_num;

}
```