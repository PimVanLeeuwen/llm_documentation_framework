**Deck**: The function of `Deck` is to initialize a deck of cards with the given ranks and suits.

**Parameters**:
- `const vector<string>& ranks`: A list of card ranks.
- `const vector<string>& suits`: A list of card suits.

**Code Description**:

The `Deck` constructor takes two parameters: `ranks` and `suits`, both of which are vectors of strings. It initializes the `ranks` and `suits` member variables with the provided values.

 Inside the constructor, it iterates over each rank and suit combination using nested loops. For each combination, it creates a string representation of the card by concatenating the rank and suit (e.g., "Ace of Hearts"). This string is then added to the `cards_str` vector.

Additionally, for each card created, an object is pushed back into the `cards` vector with the card's string representation as its value and a unique integer identifier (`card_num`) as its key. The `card_num` variable is incremented after each card creation to ensure that each card has a distinct identifier.

The constructor does not return any value, implying that it modifies the object's state directly. \\
 ## Code: 
 ```
Deck::Deck(const vector<string>& ranks, const vector<string>& suits) {
    this->ranks = ranks;
    this->suits = suits;
    int card_num = 0;
    for(const string& one_rank : ranks){
        for(const string& one_suit: suits){
            string one_card = one_rank + one_suit;
            cards_str.push_back(one_card);
            cards.emplace_back(one_card,card_num);
            card_num += 1;
        }
    }
}
```