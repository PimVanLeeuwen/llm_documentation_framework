The `getCards` method returns a reference to the vector of cards stored in the Deck object.
This allows access to the deck's card collection without modifying it.