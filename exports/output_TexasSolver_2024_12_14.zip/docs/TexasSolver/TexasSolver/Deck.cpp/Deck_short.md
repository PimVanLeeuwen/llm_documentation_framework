The `Deck` method initializes a deck of cards by combining given ranks and suits, generating unique card identifiers.

It populates two data structures: a string vector (`cards_str`) with concatenated rank-suit pairs and a map-like collection (`cards`) containing the same pairs along with an incrementing card number.