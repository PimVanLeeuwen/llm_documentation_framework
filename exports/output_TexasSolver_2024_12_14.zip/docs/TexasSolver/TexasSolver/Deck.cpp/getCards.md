`getCards`: The function of `getCards` is to return a reference to the vector of cards stored in the Deck object.

**Code Description**: 
The `getCards` method is a member function of the `Deck` class, which returns a reference to the internal vector of `Card` objects. This vector, named `cards`, stores all the cards that are part of the deck. The method simply returns this vector, allowing external access to the deck's contents. \\
 ## Code: 
 ```
vector<Card>& Deck::getCards() {
    return this->cards;
}
```