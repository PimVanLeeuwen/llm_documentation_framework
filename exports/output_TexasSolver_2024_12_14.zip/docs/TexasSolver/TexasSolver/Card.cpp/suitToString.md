`suitToString`: The function of `suitToString` is to convert a given integer representing a card suit into its corresponding string representation.

**Parameters**:
`int suit`: An integer value between 0 and 3, inclusive, where each number corresponds to a specific suit: 0 for clubs (c), 1 for diamonds (d), 2 for hearts (h), and 3 for spades (s).

**Code Description**: The `suitToString` function uses a switch statement to determine the string representation of the card suit based on the input integer. If the input is within the valid range, it returns the corresponding string; otherwise, it defaults to "c" (clubs). \\
 ## Code: 
 ```
string Card::suitToString(int suit)
{
    switch(suit)
    {
        case 0: return "c";
        case 1: return "d";
        case 2: return "h";
        case 3: return "s";
        default: return "c";
    }
}
```