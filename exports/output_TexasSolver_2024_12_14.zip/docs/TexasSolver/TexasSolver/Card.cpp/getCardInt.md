`getCardInt`: The function of `getCardInt` is to return the integer representation of a card.

**Code Description**: 
The `getCardInt` method is a simple getter function that returns the integer value associated with a card. It does this by directly returning the value stored in the `card_int` member variable of the `Card` class. This suggests that the `card_int` variable has been assigned an integer value representing the specific card, such as its rank and suit. The method does not perform any calculations or operations on the data; it merely provides access to the existing integer representation of the card. \\
 ## Code: 
 ```
int Card::getCardInt() {
    return this->card_int;
}
```