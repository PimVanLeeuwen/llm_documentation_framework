`suitToInt`: The function of `suitToInt` is to convert a character representing the suit of a card into an integer value.

**Parameters**:
`char suit`: A single character representing the suit of a card, which can be 'c' for 梅花 (clubs), 'd' for 方块 (diamonds), 'h' for 红桃 (hearts), or 's' for 黑桃 (spades).

**Code Description**: The `suitToInt` function uses a switch statement to map the input character to its corresponding integer value. If the input character is not one of the expected values, it returns 0 by default. This allows the function to be used in scenarios where an unknown or invalid suit is encountered, and provides a fallback value for such cases. \\
 ## Code: 
 ```
int Card::suitToInt(char suit)
{
    switch(suit)
    {
        case 'c': return 0; // 梅花
        case 'd': return 1; // 方块
        case 'h': return 2; // 红桃
        case 's': return 3; // 黑桃
        default: return 0;
    }
}
```