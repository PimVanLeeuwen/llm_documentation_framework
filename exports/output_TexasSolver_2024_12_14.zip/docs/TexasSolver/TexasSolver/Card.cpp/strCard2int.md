**strCard2int**: Converts a string representation of a card to its corresponding integer value.

**Parameters**:
`string card`: A string containing the rank and suit of a card, e.g., "Ac" or "10d".

**Code Description**:
The `strCard2int` function takes a string `card` as input and returns an integer representing the card's value. It first checks if the length of the input string is 2; if not, it throws a runtime error. Then, it extracts the rank and suit from the string using `at(0)` and `at(1)`, respectively. The function then calls `rankToInt` to convert the rank character to its integer value and subtracts 2 (since ranks are 1-indexed in the standard deck), multiplies by 4, and adds the result of calling `suitToInt` to convert the suit character to its integer value. This final result is returned as the card's integer value. \\
 ## Code: 
 ```
int Card::strCard2int(string card) {
    char rank = card.at(0);
    char suit = card.at(1);
    if(card.length() != 2){
        throw runtime_error( tfm::format("card %s not found",card));
    }
    return (rankToInt(rank) - 2) * 4 + suitToInt(suit);
}
```