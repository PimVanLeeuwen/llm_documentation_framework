The `getCardInt` method returns the integer representation of a card object.
This method provides direct access to the internal card integer value.