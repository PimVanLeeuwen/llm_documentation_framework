**intCard2Str**: The function of `intCard2Str` is to convert an integer card value into a string representation.

**Parameters**:
`int card`: The input integer representing the card's rank and suit, where the rank is determined by the integer's remainder when divided by 4 (with 0 being Ace), and the suit is determined by the integer's remainder when divided by 16 (with 0 being Clubs).

**Code Description**: 
The `intCard2Str` function takes an integer card value as input, calculates its rank and suit based on the given formula, and then uses the `rankToString` and `suitToString` methods to convert these values into their respective string representations. The resulting strings are concatenated together to form the final output string representing the card. \\
 ## Code: 
 ```
string Card::intCard2Str(int card){
    int rank = card / 4 + 2;
    int suit = card - (rank-2)*4;
    return Card::rankToString(rank) + Card::suitToString(suit);
}
```