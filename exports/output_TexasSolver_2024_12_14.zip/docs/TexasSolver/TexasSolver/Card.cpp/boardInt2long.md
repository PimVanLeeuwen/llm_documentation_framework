`boardInt2long`: The function of `boardInt2long` is to convert a 1-based integer representation of a card in a poker game to a 64-bit unsigned integer.

**Parameters**:
`int board`: An integer representing the position of a card in a standard 52-card deck, where 0 corresponds to the first card and 51 corresponds to the last card.

**Code Description**: 
The `boardInt2long` function takes an integer `board` as input and returns its corresponding 64-bit unsigned integer representation. It first checks if the input `board` is within the valid range of 0 to 51 (inclusive), throwing a runtime error if it's not. Then, it uses bitwise left shift operation to convert the input `board` into a 64-bit unsigned integer. The result is a unique identifier for each card in the deck, where each bit corresponds to a specific card. \\
 ## Code: 
 ```
uint64_t Card::boardInt2long(int board){
    // 这里hard code了一副扑克牌是52张
    if(board < 0 || board >= 52){
        throw runtime_error(tfm::format("Card with id %s not found",board));
    }
    // uint64_7 的range 在0 ~ + 2^ 64之间,所以不用太担心溢出问题
    return ((uint64_t)(1) << board);
}
```