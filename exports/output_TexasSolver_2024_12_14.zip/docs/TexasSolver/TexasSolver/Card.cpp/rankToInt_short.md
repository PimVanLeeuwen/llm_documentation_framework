The `rankToInt` method converts a card rank character to its corresponding integer value in a standard deck of cards.

This method uses a switch statement to map each valid card rank ('2' to 'A') to its respective integer value, returning 2 for invalid ranks.