`getSuits`: The function of `getSuits` is to return a vector of strings representing the four suits in a standard deck of cards.

**Code Description**: 
The `getSuits` method returns a vector containing the four suits: "c" for clubs, "d" for diamonds, "h" for hearts, and "s" for spades. This function is likely used to provide the possible suit values for a card in the TexasSolver project. The returned vector can be iterated over or indexed to access each suit value individually. \\
 ## Code: 
 ```
vector<string> Card::getSuits(){
    return {"c","d","h","s"};
}
```