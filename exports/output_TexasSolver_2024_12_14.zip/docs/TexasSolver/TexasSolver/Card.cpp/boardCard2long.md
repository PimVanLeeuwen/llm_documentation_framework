`boardCard2long`: The function of `boardCard2long` is to convert a Card object's integer representation into a unique long integer value.

**Parameters**:
`Card& card`: A reference to a Card object, from which the integer representation will be retrieved.

**Code Description**: 
The `boardCard2long` method takes a reference to a Card object as input and returns a unique long integer value representing that card. It does this by calling the `getCardInt` method on the provided Card object, which retrieves its internal integer representation. This integer is then passed to the `boardInt2long` method, which converts it into a unique long integer value. If the input index is out of range (indicating an invalid card ID), the `boardInt2long` method will throw an exception. \\
 ## Code: 
 ```
uint64_t Card::boardCard2long(Card& card){
    return Card::boardInt2long(card.getCardInt());
}
```