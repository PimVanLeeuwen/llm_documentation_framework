**Card**: The function of `Card` is to initialize a new instance with the given string representation of a card.

**Parameters**:
- `string card`: A two-character string representing a card, where the first character denotes the rank and the second character denotes the suit.

**Code Description**:
The `Card` constructor takes a string `card` as input and initializes three member variables: `card`, `card_int`, and `card_number_in_deck`. The `strCard2int` method is called to convert the input string into an integer value, which is stored in `card_int`. The `card_number_in_deck` variable is initialized with a default value of -1. This constructor allows for the creation of new card objects from their string representations. \\
 ## Code: 
 ```
Card::Card(string card){
    this->card = card;
    this->card_int = Card::strCard2int(this->card);
    this->card_number_in_deck = -1;
}
```