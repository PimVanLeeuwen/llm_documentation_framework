`boardCards2long`: The function of `boardCards2long` is to convert a vector of string representations of poker board cards into a single 64-bit unsigned integer.

**Parameters**:
`vector<string> cards`: A vector of string representations of poker board cards, where each string corresponds to a card in the board.

**Code Description**: The function first creates a new vector of `Card` objects from the input vector of strings. It then calls another instance of the `boardCards2long` method on this new vector of `Card` objects, which converts the entire poker board into a single 64-bit unsigned integer. This is achieved by iterating over each card in the board, converting it to its corresponding integer value using the `strCard2int` method, and then combining these values into a single long integer. \\
 ## Code: 
 ```
uint64_t Card::boardCards2long(vector<string> cards) {
    vector<Card> cards_objs(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_objs[i] = Card(cards[i]);
    }
    return Card::boardCards2long(cards_objs);
}
```