`getNumberInDeckInt`: The function of `getNumberInDeckInt` is to return the card number in deck as an integer.

**Code Description**: 
The `getNumberInDeckInt` method is a member function of the `Card` class. It retrieves and returns the card's position within its respective deck, represented by the `card_number_in_deck` attribute. This value is expected to be a non-negative integer, indicating the unique identifier or ranking of the card in the deck. If the `card_number_in_deck` attribute has been assigned an invalid value (-1), the method throws a runtime error to signal that the requested information cannot be provided due to an inconsistent state. \\
 ## Code: 
 ```
int Card::getNumberInDeckInt(){
    if(this->card_number_in_deck == -1)throw runtime_error("card number in deck cannot be -1");
    return this->card_number_in_deck;
}
```