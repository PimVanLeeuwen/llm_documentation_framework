`boardCards2html`: The function of `boardCards2html` is to convert a list of card objects into an HTML-formatted string.

**Parameters**:
`vector<Card>& cards`: A reference to a vector of Card objects, where each Card object represents a card in the TexasSolver system.

**Code Description**: 
The `boardCards2html` function iterates through the provided vector of Card objects. For each non-empty Card object, it calls the `toFormattedHtml` method on that object and appends the resulting HTML-formatted string to a return string (`ret_html`). The final HTML-formatted string is then returned by the function. If a Card object is empty (i.e., its `empty` method returns true), it is skipped in the iteration process, and no HTML-formatted string is appended for that card. \\
 ## Code: 
 ```
QString Card::boardCards2html(vector<Card>& cards){
    QString ret_html = "";
    for(auto one_card:cards){
        if(one_card.empty())continue;
        ret_html += one_card.toFormattedHtml();
    }
    return ret_html;
}
```