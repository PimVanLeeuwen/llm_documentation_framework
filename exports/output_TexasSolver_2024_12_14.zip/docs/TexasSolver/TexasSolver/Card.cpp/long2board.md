`long2board`: The function of `long2board` is to convert a 64-bit unsigned integer representing a binary long value into a vector of integers, where each integer represents the index of a card in a standard deck.

**Parameters**:
`uint64_t board_long`: A 64-bit unsigned integer containing a binary representation of a long value.

**Code Description**: 
The `long2board` function takes a `uint64_t` parameter `board_long`, which is expected to contain a binary representation of a long value. The function iterates through each bit in the binary representation, starting from the least significant bit (LSB). If the current bit is set (i.e., its value is 1), the corresponding index of a card in a standard deck (0-51) is added to a vector `board`. The process continues until all bits have been processed. After iterating through all bits, the function checks if the size of the resulting `board` vector is within the expected range (i.e., between 1 and 7). If not, it throws a runtime error with an informative message. Finally, the function returns the populated `board` vector. \\
 ## Code: 
 ```
vector<int> Card::long2board(uint64_t board_long) {
    vector<int> board;
    board.reserve(7);
    for(int i = 0;i < 52;i ++){
        // 看二进制最后一位是否为1
        if((board_long & 1) == 1){
            board.push_back(i);
        }
        board_long = board_long >> 1;
    }
    if (board.size() < 1 || board.size() > 7){
        throw runtime_error(tfm::format("board length not correct, board length %s",board.size()));
    }
    return board;
}
```