The `toFormattedString` method converts a card object into a formatted string representation, replacing numerical values with corresponding suit symbols.

This method returns a standard string that can be used for display or further processing, with suits represented by Unicode characters (e.g., ♣️, ♦️, ♥️, and ♠️).