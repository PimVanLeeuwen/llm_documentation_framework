The `getNumberInDeckInt` method returns the card number in a deck as an integer.
It throws a runtime error if the card number is invalid (-1).