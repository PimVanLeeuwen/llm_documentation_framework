`rankToInt`: The function of `rankToInt` is to convert a card's rank from a character representation ('2'-'A') to an integer value.

**Parameters**:
`char rank`: A single character representing the rank of a playing card, where '2' represents the lowest rank and 'A' represents the highest rank.

**Code Description**: 
The `rankToInt` function is a switch-case statement that takes a character representation of a card's rank as input. It returns an integer value corresponding to the rank, with '2' returning 2, '3' returning 3, and so on up to 'A' returning 14. If any other character is passed, it defaults to returning 2. This function appears to be part of a larger system for representing and manipulating playing cards in the TexasSolver project. \\
 ## Code: 
 ```
int Card::rankToInt(char rank)
{
    switch(rank)
    {
        case '2': return 2;
        case '3': return 3;
        case '4': return 4;
        case '5': return 5;
        case '6': return 6;
        case '7': return 7;
        case '8': return 8;
        case '9': return 9;
        case 'T': return 10;
        case 'J': return 11;
        case 'Q': return 12;
        case 'K': return 13;
        case 'A': return 14;
        default: return 2;
    }
}
```