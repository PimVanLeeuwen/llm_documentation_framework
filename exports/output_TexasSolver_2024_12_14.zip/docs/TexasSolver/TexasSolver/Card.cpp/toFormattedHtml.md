**toFormattedHtml**: The function of `toFormattedHtml` is to format a card's value as HTML, replacing the first letter with a corresponding Unicode character for each suit.

**Code Description**: 
The `toFormattedHtml` method takes no arguments and returns a QString. It starts by converting the card's value (stored in the `card` member variable) from a std::string to a QString using `QString::fromStdString`. 

It then checks if the resulting string contains any of the characters "c", "d", "h", or "s" (representing the clubs, diamonds, hearts, and spades suits respectively). If it finds one of these characters, it replaces that character with a corresponding HTML span element containing a Unicode character for the suit. 

For example, if the card's value is "c5", it will replace the "c" with "<span style="color:black;">&#9827;</span>", which displays a black club symbol. The method returns the modified QString as its result. \\
 ## Code: 
 ```
QString Card::toFormattedHtml() {
    QString qString = QString::fromStdString(this->card);
    if(qString.contains("c"))
        qString = qString.replace("c", QString::fromLocal8Bit("<span style=\"color:black;\">&#9827;<\/span>"));
    else if(qString.contains("d"))
        qString = qString.replace("d", QString::fromLocal8Bit("<span style=\"color:red;\">&#9830;<\/span>"));
    else if(qString.contains("h"))
        qString = qString.replace("h", QString::fromLocal8Bit("<span style=\"color:red;\">&#9829;<\/span>"));
    else if(qString.contains("s"))
        qString = qString.replace("s", QString::fromLocal8Bit("<span style=\"color:black;\">&#9824;<\/span>"));
    return qString;
}
```