`rankToString`: The function of `rankToString` is to convert a given card rank into its corresponding string representation.

**Parameters**:
`int rank`: An integer representing the rank of a playing card, ranging from 2 to 14 (inclusive), where each value corresponds to a specific card rank.

**Code Description**: 
The `rankToString` function takes an integer `rank` as input and uses a switch statement to determine which string representation to return. The function maps the integer values 2 through 14 to their respective string equivalents, such as "2", "3", "4", ..., "A". If the input `rank` is outside this range (i.e., not between 2 and 14), the function returns a default value of "2". This approach allows for efficient conversion of card ranks to their string representations. \\
 ## Code: 
 ```
string Card::rankToString(int rank)
{
    switch(rank)
    {
        case 2: return "2";
        case 3: return "3";
        case 4: return "4";
        case 5: return "5";
        case 6: return "6";
        case 7: return "7";
        case 8: return "8";
        case 9: return "9";
        case 10: return "T";
        case 11: return "J";
        case 12: return "Q";
        case 13: return "K";
        case 14: return "A";
        default: return "2";
    }
}
```