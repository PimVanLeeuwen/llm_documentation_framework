**toFormattedString**: The function of `toFormattedString` is to return a formatted string representation of the card, replacing numerical values with their corresponding suit symbols.

**Code Description**: 
The `toFormattedString` method takes no arguments and returns a string. It first converts the underlying card value (stored as a string) into a QString using the `QString::fromStdString` function. Then, it replaces occurrences of "c", "d", "h", and "s" with their respective suit symbols: ♣️, ♦️, ♥️, and ♠️. Finally, it converts the modified QString back to a standard string using the `toStdString` method and returns this formatted string representation of the card. \\
 ## Code: 
 ```
string Card::toFormattedString() {
    QString qString = QString::fromStdString(this->card);
    qString = qString.replace("c", "♣️");
    qString = qString.replace("d", "♦️");
    qString = qString.replace("h", "♥️");
    qString = qString.replace("s", "♠️");
    return qString.toStdString();
}
```