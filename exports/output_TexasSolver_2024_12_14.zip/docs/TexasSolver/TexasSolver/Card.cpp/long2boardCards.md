`long2boardCards`: The function of `long2boardCards` is to convert a 64-bit unsigned integer representing a card board into a vector of Card objects.

**Parameters**:
`uint64_t board_long`: A 64-bit unsigned integer representing the card board.

**Code Description**: 
The `long2boardCards` method takes a 64-bit unsigned integer (`uint64_t`) as input, which represents a card board. It first converts this long integer into a vector of integers using the `long2board` method. The resulting vector is then used to create a new vector of Card objects by iterating through each integer in the vector and creating a Card object from it using the `Card(intCard2Str(one_board))` constructor. The function checks if the size of the board_cards vector is within the valid range (1-7) and throws an exception if not. Finally, it returns the vector of Card objects. \\
 ## Code: 
 ```
vector<Card> Card::long2boardCards(uint64_t board_long){
        vector<int> board = long2board(board_long);
        vector<Card> board_cards(board.size());
        for(std::size_t i = 0;i < board.size();i ++){
            int one_board = board[i];
            board_cards[i] = Card(intCard2Str(one_board));
        }
        if (board_cards.size() < 1 || board_cards.size() > 7){
            throw runtime_error(tfm::format("board length not correct, board length %s",board_cards.size()));
        }
        vector<Card> retval(board_cards.size());
        for(std::size_t i = 0;i < board_cards.size();i ++){
            retval[i] = board_cards[i];
        }
        return retval;
}
```