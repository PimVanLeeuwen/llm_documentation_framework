`card2int`: The function of `card2int` is to convert a Card object into its corresponding integer value in a standard deck of cards.

**Parameters**:
`Card card`: A Card object that represents the card to be converted.

**Code Description**:
The `card2int` method takes a Card object as input and returns an integer value representing the card's position in a standard deck. This is achieved by calling the `strCard2int` method, which converts the string representation of the card (obtained from the `getCard` method) into its corresponding integer value.

In essence, `card2int` serves as a wrapper around `strCard2int`, allowing for easy conversion of Card objects to their respective integer values. This can be useful in various scenarios, such as when comparing or sorting cards based on their numerical values. \\
 ## Code: 
 ```
int Card::card2int(Card card) {
    return strCard2int(card.getCard());
}
```