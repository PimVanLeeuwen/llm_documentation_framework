`log_with_signal`: The function of `log_with_signal` is to emit a signal with the given message.

**Parameters**:
`QString message`: A string containing the message to be logged and emitted as a signal.

**Code Description**: 
The `log_with_signal` method takes a `QString` parameter, which represents the message to be logged. It then emits a signal named `message_signal` with the provided message. This allows other parts of the program to receive and respond to this signal when logging occurs. The purpose of this function is to notify other components about log messages without directly modifying their state or behavior. \\
 ## Code: 
 ```
void QSTextEdit::log_with_signal(QString message){
    emit message_signal(message);
}
```