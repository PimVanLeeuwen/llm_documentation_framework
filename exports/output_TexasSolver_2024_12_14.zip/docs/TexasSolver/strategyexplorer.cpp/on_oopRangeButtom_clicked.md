`on_oopRangeButtom_clicked`: The function of `on_oopRangeButtom_clicked` is to update the application's UI and data model when the "OOP Range" button is clicked.

**Code Description**: When the "OOP Range" button is clicked, this method updates the detail window setting mode to RANGE_OOP. It then triggers an update of the strategy table view, detail view, and rough strategy viewer model. The `onchanged` method of the rough strategy viewer model is called to refresh its data, and finally, the viewport of the rough strategy view is updated. \\
 ## Code: 
 ```
void StrategyExplorer::on_oopRangeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::RANGE_OOP;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```