Here's the completed template:

`onMouseMoveEvent`: The function of `onMouseMoveEvent` is to update the grid coordinates and refresh the views when a mouse move event occurs.

**Parameters**:
`int i`: The row index of the grid where the mouse cursor is currently located.
`int j`: The column index of the grid where the mouse cursor is currently located.

**Code Description**: This method updates the `detailWindowSetting.grid_i` and `detailWindowSetting.grid_j` variables with the current grid coordinates, then refreshes the `detailView` and `strategyTableView` views by calling their respective viewport update methods. \\
 ## Code: 
 ```
void StrategyExplorer::onMouseMoveEvent(int i,int j){
    this->detailWindowSetting.grid_i = i;
    this->detailWindowSetting.grid_j = j;
    this->ui->detailView->viewport()->update();
    this->ui->strategyTableView->viewport()->update();
}
```