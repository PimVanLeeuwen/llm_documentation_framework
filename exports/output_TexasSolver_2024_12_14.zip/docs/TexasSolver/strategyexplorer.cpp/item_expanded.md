`item_expanded`: The function of `item_expanded` is to handle the expansion of a tree item in the game tree view.

**Parameters**:
`const QModelIndex& index`: This parameter represents the index of the tree item that has been expanded.

**Code Description**: 
The `item_expanded` method is called when a tree item in the game tree view is expanded. It retrieves the TreeItem associated with the given index and checks if it has any children. If a child item does not have any further children, the method calls the `reGenerateTreeItem` function from the tree model to regenerate the tree item for that round number. This process continues recursively until all child items without further children are processed.

The code uses a loop to iterate over each child of the expanded TreeItem and checks if the child has any children itself. If it does not, the `reGenerateTreeItem` function is called with the round number from the GameTreeNode object associated with that child item. This ensures that the tree view remains up-to-date and accurately reflects the current state of the game.

The use of a loop allows the method to efficiently process all child items without further children, making it suitable for handling large or complex game trees. The recursive nature of the `reGenerateTreeItem` function call also enables the method to handle nested tree structures effectively. \\
 ## Code: 
 ```
void StrategyExplorer::item_expanded(const QModelIndex& index){
    TreeItem *item = static_cast<TreeItem*>(index.internalPointer());
    int num_child = item->childCount();
    for (int i = 0;i < num_child;i ++){
        TreeItem* one_child = item->child(i);
        if(one_child->childCount() != 0)continue;
        this->ui->gameTreeView->tree_model->reGenerateTreeItem(one_child->m_treedata.lock()->getRound(),one_child);
    }
}
```