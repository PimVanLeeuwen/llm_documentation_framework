`on_evModeButtom_clicked`: The function of `on_evModeButtom_clicked` is to switch the mode of the application's detail window to EV (Electric Vehicle) mode.

**Code Description**: 
The `on_evModeButtom_clicked` method is a slot function that is triggered when the "EV Mode" button is clicked. It updates the `mode` property of the `detailWindowSetting` object to `DetailWindowMode::EV`, which likely changes the display and functionality of the application's detail window, strategy table view, and rough strategy view to be relevant for electric vehicle mode. The method also updates the viewport of these views to reflect the new mode. \\
 ## Code: 
 ```
void StrategyExplorer::on_evModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::EV;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->ui->roughStrategyView->viewport()->update();
}
```