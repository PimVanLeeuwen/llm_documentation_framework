`on_riverCardBox_currentIndexChanged`: The function of `on_riverCardBox_currentIndexChanged` is to update the river card in the strategy model when the user selects a new card from the river card box.

**Parameters**:
`int index`: The index of the selected card in the cards list.

**Code Description**: This method is triggered when the current index changes in the river card box. It checks if there are cards available and if the selected index is within the bounds of the cards list. If so, it updates the river card in the strategy model with the selected card, recalculates the strategy data, and processes the board by splitting it into individual cards and displaying the resulting card collection in HTML format. Finally, it updates the UI to reflect the changes. \\
 ## Code: 
 ```
void StrategyExplorer::on_riverCardBox_currentIndexChanged(int index)
{
    if(this->cards.size() > 0  && index < this->cards.size()){
        this->tableStrategyModel->setRiverCard(this->cards[index]);
        this->tableStrategyModel->updateStrategyData();
        //this->roughStrategyViewerModel->onchanged();
        //this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```