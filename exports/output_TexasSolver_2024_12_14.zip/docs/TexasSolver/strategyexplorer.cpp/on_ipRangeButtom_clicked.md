`on_ipRangeButtom_clicked`: The function of `on_ipRangeButtom_clicked` is to handle the click event on the "IP Range" button.

**Code Description**: When the "IP Range" button is clicked, this method updates the detail window setting mode to display IP range information. It then refreshes the strategy table view and detail view by updating their respective viewport contents. Additionally, it triggers an update in the rough strategy viewer model by calling its `onchanged` method, which likely emits a signal to update the header data in the table model when its underlying data changes. Finally, it updates the rough strategy view's viewport content. \\
 ## Code: 
 ```
void StrategyExplorer::on_ipRangeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::RANGE_IP;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```