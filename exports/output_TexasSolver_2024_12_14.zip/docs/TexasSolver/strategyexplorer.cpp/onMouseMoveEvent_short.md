This code updates the grid coordinates in the `detailWindowSetting` object when a mouse move event occurs, and refreshes two UI views to reflect the new coordinates.

The `onMouseMoveEvent` method is called when a mouse move event occurs, likely within a graphical user interface (GUI) application.