`item_clicked`: The function of `item_clicked` is to process a tree click event in the Strategy Explorer.

**Parameters**:
`const QModelIndex& index`: A pointer to a QModelIndex object representing the clicked item in the tree view.

**Code Description**:

When the `item_clicked` method is called, it attempts to process the tree click event by casting the internal pointer of the QModelIndex object to a TreeItem pointer. If successful, it calls three methods: `process_treeclick`, `process_board`, and `updateStrategyData`. The `process_treeclick` method updates the node display label based on the type of game node clicked, while the `process_board` method processes a poker board by splitting it into individual cards. The `updateStrategyData` method is called to update the strategy data in the table model.

Additionally, the method sets the game tree node for the TableStrategyModel object using the `setGameTreeNode` method and triggers an update of the rough strategy viewer model using the `onchanged` method. Finally, it updates the viewport of the strategy table view and the rough strategy view to reflect any changes in the data.

If an error occurs during this process, a runtime_error exception is caught and logged using qDebug(). \\
 ## Code: 
 ```
void StrategyExplorer::item_clicked(const QModelIndex& index){
    try{
        TreeItem * treeNode = static_cast<TreeItem*>(index.internalPointer());
        this->process_treeclick(treeNode);
        this->process_board(treeNode);
        this->tableStrategyModel->setGameTreeNode(treeNode);
        this->tableStrategyModel->updateStrategyData();
        this->ui->strategyTableView->viewport()->update();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->triger_resize();
        this->ui->roughStrategyView->viewport()->update();
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```