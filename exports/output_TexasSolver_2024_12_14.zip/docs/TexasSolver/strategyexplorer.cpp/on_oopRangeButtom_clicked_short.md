When the "OOP Range" button is clicked, this method updates the UI to display a range-based detail view.

This code refreshes the table models and views in the Strategy Explorer window when the "OOP Range" mode is selected.