`on_turnCardBox_currentIndexChanged`: The function of `on_turnCardBox_currentIndexChanged` is to update the game state and strategy data when a new turn card is selected.

**Parameters**:
`int index`: The index of the selected turn card in the cards list.

**Code Description**: 
When the current index of the turn card box changes, this method checks if there are cards available and if the new index is within the valid range. If so, it updates the table strategy model with the new turn card and triggers an update of the strategy data. It then processes the poker board by splitting it into individual cards, adding community cards, and displaying the resulting card collection in HTML format. Finally, it updates the UI components to reflect the changes in the game state. \\
 ## Code: 
 ```
void StrategyExplorer::on_turnCardBox_currentIndexChanged(int index)
{
    if(this->cards.size() > 0 && index < this->cards.size()){
        this->tableStrategyModel->setTrunCard(this->cards[index]);
        this->tableStrategyModel->updateStrategyData();
        // TODO this somehow cause bugs, crashes, why?
        //this->roughStrategyViewerModel->onchanged();
        //this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```