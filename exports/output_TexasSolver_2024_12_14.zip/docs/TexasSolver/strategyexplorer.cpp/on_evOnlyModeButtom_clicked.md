`on_evOnlyModeButtom_clicked`: The function of `on_evOnlyModeButtom_clicked` is to switch the application's mode to EV (Electric Vehicle) only.

**Code Description**: This method, `on_evOnlyModeButtom_clicked`, is a slot function that responds to the click event of the "EV Only Mode" button. It updates the internal state of the `StrategyExplorer` object by setting its `detailWindowSetting.mode` to `DetailWindowMode::EV_ONLY`. Additionally, it triggers an update of the user interface components, including the strategy table view and detail view, as well as the rough strategy viewer model. The `onchanged` method is called on the rough strategy viewer model to notify it that its data has changed, which in turn updates the header data in the table model. \\
 ## Code: 
 ```
void StrategyExplorer::on_evOnlyModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::EV_ONLY;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```