`on_strategyModeButtom_clicked`: The function of `on_strategyModeButtom_clicked` is to switch the application's mode to strategy view.

**Code Description**: When the "strategyModeButton" is clicked, this method updates the detail window setting to display strategy-related information. It then refreshes the UI components that display strategy data, including the strategy table view and rough strategy viewer. Additionally, it triggers an update in the rough strategy viewer model by calling its `onchanged` method. This ensures that any changes in the underlying data are reflected in the viewer's display. \\
 ## Code: 
 ```
void StrategyExplorer::on_strategyModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::STRATEGY;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```