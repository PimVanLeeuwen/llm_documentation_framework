This method updates the UI components to reflect EV-only mode when a button is clicked.
It triggers a refresh of the table model and progress bar displays accordingly.