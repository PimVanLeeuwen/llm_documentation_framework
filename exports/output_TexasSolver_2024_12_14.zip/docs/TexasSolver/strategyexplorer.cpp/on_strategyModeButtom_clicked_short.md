This method updates the UI to display strategy mode when a button is clicked.
It triggers a refresh of the table model's header and updates several views in the UI.