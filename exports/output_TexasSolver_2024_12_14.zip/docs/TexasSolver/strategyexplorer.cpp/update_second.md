`update_second`: The function of `update_second` is to update various components of the poker game solver when a new second is reached in the game tree traversal.

**Code Description**: 
The `update_second` method updates several parts of the TexasSolver application when a new second has been processed. It first checks if there are any cards available, and if so, it triggers an update of the table strategy model, notifies the rough strategy viewer model that its data has changed, and refreshes the viewports of the rough strategy view and the detail view. Additionally, it calls the `process_board` method to process the current state of the game board, and finally updates the viewports of the strategy table view and the detail view. \\
 ## Code: 
 ```
void StrategyExplorer::update_second(){
    if(this->cards.size() > 0){
        this->tableStrategyModel->updateStrategyData();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```