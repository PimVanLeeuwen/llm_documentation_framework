`resizeEvent`: The function of `resizeEvent` is to handle the resize event of a QTableView, adjusting its column and row widths accordingly.

**Parameters**:
`QResizeEvent* ev`: A pointer to a QResizeEvent object that contains information about the new size of the view.

**Code Description**: 
The `resizeEvent` function is called when the user resizes the QTableView. It first checks if there is a model associated with the view, and if so, it retrieves the number of columns and rows in the model. If there are any columns, it calculates the width of each column as a percentage of the available width, taking into account the size of the new window. The last column's width is set to the remaining width. Similarly, if there are any rows, it calculates the height of each row as a percentage of the available height, and sets the last row's height to the remaining height. Finally, it calls the parent class's `resizeEvent` function to propagate the resize event further up the widget hierarchy. \\
 ## Code: 
 ```
void HtmlTableView::resizeEvent(QResizeEvent* ev){
    if(model() != NULL){
        int num_columns = this->model()->columnCount(QModelIndex());
        int num_rows = this->model()->rowCount(QModelIndex());
        if (num_columns > 0) {
        int width = ev->size().width();
        int used_width = 0;
        // Set our widths to be a percentage of the available width
        for (int i = 0; i < num_columns - 1; i++) {
            //int column_width = width / num_columns;
            int column_width = (int)((float)width * (i + 1) / num_columns) -  (int)((float)width * (i) / num_columns);
            this->setColumnWidth(i, column_width);
            used_width += column_width;
        }

        // Set our last column to the remaining width
        this->setColumnWidth(num_columns - 1, width - used_width);
        }
        if (num_columns > 0) {
        int height = ev->size().height();
        int used_height = 0;
        for (int i = 0; i < num_columns - 1; i++) {
            //int column_height = height / num_rows;
            int column_height = (int)((float)height * (i + 1) / num_rows) -  (int)((float)height * (i) / num_rows);
            this->setRowHeight(i, column_height);
            used_height += column_height;
        }
        this->setRowHeight(num_columns - 1, height - used_height);
        }
    }
    QTableView::resizeEvent(ev);
}
```