`eventFilter`: The function of `eventFilter` is to filter events for the HtmlTableView object and handle mouse move and leave events.

**Parameters**:
`QObject *watched`: The QObject that triggered the event.
`QEvent *event`: The QEvent that was triggered.

**Code Description**: 
The `eventFilter` method is a custom event filter function for the HtmlTableView class. It checks if the viewport of the table view matches the watched object, and if so, it handles mouse move events by checking if the mouse cursor has moved over a valid index in the table. If the index has changed, it emits an `itemMouseChange` signal with the new row and column indices. The method also returns true to indicate that the event was handled, allowing the parent class's event filter function to be called. \\
 ## Code: 
 ```
bool HtmlTableView::eventFilter(QObject *watched, QEvent *event){
    if(viewport() == watched){
        if(event->type() == QEvent::MouseMove){
        QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
        QModelIndex index = indexAt(mouseEvent->pos());
        if(index.isValid()){
            int i = index.row();
            int j = index.column();
            if(i != this->last_bearing_i || j != last_bearing_j){
                this->last_bearing_i = i;
                this->last_bearing_j = j;
                emit itemMouseChange(i,j);
            }
        }
        else{
        }
        }
        else if(event->type() == QEvent::Leave){
        }
    }
    return QTableView::eventFilter(watched, event);
}
```