**HtmlTableView**: The function of `HtmlTableView` is to create a custom QTableView widget that installs an event filter on its viewport and enables mouse tracking.

**Parameters**:
`QWidget *parent`: This parameter represents the parent widget of the HtmlTableView instance. It allows the HtmlTableView to be embedded within another GUI component, inheriting its properties and behavior.

**Code Description**: The `HtmlTableView` constructor initializes a QTableView object with the provided parent widget. It then installs an event filter on the viewport of the table view using the `installEventFilter` method. This enables the HtmlTableView to receive events and notifications from the underlying viewport. Finally, it sets mouse tracking to true using the `setMouseTracking` method, allowing the table view to track mouse movements even when no buttons are pressed. \\
 ## Code: 
 ```
HtmlTableView::HtmlTableView(QWidget *parent):
    QTableView(parent)
{
    viewport()->installEventFilter(this);
    setMouseTracking(true);
}
```