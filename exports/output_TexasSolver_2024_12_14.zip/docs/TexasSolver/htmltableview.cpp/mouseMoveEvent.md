`mouseMoveEvent`: The function of `mouseMoveEvent` is to handle mouse movement events in the HtmlTableView object.

**Parameters**:
`QMouseEvent *event`: This parameter represents a pointer to a QMouseEvent object, which contains information about the mouse event that occurred.

**Code Description**: 
The `mouseMoveEvent` method is responsible for updating the state of the HtmlTableView object based on the user's mouse movement. It takes a QMouseEvent object as input and performs the following actions:

1. It calculates the anchor at the current mouse position using the `anchorAt` method.
2. If the calculated anchor is different from the previously stored anchor, it clears the previous anchor and updates the new anchor.
3. If the last hovered anchor is different from the newly calculated anchor, it updates the last hovered anchor and emits a signal to indicate that a link has been hovered over or unhovered.
4. Depending on whether an anchor is being hovered over, it sets or restores the cursor to a pointing hand cursor.

The `mouseMoveEvent` method plays a crucial role in handling user interactions with the HtmlTableView object, allowing it to respond to mouse movements and provide visual feedback to the user. \\
 ## Code: 
 ```
void HtmlTableView::mouseMoveEvent(QMouseEvent *event) {
    auto anchor = anchorAt(event->pos());

    if (_mousePressAnchor != anchor) {
        _mousePressAnchor.clear();
    }

    if (_lastHoveredAnchor != anchor) {
        _lastHoveredAnchor = anchor;
        if (!_lastHoveredAnchor.isEmpty()) {
            QApplication::setOverrideCursor(QCursor(Qt::PointingHandCursor));
            emit linkHovered(_lastHoveredAnchor);
        } else {
            QApplication::restoreOverrideCursor();
            emit linkUnhovered();
        }
    }
}
```