This method triggers a resize event in the HtmlTableView object, causing it to adjust its layout based on the available space.

The `triger_resize` method creates a QResizeEvent and passes it to the `resizeEvent` method to initiate the resizing process.