`mouseReleaseEvent`: The function of `mouseReleaseEvent` is to handle the release event of a mouse button in the HtmlTableView class.

**Parameters**:
`QMouseEvent *event`: This parameter represents the mouse event that triggered the release event, containing information about the position and type of the event.

**Code Description**: 
The `mouseReleaseEvent` function first checks if an anchor was pressed previously. If so, it determines whether the current mouse release event is at the same anchor by calling the `anchorAt` method with the event's position. If they match, it emits a signal to indicate that the link has been activated and clears the stored press anchor. Finally, it calls the base class's `mouseReleaseEvent` function to propagate the event further up the widget hierarchy. \\
 ## Code: 
 ```
void HtmlTableView::mouseReleaseEvent(QMouseEvent *event) {
    if (!_mousePressAnchor.isEmpty()) {
        auto anchor = anchorAt(event->pos());

        if (anchor == _mousePressAnchor) {
            emit linkActivated(_mousePressAnchor);
        }

        _mousePressAnchor.clear();
    }

    QTableView::mouseReleaseEvent(event);
}
```