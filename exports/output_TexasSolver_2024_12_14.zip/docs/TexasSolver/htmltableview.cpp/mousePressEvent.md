`mousePressEvent`: The function of `mousePressEvent` is to handle mouse press events in the HtmlTableView object.

**Parameters**:
`QMouseEvent *event`: This parameter represents the mouse event that triggered the press event, containing information such as the position and type of the event.

**Code Description**: 
The `mousePressEvent` method first calls the parent class's `mousePressEvent` method to perform any necessary actions. Then, it calculates the anchor at the position of the mouse event using the `anchorAt` method. The calculated anchor is then stored in the `_mousePressAnchor` member variable for further use. This approach allows the HtmlTableView object to track and respond to user interactions with its contents. \\
 ## Code: 
 ```
void HtmlTableView::mousePressEvent(QMouseEvent *event) {
    QTableView::mousePressEvent(event);

    auto anchor = anchorAt(event->pos());
    _mousePressAnchor = anchor;
}
```