`triger_resize`: The function of `triger_resize` is to trigger a resize event in the HtmlTableView object, causing it to adjust its column widths and row heights based on the available space.

**Code Description**: 
The `triger_resize` method creates a new QResizeEvent object with the current size of the HtmlTableView as both the old and new sizes. It then calls the `resizeEvent` method on itself, passing in the newly created event. This triggers the resize event, which is handled by the `resizeEvent` method to adjust the column widths and row heights accordingly. The QResizeEvent object is then deleted to free up memory. \\
 ## Code: 
 ```
void HtmlTableView::triger_resize(){
    QResizeEvent* ev = new QResizeEvent(this->size(),this->size());
    this->resizeEvent(ev);
    //this->resize(this->parentWidget()->size());
    delete ev;
}
```