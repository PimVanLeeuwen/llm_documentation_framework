**on_confirmBox_accepted**: The function of `on_confirmBox_accepted` is to save the user's settings when a confirmation box is accepted.

**Code Description**: This method, `on_confirmBox_accepted`, is responsible for storing the user's preferences in the application's settings. It retrieves the current language and round values from the UI elements (`languageBox` and `roundBox`) and saves them as "language" and "dump_round" respectively in a QSettings object with the group name "solver". The language value is converted to its corresponding string representation ("EN" for English, "CN" for Chinese). If an unknown language is selected, it logs an error message. \\
 ## Code: 
 ```
void SettingEditor::on_confirmBox_accepted()
{
    QSettings setting("TexasSolver", "Setting");
    setting.beginGroup("solver");
    QString lang = this->ui->languageBox->currentText();
    QString language_str;
    if(lang == "English"){
        language_str = "EN";
    }else if(lang == "Chinese"){
        language_str = "CN";
    }else{
        qDebug().noquote() << tr("Unknown language: ") << lang << tr("Setting fail");
    }
    setting.setValue("language",language_str);

    int round = this->ui->roundBox->currentText().toInt();
    setting.setValue("dump_round",round);
}
```