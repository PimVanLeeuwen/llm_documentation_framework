**on_confirmButton_clicked**: The function of `on_confirmButton_clicked` is to handle the click event on a confirm button.

**Code Description**: When the confirm button is clicked, this method updates the text in the `boardEdit` field with the current text from the UI's `boardEdit` field and then closes the window. \\
 ## Code: 
 ```
void boardselector::on_confirmButton_clicked()
{
    this->boardEdit->setText(this->ui->boardEdit->text());
    this->close();
}
```