`on_cancelButton_clicked`: The function of `on_cancelButton_clicked` is to close the current window when the cancel button is clicked.

**Code Description**: 
The `on_cancelButton_clicked` method is a signal slot function that gets triggered when the cancel button on the board selector UI is clicked. It simply calls the `close()` method on the current object (`this`) which results in the window being closed, effectively cancelling any ongoing operation or selection process initiated by the user. This method does not perform any data validation or modification; it merely terminates the current interaction session with the user. \\
 ## Code: 
 ```
void boardselector::on_cancelButton_clicked()
{
    this->close();
}
```