This method handles the click event on a confirmation button, updating the board edit text field and closing the current window.

The `on_confirmButton_clicked` method updates the local `boardEdit` text with the value from the UI's `boardEdit` field and then closes the current window.