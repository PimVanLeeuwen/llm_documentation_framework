`boardselector`: The function of `boardselector` is to create a dialog window for selecting a board in a Texas Hold'em or Short Deck poker game.

**Parameters**:
- `QTextEdit* boardEdit`: A pointer to a text edit widget where the selected board will be displayed.
- `QSolverJob::Mode mode`: An enumeration value specifying the type of poker game being played (either HOLDEM or SHORTDECK).
- `QWidget *parent`: A pointer to the parent widget that owns this dialog window.

**Code Description**: The `boardselector` function initializes a dialog window with a table model and delegate for displaying and selecting a board. It sets up the UI, populates the rank list based on the specified game mode, creates a table model and delegate, and connects them to the UI components. If an invalid game mode is provided, it throws a runtime error. 
## Code: 
 ```
boardselector::boardselector(QTextEdit* boardEdit,QSolverJob::Mode mode,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::boardselector)
{
    ui->setupUi(this);
    this->setWindowTitle(tr("BoardSelector"));
    this->boardEdit = boardEdit;
    this->mode = mode;

    QString ranks;
    if(mode == QSolverJob::Mode::HOLDEM){
        ranks = "A,K,Q,J,T,9,8,7,6,5,4,3,2";
    }else if(mode == QSolverJob::Mode::SHORTDECK){
        ranks = "A,K,Q,J,T,9,8,7,6";
    }else{
        throw runtime_error("mode not found in range selector");
    }
    this->rank_list = ranks.split(",");

    this->boardSelectorTableModel = new BoardSelectorTableModel(this->rank_list,boardEdit->toPlainText(),this);
    this->ui->boardSelectorTable->setModel(boardSelectorTableModel);
    this->boardSelectorTableDelegate = new BoardSelectorTableDelegate(this->rank_list,this->boardSelectorTableModel,this);
    this->ui->boardSelectorTable->setItemDelegate(this->boardSelectorTableDelegate);
    this->ui->boardEdit->setText(boardEdit->toPlainText());
}
```