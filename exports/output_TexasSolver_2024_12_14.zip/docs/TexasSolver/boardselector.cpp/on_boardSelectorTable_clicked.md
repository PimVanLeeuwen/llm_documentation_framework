`on_boardSelectorTable_clicked`: The function of `on_boardSelectorTable_clicked` is to handle the click event on a table cell in the board selector.

**Parameters**:
`const QModelIndex &index`: This parameter represents the index of the clicked table cell, containing information about its row and column position.

**Code Description**: 
This method is triggered when a user clicks on a cell in the `boardSelectorTable`. It retrieves the row and column indices of the clicked cell using the `row()` and `column()` methods. The `setBoardAt` method from the `boardSelectorTableModel` is then called to toggle the value at the specified row and column in the board grid, effectively selecting or deselecting a board position.

If the text in the `boardEdit` field does not match the current board text retrieved by calling `getBoardText` on the `boardSelectorTableModel`, it updates the `boardEdit` field with the new board text. Finally, it sets focus to both the `boardEdit` and `boardSelectorTable` widgets. \\
 ## Code: 
 ```
void boardselector::on_boardSelectorTable_clicked(const QModelIndex &index)
{
    int row = index.row();
    int col = index.column();
    this->boardSelectorTableModel->setBoardAt(row,col,1 - this->boardSelectorTableModel->getBoardAt(row,col));
    if(this->ui->boardEdit->text() != this->boardSelectorTableModel->getBoardText()){
        this->ui->boardEdit->setText(this->boardSelectorTableModel->getBoardText());
    }
    this->ui->boardEdit->setFocus();
    this->ui->boardSelectorTable->setFocus();
}
```