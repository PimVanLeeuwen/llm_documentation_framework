This method calculates the Julian Cycle value for a given date and longitude east.
It returns a rounded float representing this cycle value.