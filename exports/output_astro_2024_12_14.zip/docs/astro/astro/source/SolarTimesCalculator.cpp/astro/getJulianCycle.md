`getJulianCycle`: The function of `getJulianCycle` is to calculate the Julian cycle number for a given date and longitude.

**Parameters**:
`const JulianDate &date`: A reference to a JulianDate object representing the date for which the Julian cycle number is to be calculated.
`angle_type longitudeEast`: An angle representing the longitude east of the planet's center, used in conjunction with the date to calculate the Julian cycle number.

**Code Description**: The `getJulianCycle` function takes a JulianDate and an angle representing longitude east as input, and returns the corresponding Julian cycle number. It does this by subtracting the J0 value for the specified planet from the truncated 2000 year value of the date, dividing the result by the J3 value for the planet, adding half the longitude east divided by 2π radians, and rounding the final result to the nearest integer using `std::round`. The resulting value represents the Julian cycle number. \\
## Code: 
```
static float_type getJulianCycle(const JulianDate &date, angle_type longitudeEast) {
    return std::round(
        (date.truncated2000() - C::get<PLANET, C::J0>()) / C::get<PLANET, C::J3>() +
         longitudeEast / 2_pi_rad);
  }
```