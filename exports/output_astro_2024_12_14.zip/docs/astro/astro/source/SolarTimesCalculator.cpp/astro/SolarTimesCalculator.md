`SolarTimesCalculator`: The function of `SolarTimesCalculator` is to calculate the solar times for a given planet.

**Parameters**:
`const Sun<PLANET> &sun`: A reference to a `Sun` object representing the sun's position and properties for the specified planet.

**Code Description**: 
The `SolarTimesCalculator` constructor initializes an instance of the calculator by taking in a `Sun` object as input. It uses this information to calculate the solar transit time, Julian cycle value, and stores them in member variables `_transit`, `_cycle`, and `_sun` respectively. The `calculateSolarTransit` method is called with an initial hour angle of 0 radians to determine the solar transit time for the given planet. The `getJulianCycle` method is used to calculate the Julian cycle value based on the date and longitude east of the observer's position, which is obtained from the input `Sun` object. This information is then stored in the `_cycle` member variable. \\
## Code: 
```
SolarTimesCalculator<PLANET>::SolarTimesCalculator(const Sun<PLANET> &sun) :
    _sun(sun),
    _cycle(getJulianCycle<PLANET>(
        _sun._observer.getDate(),
        _sun._observer.getPosition().longitude)),
    _transit(calculateSolarTransit(0_rad)) {}
```