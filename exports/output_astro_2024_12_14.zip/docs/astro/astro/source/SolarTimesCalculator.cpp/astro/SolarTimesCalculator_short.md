The SolarTimesCalculator class initializes its internal state based on a given Sun object, calculating the Julian Cycle and solar transit time for a specified planet.

This code sets up the necessary parameters for further calculations related to solar times, such as transits and cycles, using input from a Sun object and planetary constants.