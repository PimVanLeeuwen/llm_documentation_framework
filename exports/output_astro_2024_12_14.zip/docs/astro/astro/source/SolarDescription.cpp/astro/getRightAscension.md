`getRightAscension`: The function of `getRightAscension` is to calculate the right ascension of a celestial object.

**Code Description**: 
The `getRightAscension` method is a part of the SolarDescription class, which is used to describe solar system objects. This method calculates the right ascension of a celestial object given its ecliptical longitude and obliquity (the angle between the Earth's equator and its orbit around the Sun). The calculation is performed using the `rightAscension` function from the Trigonometry class, which takes into account the longitude, latitude, and ecliptic longitude to return the result in radians. This method does not take any parameters other than those inherited from the SolarDescription class and returns an angle_type value representing the right ascension of the celestial object. \\
## Code: 
```
angle_type SolarDescription<PLANET>::getRightAscension() const {
    return Trigonometry::rightAscension(_eclipticalLongitude, C::get<PLANET, C::Obliquity>());
  }
```