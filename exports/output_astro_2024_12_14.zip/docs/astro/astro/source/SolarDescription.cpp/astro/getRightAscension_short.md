The `getRightAscension` method calculates the right ascension of a celestial object given its ecliptical longitude, using trigonometric calculations.

This method returns the result in radians, utilizing the `rightAscension` function from the Trigonometry module.