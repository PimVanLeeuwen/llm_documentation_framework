**SolarDescription**: The function of `SolarDescription` is to calculate the solar description for a given planet at a specified date.

**Parameters**:
`const JulianDate &date`: A reference to a `JulianDate` object representing the date for which the solar description is to be calculated.

**Code Description**:

The `SolarDescription` function calculates the mean anomaly, equation of the center, and ecliptical longitude of a planet at a given date. It uses the Julian Date system to represent time, where J2000 is the reference epoch (January 1, 2000).

The calculation involves several steps:

*   The mean anomaly `_meanAnomaly` is calculated using the formula `M = M0 + M1 (J - J2000)`, where `M0` and `M1` are constants specific to each planet.
*   The equation of the center `_equationOfTheCenter` is calculated using a trigonometric series involving sine functions, with coefficients `C1` through `C6` that depend on the planet.
*   The ecliptical longitude `_eclipticalLongitude` is calculated by adding the mean anomaly, equation of the center, perihelion correction, and a constant value (180 degrees) to the mean anomaly.

The function uses the `C::get<PLANET, CONSTANT>()` syntax to retrieve planet-specific constants from a lookup table. The `Sin()` function is used to calculate sine values for the mean anomalies involved in the equation of the center calculation.

Overall, the `SolarDescription` function provides a way to compute the solar description (mean anomaly, equation of the center, and ecliptical longitude) for any planet at a specified date using the Julian Date system. \\
## Code: 
```
SolarDescription<PLANET>::SolarDescription(const JulianDate &date) {
    // M = M0 + M1 (J - J2000)
    _meanAnomaly = C::get<PLANET, C::M0>() + C::get<PLANET, C::M1>() * date.truncated2000();
    // C ~ C1 sin(M) + C2 sin(2M) + C3 sin(3M) + C4 sin(4M) + C5 sin(5M) + C6 sin(6M)
    _equationOfTheCenter = C::get<PLANET, C::C1>() * Sin(_meanAnomaly) +
                           C::get<PLANET, C::C2>() * Sin(2.0 * _meanAnomaly) +
                           C::get<PLANET, C::C3>() * Sin(3.0 * _meanAnomaly) +
                           C::get<PLANET, C::C4>() * Sin(4.0 * _meanAnomaly) +
                           C::get<PLANET, C::C5>() * Sin(5.0 * _meanAnomaly) +
                           C::get<PLANET, C::C6>() * Sin(6.0 * _meanAnomaly);
    // l = M + C + Perihelion + 180
    _eclipticalLongitude = _meanAnomaly + _equationOfTheCenter + C::get<PLANET, C::Perihelion>() + 1_pi_rad;
  }
```