This method calculates the total number of seconds in a day.
It returns a constant value representing 24 hours multiplied by 3600 seconds per hour.