`secondsInADay`: The function of `secondsInADay` is to calculate the total number of seconds in a day.

**Code Description**: This method returns the total number of seconds in a 24-hour period, which is calculated by multiplying the number of hours (24) by the number of seconds in an hour (3600). The result is a constant value representing the total number of seconds in a day. \\
## Code: 
```
static constexpr long unsigned secondsInADay() {
    return 24 * 3600;
  }
```