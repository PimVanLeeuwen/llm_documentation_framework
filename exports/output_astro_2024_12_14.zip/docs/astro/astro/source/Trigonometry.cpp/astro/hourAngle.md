## Expected output
`hourAngle`: The function of `hourAngle` is to calculate the hour angle of a celestial object given its altitude, declination, and latitude.

**Parameters**:
`angle_type alt`: The altitude of the celestial object above the horizon.
`angle_type dec`: The declination (angular distance from the celestial equator) of the celestial object.
`angle_type lat`: The latitude of the observer's location on Earth.

**Code Description**: 
The `hourAngle` function uses trigonometric functions to calculate the hour angle. It takes three parameters: `alt`, `dec`, and `lat`. The function returns an angle value representing the hour angle. The calculation involves using the sine, cosine, and arccosine (ACos) of these angles to determine the hour angle. This is a mathematical operation commonly used in astronomy to calculate the position of celestial objects relative to observers on Earth. \\
## Code: 
```
angle_type Trigonometry::hourAngle(angle_type alt, angle_type dec, angle_type lat) {
    return ACos((Sin(alt) - Sin(dec) * Sin(lat)) / (Cos(dec) * Cos(lat)));
  }
```