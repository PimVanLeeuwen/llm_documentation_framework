`rightAscension`: The function of `rightAscension` is to calculate the right ascension of a celestial object given its longitude, latitude, and ecliptic longitude.

**Parameters**:
`angle_type l`: The longitude of the celestial object.
`angle_type b`: The latitude of the celestial object.
`angle_type e`: The ecliptic longitude of the celestial object.

**Code Description**: 
The `rightAscension` function uses the ATan2 and trigonometric functions (Sin, Cos, Tan) to calculate the right ascension. It takes in three parameters: the longitude (`l`), latitude (`b`), and ecliptic longitude (`e`) of a celestial object. The function returns the calculated right ascension as an `angle_type`. 

The calculation involves using the formula for right ascension, which is based on the given coordinates. The ATan2 function is used to calculate the arctangent of a ratio, and the Sin, Cos, and Tan functions are used to perform trigonometric calculations. The result is then returned as the calculated right ascension.

This function appears to be part of an astronomy-related project, where it's used to calculate the position of celestial objects in the sky. \\
## Code: 
```
angle_type Trigonometry::rightAscension(angle_type l, angle_type b, angle_type e) {
    return ATan2(Sin(l) * Cos(e) - Tan(b) * Sin(e), Cos(l));
  }
```