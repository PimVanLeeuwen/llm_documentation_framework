**azimuth**: The function of `azimuth` is to calculate the azimuth angle between a celestial object and an observer's location.

**Parameters**:
- `angle_type h`: The hour angle, which represents the difference between the local sidereal time and the right ascension of the celestial object.
- `angle_type decl`: The declination, which represents the angular distance of the celestial object from the celestial equator.
- `angle_type lat`: The latitude of the observer's location.

**Code Description**: 
The `azimuth` function uses trigonometric functions to calculate the azimuth angle. It takes into account the hour angle (`h`), declination (`decl`), and latitude (`lat`) as inputs. The formula used is based on the definition of the atan2 function, which returns the principal value of the arctangent of `y/x`, where `x` and `y` are the input values. In this case, `x` is calculated as `Cos(h) * Sin(lat) - Tan(decl) * Cos(lat)` and `y` is simply `Sin(h)`. The result is a value in the range `-π` to `π`, representing the azimuth angle in radians. \\
## Code: 
```
angle_type Trigonometry::azimuth(angle_type h, angle_type decl, angle_type lat) {
    return ATan2(Sin(h), Cos(h) * Sin(lat) - Tan(decl) * Cos(lat));
  }
```