**altitude**: The function of `altitude` is to calculate the altitude angle between a celestial object and an observer's horizon.

**Parameters**:
- `angle_type h`: The hour angle, which represents the difference in right ascension between the celestial object and the observer's local meridian.
- `angle_type decl`: The declination of the celestial object, representing its angular distance from the celestial equator.
- `angle_type lat`: The latitude of the observer's location on Earth.

**Code Description**: 
The `altitude` function uses trigonometric functions to compute the altitude angle. It takes into account the hour angle (`h`), declination (`decl`) of the celestial object, and the latitude (`lat`) of the observer. The calculation involves the use of sine (Sin) and cosine (Cos) functions in a formula that represents the relationship between these angles. Specifically, it applies the formula `ASin(Cos(h) * Cos(decl) * Cos(lat) + Sin(decl) * Sin(lat))` to determine the altitude angle. This mathematical operation is fundamental in astronomy for determining the position of celestial objects relative to an observer's location on Earth. \\
## Code: 
```
angle_type Trigonometry::altitude(angle_type h, angle_type decl, angle_type lat) {
    return ASin(Cos(h) * Cos(decl) * Cos(lat) + Sin(decl) * Sin(lat));
  }
```