This method calculates the azimuth angle between a celestial object and an observer on Earth, given their hour angle, declination, and latitude.

The `azimuth` function takes three angles as input: hour angle (h), declination (decl), and latitude (lat), and returns the calculated azimuth angle.