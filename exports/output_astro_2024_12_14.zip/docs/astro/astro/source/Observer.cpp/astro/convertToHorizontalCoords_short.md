The `convertToHorizontalCoords` method converts equatorial coordinates to horizontal coordinates for a celestial object, given its position on Earth.

This conversion involves calculating hour angle, azimuth, and altitude angles using trigonometric functions based on input values such as right ascension, declination, latitude, and longitude.