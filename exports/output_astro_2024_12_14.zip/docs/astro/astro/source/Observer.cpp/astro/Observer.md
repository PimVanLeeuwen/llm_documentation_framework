`Observer`: The function of `Observer` is to initialize an observer object with a specified date and position.

**Parameters**:
- `const JulianDate &date`: This parameter represents the date for which the observer's information will be calculated.
- `const GeographicalCoords &position`: This parameter specifies the geographical coordinates (longitude) at which the observer is located.

**Code Description**: The `Observer` constructor initializes an instance of the `Observer` class by setting its member variables `_date`, `_position`, and `_siderealTime`. It uses the `getSiderealTime` method to calculate the sidereal time for a given date and longitude, taking into account the specified longitude. \\
## Code: 
```
Observer<PLANET>::Observer(const JulianDate &date, const GeographicalCoords &position) :
    _date(date),
    _position(position),
    _siderealTime(astro::getSiderealTime<PLANET>(_date, _position.longitude)) {}
```