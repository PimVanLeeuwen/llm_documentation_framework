`convertToHorizontalCoords`: The function of `convertToHorizontalCoords` is to convert equatorial coordinates into horizontal coordinates.

**Parameters**:
`const EquatorialCoords &ec`: This parameter represents the equatorial coordinates that need to be converted, including right ascension and declination.

**Code Description**: 
The `convertToHorizontalCoords` method takes in a constant reference to an `EquatorialCoords` object as input. It calculates the hour angle using the `convertToHourAngle` function from the Trigonometry class. Then, it uses the calculated hour angle along with the declination and latitude of the observer's position to compute the azimuth and altitude angles using the corresponding functions from the Trigonometry class. The resulting horizontal coordinates are then returned as a HorizontalCoords object. \\
## Code: 
```
HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }
```