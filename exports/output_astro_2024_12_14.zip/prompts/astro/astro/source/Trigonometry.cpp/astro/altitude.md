# PROMPT
## Instruction
You are an AI docs assistant. Your task is to generate clear, concise docs for the given code of an 
object to help developers and beginners understand its function and usage.
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/Trigonometry.cpp/astro` \
**Type:** `Method` \
**Method Name:** `altitude` \
**Code Content:** \
`angle_type Trigonometry::altitude(angle_type h, angle_type decl, angle_type lat) {
    return ASin(Cos(h) * Cos(decl) * Cos(lat) + Sin(decl) * Sin(lat));
  }`






## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`altitude`: The function of `altitude` is *FILL IN* \
**Parameters**:\
`angle_type h`: *FILL IN* \
`angle_type decl`: *FILL IN* \
`angle_type lat`: *FILL IN* \

**Code Description**: *FILL IN*
