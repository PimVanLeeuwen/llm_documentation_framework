# PROMPT
## Instruction
You are an AI docs assistant. Your task is to generate clear, concise docs for the given code of an 
object to help developers and beginners understand its function and usage.
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/Trigonometry.cpp/astro` \
**Type:** `Method` \
**Method Name:** `rightAscension` \
**Code Content:** \
`angle_type Trigonometry::rightAscension(angle_type l, angle_type b, angle_type e) {
    return ATan2(Sin(l) * Cos(e) - Tan(b) * Sin(e), Cos(l));
  }`






## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`rightAscension`: The function of `rightAscension` is *FILL IN* \
**Parameters**:\
`angle_type l`: *FILL IN* \
`angle_type b`: *FILL IN* \
`angle_type e`: *FILL IN* \

**Code Description**: *FILL IN*
