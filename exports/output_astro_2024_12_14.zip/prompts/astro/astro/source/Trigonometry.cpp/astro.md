# PROMPT
## Instruction
You are an AI docs assistant. Your task is to generate clear, concise docs for the given code of an 
object to help developers and beginners understand its function and usage.
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/Trigonometry.cpp` \
**Type:** `Class` \
**Class Name:** `astro` \
**Code Content:** \
`namespace astro {

  using namespace astro::math;

  angle_type Trigonometry::declination(angle_type l, angle_type e) {
    return ASin(Sin(e) * Sin(l));
  }

  angle_type Trigonometry::rightAscension(angle_type l, angle_type e) {
    return ATan2(Sin(l) * Cos(e), Cos(l));
  }

  angle_type Trigonometry::declination(angle_type l, angle_type b, angle_type e) {
    return ASin(Sin(b) * Cos(e) + Cos(b) * Sin(e) * Sin(l));
  }

  angle_type Trigonometry::rightAscension(angle_type l, angle_type b, angle_type e) {
    return ATan2(Sin(l) * Cos(e) - Tan(b) * Sin(e), Cos(l));
  }

  angle_type Trigonometry::azimuth(angle_type h, angle_type decl, angle_type lat) {
    return ATan2(Sin(h), Cos(h) * Sin(lat) - Tan(decl) * Cos(lat));
  }

  angle_type Trigonometry::altitude(angle_type h, angle_type decl, angle_type lat) {
    return ASin(Cos(h) * Cos(decl) * Cos(lat) + Sin(decl) * Sin(lat));
  }

  angle_type Trigonometry::hourAngle(angle_type alt, angle_type dec, angle_type lat) {
    return ACos((Sin(alt) - Sin(dec) * Sin(lat)) / (Cos(dec) * Cos(lat)));
  }

}`



## Children \
 This code contains the following methods/classes: \
### astro/astro/source/Trigonometry.cpp/astro.declination \
### astro/astro/source/Trigonometry.cpp/astro.rightAscension \
### astro/astro/source/Trigonometry.cpp/astro.declination \
### astro/astro/source/Trigonometry.cpp/astro.rightAscension \
### astro/astro/source/Trigonometry.cpp/astro.azimuth \
### astro/astro/source/Trigonometry.cpp/astro.altitude \
### astro/astro/source/Trigonometry.cpp/astro.hourAngle \



## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`astro`: The function of `astro` is *FILL IN* \

**Code Description**: *FILL IN*
