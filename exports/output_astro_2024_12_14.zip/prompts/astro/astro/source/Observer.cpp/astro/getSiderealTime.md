# PROMPT
## Instruction
You are an AI docs assistant. Your task is to generate clear, concise docs for the given code of an 
object to help developers and beginners understand its function and usage.
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/Observer.cpp/astro` \
**Type:** `Method` \
**Method Name:** `getSiderealTime` \
**Code Content:** \
`static angle_type getSiderealTime(const JulianDate &date, angle_type longitudeEast) {
    using C = Constant;
    // Theta = Theta0 + Theta1 (J - J2000) - l_west
    return C::get<PLANET, C::Theta0>() +
           C::get<PLANET, C::Theta1>() * date.truncated2000() +
           longitudeEast;
  }`






## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`getSiderealTime`: The function of `getSiderealTime` is *FILL IN* \
**Parameters**:\
`const JulianDate &date`: *FILL IN* \
`angle_type longitudeEast`: *FILL IN* \

**Code Description**: *FILL IN*
