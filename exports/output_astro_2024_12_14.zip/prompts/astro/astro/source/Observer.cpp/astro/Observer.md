# PROMPT
## Instruction
You are an AI docs assistant. Your task is to generate clear, concise docs for the given code of an 
object to help developers and beginners understand its function and usage.
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/Observer.cpp/astro` \
**Type:** `Method` \
**Method Name:** `Observer` \
**Code Content:** \
`Observer<PLANET>::Observer(const JulianDate &date, const GeographicalCoords &position) :
    _date(date),
    _position(position),
    _siderealTime(astro::getSiderealTime<PLANET>(_date, _position.longitude)) {}`

## Calls \
 This code calls the following methods within the repository: \
### astro/astro/source/Observer.cpp/astro.getSiderealTime \
 - Explanation:  _This method calculates the sidereal time for a given date and longitude east.
It uses constants and a Julian date to compute the result, taking into account the specified longitude._ \





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`Observer`: The function of `Observer` is *FILL IN* \
**Parameters**:\
`const JulianDate &date`: *FILL IN* \
`const GeographicalCoords &position`: *FILL IN* \

**Code Description**: *FILL IN*
