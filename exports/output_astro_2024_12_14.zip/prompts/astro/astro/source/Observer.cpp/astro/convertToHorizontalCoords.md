# PROMPT
## Instruction
You are an AI docs assistant. Your task is to generate clear, concise docs for the given code of an 
object to help developers and beginners understand its function and usage.
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/Observer.cpp/astro` \
**Type:** `Method` \
**Method Name:** `convertToHorizontalCoords` \
**Code Content:** \
`HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }`

## Calls \
 This code calls the following methods within the repository: \
### astro/astro/source/Trigonometry.cpp/astro.hourAngle \
 - Explanation:  _This method calculates the hour angle in astronomy, given altitude, declination, and latitude angles.
It uses trigonometric functions to compute the hour angle based on the input values._ \
### astro/astro/source/Trigonometry.cpp/astro.altitude \
 - Explanation:  _This method calculates the altitude angle using the given height, declination, and latitude values.
It returns the calculated altitude angle in radians._ \
### astro/astro/source/Trigonometry.cpp/astro.azimuth \
 - Explanation:  _This method calculates the azimuth angle between a celestial object and an observer on Earth, given their hour angle, declination, and latitude.

The `azimuth` function takes three angles as input: hour angle (h), declination (decl), and latitude (lat), and returns the calculated azimuth angle._ \
### astro/astro/source/Trigonometry.cpp/astro.declination \
 - Explanation:  _This method calculates the declination angle given latitude, altitude, and east longitude. It uses trigonometric functions to compute the result._ \
### astro/astro/source/Trigonometry.cpp/astro.rightAscension \
 - Explanation:  _This method calculates the right ascension of a celestial object given its longitude, latitude, and ecliptic longitude. It returns the result in radians._ \





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`convertToHorizontalCoords`: The function of `convertToHorizontalCoords` is *FILL IN* \
**Parameters**:\
`const EquatorialCoords &ec`: *FILL IN* \

**Code Description**: *FILL IN*
