# PROMPT
## Instruction
You are an AI docs assistant. Your task is to generate clear, concise docs for the given code of an 
object to help developers and beginners understand its function and usage.
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/Observer.cpp` \
**Type:** `Class` \
**Class Name:** `astro` \
**Code Content:** \
`namespace astro {

  template <Planet PLANET>
  static angle_type getSiderealTime(const JulianDate &date, angle_type longitudeEast) {
    using C = Constant;
    // Theta = Theta0 + Theta1 (J - J2000) - l_west
    return C::get<PLANET, C::Theta0>() +
           C::get<PLANET, C::Theta1>() * date.truncated2000() +
           longitudeEast;
  }

  template <Planet PLANET>
  Observer<PLANET>::Observer(const JulianDate &date, const GeographicalCoords &position) :
    _date(date),
    _position(position),
    _siderealTime(astro::getSiderealTime<PLANET>(_date, _position.longitude)) {}

  template <Planet PLANET>
  HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }

  ASTRO_TEMPLATE_CLASS_INSTANTIATE_FOR_EACH_PLANET(Observer);

}`



## Children \
 This code contains the following methods/classes: \
### astro/astro/source/Observer.cpp/astro.getSiderealTime \
### astro/astro/source/Observer.cpp/astro.Observer \
### astro/astro/source/Observer.cpp/astro.convertToHorizontalCoords \



## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`astro`: The function of `astro` is *FILL IN* \

**Code Description**: *FILL IN*
