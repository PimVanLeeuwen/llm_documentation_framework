`actionPerformed`: The function of `actionPerformed` is to perform an action when a specific event occurs.
**Parameters**: 
`ActionEvent e`: This parameter represents the event that triggered the action.
**Code Description**: When the `actionPerformed` method is called, it hides the GUI frame and displays a message indicating that the "HEAP SORT" algorithm has been visited.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
				obj.vis(6,"HEAP SORT");
				frame.setVisible(false);
			}
```