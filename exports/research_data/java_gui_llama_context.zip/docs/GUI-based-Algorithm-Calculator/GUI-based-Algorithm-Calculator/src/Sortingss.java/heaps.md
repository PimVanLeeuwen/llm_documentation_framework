The function of `heaps` is to implement a heap sort algorithm for sorting an array of integers in ascending order.

**Code Description**: 
The code defines a class named `heaps` with two methods: `heapify` and `heapSort`. The `heapify` method is used to maintain the heap property in a subtree rooted at index `i`, while the `heapSort` method uses the `heapify` method to sort an entire array. 

The `heapify` method takes three parameters: `num[]` (the array to be sorted), `size` (the size of the array), and `i` (the index of the current subtree). It first checks if the left or right child of the current node is larger than the current node, and if so, it swaps the values and recursively calls itself on the affected subtree.

The `heapSort` method takes two parameters: `num[]` (the array to be sorted) and `size` (the size of the array). It first calls the `heapify` method on each non-leaf node in the heap, starting from the last internal node. Then it repeatedly swaps the root of the heap with the last element, reduces the size of the heap by one, and calls the `heapify` method on the reduced heap to maintain the heap property.

The analysis of this code is that it correctly implements a heap sort algorithm using the `heapify` method to maintain the heap property. The time complexity of the `heapSort` method is O(n log n), where n is the size of the array, because each call to the `heapify` method reduces the size of the heap by at least half.\\
## Code: 
```
class heaps{
	void heapify(int num[], int size, int i)
    {
        int largest = i;
        int left = 2*i + 1;
        int right = 2*i + 2;

        if (left < size && num[left] >num[largest])
            largest = left;

        if (right < size && num[right] > num[largest])
            largest = right;

        if (largest != i)
        {
        	int temp;
            temp = num[i];
            num[i]= num[largest];
            num[largest] = temp;
            heapify(num, size, largest);
        }
    }
 
	
	void heapSort(int num[], int size)
	    {
	        int i;
	        for (i = size / 2 - 1; i >= 0; i--)
	            heapify(num, size, i);
	        for (i=size-1; i>=0; i--)
	        {
	        	int temp;
	            temp = num[0];
	            num[0]= num[i];
	            num[i] = temp;
	            heapify(num, i, 0);
	        }
	     }
	       
}
```