**The function of `vis` is to make a GUI window visible and set the key value.**

**Parameters:**
- `int k`: This parameter represents an integer key value.
- `String str`: This parameter represents a string variable that will be used to update the title name of the GUI window.

**Code Description:** The `vis` function takes two parameters, an integer `k` and a string `str`. It sets the key value to `k`, then updates the title name of the GUI window using the string `str`. Finally, it makes the GUI window visible by calling the `setVisible(true)` method on the `frame` object. The function returns 0, indicating successful execution.\\
## Code: 
```
int vis(int k,String str){
		key=k;
		tname="Hello";
		tname="pop";
		tname=str;
		frame.setVisible(true);
		return 0;
	}
```