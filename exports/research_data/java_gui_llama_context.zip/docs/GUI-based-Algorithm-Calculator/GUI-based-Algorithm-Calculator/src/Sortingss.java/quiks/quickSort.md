## Expected output
`quickSort`: The function of `quickSort` is to recursively sort an array of integers using the Quicksort algorithm.
**Parameters**:\
`int[] num`: This parameter represents the array of integers that needs to be sorted.
`int start`: This parameter specifies the starting index of the subarray within `num` that should be sorted.
`int end`: This parameter specifies the ending index of the subarray within `num` that should be sorted.

**Code Description**: The code implements a recursive Quicksort algorithm, where it first calls the `partition` method to rearrange elements in the array such that all elements less than the pivot are on its left and all elements greater are on its right. It then recursively sorts the subarrays of elements before and after the pivot using the same approach until the entire array is sorted.\\
## Code: 
```
void quickSort(int[] num, int start, int end)
	 {
	    int partition = partition(num, start, end);
        if(partition-1>start)
        {
        	quickSort(num, start, partition - 1);
        }
    	if(partition+1<end) 
    	{
    		quickSort(num, partition + 1, end);
    	}
	 }
```