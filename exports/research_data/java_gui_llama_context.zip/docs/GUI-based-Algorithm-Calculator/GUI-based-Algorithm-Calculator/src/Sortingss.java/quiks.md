The function of `quiks` is to implement a Quicksort algorithm for sorting an array of integers.

**Code Description**: 
The code implements the partitioning step in the Quicksort algorithm, which rearranges elements in an array to place a pivot element at its final sorted position. The `quickSort` method recursively calls itself to sort the sub-arrays on either side of the pivot element. The `partition` method is used to select and place the pivot element in its correct position within the array.\\
## Code: 
```
class quiks
{
	 void quickSort(int[] num, int start, int end)
	 {
	    int partition = partition(num, start, end);
        if(partition-1>start)
        {
        	quickSort(num, start, partition - 1);
        }
    	if(partition+1<end) 
    	{
    		quickSort(num, partition + 1, end);
    	}
	 }

	     int partition(int[] num, int start, int end){
	         int pivot = num[end];

	         for(int i=start; i<end; i++){
	            if(num[i]<pivot){
	            int temp= num[start];
	            num[start]=num[i];
	            num[i]=temp;
	            start++;
	        }
	        }

	        int temp = num[start];
	        num[start] = pivot;
	        num[end] = temp;
	        return start;

	        }
}
```