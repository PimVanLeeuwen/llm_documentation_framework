## Expected output
`merge`: The function of `merge` is to merge two sorted subarrays into a single sorted array.
**Parameters**:
`int num[]`: This parameter represents the input array that needs to be merged.
`int l`: This parameter represents the starting index of the first subarray in the input array.
`int m`: This parameter represents the ending index of the first subarray and the starting index of the second subarray in the input array.
`int r`: This parameter represents the ending index of the second subarray in the input array.

**Code Description**: The `merge` function takes four parameters: an input array `num`, and three indices `l`, `m`, and `r`. It splits the input array into two halves at the specified indices, sorts each half separately, and then merges them back together in a sorted manner.\\
## Code: 
```
void merge(int num[], int l, int m, int r)
    {
        int i, j, k;
        int n1 = m - l + 1;
        int n2 =  r - m;
        int[] L = new int[n1];  
        int[] R = new int[n2];  
        //int L[n1], R[n2];

        for (i = 0; i < n1; i++)
            L[i] = num[l + i];
        for (j = 0; j < n2; j++)
            R[j] = num[m + 1+ j];

        i = 0; // Initial index of first subarray
        j = 0; // Initial index of second subarray
        k = l; // Initial index of merged subarray
        while (i < n1 && j < n2)
        {
            if (L[i] <= R[j])
            {
                num[k] = L[i];
                i++;
            }
            else
            {
                num[k] = R[j];
                j++;
            }
            k++;
        }

        while (i < n1)
        {
            num[k] = L[i];
            i++;
            k++;
        }

        while (j < n2)
        {
            num[k] = R[j];
            j++;
            k++;
        }
    }
```