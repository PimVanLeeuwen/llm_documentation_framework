`heapSort`: The function of `heapSort` is to sort an array in ascending order using the heap sort algorithm.

**Parameters**:
`int num[]`: This parameter represents the input array that needs to be sorted.
`int size`: This parameter represents the size of the input array, which is used as a reference for the sorting process.

**Code Description**: The `heapSort` function first calls the `heapify` function on each non-leaf node in the binary tree representation of the array. Then, it repeatedly removes the largest element from the heap (which is now at the root) and places it at the end of the array, reducing the size of the heap by one. This process continues until the entire array has been sorted.\\
## Code: 
```
void heapSort(int num[], int size)
	    {
	        int i;
	        for (i = size / 2 - 1; i >= 0; i--)
	            heapify(num, size, i);
	        for (i=size-1; i>=0; i--)
	        {
	        	int temp;
	            temp = num[0];
	            num[0]= num[i];
	            num[i] = temp;
	            heapify(num, i, 0);
	        }
	     }
```