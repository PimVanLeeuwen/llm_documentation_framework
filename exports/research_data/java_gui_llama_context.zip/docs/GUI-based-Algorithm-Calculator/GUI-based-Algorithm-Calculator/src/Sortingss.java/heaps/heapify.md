`heapify`: The function of `heapify` is to maintain the heap property in a given array by ensuring that the parent node is greater than or equal to its child nodes.

**Parameters**:
- `int num[]`: This parameter represents the input array that needs to be heapified.
- `int size`: This parameter specifies the size of the input array, which is used to determine the valid indices within the array.
- `int i`: This parameter represents the index of the node in the array that needs to be heapified.

**Code Description**: The `heapify` function takes an array `num`, its size `size`, and a node index `i` as input. It first checks if the left child of the current node is within the valid range and has a greater value than the current node's value. If so, it updates the largest variable to point to the left child. Similarly, it checks the right child and updates the largest variable accordingly. If the largest variable points to a different index than the current node, it swaps the values of the current node and its largest child, and recursively calls itself on the updated array with the new largest index. This process continues until the heap property is maintained throughout the entire array.\\
## Code: 
```
void heapify(int num[], int size, int i)
    {
        int largest = i;
        int left = 2*i + 1;
        int right = 2*i + 2;

        if (left < size && num[left] >num[largest])
            largest = left;

        if (right < size && num[right] > num[largest])
            largest = right;

        if (largest != i)
        {
        	int temp;
            temp = num[i];
            num[i]= num[largest];
            num[largest] = temp;
            heapify(num, size, largest);
        }
    }
```