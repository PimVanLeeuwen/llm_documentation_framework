## Expected Output
`hourAngle`: The function of `hourAngle` is to calculate the hour angle, which is the angular distance between the observer's local zenith and the Sun.

## Code Description
The code calculates the hour angle using the formula: `ACos((Sin(alt) - Sin(dec) * Sin(lat)) / (Cos(dec) * Cos(lat)))`. This formula takes into account the altitude (`alt`), declination (`dec`), and latitude (`lat`) of the observer's location. The result is an angle in radians, which represents the hour angle.\\
## Code: 
```
angle_type Trigonometry::hourAngle(angle_type alt, angle_type dec, angle_type lat) {
    return ACos((Sin(alt) - Sin(dec) * Sin(lat)) / (Cos(dec) * Cos(lat)));
  }
```