**Expected Output**
The function of `altitude` is to calculate the altitude angle, which is the angle between the observer's horizon and a celestial object.

**Code Description**
This code calculates the altitude angle using the haversine formula. It takes three parameters: `h`, `decl`, and `lat`, representing the hour angle, declination, and latitude of the celestial object, respectively. The function uses the `ASin` (arc sine) and `Cos` (cosine) functions to compute the altitude angle in radians.\\
## Code: 
```
angle_type Trigonometry::altitude(angle_type h, angle_type decl, angle_type lat) {
    return ASin(Cos(h) * Cos(decl) * Cos(lat) + Sin(decl) * Sin(lat));
  }
```