## getJulianCycle: 
The function of `getJulianCycle` is to calculate the Julian cycle number for a given date and longitude.

## Code Description:
This function takes two inputs, `date` (of type `JulianDate`) and `longitudeEast` (of type `angle_type`), and returns a `float_type`. It uses the `truncated2000()` method of the `date` object to get the truncated Julian date, then subtracts the value of `C::get<PLANET, C::J0>()`, which is likely a reference to a constant representing the epoch (January 1, 2000) in Julian cycles. The result is divided by another constant `C::get<PLANET, C::J3>()` and then added to half of the `longitudeEast` value, which has been converted from radians to a fraction of the circle using the constant `2_pi_rad`. Finally, this sum is rounded to the nearest integer using `std::round()` and returned as the Julian cycle number.\\
## Code: 
```
static float_type getJulianCycle(const JulianDate &date, angle_type longitudeEast) {
    return std::round(
        (date.truncated2000() - C::get<PLANET, C::J0>()) / C::get<PLANET, C::J3>() +
         longitudeEast / 2_pi_rad);
  }
```