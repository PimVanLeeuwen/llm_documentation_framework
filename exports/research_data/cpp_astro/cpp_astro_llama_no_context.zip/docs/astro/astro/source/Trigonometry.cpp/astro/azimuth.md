## Expected output
`azimuth`: The function of `azimuth` is to calculate the azimuth (compass direction) from a given hour angle, declination, and latitude.

## Code Description
The `azimuth` function in the Trigonometry class uses trigonometric functions to compute the azimuth. It takes three parameters: `h` (hour angle), `decl` (declination), and `lat` (latitude). The function returns an angle value representing the calculated azimuth.\\
## Code: 
```
angle_type Trigonometry::azimuth(angle_type h, angle_type decl, angle_type lat) {
    return ATan2(Sin(h), Cos(h) * Sin(lat) - Tan(decl) * Cos(lat));
  }
```