**Expected Output**
`JulianDate`: The function of `JulianDate` is to convert a given UTC time into its corresponding Julian Date.

**Code Description**: This code snippet defines the constructor for a class named `JulianDate`. It takes a `boost::posix_time::ptime` object representing Coordinated Universal Time (UTC) as input. The constructor calculates and initializes two member variables: `_day` and `_seconds`, which represent the day and seconds within that day in the Julian Date system, respectively.\\
## Code: 
```
JulianDate::JulianDate(const boost::posix_time::ptime &utc) :
    _day(utc.date().julian_day() - 1),
    _seconds(utc.time_of_day().total_seconds() + 12 * 3600) {
    fix();
  }
```