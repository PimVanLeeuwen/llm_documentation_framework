## getRightAscension: 
The function of `getRightAscension` is to calculate the right ascension of a celestial body.

## Code Description:
This code snippet defines a member function called `getRightAscension()` within the class `SolarDescription<PLANET>`. The purpose of this function appears to be calculating the right ascension (RA) of a celestial body, specifically for a planet. 

The calculation is performed using the `Trigonometry::rightAscension` function, which takes two parameters: `_eclipticalLongitude` and `C::get<PLANET, C::Obliquity>()`. The first parameter seems to represent the ecliptical longitude of the celestial body, while the second parameter likely represents the obliquity (or inclination) of the planet's orbit. 

The result of this calculation is then returned by the `getRightAscension()` function as its output value.\\
## Code: 
```
angle_type SolarDescription<PLANET>::getRightAscension() const {
    return Trigonometry::rightAscension(_eclipticalLongitude, C::get<PLANET, C::Obliquity>());
  }
```