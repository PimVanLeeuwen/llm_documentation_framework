`convertToHorizontalCoords`: The function of `convertToHorizontalCoords` is to convert equatorial coordinates into horizontal coordinates.

**Code Description**: This function takes in a set of equatorial coordinates (right ascension and declination) and uses them, along with the observer's position latitude, to calculate the azimuth and altitude of an object. It utilizes trigonometric functions from the Trigonometry class to perform these calculations. The result is a set of horizontal coordinates that describe the object's position in the sky relative to the observer's location.\\
## Code: 
```
HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }
```