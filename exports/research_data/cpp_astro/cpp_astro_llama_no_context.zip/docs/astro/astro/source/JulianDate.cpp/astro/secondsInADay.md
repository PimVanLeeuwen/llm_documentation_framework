## secondsInADay: 
The function of `secondsInADay` is to calculate the total number of seconds in a day.

## Code Description:
This C++ code defines a static constexpr function named `secondsInADay`. The function returns the total number of seconds in a day, which is calculated by multiplying 24 hours (the number of hours in a day) by 3600 seconds (the number of seconds in an hour).\\
## Code: 
```
static constexpr long unsigned secondsInADay() {
    return 24 * 3600;
  }
```