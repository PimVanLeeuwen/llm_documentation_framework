## Expected output
`rightAscension`: The function of `rightAscension` is to calculate the right ascension of a celestial object given its longitude, latitude, and ecliptic longitude.

**Code Description**: This function uses the ATan2 and Sin functions from the Trigonometry class to compute the right ascension. It takes three angle parameters: l (longitude), b (latitude), and e (ecliptic longitude). The calculation involves trigonometric operations to derive the right ascension value.\\
## Code: 
```
angle_type Trigonometry::rightAscension(angle_type l, angle_type b, angle_type e) {
    return ATan2(Sin(l) * Cos(e) - Tan(b) * Sin(e), Cos(l));
  }
```