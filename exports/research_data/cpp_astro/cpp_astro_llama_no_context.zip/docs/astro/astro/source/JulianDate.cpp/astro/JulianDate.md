**Expected Output**
`JulianDate`: The function of `JulianDate` is to create an instance of the JulianDate class, representing a specific date in the Julian calendar system.

**Code Description**: This constructor initializes the JulianDate object with two parameters: `julianDay` and `secondsSinceNoon`. It sets the `_day` member variable to the provided `julianDay` value and the `_seconds` member variable to the provided `secondsSinceNoon` value. After initialization, it calls the `fix()` method to perform any necessary adjustments or calculations on the date.\\
## Code: 
```
JulianDate::JulianDate(long unsigned julianDay, long unsigned secondsSinceNoon) :
    _day(julianDay),
    _seconds(secondsSinceNoon) {
    fix();
  }
```