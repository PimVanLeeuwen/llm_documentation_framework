# PROMPT
## Information
**Code Content:** \
`HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }`

## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`convertToHorizontalCoords`: The function of `convertToHorizontalCoords` is *FILL IN* 

**Code Description**: *FILL IN*
