# PROMPT
## Information
**Code Content:** \
`static float_type getJulianCycle(const JulianDate &date, angle_type longitudeEast) {
    return std::round(
        (date.truncated2000() - C::get<PLANET, C::J0>()) / C::get<PLANET, C::J3>() +
         longitudeEast / 2_pi_rad);
  }`

## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`getJulianCycle`: The function of `getJulianCycle` is *FILL IN* 

**Code Description**: *FILL IN*
