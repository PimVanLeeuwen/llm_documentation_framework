# PROMPT
## Information
**Code Content:** \
`SolarDescription<PLANET>::SolarDescription(const JulianDate &date) {
    // M = M0 + M1 (J - J2000)
    _meanAnomaly = C::get<PLANET, C::M0>() + C::get<PLANET, C::M1>() * date.truncated2000();
    // C ~ C1 sin(M) + C2 sin(2M) + C3 sin(3M) + C4 sin(4M) + C5 sin(5M) + C6 sin(6M)
    _equationOfTheCenter = C::get<PLANET, C::C1>() * Sin(_meanAnomaly) +
                           C::get<PLANET, C::C2>() * Sin(2.0 * _meanAnomaly) +
                           C::get<PLANET, C::C3>() * Sin(3.0 * _meanAnomaly) +
                           C::get<PLANET, C::C4>() * Sin(4.0 * _meanAnomaly) +
                           C::get<PLANET, C::C5>() * Sin(5.0 * _meanAnomaly) +
                           C::get<PLANET, C::C6>() * Sin(6.0 * _meanAnomaly);
    // l = M + C + Perihelion + 180
    _eclipticalLongitude = _meanAnomaly + _equationOfTheCenter + C::get<PLANET, C::Perihelion>() + 1_pi_rad;
  }`

## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`SolarDescription`: The function of `SolarDescription` is *FILL IN* 

**Code Description**: *FILL IN*
