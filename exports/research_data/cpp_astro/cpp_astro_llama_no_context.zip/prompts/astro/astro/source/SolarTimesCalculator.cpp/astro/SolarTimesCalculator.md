# PROMPT
## Information
**Code Content:** \
`SolarTimesCalculator<PLANET>::SolarTimesCalculator(const Sun<PLANET> &sun) :
    _sun(sun),
    _cycle(getJulianCycle<PLANET>(
        _sun._observer.getDate(),
        _sun._observer.getPosition().longitude)),
    _transit(calculateSolarTransit(0_rad)) {}`

## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`SolarTimesCalculator`: The function of `SolarTimesCalculator` is *FILL IN* 

**Code Description**: *FILL IN*
