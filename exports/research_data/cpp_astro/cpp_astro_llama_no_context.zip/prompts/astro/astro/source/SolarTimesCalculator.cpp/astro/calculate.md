# PROMPT
## Information
**Code Content:** \
`SolarTimes SolarTimesCalculator<PLANET>::calculate(const angle_type altitude) const {
    const auto &here = _sun._observer.getPosition();
    const auto declination = _sun.getEquatorialCoords().declination;
    const auto hourAngle = Trigonometry::hourAngle(altitude, declination, here.latitude);
    const auto set = calculateSolarTransit(hourAngle);
    const auto rise = JulianDate::fromTruncated2000(2.0 * _transit.truncated2000() - set.truncated2000());
    return {rise, set};
  }`

## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`calculate`: The function of `calculate` is *FILL IN* 

**Code Description**: *FILL IN*
