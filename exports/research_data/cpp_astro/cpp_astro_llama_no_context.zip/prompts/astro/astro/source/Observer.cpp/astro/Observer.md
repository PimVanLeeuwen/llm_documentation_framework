# PROMPT
## Information
**Code Content:** \
`Observer<PLANET>::Observer(const JulianDate &date, const GeographicalCoords &position) :
    _date(date),
    _position(position),
    _siderealTime(astro::getSiderealTime<PLANET>(_date, _position.longitude)) {}`

## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`Observer`: The function of `Observer` is *FILL IN* 

**Code Description**: *FILL IN*
