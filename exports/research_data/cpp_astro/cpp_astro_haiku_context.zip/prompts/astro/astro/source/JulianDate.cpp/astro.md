# PROMPT
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/JulianDate.cpp` \
**Type:** `Class` \
**Class Name:** `astro` \
**Code Content:** \
`namespace astro {

  static constexpr long unsigned secondsInADay() {
    return 24 * 3600;
  }

  JulianDate::JulianDate(long unsigned julianDay, long unsigned secondsSinceNoon) :
    _day(julianDay),
    _seconds(secondsSinceNoon) {
    fix();
  }

#ifndef ASTRO_NO_BOOST`



## Children 
 This code contains the following methods/classes that are already documented: 
### secondsInADay 
The `secondsInADay()` function returns the number of seconds in a day, which is 24 hours multiplied by 60 minutes per hour and 60 seconds per minute, resulting in 86,400 seconds. 
### JulianDate 
The provided code is a constructor for the `JulianDate` class. It initializes the `_day` and `_seconds` member variables with the given `julianDay` and `secondsSinceNoon` values, and then calls the `fix()` method to ensure the date is properly formatted. 



## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`astro`: The function of `astro` is *FILL IN* 

**Code Description**: *FILL IN*
