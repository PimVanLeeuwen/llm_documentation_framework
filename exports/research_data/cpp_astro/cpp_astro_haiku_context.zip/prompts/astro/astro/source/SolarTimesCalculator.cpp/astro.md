# PROMPT
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/SolarTimesCalculator.cpp` \
**Type:** `Class` \
**Class Name:** `astro` \
**Code Content:** \
`namespace astro {

  using namespace literals;
  using C = Constant;

  template <Planet PLANET>
  static float_type getJulianCycle(const JulianDate &date, angle_type longitudeEast) {
    return std::round(
        (date.truncated2000() - C::get<PLANET, C::J0>()) / C::get<PLANET, C::J3>() +
         longitudeEast / 2_pi_rad);
  }

  template <Planet PLANET>
  SolarTimesCalculator<PLANET>::SolarTimesCalculator(const Sun<PLANET> &sun) :
    _sun(sun),
    _cycle(getJulianCycle<PLANET>(
        _sun._observer.getDate(),
        _sun._observer.getPosition().longitude)),
    _transit(calculateSolarTransit(0_rad)) {}

  template <Planet PLANET>
  SolarTimes SolarTimesCalculator<PLANET>::calculateSunriseAndSunset(
      const bool applyAtmosphericCorrection) const {
    constexpr auto elevation = - C::get<PLANET, C::SolarDisk>() / 2.0;
    if (applyAtmosphericCorrection)
      return calculate(elevation + C::get<PLANET, C::AtmosphericCorrection>());
    return calculate(elevation);
  }

  template <Planet PLANET>
  SolarTimes SolarTimesCalculator<PLANET>::calculate(const angle_type altitude) const {
    const auto &here = _sun._observer.getPosition();
    const auto declination = _sun.getEquatorialCoords().declination;
    const auto hourAngle = Trigonometry::hourAngle(altitude, declination, here.latitude);
    const auto set = calculateSolarTransit(hourAngle);
    const auto rise = JulianDate::fromTruncated2000(2.0 * _transit.truncated2000() - set.truncated2000());
    return {rise, set};
  }

  template <Planet PLANET>
  JulianDate SolarTimesCalculator<PLANET>::calculateSolarTransit(const angle_type hourAngle) const {
    const auto longitudeEast = _sun._observer.getPosition().longitude;
    const auto meanAnomaly = _sun._sun.getMeanAnomaly();
    const auto eclipticLongitudeOfTheSun = _sun.getEclipticalLongitude();

    const auto estimatedTransit =
        C::get<PLANET, C::J0>() +
        C::get<PLANET, C::J3>() * (_cycle + (hourAngle - longitudeEast) / 2_pi_rad);
    const auto transit =
        estimatedTransit +
        C::get<PLANET, C::J1>() * math::Sin(meanAnomaly) +
        C::get<PLANET, C::J2>() * math::Sin(2.0 * eclipticLongitudeOfTheSun);
    // transit -= J3 * H(transit) / 360_deg // @todo repeat to improve precision
    return JulianDate::fromTruncated2000(transit);
  }

  ASTRO_TEMPLATE_CLASS_INSTANTIATE_FOR_EACH_PLANET(SolarTimesCalculator)

}`



## Children 
 This code contains the following methods/classes that are already documented: 
### getJulianCycle 
The `getJulianCycle` function calculates the Julian cycle for a given Julian date and longitude east. It uses a formula involving constants from the `C` class to compute the Julian cycle. 
### SolarTimesCalculator 
This code is a constructor for the `SolarTimesCalculator` class, which is responsible for calculating solar transit times for a given planet. It initializes the `_sun`, `_cycle`, and `_transit` member variables using the provided `Sun` object and the `calculateSolarTransit` and `getJulianCycle` functions. 
### calculateSunriseAndSunset 
This code calculates the sunrise and sunset times for a given planet, taking into account the atmospheric correction if requested. It calls the `calculate` method to perform the necessary computations. 
### calculate 
This code calculates the rise and set times of the sun for a given planet based on the observer's location and the sun's equatorial coordinates. It uses various astronomical calculations and trigonometric functions to determine the solar transit time, from which the rise and set times are derived. 
### calculateSolarTransit 
This code calculates the solar transit time for a given planet using various astronomical parameters such as the observer's longitude, the sun's mean anomaly, and the sun's ecliptical longitude. The calculation involves several mathematical formulas and constants specific to the planet. 



## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`astro`: The function of `astro` is *FILL IN* 

**Code Description**: *FILL IN*
