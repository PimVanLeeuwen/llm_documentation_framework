# PROMPT
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/Observer.cpp` \
**Type:** `Class` \
**Class Name:** `astro` \
**Code Content:** \
`namespace astro {

  template <Planet PLANET>
  static angle_type getSiderealTime(const JulianDate &date, angle_type longitudeEast) {
    using C = Constant;
    // Theta = Theta0 + Theta1 (J - J2000) - l_west
    return C::get<PLANET, C::Theta0>() +
           C::get<PLANET, C::Theta1>() * date.truncated2000() +
           longitudeEast;
  }

  template <Planet PLANET>
  Observer<PLANET>::Observer(const JulianDate &date, const GeographicalCoords &position) :
    _date(date),
    _position(position),
    _siderealTime(astro::getSiderealTime<PLANET>(_date, _position.longitude)) {}

  template <Planet PLANET>
  HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }

  ASTRO_TEMPLATE_CLASS_INSTANTIATE_FOR_EACH_PLANET(Observer);

}`



## Children 
 This code contains the following methods/classes that are already documented: 
### getSiderealTime 
This code calculates the sidereal time based on the given Julian date and longitude east. It uses predefined constants to compute the sidereal time using a formula involving the Julian date and longitude. 
### Observer 
This code is a constructor for the `Observer` class, which initializes the `_date`, `_position`, and `_siderealTime` member variables based on the provided `JulianDate` and `GeographicalCoords` parameters. It uses the `astro::getSiderealTime` function to calculate the sidereal time for the given location and date. 
### convertToHorizontalCoords 
This code is a method named `convertToHorizontalCoords` that takes an `EquatorialCoords` object as input and converts it to `HorizontalCoords` using trigonometric calculations. The method calculates the azimuth and altitude angles based on the input coordinates and the observer's position. 



## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`astro`: The function of `astro` is *FILL IN* 

**Code Description**: *FILL IN*
