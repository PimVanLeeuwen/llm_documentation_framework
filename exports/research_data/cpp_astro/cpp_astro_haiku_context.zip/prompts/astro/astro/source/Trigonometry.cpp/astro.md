# PROMPT
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/Trigonometry.cpp` \
**Type:** `Class` \
**Class Name:** `astro` \
**Code Content:** \
`namespace astro {

  using namespace astro::math;

  angle_type Trigonometry::declination(angle_type l, angle_type e) {
    return ASin(Sin(e) * Sin(l));
  }

  angle_type Trigonometry::rightAscension(angle_type l, angle_type e) {
    return ATan2(Sin(l) * Cos(e), Cos(l));
  }

  angle_type Trigonometry::declination(angle_type l, angle_type b, angle_type e) {
    return ASin(Sin(b) * Cos(e) + Cos(b) * Sin(e) * Sin(l));
  }

  angle_type Trigonometry::rightAscension(angle_type l, angle_type b, angle_type e) {
    return ATan2(Sin(l) * Cos(e) - Tan(b) * Sin(e), Cos(l));
  }

  angle_type Trigonometry::azimuth(angle_type h, angle_type decl, angle_type lat) {
    return ATan2(Sin(h), Cos(h) * Sin(lat) - Tan(decl) * Cos(lat));
  }

  angle_type Trigonometry::altitude(angle_type h, angle_type decl, angle_type lat) {
    return ASin(Cos(h) * Cos(decl) * Cos(lat) + Sin(decl) * Sin(lat));
  }

  angle_type Trigonometry::hourAngle(angle_type alt, angle_type dec, angle_type lat) {
    return ACos((Sin(alt) - Sin(dec) * Sin(lat)) / (Cos(dec) * Cos(lat)));
  }

}`



## Children 
 This code contains the following methods/classes that are already documented: 
### declination 
The `declination` method calculates the declination angle based on the given latitude (`l`) and ecliptic obliquity (`e`) using the trigonometric function `ASin`. 
### rightAscension 
The `rightAscension` method calculates the right ascension of a celestial object given its longitude (`l`) and ecliptic latitude (`e`). It uses the `ATan2` function to compute the right ascension based on the trigonometric relationships between the longitude, latitude, and right ascension. 
### declination 
The provided code calculates the declination angle based on the given latitude (l), latitude (b), and ecliptic longitude (e) using the trigonometric sine and cosine functions. 
### rightAscension 
The provided code calculates the right ascension of a celestial object given its ecliptic longitude (l), ecliptic latitude (b), and the obliquity of the ecliptic (e). The calculation is performed using the trigonometric functions sine, cosine, and arctangent. 
### azimuth 
The provided code calculates the azimuth angle based on the given hour angle (h), declination (decl), and latitude (lat) using the trigonometric functions Sin, Cos, and ATan2. 
### altitude 
The provided code calculates the altitude angle of an object given its hour angle (h), declination (decl), and the observer's latitude (lat). It uses trigonometric functions to compute the altitude angle. 
### hourAngle 
The `hourAngle` method calculates the hour angle given the altitude, declination, and latitude. It uses the trigonometric functions `Sin`, `Cos`, and `ACos` to compute the hour angle. 



## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`astro`: The function of `astro` is *FILL IN* 

**Code Description**: *FILL IN*
