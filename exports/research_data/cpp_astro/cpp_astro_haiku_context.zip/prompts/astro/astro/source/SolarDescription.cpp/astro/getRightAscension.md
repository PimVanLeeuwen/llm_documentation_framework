# PROMPT
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/SolarDescription.cpp/astro` \
**Type:** `Method` \
**Method Name:** `getRightAscension` \
**Code Content:** \
`angle_type SolarDescription<PLANET>::getRightAscension() const {
    return Trigonometry::rightAscension(_eclipticalLongitude, C::get<PLANET, C::Obliquity>());
  }`

## Calls 
 This code calls the following methods within the repository: 
### astro/astro/source/Trigonometry.cpp/astro.rightAscension 
 - Explanation:  _The provided code calculates the right ascension of a celestial object given its ecliptic longitude (l), ecliptic latitude (b), and the obliquity of the ecliptic (e). The calculation is performed using the trigonometric functions sine, cosine, and arctangent._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`getRightAscension`: The function of `getRightAscension` is *FILL IN* 

**Code Description**: *FILL IN*
