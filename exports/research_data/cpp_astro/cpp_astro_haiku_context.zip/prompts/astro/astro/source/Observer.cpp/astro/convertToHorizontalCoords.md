# PROMPT
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/Observer.cpp/astro` \
**Type:** `Method` \
**Method Name:** `convertToHorizontalCoords` \
**Code Content:** \
`HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }`

## Calls 
 This code calls the following methods within the repository: 
### astro/astro/source/Trigonometry.cpp/astro.rightAscension 
 - Explanation:  _The provided code calculates the right ascension of a celestial object given its ecliptic longitude (l), ecliptic latitude (b), and the obliquity of the ecliptic (e). The calculation is performed using the trigonometric functions sine, cosine, and arctangent._ 
### astro/astro/source/Trigonometry.cpp/astro.altitude 
 - Explanation:  _The provided code calculates the altitude angle of an object given its hour angle (h), declination (decl), and the observer's latitude (lat). It uses trigonometric functions to compute the altitude angle._ 
### astro/astro/source/Trigonometry.cpp/astro.declination 
 - Explanation:  _The provided code calculates the declination angle based on the given latitude (l), latitude (b), and ecliptic longitude (e) using the trigonometric sine and cosine functions._ 
### astro/astro/source/Trigonometry.cpp/astro.hourAngle 
 - Explanation:  _The `hourAngle` method calculates the hour angle given the altitude, declination, and latitude. It uses the trigonometric functions `Sin`, `Cos`, and `ACos` to compute the hour angle._ 
### astro/astro/source/Trigonometry.cpp/astro.azimuth 
 - Explanation:  _The provided code calculates the azimuth angle based on the given hour angle (h), declination (decl), and latitude (lat) using the trigonometric functions Sin, Cos, and ATan2._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`convertToHorizontalCoords`: The function of `convertToHorizontalCoords` is *FILL IN* 
**Parameters**:\
`const EquatorialCoords &ec`: *FILL IN* \

**Code Description**: *FILL IN*
