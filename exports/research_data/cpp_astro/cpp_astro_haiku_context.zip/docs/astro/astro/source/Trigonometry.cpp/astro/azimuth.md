`azimuth`: The function of `azimuth` is to calculate the azimuth angle, which is the horizontal angle between a reference direction (usually north) and the direction of a celestial object.

**Parameters**:
`angle_type h`: The hour angle of the celestial object, which is the angle between the object's position and the local meridian.
`angle_type decl`: The declination of the celestial object, which is the angular distance of the object north or south of the celestial equator.
`angle_type lat`: The latitude of the observer's location.

**Code Description**:
The `azimuth` function calculates the azimuth angle using the formula:
`azimuth = atan2(sin(h), cos(h) * sin(lat) - tan(decl) * cos(lat))`
This formula is derived from the spherical trigonometry equations that relate the hour angle, declination, and latitude to the azimuth angle.

The function first calculates the sine and cosine of the hour angle `h` using the `Sin` and `Cos` functions, respectively. It then calculates the tangent of the declination `decl` using the `Tan` function.

The function then uses the `atan2` function to calculate the azimuth angle. The `atan2` function takes two arguments, the y-coordinate and the x-coordinate of a point in the Cartesian plane, and returns the angle between the positive x-axis and the line segment connecting the origin to the point.

In this case, the `atan2` function is used to calculate the angle between the north direction and the direction of the celestial object, given the sine and cosine of the hour angle and the terms involving the declination and latitude.

The resulting azimuth angle is returned as the output of the function.\\
## Code: 
```
angle_type Trigonometry::azimuth(angle_type h, angle_type decl, angle_type lat) {
    return ATan2(Sin(h), Cos(h) * Sin(lat) - Tan(decl) * Cos(lat));
  }
```