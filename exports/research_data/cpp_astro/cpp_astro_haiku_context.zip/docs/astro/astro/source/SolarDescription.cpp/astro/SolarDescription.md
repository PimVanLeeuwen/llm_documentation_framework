`SolarDescription`: The function of `SolarDescription` is to calculate the solar description for a given planet at a specific Julian date.

**Parameters**:
`const JulianDate &date`: This parameter represents the Julian date for which the solar description needs to be calculated.

**Code Description**:
The `SolarDescription` function performs the following steps:

1. Calculates the mean anomaly (`_meanAnomaly`) of the planet using the formula `M = M0 + M1 (J - J2000)`, where `M0` and `M1` are constants specific to the planet, and `J` is the truncated Julian date (2000.0).

2. Calculates the equation of the center (`_equationOfTheCenter`) using the formula `C ~ C1 sin(M) + C2 sin(2M) + C3 sin(3M) + C4 sin(4M) + C5 sin(5M) + C6 sin(6M)`, where `C1` to `C6` are constants specific to the planet, and `M` is the mean anomaly.

3. Calculates the ecliptical longitude (`_eclipticalLongitude`) using the formula `l = M + C + Perihelion + 180`, where `M` is the mean anomaly, `C` is the equation of the center, and `Perihelion` is a constant specific to the planet.

The function uses the `C::get<PLANET, C::M0>()`, `C::get<PLANET, C::M1>()`, `C::get<PLANET, C::C1>()`, `C::get<PLANET, C::C2>()`, `C::get<PLANET, C::C3>()`, `C::get<PLANET, C::C4>()`, `C::get<PLANET, C::C5>()`, `C::get<PLANET, C::C6>()`, and `C::get<PLANET, C::Perihelion>()` functions to retrieve the necessary constants for the given planet. The `Sin()` function is used to calculate the sine of the various angles.

The calculated values of `_meanAnom\\
## Code: 
```
SolarDescription<PLANET>::SolarDescription(const JulianDate &date) {
    // M = M0 + M1 (J - J2000)
    _meanAnomaly = C::get<PLANET, C::M0>() + C::get<PLANET, C::M1>() * date.truncated2000();
    // C ~ C1 sin(M) + C2 sin(2M) + C3 sin(3M) + C4 sin(4M) + C5 sin(5M) + C6 sin(6M)
    _equationOfTheCenter = C::get<PLANET, C::C1>() * Sin(_meanAnomaly) +
                           C::get<PLANET, C::C2>() * Sin(2.0 * _meanAnomaly) +
                           C::get<PLANET, C::C3>() * Sin(3.0 * _meanAnomaly) +
                           C::get<PLANET, C::C4>() * Sin(4.0 * _meanAnomaly) +
                           C::get<PLANET, C::C5>() * Sin(5.0 * _meanAnomaly) +
                           C::get<PLANET, C::C6>() * Sin(6.0 * _meanAnomaly);
    // l = M + C + Perihelion + 180
    _eclipticalLongitude = _meanAnomaly + _equationOfTheCenter + C::get<PLANET, C::Perihelion>() + 1_pi_rad;
  }
```