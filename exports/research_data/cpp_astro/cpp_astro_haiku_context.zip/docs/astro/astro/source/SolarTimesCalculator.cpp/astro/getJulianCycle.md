`getJulianCycle`: The function of `getJulianCycle` is to calculate the Julian cycle for a given Julian date and longitude east.

**Parameters**:
`const JulianDate &date`: The Julian date for which the Julian cycle is to be calculated.
`angle_type longitudeEast`: The longitude east, in radians, for the location where the Julian cycle is to be calculated.

**Code Description**:
The `getJulianCycle` function takes a `JulianDate` object and an `angle_type` value representing the longitude east, and calculates the Julian cycle for the given date and location.

The function first calculates the difference between the truncated Julian date (the integer part of the Julian date) and the constant `C::get<PLANET, C::J0>()`, which represents the Julian date of a reference point. This difference is then divided by the constant `C::get<PLANET, C::J3>()`, which represents the number of days in a Julian cycle.

The result of this calculation is then rounded to the nearest integer using the `std::round()` function. This rounded value represents the Julian cycle for the given date and location.

Finally, the function adds the longitude east (divided by 2π radians) to the calculated Julian cycle and returns the result.

The Julian cycle is a measure of the number of complete 365.25-day years that have elapsed since a reference point, typically the Julian date 2451545.0, which corresponds to January 1, 2000, at 12:00 UTC. This information can be useful in various astronomical calculations and applications.\\
## Code: 
```
static float_type getJulianCycle(const JulianDate &date, angle_type longitudeEast) {
    return std::round(
        (date.truncated2000() - C::get<PLANET, C::J0>()) / C::get<PLANET, C::J3>() +
         longitudeEast / 2_pi_rad);
  }
```