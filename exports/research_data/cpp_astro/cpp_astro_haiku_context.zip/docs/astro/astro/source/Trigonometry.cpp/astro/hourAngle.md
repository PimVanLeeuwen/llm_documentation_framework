`hourAngle`: The function of `hourAngle` is to calculate the hour angle of a celestial body given its altitude, declination, and the observer's latitude.

**Parameters**:
`angle_type alt`: The altitude of the celestial body, which is the angle between the horizon and the line of sight to the body.
`angle_type dec`: The declination of the celestial body, which is the angle between the celestial equator and the line of sight to the body.
`angle_type lat`: The latitude of the observer, which is the angle between the equatorial plane and the line of sight to the observer's location.

**Code Description**:
The `hourAngle` function calculates the hour angle of a celestial body using the formula:

`hourAngle = ACos((Sin(alt) - Sin(dec) * Sin(lat)) / (Cos(dec) * Cos(lat)))`

The hour angle is the angle between the celestial meridian (the great circle passing through the celestial poles and the zenith) and the hour circle passing through the celestial body. It is a measure of the time elapsed since the celestial body crossed the celestial meridian.

The formula used in the `hourAngle` function is derived from the spherical trigonometry relationship between the altitude, declination, and latitude of a celestial body. The function first calculates the expression `(Sin(alt) - Sin(dec) * Sin(lat)) / (Cos(dec) * Cos(lat))`, which represents the cosine of the hour angle. It then uses the `ACos` function to calculate the angle corresponding to this cosine value, which is the hour angle.

The `hourAngle` function is likely used in astronomical calculations, such as determining the position of a celestial body in the sky or calculating the time of sunrise or sunset. It is a fundamental function in the field of spherical astronomy and is commonly used in applications related to celestial navigation, astronomy, and time-keeping.\\
## Code: 
```
angle_type Trigonometry::hourAngle(angle_type alt, angle_type dec, angle_type lat) {
    return ACos((Sin(alt) - Sin(dec) * Sin(lat)) / (Cos(dec) * Cos(lat)));
  }
```