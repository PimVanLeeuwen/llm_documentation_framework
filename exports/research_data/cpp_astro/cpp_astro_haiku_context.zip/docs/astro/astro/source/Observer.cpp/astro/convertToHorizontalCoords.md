`convertToHorizontalCoords`: The function of `convertToHorizontalCoords` is to convert the given equatorial coordinates (right ascension and declination) to horizontal coordinates (azimuth and altitude) based on the observer's position.

**Parameters**:
`const EquatorialCoords &ec`: This parameter represents the equatorial coordinates of a celestial object, which include the right ascension and declination.

**Code Description**:
The `convertToHorizontalCoords` function takes the equatorial coordinates (`ec`) as input and calculates the corresponding horizontal coordinates (azimuth and altitude) based on the observer's position (`_position.latitude`).

1. It first calculates the hour angle (`hourAngle`) by calling the `convertToHourAngle` function, which converts the right ascension to the hour angle.
2. The function then calculates the azimuth (`hc.azimuth`) by calling the `Trigonometry::azimuth` function, which takes the hour angle, declination, and observer's latitude as input.
3. Similarly, the function calculates the altitude (`hc.altitude`) by calling the `Trigonometry::altitude` function, which also takes the hour angle, declination, and observer's latitude as input.
4. Finally, the function returns the calculated horizontal coordinates (`hc`) as a `HorizontalCoords` object.

The `convertToHorizontalCoords` function is used to convert the equatorial coordinates of a celestial object to the corresponding horizontal coordinates, which are more useful for observational purposes, as they describe the object's position relative to the observer's horizon.\\
## Code: 
```
HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }
```