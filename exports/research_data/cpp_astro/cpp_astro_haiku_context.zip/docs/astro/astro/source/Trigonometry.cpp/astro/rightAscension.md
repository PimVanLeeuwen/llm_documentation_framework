`rightAscension`: The function of `rightAscension` is to calculate the right ascension of a celestial object given its longitude (`l`), latitude (`b`), and the ecliptic longitude (`e`) of the Sun.

**Parameters**:
`angle_type l`: The longitude of the celestial object.
`angle_type b`: The latitude of the celestial object.
`angle_type e`: The ecliptic longitude of the Sun.

**Code Description**: The function `rightAscension` calculates the right ascension of a celestial object using the formula:

```
right ascension = atan2(sin(l) * cos(e) - tan(b) * sin(e), cos(l))
```

This formula is derived from the spherical trigonometry relationships between the celestial coordinates (right ascension and declination) and the ecliptic coordinates (longitude and latitude).

The `atan2` function is used to calculate the angle (in radians) whose tangent is the ratio of the two arguments. The first argument is the y-coordinate (the numerator of the fraction), and the second argument is the x-coordinate (the denominator of the fraction).

The formula calculates the right ascension by using the following steps:

1. Compute `sin(l) * cos(e) - tan(b) * sin(e)`, which represents the y-coordinate of the celestial object in the equatorial coordinate system.
2. Compute `cos(l)`, which represents the x-coordinate of the celestial object in the equatorial coordinate system.
3. Use the `atan2` function to calculate the angle (in radians) whose tangent is the ratio of the y-coordinate to the x-coordinate. This angle represents the right ascension of the celestial object.

The function `rightAscension` takes the longitude (`l`), latitude (`b`), and ecliptic longitude (`e`) of the Sun as input parameters and returns the right ascension of the celestial object as an `angle_type` value.\\
## Code: 
```
angle_type Trigonometry::rightAscension(angle_type l, angle_type b, angle_type e) {
    return ATan2(Sin(l) * Cos(e) - Tan(b) * Sin(e), Cos(l));
  }
```