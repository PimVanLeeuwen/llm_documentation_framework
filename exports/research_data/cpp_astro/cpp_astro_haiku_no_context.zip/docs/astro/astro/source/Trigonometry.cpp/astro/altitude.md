`altitude`: The function of `altitude` is to calculate the altitude angle of an object given its hour angle, declination, and latitude.

**Code Description**: The `altitude` function takes three input parameters:
- `h`: the hour angle of the object
- `decl`: the declination of the object
- `lat`: the latitude of the observer

The function then calculates the altitude angle using the formula:

`altitude = asin(cos(h) * cos(decl) * cos(lat) + sin(decl) * sin(lat))`

This formula is derived from the spherical trigonometry relationship between the hour angle, declination, and latitude of an object, and its altitude angle. The `Cos()`, `Sin()`, and `ASin()` functions are used to perform the necessary trigonometric calculations.

The function returns the calculated altitude angle, which represents the angle between the object and the horizon, as seen from the observer's location.

This function is commonly used in astronomy and navigation applications to determine the position of celestial objects in the sky, or to calculate the elevation of an object above the horizon.\\
## Code: 
```
angle_type Trigonometry::altitude(angle_type h, angle_type decl, angle_type lat) {
    return ASin(Cos(h) * Cos(decl) * Cos(lat) + Sin(decl) * Sin(lat));
  }
```