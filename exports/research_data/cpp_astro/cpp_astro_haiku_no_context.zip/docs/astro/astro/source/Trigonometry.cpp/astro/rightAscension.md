`rightAscension`: The function of `rightAscension` is to calculate the right ascension of a celestial object given its longitude (`l`), latitude (`b`), and the ecliptic longitude (`e`).

**Code Description**: The `rightAscension` function takes three input parameters: `l` (longitude), `b` (latitude), and `e` (ecliptic longitude). It then calculates the right ascension using the formula:

```
rightAscension = atan2(sin(l) * cos(e) - tan(b) * sin(e), cos(l))
```

This formula is derived from the spherical trigonometry equations that relate the celestial coordinates (right ascension and declination) to the ecliptic coordinates (longitude and latitude).

The key steps are:

1. `sin(l) * cos(e) - tan(b) * sin(e)`: This part of the formula calculates the y-component of the vector in the equatorial coordinate system.
2. `cos(l)`: This part of the formula calculates the x-component of the vector in the equatorial coordinate system.
3. `atan2(y, x)`: This function calculates the angle (in radians) between the positive x-axis and the vector (x, y) in the Cartesian coordinate system. The result is the right ascension of the celestial object.

The `rightAscension` function is a common utility in astronomy and astrophysics applications, where it is used to convert between different coordinate systems and perform various calculations related to the positions of celestial objects.\\
## Code: 
```
angle_type Trigonometry::rightAscension(angle_type l, angle_type b, angle_type e) {
    return ATan2(Sin(l) * Cos(e) - Tan(b) * Sin(e), Cos(l));
  }
```