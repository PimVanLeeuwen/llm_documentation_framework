`Observer`: The function of `Observer` is to initialize an observer object with a given Julian date, geographical coordinates, and the corresponding sidereal time.

**Code Description**: The `Observer` class constructor takes two parameters: a `JulianDate` object representing the date and time, and a `GeographicalCoords` object representing the geographical position of the observer. The constructor initializes three member variables:

1. `_date`: This stores the given `JulianDate` object.
2. `_position`: This stores the given `GeographicalCoords` object.
3. `_siderealTime`: This is calculated using the `astro::getSiderealTime<PLANET>` function, which takes the `_date` and `_position.longitude` as input and computes the sidereal time for the specified planet (`PLANET`).

The purpose of this `Observer` class is to provide a way to represent an observer's location and the corresponding sidereal time, which is a crucial piece of information in astronomical calculations and observations.\\
## Code: 
```
Observer<PLANET>::Observer(const JulianDate &date, const GeographicalCoords &position) :
    _date(date),
    _position(position),
    _siderealTime(astro::getSiderealTime<PLANET>(_date, _position.longitude)) {}
```