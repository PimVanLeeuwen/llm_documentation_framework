`convertToHorizontalCoords`: The function of `convertToHorizontalCoords` is to convert equatorial coordinates (right ascension and declination) to horizontal coordinates (azimuth and altitude) for a given observer's position.

**Code Description**: The `convertToHorizontalCoords` function takes an `EquatorialCoords` object as input, which represents the right ascension and declination of a celestial object, and converts it to a `HorizontalCoords` object, which represents the azimuth and altitude of the object from the observer's perspective.

The function first calculates the hour angle of the object using the `convertToHourAngle` function. The hour angle is the angular distance between the object's right ascension and the observer's local meridian.

Next, the function calculates the azimuth and altitude of the object using the `Trigonometry::azimuth` and `Trigonometry::altitude` functions, respectively. These functions take the hour angle, declination, and the observer's latitude as input and compute the azimuth and altitude of the object.

Finally, the function returns the `HorizontalCoords` object containing the calculated azimuth and altitude.

This function is likely used in an astronomical application to convert the equatorial coordinates of a celestial object, which are typically used in astronomical calculations, to the horizontal coordinates that are more relevant for an observer's perspective on the sky.\\
## Code: 
```
HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }
```