`getJulianCycle`: The function of `getJulianCycle` is to calculate the Julian cycle for a given Julian date and longitude.

**Code Description**: The `getJulianCycle` function takes two parameters: a `JulianDate` object `date` and an `angle_type` value `longitudeEast`. It calculates the Julian cycle by performing the following steps:

1. It calculates the number of days since the reference Julian date `C::J0` by subtracting `C::J0` from the truncated year 2000 of the input `date` object.
2. It divides the result from step 1 by the constant `C::J3`, which represents the number of days in a Julian cycle.
3. It adds the longitude in radians (`longitudeEast / 2_pi_rad`) to the result from step 2.
4. It rounds the final result to the nearest integer using the `std::round` function, which gives the Julian cycle for the input `date` and `longitudeEast`.

The Julian cycle is a measure of the number of complete 365.25-day years that have elapsed since a reference date, typically the beginning of the Julian calendar. This information is useful in astronomical calculations and calendar conversions.\\
## Code: 
```
static float_type getJulianCycle(const JulianDate &date, angle_type longitudeEast) {
    return std::round(
        (date.truncated2000() - C::get<PLANET, C::J0>()) / C::get<PLANET, C::J3>() +
         longitudeEast / 2_pi_rad);
  }
```