`getRightAscension`: The function of `getRightAscension` is to calculate the right ascension of a planet based on its ecliptical longitude and the obliquity of the planet's orbit.

**Code Description**: The `getRightAscension` function is a member function of the `SolarDescription<PLANET>` class. It takes no parameters and returns an `angle_type` value, which represents the right ascension of the planet.

The function calls the `Trigonometry::rightAscension` function, passing in the `_eclipticalLongitude` member variable of the `SolarDescription<PLANET>` class and the `C::Obliquity` constant for the given `PLANET`. The `C::Obliquity` constant represents the obliquity (tilt) of the planet's orbit.

The `Trigonometry::rightAscension` function calculates the right ascension of the planet based on the provided ecliptical longitude and obliquity. The right ascension is a celestial coordinate that measures the east-west position of a celestial object on the celestial sphere.

The calculated right ascension is then returned by the `getRightAscension` function.\\
## Code: 
```
angle_type SolarDescription<PLANET>::getRightAscension() const {
    return Trigonometry::rightAscension(_eclipticalLongitude, C::get<PLANET, C::Obliquity>());
  }
```