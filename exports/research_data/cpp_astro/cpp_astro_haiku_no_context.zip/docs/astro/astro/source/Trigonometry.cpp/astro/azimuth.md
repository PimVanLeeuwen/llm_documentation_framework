`azimuth`: The function of `azimuth` is to calculate the azimuth angle based on the given parameters.

**Code Description**: The `azimuth` function takes three input parameters: `h` (hour angle), `decl` (declination), and `lat` (latitude). It then calculates the azimuth angle using the formula:

`azimuth = atan2(sin(h), cos(h) * sin(lat) - tan(decl) * cos(lat))`

The `atan2` function is used to calculate the arctangent of the given expression, which results in the azimuth angle. The `sin`, `cos`, and `tan` functions are used to perform the necessary trigonometric calculations.

The azimuth angle is a measure of the horizontal direction of a celestial object, typically used in astronomy and navigation. It is the angle between the north direction and the direction of the object, measured clockwise from the north.

This function can be useful in applications that involve tracking the position of celestial objects, such as in astronomy, or in navigation systems that need to determine the direction of a target.\\
## Code: 
```
angle_type Trigonometry::azimuth(angle_type h, angle_type decl, angle_type lat) {
    return ATan2(Sin(h), Cos(h) * Sin(lat) - Tan(decl) * Cos(lat));
  }
```