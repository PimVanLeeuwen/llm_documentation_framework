`hourAngle`: The function of `hourAngle` is to calculate the hour angle of the sun given the altitude, declination, and latitude.

**Code Description**: The `hourAngle` function takes three parameters: `alt` (the altitude of the sun), `dec` (the declination of the sun), and `lat` (the latitude of the observer). It then calculates the hour angle of the sun using the formula:

`hourAngle = ACos((Sin(alt) - Sin(dec) * Sin(lat)) / (Cos(dec) * Cos(lat)))`

The hour angle is the angle between the observer's meridian and the sun's meridian, measured westward from the observer's meridian. This angle is used to determine the time of day, as the hour angle changes throughout the day as the sun appears to move across the sky.

The formula used in the `hourAngle` function is derived from the spherical trigonometry relationship between the altitude, declination, and latitude of the sun. The `Sin(alt)` term represents the sine of the sun's altitude, `Sin(dec)` represents the sine of the sun's declination, and `Sin(lat)` represents the sine of the observer's latitude. The `Cos(dec)` and `Cos(lat)` terms represent the cosine of the sun's declination and the observer's latitude, respectively.

The `ACos` function is used to calculate the inverse cosine of the expression, which gives the hour angle in radians. This value can then be converted to degrees or hours, depending on the application.

The `hourAngle` function is a useful tool in astronomy and navigation, as it allows the time of day to be determined from the position of the sun in the sky. It is commonly used in solar tracking systems, sundials, and other applications that require knowledge of the sun's position.\\
## Code: 
```
angle_type Trigonometry::hourAngle(angle_type alt, angle_type dec, angle_type lat) {
    return ACos((Sin(alt) - Sin(dec) * Sin(lat)) / (Cos(dec) * Cos(lat)));
  }
```