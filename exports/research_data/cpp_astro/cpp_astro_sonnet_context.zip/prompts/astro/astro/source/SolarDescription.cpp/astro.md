# PROMPT
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/SolarDescription.cpp` \
**Type:** `Class` \
**Class Name:** `astro` \
**Code Content:** \
`namespace astro {

  using namespace astro::literals;
  using namespace astro::math;
  using C = Constant;

  template <Planet PLANET>
  SolarDescription<PLANET>::SolarDescription(const JulianDate &date) {
    // M = M0 + M1 (J - J2000)
    _meanAnomaly = C::get<PLANET, C::M0>() + C::get<PLANET, C::M1>() * date.truncated2000();
    // C ~ C1 sin(M) + C2 sin(2M) + C3 sin(3M) + C4 sin(4M) + C5 sin(5M) + C6 sin(6M)
    _equationOfTheCenter = C::get<PLANET, C::C1>() * Sin(_meanAnomaly) +
                           C::get<PLANET, C::C2>() * Sin(2.0 * _meanAnomaly) +
                           C::get<PLANET, C::C3>() * Sin(3.0 * _meanAnomaly) +
                           C::get<PLANET, C::C4>() * Sin(4.0 * _meanAnomaly) +
                           C::get<PLANET, C::C5>() * Sin(5.0 * _meanAnomaly) +
                           C::get<PLANET, C::C6>() * Sin(6.0 * _meanAnomaly);
    // l = M + C + Perihelion + 180
    _eclipticalLongitude = _meanAnomaly + _equationOfTheCenter + C::get<PLANET, C::Perihelion>() + 1_pi_rad;
  }

  template <Planet PLANET>
  angle_type SolarDescription<PLANET>::getDeclination() const {
    return Trigonometry::declination(_eclipticalLongitude, C::get<PLANET, C::Obliquity>());
  }

  template <Planet PLANET>
  angle_type SolarDescription<PLANET>::getRightAscension() const {
    return Trigonometry::rightAscension(_eclipticalLongitude, C::get<PLANET, C::Obliquity>());
  }

  ASTRO_TEMPLATE_CLASS_INSTANTIATE_FOR_EACH_PLANET(SolarDescription);

}`



## Children 
 This code contains the following methods/classes that are already documented: 
### SolarDescription 
This code defines a constructor for the `SolarDescription` class template, which calculates planetary positions. It computes the mean anomaly, equation of the center, and ecliptical longitude for a given planet at a specific Julian date. 
### getDeclination 
This method calculates the declination of a celestial object (specifically a planet) using its ecliptical longitude and the planet's obliquity. It utilizes the Trigonometry::declination function to perform the calculation, returning the result as an angle_type. 
### getRightAscension 
This method calculates the right ascension of a celestial object for a specific planet. It uses the object's ecliptical longitude and the planet's obliquity, calling the Trigonometry::rightAscension function to perform the calculation. 



## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`astro`: The function of `astro` is *FILL IN* 

**Code Description**: *FILL IN*
