# PROMPT
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/Observer.cpp/astro` \
**Type:** `Method` \
**Method Name:** `convertToHorizontalCoords` \
**Code Content:** \
`HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }`

## Calls 
 This code calls the following methods within the repository: 
### astro/astro/source/Trigonometry.cpp/astro.azimuth 
 - Explanation:  _This method calculates the azimuth angle given the hour angle (h), declination (decl), and latitude (lat). It uses trigonometric functions to compute the azimuth based on the celestial coordinates and observer's position._ 
### astro/astro/source/Trigonometry.cpp/astro.declination 
 - Explanation:  _This method calculates the declination of a celestial object given its celestial coordinates (longitude l and latitude b) and the obliquity of the ecliptic (e). It uses trigonometric functions to compute the declination angle based on the input parameters._ 
### astro/astro/source/Trigonometry.cpp/astro.altitude 
 - Explanation:  _This method calculates the altitude of a celestial object using its hour angle, declination, and the observer's latitude. It employs trigonometric functions to compute the altitude based on these input parameters._ 
### astro/astro/source/Trigonometry.cpp/astro.rightAscension 
 - Explanation:  _This method calculates the right ascension of a celestial object given its celestial longitude (l), celestial latitude (b), and the obliquity of the ecliptic (e). It uses trigonometric functions to convert ecliptic coordinates to equatorial coordinates, specifically determining the right ascension._ 
### astro/astro/source/Trigonometry.cpp/astro.hourAngle 
 - Explanation:  _This method calculates the hour angle given altitude, declination, and latitude angles. It uses trigonometric functions to compute the angle based on the spherical astronomy formula for hour angle._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`convertToHorizontalCoords`: The function of `convertToHorizontalCoords` is *FILL IN* 
**Parameters**:\
`const EquatorialCoords &ec`: *FILL IN* \

**Code Description**: *FILL IN*
