# PROMPT
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/Observer.cpp` \
**Type:** `Class` \
**Class Name:** `astro` \
**Code Content:** \
`namespace astro {

  template <Planet PLANET>
  static angle_type getSiderealTime(const JulianDate &date, angle_type longitudeEast) {
    using C = Constant;
    // Theta = Theta0 + Theta1 (J - J2000) - l_west
    return C::get<PLANET, C::Theta0>() +
           C::get<PLANET, C::Theta1>() * date.truncated2000() +
           longitudeEast;
  }

  template <Planet PLANET>
  Observer<PLANET>::Observer(const JulianDate &date, const GeographicalCoords &position) :
    _date(date),
    _position(position),
    _siderealTime(astro::getSiderealTime<PLANET>(_date, _position.longitude)) {}

  template <Planet PLANET>
  HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }

  ASTRO_TEMPLATE_CLASS_INSTANTIATE_FOR_EACH_PLANET(Observer);

}`



## Children 
 This code contains the following methods/classes that are already documented: 
### getSiderealTime 
This method calculates the sidereal time for a given Julian date and longitude. It uses constants and the provided date to compute the sidereal time, adjusting for the observer's longitude east of the prime meridian. 
### Observer 
This code defines a constructor for the Observer class, which initializes an observer with a given date and geographical position. It also calculates the sidereal time for the observer's location using the provided date and longitude. 
### convertToHorizontalCoords 
This method converts equatorial coordinates (right ascension and declination) to horizontal coordinates (azimuth and altitude) for a given observer position. It utilizes trigonometric calculations to perform the coordinate transformation, taking into account the observer's latitude and the hour angle derived from the right ascension. 



## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`astro`: The function of `astro` is *FILL IN* 

**Code Description**: *FILL IN*
