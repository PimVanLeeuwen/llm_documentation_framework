# PROMPT
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/Trigonometry.cpp` \
**Type:** `Class` \
**Class Name:** `astro` \
**Code Content:** \
`namespace astro {

  using namespace astro::math;

  angle_type Trigonometry::declination(angle_type l, angle_type e) {
    return ASin(Sin(e) * Sin(l));
  }

  angle_type Trigonometry::rightAscension(angle_type l, angle_type e) {
    return ATan2(Sin(l) * Cos(e), Cos(l));
  }

  angle_type Trigonometry::declination(angle_type l, angle_type b, angle_type e) {
    return ASin(Sin(b) * Cos(e) + Cos(b) * Sin(e) * Sin(l));
  }

  angle_type Trigonometry::rightAscension(angle_type l, angle_type b, angle_type e) {
    return ATan2(Sin(l) * Cos(e) - Tan(b) * Sin(e), Cos(l));
  }

  angle_type Trigonometry::azimuth(angle_type h, angle_type decl, angle_type lat) {
    return ATan2(Sin(h), Cos(h) * Sin(lat) - Tan(decl) * Cos(lat));
  }

  angle_type Trigonometry::altitude(angle_type h, angle_type decl, angle_type lat) {
    return ASin(Cos(h) * Cos(decl) * Cos(lat) + Sin(decl) * Sin(lat));
  }

  angle_type Trigonometry::hourAngle(angle_type alt, angle_type dec, angle_type lat) {
    return ACos((Sin(alt) - Sin(dec) * Sin(lat)) / (Cos(dec) * Cos(lat)));
  }

}`



## Children 
 This code contains the following methods/classes that are already documented: 
### declination 
This method calculates the declination angle using the latitude (l) and ecliptic longitude (e) as inputs. It applies the formula sin(declination) = sin(e) * sin(l) and returns the result using the inverse sine function (ASin). 
### rightAscension 
This method calculates the right ascension of a celestial object using its ecliptic longitude (l) and ecliptic latitude (e). It employs trigonometric functions to convert ecliptic coordinates to equatorial coordinates, specifically the right ascension. 
### declination 
This method calculates the declination of a celestial object given its celestial coordinates (longitude l and latitude b) and the obliquity of the ecliptic (e). It uses trigonometric functions to compute the declination angle based on the input parameters. 
### rightAscension 
This method calculates the right ascension of a celestial object given its celestial longitude (l), celestial latitude (b), and the obliquity of the ecliptic (e). It uses trigonometric functions to convert ecliptic coordinates to equatorial coordinates, specifically determining the right ascension. 
### azimuth 
This method calculates the azimuth angle given the hour angle (h), declination (decl), and latitude (lat). It uses trigonometric functions to compute the azimuth based on the celestial coordinates and observer's position. 
### altitude 
This method calculates the altitude of a celestial object using its hour angle, declination, and the observer's latitude. It employs trigonometric functions to compute the altitude based on these input parameters. 
### hourAngle 
This method calculates the hour angle given altitude, declination, and latitude angles. It uses trigonometric functions to compute the angle based on the spherical astronomy formula for hour angle. 



## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`astro`: The function of `astro` is *FILL IN* 

**Code Description**: *FILL IN*
