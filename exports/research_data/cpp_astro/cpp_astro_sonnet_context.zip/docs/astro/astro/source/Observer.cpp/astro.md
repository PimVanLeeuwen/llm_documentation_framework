`astro`: The function of `astro` is to provide astronomical calculations and coordinate conversions for different planets.

**Code Description**: This namespace contains template functions and classes for astronomical calculations. It includes a method to calculate sidereal time for a given planet, date, and longitude. The Observer class is templated for different planets and provides functionality to initialize an observer with a date and geographical position, as well as convert equatorial coordinates to horizontal coordinates. The code uses constants specific to each planet and employs trigonometric calculations for coordinate transformations. The namespace also includes a macro to instantiate the Observer class for each supported planet.\\
## Code: 
```
namespace astro {

  template <Planet PLANET>
  static angle_type getSiderealTime(const JulianDate &date, angle_type longitudeEast) {
    using C = Constant;
    // Theta = Theta0 + Theta1 (J - J2000) - l_west
    return C::get<PLANET, C::Theta0>() +
           C::get<PLANET, C::Theta1>() * date.truncated2000() +
           longitudeEast;
  }

  template <Planet PLANET>
  Observer<PLANET>::Observer(const JulianDate &date, const GeographicalCoords &position) :
    _date(date),
    _position(position),
    _siderealTime(astro::getSiderealTime<PLANET>(_date, _position.longitude)) {}

  template <Planet PLANET>
  HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }

  ASTRO_TEMPLATE_CLASS_INSTANTIATE_FOR_EACH_PLANET(Observer);

}
```