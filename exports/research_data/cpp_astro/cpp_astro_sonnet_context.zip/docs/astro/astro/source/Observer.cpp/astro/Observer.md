`Observer`: The function of `Observer` is to initialize an Observer object with a given date and geographical position.

**Parameters**:
`const JulianDate &date`: The Julian date for the observation
`const GeographicalCoords &position`: The geographical coordinates of the observer's location

**Code Description**: This constructor initializes an Observer object for a specific planet (templated as PLANET). It takes two parameters: a Julian date and geographical coordinates. The constructor sets the internal _date member to the provided date and _position member to the given geographical coordinates. It then calculates the sidereal time for the observer's location using the astro::getSiderealTime function, passing the date and longitude from the position. The calculated sidereal time is stored in the _siderealTime member. This setup allows the Observer object to represent an observer at a specific time and location, with the necessary information for astronomical calculations.\\
## Code: 
```
Observer<PLANET>::Observer(const JulianDate &date, const GeographicalCoords &position) :
    _date(date),
    _position(position),
    _siderealTime(astro::getSiderealTime<PLANET>(_date, _position.longitude)) {}
```