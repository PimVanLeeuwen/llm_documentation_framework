`altitude`: The function of `altitude` is to calculate the altitude of a celestial object.

**Parameters**:
`angle_type h`: The hour angle of the celestial object
`angle_type decl`: The declination of the celestial object
`angle_type lat`: The latitude of the observer

**Code Description**: This method computes the altitude of a celestial object using spherical trigonometry. It takes three angular inputs: the hour angle (h), declination (decl), and observer's latitude (lat). The function uses the sine and cosine of these angles in the formula: sin(altitude) = cos(h) * cos(decl) * cos(lat) + sin(decl) * sin(lat). The result is then obtained by taking the arcsine (ASin) of this calculation, which gives the altitude angle. This formula is derived from the celestial sphere model and is commonly used in astronomical calculations to determine the position of celestial objects in the sky relative to an observer on Earth.\\
## Code: 
```
angle_type Trigonometry::altitude(angle_type h, angle_type decl, angle_type lat) {
    return ASin(Cos(h) * Cos(decl) * Cos(lat) + Sin(decl) * Sin(lat));
  }
```