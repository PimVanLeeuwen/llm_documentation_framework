`getRightAscension`: The function of `getRightAscension` is to calculate and return the right ascension of a planet.

**Code Description**: This method is part of the `SolarDescription` class template, specialized for a specific planet. It calculates the right ascension of the planet using the planet's ecliptical longitude and the obliquity of the ecliptic. The method calls the `Trigonometry::rightAscension` function, passing two arguments: `_eclipticalLongitude` (likely a member variable representing the planet's ecliptical longitude) and the obliquity of the ecliptic for the specific planet, obtained using `C::get<PLANET, C::Obliquity>()`. The result is returned as an `angle_type`, which is likely a type alias for a floating-point or angular measurement type. This method allows for the conversion from ecliptic coordinates to equatorial coordinates, specifically computing the right ascension component.\\
## Code: 
```
angle_type SolarDescription<PLANET>::getRightAscension() const {
    return Trigonometry::rightAscension(_eclipticalLongitude, C::get<PLANET, C::Obliquity>());
  }
```