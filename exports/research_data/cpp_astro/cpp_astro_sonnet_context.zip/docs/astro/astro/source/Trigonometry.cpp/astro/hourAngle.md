`hourAngle`: The function of `hourAngle` is to calculate the hour angle of a celestial object.

**Parameters**:
`angle_type alt`: The altitude of the celestial object
`angle_type dec`: The declination of the celestial object
`angle_type lat`: The latitude of the observer

**Code Description**: This method calculates the hour angle of a celestial object using the object's altitude, declination, and the observer's latitude. It employs the spherical trigonometry formula for the hour angle. The function uses sine and cosine operations (Sin, Cos) on the input angles, and then applies the inverse cosine function (ACos) to obtain the final result. The hour angle is returned as an angle_type, which is likely a custom type for representing angles in the astro library.\\
## Code: 
```
angle_type Trigonometry::hourAngle(angle_type alt, angle_type dec, angle_type lat) {
    return ACos((Sin(alt) - Sin(dec) * Sin(lat)) / (Cos(dec) * Cos(lat)));
  }
```