`rightAscension`: The function of `rightAscension` is to calculate the right ascension of a celestial object.

**Parameters**:
`angle_type l`: Celestial longitude of the object
`angle_type b`: Celestial latitude of the object
`angle_type e`: Obliquity of the ecliptic

**Code Description**: This method computes the right ascension of a celestial object using its celestial coordinates and the obliquity of the ecliptic. It employs the arctangent of two arguments (ATan2) to determine the angle. The calculation involves trigonometric functions (Sin, Cos, Tan) applied to the input angles. The formula used is a standard astronomical equation for converting ecliptic coordinates to equatorial coordinates. The result is returned as an angle, representing the right ascension of the object in the celestial sphere.\\
## Code: 
```
angle_type Trigonometry::rightAscension(angle_type l, angle_type b, angle_type e) {
    return ATan2(Sin(l) * Cos(e) - Tan(b) * Sin(e), Cos(l));
  }
```