`SolarDescription`: The function of `SolarDescription` is to calculate various solar parameters for a specific planet at a given date.

**Parameters**:
`const JulianDate &date`: The Julian date for which the solar parameters are to be calculated.

**Code Description**: This constructor initializes a `SolarDescription` object for a specific planet (defined by the template parameter `PLANET`) at a given Julian date. It performs three main calculations:

1. Mean Anomaly: Calculated using the formula M = M0 + M1 * (J - J2000), where M0 and M1 are planet-specific constants, and J is the given Julian date.

2. Equation of the Center: Computed using a series of sine terms, each with planet-specific coefficients (C1 to C6). This approximates the difference between the mean anomaly and the true anomaly.

3. Ecliptical Longitude: Derived from the mean anomaly, equation of the center, the planet's perihelion, and an additional 180 degrees (π radians).

The method uses template-based constant retrieval (C::get<PLANET, ...>()) to access planet-specific parameters. The results are stored in member variables _meanAnomaly, _equationOfTheCenter, and _eclipticalLongitude for later use.\\
## Code: 
```
SolarDescription<PLANET>::SolarDescription(const JulianDate &date) {
    // M = M0 + M1 (J - J2000)
    _meanAnomaly = C::get<PLANET, C::M0>() + C::get<PLANET, C::M1>() * date.truncated2000();
    // C ~ C1 sin(M) + C2 sin(2M) + C3 sin(3M) + C4 sin(4M) + C5 sin(5M) + C6 sin(6M)
    _equationOfTheCenter = C::get<PLANET, C::C1>() * Sin(_meanAnomaly) +
                           C::get<PLANET, C::C2>() * Sin(2.0 * _meanAnomaly) +
                           C::get<PLANET, C::C3>() * Sin(3.0 * _meanAnomaly) +
                           C::get<PLANET, C::C4>() * Sin(4.0 * _meanAnomaly) +
                           C::get<PLANET, C::C5>() * Sin(5.0 * _meanAnomaly) +
                           C::get<PLANET, C::C6>() * Sin(6.0 * _meanAnomaly);
    // l = M + C + Perihelion + 180
    _eclipticalLongitude = _meanAnomaly + _equationOfTheCenter + C::get<PLANET, C::Perihelion>() + 1_pi_rad;
  }
```