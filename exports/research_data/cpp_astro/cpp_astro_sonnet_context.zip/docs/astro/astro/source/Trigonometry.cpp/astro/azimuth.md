`azimuth`: The function of `azimuth` is to calculate the azimuth angle given the hour angle, declination, and latitude.

**Parameters**:
`angle_type h`: The hour angle
`angle_type decl`: The declination angle
`angle_type lat`: The latitude angle

**Code Description**: This method calculates the azimuth angle using spherical trigonometry. It takes three input parameters: hour angle (h), declination (decl), and latitude (lat). The function uses the arctangent of two arguments (ATan2) to compute the azimuth. The formula used is:

azimuth = ATan2(Sin(h), Cos(h) * Sin(lat) - Tan(decl) * Cos(lat))

This formula is derived from the spherical triangle formed by the zenith, celestial pole, and the observed celestial object. The Sin(h) represents the east-west component, while the denominator (Cos(h) * Sin(lat) - Tan(decl) * Cos(lat)) represents the north-south component of the object's position relative to the observer. The ATan2 function is used to handle all quadrants correctly and avoid division by zero issues.\\
## Code: 
```
angle_type Trigonometry::azimuth(angle_type h, angle_type decl, angle_type lat) {
    return ATan2(Sin(h), Cos(h) * Sin(lat) - Tan(decl) * Cos(lat));
  }
```