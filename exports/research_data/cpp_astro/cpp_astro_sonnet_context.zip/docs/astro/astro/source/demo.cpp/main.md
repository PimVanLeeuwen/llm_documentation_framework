`main`: The function of `main` is to demonstrate the usage of the astro library for calculating solar times and positions on Earth and Mars.

**Code Description**: This main function showcases two primary use cases of the astro library. First, it calculates various solar times for a specific location on Earth. It sets up an observer in Australia (latitude -25°20'42", longitude 131°02'10") and calculates solar noon, sunrise, sunset, astronomical dawn, and astronomical dusk for the current UTC time. The results are adjusted to the local time zone (UTC+9:30) and printed to the console.

Second, it demonstrates how to calculate the Sun's altitude on Mars. It creates an observer on Mars (latitude 39.662°, longitude -0.226°) and prints the Sun's altitude in degrees.

The code utilizes several key components of the astro library:
1. GeographicalCoords for specifying locations
2. Observer and Sun templates for Earth and Mars
3. JulianDate for time representation
4. SolarTimesCalculator for computing solar events

It also employs Boost's date-time library for handling UTC time and time zone offsets. The code showcases the library's flexibility in handling astronomical calculations for different celestial bodies and demonstrates how to convert between different time representations.\\
## Code: 
```
int main() {
  using namespace astro;
  using namespace astro::literals;

  namespace bpt = boost::posix_time;

  bpt::ptime utc(bpt::second_clock::universal_time());
  {
    auto timeZone = bpt::hours(9) + bpt::minutes(30);

    constexpr auto position = GeographicalCoords{
                    -(25_deg + 20_arcmin + 42_arcsec),
                     131_deg +  2_arcmin + 10_arcsec};

    Observer<Earth> observer(JulianDate(utc), position);
    Sun<Earth> sun(observer);

    auto solarTimes = sun.getSolarTimesCalculator();
    auto sunriseAndSunset = solarTimes.calculateSunriseAndSunset();

    auto getLocalTime = [&timeZone](const JulianDate &date) {
      return date.toPosixTime() + timeZone;
    };

    std::cout << "Noon    = " << getLocalTime(solarTimes.getTransit()) << '\n';
    std::cout << "Sunrise = " << getLocalTime(sunriseAndSunset.rise) << '\n';
    std::cout << "Sunset  = " << getLocalTime(sunriseAndSunset.set) << '\n';

    auto duskAndDawn = solarTimes.calculate(-18_deg);

    std::cout << "Astronomical Dawn  = " << getLocalTime(duskAndDawn.rise) << '\n';
    std::cout << "Astronomical Dusk = " << getLocalTime(duskAndDawn.set) << '\n';
  }
  {
    Observer<Mars> observer(JulianDate(utc), {39.662_deg, -0.226_deg});
    Sun<Mars> sun(observer);

    std::cout << sun.getAltitude().deg() << '\n';
  }
}
```