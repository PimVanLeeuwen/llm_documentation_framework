`SolarTimesCalculator`: The function of `SolarTimesCalculator` is to initialize a calculator for solar times on a specific planet.

**Parameters**:
`const Sun<PLANET> &sun`: A reference to a Sun object for the specified planet, containing observer and position information.

**Code Description**: This constructor initializes a SolarTimesCalculator object for a given planet. It takes a Sun object as input and performs the following steps:
1. Stores the provided Sun object in the `_sun` member variable.
2. Calculates the Julian cycle using the `getJulianCycle` function, passing the observer's date and longitude from the Sun object. The result is stored in the `_cycle` member variable.
3. Computes the solar transit time by calling the `calculateSolarTransit` function with an initial argument of 0 radians. The result is stored in the `_transit` member variable.

These initializations set up the necessary data for subsequent solar time calculations specific to the given planet and observer location.\\
## Code: 
```
SolarTimesCalculator<PLANET>::SolarTimesCalculator(const Sun<PLANET> &sun) :
    _sun(sun),
    _cycle(getJulianCycle<PLANET>(
        _sun._observer.getDate(),
        _sun._observer.getPosition().longitude)),
    _transit(calculateSolarTransit(0_rad)) {}
```