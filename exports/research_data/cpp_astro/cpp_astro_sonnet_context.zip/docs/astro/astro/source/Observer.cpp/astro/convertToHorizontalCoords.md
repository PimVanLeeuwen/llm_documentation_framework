`convertToHorizontalCoords`: The function of `convertToHorizontalCoords` is to convert equatorial coordinates to horizontal coordinates.

**Parameters**:
`const EquatorialCoords &ec`: A constant reference to an EquatorialCoords object containing the right ascension and declination of a celestial object.

**Code Description**: This method takes equatorial coordinates (right ascension and declination) and converts them to horizontal coordinates (azimuth and altitude) for the observer's location. It first calculates the hour angle by calling the `convertToHourAngle` method (not shown in the provided code) using the right ascension. Then, it uses the Trigonometry class to compute the azimuth and altitude. The azimuth is calculated using the hour angle, declination, and the observer's latitude. The altitude is similarly computed using the same parameters. The resulting horizontal coordinates (azimuth and altitude) are stored in an HorizontalCoords object and returned. This conversion is essential for determining the position of celestial objects relative to an observer's local horizon.\\
## Code: 
```
HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }
```