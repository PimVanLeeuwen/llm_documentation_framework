`getRightAscension`: The function of `getRightAscension` is to calculate and return the right ascension of a celestial body.

**Code Description**: This method is a member function of the `SolarDescription` class template, specialized for a specific `PLANET`. It returns an `angle_type` value representing the right ascension of the celestial body. The calculation is performed using the `Trigonometry::rightAscension` function, which takes two parameters: the ecliptical longitude (`_eclipticalLongitude`) and the obliquity of the ecliptic (obtained from `C::get<PLANET, C::Obliquity>()`). The ecliptical longitude is likely a member variable of the `SolarDescription` class, while the obliquity is retrieved using a constant or configuration class `C`. The use of template parameters suggests that this function can be used for different celestial bodies (planets) with specific obliquity values.\\
## Code: 
```
angle_type SolarDescription<PLANET>::getRightAscension() const {
    return Trigonometry::rightAscension(_eclipticalLongitude, C::get<PLANET, C::Obliquity>());
  }
```