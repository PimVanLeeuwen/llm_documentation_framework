`hourAngle`: The function of `hourAngle` is to calculate the hour angle of a celestial object given its altitude, declination, and the observer's latitude.

**Code Description**: This method is part of a Trigonometry class and takes three angle_type parameters: alt (altitude), dec (declination), and lat (latitude). It uses these values to compute the hour angle using the spherical law of cosines formula. The function applies trigonometric operations (sine, cosine, and arccosine) to determine the angular distance between the celestial object's position and the observer's meridian. The result is returned as an angle_type, representing the hour angle in the same units as the input parameters.\\
## Code: 
```
angle_type Trigonometry::hourAngle(angle_type alt, angle_type dec, angle_type lat) {
    return ACos((Sin(alt) - Sin(dec) * Sin(lat)) / (Cos(dec) * Cos(lat)));
  }
```