`getJulianCycle`: The function of `getJulianCycle` is to calculate the Julian cycle for a given date and longitude.

**Code Description**: This function takes two parameters: a `JulianDate` object and a longitude value (`longitudeEast`) of type `angle_type`. It calculates the Julian cycle using a formula that involves the input date, longitude, and several constants. The function first subtracts a constant (`C::J0`) from the truncated year 2000 value of the input date. This difference is then divided by another constant (`C::J3`). The result is added to half the input longitude divided by 2π radians. Finally, the sum is rounded to the nearest integer using `std::round()`. The calculated Julian cycle is returned as a `float_type` value. This function is likely part of a larger astronomical calculation system, possibly related to solar position or time calculations.\\
## Code: 
```
static float_type getJulianCycle(const JulianDate &date, angle_type longitudeEast) {
    return std::round(
        (date.truncated2000() - C::get<PLANET, C::J0>()) / C::get<PLANET, C::J3>() +
         longitudeEast / 2_pi_rad);
  }
```