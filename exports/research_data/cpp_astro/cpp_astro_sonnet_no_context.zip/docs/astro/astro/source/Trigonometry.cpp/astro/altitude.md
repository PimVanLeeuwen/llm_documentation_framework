`altitude`: The function of `altitude` is to calculate the altitude of a celestial object given its hour angle, declination, and the observer's latitude.

**Code Description**: This method is part of a Trigonometry class and takes three parameters: 'h' (hour angle), 'decl' (declination), and 'lat' (latitude), all of type angle_type. It uses the sine and cosine functions to compute the altitude using the formula: altitude = arcsin(cos(h) * cos(decl) * cos(lat) + sin(decl) * sin(lat)). The result is returned as an angle_type, representing the altitude of the celestial object above the horizon.\\
## Code: 
```
angle_type Trigonometry::altitude(angle_type h, angle_type decl, angle_type lat) {
    return ASin(Cos(h) * Cos(decl) * Cos(lat) + Sin(decl) * Sin(lat));
  }
```