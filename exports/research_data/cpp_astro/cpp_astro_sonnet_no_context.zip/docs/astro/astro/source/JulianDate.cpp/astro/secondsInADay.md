`secondsInADay`: The function of `secondsInADay` is to return the number of seconds in a day.

**Code Description**: This is a static constexpr function that calculates and returns the number of seconds in a day. It multiplies 24 (hours in a day) by 3600 (seconds in an hour) to get 86,400, which is the total number of seconds in a 24-hour day. The use of constexpr allows this calculation to be performed at compile-time, potentially improving runtime performance. Being static, it can be called without instantiating an object of the class it belongs to.\\
## Code: 
```
static constexpr long unsigned secondsInADay() {
    return 24 * 3600;
  }
```