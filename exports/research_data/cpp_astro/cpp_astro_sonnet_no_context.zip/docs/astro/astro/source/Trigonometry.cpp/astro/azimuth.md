`azimuth`: The function of `azimuth` is to calculate the azimuth angle given the hour angle, declination, and latitude.

**Code Description**: This method is part of a Trigonometry class and calculates the azimuth angle using spherical trigonometry. It takes three parameters: 'h' (hour angle), 'decl' (declination), and 'lat' (latitude), all of type 'angle_type'. The function uses the arctangent of two arguments (ATan2) to compute the azimuth. The formula implemented is a standard astronomical equation for determining the azimuth of a celestial object. It utilizes sine (Sin), cosine (Cos), and tangent (Tan) functions, suggesting that the angle_type is likely in radians. The result is returned as an angle_type, representing the azimuth angle.\\
## Code: 
```
angle_type Trigonometry::azimuth(angle_type h, angle_type decl, angle_type lat) {
    return ATan2(Sin(h), Cos(h) * Sin(lat) - Tan(decl) * Cos(lat));
  }
```