`convertToHorizontalCoords`: The function of `convertToHorizontalCoords` is to convert equatorial coordinates to horizontal coordinates.

**Code Description**: This method is a member of the `Observer` class template, which is parameterized with a `PLANET` type. It takes an `EquatorialCoords` object as input and returns a `HorizontalCoords` object. The conversion process involves several steps:

1. It creates a `HorizontalCoords` object to store the result.
2. It calls `convertToHourAngle` (not shown in this snippet) to convert the right ascension to hour angle.
3. It uses the `Trigonometry::azimuth` function to calculate the azimuth, passing the hour angle, declination, and the observer's latitude.
4. It uses the `Trigonometry::altitude` function to calculate the altitude, using the same parameters.
5. Finally, it returns the calculated horizontal coordinates.

The method uses the observer's position (specifically the latitude) stored in the `_position` member variable. This conversion is useful in astronomy for transforming celestial coordinates from the equatorial system to the horizontal system, which is based on the observer's local horizon.\\
## Code: 
```
HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }
```