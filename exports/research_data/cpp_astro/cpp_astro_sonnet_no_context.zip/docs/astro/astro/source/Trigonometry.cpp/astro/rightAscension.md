`rightAscension`: The function of `rightAscension` is to calculate the right ascension coordinate in celestial astronomy.

**Code Description**: This method is part of a Trigonometry class and takes three angle parameters: l (longitude), b (latitude), and e (obliquity of the ecliptic). It uses trigonometric functions to convert celestial coordinates from the ecliptic system to the equatorial system. The function returns the right ascension as an angle, using the arctangent (ATan2) of two expressions involving sines, cosines, and tangents of the input angles. This calculation is based on spherical trigonometry formulas used in astronomical coordinate transformations.\\
## Code: 
```
angle_type Trigonometry::rightAscension(angle_type l, angle_type b, angle_type e) {
    return ATan2(Sin(l) * Cos(e) - Tan(b) * Sin(e), Cos(l));
  }
```