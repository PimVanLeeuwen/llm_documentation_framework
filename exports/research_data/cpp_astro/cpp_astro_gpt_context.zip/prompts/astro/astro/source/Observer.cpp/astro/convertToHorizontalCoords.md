# PROMPT
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/Observer.cpp/astro` \
**Type:** `Method` \
**Method Name:** `convertToHorizontalCoords` \
**Code Content:** \
`HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }`

## Calls 
 This code calls the following methods within the repository: 
### astro/astro/source/Trigonometry.cpp/astro.altitude 
 - Explanation:  _This method calculates the altitude angle using the given hour angle (h), declination (decl), and latitude (lat). It returns the result of the altitude angle using trigonometric functions._ 
### astro/astro/source/Trigonometry.cpp/astro.declination 
 - Explanation:  _Calculates the declination angle using the provided latitude (l), longitude (b), and obliquity (e) angles. The result is obtained using the trigonometric formula involving sine and cosine functions._ 
### astro/astro/source/Trigonometry.cpp/astro.rightAscension 
 - Explanation:  _Calculates the right ascension given the ecliptic longitude (l), latitude (b), and obliquity of the ecliptic (e). Uses trigonometric functions to determine the angle._ 
### astro/astro/source/Trigonometry.cpp/astro.azimuth 
 - Explanation:  _The `azimuth` method calculates the azimuth angle based on the hour angle (`h`), declination (`decl`), and latitude (`lat`). It uses trigonometric functions to determine the angle in a coordinate system._ 
### astro/astro/source/Trigonometry.cpp/astro.hourAngle 
 - Explanation:  _The `hourAngle` method calculates the hour angle of a celestial object based on its altitude, declination, and the observer's latitude. It uses trigonometric functions to compute the angle._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`convertToHorizontalCoords`: The function of `convertToHorizontalCoords` is *FILL IN* 
**Parameters**:\
`const EquatorialCoords &ec`: *FILL IN* \

**Code Description**: *FILL IN*
