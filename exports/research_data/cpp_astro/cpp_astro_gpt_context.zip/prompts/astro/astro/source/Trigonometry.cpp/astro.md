# PROMPT
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/Trigonometry.cpp` \
**Type:** `Class` \
**Class Name:** `astro` \
**Code Content:** \
`namespace astro {

  using namespace astro::math;

  angle_type Trigonometry::declination(angle_type l, angle_type e) {
    return ASin(Sin(e) * Sin(l));
  }

  angle_type Trigonometry::rightAscension(angle_type l, angle_type e) {
    return ATan2(Sin(l) * Cos(e), Cos(l));
  }

  angle_type Trigonometry::declination(angle_type l, angle_type b, angle_type e) {
    return ASin(Sin(b) * Cos(e) + Cos(b) * Sin(e) * Sin(l));
  }

  angle_type Trigonometry::rightAscension(angle_type l, angle_type b, angle_type e) {
    return ATan2(Sin(l) * Cos(e) - Tan(b) * Sin(e), Cos(l));
  }

  angle_type Trigonometry::azimuth(angle_type h, angle_type decl, angle_type lat) {
    return ATan2(Sin(h), Cos(h) * Sin(lat) - Tan(decl) * Cos(lat));
  }

  angle_type Trigonometry::altitude(angle_type h, angle_type decl, angle_type lat) {
    return ASin(Cos(h) * Cos(decl) * Cos(lat) + Sin(decl) * Sin(lat));
  }

  angle_type Trigonometry::hourAngle(angle_type alt, angle_type dec, angle_type lat) {
    return ACos((Sin(alt) - Sin(dec) * Sin(lat)) / (Cos(dec) * Cos(lat)));
  }

}`



## Children 
 This code contains the following methods/classes that are already documented: 
### declination 
The `declination` method calculates the declination angle using the given latitude (`l`) and obliquity (`e`) angles. It returns the arcsine of the product of the sines of these two angles. 
### rightAscension 
The `rightAscension` method calculates the right ascension angle given the ecliptic longitude (`l`) and the obliquity of the ecliptic (`e`). It uses the `ATan2` function to compute the angle based on the sine and cosine of the input angles. 
### declination 
Calculates the declination angle using the provided latitude (l), longitude (b), and obliquity (e) angles. The result is obtained using the trigonometric formula involving sine and cosine functions. 
### rightAscension 
Calculates the right ascension given the ecliptic longitude (l), latitude (b), and obliquity of the ecliptic (e). Uses trigonometric functions to determine the angle. 
### azimuth 
The `azimuth` method calculates the azimuth angle based on the hour angle (`h`), declination (`decl`), and latitude (`lat`). It uses trigonometric functions to determine the angle in a coordinate system. 
### altitude 
This method calculates the altitude angle using the given hour angle (h), declination (decl), and latitude (lat). It returns the result of the altitude angle using trigonometric functions. 
### hourAngle 
The `hourAngle` method calculates the hour angle of a celestial object based on its altitude, declination, and the observer's latitude. It uses trigonometric functions to compute the angle. 



## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`astro`: The function of `astro` is *FILL IN* 

**Code Description**: *FILL IN*
