`SolarDescription`: The function of `SolarDescription` is to calculate the mean anomaly, equation of the center, and ecliptical longitude for a given planet at a specified Julian date.

**Parameters**:\
`const JulianDate &date`: The Julian date for which the solar description calculations are to be performed.

**Code Description**: The `SolarDescription` constructor initializes the solar description for a specified planet by performing the following calculations:
1. **Mean Anomaly (`_meanAnomaly`)**: This is calculated using the formula `M = M0 + M1 * (J - J2000)`, where `M0` and `M1` are constants specific to the planet, and `J` is the Julian date truncated to the year 2000.
2. **Equation of the Center (`_equationOfTheCenter`)**: This is computed as a sum of sinusoidal terms involving the mean anomaly, each multiplied by planet-specific constants `C1` to `C6`.
3. **Ecliptical Longitude (`_eclipticalLongitude`)**: This is determined by adding the mean anomaly, the equation of the center, the planet's perihelion, and a constant value of 180 degrees (represented as `1_pi_rad`).\\
## Code: 
```
SolarDescription<PLANET>::SolarDescription(const JulianDate &date) {
    // M = M0 + M1 (J - J2000)
    _meanAnomaly = C::get<PLANET, C::M0>() + C::get<PLANET, C::M1>() * date.truncated2000();
    // C ~ C1 sin(M) + C2 sin(2M) + C3 sin(3M) + C4 sin(4M) + C5 sin(5M) + C6 sin(6M)
    _equationOfTheCenter = C::get<PLANET, C::C1>() * Sin(_meanAnomaly) +
                           C::get<PLANET, C::C2>() * Sin(2.0 * _meanAnomaly) +
                           C::get<PLANET, C::C3>() * Sin(3.0 * _meanAnomaly) +
                           C::get<PLANET, C::C4>() * Sin(4.0 * _meanAnomaly) +
                           C::get<PLANET, C::C5>() * Sin(5.0 * _meanAnomaly) +
                           C::get<PLANET, C::C6>() * Sin(6.0 * _meanAnomaly);
    // l = M + C + Perihelion + 180
    _eclipticalLongitude = _meanAnomaly + _equationOfTheCenter + C::get<PLANET, C::Perihelion>() + 1_pi_rad;
  }
```