`hourAngle`: The function of `hourAngle` is to calculate the hour angle of a celestial object based on its altitude, declination, and the observer's latitude. \
**Parameters**:\
`angle_type alt`: The altitude of the celestial object. \
`angle_type dec`: The declination of the celestial object. \
`angle_type lat`: The latitude of the observer. \

**Code Description**: The `hourAngle` method calculates the hour angle using the formula: 
\[ \text{hour angle} = \arccos\left(\frac{\sin(\text{alt}) - \sin(\text{dec}) \cdot \sin(\text{lat})}{\cos(\text{dec}) \cdot \cos(\text{lat})}\right) \]
It uses trigonometric functions to determine the hour angle, which is the angle between the observer's meridian and the hour circle passing through the celestial object. The result is obtained by taking the arccosine of the calculated value.\\
## Code: 
```
angle_type Trigonometry::hourAngle(angle_type alt, angle_type dec, angle_type lat) {
    return ACos((Sin(alt) - Sin(dec) * Sin(lat)) / (Cos(dec) * Cos(lat)));
  }
```