`azimuth`: The function of `azimuth` is to calculate the azimuth angle based on the hour angle, declination, and latitude.

**Parameters**:\
`angle_type h`: The hour angle, which is the measure of time since the celestial object last crossed the local meridian. \
`angle_type decl`: The declination, which is the angle between the celestial object and the celestial equator. \
`angle_type lat`: The latitude, which is the observer's latitude on Earth.

**Code Description**: The `azimuth` function calculates the azimuth angle using trigonometric functions. It uses the `ATan2` function to compute the arctangent of the quotient of its arguments, which are the sine of the hour angle and the difference between the product of the cosine of the hour angle and the sine of the latitude, and the product of the tangent of the declination and the cosine of the latitude. This calculation provides the azimuth angle, which is the compass direction from which the celestial object is observed.\\
## Code: 
```
angle_type Trigonometry::azimuth(angle_type h, angle_type decl, angle_type lat) {
    return ATan2(Sin(h), Cos(h) * Sin(lat) - Tan(decl) * Cos(lat));
  }
```