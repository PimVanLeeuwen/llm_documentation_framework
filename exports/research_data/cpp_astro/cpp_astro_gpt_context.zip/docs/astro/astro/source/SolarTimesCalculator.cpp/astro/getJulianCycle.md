`getJulianCycle`: The function of `getJulianCycle` is to calculate the Julian cycle number for a given date and longitude.

**Parameters**:\
`const JulianDate &date`: The Julian date for which the Julian cycle number is to be calculated.\
`angle_type longitudeEast`: The longitude in the east direction, expressed in radians.

**Code Description**: This method calculates the Julian cycle number by first truncating the given Julian date to the year 2000 epoch. It then subtracts a constant value `J0` from this truncated date and divides the result by another constant `J3`. The longitude in the east direction is divided by `2π` radians and added to the result. Finally, the sum is rounded to the nearest integer to obtain the Julian cycle number. The constants `J0` and `J3` are retrieved from a configuration or constants class `C` specific to the `PLANET` context.\\
## Code: 
```
static float_type getJulianCycle(const JulianDate &date, angle_type longitudeEast) {
    return std::round(
        (date.truncated2000() - C::get<PLANET, C::J0>()) / C::get<PLANET, C::J3>() +
         longitudeEast / 2_pi_rad);
  }
```