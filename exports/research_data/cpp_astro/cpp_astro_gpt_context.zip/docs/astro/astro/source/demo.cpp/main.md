`main`: The function of `main` is to calculate and display solar events (noon, sunrise, sunset, astronomical dawn, and dusk) for Earth and the altitude of the Sun for Mars at a given UTC time.

**Code Description**: 
The `main` function begins by setting up the necessary namespaces and obtaining the current UTC time using the Boost library. It then defines a time zone offset and geographical coordinates for an observer on Earth. Using these parameters, it creates an `Observer` object for Earth and a `Sun` object associated with this observer. The function calculates solar events such as noon, sunrise, sunset, astronomical dawn, and dusk using the `SolarTimesCalculator` and converts these times to local time by adding the time zone offset. The results are printed to the console.

Next, the function sets up an observer on Mars with specific coordinates and calculates the altitude of the Sun for this observer, printing the result to the console. This demonstrates the use of the `Observer` and `Sun` classes for different celestial bodies.\\
## Code: 
```
int main() {
  using namespace astro;
  using namespace astro::literals;

  namespace bpt = boost::posix_time;

  bpt::ptime utc(bpt::second_clock::universal_time());
  {
    auto timeZone = bpt::hours(9) + bpt::minutes(30);

    constexpr auto position = GeographicalCoords{
                    -(25_deg + 20_arcmin + 42_arcsec),
                     131_deg +  2_arcmin + 10_arcsec};

    Observer<Earth> observer(JulianDate(utc), position);
    Sun<Earth> sun(observer);

    auto solarTimes = sun.getSolarTimesCalculator();
    auto sunriseAndSunset = solarTimes.calculateSunriseAndSunset();

    auto getLocalTime = [&timeZone](const JulianDate &date) {
      return date.toPosixTime() + timeZone;
    };

    std::cout << "Noon    = " << getLocalTime(solarTimes.getTransit()) << '\n';
    std::cout << "Sunrise = " << getLocalTime(sunriseAndSunset.rise) << '\n';
    std::cout << "Sunset  = " << getLocalTime(sunriseAndSunset.set) << '\n';

    auto duskAndDawn = solarTimes.calculate(-18_deg);

    std::cout << "Astronomical Dawn  = " << getLocalTime(duskAndDawn.rise) << '\n';
    std::cout << "Astronomical Dusk = " << getLocalTime(duskAndDawn.set) << '\n';
  }
  {
    Observer<Mars> observer(JulianDate(utc), {39.662_deg, -0.226_deg});
    Sun<Mars> sun(observer);

    std::cout << sun.getAltitude().deg() << '\n';
  }
}
```