`rightAscension`: The function of `rightAscension` is to calculate the right ascension of a celestial object based on its ecliptic longitude, ecliptic latitude, and the obliquity of the ecliptic.

**Parameters**:\
`angle_type l`: The ecliptic longitude of the celestial object. \
`angle_type b`: The ecliptic latitude of the celestial object. \
`angle_type e`: The obliquity of the ecliptic.

**Code Description**: The `rightAscension` method calculates the right ascension using the formula:
\[ \alpha = \arctan2(\sin(l) \cdot \cos(e) - \tan(b) \cdot \sin(e), \cos(l)) \]
where:
- \(\sin\), \(\cos\), and \(\tan\) are trigonometric functions.
- \(\arctan2\) is the two-argument arctangent function that returns the angle whose tangent is the quotient of two specified numbers, taking into account the signs of both arguments to determine the correct quadrant.

The function returns the right ascension angle in the same unit as the input angles.\\
## Code: 
```
angle_type Trigonometry::rightAscension(angle_type l, angle_type b, angle_type e) {
    return ATan2(Sin(l) * Cos(e) - Tan(b) * Sin(e), Cos(l));
  }
```