`getRightAscension`: The function of `getRightAscension` is to calculate and return the right ascension of a celestial object.

**Code Description**: This method, `getRightAscension`, is a member of the `SolarDescription` class template, which is parameterized by `PLANET`. It calculates the right ascension of a celestial object (such as a planet) by calling the `Trigonometry::rightAscension` function. The calculation uses the object's ecliptical longitude (`_eclipticalLongitude`) and the obliquity of the ecliptic for the specified planet, which is retrieved using `C::get<PLANET, C::Obliquity>()`. The result is returned as an `angle_type`.\\
## Code: 
```
angle_type SolarDescription<PLANET>::getRightAscension() const {
    return Trigonometry::rightAscension(_eclipticalLongitude, C::get<PLANET, C::Obliquity>());
  }
```