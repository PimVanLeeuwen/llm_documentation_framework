`altitude`: The function of `altitude` is to calculate the altitude angle of a celestial object based on the hour angle, declination, and latitude.

**Parameters**:\
`angle_type h`: The hour angle of the celestial object. \
`angle_type decl`: The declination of the celestial object. \
`angle_type lat`: The latitude of the observer.

**Code Description**: The `altitude` method calculates the altitude angle using the formula: 
\[ \text{altitude} = \arcsin(\cos(h) \cdot \cos(\text{decl}) \cdot \cos(\text{lat}) + \sin(\text{decl}) \cdot \sin(\text{lat})) \]
This formula combines trigonometric functions to determine the altitude based on the provided hour angle, declination, and latitude. The `ASin` function computes the arcsine of the given expression, which represents the altitude angle in radians.\\
## Code: 
```
angle_type Trigonometry::altitude(angle_type h, angle_type decl, angle_type lat) {
    return ASin(Cos(h) * Cos(decl) * Cos(lat) + Sin(decl) * Sin(lat));
  }
```