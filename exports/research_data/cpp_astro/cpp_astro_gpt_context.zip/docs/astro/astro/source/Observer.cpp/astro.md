`astro`: The function of `astro` is to provide astronomical calculations and conversions related to observing celestial objects from different planets.

**Code Description**: 
The `astro` namespace contains functions and classes for astronomical calculations. The `getSiderealTime` function calculates the sidereal time for a given Julian date and longitude on a specified planet using predefined constants. The `Observer` class template is instantiated for each planet and is used to initialize an observer's position and date, and to calculate the sidereal time. The `convertToHorizontalCoords` method in the `Observer` class converts equatorial coordinates to horizontal coordinates, calculating azimuth and altitude based on the observer's location and the celestial object's position.\\
## Code: 
```
namespace astro {

  template <Planet PLANET>
  static angle_type getSiderealTime(const JulianDate &date, angle_type longitudeEast) {
    using C = Constant;
    // Theta = Theta0 + Theta1 (J - J2000) - l_west
    return C::get<PLANET, C::Theta0>() +
           C::get<PLANET, C::Theta1>() * date.truncated2000() +
           longitudeEast;
  }

  template <Planet PLANET>
  Observer<PLANET>::Observer(const JulianDate &date, const GeographicalCoords &position) :
    _date(date),
    _position(position),
    _siderealTime(astro::getSiderealTime<PLANET>(_date, _position.longitude)) {}

  template <Planet PLANET>
  HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }

  ASTRO_TEMPLATE_CLASS_INSTANTIATE_FOR_EACH_PLANET(Observer);

}
```