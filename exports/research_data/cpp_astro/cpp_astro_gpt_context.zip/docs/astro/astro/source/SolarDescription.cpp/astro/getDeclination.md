`getDeclination`: The function of `getDeclination` is to calculate and return the declination angle of a planet.

**Code Description**: The `getDeclination` method in the `SolarDescription` class template calculates the declination angle of a planet. It does this by calling the `Trigonometry::declination` function, passing the planet's ecliptical longitude and the obliquity of the ecliptic as arguments. The obliquity value is retrieved using the `C::get` method, which fetches the constant value associated with the specified planet and the obliquity parameter. The result is the declination angle, which is returned as an `angle_type`.\\
## Code: 
```
angle_type SolarDescription<PLANET>::getDeclination() const {
    return Trigonometry::declination(_eclipticalLongitude, C::get<PLANET, C::Obliquity>());
  }
```