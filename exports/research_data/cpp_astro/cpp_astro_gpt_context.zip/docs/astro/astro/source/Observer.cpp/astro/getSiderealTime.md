`getSiderealTime`: The function of `getSiderealTime` is to calculate the sidereal time at a given Julian date and longitude.

**Parameters**:\
`const JulianDate &date`: The Julian date for which the sidereal time is to be calculated. \
`angle_type longitudeEast`: The longitude in the east direction, used to adjust the sidereal time calculation.

**Code Description**: This method calculates the sidereal time using the formula `Theta = Theta0 + Theta1 * (J - J2000) + longitudeEast`. It retrieves the constants `Theta0` and `Theta1` from the `Constant` class, which are specific to the planet being considered. The term `date.truncated2000()` represents the number of Julian centuries since the J2000 epoch. The longitude in the east direction is added to the result to adjust for the observer's location.\\
## Code: 
```
static angle_type getSiderealTime(const JulianDate &date, angle_type longitudeEast) {
    using C = Constant;
    // Theta = Theta0 + Theta1 (J - J2000) - l_west
    return C::get<PLANET, C::Theta0>() +
           C::get<PLANET, C::Theta1>() * date.truncated2000() +
           longitudeEast;
  }
```