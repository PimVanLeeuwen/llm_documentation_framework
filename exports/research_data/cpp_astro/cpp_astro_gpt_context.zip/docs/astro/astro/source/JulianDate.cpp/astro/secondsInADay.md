`secondsInADay`: The function of `secondsInADay` is to return the number of seconds in a day.

**Code Description**: This static constexpr method calculates and returns the total number of seconds in a day by multiplying the number of hours in a day (24) by the number of seconds in an hour (3600). The result is a constant value of 86400 seconds.\\
## Code: 
```
static constexpr long unsigned secondsInADay() {
    return 24 * 3600;
  }
```