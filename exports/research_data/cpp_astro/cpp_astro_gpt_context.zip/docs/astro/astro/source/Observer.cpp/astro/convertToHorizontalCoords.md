`convertToHorizontalCoords`: The function of `convertToHorizontalCoords` is to convert equatorial coordinates into horizontal coordinates.

**Parameters**:\
`const EquatorialCoords &ec`: This parameter represents the input equatorial coordinates, which include right ascension and declination.

**Code Description**: 
The code calculates the horizontal coordinates (azimuth and altitude) from the given equatorial coordinates. It first converts the right ascension to an hour angle using the `convertToHourAngle` function. Then it uses the `Trigonometry::azimuth`, `Trigonometry::altitude`, and `Trigonometry::hourAngle` functions to calculate the azimuth, altitude, and hour angle respectively based on the input declination, latitude, and hour angle. The calculated horizontal coordinates are then returned as a `HorizontalCoords` object.\\
## Code: 
```
HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }
```