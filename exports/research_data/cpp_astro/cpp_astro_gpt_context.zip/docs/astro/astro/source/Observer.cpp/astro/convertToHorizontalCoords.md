`convertToHorizontalCoords`: The function of `convertToHorizontalCoords` is to convert equatorial coordinates to horizontal coordinates for a given observer's position.

**Parameters**:\
`const EquatorialCoords &ec`: The equatorial coordinates of the celestial object, which include right ascension and declination.

**Code Description**: This method converts the provided equatorial coordinates (right ascension and declination) to horizontal coordinates (azimuth and altitude) based on the observer's position. It first calculates the hour angle from the right ascension. Then, it uses trigonometric functions to compute the azimuth and altitude angles, considering the observer's latitude. The resulting horizontal coordinates are returned.\\
## Code: 
```
HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }
```