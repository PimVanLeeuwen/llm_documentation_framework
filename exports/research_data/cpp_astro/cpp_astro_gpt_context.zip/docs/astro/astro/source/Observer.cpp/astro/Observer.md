`Observer`: The function of `Observer` is to initialize an observer object with a specific date and geographical position, and to calculate the sidereal time for that date and position.

**Parameters**:\
`const JulianDate &date`: The Julian date representing the specific point in time for the observation.\
`const GeographicalCoords &position`: The geographical coordinates (latitude and longitude) representing the observer's location on Earth.

**Code Description**: This constructor initializes an `Observer` object for a celestial body (denoted as `PLANET`). It takes a Julian date and geographical coordinates as input parameters. The constructor sets the internal `_date` and `_position` members to the provided values. It also calculates the sidereal time for the given date and longitude using the `astro::getSiderealTime` method and stores it in the `_siderealTime` member.\\
## Code: 
```
Observer<PLANET>::Observer(const JulianDate &date, const GeographicalCoords &position) :
    _date(date),
    _position(position),
    _siderealTime(astro::getSiderealTime<PLANET>(_date, _position.longitude)) {}
```