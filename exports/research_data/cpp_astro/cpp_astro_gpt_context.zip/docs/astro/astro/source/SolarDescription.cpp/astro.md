`astro`: The function of `astro` is to provide astronomical calculations related to the positions of planets in the solar system.

**Code Description**: 
The `astro` namespace contains a template class `SolarDescription` that calculates the mean anomaly, equation of the center, and ecliptical longitude for a specified planet at a given Julian date. The class uses predefined constants specific to each planet for these calculations. The `getDeclination` method computes the declination angle of the planet using its ecliptical longitude and the obliquity of the ecliptic, while the `getRightAscension` method calculates the right ascension of the planet using the same parameters. These methods utilize trigonometric functions from the `Trigonometry` namespace. The class is instantiated for each planet using the `ASTRO_TEMPLATE_CLASS_INSTANTIATE_FOR_EACH_PLANET` macro.\\
## Code: 
```
namespace astro {

  using namespace astro::literals;
  using namespace astro::math;
  using C = Constant;

  template <Planet PLANET>
  SolarDescription<PLANET>::SolarDescription(const JulianDate &date) {
    // M = M0 + M1 (J - J2000)
    _meanAnomaly = C::get<PLANET, C::M0>() + C::get<PLANET, C::M1>() * date.truncated2000();
    // C ~ C1 sin(M) + C2 sin(2M) + C3 sin(3M) + C4 sin(4M) + C5 sin(5M) + C6 sin(6M)
    _equationOfTheCenter = C::get<PLANET, C::C1>() * Sin(_meanAnomaly) +
                           C::get<PLANET, C::C2>() * Sin(2.0 * _meanAnomaly) +
                           C::get<PLANET, C::C3>() * Sin(3.0 * _meanAnomaly) +
                           C::get<PLANET, C::C4>() * Sin(4.0 * _meanAnomaly) +
                           C::get<PLANET, C::C5>() * Sin(5.0 * _meanAnomaly) +
                           C::get<PLANET, C::C6>() * Sin(6.0 * _meanAnomaly);
    // l = M + C + Perihelion + 180
    _eclipticalLongitude = _meanAnomaly + _equationOfTheCenter + C::get<PLANET, C::Perihelion>() + 1_pi_rad;
  }

  template <Planet PLANET>
  angle_type SolarDescription<PLANET>::getDeclination() const {
    return Trigonometry::declination(_eclipticalLongitude, C::get<PLANET, C::Obliquity>());
  }

  template <Planet PLANET>
  angle_type SolarDescription<PLANET>::getRightAscension() const {
    return Trigonometry::rightAscension(_eclipticalLongitude, C::get<PLANET, C::Obliquity>());
  }

  ASTRO_TEMPLATE_CLASS_INSTANTIATE_FOR_EACH_PLANET(SolarDescription);

}
```