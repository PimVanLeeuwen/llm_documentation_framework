`getSiderealTime`: The function of `getSiderealTime` is to calculate the sidereal time at a given Julian date and longitude.

**Code Description**: 
- The function `getSiderealTime` takes two parameters: a `JulianDate` object `date` and an `angle_type` `longitudeEast`.
- It calculates the sidereal time using the formula: `Theta = Theta0 + Theta1 * (J - J2000) + longitudeEast`.
- `C::get<PLANET, C::Theta0>()` retrieves the constant `Theta0` for the planet.
- `C::get<PLANET, C::Theta1>()` retrieves the constant `Theta1` for the planet.
- `date.truncated2000()` computes the difference between the given Julian date and the Julian date for J2000.
- The result is the sum of `Theta0`, the product of `Theta1` and the truncated date, and the `longitudeEast`.
- The function returns the calculated sidereal time as an `angle_type`.\\
## Code: 
```
static angle_type getSiderealTime(const JulianDate &date, angle_type longitudeEast) {
    using C = Constant;
    // Theta = Theta0 + Theta1 (J - J2000) - l_west
    return C::get<PLANET, C::Theta0>() +
           C::get<PLANET, C::Theta1>() * date.truncated2000() +
           longitudeEast;
  }
```