`getJulianCycle`: The function of `getJulianCycle` is to calculate the Julian cycle number for a given date and longitude.

**Code Description**: 
- The function `getJulianCycle` takes two parameters: a `JulianDate` object `date` and an `angle_type` value `longitudeEast`.
- It calculates the Julian cycle number by performing the following steps:
  1. Subtracts a constant `J0` (retrieved using `C::get<PLANET, C::J0>()`) from the truncated Julian date (obtained using `date.truncated2000()`).
  2. Divides the result by another constant `J3` (retrieved using `C::get<PLANET, C::J3>()`).
  3. Adds the value of `longitudeEast` divided by `2_pi_rad` to the result.
  4. Rounds the final result to the nearest integer using `std::round`.
- The function returns the rounded Julian cycle number as a `float_type`.\\
## Code: 
```
static float_type getJulianCycle(const JulianDate &date, angle_type longitudeEast) {
    return std::round(
        (date.truncated2000() - C::get<PLANET, C::J0>()) / C::get<PLANET, C::J3>() +
         longitudeEast / 2_pi_rad);
  }
```