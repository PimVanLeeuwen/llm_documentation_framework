`azimuth`: The function of `azimuth` is to calculate the azimuth angle based on the hour angle, declination, and latitude.

**Code Description**: This function `azimuth` is a member of the `Trigonometry` class and takes three parameters: `h` (hour angle), `decl` (declination), and `lat` (latitude). It calculates the azimuth angle using the formula `ATan2(Sin(h), Cos(h) * Sin(lat) - Tan(decl) * Cos(lat))`. The `ATan2` function computes the arctangent of the quotient of its arguments, which helps in determining the angle in the correct quadrant. The `Sin`, `Cos`, and `Tan` functions are standard trigonometric functions that compute the sine, cosine, and tangent of the given angles, respectively. The result is the azimuth angle, which is typically used in navigation and astronomy to specify the direction of a celestial object.\\
## Code: 
```
angle_type Trigonometry::azimuth(angle_type h, angle_type decl, angle_type lat) {
    return ATan2(Sin(h), Cos(h) * Sin(lat) - Tan(decl) * Cos(lat));
  }
```