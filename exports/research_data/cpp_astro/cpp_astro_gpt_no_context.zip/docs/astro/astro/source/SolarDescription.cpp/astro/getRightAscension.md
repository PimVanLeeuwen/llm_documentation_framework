`getRightAscension`: The function of `getRightAscension` is to calculate and return the right ascension of a planet.

**Code Description**: This method, `getRightAscension`, is a member of the `SolarDescription` class template specialized for a specific `PLANET`. It calculates the right ascension of the planet by using its ecliptical longitude and the obliquity of the ecliptic. The method calls `Trigonometry::rightAscension`, passing the planet's ecliptical longitude and the obliquity (retrieved from a constant `C` class) as arguments, and returns the computed right ascension value.\\
## Code: 
```
angle_type SolarDescription<PLANET>::getRightAscension() const {
    return Trigonometry::rightAscension(_eclipticalLongitude, C::get<PLANET, C::Obliquity>());
  }
```