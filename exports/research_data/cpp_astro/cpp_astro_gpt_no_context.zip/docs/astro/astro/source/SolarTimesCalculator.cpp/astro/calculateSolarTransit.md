`calculateSolarTransit`: The function of `calculateSolarTransit` is to calculate the solar transit time for a given hour angle on a specified planet.

**Code Description**: 
- The function `calculateSolarTransit` is a member of the `SolarTimesCalculator` class template, which is specialized for a specific planet.
- It takes an `hourAngle` as input and returns a `JulianDate` representing the solar transit time.
- The function retrieves the observer's longitude (`longitudeEast`), the mean anomaly of the sun (`meanAnomaly`), and the ecliptic longitude of the sun (`eclipticLongitudeOfTheSun`).
- It calculates an `estimatedTransit` time using constants specific to the planet (`C::get<PLANET, C::J0>()` and `C::get<PLANET, C::J3>()`), the current cycle (`_cycle`), and the hour angle.
- The `transit` time is then refined by adding corrections based on the mean anomaly and the ecliptic longitude of the sun, using additional constants (`C::get<PLANET, C::J1>()` and `C::get<PLANET, C::J2>()`).
- The function returns the calculated transit time as a `JulianDate` object, converted from the truncated Julian date format.\\
## Code: 
```
JulianDate SolarTimesCalculator<PLANET>::calculateSolarTransit(const angle_type hourAngle) const {
    const auto longitudeEast = _sun._observer.getPosition().longitude;
    const auto meanAnomaly = _sun._sun.getMeanAnomaly();
    const auto eclipticLongitudeOfTheSun = _sun.getEclipticalLongitude();

    const auto estimatedTransit =
        C::get<PLANET, C::J0>() +
        C::get<PLANET, C::J3>() * (_cycle + (hourAngle - longitudeEast) / 2_pi_rad);
    const auto transit =
        estimatedTransit +
        C::get<PLANET, C::J1>() * math::Sin(meanAnomaly) +
        C::get<PLANET, C::J2>() * math::Sin(2.0 * eclipticLongitudeOfTheSun);
    // transit -= J3 * H(transit) / 360_deg // @todo repeat to improve precision
    return JulianDate::fromTruncated2000(transit);
  }
```