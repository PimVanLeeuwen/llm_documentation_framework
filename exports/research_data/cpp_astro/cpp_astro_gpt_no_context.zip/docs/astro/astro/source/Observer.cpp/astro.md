`astro`: The function of `astro` is to provide astronomical calculations related to sidereal time and coordinate transformations for different planets.

**Code Description**: 
- The `getSiderealTime` function template calculates the sidereal time for a given planet, Julian date, and longitude. It uses constants specific to the planet to compute the sidereal time.
- The `Observer` class template represents an observer on a specific planet. It is initialized with a Julian date and geographical coordinates, and it calculates the sidereal time for the observer's location.
- The `convertToHorizontalCoords` member function of the `Observer` class converts equatorial coordinates (right ascension and declination) to horizontal coordinates (azimuth and altitude) based on the observer's position and the calculated sidereal time.
- The `ASTRO_TEMPLATE_CLASS_INSTANTIATE_FOR_EACH_PLANET` macro instantiates the `Observer` class template for each planet, ensuring that the class is available for all defined planets.\\
## Code: 
```
namespace astro {

  template <Planet PLANET>
  static angle_type getSiderealTime(const JulianDate &date, angle_type longitudeEast) {
    using C = Constant;
    // Theta = Theta0 + Theta1 (J - J2000) - l_west
    return C::get<PLANET, C::Theta0>() +
           C::get<PLANET, C::Theta1>() * date.truncated2000() +
           longitudeEast;
  }

  template <Planet PLANET>
  Observer<PLANET>::Observer(const JulianDate &date, const GeographicalCoords &position) :
    _date(date),
    _position(position),
    _siderealTime(astro::getSiderealTime<PLANET>(_date, _position.longitude)) {}

  template <Planet PLANET>
  HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }

  ASTRO_TEMPLATE_CLASS_INSTANTIATE_FOR_EACH_PLANET(Observer);

}
```