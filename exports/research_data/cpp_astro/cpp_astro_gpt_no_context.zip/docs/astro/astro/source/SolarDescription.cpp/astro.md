`astro`: The function of `astro` is to provide astronomical calculations related to the positions of planets in the solar system.

**Code Description**: 
The `SolarDescription` class template in the `astro` namespace calculates the solar position parameters for a given planet and date. It uses the Julian Date to compute the mean anomaly, equation of the center, and ecliptical longitude of the planet. The class provides methods to retrieve the declination and right ascension of the planet based on these calculations.

- **Namespace and Usings**: The `astro` namespace includes other namespaces and constants for astronomical calculations.
- **Template Class**: `SolarDescription<PLANET>` is a template class instantiated for each planet.
- **Constructor**: The constructor takes a `JulianDate` object and calculates:
  - `_meanAnomaly`: The mean anomaly of the planet.
  - `_equationOfTheCenter`: The equation of the center using a series of sinusoidal terms.
  - `_eclipticalLongitude`: The ecliptical longitude, which is the sum of the mean anomaly, equation of the center, perihelion, and a constant (180 degrees).
- **Methods**:
  - `getDeclination()`: Returns the declination of the planet using its ecliptical longitude and obliquity.
  - `getRightAscension()`: Returns the right ascension of the planet using its ecliptical longitude and obliquity.
- **Instantiation**: The class is instantiated for each planet using the `ASTRO_TEMPLATE_CLASS_INSTANTIATE_FOR_EACH_PLANET` macro.\\
## Code: 
```
namespace astro {

  using namespace astro::literals;
  using namespace astro::math;
  using C = Constant;

  template <Planet PLANET>
  SolarDescription<PLANET>::SolarDescription(const JulianDate &date) {
    // M = M0 + M1 (J - J2000)
    _meanAnomaly = C::get<PLANET, C::M0>() + C::get<PLANET, C::M1>() * date.truncated2000();
    // C ~ C1 sin(M) + C2 sin(2M) + C3 sin(3M) + C4 sin(4M) + C5 sin(5M) + C6 sin(6M)
    _equationOfTheCenter = C::get<PLANET, C::C1>() * Sin(_meanAnomaly) +
                           C::get<PLANET, C::C2>() * Sin(2.0 * _meanAnomaly) +
                           C::get<PLANET, C::C3>() * Sin(3.0 * _meanAnomaly) +
                           C::get<PLANET, C::C4>() * Sin(4.0 * _meanAnomaly) +
                           C::get<PLANET, C::C5>() * Sin(5.0 * _meanAnomaly) +
                           C::get<PLANET, C::C6>() * Sin(6.0 * _meanAnomaly);
    // l = M + C + Perihelion + 180
    _eclipticalLongitude = _meanAnomaly + _equationOfTheCenter + C::get<PLANET, C::Perihelion>() + 1_pi_rad;
  }

  template <Planet PLANET>
  angle_type SolarDescription<PLANET>::getDeclination() const {
    return Trigonometry::declination(_eclipticalLongitude, C::get<PLANET, C::Obliquity>());
  }

  template <Planet PLANET>
  angle_type SolarDescription<PLANET>::getRightAscension() const {
    return Trigonometry::rightAscension(_eclipticalLongitude, C::get<PLANET, C::Obliquity>());
  }

  ASTRO_TEMPLATE_CLASS_INSTANTIATE_FOR_EACH_PLANET(SolarDescription);

}
```