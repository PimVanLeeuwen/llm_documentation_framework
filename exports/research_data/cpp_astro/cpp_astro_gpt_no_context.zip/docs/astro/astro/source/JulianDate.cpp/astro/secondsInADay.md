`secondsInADay`: The function of `secondsInADay` is to calculate the number of seconds in a day.

**Code Description**: This static constexpr function named `secondsInADay` returns the number of seconds in a day by multiplying the number of hours in a day (24) by the number of seconds in an hour (3600). The use of `constexpr` ensures that the value is computed at compile time, making it a constant expression.\\
## Code: 
```
static constexpr long unsigned secondsInADay() {
    return 24 * 3600;
  }
```