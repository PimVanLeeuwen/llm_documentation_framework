`JulianDate`: The function of `JulianDate` is to initialize a JulianDate object with a given Julian day and the number of seconds since noon.

**Code Description**: This constructor for the `JulianDate` class takes two parameters: `julianDay` and `secondsSinceNoon`. It initializes the private member variables `_day` and `_seconds` with these values, respectively. After initialization, it calls the `fix()` method to ensure the date and time values are properly adjusted or normalized.\\
## Code: 
```
JulianDate::JulianDate(long unsigned julianDay, long unsigned secondsSinceNoon) :
    _day(julianDay),
    _seconds(secondsSinceNoon) {
    fix();
  }
```