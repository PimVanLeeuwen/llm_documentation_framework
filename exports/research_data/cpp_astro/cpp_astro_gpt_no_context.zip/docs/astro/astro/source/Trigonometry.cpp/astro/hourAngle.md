`hourAngle`: The function of `hourAngle` is to calculate the hour angle of a celestial object based on its altitude, declination, and the observer's latitude.

**Code Description**: The `hourAngle` function in the `Trigonometry` class takes three parameters: `alt` (altitude), `dec` (declination), and `lat` (latitude), all of which are of type `angle_type`. It calculates the hour angle using the formula:

\[ \text{hour angle} = \arccos\left(\frac{\sin(\text{alt}) - \sin(\text{dec}) \cdot \sin(\text{lat})}{\cos(\text{dec}) \cdot \cos(\text{lat})}\right) \]

The function returns the result of this calculation, which is the hour angle of the celestial object. The trigonometric functions `Sin`, `Cos`, and `ACos` are used to perform the necessary calculations.\\
## Code: 
```
angle_type Trigonometry::hourAngle(angle_type alt, angle_type dec, angle_type lat) {
    return ACos((Sin(alt) - Sin(dec) * Sin(lat)) / (Cos(dec) * Cos(lat)));
  }
```