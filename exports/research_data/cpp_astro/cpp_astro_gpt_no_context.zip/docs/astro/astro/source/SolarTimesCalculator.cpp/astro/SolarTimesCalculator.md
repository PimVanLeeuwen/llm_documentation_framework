`SolarTimesCalculator`: The function of `SolarTimesCalculator` is to initialize an instance of the `SolarTimesCalculator` class for a given planet.

**Code Description**: This constructor initializes the `SolarTimesCalculator` object using a reference to a `Sun` object specific to a planet. It sets the `_sun` member variable to the provided `Sun` object. It then calculates the Julian cycle for the observer's date and longitude using the `getJulianCycle` function and assigns it to the `_cycle` member variable. Finally, it calculates the solar transit at 0 radians using the `calculateSolarTransit` function and assigns it to the `_transit` member variable.\\
## Code: 
```
SolarTimesCalculator<PLANET>::SolarTimesCalculator(const Sun<PLANET> &sun) :
    _sun(sun),
    _cycle(getJulianCycle<PLANET>(
        _sun._observer.getDate(),
        _sun._observer.getPosition().longitude)),
    _transit(calculateSolarTransit(0_rad)) {}
```