`convertToHorizontalCoords`: The function of `convertToHorizontalCoords` is to convert equatorial coordinates to horizontal coordinates for a given observer.

**Code Description**: This function takes an `EquatorialCoords` object `ec` as input and converts it to a `HorizontalCoords` object. It first calculates the hour angle from the right ascension of the equatorial coordinates using the `convertToHourAngle` method. Then, it computes the azimuth and altitude using trigonometric functions provided by the `Trigonometry` class, taking into account the observer's latitude stored in `_position.latitude`. Finally, it returns the resulting `HorizontalCoords` object containing the azimuth and altitude.\\
## Code: 
```
HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }
```