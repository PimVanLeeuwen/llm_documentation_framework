`altitude`: The function of `altitude` is to calculate the altitude angle of a celestial object based on the hour angle, declination, and latitude.

**Code Description**: This function `altitude` takes three parameters: `h` (hour angle), `decl` (declination), and `lat` (latitude), all of which are of type `angle_type`. It calculates the altitude angle using the formula:
\[ \text{altitude} = \arcsin(\cos(h) \cdot \cos(\text{decl}) \cdot \cos(\text{lat}) + \sin(\text{decl}) \cdot \sin(\text{lat})) \]
The function returns the result of this calculation. The trigonometric functions `ASin`, `Cos`, and `Sin` are used to perform the necessary mathematical operations.\\
## Code: 
```
angle_type Trigonometry::altitude(angle_type h, angle_type decl, angle_type lat) {
    return ASin(Cos(h) * Cos(decl) * Cos(lat) + Sin(decl) * Sin(lat));
  }
```