`rightAscension`: The function of `rightAscension` is to calculate the right ascension of a celestial object given its ecliptic longitude, ecliptic latitude, and the obliquity of the ecliptic.

**Code Description**: 
- The function `rightAscension` is a member of the `Trigonometry` class.
- It takes three parameters: `l` (ecliptic longitude), `b` (ecliptic latitude), and `e` (obliquity of the ecliptic), all of which are of type `angle_type`.
- It calculates the right ascension using the formula: `ATan2(Sin(l) * Cos(e) - Tan(b) * Sin(e), Cos(l))`.
- `Sin`, `Cos`, `Tan`, and `ATan2` are trigonometric functions that compute the sine, cosine, tangent, and the arctangent of two variables, respectively.
- The result is the right ascension angle, which is returned as an `angle_type`.\\
## Code: 
```
angle_type Trigonometry::rightAscension(angle_type l, angle_type b, angle_type e) {
    return ATan2(Sin(l) * Cos(e) - Tan(b) * Sin(e), Cos(l));
  }
```