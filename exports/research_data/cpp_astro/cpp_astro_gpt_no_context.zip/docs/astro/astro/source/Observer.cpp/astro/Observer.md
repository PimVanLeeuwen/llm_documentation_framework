`Observer`: The function of `Observer` is to initialize an `Observer` object with a given date and geographical position.

**Code Description**: The constructor `Observer<PLANET>::Observer` takes two parameters: a `JulianDate` object `date` and a `GeographicalCoords` object `position`. It initializes the private member variables `_date` and `_position` with the provided `date` and `position` respectively. Additionally, it calculates the sidereal time for the given date and longitude using the `astro::getSiderealTime<PLANET>` function and assigns the result to the private member variable `_siderealTime`.\\
## Code: 
```
Observer<PLANET>::Observer(const JulianDate &date, const GeographicalCoords &position) :
    _date(date),
    _position(position),
    _siderealTime(astro::getSiderealTime<PLANET>(_date, _position.longitude)) {}
```