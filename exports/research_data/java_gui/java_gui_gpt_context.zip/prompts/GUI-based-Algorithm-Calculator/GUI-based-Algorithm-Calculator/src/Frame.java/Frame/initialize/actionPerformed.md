# PROMPT
## Information
**Project Structure:** `GUI-based-Algorithm-Calculator` \
**File Path:** `GUI-based-Algorithm-Calculator/GUI-based-Algorithm-Calculator/src/Frame.java/Frame/initialize` \
**Type:** `Method` \
**Method Name:** `actionPerformed` \
**Code Content:** \
`void actionPerformed(ActionEvent e) {
				obj.vis(6,"HEAP SORT");
				frame.setVisible(false);
			}`

## Calls 
 This code calls the following methods within the repository: 
### GUI-based-Algorithm-Calculator/GUI-based-Algorithm-Calculator/src/Sortingss.java/Sortingss.vis 
 - Explanation:  _This method sets the `key` to the provided integer `k`, updates the `tname` variable to the provided string `str`, makes the `frame` visible, and returns 0. The intermediate assignments to `tname` are overwritten by the final assignment._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`actionPerformed`: The function of `actionPerformed` is *FILL IN* 
**Parameters**:\
`ActionEvent e`: *FILL IN* \

**Code Description**: *FILL IN*
