`partition`: The function of `partition` is to rearrange the elements in the array such that all elements less than the pivot are on its left, and all elements greater than the pivot are on its right, and then return the final position of the pivot.

**Parameters**:\
`int[] num`: The array of integers to be partitioned.\
`int start`: The starting index of the segment of the array to be partitioned.\
`int end`: The ending index of the segment of the array to be partitioned.

**Code Description**: The `partition` method selects the last element of the array segment as the pivot. It then iterates through the array segment from the `start` index to the `end` index. For each element, if it is less than the pivot, it swaps the element with the element at the `start` index and increments the `start` index. After the loop, it swaps the pivot element with the element at the `start` index, placing the pivot in its correct position. Finally, it returns the `start` index, which is the new position of the pivot.\\
## Code: 
```
int partition(int[] num, int start, int end){
	         int pivot = num[end];

	         for(int i=start; i<end; i++){
	            if(num[i]<pivot){
	            int temp= num[start];
	            num[start]=num[i];
	            num[i]=temp;
	            start++;
	        }
	        }

	        int temp = num[start];
	        num[start] = pivot;
	        num[end] = temp;
	        return start;

	        }
```