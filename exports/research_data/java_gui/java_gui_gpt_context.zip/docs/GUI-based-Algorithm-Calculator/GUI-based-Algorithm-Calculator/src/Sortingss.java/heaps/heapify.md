`heapify`: The function of `heapify` is to maintain the max-heap property in a subtree rooted at index `i` within an array.

**Parameters**:\
`int num[]`: The array representing the heap. \
`int size`: The number of elements in the heap. \
`int i`: The index of the root element of the subtree to be heapified.

**Code Description**: 
1. The method initializes `largest` to the root index `i`.
2. It calculates the indices of the left and right children of the root.
3. It checks if the left child exists and is greater than the root. If so, it updates `largest` to the left child's index.
4. It checks if the right child exists and is greater than the current largest element. If so, it updates `largest` to the right child's index.
5. If `largest` is not the root index `i`, it swaps the root element with the largest element.
6. It recursively calls `heapify` on the affected subtree to ensure the max-heap property is maintained.\\
## Code: 
```
void heapify(int num[], int size, int i)
    {
        int largest = i;
        int left = 2*i + 1;
        int right = 2*i + 2;

        if (left < size && num[left] >num[largest])
            largest = left;

        if (right < size && num[right] > num[largest])
            largest = right;

        if (largest != i)
        {
        	int temp;
            temp = num[i];
            num[i]= num[largest];
            num[largest] = temp;
            heapify(num, size, largest);
        }
    }
```