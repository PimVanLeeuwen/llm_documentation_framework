`heapSort`: The function of `heapSort` is to sort an array of integers in ascending order using the heap sort algorithm.

**Parameters**:\
`int num[]`: An array of integers to be sorted.\
`int size`: The number of elements in the array.

**Code Description**: 
The `heapSort` method sorts an array of integers by first building a max-heap from the input array and then repeatedly extracting the maximum element from the heap and placing it at the end of the array. The process involves two main steps:

1. **Building the Max-Heap**: 
   - The method starts by calling the `heapify` function on each non-leaf node, starting from the last non-leaf node up to the root node. This ensures that the entire array satisfies the max-heap property.

2. **Extracting Elements from the Heap**:
   - The method then repeatedly swaps the root of the heap (the maximum element) with the last element of the heap, reduces the size of the heap by one, and calls `heapify` on the root node to restore the max-heap property. This process is repeated until the heap is empty, resulting in a sorted array.

The `heapify` method is called to maintain the heap property during both the heap construction and the extraction phases.\\
## Code: 
```
void heapSort(int num[], int size)
	    {
	        int i;
	        for (i = size / 2 - 1; i >= 0; i--)
	            heapify(num, size, i);
	        for (i=size-1; i>=0; i--)
	        {
	        	int temp;
	            temp = num[0];
	            num[0]= num[i];
	            num[i] = temp;
	            heapify(num, i, 0);
	        }
	     }
```