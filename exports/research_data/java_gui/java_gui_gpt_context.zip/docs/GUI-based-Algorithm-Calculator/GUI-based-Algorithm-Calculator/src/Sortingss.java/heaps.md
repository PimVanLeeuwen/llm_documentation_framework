`heaps`: The function of `heaps` is to implement the heap sort algorithm, which is used to sort an array of integers in ascending order.

**Code Description**: 
The `heaps` class contains two methods: `heapify` and `heapSort`.

1. **heapify(int num[], int size, int i)**:
   - This method ensures that the subtree rooted at index `i` in the array `num` is a max-heap.
   - Parameters:
     - `num[]`: The array of integers to be heapified.
     - `size`: The size of the heap.
     - `i`: The index of the root of the subtree.
   - The method works by comparing the root with its left and right children. If the root is not the largest, it swaps the root with the largest child and recursively heapifies the affected subtree.

2. **heapSort(int num[], int size)**:
   - This method sorts the array `num` using the heap sort algorithm.
   - Parameters:
     - `num[]`: The array of integers to be sorted.
     - `size`: The size of the array.
   - The method works in two main steps:
     1. Build a max-heap from the input array.
     2. Repeatedly extract the maximum element from the heap and rebuild the heap until the array is sorted.
   - The first loop builds the max-heap by calling `heapify` on each non-leaf node.
   - The second loop extracts the maximum element (root of the heap) and places it at the end of the array, then calls `heapify` to maintain the heap property for the remaining elements.

Overall, the `heaps` class provides a clear and efficient implementation of the heap sort algorithm, ensuring that the input array is sorted in ascending order.\\
## Code: 
```
class heaps{
	void heapify(int num[], int size, int i)
    {
        int largest = i;
        int left = 2*i + 1;
        int right = 2*i + 2;

        if (left < size && num[left] >num[largest])
            largest = left;

        if (right < size && num[right] > num[largest])
            largest = right;

        if (largest != i)
        {
        	int temp;
            temp = num[i];
            num[i]= num[largest];
            num[largest] = temp;
            heapify(num, size, largest);
        }
    }
 
	
	void heapSort(int num[], int size)
	    {
	        int i;
	        for (i = size / 2 - 1; i >= 0; i--)
	            heapify(num, size, i);
	        for (i=size-1; i>=0; i--)
	        {
	        	int temp;
	            temp = num[0];
	            num[0]= num[i];
	            num[i] = temp;
	            heapify(num, i, 0);
	        }
	     }
	       
}
```