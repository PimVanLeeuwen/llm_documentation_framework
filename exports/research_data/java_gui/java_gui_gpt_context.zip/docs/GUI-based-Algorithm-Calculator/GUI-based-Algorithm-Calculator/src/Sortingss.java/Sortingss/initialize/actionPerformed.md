`actionPerformed`: The function of `actionPerformed` is to handle the event triggered by a user action, such as pressing a button, and perform the appropriate sorting algorithm on the input data based on the value of the `key` variable.

**Parameters**:\
`ActionEvent e`: This parameter represents the event that triggered the action, typically a user interaction with a GUI component like a button.

**Code Description**: 
1. The method retrieves the input string from `textField` and splits it into tokens based on spaces.
2. It converts these tokens into an integer array `num`.
3. Depending on the value of the `key` variable, it performs one of the following sorting algorithms on the `num` array:
   - **Bubble Sort** (if `key == 1`): Repeatedly swaps adjacent elements if they are in the wrong order.
   - **Selection Sort** (if `key == 2`): Selects the minimum element from the unsorted part and swaps it with the first unsorted element.
   - **Quick Sort** (if `key == 3`): Uses the `quickSort` method from the `quiks` class to sort the array.
   - **Insertion Sort** (if `key == 4`): Builds the sorted array one element at a time by inserting elements into their correct position.
   - **Merge Sort** (if `key == 5`): Uses the `mergeSort` method from the `merg` class to sort the array.
   - **Heap Sort** (if `key == 6`): Uses the `heapSort` method from the `heaps` class to sort the array.
4. After sorting, it constructs a result string `fin` that includes the name of the sorting algorithm and the sorted numbers.
5. It updates `textArea` with the sorted result and `textArea_1` with the name of the sorting algorithm used.\\
## Code: 
```
void actionPerformed(ActionEvent e){
				
				String fin = new String();
				String str=new String();
				str = textField.getText();
				
				String [] tok = str.split(" ");
				int [] num = new int[tok.length];
				
				for(int i=0;i<tok.length;i++){
					num[i]=Integer.parseInt(tok[i]);
				}
				if(key==1)
				{
					int j;
			        boolean flag = true;   // set flag to true to begin first pass
			        int temp;   //holding variable

			        while ( flag )
			        {
			            flag= false;    //set flag to false awaiting a possible swap
			            for( j=0;  j < num.length -1;  j++ )
			            {
			                if ( num[ j ] > num[j+1] )   // change to > for ascending sort
			                {
			                    temp = num[ j ];                //swap elements
			                    num[ j ] = num[ j+1 ];
			                    num[ j+1 ] = temp;
			                    flag = true;              //shows a swap occurred
			                }
			            }
			        }
			        fin = "Bubble Sort =";
				}
				if(key==2){
			        int n = num.length;

			        // One by one move boundary of unsorted subarray
			        for (int i = 0; i < n-1; i++)
			        {
			            // Find the minimum element in unsorted array
			            int min_idx = i;
			            for (int j = i+1; j < n; j++)
			                if (num[j] < num[min_idx])
			                    min_idx = j;

			            // Swap the found minimum element with the first
			            // element
			            int temp = num[min_idx];
			            num[min_idx] = num[i];
			            num[i] = temp;
			        }
			        tname="SELECTION SORT";
			        fin = "Selection Sort =";
				}
				if(key==3){
				
					
					quiks obj2 =new quiks();
					int size=num.length;
					obj2.quickSort(num,0,size-1);
					fin="Quick Sort =";
					tname="QUICK SORT";
				}
				
				if(key==4){
					int i, ke, j;
			        for (i = 1; i < tok.length; i++)
			        {
			            ke = num[i];
			            j = i - 1;

			        /* Move elements of arr[0..i-1], that are
			        greater than key, to one position ahead
			        of their current position */
			            while (j >= 0 && num[j] > ke)
			            {
			                num[j + 1] = num[j];
			                j = j - 1;
			            }
			            num[j + 1] = ke;
			        }
			        tname="INSERTION SORT";
			        fin = "Insertion Sort =";
				}
				if(key==5){
					merg obj3=new merg();
					int size =num.length-1;
					obj3.mergeSort(num, 0, size);
					fin ="Merge Sort =";
					tname="MERGE SORT";
				}
				
				if(key==6){
					heaps obj4=new heaps();
					int size;
					size=tok.length;
					obj4.heapSort(num,size);
					fin ="Heap Sort =";
					tname="HEAP SORT";
				}
				
				String str1[] =new String[tok.length];
				for(int i=0;i<tok.length;i++){
					str1[i]=Integer.toString(num[i]);
					fin=fin+" "+str1[i];
				}
				textArea.setText(fin);
				textArea_1.setText(tname);
			}
```