`vis`: The function of `vis` is to set the visibility of a frame and update some internal variables.

**Parameters**:\
`int k`: An integer value used to set the `key` variable.\
`String str`: A string value used to set the `tname` variable.

**Code Description**: The `vis` method takes two parameters, an integer `k` and a string `str`. It assigns the value of `k` to the `key` variable. It then sets the `tname` variable to the string "Hello", then to "pop", and finally to the value of `str`. After updating these variables, it makes a frame visible by calling `frame.setVisible(true)`. The method returns an integer value of 0.\\
## Code: 
```
int vis(int k,String str){
		key=k;
		tname="Hello";
		tname="pop";
		tname=str;
		frame.setVisible(true);
		return 0;
	}
```