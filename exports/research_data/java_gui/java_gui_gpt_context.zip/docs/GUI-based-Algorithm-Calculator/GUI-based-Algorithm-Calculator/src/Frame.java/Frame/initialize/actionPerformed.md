`actionPerformed`: The function of `actionPerformed` is to handle an action event by invoking the `vis` method with specific parameters and then hiding the current frame.
**Parameters**:\
`ActionEvent e`: This parameter represents the event that triggered the action, typically a user interaction such as a button click.

**Code Description**: This method is triggered by an action event. It calls the `vis` method of the `obj` object with the parameters `6` and `"HEAP SORT"`, which likely sets up a visualization for the Heap Sort algorithm. After invoking the `vis` method, it sets the visibility of the `frame` to `false`, effectively hiding the current frame.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
				obj.vis(6,"HEAP SORT");
				frame.setVisible(false);
			}
```