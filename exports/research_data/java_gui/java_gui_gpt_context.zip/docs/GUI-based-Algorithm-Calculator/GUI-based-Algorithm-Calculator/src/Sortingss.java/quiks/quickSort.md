`quickSort`: The function of `quickSort` is to sort an array of integers using the QuickSort algorithm.

**Parameters**:\
`int[] num`: The array of integers to be sorted.\
`int start`: The starting index of the portion of the array to be sorted.\
`int end`: The ending index of the portion of the array to be sorted.

**Code Description**: The `quickSort` method sorts the array `num` between the indices `start` and `end` using the QuickSort algorithm. It first partitions the array around a pivot element, which is determined by the `partition` method. The `partition` method rearranges the elements such that elements less than the pivot are on its left and elements greater than the pivot are on its right. The `quickSort` method then recursively sorts the subarrays to the left and right of the pivot. If the subarray to the left of the pivot has more than one element, it recursively calls `quickSort` on that subarray. Similarly, if the subarray to the right of the pivot has more than one element, it recursively calls `quickSort` on that subarray. This process continues until the entire array is sorted.\\
## Code: 
```
void quickSort(int[] num, int start, int end)
	 {
	    int partition = partition(num, start, end);
        if(partition-1>start)
        {
        	quickSort(num, start, partition - 1);
        }
    	if(partition+1<end) 
    	{
    		quickSort(num, partition + 1, end);
    	}
	 }
```