`mergeSort`: The function of `mergeSort` is to recursively divide the array into smaller subarrays, sort them, and then merge them back together in sorted order.

**Parameters**:\
`int num[]`: The array of integers to be sorted.\
`int l`: The starting index of the subarray to be sorted.\
`int r`: The ending index of the subarray to be sorted.\

**Code Description**: The `mergeSort` method is a recursive function that implements the merge sort algorithm. It first checks if the left index `l` is less than the right index `r`, indicating that the subarray has more than one element and needs to be sorted. It then calculates the middle index `m` to divide the array into two halves. The method recursively calls itself to sort the left half (`num[l..m]`) and the right half (`num[m+1..r]`). After sorting both halves, it calls the `merge` method to merge the two sorted halves into a single sorted subarray. This process continues until the entire array is sorted.\\
## Code: 
```
void mergeSort(int num[], int l, int r)
    {
        if (l < r)
        {
                int m = l+(r-l)/2;

            mergeSort(num, l, m);
            mergeSort(num, m+1, r);
            merge(num, l, m, r);
        }
    }
```