`quiks`: The function of `quiks` is to implement the QuickSort algorithm for sorting an array of integers.

**Code Description**: 
The `quiks` class contains two methods: `quickSort` and `partition`.

- `quickSort(int[] num, int start, int end)`: This method sorts the array `num` using the QuickSort algorithm. It recursively sorts the subarrays before and after the partition index. The base case for the recursion is when the subarray has one or zero elements.

- `partition(int[] num, int start, int end)`: This method partitions the array around a pivot element (chosen as the last element in the current subarray). It rearranges the elements such that all elements less than the pivot are on its left, and all elements greater than the pivot are on its right. It returns the final position of the pivot element after partitioning.\\
## Code: 
```
class quiks
{
	 void quickSort(int[] num, int start, int end)
	 {
	    int partition = partition(num, start, end);
        if(partition-1>start)
        {
        	quickSort(num, start, partition - 1);
        }
    	if(partition+1<end) 
    	{
    		quickSort(num, partition + 1, end);
    	}
	 }

	     int partition(int[] num, int start, int end){
	         int pivot = num[end];

	         for(int i=start; i<end; i++){
	            if(num[i]<pivot){
	            int temp= num[start];
	            num[start]=num[i];
	            num[i]=temp;
	            start++;
	        }
	        }

	        int temp = num[start];
	        num[start] = pivot;
	        num[end] = temp;
	        return start;

	        }
}
```