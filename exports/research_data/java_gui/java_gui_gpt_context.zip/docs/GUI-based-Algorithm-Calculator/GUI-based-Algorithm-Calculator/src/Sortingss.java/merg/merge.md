`merge`: The function of `merge` is to merge two sorted subarrays of `num` into a single sorted subarray. 

**Parameters**:\
`int num[]`: The array containing the subarrays to be merged. \
`int l`: The starting index of the first subarray. \
`int m`: The ending index of the first subarray and the midpoint of the two subarrays. \
`int r`: The ending index of the second subarray. \

**Code Description**: 
The `merge` method merges two sorted subarrays of the array `num`. The first subarray is defined from index `l` to `m`, and the second subarray is defined from index `m+1` to `r`. The method works as follows:

1. Calculate the sizes of the two subarrays: `n1` for the first subarray and `n2` for the second subarray.
2. Create temporary arrays `L` and `R` to hold the elements of the first and second subarrays, respectively.
3. Copy the elements of the first subarray into `L` and the elements of the second subarray into `R`.
4. Initialize three indices: `i` for traversing `L`, `j` for traversing `R`, and `k` for traversing the merged subarray in `num`.
5. Merge the elements from `L` and `R` back into `num` in sorted order:
   - Compare the current elements of `L` and `R`.
   - Place the smaller element into `num` and move the corresponding index (`i` or `j`) forward.
   - Move the index `k` forward.
6. Copy any remaining elements of `L` into `num` if there are any left.
7. Copy any remaining elements of `R` into `num` if there are any left.

This process ensures that the subarray of `num` from index `l` to `r` is sorted.\\
## Code: 
```
void merge(int num[], int l, int m, int r)
    {
        int i, j, k;
        int n1 = m - l + 1;
        int n2 =  r - m;
        int[] L = new int[n1];  
        int[] R = new int[n2];  
        //int L[n1], R[n2];

        for (i = 0; i < n1; i++)
            L[i] = num[l + i];
        for (j = 0; j < n2; j++)
            R[j] = num[m + 1+ j];

        i = 0; // Initial index of first subarray
        j = 0; // Initial index of second subarray
        k = l; // Initial index of merged subarray
        while (i < n1 && j < n2)
        {
            if (L[i] <= R[j])
            {
                num[k] = L[i];
                i++;
            }
            else
            {
                num[k] = R[j];
                j++;
            }
            k++;
        }

        while (i < n1)
        {
            num[k] = L[i];
            i++;
            k++;
        }

        while (j < n2)
        {
            num[k] = R[j];
            j++;
            k++;
        }
    }
```