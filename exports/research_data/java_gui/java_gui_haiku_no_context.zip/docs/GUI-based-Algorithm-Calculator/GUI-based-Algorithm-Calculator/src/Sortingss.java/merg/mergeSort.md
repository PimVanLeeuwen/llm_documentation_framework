`mergeSort`: The function of `mergeSort` is to sort an array of integers in ascending order using the merge sort algorithm.

**Code Description**: The `mergeSort` function is a recursive implementation of the merge sort algorithm. It takes an integer array `num`, and the start and end indices `l` and `r` of the subarray to be sorted.

The function first checks if the subarray has more than one element (`l < r`). If so, it calculates the midpoint `m` of the subarray. It then recursively calls `mergeSort` on the left and right halves of the subarray (from `l` to `m`, and from `m+1` to `r`, respectively). After the recursive calls, it calls the `merge` function to merge the two sorted subarrays.

The `merge` function is responsible for merging the two sorted subarrays into a single sorted subarray. It takes the array `num`, and the start, middle, and end indices `l`, `m`, and `r` of the two subarrays to be merged.

The `mergeSort` function uses a divide-and-conquer approach to sort the array. It recursively divides the array into smaller subarrays, sorts them, and then merges the sorted subarrays back together. This approach has a time complexity of O(n log n), which is efficient for large arrays.

The `mergeSort` function is a common implementation of the merge sort algorithm, which is a popular sorting algorithm due to its efficiency and stability (i.e., it preserves the relative order of equal elements).\\
## Code: 
```
void mergeSort(int num[], int l, int r)
    {
        if (l < r)
        {
                int m = l+(r-l)/2;

            mergeSort(num, l, m);
            mergeSort(num, m+1, r);
            merge(num, l, m, r);
        }
    }
```