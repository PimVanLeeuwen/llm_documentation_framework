`actionPerformed`: The function of `actionPerformed` is to perform various sorting algorithms on a set of numbers entered in a text field, and display the sorted numbers and the name of the sorting algorithm used.

**Code Description**:

1. The function first retrieves the text entered in the text field and splits it into an array of integers.
2. It then checks the value of the `key` variable to determine which sorting algorithm to use.
3. If `key` is 1, it performs a Bubble Sort on the array of integers. The Bubble Sort algorithm compares adjacent elements and swaps them if they are in the wrong order, repeating this process until the entire array is sorted.
4. If `key` is 2, it performs a Selection Sort on the array of integers. The Selection Sort algorithm finds the minimum element in the unsorted part of the array and swaps it with the first element of the unsorted part.
5. If `key` is 3, it calls the `quickSort` method of a `quiks` object, passing the array of integers and the start and end indices. This performs a Quick Sort on the array.
6. If `key` is 4, it performs an Insertion Sort on the array of integers. The Insertion Sort algorithm iterates through the array, and for each element, it finds the appropriate position in the sorted portion of the array and inserts the element there.
7. If `key` is 5, it calls the `mergeSort` method of a `merg` object, passing the array of integers and the start and end indices. This performs a Merge Sort on the array.
8. If `key` is 6, it calls the `heapSort` method of a `heaps` object, passing the array of integers and the size of the array. This performs a Heap Sort on the array.
9. After performing the selected sorting algorithm, the function creates a new array of strings, where each element is the corresponding sorted integer converted to a string.
10. Finally, the function sets the text of the `textArea` and `textArea_1` components to display the sorted numbers and the name of the sorting algorithm used, respectively.\\
## Code: 
```
void actionPerformed(ActionEvent e){
				
				String fin = new String();
				String str=new String();
				str = textField.getText();
				
				String [] tok = str.split(" ");
				int [] num = new int[tok.length];
				
				for(int i=0;i<tok.length;i++){
					num[i]=Integer.parseInt(tok[i]);
				}
				if(key==1)
				{
					int j;
			        boolean flag = true;   // set flag to true to begin first pass
			        int temp;   //holding variable

			        while ( flag )
			        {
			            flag= false;    //set flag to false awaiting a possible swap
			            for( j=0;  j < num.length -1;  j++ )
			            {
			                if ( num[ j ] > num[j+1] )   // change to > for ascending sort
			                {
			                    temp = num[ j ];                //swap elements
			                    num[ j ] = num[ j+1 ];
			                    num[ j+1 ] = temp;
			                    flag = true;              //shows a swap occurred
			                }
			            }
			        }
			        fin = "Bubble Sort =";
				}
				if(key==2){
			        int n = num.length;

			        // One by one move boundary of unsorted subarray
			        for (int i = 0; i < n-1; i++)
			        {
			            // Find the minimum element in unsorted array
			            int min_idx = i;
			            for (int j = i+1; j < n; j++)
			                if (num[j] < num[min_idx])
			                    min_idx = j;

			            // Swap the found minimum element with the first
			            // element
			            int temp = num[min_idx];
			            num[min_idx] = num[i];
			            num[i] = temp;
			        }
			        tname="SELECTION SORT";
			        fin = "Selection Sort =";
				}
				if(key==3){
				
					
					quiks obj2 =new quiks();
					int size=num.length;
					obj2.quickSort(num,0,size-1);
					fin="Quick Sort =";
					tname="QUICK SORT";
				}
				
				if(key==4){
					int i, ke, j;
			        for (i = 1; i < tok.length; i++)
			        {
			            ke = num[i];
			            j = i - 1;

			        /* Move elements of arr[0..i-1], that are
			        greater than key, to one position ahead
			        of their current position */
			            while (j >= 0 && num[j] > ke)
			            {
			                num[j + 1] = num[j];
			                j = j - 1;
			            }
			            num[j + 1] = ke;
			        }
			        tname="INSERTION SORT";
			        fin = "Insertion Sort =";
				}
				if(key==5){
					merg obj3=new merg();
					int size =num.length-1;
					obj3.mergeSort(num, 0, size);
					fin ="Merge Sort =";
					tname="MERGE SORT";
				}
				
				if(key==6){
					heaps obj4=new heaps();
					int size;
					size=tok.length;
					obj4.heapSort(num,size);
					fin ="Heap Sort =";
					tname="HEAP SORT";
				}
				
				String str1[] =new String[tok.length];
				for(int i=0;i<tok.length;i++){
					str1[i]=Integer.toString(num[i]);
					fin=fin+" "+str1[i];
				}
				textArea.setText(fin);
				textArea_1.setText(tname);
			}
```