`partition`: The function of `partition` is to partition the given array `num` around a pivot element, and return the index of the pivot element.

**Code Description**:

The `partition` function takes three parameters: an integer array `num`, an integer `start` representing the starting index of the partition, and an integer `end` representing the ending index of the partition.

1. The first step is to select the last element of the array `num[end]` as the pivot element.

2. The function then iterates through the array from the `start` index to the `end-1` index. For each element `num[i]`, it checks if the element is less than the pivot element `num[end]`. If it is, the function swaps the element at the `start` index with the element at the `i` index, and increments the `start` index.

3. After the loop, the function swaps the element at the `start` index with the pivot element `num[end]`. This effectively places the pivot element at its correct position in the partitioned array.

4. Finally, the function returns the `start` index, which is the index of the pivot element in the partitioned array.

The purpose of this function is to partition the array around a pivot element, such that all elements to the left of the pivot are less than the pivot, and all elements to the right of the pivot are greater than or equal to the pivot. This is a key step in the Quicksort algorithm, which is a popular sorting algorithm that uses this partitioning technique to sort an array efficiently.\\
## Code: 
```
int partition(int[] num, int start, int end){
	         int pivot = num[end];

	         for(int i=start; i<end; i++){
	            if(num[i]<pivot){
	            int temp= num[start];
	            num[start]=num[i];
	            num[i]=temp;
	            start++;
	        }
	        }

	        int temp = num[start];
	        num[start] = pivot;
	        num[end] = temp;
	        return start;

	        }
```