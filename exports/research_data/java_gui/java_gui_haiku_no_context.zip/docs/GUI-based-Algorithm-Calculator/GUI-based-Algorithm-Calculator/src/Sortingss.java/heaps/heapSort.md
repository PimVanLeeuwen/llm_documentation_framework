`heapSort`: The function of `heapSort` is to sort an array of integers in ascending order using the Heap Sort algorithm.

**Code Description**:
The `heapSort` function takes two parameters: an integer array `num` and the size of the array `size`.

1. The function first builds a max-heap from the input array `num` using a loop that iterates from the middle of the array to the beginning (i.e., `size / 2 - 1` to 0). For each element, the `heapify` function is called to maintain the max-heap property.

2. After the max-heap is built, the function enters a loop that iterates from the end of the array to the beginning (i.e., `size-1` to 0). In each iteration:
   - The first element of the array (the maximum value) is swapped with the last element.
   - The `heapify` function is called to maintain the max-heap property for the remaining elements (i.e., the elements from the beginning of the array to the current index `i`).

The `heapify` function is a helper function that is used to maintain the max-heap property of a subtree rooted at a given index `i` in the array `num` with a given size `size`. It works as follows:

1. It finds the largest value among the root (index `i`), the left child (index `2*i + 1`), and the right child (index `2*i + 2`).
2. If the largest value is not the root, it swaps the root with the largest value and recursively calls `heapify` on the subtree rooted at the new root.

The overall time complexity of the `heapSort` function is O(n log n), where n is the size of the input array. This is because the initial max-heap construction takes O(n) time, and the subsequent sorting process involves n iterations of the `heapify` function, each of which takes O(log n) time.\\
## Code: 
```
void heapSort(int num[], int size)
	    {
	        int i;
	        for (i = size / 2 - 1; i >= 0; i--)
	            heapify(num, size, i);
	        for (i=size-1; i>=0; i--)
	        {
	        	int temp;
	            temp = num[0];
	            num[0]= num[i];
	            num[i] = temp;
	            heapify(num, i, 0);
	        }
	     }
```