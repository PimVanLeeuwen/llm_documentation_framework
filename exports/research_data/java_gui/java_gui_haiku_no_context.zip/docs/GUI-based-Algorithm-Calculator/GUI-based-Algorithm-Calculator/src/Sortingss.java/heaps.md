`heaps`: The function of `heaps` is to implement the heap data structure and provide methods for heapifying and sorting an array using the heap sort algorithm.

**Code Description**:

1. `heapify(int num[], int size, int i)`:
   - This function is responsible for maintaining the heap property in a given array `num` of size `size`, starting from the index `i`.
   - It first identifies the largest element among the current node (`i`), the left child (`2*i + 1`), and the right child (`2*i + 2`).
   - If the largest element is not the current node, it swaps the current node with the largest element and recursively calls `heapify` on the largest element's index.
   - This process ensures that the subtree rooted at the current node satisfies the heap property.

2. `heapSort(int num[], int size)`:
   - This function implements the heap sort algorithm to sort the given array `num` of size `size` in ascending order.
   - It first builds a max-heap by calling `heapify` on the array, starting from the last non-leaf node (`size / 2 - 1`) and working towards the root.
   - Then, it repeatedly extracts the maximum element (the root of the heap) by swapping it with the last element of the heap, decrements the heap size, and calls `heapify` on the root to maintain the heap property.
   - This process continues until the entire array is sorted in ascending order.

The `heaps` class provides the following functionality:

1. `heapify(int num[], int size, int i)`:
   - This function ensures that the subtree rooted at the given index `i` in the array `num` of size `size` satisfies the heap property.
   - It does this by identifying the largest element among the current node, the left child, and the right child, and then swapping the current node with the largest element if necessary. It then recursively calls `heapify` on the largest element's index.

2. `heapSort(int num[], int size)`:
   - This function implements the heap sort algorithm to sort the given array `num` of size `size` in ascending order\\
## Code: 
```
class heaps{
	void heapify(int num[], int size, int i)
    {
        int largest = i;
        int left = 2*i + 1;
        int right = 2*i + 2;

        if (left < size && num[left] >num[largest])
            largest = left;

        if (right < size && num[right] > num[largest])
            largest = right;

        if (largest != i)
        {
        	int temp;
            temp = num[i];
            num[i]= num[largest];
            num[largest] = temp;
            heapify(num, size, largest);
        }
    }
 
	
	void heapSort(int num[], int size)
	    {
	        int i;
	        for (i = size / 2 - 1; i >= 0; i--)
	            heapify(num, size, i);
	        for (i=size-1; i>=0; i--)
	        {
	        	int temp;
	            temp = num[0];
	            num[0]= num[i];
	            num[i] = temp;
	            heapify(num, i, 0);
	        }
	     }
	       
}
```