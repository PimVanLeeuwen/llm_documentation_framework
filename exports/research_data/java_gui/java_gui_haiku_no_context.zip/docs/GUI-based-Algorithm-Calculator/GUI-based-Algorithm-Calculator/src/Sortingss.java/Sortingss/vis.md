`vis`: The function of `vis` is to set the value of various variables and make a frame visible.

**Code Description**: The `vis` function takes two parameters: an integer `k` and a string `str`. It performs the following operations:

1. Assigns the value of `k` to the variable `key`.
2. Assigns the string "Hello" to the variable `tname`.
3. Assigns the string "pop" to the variable `tname`.
4. Assigns the value of `str` to the variable `tname`.
5. Sets the visibility of the `frame` object to `true`, making it visible.
6. Returns the value `0`.

The purpose of this function is to manipulate the values of the `key`, `tname`, and `frame` variables based on the input parameters. It does not appear to have any other functionality beyond these basic operations.\\
## Code: 
```
int vis(int k,String str){
		key=k;
		tname="Hello";
		tname="pop";
		tname=str;
		frame.setVisible(true);
		return 0;
	}
```