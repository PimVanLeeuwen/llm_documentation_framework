`heapify`: The function of `heapify` is to maintain the heap property of a binary heap data structure.

**Code Description**: The `heapify` function takes three parameters: an array `num`, the size of the array `size`, and an index `i`. The function's purpose is to ensure that the subtree rooted at index `i` satisfies the heap property, which states that the value of each node must be greater than or equal to (or less than or equal to, depending on the type of heap) the values of its children.

The function works as follows:

1. It initializes the variable `largest` to the index `i`, which represents the root of the subtree being heapified.
2. It calculates the indices of the left and right children of the current node, `left` and `right`, respectively.
3. It compares the values of the current node and its left and right children. If the left child is larger than the current node, it updates `largest` to the index of the left child. If the right child is larger than the current node (or the left child, if the left child was already determined to be the largest), it updates `largest` to the index of the right child.
4. If `largest` is not equal to the original index `i`, it means that either the left or right child is larger than the current node. In this case, the function swaps the values at indices `i` and `largest`, and then recursively calls `heapify` on the subtree rooted at the new `largest` index to ensure the heap property is maintained.

This process continues until the heap property is satisfied for the entire subtree rooted at the initial index `i`. The function ensures that the heap property is maintained by comparing the values of the current node and its children, and then recursively fixing any violations of the heap property.

The `heapify` function is a crucial component of the heap data structure, as it is used to build and maintain the heap property, which is essential for efficient heap-based algorithms such as heap sort and priority queues.\\
## Code: 
```
void heapify(int num[], int size, int i)
    {
        int largest = i;
        int left = 2*i + 1;
        int right = 2*i + 2;

        if (left < size && num[left] >num[largest])
            largest = left;

        if (right < size && num[right] > num[largest])
            largest = right;

        if (largest != i)
        {
        	int temp;
            temp = num[i];
            num[i]= num[largest];
            num[largest] = temp;
            heapify(num, size, largest);
        }
    }
```