`quiks`: The function of `quiks` is to implement the Quicksort algorithm to sort an array of integers.

**Code Description**:

The `quiks` class contains two methods: `quickSort` and `partition`.

1. `quickSort` method:
   - This method takes an integer array `num`, and the start and end indices `start` and `end` as input.
   - It first calls the `partition` method to find the pivot index `partition`.
   - If the left subarray (from `start` to `partition - 1`) has more than one element, it recursively calls `quickSort` on the left subarray.
   - If the right subarray (from `partition + 1` to `end`) has more than one element, it recursively calls `quickSort` on the right subarray.
   - The recursive calls continue until the entire array is sorted.

2. `partition` method:
   - This method takes an integer array `num`, and the start and end indices `start` and `end` as input.
   - It selects the last element of the array (`num[end]`) as the pivot.
   - It then iterates through the array from `start` to `end - 1`, comparing each element with the pivot.
   - If the current element is less than the pivot, it swaps the current element with the element at the `start` index, and increments the `start` index.
   - After the loop, it swaps the element at the `start` index with the pivot element (`num[end]`).
   - Finally, it returns the `start` index, which is the new pivot index.

The Quicksort algorithm is a divide-and-conquer algorithm that works by selecting a 'pivot' element from the array, and partitioning the other elements into two sub-arrays, according to whether they are less than or greater than the pivot. The sub-arrays are then recursively sorted.

The time complexity of Quicksort is O(n log n) on average, but can degrade to O(n^2) in the worst case scenario (when the array is already sorted or reverse-sorted). The space complexity is O(log n) due to the recursive calls.\\
## Code: 
```
class quiks
{
	 void quickSort(int[] num, int start, int end)
	 {
	    int partition = partition(num, start, end);
        if(partition-1>start)
        {
        	quickSort(num, start, partition - 1);
        }
    	if(partition+1<end) 
    	{
    		quickSort(num, partition + 1, end);
    	}
	 }

	     int partition(int[] num, int start, int end){
	         int pivot = num[end];

	         for(int i=start; i<end; i++){
	            if(num[i]<pivot){
	            int temp= num[start];
	            num[start]=num[i];
	            num[i]=temp;
	            start++;
	        }
	        }

	        int temp = num[start];
	        num[start] = pivot;
	        num[end] = temp;
	        return start;

	        }
}
```