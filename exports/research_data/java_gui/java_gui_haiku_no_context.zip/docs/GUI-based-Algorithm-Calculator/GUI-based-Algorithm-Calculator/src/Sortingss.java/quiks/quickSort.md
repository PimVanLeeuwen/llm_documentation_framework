`quickSort`: The function of `quickSort` is to sort an array of integers in ascending order using the quicksort algorithm.

**Code Description**: The `quickSort` function takes three parameters: an integer array `num`, and two integer indices `start` and `end` that define the range of the array to be sorted.

The function first calls the `partition` function, which rearranges the elements in the array such that all elements less than a chosen "pivot" element are placed before the pivot, and all elements greater than the pivot are placed after it. The index of the pivot element is returned by the `partition` function and stored in the `partition` variable.

If the index of the pivot element minus 1 is greater than the `start` index, the function recursively calls itself with the range from `start` to `partition - 1`, effectively sorting the left half of the array.

Similarly, if the index of the pivot element plus 1 is less than the `end` index, the function recursively calls itself with the range from `partition + 1` to `end`, effectively sorting the right half of the array.

This recursive process continues until the entire array is sorted in ascending order.

The quicksort algorithm is a popular sorting algorithm because it has an average time complexity of O(n log n), which is efficient for large arrays. However, in the worst case scenario, where the array is already sorted or reverse-sorted, the time complexity can degrade to O(n^2).\\
## Code: 
```
void quickSort(int[] num, int start, int end)
	 {
	    int partition = partition(num, start, end);
        if(partition-1>start)
        {
        	quickSort(num, start, partition - 1);
        }
    	if(partition+1<end) 
    	{
    		quickSort(num, partition + 1, end);
    	}
	 }
```