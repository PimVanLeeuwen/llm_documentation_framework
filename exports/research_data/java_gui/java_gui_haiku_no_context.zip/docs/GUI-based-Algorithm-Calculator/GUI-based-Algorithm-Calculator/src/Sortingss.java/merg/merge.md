`merge`: The function of `merge` is to merge two sorted subarrays of an array into a single sorted array.

**Code Description**: The `merge` function takes four parameters: `num` (the array to be merged), `l` (the starting index of the first subarray), `m` (the middle index, which separates the two subarrays), and `r` (the ending index of the second subarray).

The function first calculates the sizes of the two subarrays, `n1` and `n2`, and creates two temporary arrays, `L` and `R`, to hold the elements of the two subarrays.

The function then copies the elements of the first subarray (`num[l]` to `num[m]`) into the `L` array, and the elements of the second subarray (`num[m+1]` to `num[r]`) into the `R` array.

Next, the function merges the two sorted subarrays back into the original `num` array. It does this by comparing the elements of the `L` and `R` arrays and adding the smaller element to the `num` array. Once one of the subarrays is empty, the function adds the remaining elements of the other subarray to the `num` array.

The overall time complexity of the `merge` function is O(n), where n is the size of the subarray being merged, as it performs a linear scan of the two subarrays and merges them into the original array.\\
## Code: 
```
void merge(int num[], int l, int m, int r)
    {
        int i, j, k;
        int n1 = m - l + 1;
        int n2 =  r - m;
        int[] L = new int[n1];  
        int[] R = new int[n2];  
        //int L[n1], R[n2];

        for (i = 0; i < n1; i++)
            L[i] = num[l + i];
        for (j = 0; j < n2; j++)
            R[j] = num[m + 1+ j];

        i = 0; // Initial index of first subarray
        j = 0; // Initial index of second subarray
        k = l; // Initial index of merged subarray
        while (i < n1 && j < n2)
        {
            if (L[i] <= R[j])
            {
                num[k] = L[i];
                i++;
            }
            else
            {
                num[k] = R[j];
                j++;
            }
            k++;
        }

        while (i < n1)
        {
            num[k] = L[i];
            i++;
            k++;
        }

        while (j < n2)
        {
            num[k] = R[j];
            j++;
            k++;
        }
    }
```