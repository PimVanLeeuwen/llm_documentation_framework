The function of `merge` is to merge two sorted subarrays into a single sorted array.

**Code Description**: 
The `merge` function takes an array `num`, and three indices `l`, `m`, and `r`. It divides the array into two parts at index `m`, sorts them separately, and then merges them back together in sorted order. The function uses temporary arrays `L` and `R` to store the left and right subarrays, respectively. It iterates through both subarrays, comparing elements and placing the smaller one into the merged array. If there are remaining elements in either subarray, they are appended to the merged array.\\
## Code: 
```
void merge(int num[], int l, int m, int r)
    {
        int i, j, k;
        int n1 = m - l + 1;
        int n2 =  r - m;
        int[] L = new int[n1];  
        int[] R = new int[n2];  
        //int L[n1], R[n2];

        for (i = 0; i < n1; i++)
            L[i] = num[l + i];
        for (j = 0; j < n2; j++)
            R[j] = num[m + 1+ j];

        i = 0; // Initial index of first subarray
        j = 0; // Initial index of second subarray
        k = l; // Initial index of merged subarray
        while (i < n1 && j < n2)
        {
            if (L[i] <= R[j])
            {
                num[k] = L[i];
                i++;
            }
            else
            {
                num[k] = R[j];
                j++;
            }
            k++;
        }

        while (i < n1)
        {
            num[k] = L[i];
            i++;
            k++;
        }

        while (j < n2)
        {
            num[k] = R[j];
            j++;
            k++;
        }
    }
```