The function of `heaps` is to implement a heap data structure, which allows for efficient sorting and manipulation of elements in an array.

**Code Description**: 
The code defines a class called `heaps` that contains two methods: `heapify` and `heapSort`. The `heapify` method takes an array `num`, its size `size`, and an index `i` as input, and it recursively ensures that the subtree rooted at index `i` satisfies the heap property (i.e., the parent node is greater than or equal to its child nodes). The `heapSort` method uses the `heapify` method to sort the entire array in ascending order.\\
## Code: 
```
class heaps{
	void heapify(int num[], int size, int i)
    {
        int largest = i;
        int left = 2*i + 1;
        int right = 2*i + 2;

        if (left < size && num[left] >num[largest])
            largest = left;

        if (right < size && num[right] > num[largest])
            largest = right;

        if (largest != i)
        {
        	int temp;
            temp = num[i];
            num[i]= num[largest];
            num[largest] = temp;
            heapify(num, size, largest);
        }
    }
 
	
	void heapSort(int num[], int size)
	    {
	        int i;
	        for (i = size / 2 - 1; i >= 0; i--)
	            heapify(num, size, i);
	        for (i=size-1; i>=0; i--)
	        {
	        	int temp;
	            temp = num[0];
	            num[0]= num[i];
	            num[i] = temp;
	            heapify(num, i, 0);
	        }
	     }
	       
}
```