The function of `partition` is to rearrange the elements in the array such that all elements less than the pivot are on its left, and all elements greater than or equal to the pivot are on its right.

**Code Description**: The code implements a partitioning scheme for quicksort algorithm. It takes an array `num`, and two indices `start` and `end` as input. The function selects the last element of the range (`pivot = num[end]`) as the pivot, and then iterates through the range from `start` to `end-1`. If an element is less than the pivot, it swaps that element with the first element in the unpartitioned range (`num[start]`). The function finally swaps the pivot element with the last element in the unpartitioned range. The function returns the index of the pivot element after partitioning.\\
## Code: 
```
int partition(int[] num, int start, int end){
	         int pivot = num[end];

	         for(int i=start; i<end; i++){
	            if(num[i]<pivot){
	            int temp= num[start];
	            num[start]=num[i];
	            num[i]=temp;
	            start++;
	        }
	        }

	        int temp = num[start];
	        num[start] = pivot;
	        num[end] = temp;
	        return start;

	        }
```