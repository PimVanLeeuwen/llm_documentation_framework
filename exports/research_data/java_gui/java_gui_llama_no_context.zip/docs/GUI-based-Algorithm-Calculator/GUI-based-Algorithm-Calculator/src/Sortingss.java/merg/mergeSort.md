`mergeSort`: The function of `mergeSort` is to sort an array of integers in ascending order using the merge sort algorithm.

**Code Description**: The code implements a recursive merge sort algorithm, which divides the input array into two halves, recursively sorts each half, and then merges them back together in sorted order.\\
## Code: 
```
void mergeSort(int num[], int l, int r)
    {
        if (l < r)
        {
                int m = l+(r-l)/2;

            mergeSort(num, l, m);
            mergeSort(num, m+1, r);
            merge(num, l, m, r);
        }
    }
```