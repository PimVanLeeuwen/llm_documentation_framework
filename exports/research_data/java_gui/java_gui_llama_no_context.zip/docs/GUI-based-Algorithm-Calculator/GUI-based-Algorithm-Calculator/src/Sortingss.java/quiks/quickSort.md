`quickSort`: The function of `quickSort` is to sort an array of integers in ascending order using the quicksort algorithm.

**Code Description**: The code defines a recursive function called `quickSort` that takes three parameters: an array of integers (`num`), and two indices (`start` and `end`) representing the range of elements to be sorted. The function uses the `partition` function (not shown in this snippet) to partition the array around a pivot element, and then recursively sorts the subarrays on either side of the pivot.\\
## Code: 
```
void quickSort(int[] num, int start, int end)
	 {
	    int partition = partition(num, start, end);
        if(partition-1>start)
        {
        	quickSort(num, start, partition - 1);
        }
    	if(partition+1<end) 
    	{
    		quickSort(num, partition + 1, end);
    	}
	 }
```