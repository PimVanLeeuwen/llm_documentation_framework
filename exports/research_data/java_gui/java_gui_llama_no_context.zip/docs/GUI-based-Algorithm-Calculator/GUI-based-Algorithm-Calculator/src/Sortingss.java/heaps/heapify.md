`heapify`: The function of `heapify` is to maintain the heap property in a binary heap data structure, ensuring that the parent node is greater than or equal to its child nodes.

**Code Description**: The `heapify` function takes an array `num`, its size `size`, and an index `i` as input. It recursively checks if the current node at index `i` has a larger value than its left and right children, and swaps them if necessary to maintain the heap property.\\
## Code: 
```
void heapify(int num[], int size, int i)
    {
        int largest = i;
        int left = 2*i + 1;
        int right = 2*i + 2;

        if (left < size && num[left] >num[largest])
            largest = left;

        if (right < size && num[right] > num[largest])
            largest = right;

        if (largest != i)
        {
        	int temp;
            temp = num[i];
            num[i]= num[largest];
            num[largest] = temp;
            heapify(num, size, largest);
        }
    }
```