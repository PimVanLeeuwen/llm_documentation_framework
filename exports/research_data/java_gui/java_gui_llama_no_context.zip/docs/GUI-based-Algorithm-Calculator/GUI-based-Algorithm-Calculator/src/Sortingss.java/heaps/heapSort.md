`heapSort`: The function of `heapSort` is to sort an array of integers in ascending order using the heap sort algorithm.

**Code Description**: The code implements a simple implementation of the heap sort algorithm, which consists of two main steps: building a max-heap and then extracting elements from the heap one by one. The `heapify` function is used to maintain the heap property after each extraction.\\
## Code: 
```
void heapSort(int num[], int size)
	    {
	        int i;
	        for (i = size / 2 - 1; i >= 0; i--)
	            heapify(num, size, i);
	        for (i=size-1; i>=0; i--)
	        {
	        	int temp;
	            temp = num[0];
	            num[0]= num[i];
	            num[i] = temp;
	            heapify(num, i, 0);
	        }
	     }
```