`actionPerformed`: The function of `actionPerformed` is to perform an action when an event occurs.

**Code Description**: This code snippet defines a method called `actionPerformed`, which appears to be part of a class that handles events in a graphical user interface (GUI) application. The method takes an `ActionEvent` object as a parameter, indicating that it responds to some type of user interaction or system event. When executed, the method calls another function `obj.vis(6,"HEAP SORT")`, which likely displays information about heap sort, and then sets the visibility of a GUI component called `frame` to false, effectively hiding it from view.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
				obj.vis(6,"HEAP SORT");
				frame.setVisible(false);
			}
```