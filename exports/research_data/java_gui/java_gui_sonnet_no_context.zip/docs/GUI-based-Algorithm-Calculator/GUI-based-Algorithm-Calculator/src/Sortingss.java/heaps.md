`heaps`: The function of `heaps` is to implement heap sort algorithm.

**Code Description**: This class implements the heap sort algorithm using a max heap data structure. It contains two main methods:

1. `heapify`: This method maintains the max heap property. It compares a node with its left and right children, swapping it with the largest child if necessary, and recursively applies this process to the affected subtree.

2. `heapSort`: This method sorts an array using the heap sort algorithm. It first builds a max heap from the input array, then repeatedly extracts the maximum element from the heap and places it at the end of the array.

The `heapSort` method works in two phases:
- Build max heap: It starts from the last non-leaf node and calls `heapify` on each node to create a max heap.
- Extract elements: It swaps the root (maximum element) with the last element, reduces the heap size, and calls `heapify` on the root to maintain the max heap property.

This implementation sorts the array in-place, resulting in the array being sorted in ascending order after the method completes.\\
## Code: 
```
class heaps{
	void heapify(int num[], int size, int i)
    {
        int largest = i;
        int left = 2*i + 1;
        int right = 2*i + 2;

        if (left < size && num[left] >num[largest])
            largest = left;

        if (right < size && num[right] > num[largest])
            largest = right;

        if (largest != i)
        {
        	int temp;
            temp = num[i];
            num[i]= num[largest];
            num[largest] = temp;
            heapify(num, size, largest);
        }
    }
 
	
	void heapSort(int num[], int size)
	    {
	        int i;
	        for (i = size / 2 - 1; i >= 0; i--)
	            heapify(num, size, i);
	        for (i=size-1; i>=0; i--)
	        {
	        	int temp;
	            temp = num[0];
	            num[0]= num[i];
	            num[i] = temp;
	            heapify(num, i, 0);
	        }
	     }
	       
}
```