`partition`: The function of `partition` is to rearrange elements in an array around a pivot element.

**Code Description**: This method implements the partition step of the quicksort algorithm. It takes an integer array `num`, and two indices `start` and `end` as parameters. The function chooses the last element (`num[end]`) as the pivot. It then iterates through the array from `start` to `end-1`, comparing each element with the pivot. Elements smaller than the pivot are moved to the left side of the array by swapping them with the element at the `start` index, which is then incremented. After the loop, the pivot is placed in its final sorted position by swapping it with the element at the `start` index. The function returns the final position of the pivot, which divides the array into two partitions: elements smaller than the pivot on the left, and elements greater than or equal to the pivot on the right.\\
## Code: 
```
int partition(int[] num, int start, int end){
	         int pivot = num[end];

	         for(int i=start; i<end; i++){
	            if(num[i]<pivot){
	            int temp= num[start];
	            num[start]=num[i];
	            num[i]=temp;
	            start++;
	        }
	        }

	        int temp = num[start];
	        num[start] = pivot;
	        num[end] = temp;
	        return start;

	        }
```