`heapify`: The function of `heapify` is to maintain the max-heap property for a binary heap.

**Code Description**: This function takes an array `num`, its size `size`, and an index `i` as input. It assumes that the binary trees rooted at `left` and `right` are max-heaps, but the element at index `i` might violate the max-heap property. The function compares the element at `i` with its left and right children, finds the largest among them, and swaps if necessary. If a swap occurs, it recursively calls itself on the affected subtree to ensure the max-heap property is maintained throughout. The process involves:

1. Initializing `largest` as the root (`i`).
2. Calculating indices of left and right children.
3. Comparing root with left child, updating `largest` if left child is greater.
4. Comparing the larger of root and left child with right child, updating `largest` if right child is greater.
5. If `largest` is not the root, swapping the root with the largest child and recursively calling `heapify` on the affected subtree.

This function is a crucial component of the heap sort algorithm and is used to build and maintain max-heaps.\\
## Code: 
```
void heapify(int num[], int size, int i)
    {
        int largest = i;
        int left = 2*i + 1;
        int right = 2*i + 2;

        if (left < size && num[left] >num[largest])
            largest = left;

        if (right < size && num[right] > num[largest])
            largest = right;

        if (largest != i)
        {
        	int temp;
            temp = num[i];
            num[i]= num[largest];
            num[largest] = temp;
            heapify(num, size, largest);
        }
    }
```