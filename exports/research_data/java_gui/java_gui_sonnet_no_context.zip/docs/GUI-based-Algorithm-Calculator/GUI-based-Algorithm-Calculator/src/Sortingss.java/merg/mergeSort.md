`mergeSort`: The function of `mergeSort` is to sort an array of integers using the merge sort algorithm.

**Code Description**: This function implements the recursive part of the merge sort algorithm. It takes an integer array `num` and two indices `l` and `r` representing the left and right boundaries of the current subarray. The function first checks if the left index is less than the right index. If true, it calculates the middle index `m` using the formula `l+(r-l)/2` to avoid potential integer overflow. Then, it recursively calls itself on the left half of the array (`l` to `m`) and the right half (`m+1` to `r`). After the recursive calls, it invokes a `merge` function (not shown in the provided code) to combine the sorted subarrays. This process continues until the entire array is sorted.\\
## Code: 
```
void mergeSort(int num[], int l, int r)
    {
        if (l < r)
        {
                int m = l+(r-l)/2;

            mergeSort(num, l, m);
            mergeSort(num, m+1, r);
            merge(num, l, m, r);
        }
    }
```