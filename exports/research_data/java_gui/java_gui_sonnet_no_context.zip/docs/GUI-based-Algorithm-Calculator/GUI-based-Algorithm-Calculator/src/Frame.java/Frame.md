`Frame`: The function of `Frame` is to create a graphical user interface for selecting different sorting algorithms.

**Code Description**: This class creates a window with buttons for various sorting algorithms. It uses Java Swing to build the GUI. The main method sets up the application by creating a Frame instance and making it visible. The Frame constructor calls the initialize method, which sets up the JFrame and adds buttons for Bubble Sort, Insertion Sort, Selection Sort, Merge Sort, Quick Sort, and Max Heap Sort. Each button has an ActionListener that, when clicked, calls a method vis() from a Sortingss object with specific parameters for the chosen sorting algorithm. The frame is then hidden after a button is clicked. The layout is set to null, and buttons are positioned using absolute coordinates.\\
## Code: 
```
class Frame {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Frame window = new Frame();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Frame() {
		initialize();
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		Sortingss obj = new Sortingss();
		frame = new JFrame();
		frame.setBounds(100, 100, 456, 324);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Bubble Sort");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(1,"BUBBLE SORT");
				frame.setVisible(false);	
			}
		});
		btnNewButton.setBounds(43, 48, 128, 25);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Insertion Sort");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(4,"INSERTION SORT");
				frame.setVisible(false);
			}
		});
		btnNewButton_1.setBounds(253, 48, 128, 25);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Selection Sort");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(2,"SELECTION SORT");
				frame.setVisible(false);
			}
		});
		btnNewButton_2.setBounds(43, 116, 128, 25);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Merge Sort");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(5,"MERGE SORT");
				frame.setVisible(false);
			}
		});
		btnNewButton_3.setBounds(253, 116, 128, 25);
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Quick Sort");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(3,"QUICK SORT");
				frame.setVisible(false);
			}
		});
		btnNewButton_4.setBounds(43, 178, 128, 25);
		frame.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Max Heap Sort");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(6,"HEAP SORT");
				frame.setVisible(false);
			}
		});
		btnNewButton_5.setBounds(253, 178, 128, 25);
		frame.getContentPane().add(btnNewButton_5);
	}
}
```