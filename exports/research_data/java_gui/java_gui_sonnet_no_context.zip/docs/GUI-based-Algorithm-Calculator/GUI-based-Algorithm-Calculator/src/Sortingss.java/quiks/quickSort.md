`quickSort`: The function of `quickSort` is to sort an array of integers using the QuickSort algorithm.

**Code Description**: This recursive implementation of QuickSort divides the array into smaller subarrays and sorts them. It uses a partition function to choose a pivot element and rearrange the array around it. The function takes three parameters: the array to be sorted (num), the starting index (start), and the ending index (end) of the current subarray. It first calls the partition function to get the partition index. Then, it recursively applies QuickSort to the left subarray (elements smaller than the pivot) if there are elements to the left of the partition. Similarly, it recursively sorts the right subarray (elements larger than the pivot) if there are elements to the right of the partition. This process continues until the entire array is sorted.\\
## Code: 
```
void quickSort(int[] num, int start, int end)
	 {
	    int partition = partition(num, start, end);
        if(partition-1>start)
        {
        	quickSort(num, start, partition - 1);
        }
    	if(partition+1<end) 
    	{
    		quickSort(num, partition + 1, end);
    	}
	 }
```