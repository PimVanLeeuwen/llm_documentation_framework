`quiks`: The function of `quiks` is to implement the QuickSort algorithm for sorting an array of integers.

**Code Description**: This class contains two methods: `quickSort` and `partition`. The `quickSort` method is the main recursive function that implements the QuickSort algorithm. It takes an integer array `num`, and two indices `start` and `end` as parameters. The method first calls the `partition` function to get a pivot index, then recursively sorts the subarrays on either side of the pivot.

The `partition` method is a helper function that selects the last element as the pivot and partitions the array around it. It iterates through the array, moving elements smaller than the pivot to the left side. Finally, it places the pivot in its correct sorted position and returns this index.

The implementation uses in-place sorting, meaning it doesn't create new arrays but modifies the original array. The time complexity of this QuickSort implementation is O(n log n) on average, but can degrade to O(n^2) in the worst case. The space complexity is O(log n) due to the recursive calls on the call stack.\\
## Code: 
```
class quiks
{
	 void quickSort(int[] num, int start, int end)
	 {
	    int partition = partition(num, start, end);
        if(partition-1>start)
        {
        	quickSort(num, start, partition - 1);
        }
    	if(partition+1<end) 
    	{
    		quickSort(num, partition + 1, end);
    	}
	 }

	     int partition(int[] num, int start, int end){
	         int pivot = num[end];

	         for(int i=start; i<end; i++){
	            if(num[i]<pivot){
	            int temp= num[start];
	            num[start]=num[i];
	            num[i]=temp;
	            start++;
	        }
	        }

	        int temp = num[start];
	        num[start] = pivot;
	        num[end] = temp;
	        return start;

	        }
}
```