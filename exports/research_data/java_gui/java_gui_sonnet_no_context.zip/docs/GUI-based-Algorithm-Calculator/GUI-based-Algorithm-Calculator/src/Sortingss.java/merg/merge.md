`merge`: The function of `merge` is to combine two sorted subarrays into a single sorted array.

**Code Description**: This function implements the merge step of the merge sort algorithm. It takes an array `num`, and three indices `l`, `m`, and `r` representing the left, middle, and right boundaries of the subarrays to be merged. The function first creates two temporary arrays `L` and `R` to store the left and right subarrays. It then copies the elements from the original array into these temporary arrays. The function then compares elements from both subarrays, placing the smaller element into the original array in sorted order. This process continues until all elements from both subarrays are merged back into the original array. Any remaining elements in either subarray are then copied to the end of the merged array. The result is a single sorted subarray within the original array from index `l` to `r`.\\
## Code: 
```
void merge(int num[], int l, int m, int r)
    {
        int i, j, k;
        int n1 = m - l + 1;
        int n2 =  r - m;
        int[] L = new int[n1];  
        int[] R = new int[n2];  
        //int L[n1], R[n2];

        for (i = 0; i < n1; i++)
            L[i] = num[l + i];
        for (j = 0; j < n2; j++)
            R[j] = num[m + 1+ j];

        i = 0; // Initial index of first subarray
        j = 0; // Initial index of second subarray
        k = l; // Initial index of merged subarray
        while (i < n1 && j < n2)
        {
            if (L[i] <= R[j])
            {
                num[k] = L[i];
                i++;
            }
            else
            {
                num[k] = R[j];
                j++;
            }
            k++;
        }

        while (i < n1)
        {
            num[k] = L[i];
            i++;
            k++;
        }

        while (j < n2)
        {
            num[k] = R[j];
            j++;
            k++;
        }
    }
```