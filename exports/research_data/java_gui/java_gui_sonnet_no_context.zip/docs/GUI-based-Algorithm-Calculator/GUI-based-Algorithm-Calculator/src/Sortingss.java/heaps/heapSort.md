`heapSort`: The function of `heapSort` is to sort an array of integers in ascending order using the heap sort algorithm.

**Code Description**: This function implements the heap sort algorithm to sort an array of integers. It operates in two main phases:

1. Build Max Heap: The first loop (i = size / 2 - 1 to 0) builds a max heap from the input array by calling the heapify function on each non-leaf node.

2. Extract and Sort: The second loop (i = size-1 to 0) repeatedly extracts the maximum element (root) from the heap, places it at the end of the array, and then calls heapify on the reduced heap to maintain the max heap property.

The function uses a swap operation to exchange elements and relies on a separate heapify function (not shown in this code snippet) to maintain the heap property. The sorting is performed in-place, modifying the original array without requiring additional space proportional to the input size.\\
## Code: 
```
void heapSort(int num[], int size)
	    {
	        int i;
	        for (i = size / 2 - 1; i >= 0; i--)
	            heapify(num, size, i);
	        for (i=size-1; i>=0; i--)
	        {
	        	int temp;
	            temp = num[0];
	            num[0]= num[i];
	            num[i] = temp;
	            heapify(num, i, 0);
	        }
	     }
```