`actionPerformed`: The function of `actionPerformed` is to handle an action event by making a specific visualization visible and hiding the current frame.

**Code Description**: This method is an event handler for an action event. When triggered, it calls the `vis` method on an object named `obj`, passing the arguments 6 and "HEAP SORT". This likely initializes or displays a visualization related to the Heap Sort algorithm. After that, it sets the visibility of a frame object to false, effectively hiding it from view. This method is typically used in graphical user interfaces to respond to user actions like button clicks, menu selections, or other interactive elements.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
				obj.vis(6,"HEAP SORT");
				frame.setVisible(false);
			}
```