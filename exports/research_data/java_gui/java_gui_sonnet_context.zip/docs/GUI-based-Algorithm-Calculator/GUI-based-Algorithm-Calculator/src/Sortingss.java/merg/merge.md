`merge`: The function of `merge` is to combine two sorted subarrays into a single sorted array.

**Parameters**:
`int num[]`: The original array containing the subarrays to be merged
`int l`: The starting index of the first subarray
`int m`: The ending index of the first subarray (and m+1 is the starting index of the second subarray)
`int r`: The ending index of the second subarray

**Code Description**: This method implements the merge step of the merge sort algorithm. It creates two temporary arrays, L and R, to hold the elements of the two subarrays to be merged. The first subarray is from index l to m, and the second subarray is from index m+1 to r. The method then compares elements from both subarrays and places them in the correct order back into the original array num[]. This process continues until all elements from both subarrays are merged back into the original array in sorted order. The method uses three pointers (i, j, and k) to keep track of the current positions in the L array, R array, and the original num[] array, respectively. After the main merging process, any remaining elements in either L or R are copied to the end of the merged portion of num[].\\
## Code: 
```
void merge(int num[], int l, int m, int r)
    {
        int i, j, k;
        int n1 = m - l + 1;
        int n2 =  r - m;
        int[] L = new int[n1];  
        int[] R = new int[n2];  
        //int L[n1], R[n2];

        for (i = 0; i < n1; i++)
            L[i] = num[l + i];
        for (j = 0; j < n2; j++)
            R[j] = num[m + 1+ j];

        i = 0; // Initial index of first subarray
        j = 0; // Initial index of second subarray
        k = l; // Initial index of merged subarray
        while (i < n1 && j < n2)
        {
            if (L[i] <= R[j])
            {
                num[k] = L[i];
                i++;
            }
            else
            {
                num[k] = R[j];
                j++;
            }
            k++;
        }

        while (i < n1)
        {
            num[k] = L[i];
            i++;
            k++;
        }

        while (j < n2)
        {
            num[k] = R[j];
            j++;
            k++;
        }
    }
```