`heapSort`: The function of `heapSort` is to sort an array of integers using the heap sort algorithm.

**Parameters**:
`int num[]`: The array of integers to be sorted
`int size`: The number of elements in the array

**Code Description**: The heapSort method implements the heap sort algorithm to sort an array in-place. It first builds a max heap from the input array by calling the heapify method on each non-leaf node, starting from the last non-leaf node up to the root. This is done in the first for loop. Then, it repeatedly extracts the maximum element (root) from the heap and places it at the end of the array. After each extraction, it reduces the heap size by 1 and calls heapify on the root to maintain the max heap property. This process is repeated until the entire array is sorted. The second for loop performs this extraction and re-heapification process. The method uses a temporary variable for swapping elements during the sorting process.\\
## Code: 
```
void heapSort(int num[], int size)
	    {
	        int i;
	        for (i = size / 2 - 1; i >= 0; i--)
	            heapify(num, size, i);
	        for (i=size-1; i>=0; i--)
	        {
	        	int temp;
	            temp = num[0];
	            num[0]= num[i];
	            num[i] = temp;
	            heapify(num, i, 0);
	        }
	     }
```