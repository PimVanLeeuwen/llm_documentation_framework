`heaps`: The function of `heaps` is to implement the Heap Sort algorithm.

**Code Description**: This class contains two main methods:

1. `heapify`: This method is responsible for maintaining the heap property. It takes an array, the size of the heap, and an index as parameters. It compares the element at the given index with its left and right children, swapping it with the largest child if necessary, and then recursively applies the same process to the affected subtree.

2. `heapSort`: This method implements the Heap Sort algorithm. It first builds a max heap from the input array by calling `heapify` on all non-leaf nodes. Then, it repeatedly extracts the maximum element (root) and places it at the end of the array, reducing the heap size by one and calling `heapify` on the root to maintain the heap property.

The class uses an in-place sorting approach, modifying the original array without requiring additional space proportional to the input size. The time complexity of Heap Sort is O(n log n) for all cases, making it an efficient sorting algorithm for large datasets.\\
## Code: 
```
class heaps{
	void heapify(int num[], int size, int i)
    {
        int largest = i;
        int left = 2*i + 1;
        int right = 2*i + 2;

        if (left < size && num[left] >num[largest])
            largest = left;

        if (right < size && num[right] > num[largest])
            largest = right;

        if (largest != i)
        {
        	int temp;
            temp = num[i];
            num[i]= num[largest];
            num[largest] = temp;
            heapify(num, size, largest);
        }
    }
 
	
	void heapSort(int num[], int size)
	    {
	        int i;
	        for (i = size / 2 - 1; i >= 0; i--)
	            heapify(num, size, i);
	        for (i=size-1; i>=0; i--)
	        {
	        	int temp;
	            temp = num[0];
	            num[0]= num[i];
	            num[i] = temp;
	            heapify(num, i, 0);
	        }
	     }
	       
}
```