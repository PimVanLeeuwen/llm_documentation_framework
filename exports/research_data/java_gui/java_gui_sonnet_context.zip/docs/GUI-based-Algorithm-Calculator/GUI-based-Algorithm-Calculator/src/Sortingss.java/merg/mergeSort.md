`mergeSort`: The function of `mergeSort` is to sort an array using the merge sort algorithm.

**Parameters**:
`int num[]`: The array to be sorted
`int l`: The starting index of the subarray to be sorted
`int r`: The ending index of the subarray to be sorted

**Code Description**: This method implements the recursive divide-and-conquer approach of the merge sort algorithm. It first checks if the subarray has more than one element (l < r). If so, it calculates the middle index m, then recursively calls itself on the left half (l to m) and right half (m+1 to r) of the subarray. After the recursive calls, it merges the two sorted halves using the merge method. The base case is when l >= r, at which point the recursion stops. This process continues until the entire array is sorted.\\
## Code: 
```
void mergeSort(int num[], int l, int r)
    {
        if (l < r)
        {
                int m = l+(r-l)/2;

            mergeSort(num, l, m);
            mergeSort(num, m+1, r);
            merge(num, l, m, r);
        }
    }
```