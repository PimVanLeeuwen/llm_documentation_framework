`partition`: The function of `partition` is to rearrange elements in an array around a pivot element.

**Parameters**:
`int[] num`: The array to be partitioned
`int start`: The starting index of the partition range
`int end`: The ending index of the partition range

**Code Description**: This method implements the partition step of the QuickSort algorithm. It selects the last element of the given range as the pivot. It then iterates through the array from `start` to `end-1`, comparing each element with the pivot. Elements smaller than the pivot are moved to the left side of the array by swapping them with the element at the `start` index, which is then incremented. After the iteration, the pivot is placed in its final sorted position by swapping it with the element at the current `start` index. The method returns the final position of the pivot, which divides the array into two subarrays: one with elements smaller than the pivot and another with elements larger than the pivot. This partition process is a crucial step in the QuickSort algorithm, as it helps to divide the array into smaller subarrays for recursive sorting.\\
## Code: 
```
int partition(int[] num, int start, int end){
	         int pivot = num[end];

	         for(int i=start; i<end; i++){
	            if(num[i]<pivot){
	            int temp= num[start];
	            num[start]=num[i];
	            num[i]=temp;
	            start++;
	        }
	        }

	        int temp = num[start];
	        num[start] = pivot;
	        num[end] = temp;
	        return start;

	        }
```