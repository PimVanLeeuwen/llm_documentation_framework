`quickSort`: The function of `quickSort` is to implement the QuickSort algorithm for sorting an array of integers.

**Parameters**:
`int[] num`: The array of integers to be sorted
`int start`: The starting index of the subarray to be sorted
`int end`: The ending index of the subarray to be sorted

**Code Description**: This method implements the recursive QuickSort algorithm. It first calls the `partition` method to divide the array into two parts around a pivot element. Then, it recursively applies the QuickSort algorithm to the left and right subarrays if they contain more than one element. The left subarray consists of elements from the start index to `partition - 1`, while the right subarray consists of elements from `partition + 1` to the end index. This process continues until the entire array is sorted.\\
## Code: 
```
void quickSort(int[] num, int start, int end)
	 {
	    int partition = partition(num, start, end);
        if(partition-1>start)
        {
        	quickSort(num, start, partition - 1);
        }
    	if(partition+1<end) 
    	{
    		quickSort(num, partition + 1, end);
    	}
	 }
```