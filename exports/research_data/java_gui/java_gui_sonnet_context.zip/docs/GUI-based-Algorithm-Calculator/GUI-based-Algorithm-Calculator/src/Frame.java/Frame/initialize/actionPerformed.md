`actionPerformed`: The function of `actionPerformed` is to handle a button click event by initiating a heap sort visualization and closing the current frame.

**Parameters**:
`ActionEvent e`: An event object representing the action that occurred, typically a button click.

**Code Description**: This method is an event handler for a user interface action. When triggered, it performs two main tasks:

1. It calls the `vis` method of an object named `obj`, passing the integer 6 and the string "HEAP SORT" as arguments. This likely initializes a visualization for the heap sort algorithm.

2. It sets the visibility of the current frame (`frame`) to false, effectively closing or hiding the window.

The method is designed to transition from the current interface to a heap sort visualization interface when a specific action (like a button click) occurs.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
				obj.vis(6,"HEAP SORT");
				frame.setVisible(false);
			}
```