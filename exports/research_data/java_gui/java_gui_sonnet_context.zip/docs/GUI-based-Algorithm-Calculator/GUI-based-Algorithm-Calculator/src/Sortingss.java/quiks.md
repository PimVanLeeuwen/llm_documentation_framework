`quiks`: The function of `quiks` is to implement the QuickSort algorithm for sorting an array of integers.

**Code Description**: This class contains two methods: `quickSort` and `partition`. The `quickSort` method is the main recursive function that implements the QuickSort algorithm. It takes an integer array, a start index, and an end index as parameters. The method calls the `partition` function to divide the array into two sub-arrays and then recursively sorts these sub-arrays. The `partition` method selects the last element as the pivot, places it in its correct position in the sorted array, and arranges smaller elements to its left and larger elements to its right. This process continues until the entire array is sorted. The implementation uses in-place sorting, which means it doesn't require additional memory proportional to the input size.\\
## Code: 
```
class quiks
{
	 void quickSort(int[] num, int start, int end)
	 {
	    int partition = partition(num, start, end);
        if(partition-1>start)
        {
        	quickSort(num, start, partition - 1);
        }
    	if(partition+1<end) 
    	{
    		quickSort(num, partition + 1, end);
    	}
	 }

	     int partition(int[] num, int start, int end){
	         int pivot = num[end];

	         for(int i=start; i<end; i++){
	            if(num[i]<pivot){
	            int temp= num[start];
	            num[start]=num[i];
	            num[i]=temp;
	            start++;
	        }
	        }

	        int temp = num[start];
	        num[start] = pivot;
	        num[end] = temp;
	        return start;

	        }
}
```