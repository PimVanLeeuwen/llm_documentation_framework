`heapify`: The function of `heapify` is to maintain the max-heap property for a binary heap.

**Parameters**:
`int num[]`: The array representing the binary heap
`int size`: The size of the heap
`int i`: The index of the root of the subtree to be heapified

**Code Description**: This method implements the heapify operation for a max-heap. It compares the element at index `i` with its left and right children, finds the largest among them, and swaps the largest child with the root if necessary. If a swap occurs, it recursively calls itself on the affected subtree to ensure the heap property is maintained throughout. The method uses temporary variables for swapping and handles array bounds to prevent out-of-bounds access. This operation is crucial for heap sort and priority queue implementations, ensuring that the largest element is always at the root of the heap or subtree.\\
## Code: 
```
void heapify(int num[], int size, int i)
    {
        int largest = i;
        int left = 2*i + 1;
        int right = 2*i + 2;

        if (left < size && num[left] >num[largest])
            largest = left;

        if (right < size && num[right] > num[largest])
            largest = right;

        if (largest != i)
        {
        	int temp;
            temp = num[i];
            num[i]= num[largest];
            num[largest] = temp;
            heapify(num, size, largest);
        }
    }
```