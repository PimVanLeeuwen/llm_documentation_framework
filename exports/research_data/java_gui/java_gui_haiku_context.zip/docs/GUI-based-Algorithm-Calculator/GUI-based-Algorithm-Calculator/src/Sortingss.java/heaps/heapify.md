`heapify`: The function of `heapify` is to maintain the heap property of a binary heap data structure.

**Parameters**:
`int num[]`: The array containing the elements to be heapified.
`int size`: The size of the array `num`.
`int i`: The index of the element to be heapified.

**Code Description**:
The `heapify` function takes an array `num`, its size `size`, and an index `i` as input. It ensures that the subtree rooted at index `i` satisfies the heap property, which states that the value of each node is greater than or equal to (or less than or equal to, depending on the type of heap) the values of its children.

The function works as follows:

1. It initializes `largest` to the index `i`, which is the root of the subtree to be heapified.
2. It calculates the indices of the left and right children of the node at index `i` as `left = 2*i + 1` and `right = 2*i + 2`, respectively.
3. It compares the values of the root (`num[i]`), the left child (`num[left]`), and the right child (`num[right]`). If the left child is larger than the root, it updates `largest` to the index of the left child.
4. It then compares the values of the root (`num[i]`) and the right child (`num[right]`). If the right child is larger than the current `largest`, it updates `largest` to the index of the right child.
5. If `largest` is not equal to `i`, it means that either the left or right child is larger than the root. In this case, it swaps the values at indices `i` and `largest`, and recursively calls `heapify` on the subtree rooted at `largest` to maintain the heap property.

This process continues until the heap property is satisfied for the entire subtree rooted at index `i`. The `heapify` function is a crucial part of the heap sort algorithm, as it is used to build and maintain the heap data structure.\\
## Code: 
```
void heapify(int num[], int size, int i)
    {
        int largest = i;
        int left = 2*i + 1;
        int right = 2*i + 2;

        if (left < size && num[left] >num[largest])
            largest = left;

        if (right < size && num[right] > num[largest])
            largest = right;

        if (largest != i)
        {
        	int temp;
            temp = num[i];
            num[i]= num[largest];
            num[largest] = temp;
            heapify(num, size, largest);
        }
    }
```