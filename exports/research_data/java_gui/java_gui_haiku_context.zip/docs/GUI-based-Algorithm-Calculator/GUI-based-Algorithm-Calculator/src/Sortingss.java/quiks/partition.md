`partition`: The function of `partition` is to divide the given array `num` into two partitions around a pivot element, where all elements less than the pivot are placed to the left of the pivot, and all elements greater than or equal to the pivot are placed to the right of the pivot.

**Parameters**:
`int[] num`: The input array to be partitioned.
`int start`: The starting index of the subarray to be partitioned.
`int end`: The ending index of the subarray to be partitioned.

**Code Description**:
1. The function first selects the last element of the subarray, `num[end]`, as the pivot.
2. It then iterates through the subarray from the `start` index to the `end-1` index.
3. For each element `num[i]` in the subarray, if it is less than the pivot, it is swapped with the element at the `start` index, and the `start` index is incremented.
4. After the loop, the pivot element is swapped with the element at the `start` index.
5. The function then returns the `start` index, which represents the new position of the pivot element in the partitioned array.

The purpose of this `partition` function is to rearrange the elements of the input array `num` in such a way that all elements less than the pivot are placed to the left of the pivot, and all elements greater than or equal to the pivot are placed to the right of the pivot. This is a crucial step in the implementation of the Quicksort algorithm, as it allows the algorithm to recursively sort the left and right subarrays of the pivot element.\\
## Code: 
```
int partition(int[] num, int start, int end){
	         int pivot = num[end];

	         for(int i=start; i<end; i++){
	            if(num[i]<pivot){
	            int temp= num[start];
	            num[start]=num[i];
	            num[i]=temp;
	            start++;
	        }
	        }

	        int temp = num[start];
	        num[start] = pivot;
	        num[end] = temp;
	        return start;

	        }
```