## Expected output

`Sortingss`: The function of `Sortingss` is to provide a GUI-based application that allows users to input a list of numbers and apply various sorting algorithms to sort the input.

**Code Description**:

The `Sortingss` class is the main class that sets up the GUI-based application. It contains the following key components:

1. `main()` method: This is the entry point of the application. It creates an instance of the `Sortingss` class and makes the GUI window visible.

2. `Sortingss()` constructor: This method initializes the GUI components, including the frame, text fields, buttons, and labels.

3. `vis()` method: This method sets the value of the `key` variable, updates the `tname` variable, and makes the `frame` object visible.

4. `initialize()` method: This method sets up the GUI components, including:
   - Creating a `JFrame` object to hold the GUI elements
   - Adding a `JTextArea` for displaying the sorting algorithm name
   - Adding a `JTextField` for user input
   - Adding a "Submit" button that performs the sorting operation
   - Adding an "Exit" button to close the application
   - Adding an "Open Code" button that opens the corresponding sorting algorithm code in Notepad

The application allows the user to input a space-separated list of integers and select a sorting algorithm to apply. The available sorting algorithms are:

1. Bubble Sort
2. Selection Sort
3. Quick Sort
4. Insertion Sort
5. Merge Sort
6. Heap Sort

When the user clicks the "Submit" button, the application performs the selected sorting algorithm on the input and displays the sorted output in the `JTextArea`. The name of the sorting algorithm is also displayed in the `JTextArea` at the top of the window.

The "Open Code" button allows the user to open the corresponding sorting algorithm code in Notepad, providing easy access to the implementation details of each sorting algorithm.

Overall, the `Sortingss` class provides a user-friendly GUI interface for demonstrating and experimenting with various sorting algorithms, making it a useful tool for learning and understanding these fundamental computer science concepts.\\
## Code: 
```
class Sortingss {

	private JFrame frame;
	private JTextField textField;
	int key;
	String tname = new String();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) throws Exception{
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Sortingss window = new Sortingss();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Sortingss() {
		initialize();
	}
	public int vis(int k,String str){
		key=k;
		tname="Hello";
		tname="pop";
		tname=str;
		frame.setVisible(true);
		return 0;
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
 
   
        private void initialize() {
		
        frame = new JFrame();
		frame.setBounds(100, 100, 514, 329);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setFont(new Font("Arial", Font.BOLD, 26));
		textArea_1.setBackground(Color.DARK_GRAY);
		textArea_1.setForeground(Color.WHITE);
		textArea_1.setBounds(102, 0, 304, 41);
		frame.getContentPane().add(textArea_1);
		
		
		textField = new JTextField();
		textField.setBounds(102, 102, 304, 22);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblEnterInput = new JLabel("Enter Input");
		lblEnterInput.setBounds(30, 105, 85, 16);
		frame.getContentPane().add(lblEnterInput);
		
		JTextArea textArea = new JTextArea();
		textArea.setLineWrap(true);
		textArea.setEditable(false);
		textArea.setBounds(102, 175, 304, 56);
		frame.getContentPane().add(textArea);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				
				String fin = new String();
				String str=new String();
				str = textField.getText();
				
				String [] tok = str.split(" ");
				int [] num = new int[tok.length];
				
				for(int i=0;i<tok.length;i++){
					num[i]=Integer.parseInt(tok[i]);
				}
				if(key==1)
				{
					int j;
			        boolean flag = true;   // set flag to true to begin first pass
			        int temp;   //holding variable

			        while ( flag )
			        {
			            flag= false;    //set flag to false awaiting a possible swap
			            for( j=0;  j < num.length -1;  j++ )
			            {
			                if ( num[ j ] > num[j+1] )   // change to > for ascending sort
			                {
			                    temp = num[ j ];                //swap elements
			                    num[ j ] = num[ j+1 ];
			                    num[ j+1 ] = temp;
			                    flag = true;              //shows a swap occurred
			                }
			            }
			        }
			        fin = "Bubble Sort =";
				}
				if(key==2){
			        int n = num.length;

			        // One by one move boundary of unsorted subarray
			        for (int i = 0; i < n-1; i++)
			        {
			            // Find the minimum element in unsorted array
			            int min_idx = i;
			            for (int j = i+1; j < n; j++)
			                if (num[j] < num[min_idx])
			                    min_idx = j;

			            // Swap the found minimum element with the first
			            // element
			            int temp = num[min_idx];
			            num[min_idx] = num[i];
			            num[i] = temp;
			        }
			        tname="SELECTION SORT";
			        fin = "Selection Sort =";
				}
				if(key==3){
				
					
					quiks obj2 =new quiks();
					int size=num.length;
					obj2.quickSort(num,0,size-1);
					fin="Quick Sort =";
					tname="QUICK SORT";
				}
				
				if(key==4){
					int i, ke, j;
			        for (i = 1; i < tok.length; i++)
			        {
			            ke = num[i];
			            j = i - 1;

			        /* Move elements of arr[0..i-1], that are
			        greater than key, to one position ahead
			        of their current position */
			            while (j >= 0 && num[j] > ke)
			            {
			                num[j + 1] = num[j];
			                j = j - 1;
			            }
			            num[j + 1] = ke;
			        }
			        tname="INSERTION SORT";
			        fin = "Insertion Sort =";
				}
				if(key==5){
					merg obj3=new merg();
					int size =num.length-1;
					obj3.mergeSort(num, 0, size);
					fin ="Merge Sort =";
					tname="MERGE SORT";
				}
				
				if(key==6){
					heaps obj4=new heaps();
					int size;
					size=tok.length;
					obj4.heapSort(num,size);
					fin ="Heap Sort =";
					tname="HEAP SORT";
				}
				
				String str1[] =new String[tok.length];
				for(int i=0;i<tok.length;i++){
					str1[i]=Integer.toString(num[i]);
					fin=fin+" "+str1[i];
				}
				textArea.setText(fin);
				textArea_1.setText(tname);
			}
		});
		btnSubmit.setBounds(210, 137, 97, 25);
		frame.getContentPane().add(btnSubmit);
		
		JLabel lblIntegerMustBe = new JLabel("Integer must be space separated in your input");
		lblIntegerMustBe.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblIntegerMustBe.setBounds(29, 48, 408, 41);
		frame.getContentPane().add(lblIntegerMustBe);
		
		JLabel lblYourOutput = new JLabel("Your Output");
		lblYourOutput.setBounds(30, 178, 112, 16);
		frame.getContentPane().add(lblYourOutput);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
			}
		});
		btnExit.setBounds(210, 244, 97, 25);
		frame.getContentPane().add(btnExit);
		
		JButton btnOpenCode = new JButton("Open Code");
		btnOpenCode.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
			if(key==1)
			{
				try{
				ProcessBuilder pb= new ProcessBuilder("Notepad.exe","bubble.txt");	
				pb.start();
				}catch(Exception ew){
					System.out.println(ew.toString());
				}
			}
			//C:\\Users\\HARSH\\workspace\\Selection.txt
			if(key==2){
				try{
					ProcessBuilder pb= new ProcessBuilder("Notepad.exe","selection.txt");	
					pb.start();
					}catch(Exception ew){
						System.out.println(ew.toString());
					}
			}
			if(key==3){
			
				try{
					ProcessBuilder pb= new ProcessBuilder("Notepad.exe","quicksort.txt");	
					pb.start();
					}catch(Exception ew){
						System.out.println(ew.toString());
				}
			}
			
			if(key==4){
				
				try{
					ProcessBuilder pb= new ProcessBuilder("Notepad.exe","insertion.txt");	
					pb.start();
					}catch(Exception ew){
						System.out.println(ew.toString());
				}
			}
			if(key==5){
				
				try{
					ProcessBuilder pb= new ProcessBuilder("Notepad.exe","merge.txt");	
					pb.start();
					}catch(Exception ew){
						System.out.println(ew.toString());
				}				
			}
			
			if(key==6){
				try{
					ProcessBuilder pb= new ProcessBuilder("Notepad.exe","maxheap.txt");	
					pb.start();
					}catch(Exception ew){
						System.out.println(ew.toString());
				}
			}
			}
		});
		btnOpenCode.setBounds(372, 244, 97, 25);
		frame.getContentPane().add(btnOpenCode);
		
		
	}
}
```