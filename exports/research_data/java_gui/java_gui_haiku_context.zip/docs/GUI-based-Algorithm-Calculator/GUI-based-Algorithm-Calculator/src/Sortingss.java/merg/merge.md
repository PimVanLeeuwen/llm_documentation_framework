`merge`: The function of `merge` is to merge two sorted subarrays of an array into a single sorted array.

**Parameters**:
`int num[]`: The input array that needs to be sorted.
`int l`: The starting index of the first subarray.
`int m`: The middle index that separates the first and second subarrays.
`int r`: The ending index of the second subarray.

**Code Description**:
The `merge` function is a part of the Merge Sort algorithm, which is a divide-and-conquer algorithm used to sort an array. The function takes an array `num`, and three indices `l`, `m`, and `r` that define the two subarrays to be merged.

1. The function first calculates the sizes of the two subarrays, `n1` and `n2`.
2. It then creates two temporary arrays, `L` and `R`, to store the elements of the two subarrays.
3. The function then copies the elements of the first subarray (from index `l` to `m`) into the `L` array, and the elements of the second subarray (from index `m+1` to `r`) into the `R` array.
4. The function then merges the two sorted subarrays `L` and `R` back into the original array `num`. It does this by comparing the elements of `L` and `R` and placing the smaller element into the `num` array. This is done until all elements from both subarrays have been merged.
5. Finally, the function handles any remaining elements in the `L` and `R` arrays by copying them back into the `num` array.

The overall time complexity of the `merge` function is O(n), where n is the size of the subarray being merged, as it performs a linear scan of the two subarrays and merges them into the original array.\\
## Code: 
```
void merge(int num[], int l, int m, int r)
    {
        int i, j, k;
        int n1 = m - l + 1;
        int n2 =  r - m;
        int[] L = new int[n1];  
        int[] R = new int[n2];  
        //int L[n1], R[n2];

        for (i = 0; i < n1; i++)
            L[i] = num[l + i];
        for (j = 0; j < n2; j++)
            R[j] = num[m + 1+ j];

        i = 0; // Initial index of first subarray
        j = 0; // Initial index of second subarray
        k = l; // Initial index of merged subarray
        while (i < n1 && j < n2)
        {
            if (L[i] <= R[j])
            {
                num[k] = L[i];
                i++;
            }
            else
            {
                num[k] = R[j];
                j++;
            }
            k++;
        }

        while (i < n1)
        {
            num[k] = L[i];
            i++;
            k++;
        }

        while (j < n2)
        {
            num[k] = R[j];
            j++;
            k++;
        }
    }
```