`Frame`: The function of `Frame` is to create a graphical user interface (GUI) for the Algorithm Calculator application.

**Code Description**:

The `Frame` class is responsible for creating and initializing the main window of the GUI-based Algorithm Calculator application. The class has the following key functionalities:

1. `main()` method:
   - This is the entry point of the application.
   - It creates a new instance of the `Frame` class and sets its visibility to `true`, allowing the application to be displayed.

2. `Frame()` constructor:
   - This constructor initializes the contents of the GUI frame by calling the `initialize()` method.

3. `initialize()` method:
   - This method sets up the layout and components of the GUI frame.
   - It creates a new `JFrame` object and sets its size, default close operation, and layout.
   - It then adds six buttons to the frame, each representing a different sorting algorithm:
     - Bubble Sort
     - Insertion Sort
     - Selection Sort
     - Merge Sort
     - Quick Sort
     - Heap Sort
   - Each button has an `ActionListener` that calls the `vis()` method of the `Sortingss` class with a specific argument when the button is clicked. This argument corresponds to the sorting algorithm that the button represents.
   - After adding the buttons, the `frame` object is set to be invisible.

The purpose of this code is to provide a user-friendly interface for the Algorithm Calculator application, allowing users to easily select and visualize different sorting algorithms. When a user clicks on one of the buttons, the corresponding sorting algorithm is executed, and the visualization is displayed in a separate window.\\
## Code: 
```
class Frame {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Frame window = new Frame();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Frame() {
		initialize();
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		Sortingss obj = new Sortingss();
		frame = new JFrame();
		frame.setBounds(100, 100, 456, 324);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Bubble Sort");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(1,"BUBBLE SORT");
				frame.setVisible(false);	
			}
		});
		btnNewButton.setBounds(43, 48, 128, 25);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Insertion Sort");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(4,"INSERTION SORT");
				frame.setVisible(false);
			}
		});
		btnNewButton_1.setBounds(253, 48, 128, 25);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Selection Sort");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(2,"SELECTION SORT");
				frame.setVisible(false);
			}
		});
		btnNewButton_2.setBounds(43, 116, 128, 25);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Merge Sort");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(5,"MERGE SORT");
				frame.setVisible(false);
			}
		});
		btnNewButton_3.setBounds(253, 116, 128, 25);
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Quick Sort");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(3,"QUICK SORT");
				frame.setVisible(false);
			}
		});
		btnNewButton_4.setBounds(43, 178, 128, 25);
		frame.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Max Heap Sort");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(6,"HEAP SORT");
				frame.setVisible(false);
			}
		});
		btnNewButton_5.setBounds(253, 178, 128, 25);
		frame.getContentPane().add(btnNewButton_5);
	}
}
```