`quickSort`: The function of `quickSort` is to recursively sort the given array `num` in ascending order using the quicksort algorithm.

**Parameters**:
`int[] num`: The array to be sorted.
`int start`: The starting index of the subarray to be sorted.
`int end`: The ending index of the subarray to be sorted.

**Code Description**:
The `quickSort` method is an implementation of the quicksort algorithm, which is a divide-and-conquer algorithm for sorting an array. The algorithm works by selecting a 'pivot' element from the array, and partitioning the other elements into two sub-arrays, according to whether they are less than or greater than the pivot. The sub-arrays are then recursively sorted.

The method takes three parameters:
1. `int[] num`: The array to be sorted.
2. `int start`: The starting index of the subarray to be sorted.
3. `int end`: The ending index of the subarray to be sorted.

The method first calls the `partition` helper function, which partitions the subarray around a pivot element. The `partition` function returns the index of the pivot element after the partitioning is complete.

After the partitioning, the method recursively calls itself on the left and right subarrays, i.e., the subarrays to the left and right of the pivot element. The left subarray contains all elements less than the pivot, and the right subarray contains all elements greater than the pivot.

The base case of the recursion is when the `start` index is greater than or equal to the `end` index, which means the subarray has been fully sorted.

The time complexity of the quicksort algorithm is O(n log n) on average, where n is the size of the input array. However, in the worst case, when the array is already sorted or reverse-sorted, the time complexity can be O(n^2).\\
## Code: 
```
void quickSort(int[] num, int start, int end)
	 {
	    int partition = partition(num, start, end);
        if(partition-1>start)
        {
        	quickSort(num, start, partition - 1);
        }
    	if(partition+1<end) 
    	{
    		quickSort(num, partition + 1, end);
    	}
	 }
```