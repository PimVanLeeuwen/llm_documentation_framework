`heapSort`: The function of `heapSort` is to sort an array of integers in ascending order using the heap sort algorithm.

**Parameters**:
`int num[]`: The array of integers to be sorted.
`int size`: The size of the array `num`.

**Code Description**: The `heapSort` function first builds a max-heap from the input array `num` using the `heapify` function. It then repeatedly extracts the maximum element (the root of the heap) and places it at the end of the sorted portion of the array, effectively sorting the array in ascending order.

The function works as follows:

1. It starts by building a max-heap from the input array `num`. This is done by calling the `heapify` function for each non-leaf node in the array, starting from the middle index `size/2 - 1` and going down to index 0.

2. After the max-heap is built, the function enters a loop that runs from the last index of the array (`size-1`) down to 0. In each iteration of the loop:
   - The function swaps the root element (the maximum element) with the element at the current index `i`.
   - It then calls the `heapify` function to restore the max-heap property for the modified array, starting from the root (index 0) and considering only the elements up to the current index `i`.

This process continues until the entire array is sorted in ascending order.

The `heapify` function is a helper function that ensures the heap property is maintained for a given subtree of the heap. It takes the array `num`, the size of the array `size`, and an index `i` as input. It then compares the element at index `i` with its left and right child elements (if they exist) and swaps the element at index `i` with the largest of the three if necessary. This process is repeated recursively for the left and right subtrees until the heap property is restored.

The time complexity of the `heapSort` function is O(n log n), where n is the size of the input array `num`. This is because the initial heap construction takes O(n) time, and the subsequent extraction of the maximum element and heap restoration takes O(log n) time for each of the n elements\\
## Code: 
```
void heapSort(int num[], int size)
	    {
	        int i;
	        for (i = size / 2 - 1; i >= 0; i--)
	            heapify(num, size, i);
	        for (i=size-1; i>=0; i--)
	        {
	        	int temp;
	            temp = num[0];
	            num[0]= num[i];
	            num[i] = temp;
	            heapify(num, i, 0);
	        }
	     }
```