`heaps`: The function of `heaps` is to implement the Heap Sort algorithm, which is a comparison-based sorting algorithm that works by first building a binary heap data structure from the input array, and then repeatedly extracting the maximum element from the heap to build the sorted array.

**Code Description**:

1. `heapify(int num[], int size, int i)`:
   - This method is responsible for maintaining the heap property in the binary heap data structure.
   - It takes an array `num`, the size of the array `size`, and the index `i` of the node to be heapified.
   - It finds the index of the largest element among the current node, its left child, and its right child.
   - If the largest element is not the current node, it swaps the current node with the largest element and recursively calls `heapify` on the largest element's index.
   - This process ensures that the subtree rooted at the current node satisfies the heap property.

2. `heapSort(int num[], int size)`:
   - This method implements the Heap Sort algorithm.
   - It first builds a max-heap from the input array `num` by calling `heapify` on all the non-leaf nodes (from the middle of the array to the beginning).
   - Then, it repeatedly extracts the maximum element (the root of the heap) and swaps it with the last element of the unsorted part of the array.
   - After each swap, it calls `heapify` on the root of the heap to maintain the heap property.
   - This process continues until the entire array is sorted in ascending order.

The Heap Sort algorithm has a time complexity of O(n log n) in the average and worst cases, making it an efficient sorting algorithm. It is particularly useful when the input data is too large to fit in memory, as it can be implemented in-place, requiring only a constant amount of extra space.

The `heaps` class provides the implementation of the Heap Sort algorithm, which can be used to sort an array of integers in ascending order. The `heapify` method ensures that the binary heap data structure is maintained, while the `heapSort` method orchestrates the overall sorting process.\\
## Code: 
```
class heaps{
	void heapify(int num[], int size, int i)
    {
        int largest = i;
        int left = 2*i + 1;
        int right = 2*i + 2;

        if (left < size && num[left] >num[largest])
            largest = left;

        if (right < size && num[right] > num[largest])
            largest = right;

        if (largest != i)
        {
        	int temp;
            temp = num[i];
            num[i]= num[largest];
            num[largest] = temp;
            heapify(num, size, largest);
        }
    }
 
	
	void heapSort(int num[], int size)
	    {
	        int i;
	        for (i = size / 2 - 1; i >= 0; i--)
	            heapify(num, size, i);
	        for (i=size-1; i>=0; i--)
	        {
	        	int temp;
	            temp = num[0];
	            num[0]= num[i];
	            num[i] = temp;
	            heapify(num, i, 0);
	        }
	     }
	       
}
```