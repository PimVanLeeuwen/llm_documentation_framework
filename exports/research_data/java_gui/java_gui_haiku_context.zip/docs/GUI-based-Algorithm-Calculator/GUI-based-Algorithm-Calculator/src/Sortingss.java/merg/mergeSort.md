`mergeSort`: The function of `mergeSort` is to recursively divide the input array into two halves, sort them, and then merge them back together to produce a sorted array.

**Parameters**:
`int num[]`: The input array that needs to be sorted.
`int l`: The index of the first element in the current subarray.
`int r`: The index of the last element in the current subarray.

**Code Description**:
The `mergeSort` function takes an array `num`, and the indices `l` and `r` that define the current subarray to be sorted. The function first checks if the subarray has more than one element (`l < r`). If so, it calculates the middle index `m` as the average of `l` and `r`.

The function then recursively calls `mergeSort` on the left and right halves of the subarray, i.e., the subarrays defined by the ranges `[l, m]` and `[m+1, r]`. Once the left and right subarrays are sorted, the function calls the `merge` function to merge the two sorted subarrays into a single sorted subarray.

The `merge` function is responsible for combining the two sorted subarrays into a single sorted subarray. It does this by comparing the elements in the two subarrays and placing them in the correct order in the original array.

The recursive nature of the `mergeSort` function ensures that the entire input array is eventually divided into single-element subarrays, which are then merged back together in a sorted manner. This results in the entire input array being sorted in ascending order.

The time complexity of the `mergeSort` algorithm is O(n log n), where n is the size of the input array. This is because the array is repeatedly divided in half, and the merge step takes linear time to combine the sorted subarrays.\\
## Code: 
```
void mergeSort(int num[], int l, int r)
    {
        if (l < r)
        {
                int m = l+(r-l)/2;

            mergeSort(num, l, m);
            mergeSort(num, m+1, r);
            merge(num, l, m, r);
        }
    }
```