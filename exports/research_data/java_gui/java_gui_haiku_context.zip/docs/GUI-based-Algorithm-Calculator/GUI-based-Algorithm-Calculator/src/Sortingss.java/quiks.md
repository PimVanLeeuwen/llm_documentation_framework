`quiks`: The function of `quiks` is to implement the quicksort algorithm to sort an array of integers.

**Code Description**:

The `quiks` class contains two methods: `quickSort` and `partition`.

1. `quickSort` method:
   - This method takes an integer array `num`, and the start and end indices `start` and `end` as input.
   - It recursively applies the quicksort algorithm to sort the given array.
   - The method first calls the `partition` function to partition the array around a pivot element.
   - If the left partition (from `start` to `partition - 1`) has more than one element, it recursively calls `quickSort` on the left partition.
   - If the right partition (from `partition + 1` to `end`) has more than one element, it recursively calls `quickSort` on the right partition.

2. `partition` method:
   - This method takes an integer array `num`, and the start and end indices `start` and `end` as input.
   - It partitions the array around a pivot element, which is chosen to be the last element in the array (`num[end]`).
   - It iterates through the array from the start index to the end index (exclusive), and for each element:
     - If the element is less than the pivot, it swaps the element with the element at the start index, and increments the start index.
   - After the loop, it swaps the pivot element (the last element) with the element at the start index.
   - It returns the start index, which is the new index of the pivot element.

The quicksort algorithm is a divide-and-conquer algorithm that recursively partitions the array around a pivot element and then sorts the left and right partitions. The `partition` function is a key step in the quicksort algorithm, as it rearranges the elements in the array such that all elements less than the pivot are on the left side, and all elements greater than the pivot are on the right side.

The time complexity of the quicksort algorithm is O(n log n) on average, but can degrade to O(n^2) in the worst case scenario (when the array is already sorted or reverse-sorted). The space\\
## Code: 
```
class quiks
{
	 void quickSort(int[] num, int start, int end)
	 {
	    int partition = partition(num, start, end);
        if(partition-1>start)
        {
        	quickSort(num, start, partition - 1);
        }
    	if(partition+1<end) 
    	{
    		quickSort(num, partition + 1, end);
    	}
	 }

	     int partition(int[] num, int start, int end){
	         int pivot = num[end];

	         for(int i=start; i<end; i++){
	            if(num[i]<pivot){
	            int temp= num[start];
	            num[start]=num[i];
	            num[i]=temp;
	            start++;
	        }
	        }

	        int temp = num[start];
	        num[start] = pivot;
	        num[end] = temp;
	        return start;

	        }
}
```