`actionPerformed`: The function of `actionPerformed` is to handle the user's input and perform various sorting algorithms on the input data.

**Parameters**:
`ActionEvent e`: This parameter represents the action event that triggered the `actionPerformed` method, such as a button click or a key press.

**Code Description**:
The `actionPerformed` method first retrieves the user's input from a text field and splits it into an array of integers. It then checks the value of the `key` variable to determine which sorting algorithm to apply to the input data.

If `key` is 1, the method performs a Bubble Sort on the input array. It uses a nested loop to compare adjacent elements and swap them if they are in the wrong order, repeating this process until the array is sorted.

If `key` is 2, the method performs a Selection Sort on the input array. It iterates through the array, finding the minimum element and swapping it with the first unsorted element.

If `key` is 3, the method calls the `quickSort` method from the `quiks` class to perform a Quick Sort on the input array. Quick Sort is a divide-and-conquer algorithm that recursively partitions the array around a pivot element and then sorts the resulting subarrays.

If `key` is 4, the method performs an Insertion Sort on the input array. It iterates through the array, inserting each element into its correct position in the sorted portion of the array.

If `key` is 5, the method calls the `mergeSort` method from the `merg` class to perform a Merge Sort on the input array. Merge Sort is a divide-and-conquer algorithm that recursively divides the array into smaller subarrays, sorts them, and then merges them back together.

If `key` is 6, the method calls the `heapSort` method from the `heaps` class to perform a Heap Sort on the input array. Heap Sort is a comparison-based sorting algorithm that first builds a binary heap data structure from the input array and then repeatedly extracts the maximum element to sort the array.

After applying the selected sorting algorithm, the method formats the sorted array as a string and displays it in a text area, along with the name of the sorting algorithm used.\\
## Code: 
```
void actionPerformed(ActionEvent e){
				
				String fin = new String();
				String str=new String();
				str = textField.getText();
				
				String [] tok = str.split(" ");
				int [] num = new int[tok.length];
				
				for(int i=0;i<tok.length;i++){
					num[i]=Integer.parseInt(tok[i]);
				}
				if(key==1)
				{
					int j;
			        boolean flag = true;   // set flag to true to begin first pass
			        int temp;   //holding variable

			        while ( flag )
			        {
			            flag= false;    //set flag to false awaiting a possible swap
			            for( j=0;  j < num.length -1;  j++ )
			            {
			                if ( num[ j ] > num[j+1] )   // change to > for ascending sort
			                {
			                    temp = num[ j ];                //swap elements
			                    num[ j ] = num[ j+1 ];
			                    num[ j+1 ] = temp;
			                    flag = true;              //shows a swap occurred
			                }
			            }
			        }
			        fin = "Bubble Sort =";
				}
				if(key==2){
			        int n = num.length;

			        // One by one move boundary of unsorted subarray
			        for (int i = 0; i < n-1; i++)
			        {
			            // Find the minimum element in unsorted array
			            int min_idx = i;
			            for (int j = i+1; j < n; j++)
			                if (num[j] < num[min_idx])
			                    min_idx = j;

			            // Swap the found minimum element with the first
			            // element
			            int temp = num[min_idx];
			            num[min_idx] = num[i];
			            num[i] = temp;
			        }
			        tname="SELECTION SORT";
			        fin = "Selection Sort =";
				}
				if(key==3){
				
					
					quiks obj2 =new quiks();
					int size=num.length;
					obj2.quickSort(num,0,size-1);
					fin="Quick Sort =";
					tname="QUICK SORT";
				}
				
				if(key==4){
					int i, ke, j;
			        for (i = 1; i < tok.length; i++)
			        {
			            ke = num[i];
			            j = i - 1;

			        /* Move elements of arr[0..i-1], that are
			        greater than key, to one position ahead
			        of their current position */
			            while (j >= 0 && num[j] > ke)
			            {
			                num[j + 1] = num[j];
			                j = j - 1;
			            }
			            num[j + 1] = ke;
			        }
			        tname="INSERTION SORT";
			        fin = "Insertion Sort =";
				}
				if(key==5){
					merg obj3=new merg();
					int size =num.length-1;
					obj3.mergeSort(num, 0, size);
					fin ="Merge Sort =";
					tname="MERGE SORT";
				}
				
				if(key==6){
					heaps obj4=new heaps();
					int size;
					size=tok.length;
					obj4.heapSort(num,size);
					fin ="Heap Sort =";
					tname="HEAP SORT";
				}
				
				String str1[] =new String[tok.length];
				for(int i=0;i<tok.length;i++){
					str1[i]=Integer.toString(num[i]);
					fin=fin+" "+str1[i];
				}
				textArea.setText(fin);
				textArea_1.setText(tname);
			}
```