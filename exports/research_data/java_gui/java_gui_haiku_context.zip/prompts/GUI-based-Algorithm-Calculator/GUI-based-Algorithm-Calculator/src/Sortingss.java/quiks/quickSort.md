# PROMPT
## Information
**Project Structure:** `GUI-based-Algorithm-Calculator` \
**File Path:** `GUI-based-Algorithm-Calculator/GUI-based-Algorithm-Calculator/src/Sortingss.java/quiks` \
**Type:** `Method` \
**Method Name:** `quickSort` \
**Code Content:** \
`void quickSort(int[] num, int start, int end)
	 {
	    int partition = partition(num, start, end);
        if(partition-1>start)
        {
        	quickSort(num, start, partition - 1);
        }
    	if(partition+1<end) 
    	{
    		quickSort(num, partition + 1, end);
    	}
	 }`

## Calls 
 This code calls the following methods within the repository: 
### GUI-based-Algorithm-Calculator/GUI-based-Algorithm-Calculator/src/Sortingss.java/quiks.quickSort 
### GUI-based-Algorithm-Calculator/GUI-based-Algorithm-Calculator/src/Sortingss.java/quiks.partition 
 - Explanation:  _The `partition` method is a helper function used in the quicksort algorithm. It partitions the given array around a pivot element, rearranging the elements such that all elements less than the pivot are on the left side and all elements greater than the pivot are on the right side._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`quickSort`: The function of `quickSort` is *FILL IN* 
**Parameters**:\
`int[] num`: *FILL IN* \
`int start`: *FILL IN* \
`int end`: *FILL IN* \

**Code Description**: *FILL IN*
