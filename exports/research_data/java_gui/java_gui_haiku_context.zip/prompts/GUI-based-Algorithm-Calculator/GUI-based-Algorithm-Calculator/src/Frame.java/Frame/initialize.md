# PROMPT
## Information
**Project Structure:** `GUI-based-Algorithm-Calculator` \
**File Path:** `GUI-based-Algorithm-Calculator/GUI-based-Algorithm-Calculator/src/Frame.java/Frame` \
**Type:** `Method` \
**Method Name:** `initialize` \
**Code Content:** \
`void initialize() {
		Sortingss obj = new Sortingss();
		frame = new JFrame();
		frame.setBounds(100, 100, 456, 324);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Bubble Sort");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(1,"BUBBLE SORT");
				frame.setVisible(false);	
			}
		});
		btnNewButton.setBounds(43, 48, 128, 25);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Insertion Sort");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(4,"INSERTION SORT");
				frame.setVisible(false);
			}
		});
		btnNewButton_1.setBounds(253, 48, 128, 25);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Selection Sort");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(2,"SELECTION SORT");
				frame.setVisible(false);
			}
		});
		btnNewButton_2.setBounds(43, 116, 128, 25);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Merge Sort");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(5,"MERGE SORT");
				frame.setVisible(false);
			}
		});
		btnNewButton_3.setBounds(253, 116, 128, 25);
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Quick Sort");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(3,"QUICK SORT");
				frame.setVisible(false);
			}
		});
		btnNewButton_4.setBounds(43, 178, 128, 25);
		frame.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Max Heap Sort");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(6,"HEAP SORT");
				frame.setVisible(false);
			}
		});
		btnNewButton_5.setBounds(253, 178, 128, 25);
		frame.getContentPane().add(btnNewButton_5);
	}`



## Children 
 This code contains the following methods/classes that are already documented: 
### actionPerformed 
The `actionPerformed` method is triggered when a certain action occurs. It calls the `vis` method from the `Sortingss` class, passing the integer `1` and the string `"BUBBLE SORT"` as arguments, and then sets the `frame` object to be visible. 
### actionPerformed 
This code is an event handler method that is called when a certain action is performed. When the action is performed, it calls the `vis` method from the `Sortingss` class, passing in the integer `4` and the string `"INSERTION SORT"`, and then sets the visibility of the `frame` object to `false`. 
### actionPerformed 
This code is an event handler method that is called when a certain action is performed. It calls the `vis` method from the `Sortingss` class, passing in the integer `2` and the string `"SELECTION SORT"`, and then sets the visibility of the `frame` object to `false`. 
### actionPerformed 
The `actionPerformed` method is triggered when a certain action occurs. It calls the `vis` method from the `Sortingss` class, passing the integer `5` and the string `"MERGE SORT"` as arguments, and then sets the `frame` object to be invisible. 
### actionPerformed 
This code is an event handler method that is called when a certain action is performed. It calls the `vis` method from the `Sortingss` class, passing the values `3` and `"QUICK SORT"` as arguments, and then sets the visibility of the `frame` object to `false`. 
### actionPerformed 
This code is an event handler method that is called when a certain action is performed. When the action is performed, it calls the `vis` method from the `Sortingss` class, passing the values `6` and `"HEAP SORT"`, and then sets the visibility of the `frame` object to `false`. 



## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`initialize`: The function of `initialize` is *FILL IN* 

**Code Description**: *FILL IN*
