# PROMPT
## Information
**Project Structure:** `GUI-based-Algorithm-Calculator` \
**File Path:** `GUI-based-Algorithm-Calculator/GUI-based-Algorithm-Calculator/src/Frame.java/Frame/initialize` \
**Type:** `Method` \
**Method Name:** `actionPerformed` \
**Code Content:** \
`void actionPerformed(ActionEvent e) {
				obj.vis(6,"HEAP SORT");
				frame.setVisible(false);
			}`

## Calls 
 This code calls the following methods within the repository: 
### GUI-based-Algorithm-Calculator/GUI-based-Algorithm-Calculator/src/Sortingss.java/Sortingss.vis 
 - Explanation:  _The `vis` method takes two parameters: an integer `k` and a string `str`. It sets the value of the `key` variable to `k`, updates the `tname` variable with the string values "pop" and then `str`, and makes the `frame` object visible._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`actionPerformed`: The function of `actionPerformed` is *FILL IN* 
**Parameters**:\
`ActionEvent e`: *FILL IN* \

**Code Description**: *FILL IN*
