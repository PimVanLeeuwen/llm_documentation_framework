# PROMPT
## Information
**Project Structure:** `GUI-based-Algorithm-Calculator` \
**File Path:** `GUI-based-Algorithm-Calculator/GUI-based-Algorithm-Calculator/src/Sortingss.java/heaps` \
**Type:** `Method` \
**Method Name:** `heapSort` \
**Code Content:** \
`void heapSort(int num[], int size)
	    {
	        int i;
	        for (i = size / 2 - 1; i >= 0; i--)
	            heapify(num, size, i);
	        for (i=size-1; i>=0; i--)
	        {
	        	int temp;
	            temp = num[0];
	            num[0]= num[i];
	            num[i] = temp;
	            heapify(num, i, 0);
	        }
	     }`

## Calls 
 This code calls the following methods within the repository: 
### GUI-based-Algorithm-Calculator/GUI-based-Algorithm-Calculator/src/Sortingss.java/heaps.heapify 
 - Explanation:  _The `heapify` method is a helper function used in the implementation of the heap data structure. It takes an array `num`, the size of the array `size`, and an index `i`, and rearranges the elements in the array to maintain the heap property._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`heapSort`: The function of `heapSort` is *FILL IN* 
**Parameters**:\
`int num[]`: *FILL IN* \
`int size`: *FILL IN* \

**Code Description**: *FILL IN*
