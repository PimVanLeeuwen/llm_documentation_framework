`quiks`: The function of `quiks` is to implement the QuickSort algorithm to sort an array of integers.

**Code Description**: 
The `quiks` class contains two methods: `quickSort` and `partition`.

1. `quickSort(int[] num, int start, int end)`: This method sorts the array `num` using the QuickSort algorithm. It takes three parameters: the array `num`, the starting index `start`, and the ending index `end`. The method works by recursively partitioning the array around a pivot element and then sorting the subarrays on either side of the pivot. The base case for the recursion is when the subarray has one or zero elements.

2. `partition(int[] num, int start, int end)`: This method partitions the array `num` around a pivot element, which is chosen to be the last element in the subarray. It takes three parameters: the array `num`, the starting index `start`, and the ending index `end`. The method rearranges the elements in the subarray such that all elements less than the pivot are on the left, and all elements greater than the pivot are on the right. It then places the pivot element in its correct position and returns the index of the pivot.

The `quickSort` method calls the `partition` method to get the pivot index and then recursively sorts the subarrays to the left and right of the pivot. This process continues until the entire array is sorted.\\
## Code: 
```
class quiks
{
	 void quickSort(int[] num, int start, int end)
	 {
	    int partition = partition(num, start, end);
        if(partition-1>start)
        {
        	quickSort(num, start, partition - 1);
        }
    	if(partition+1<end) 
    	{
    		quickSort(num, partition + 1, end);
    	}
	 }

	     int partition(int[] num, int start, int end){
	         int pivot = num[end];

	         for(int i=start; i<end; i++){
	            if(num[i]<pivot){
	            int temp= num[start];
	            num[start]=num[i];
	            num[i]=temp;
	            start++;
	        }
	        }

	        int temp = num[start];
	        num[start] = pivot;
	        num[end] = temp;
	        return start;

	        }
}
```