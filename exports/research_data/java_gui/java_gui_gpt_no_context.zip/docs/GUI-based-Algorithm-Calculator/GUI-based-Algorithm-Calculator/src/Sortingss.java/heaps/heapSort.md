`heapSort`: The function of `heapSort` is to sort an array of integers in ascending order using the heap sort algorithm.

**Code Description**: 
- The `heapSort` function takes an array of integers `num` and its size `size` as input.
- It first builds a max heap from the input array by calling the `heapify` function on each non-leaf node, starting from the last non-leaf node up to the root.
- After building the max heap, it repeatedly swaps the root of the heap (the largest element) with the last element of the heap and reduces the heap size by one.
- It then calls the `heapify` function on the reduced heap to maintain the max heap property.
- This process continues until the entire array is sorted in ascending order.\\
## Code: 
```
void heapSort(int num[], int size)
	    {
	        int i;
	        for (i = size / 2 - 1; i >= 0; i--)
	            heapify(num, size, i);
	        for (i=size-1; i>=0; i--)
	        {
	        	int temp;
	            temp = num[0];
	            num[0]= num[i];
	            num[i] = temp;
	            heapify(num, i, 0);
	        }
	     }
```