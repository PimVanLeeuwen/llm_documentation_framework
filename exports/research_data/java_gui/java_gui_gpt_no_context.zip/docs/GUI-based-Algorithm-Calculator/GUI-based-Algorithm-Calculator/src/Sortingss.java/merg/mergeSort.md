`mergeSort`: The function of `mergeSort` is to sort an array of integers using the merge sort algorithm.

**Code Description**: 
- The `mergeSort` function takes three parameters: an array of integers `num`, and two integers `l` and `r` which represent the left and right indices of the array segment to be sorted.
- The function first checks if the left index `l` is less than the right index `r`. If true, it means the segment has more than one element and needs sorting.
- It calculates the middle index `m` of the segment using the formula `m = l + (r - l) / 2`.
- The function then recursively calls itself to sort the left half of the segment (`num[l..m]`) and the right half of the segment (`num[m+1..r]`).
- After sorting both halves, it calls the `merge` function to merge the two sorted halves into a single sorted segment.\\
## Code: 
```
void mergeSort(int num[], int l, int r)
    {
        if (l < r)
        {
                int m = l+(r-l)/2;

            mergeSort(num, l, m);
            mergeSort(num, m+1, r);
            merge(num, l, m, r);
        }
    }
```