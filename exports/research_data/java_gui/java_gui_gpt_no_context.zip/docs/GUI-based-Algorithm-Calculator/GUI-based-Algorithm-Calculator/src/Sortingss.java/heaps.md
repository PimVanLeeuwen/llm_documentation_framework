`heaps`: The function of `heaps` is to provide methods for sorting an array using the heap sort algorithm.

**Code Description**: 
- The `heaps` class contains two methods: `heapify` and `heapSort`.
- `heapify(int num[], int size, int i)`: This method ensures that the subtree rooted at index `i` in the array `num` is a max-heap. It does this by comparing the value at index `i` with its left and right children and swapping it with the largest of the three if necessary. This process is repeated recursively until the subtree satisfies the max-heap property.
- `heapSort(int num[], int size)`: This method sorts the array `num` using the heap sort algorithm. It first builds a max-heap from the array. Then, it repeatedly swaps the first element (the largest) with the last unsorted element, reduces the size of the heap by one, and calls `heapify` to restore the max-heap property. This process continues until the entire array is sorted.\\
## Code: 
```
class heaps{
	void heapify(int num[], int size, int i)
    {
        int largest = i;
        int left = 2*i + 1;
        int right = 2*i + 2;

        if (left < size && num[left] >num[largest])
            largest = left;

        if (right < size && num[right] > num[largest])
            largest = right;

        if (largest != i)
        {
        	int temp;
            temp = num[i];
            num[i]= num[largest];
            num[largest] = temp;
            heapify(num, size, largest);
        }
    }
 
	
	void heapSort(int num[], int size)
	    {
	        int i;
	        for (i = size / 2 - 1; i >= 0; i--)
	            heapify(num, size, i);
	        for (i=size-1; i>=0; i--)
	        {
	        	int temp;
	            temp = num[0];
	            num[0]= num[i];
	            num[i] = temp;
	            heapify(num, i, 0);
	        }
	     }
	       
}
```