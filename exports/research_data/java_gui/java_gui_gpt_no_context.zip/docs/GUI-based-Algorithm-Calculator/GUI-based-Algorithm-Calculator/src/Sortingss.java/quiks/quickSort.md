`quickSort`: The function of `quickSort` is to sort an array of integers in ascending order using the QuickSort algorithm.

**Code Description**: 
The `quickSort` function takes an array of integers (`num`), a starting index (`start`), and an ending index (`end`). It sorts the elements of the array between the indices `start` and `end` (inclusive) using the QuickSort algorithm. The function works by selecting a partition index, then recursively sorting the subarrays to the left and right of the partition index. The base case for the recursion is when the subarray has one or zero elements, at which point the function returns without making any changes. The `partition` function, which is called within `quickSort`, is responsible for rearranging the elements in such a way that all elements less than the pivot are on the left, and all elements greater than the pivot are on the right.\\
## Code: 
```
void quickSort(int[] num, int start, int end)
	 {
	    int partition = partition(num, start, end);
        if(partition-1>start)
        {
        	quickSort(num, start, partition - 1);
        }
    	if(partition+1<end) 
    	{
    		quickSort(num, partition + 1, end);
    	}
	 }
```