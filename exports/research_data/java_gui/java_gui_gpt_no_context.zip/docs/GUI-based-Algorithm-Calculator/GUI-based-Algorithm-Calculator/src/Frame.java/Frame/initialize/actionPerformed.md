`actionPerformed`: The function of `actionPerformed` is to handle an action event triggered by the user.

**Code Description**: When an action event occurs, this method calls the `vis` method on the `obj` object with the parameters `6` and `"HEAP SORT"`, which likely initiates a visualization or process related to heap sort. After that, it sets the visibility of the `frame` object to `false`, effectively hiding the frame from the user interface.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
				obj.vis(6,"HEAP SORT");
				frame.setVisible(false);
			}
```