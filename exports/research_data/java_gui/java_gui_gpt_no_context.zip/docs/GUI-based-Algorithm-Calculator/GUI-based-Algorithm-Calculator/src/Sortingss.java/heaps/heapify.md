`heapify`: The function of `heapify` is to maintain the max-heap property in a binary heap.

**Code Description**: The `heapify` function takes an array `num`, its size `size`, and an index `i`. It ensures that the subtree rooted at index `i` satisfies the max-heap property. The function works by comparing the value at index `i` with its left and right children. If either child is larger than the value at `i`, it swaps the value at `i` with the larger child and recursively calls `heapify` on the affected subtree. This process continues until the subtree rooted at `i` is a valid max-heap.\\
## Code: 
```
void heapify(int num[], int size, int i)
    {
        int largest = i;
        int left = 2*i + 1;
        int right = 2*i + 2;

        if (left < size && num[left] >num[largest])
            largest = left;

        if (right < size && num[right] > num[largest])
            largest = right;

        if (largest != i)
        {
        	int temp;
            temp = num[i];
            num[i]= num[largest];
            num[largest] = temp;
            heapify(num, size, largest);
        }
    }
```