`partition`: The function of `partition` is to rearrange the elements in the array such that all elements less than the pivot are on the left side, and all elements greater than the pivot are on the right side, and then return the final position of the pivot.

**Code Description**: The `partition` function takes an array `num` and two indices `start` and `end`. It selects the element at the `end` index as the pivot. It then iterates through the array from `start` to `end-1`. For each element that is less than the pivot, it swaps that element with the element at the `start` index and increments the `start` index. After the loop, it swaps the pivot element with the element at the `start` index, placing the pivot in its correct position in the sorted array. Finally, it returns the index of the pivot.\\
## Code: 
```
int partition(int[] num, int start, int end){
	         int pivot = num[end];

	         for(int i=start; i<end; i++){
	            if(num[i]<pivot){
	            int temp= num[start];
	            num[start]=num[i];
	            num[i]=temp;
	            start++;
	        }
	        }

	        int temp = num[start];
	        num[start] = pivot;
	        num[end] = temp;
	        return start;

	        }
```