`merge`: The function of `merge` is to combine two sorted subarrays into a single sorted array.

**Code Description**: 
- The `merge` function takes an array `num` and three integers `l`, `m`, and `r` as input. These integers represent the indices of the left, middle, and right boundaries of the subarrays to be merged.
- It calculates the sizes of the two subarrays to be merged: `n1` (from `l` to `m`) and `n2` (from `m+1` to `r`).
- It creates two temporary arrays `L` and `R` to hold the elements of the left and right subarrays, respectively.
- It copies the elements from the original array `num` into the temporary arrays `L` and `R`.
- It initializes three indices `i`, `j`, and `k` to 0. `i` and `j` are used to traverse the temporary arrays `L` and `R`, while `k` is used to traverse the merged subarray in the original array `num`.
- It merges the two subarrays by comparing elements from `L` and `R` and copying the smaller element into the original array `num`.
- After merging the elements from both subarrays, it copies any remaining elements from `L` and `R` into the original array `num`.
- The result is a single sorted subarray within the original array `num` from index `l` to `r`.\\
## Code: 
```
void merge(int num[], int l, int m, int r)
    {
        int i, j, k;
        int n1 = m - l + 1;
        int n2 =  r - m;
        int[] L = new int[n1];  
        int[] R = new int[n2];  
        //int L[n1], R[n2];

        for (i = 0; i < n1; i++)
            L[i] = num[l + i];
        for (j = 0; j < n2; j++)
            R[j] = num[m + 1+ j];

        i = 0; // Initial index of first subarray
        j = 0; // Initial index of second subarray
        k = l; // Initial index of merged subarray
        while (i < n1 && j < n2)
        {
            if (L[i] <= R[j])
            {
                num[k] = L[i];
                i++;
            }
            else
            {
                num[k] = R[j];
                j++;
            }
            k++;
        }

        while (i < n1)
        {
            num[k] = L[i];
            i++;
            k++;
        }

        while (j < n2)
        {
            num[k] = R[j];
            j++;
            k++;
        }
    }
```