`filterPaymentJob`: The function of `filterPaymentJob` is to remove invoices from the list that do not belong to a specific job.

**Parameters**: 
`List<Invoice> invoiceList`: A list of invoices to be filtered, where each invoice has a reference to a job.

**Code Description**: This method iterates over the provided list of invoices and removes any invoice whose job does not match the selected job. If no job is selected, it simply returns without modifying the list.\\
## Code: 
```
void filterPaymentJob(List<Invoice> invoiceList) {
		
		if(selectedJob == null)
			return;
		
		Iterator<Invoice> invoice = invoiceList.iterator();
		Invoice invoiceItem;
		while(invoice.hasNext()) {
			invoiceItem = invoice.next();
			if(invoiceItem.getJob().getId() != selectedJob.getId()) {
				invoice.remove();
			}
		}
		
	}
```