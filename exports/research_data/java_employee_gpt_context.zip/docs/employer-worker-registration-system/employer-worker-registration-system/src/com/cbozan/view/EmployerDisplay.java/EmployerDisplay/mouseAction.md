## Expected output
`mouseAction`: The function of `mouseAction` is to handle mouse actions on the employer display, such as selecting a job from a search result.
**Parameters**:\
`MouseEvent e`: This parameter represents the mouse event that triggered the action.
`Object searchResultObject`: This parameter represents the object returned by the search result, which in this case is a Job object.
`int chooseIndex`: This parameter represents the index of the chosen job in the search results.

**Code Description**: The `mouseAction` method updates the employer payment job filter search box with the selected job's details, makes it non-editable, and changes the color of the label to indicate that a job has been selected. It also shows the remove employer payment job filter button and updates the employer payment table data.\\
## Code: 
```
void mouseAction(MouseEvent e, Object searchResultObject, int chooseIndex) {
				selectedJob = (Job) searchResultObject;
				employerPaymentJobFilterSearchBox.setText(selectedJob.toString());
				employerPaymentJobFilterSearchBox.setEditable(false);
				employerPaymentJobFilterLabel.setForeground(new Color(37, 217, 138));
				removeEmployerPaymentJobFilterButton.setVisible(true);
				updateEmployerPaymentTableData();
				super.mouseAction(e, searchResultObject, chooseIndex);
			}
```