## Expected output
`addEditButton`: The function of `addEditButton` is to create and return a JButton that toggles the editability of a JTextComponent.
**Parameters**:\
`JTextComponent textField`: This parameter represents the JTextComponent whose editability will be toggled by the JButton.
`Component nextFocus`: This parameter represents the Component that will receive focus when the JButton is clicked, or null if no specific component should receive focus.

**Code Description**: The `addEditButton` function creates a JButton with an edit icon. When clicked, it checks if the JTextComponent is currently editable. If so, it changes the button's icon to a check icon, makes the JTextComponent non-editable, and either requests focus for the window or sets focus on the next available component. If the JTextComponent is not editable, it becomes editable, the button's icon changes back to an edit icon, and the JTextComponent gains focus.\\
## Code: 
```
JButton addEditButton(JTextComponent textField, Component nextFocus) {
		JButton editButton = new JButton(new ImageIcon("src\\icon\\text_edit.png"));
		editButton.setContentAreaFilled(false);
		editButton.setFocusable(false);
		editButton.setBorderPainted(false);
		editButton.setBounds(textField.getX() + textField.getWidth() + BS, textField.getY(), BW, rowHeight);
		
		editButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(textField.isEditable()) {
					editButton.setIcon(new ImageIcon("src\\icon\\text_edit.png"));
					textField.setEditable(false);
					if(nextFocus != null) {
						nextFocus.requestFocus();
					} else {
						requestFocusInWindow();
					}
					
				} else if(!textField.getText().equals(INIT_TEXT)) {
						textField.setEditable(true);
						editButton.setIcon(new ImageIcon("src\\icon\\check.png"));
				}
				super.mouseClicked(e);
			}
		});
		
		return editButton;
	}
```