**DBConst**: The function of `DBConst` is to define constants for database-related field lengths, specifically for first name (`FNAME_LENGTH`) and last name (`LNAME_LENGTH`).

**Code Description**: The `DBConst` class contains two public static final integer variables: `FNAME_LENGTH` set to 30 and `LNAME_LENGTH` set to 20. These values likely represent the maximum allowed character lengths for first names and last names in a database, respectively.\\
## Code: 
```
class DBConst {
	public static final int FNAME_LENGTH = 30;
	public static final int LNAME_LENGTH = 20;
}
```