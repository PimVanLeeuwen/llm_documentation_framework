## EmptyInstanceSingleton: 
The function of `EmptyInstanceSingleton` is to create a singleton instance of the `Price` class, which means it will ensure that only one instance of the `Price` class exists throughout the application.

## Code Description:
The code defines a class called `EmptyInstanceSingleton`, which contains a static final field named `instance`. This field holds an instance of the `Price` class. The key point here is that this instance is created when the `EmptyInstanceSingleton` class is loaded, and it will be reused for all subsequent requests to access the singleton instance.\\
## Code: 
```
class EmptyInstanceSingleton{
		private static final Price instance = new Price(); 
	}
```