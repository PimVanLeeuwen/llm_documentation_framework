## EmptyInstanceSingleton: 
The function of `EmptyInstanceSingleton` is to create a singleton instance of the `Invoice` class, which means it will always return the same instance of `Invoice` whenever requested.

## Code Description:
The code defines a class called `EmptyInstanceSingleton`, which contains a static final variable `instance` initialized with an instance of the `Invoice` class. This design pattern is known as the "empty instance singleton" or "static singleton", where a single instance of the class is created and reused throughout the application, eliminating the need for multiple instances.\\
## Code: 
```
class EmptyInstanceSingleton{
		private static final Invoice instance = new Invoice(); 
	}
```