**The function of `toString` is to return a string representation of an employer's name, which is the concatenation of their first and last names.**

**Code Description: The `toString` method in the Employer class returns a string that combines the first name (fname) and last name (lname) of an employer, separated by a space. This allows for easy display or logging of an employer's full name when needed.**\\
## Code: 
```
String toString() {
		return getFname() + " " + getLname();
	}
```