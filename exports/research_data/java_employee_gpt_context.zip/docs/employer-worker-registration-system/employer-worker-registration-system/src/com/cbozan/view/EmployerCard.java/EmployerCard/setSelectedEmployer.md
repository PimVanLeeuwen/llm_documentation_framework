`setSelectedEmployer`: The function of `setSelectedEmployer` is to update the UI components with the information of the newly selected employer.

**Parameters**: 
`Employer selectedEmployer`: This parameter represents the newly selected employer, which contains its details such as first name, last name, telephone number, and description.

**Code Description**: The method sets the content of various UI components (text fields and text area) with the information from the `selectedEmployer`. If no employer is selected, it resets the UI components to their default values. Additionally, it disables editing for certain UI components and updates the icon on a button.\\
## Code: 
```
void setSelectedEmployer(Employer selectedEmployer) {
		this.selectedEmployer = selectedEmployer;
		
		if(selectedEmployer == null) {
			fnameTextField.setText(INIT_TEXT);
			lnameTextField.setText(INIT_TEXT);
			telTextField.setText(INIT_TEXT);
			descriptionTextArea.setText(INIT_TEXT);
		} else {
			
			setFnameTextFieldContent(selectedEmployer.getFname());
			setLnameTextFieldContent(selectedEmployer.getLname());
			if(selectedEmployer.getTel() == null || selectedEmployer.getTel().size() == 0)
				setTelTextFieldContent("");
			else
				setTelTextFieldContent(selectedEmployer.getTel().get(0));
			setDescriptionTextAreaContent(selectedEmployer.getDescription());
			
		}
		
		for(int i = 2; i < this.getComponentCount(); i += 3) {
			if(getComponent(i - 1) instanceof RecordTextField)
				((RecordTextField)this.getComponent(i - 1)).setEditable(false);
			else if(getComponent(i - 1) instanceof TextArea)
				((TextArea)getComponent(i - 1)).setEditable(false);
			
			((JButton)this.getComponent(i)).setIcon(new ImageIcon("src\\icon\\text_edit.png"));
		}
		
		
	}
```