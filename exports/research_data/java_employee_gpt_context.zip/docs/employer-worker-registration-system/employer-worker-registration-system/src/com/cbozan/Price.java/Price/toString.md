`toString`: The function of `toString` is to return a string representation of the price, including its full-time, halftime, and overtime values.

**Code Description**: This code defines a method `toString` in the `Price` class that returns a formatted string containing the full-time, halftime, and overtime prices. The method calls the `getFulltime`, `getHalftime`, and `getOvertime` methods to retrieve these values, which are then concatenated into a single string with parentheses around each price value. This allows for easy display of the price components in a human-readable format.\\
## Code: 
```
String toString() {
		return "(" + getFulltime() + ")  " + "(" + getHalftime() + ")  " + "(" + getOvertime() + ")";
	}
```