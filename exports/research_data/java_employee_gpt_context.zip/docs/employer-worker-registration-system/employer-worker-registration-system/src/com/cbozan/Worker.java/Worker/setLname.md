`setLname`: The function of `setLname` is to set the last name of a worker.

**Parameters**:
`String lname`: This parameter represents the new last name for the worker, which will be validated and stored in the `lname` field of the worker object.

**Code Description**: 
The `setLname` method takes a string parameter `lname` and checks if it is empty or exceeds the maximum allowed length defined by `DBConst.LNAME_LENGTH`. If either condition is true, an `EntityException` is thrown with a message indicating that the last name is empty or too long. Otherwise, the provided `lname` is assigned to the `lname` field of the worker object.\\
## Code: 
```
void setLname(String lname) throws EntityException {
		if(lname.length() == 0 || lname.length() > DBConst.LNAME_LENGTH)
			throw new EntityException("Worker last name empty or too long");
		this.lname = lname;
	}
```