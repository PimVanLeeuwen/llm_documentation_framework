`resultViewPanel`: The function of `resultViewPanel` is to display a list of search results in a GUI panel, filtered by the user's input.

**Code Description**: This method retrieves the user's search text, clears any existing search results, and iterates through a list of objects to find matches. It then creates a new JTextField for each matching object, adds it to the panel, and sets its properties (color, font, etc.). The panel is resized to fit the number of search results and made visible. When a result is clicked, it triggers an action based on the selected item in the search result list.\\
## Code: 
```
void resultViewPanel() {
		
		String searchText = getText().trim().toUpperCase();
		getPanel().removeAll();
		getSearchResultList().clear();
		
		for(Object obj : getObjectList()) {
			if(obj.toString().contains(searchText)) {
				getSearchResultList().add(obj);
				if(getSearchResultList().size() >= 10) {
					break;
				}
				
			}
			
		}
		
		int i = 0;
		for(Object searchResultObj : getSearchResultList()) {
			
			JTextField tf = new JTextField(searchResultObj.toString());
			tf.setForeground(new Color(105, 35, 64));
			tf.setName(i + "");
			tf.setHorizontalAlignment(SwingConstants.CENTER);
			tf.setEditable(false);
			tf.setBackground(new Color(162, 208, 215));
			tf.setBorder(new LineBorder(new Color(202, 228, 232)));
			tf.setBounds(0, i * (getResultBoxSize().height + 1) + i, getResultBoxSize().width, getResultBoxSize().height);
			tf.addMouseListener(new MouseAdapter() {
				public void mouseExited(MouseEvent e) {
					tf.setBackground(getExitedColor());
					isEntered = false;
				}
				
				public void mouseEntered(MouseEvent e) {
					tf.setBackground(getEnteredColor());
					isEntered = true;
				}
				
				public void mouseClicked(MouseEvent e) {
					mouseAction(e, searchResultList.get(Integer.parseInt(tf.getName())), Integer.parseInt(tf.getName()));
					//selectedWorkerDefaultListModel.addElement(searchResultList.get(Integer.parseInt(tf.getName())));
					//workerList.remove(searchResultList.get(Integer.parseInt(tf.getName())));
					getPanel().setVisible(false);
					//selectedInfoCountLabel.setText(selectedWorkerDefaultListModel.size() + " kişi");
				}
			});
			
			getPanel().add(tf);
			
			++i;
		}
		
		getPanel().setSize(getPanel().getWidth(), getSearchResultList().size() * (getResultBoxSize().height + 2));
		getPanel().setVisible(true);
		getPanel().revalidate();
		getPanel().repaint();
		
		
	}
```