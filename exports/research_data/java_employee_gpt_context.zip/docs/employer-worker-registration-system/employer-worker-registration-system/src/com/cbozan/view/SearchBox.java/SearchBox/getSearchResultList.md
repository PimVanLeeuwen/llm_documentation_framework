`getSearchResultList`: The function of `getSearchResultList` is to return the list of search results.

**Code Description**: This method, `getSearchResultList`, appears to be a getter method that retrieves and returns the `searchResultList`. It does not perform any complex operations or calculations but simply provides access to the existing list of search results. The method takes no parameters and is likely used in conjunction with other methods to display or utilize the search results within the application.\\
## Code: 
```
List<Object> getSearchResultList(){
		return searchResultList;
	}
```