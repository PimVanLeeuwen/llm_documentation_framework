`notifyAllObservers`: The function of `notifyAllObservers` is to notify all registered observers that an update has occurred, allowing them to refresh their UI components.

**Code Description**: This method iterates through a list of registered observers and calls the `update()` method on each one, triggering an update in their respective UI components.\\
## Code: 
```
void notifyAllObservers() {
		for(Observer observer : observers) {
			observer.update();
		}
	}
```