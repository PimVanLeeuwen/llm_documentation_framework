## Expected output
`mouseAction`: The function of `mouseAction` is to handle mouse actions on the Worker Payment Panel.
**Parameters**:\
`MouseEvent e`: This parameter represents a mouse event, such as a click or hover action.
`Object searchResultObject`: This parameter holds an object representing the result of a search, likely containing information about a job.
`int chooseIndex`: This parameter indicates the index of the chosen item in a list.

**Code Description**: The `mouseAction` method updates the selected job and text fields with the search result object's string representation. It also sets the job search box as non-editable and refreshes the data.\\
## Code: 
```
void mouseAction(MouseEvent e, Object searchResultObject, int chooseIndex) {
				selectedJob = (Job) searchResultObject;
				jobSearchBox.setText(searchResultObject.toString());
				jobTextField.setText(searchResultObject.toString());
				jobSearchBox.setEditable(false);
				refreshData();
				super.mouseAction(e, searchResultObject, chooseIndex);
			}
```