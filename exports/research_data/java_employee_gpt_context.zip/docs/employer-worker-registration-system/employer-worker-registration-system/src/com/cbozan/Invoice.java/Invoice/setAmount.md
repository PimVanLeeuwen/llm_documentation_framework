`setAmount`: The function of `setAmount` is to set the amount of an invoice.

**Parameters**:\
`BigDecimal amount`: This parameter represents the new amount to be set for the invoice, which must be a positive value greater than zero.

**Code Description**: 
The `setAmount` method takes a `BigDecimal` object as input and checks if it's less than or equal to zero. If true, it throws an `EntityException` with a message indicating that the invoice amount is negative or zero. Otherwise, it sets the `amount` field of the current invoice object to the provided value.\\
## Code: 
```
void setAmount(BigDecimal amount) throws EntityException {
		if(amount.compareTo(new BigDecimal("0.00")) <= 0)
			throw new EntityException("Invoice amount negative or zero");
		this.amount = amount;
	}
```