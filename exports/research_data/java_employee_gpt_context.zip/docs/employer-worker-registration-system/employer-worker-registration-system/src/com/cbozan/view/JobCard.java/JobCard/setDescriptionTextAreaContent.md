`setDescriptionTextAreaContent`: This method sets the content of a text area with the given description and updates the selected job's description if it exists.
**Parameters**: A string representing the new description to be set in the text area.
**Code Description**: The method first updates the text area's content with the provided description. If a job has been previously selected, its description is also updated with the same value.\\
## Code: 
```
void setDescriptionTextAreaContent(String description) {
		this.descriptionTextArea.setText(description);
		
		if(getSelectedJob() != null)
			getSelectedJob().setDescription(description);
	}
```