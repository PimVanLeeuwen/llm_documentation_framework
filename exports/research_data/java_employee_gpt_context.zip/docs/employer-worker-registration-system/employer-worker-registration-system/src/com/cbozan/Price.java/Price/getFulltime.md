## getFulltime: 
The function of `getFulltime` is to return the full-time value.

## Code Description:
The `getFulltime` method in the `Price.java` class returns the full-time value, which is stored in the `fulltime` variable. This suggests that the `fulltime` variable holds a numerical representation of the full-time price or rate, and this method allows other parts of the program to access and utilize this value.\\
## Code: 
```
BigDecimal getFulltime() {
		return fulltime;
	}
```