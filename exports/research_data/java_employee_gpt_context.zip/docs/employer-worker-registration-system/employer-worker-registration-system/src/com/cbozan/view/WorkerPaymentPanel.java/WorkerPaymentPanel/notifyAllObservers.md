`notifyAllObservers`: The function of `notifyAllObservers` is to notify all registered observers that an update has occurred, triggering them to refresh their views.

**Code Description**: This method iterates through a list of registered observers and calls the `update()` method on each one, effectively notifying them of any changes or updates.\\
## Code: 
```
void notifyAllObservers() {
		for(Observer observer : observers) {
			observer.update();
		}
	}
```