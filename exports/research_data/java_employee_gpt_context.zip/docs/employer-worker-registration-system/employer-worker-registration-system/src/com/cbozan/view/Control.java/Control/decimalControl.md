**The function of decimalControl is to validate a list of strings against a given regular expression pattern.**

**Parameters:**
- `Pattern pattern`: This parameter represents the regular expression pattern used for validation.
 
**Code Description:** The `decimalControl` method iterates over each string in the provided array and checks if it matches the specified pattern using the `find()` method of the `Matcher` class. If any string does not match the pattern, the method returns `false`, indicating that at least one input is invalid. Otherwise, it returns `true`, signifying that all inputs are valid according to the given pattern.\\
## Code: 
```
boolean decimalControl(Pattern pattern, String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= pattern.matcher(arg).find();
		}
		return rValue;
	}
```