`setLname`: The function of `setLname` is to set the last name of an employer.

**Parameters**: 
`String lname`: This parameter represents the new last name that will be assigned to the employer.

**Code Description**: 
The `setLname` method checks if the provided last name is not empty and does not exceed a certain length (defined by `DBConst.LNAME_LENGTH`). If these conditions are met, it assigns the provided last name to the employer's `lname` field. Otherwise, it throws an `EntityException` with a message indicating that the last name is either empty or too long.\\
## Code: 
```
void setLname(String lname) throws EntityException {
		if(lname.length() == 0 || lname.length() > DBConst.LNAME_LENGTH)
			throw new EntityException("Employer last name empty or too long");
		this.lname = lname;
	}
```