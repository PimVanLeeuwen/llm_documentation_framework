## Expected output
`mouseAction`: The function of `mouseAction` is to update the selected object when a mouse action occurs.
**Parameters**:
`MouseEvent e`: This parameter represents an event triggered by a mouse interaction, such as a click or hover.
`Object searchResultObject`: This parameter holds the result of a search operation, which will be updated as the new selected object.
`int chooseIndex`: This parameter indicates the index of the chosen item in the search results list.

**Code Description**: The `mouseAction` method is triggered by a mouse event and updates the `selectedObject` variable with the new search result object based on the chosen index.\\
## Code: 
```
void mouseAction(MouseEvent e, Object searchResultObject, int chooseIndex) {
		selectedObject = searchResultObject;
	}
```