`update`: The function of `update` is to refresh and update the display with the latest data for a selected employer, including job and payment information.

**Code Description**: This code updates the EmployerDisplay view by refreshing the data from various DAO (Data Access Object) instances. It retrieves the list of employers from the EmployerDAO, selects the currently chosen employer, and updates the search box text accordingly. Additionally, it refreshes the JobDAO and InvoiceDAO instances to ensure that the job and payment tables are updated with the latest information. The updateJobTableData and updateEmployerPaymentTableData methods are called to populate these tables with the retrieved data. Finally, the EmployerCard is reloaded to reflect any changes in the employer's details.\\
## Code: 
```
void update() {
		employerSearchBox.setObjectList(EmployerDAO.getInstance().list());
		selectedEmployer = employerCard.getSelectedEmployer();
		employerSearchBox.setText(selectedEmployer == null ? "" : selectedEmployer.toString());
		JobDAO.getInstance().refresh();
		InvoiceDAO.getInstance().refresh();
		updateJobTableData();
		updateEmployerPaymentTableData();
		employerCard.reload();
	}
```