`setFname`: The function of `setFname` is to set the first name of an employer.

**Parameters**: 
`String fname`: This parameter represents the new first name that will be assigned to the employer.

**Code Description**: 
The `setFname` method checks if the provided first name (`fname`) meets certain conditions. If it's empty (i.e., has a length of 0) or exceeds the maximum allowed length specified by `DBConst.FNAME_LENGTH`, an `EntityException` is thrown with a message indicating that the employer name is either empty or too long. Otherwise, the provided first name is assigned to the `fname` field of the current employer object.\\
## Code: 
```
void setFname(String fname) throws EntityException {
		if(fname.length() == 0 || fname.length() > DBConst.FNAME_LENGTH)
			throw new EntityException("Employer name empty or too long");
		this.fname = fname;
	}
```