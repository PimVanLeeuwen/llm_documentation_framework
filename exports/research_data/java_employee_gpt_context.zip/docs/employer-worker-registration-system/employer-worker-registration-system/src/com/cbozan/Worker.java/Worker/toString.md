**toString**: The function of `toString` is to return a string representation of the worker's name, which includes their first and last names.

**Code Description**: The `toString` method in the Worker class returns a concatenated string containing the first name and last name of the worker. It calls the `getFname()` and `getLname()` methods to retrieve these values from pre-existing string variables named `fname` and `lname`, respectively, and then appends them together with a space separator.\\
## Code: 
```
String toString() {
		return " " + getFname() + " " + getLname();
	}
```