**PriceBuilder**: The function of `PriceBuilder` is to create a `Price` object by setting its properties and then building it.

**Code Description**: 
The `PriceBuilder` class is used to construct a `Price` object in a step-by-step manner. It allows for the setting of various price-related attributes such as ID, full-time, half-time, overtime, and date. The builder pattern is employed here, enabling a fluent API where each method call returns the same builder instance, allowing for chaining multiple operations together. Once all desired properties are set, the `build()` method can be called to create a fully initialized `Price` object.\\
## Code: 
```
class PriceBuilder{
		
		private int id;
		private BigDecimal fulltime;
		private BigDecimal halftime;
		private BigDecimal overtime;
		private Timestamp date;
		
		public PriceBuilder() {}

		public PriceBuilder(int id, BigDecimal fulltime, BigDecimal halftime, BigDecimal overtime, Timestamp date) {
			super();
			this.id = id;
			this.fulltime = fulltime;
			this.halftime = halftime;
			this.overtime = overtime;
			this.date = date;
		}

		public PriceBuilder setId(int id) {
			this.id = id;
			return this;
		}

		public PriceBuilder setFulltime(BigDecimal fulltime) {
			this.fulltime = fulltime;
			return this;
		}

		public PriceBuilder setHalftime(BigDecimal halftime) {
			this.halftime = halftime;
			return this;
		}

		public PriceBuilder setOvertime(BigDecimal overtime) {
			this.overtime = overtime;
			return this;
		}

		public PriceBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Price build() throws EntityException{
			return new Price(this);
		}
		
	}
```