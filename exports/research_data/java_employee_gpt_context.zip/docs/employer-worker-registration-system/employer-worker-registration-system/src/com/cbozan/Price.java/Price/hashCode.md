`hashCode`: The function of `hashCode` is to return a unique hash code for an object, which can be used in data structures such as sets and maps.

**Code Description**: This method implements the hashCode() method from the Objects class, which returns a hash code based on the values of the specified variables (date, fulltime, halftime, id, overtime). The hash code is calculated by combining the hash codes of these variables using the hash function.\\
## Code: 
```
int hashCode() {
		return Objects.hash(date, fulltime, halftime, id, overtime);
	}
```