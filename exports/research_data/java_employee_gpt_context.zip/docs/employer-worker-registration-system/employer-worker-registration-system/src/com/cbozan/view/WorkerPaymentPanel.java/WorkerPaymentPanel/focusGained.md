`focusGained`: The function of `focusGained` is to change the border and foreground color of a JTextField when it gains focus.

**Parameters**: 
`FocusEvent e`: This parameter represents an event that occurs when a component, in this case a JTextField, gains focus. 

**Code Description**: When the `focusGained` method is called due to a FocusEvent, it checks if the source of the event is an instance of JTextField. If so, it sets a blue border around the JTextField and changes the foreground color of another JLabel (amountLabel) to blue if the JTextField being focused is the amountTextField.\\
## Code: 
```
void focusGained(FocusEvent e) {
		if(e.getSource() instanceof JTextField) {
			
			((JTextField)e.getSource()).setBorder(new LineBorder(Color.blue));
			
			if(((JTextField)e.getSource()) == amountTextField) {
				amountLabel.setForeground(Color.blue);
			}
			
		}
		
	}
```