`setOvertime`: The function of `setOvertime` is to set the overtime price for a worker.

**Parameters**:
`BigDecimal overtime`: This parameter represents the overtime price that needs to be set, which should be a non-negative value greater than zero.

**Code Description**: 
The `setOvertime` method checks if the provided overtime price is valid (i.e., not null and greater than zero). If it's invalid, an `EntityException` is thrown with a message indicating that the overtime price cannot be negative or null. Otherwise, the method sets the overtime price for the worker to the provided value.\\
## Code: 
```
void setOvertime(BigDecimal overtime) throws EntityException {
		if(overtime == null || overtime.compareTo(new BigDecimal("0.00")) <= 0)
			throw new EntityException("Price overtime negative or null or zero");
		this.overtime = overtime;
	}
```