`subscribe`: The function of `subscribe` is to add a new observer to the list of observers.
**Parameters**: Observer observer: This parameter represents an object that wants to be notified when something happens in the system, and will receive updates from the system.
**Code Description**: The subscribe method adds the provided observer to the list of observers.\\
## Code: 
```
void subscribe(Observer observer) {
		observers.add(observer);
	}
```