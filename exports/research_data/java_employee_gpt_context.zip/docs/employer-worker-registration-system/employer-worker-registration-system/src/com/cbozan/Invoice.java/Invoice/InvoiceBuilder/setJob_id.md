`setJob_id`: The function of `setJob_id` is to set the job ID of an invoice.

**Parameters**:
`int job_id`: This parameter represents the job ID that will be assigned to the invoice. It is an integer value.

**Code Description**: 
The `setJob_id` method is a part of the `InvoiceBuilder` class, which is used to build and configure an `Invoice` object. The method takes an `int` parameter `job_id`, assigns it to the `job_id` field of the current `InvoiceBuilder` instance, and returns the same instance for method chaining purposes. This allows multiple settings to be made in a single statement, making the code more concise and readable.\\
## Code: 
```
InvoiceBuilder setJob_id(int job_id) {
			this.job_id = job_id;
			return this;
		}
```