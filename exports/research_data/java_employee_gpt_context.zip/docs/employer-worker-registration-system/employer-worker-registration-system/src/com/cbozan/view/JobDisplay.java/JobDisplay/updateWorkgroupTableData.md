`updateWorkgroupTableData`: The function of `updateWorkgroupTableData` is to update the table data in the job work scroll pane with the list of workgroups associated with a selected job.

**Code Description**: This method retrieves a list of workgroups from the database using the WorkgroupDAO instance, and then populates a 2D array with the details of each workgroup. The table data is updated with this information, including the workgroup ID, job name, work type, work count, description, and date. Additionally, the total count of daily wages and the number of records are displayed in labels below the table.\\
## Code: 
```
void updateWorkgroupTableData() {
		
		if(selectedJob != null) {
			
			List<Workgroup> workgroupList = WorkgroupDAO.getInstance().list(selectedJob);
			
			String[][] tableData = new String[workgroupList.size()][jobWorkTableColumns.length];
			
			int i = 0;
			int totalCount = 0;
			for(Workgroup w : workgroupList) {
				
				tableData[i][0] = w.getId() + "";
				tableData[i][1] = w.getJob().toString();
				tableData[i][2] = w.getWorktype().toString();
				tableData[i][3] = w.getWorkCount() + "";
				tableData[i][4] = w.getDescription();
				tableData[i][5] = new SimpleDateFormat("dd.MM.yyyy").format(w.getDate());
				
				totalCount += w.getWorkCount();
				++i;	
			}
			
			((JTable)jobWorkScrollPane.getViewport().getComponent(0)).setModel(new DefaultTableModel(tableData, jobWorkTableColumns));
			((JTable)jobWorkScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setPreferredWidth(5);
			((JTable)jobWorkScrollPane.getViewport().getComponent(0)).setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
			
			DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
			centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
			((JTable)jobWorkScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
			((JTable)jobWorkScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
			((JTable)jobWorkScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(5).setCellRenderer(centerRenderer);
			
			//jobWorkCount 
			jobWorkTotalCountLabel.setText(totalCount + " daily wages");
			jobWorkCountLabel.setText(workgroupList.size() + " Record");
		}
		
	}
```