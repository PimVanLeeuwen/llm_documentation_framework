`build`: The function of `build` is to create a new instance of the Price class, initialized with the data from the current builder object.

**Code Description**: 
The `build` method in the `PriceBuilder` class creates and returns a new `Price` object. It takes no arguments and throws an `EntityException`. The method initializes a new `Price` object using the data stored in the current builder object, effectively creating a new instance of the `Price` class with the specified attributes.\\
## Code: 
```
Price build() throws EntityException{
			return new Price(this);
		}
```