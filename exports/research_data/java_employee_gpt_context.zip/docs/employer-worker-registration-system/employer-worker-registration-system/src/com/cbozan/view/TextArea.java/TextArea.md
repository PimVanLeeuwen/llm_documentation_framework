**TextArea**: The function of `TextArea` is to provide a customizable text area component that can be used in a graphical user interface (GUI) system.

**Code Description**: The `TextArea` class extends the `JScrollPane` class and implements the `FocusListener` interface. It provides methods for getting and setting the text, enabling or disabling editing, and handling focus gained and lost events. When the text area gains focus, it changes its border color to blue; when it loses focus, it resets the border color to white.\\
## Code: 
```
class TextArea extends JScrollPane implements FocusListener{

	private static final long serialVersionUID = 8546529312909157181L;
	JTextArea text;
	
	public TextArea() {
		text = new JTextArea();
		setViewportView(text);
		text.addFocusListener(this);
		this.addFocusListener(this);
	}
	
	public String getText(){
		return text.getText();
	}
	
	public void setText(String strText) {
		text.setText(strText);
	}
	
	public boolean isEditable() {
		return text.isEditable();
	}
	
	public void setEditable(boolean bool) {
		text.setEditable(bool);
	}
	
	@Override
	public void focusGained(FocusEvent e) {
		text.setBorder(new LineBorder(Color.BLUE));
		
	}

	@Override
	public void focusLost(FocusEvent e) {
		text.setBorder(new LineBorder(Color.WHITE));
	}
	
	

}
```