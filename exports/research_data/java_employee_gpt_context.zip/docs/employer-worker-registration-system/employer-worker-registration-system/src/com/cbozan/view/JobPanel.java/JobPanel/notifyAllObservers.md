`notifyAllObservers`: The function of `notifyAllObservers` is to notify all registered observers that new data is available and update them accordingly.

**Code Description**: This method iterates through a list of observers, calls the update method on each observer, effectively notifying them of any changes or updates.\\
## Code: 
```
void notifyAllObservers() {
		for(Observer observer : observers) {
			observer.update();
		}
	}
```