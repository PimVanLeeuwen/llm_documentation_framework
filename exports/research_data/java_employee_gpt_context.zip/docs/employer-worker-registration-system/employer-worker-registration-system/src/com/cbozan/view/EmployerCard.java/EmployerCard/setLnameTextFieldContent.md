`setLnameTextFieldContent`: The function of `setLnameTextFieldContent` is to update the text content of a text field with the last name and also update the last name of the selected employer.

**Parameters**: 
`String lnameTextFieldContent`: This parameter represents the new last name to be updated in the text field and the selected employer's record.

**Code Description**: The `setLnameTextFieldContent` method updates the text content of a text field with the provided last name. It also attempts to update the last name of the currently selected employer, if available, by calling the `getSelectedEmployer` method to retrieve the selected employer and then invoking the `setLname` method on it. If an exception occurs during this process, it is caught and printed to the console.\\
## Code: 
```
void setLnameTextFieldContent(String lnameTextFieldContent) {
		this.lnameTextField.setText(lnameTextFieldContent);
		try {
			if(getSelectedEmployer() != null)
				getSelectedEmployer().setLname(lnameTextFieldContent);
		} catch (EntityException e) {
			e.printStackTrace();
		}
	}
```