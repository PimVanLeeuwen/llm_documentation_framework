## Expected output
`mouseAction`: The function of `mouseAction` is to handle mouse actions on a job card.
**Parameters**:\
`MouseEvent e`: This parameter represents the mouse event that triggered the action.
`Object searchResultObject`: This object contains the result of a search, likely used to update the job's price.
`int chooseIndex`: This integer represents the index of the chosen item in a list or dropdown.

**Code Description**: The `mouseAction` method is called when a mouse event occurs on a job card. It checks if a job is already selected and updates its price using the search result object. If a price is selected from a dropdown, it also updates the text field with the selected price. Finally, it calls the superclass's `mouseAction` method to handle any additional actions.\\
## Code: 
```
void mouseAction(MouseEvent e, Object searchResultObject, int chooseIndex) {
				if(selectedJob != null) {
					try {
						selectedJob.setPrice((Price)searchResultObject);
						if(priceSearchBox.getSelectedObject() != null)
							priceSearchBox.setText(priceSearchBox.getSelectedObject().toString());
					} catch (EntityException e1) {
						e1.printStackTrace();
					}
				}
				super.mouseAction(e, searchResultObject, chooseIndex);
			}
```