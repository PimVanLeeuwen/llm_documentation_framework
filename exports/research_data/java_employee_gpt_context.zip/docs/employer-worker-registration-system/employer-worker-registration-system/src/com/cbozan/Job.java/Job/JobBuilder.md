**JobBuilder**: The function of `JobBuilder` is to create a builder object that allows for the step-by-step construction of a Job object.

**Code Description**: The `JobBuilder` class provides a fluent API for building a Job object by setting its properties (id, employer_id, price_id, title, description, date, employer, and price) in a chainable manner. It ensures that all required properties are set before creating the final Job object to prevent incomplete or invalid data from being used.\\
## Code: 
```
class JobBuilder {
		
		private int id;
		private int employer_id;
		private int price_id;
		private String title;
		private String description;
		private Timestamp date;
		private Employer employer;
		private Price price;
		
		public JobBuilder() {}
		public JobBuilder(int id, int employer_id, int price_id, String title, String description, Timestamp date) {
			this.id = id;
			this.employer_id = employer_id;
			this.price_id = price_id;
			this.title = title;
			this.description = description;
			this.date = date;
		}
		
		public JobBuilder(int id, Employer employer, Price price, String title, String description, Timestamp date) {
			this(id, 0, 0, title, description, date);
			this.employer = employer;
			this.price = price;
		}
		
		public JobBuilder setId(int id) {
			this.id = id;
			return this;
		}
		
		public JobBuilder setEmployer_id(int employer_id) {
			this.employer_id = employer_id;
			return this;
		}
		
		public JobBuilder setPrice_id(int price_id) {
			this.price_id = price_id;
			return this;
		}
		
		public JobBuilder setTitle(String title) {
			this.title = title;
			return this;
		}
		
		public JobBuilder setDescription(String description) {
			this.description = description;
			return this;
		}
		
		public JobBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public JobBuilder setEmployer(Employer employer) {
			this.employer = employer;
			return this;
		}
		
		public JobBuilder setPrice(Price price) {
			this.price = price;
			return this;
		}
		
		public Job build() throws EntityException{
			if(this.employer == null || this.price == null)
				return new Job(this);
			return new Job(this.id, this.employer, this.price, this.title, this.description, this.date);
		}
		
	}
```