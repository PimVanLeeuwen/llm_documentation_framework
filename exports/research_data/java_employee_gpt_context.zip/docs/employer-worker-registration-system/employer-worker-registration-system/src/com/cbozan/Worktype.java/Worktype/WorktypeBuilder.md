**WorktypeBuilder**: The function of `WorktypeBuilder` is to create a builder object that can be used to construct a `Worktype` object in a step-by-step manner.

**Code Description**: This class provides a fluent API for building a `Worktype` object. It allows users to set the id, title, number, and date of the work type one by one, and finally build the complete `Worktype` object using the `build()` method.\\
## Code: 
```
class WorktypeBuilder {
		private int id;
		private String title;
		private int no;
		private Timestamp date;
		
		public WorktypeBuilder() {}
		public WorktypeBuilder(int id, String title, int no, Timestamp date) {
			this.id = id;
			this.title = title;
			this.no = no;
			this.date = date;
		}
		
		public WorktypeBuilder setId(int id) {
			this.id = id;
			return this;
		}
		
		public WorktypeBuilder setTitle(String title) {
			this.title = title;
			return this;
		}
		
		public WorktypeBuilder setNo(int no) {
			this.no = no;
			return this;
		}
		
		public WorktypeBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Worktype build() throws EntityException {
			return new Worktype(this);
		}
		
	}
```