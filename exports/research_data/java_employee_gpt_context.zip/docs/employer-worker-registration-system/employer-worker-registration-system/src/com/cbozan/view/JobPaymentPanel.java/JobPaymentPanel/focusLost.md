`focusLost`: The function of `focusLost` is to change the border color and foreground color of a JTextField based on whether its text represents a decimal number or not.

**Parameters**: 
`FocusEvent e`: This method takes a FocusEvent object as a parameter, which indicates that it is triggered when the focus is lost by a component.

**Code Description**: The `focusLost` method checks if the source of the event is an instance of JTextField. If so, it changes the border color and foreground color of the JTextField based on whether its text represents a decimal number or not. It uses the `decimalControl` method to check for decimal numbers. If the text is a decimal number, it sets the border color to green; otherwise, it sets it to red. Additionally, if the JTextField is the "amountTextField", it also changes the foreground color of the corresponding label to match the border color.\\
## Code: 
```
void focusLost(FocusEvent e) {
		if(e.getSource() instanceof JTextField) {
			
			Color color = Color.white;
			
			if(decimalControl(((JTextField)e.getSource()).getText())) {
				color = new Color(0, 180, 0);
			} else {
				color = Color.red;
			}
			
			((JTextField)e.getSource()).setBorder(new LineBorder(color));
		
			if(((JTextField)e.getSource()) == amountTextField) {
				amountLabel.setForeground(color);
			}
		}
	}
```