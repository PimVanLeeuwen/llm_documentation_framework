The function of `GUI` is to create a graphical user interface (GUI) for an employer registration system, allowing users to input their name, surname, phone number, and description.

**Code Description**: The code defines a method called `GUI` which creates various GUI components such as labels, text fields, and buttons. It adds these components to the panel, setting their positions, sizes, and other properties. The method also sets up event listeners for some of the components, such as text fields, to perform specific actions when certain events occur (e.g., when a text field is filled or an action is performed).\\
## Code: 
```
void GUI() {
		
		imageLabel = new JLabel();
		imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
		imageLabel.setIcon(new ImageIcon("src\\icon\\new_employer.png"));
		imageLabel.setBounds(LX + 155, 40, 128, 130);
		add(imageLabel);

		fnameLabel = new JLabel("Name");
		fnameLabel.setBounds(LX, LY, LW, LH);
		add(fnameLabel);
		
		fnameTextField = new RecordTextField(RecordTextField.REQUIRED_TEXT);
		fnameTextField.setBounds(fnameLabel.getX() + LW + LHS, fnameLabel.getY(), TW, TH);
		fnameTextField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!fnameTextField.getText().replaceAll("\\s+", "").equals("")) {
					lnameTextField.requestFocus();
				}
			}
		});
		add(fnameTextField);
		
		
		lnameLabel = new JLabel("Surname");
		lnameLabel.setBounds(fnameLabel.getX(), fnameLabel.getY() + LVS, LW, LH);
		add(lnameLabel);
		
		lnameTextField = new RecordTextField(RecordTextField.REQUIRED_TEXT);
		lnameTextField.setBounds(lnameLabel.getX() + LW + LHS, lnameLabel.getY(), TW, TH);
		lnameTextField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!lnameTextField.getText().replaceAll("\\s+", "").equals("")) {
					phoneNumberTextField.requestFocus();
				}
			}
		});
		add(lnameTextField);
		
		
		phoneNumberLabel = new JLabel("Phone Nu.");
		phoneNumberLabel.setBounds(lnameLabel.getX(), lnameLabel.getY() + LVS, LW, LH);
		add(phoneNumberLabel);
		
		phoneNumberTextField= new RecordTextField(RecordTextField.PHONE_NUMBER_TEXT + RecordTextField.REQUIRED_TEXT);
		phoneNumberTextField.setBounds(phoneNumberLabel.getX() + LW + LHS, phoneNumberLabel.getY(), TW, TH);
		phoneNumberTextField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Control.phoneNumberControl(phoneNumberTextField.getText())) {
					((JTextArea)((JViewport)descriptionScrollPane.getComponent(0)).getComponent(0)).requestFocus();
				}
			}
		});
		add(phoneNumberTextField);
		
		
		descriptionLabel= new JLabel("Description");
		descriptionLabel.setBounds(phoneNumberLabel.getX(), phoneNumberLabel.getY() + LVS, LW, LH);
		add(descriptionLabel);
		
		descriptionScrollPane = new JScrollPane(new JTextArea());
		descriptionScrollPane.setBounds(descriptionLabel.getX() + LW + LHS, descriptionLabel.getY(), TW, TH * 3);
		add(descriptionScrollPane);
		
		saveButton = new JButton("SAVE");
		saveButton.setBounds(descriptionScrollPane.getX() + ((TW - BW) / 2), descriptionScrollPane.getY() + descriptionScrollPane.getHeight() + 20, BW, BH);
		saveButton.setFocusPainted(false);
		saveButton.addActionListener(this);
		add(saveButton);
		
	}
```