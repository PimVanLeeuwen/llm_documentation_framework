**Expected Output**

`PricePanel`: The function of `PricePanel` is to display a panel for users to input and confirm their price details, including full-time, half-time, and overtime prices.

**Code Description**: 
The code describes the functionality of the `PricePanel` class in Java. It defines a graphical user interface (GUI) component that allows users to enter and confirm their price details. The panel consists of three text fields for inputting full-time, half-time, and overtime prices, respectively. When the user clicks the "SAVE" button, the code validates the input data by checking if it conforms to the required format (i.e., decimal numbers with a maximum of two floating-point digits). If the validation fails, an error message is displayed. Otherwise, the code creates a new `Price` object using the input data and attempts to save it to the database using the `PriceDAO` class. If the saving process is successful, a confirmation message is displayed; otherwise, an error message is shown. The panel also includes a "CANCEL" button that allows users to exit without making any changes.

**Analysis**

The code uses a subscription-based system to notify observers when the price details are saved successfully. The `subscribe` method adds an observer to the list of observers, while the `unsubscribe` method removes an observer from the list. The `notifyAllObservers` method notifies all observers in the list by calling their `update` method.

The code also includes a `clearPanel` method that resets the panel's input fields and labels to their default state when the user clicks the "CANCEL" button or when the price details are saved successfully.

Overall, the code provides a simple GUI component for users to input and confirm their price details while ensuring data validation and database saving.\\
## Code: 
```
class PricePanel extends JPanel implements Observer, Serializable, ActionListener{
	
	private static final long serialVersionUID = 1L;

	private final List<Observer> observers;
	
	/**
	 * y position of label
	 */
	private final int LY = 230;
	
	/**
	 * x position of label
	 */
	private final int LX = 450;
	
	/**
	 * width of the Textfield
	 */
	private final int TW = 60;
	
	/**
	 * height of the TextField
	 */
	private final int TH = 25;
	
	/**
	 * width of the label
	 */
	private final int LW = 140;
	
	/**
	 * height of the label
	 */
	private final int LH = 25;
	
	/**
	 * vertical space of the label
	 */
	private final int LVS = 50;
	
	/**
	 * vertical space between label and textfield
	 */
	private final int LTVS = 30;
	
	
	private JLabel imageLabel;
	private JLabel fulltimeLabel, halftimeLabel, overtimeLabel;
	private RecordTextField fulltimeTextField, halftimeTextField, overtimeTextField;
	private JButton saveButton;
	
	private Color defaultColor;
	
	public PricePanel() {
		
		super();
		setLayout(null);
		
		observers = new ArrayList<>();
		subscribe(this);
		
		imageLabel = new JLabel(new ImageIcon("src\\icon\\new_price.png"));
		imageLabel.setBounds(LX + 12, 50, 128, 128);
		this.add(imageLabel);
		
		defaultColor = imageLabel.getForeground();
		
		fulltimeLabel = new JLabel("Fulltime (TL)");
		fulltimeLabel.setBounds(LX, LY + LTVS, LW, LH);
		fulltimeLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		
		fulltimeTextField = new RecordTextField(RecordTextField.DECIMAL_NUMBER_TEXT + RecordTextField.REQUIRED_TEXT);
		fulltimeTextField.setHorizontalAlignment(SwingConstants.CENTER);
		fulltimeTextField.setBounds(LX + (fulltimeLabel.getWidth() / 2) - (TW / 2), LY, TW, TH);
		fulltimeTextField.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(Control.decimalControl(fulltimeTextField.getText())) {
					halftimeTextField.requestFocus();
				}
					
			}
		});
		
		add(fulltimeTextField);
		add(fulltimeLabel);
		
		halftimeLabel = new JLabel("Halftime (TL)");
		halftimeLabel.setBounds(LX, fulltimeLabel.getY() + LVS + LTVS, LW, LH);
		halftimeLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		halftimeTextField = new RecordTextField(RecordTextField.DECIMAL_NUMBER_TEXT + RecordTextField.REQUIRED_TEXT);
		halftimeTextField.setHorizontalAlignment(SwingConstants.CENTER);
		halftimeTextField.setBounds(LX + (halftimeLabel.getWidth() / 2) - (TW / 2), halftimeLabel.getY() - LTVS, TW, TH);
		halftimeTextField.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(Control.decimalControl(halftimeTextField.getText())) {
					overtimeTextField.requestFocus();
				}
			}
		});
		add(halftimeTextField);
		add(halftimeLabel);
		
		overtimeLabel = new JLabel("Overtime (TL)");
		overtimeLabel.setBounds(LX, halftimeLabel.getY() + LVS + LTVS, LW, LH);
		overtimeLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		overtimeTextField = new RecordTextField(RecordTextField.DECIMAL_NUMBER_TEXT + RecordTextField.REQUIRED_TEXT);
		overtimeTextField.setHorizontalAlignment(SwingConstants.CENTER);
		overtimeTextField.setBounds(LX + (overtimeLabel.getWidth() / 2) - (TW / 2), overtimeLabel.getY() - LTVS, TW, TH);
		overtimeTextField.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(Control.decimalControl(halftimeTextField.getText())) {
					saveButton.doClick();
				}
			}
		});
		add(overtimeTextField);
		add(overtimeLabel);
		
		saveButton = new JButton("SAVE");
		saveButton.setBounds(overtimeLabel.getX() - 70, overtimeLabel.getY() + 50, overtimeLabel.getWidth() + 120, 30);
		//save_button.setContentAreaFilled(false);
		saveButton.setFocusPainted(false);
		saveButton.addActionListener(this);
		add(saveButton);
		
	}

		
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == saveButton) {
			
			String fulltime, halftime, overtime;
			
			fulltime = fulltimeTextField.getText().replaceAll("\\s+", "");
			halftime = halftimeTextField.getText().replaceAll("\\s+", "");
			overtime = overtimeTextField.getText().replaceAll("\\s+", "");
			
			if(!Control.decimalControl(fulltime, halftime, overtime)) {
				
				String message = "Please fill in the required fields or enter correctly format (max 2 floatpoint)";
				JOptionPane.showMessageDialog(this, message, "ERROR", JOptionPane.ERROR_MESSAGE);
				
			} else {
				
				JTextArea fulltimeTextArea, halftimeTextArea, overtimeTextArea;
				
				fulltimeTextArea = new JTextArea(fulltime + " ₺");
				fulltimeTextArea.setEditable(false);
				
				halftimeTextArea = new JTextArea(halftime + " ₺");
				halftimeTextArea.setEditable(false);
				
				overtimeTextArea = new JTextArea(overtime + " ₺");
				overtimeTextArea.setEditable(false);
				
				Object[] pane = {
						new JLabel("Fulltime Price"),
						fulltimeTextArea,
						new JLabel("Halftime Price"),
						halftimeTextArea,
						new JLabel("Overtime Price"),
						overtimeTextArea
				};
				
				
		
				int result = JOptionPane.showOptionDialog(this, pane, "Confirmation", 1, 1, 
						new ImageIcon("src\\icon\\accounting_icon_1_32.png"), new Object[] {"SAVE", "CANCEL"}, "CANCEL");
				
				
				// System.out.println(result);
				// 0 -> SAVE
				// 1 -> CANCEL
				
				if(result == 0) {
					
					Price.PriceBuilder builder = new Price.PriceBuilder();
					builder.setId(Integer.MAX_VALUE);
					builder.setFulltime(new BigDecimal(fulltime));
					builder.setHalftime(new BigDecimal(halftime));
					builder.setOvertime(new BigDecimal(overtime));
					
					Price price = null;
					try {
						price = builder.build();
					} catch (EntityException e1) {
						System.out.println(e1.getMessage());
					}
					
					if(PriceDAO.getInstance().create(price)) { 
						JOptionPane.showMessageDialog(this, "Registration Successful");
						notifyAllObservers();
					} else {
						JOptionPane.showMessageDialog(this, "Not saved", "DataBase error", JOptionPane.ERROR_MESSAGE);
					}
				}
				
			}
			
			
		}
		
	}
	
	private void clearPanel() {
		
		fulltimeTextField.setText("");
		halftimeTextField.setText("");
		overtimeTextField.setText("");
		
		fulltimeTextField.setBorder(new LineBorder(Color.white));
		halftimeTextField.setBorder(new LineBorder(Color.white));
		overtimeTextField.setBorder(new LineBorder(Color.white));
		
		fulltimeLabel.setForeground(defaultColor);
		halftimeLabel.setForeground(defaultColor);
		overtimeLabel.setForeground(defaultColor);
		
	}
	
	public void subscribe(Observer observer) {
		observers.add(observer);
	}
	
	public void unsubscribe(Observer observer) {
		observers.remove(observer);
	}
	
	public void notifyAllObservers() {
		for(Observer observer : observers) {
			observer.update();
		}
	}

	@Override
	public void update() {
		clearPanel();
	}

}
```