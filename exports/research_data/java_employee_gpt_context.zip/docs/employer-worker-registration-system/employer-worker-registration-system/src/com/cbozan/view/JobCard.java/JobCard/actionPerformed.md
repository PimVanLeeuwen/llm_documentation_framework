`actionPerformed`: When the update button is clicked and a job is selected, this method updates the job details in the system.

**Parameters**: `ActionEvent e`: The event that triggered the action, specifically when the update button is clicked.

**Code Description**: This method retrieves the current text from the title text field and description text area, updates the corresponding job object if one is selected, and then attempts to save these changes to the database using the JobDAO instance. If the update is successful, it displays a success message; otherwise, it displays an error message. Additionally, it notifies any observers that the job has been updated.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == updateButton && selectedJob != null) {
			
			setTitleTextFieldContent(getTitleTextFieldContent());
			setDescriptionTextAreaContent(getDescriptionTextAreaContent());
			
			
			if(true == JobDAO.getInstance().update(selectedJob)) {
				JOptionPane.showMessageDialog(this, "Update successful", "SUCCESSFUL", JOptionPane.INFORMATION_MESSAGE);
				
				Component component = getParent();
				while(component != null && component.getClass() != JobDisplay.class) {
					component = component.getParent();
				}
				
				if(component != null) {
					((Observer)component).update();
				}
			} else {
				JOptionPane.showMessageDialog(this, "Update failed", "UNSUCCESSFUL", JOptionPane.ERROR_MESSAGE);
			}
		}
		
	}
```