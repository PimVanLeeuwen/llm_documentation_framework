`findById`: The function of `findById` is to retrieve a job from the cache or database by its ID.

**Parameters**:\
`int id`: This parameter represents the unique identifier of the job to be retrieved.

**Code Description**: 
The `findById` method first checks if caching is enabled. If not, it calls the `list()` method to populate the cache with all jobs in the database. It then checks if a job with the specified ID exists in the cache. If it does, the cached job is returned. If not, the method returns null, indicating that no job was found with the given ID.\\
## Code: 
```
Job findById(int id) {
		
		if(usingCache == false)
			list();
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```