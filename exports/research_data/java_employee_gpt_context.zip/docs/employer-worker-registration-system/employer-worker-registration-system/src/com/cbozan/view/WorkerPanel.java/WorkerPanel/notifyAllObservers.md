`notifyAllObservers`: The function of `notifyAllObservers` is to notify all registered observers that an update has occurred, allowing them to refresh their views accordingly.

**Code Description**: This method iterates through a list of registered observers and calls the `update` method on each one, effectively notifying them of any changes or updates.\\
## Code: 
```
void notifyAllObservers() {
		for(Observer observer : observers) {
			observer.update();
		}
	}
```