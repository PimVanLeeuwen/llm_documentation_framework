**InvoiceBuilder**: The function of `InvoiceBuilder` is to create an instance of the `Invoice` class with specified attributes, allowing for fluent API usage through method chaining.

**Code Description**: 
The `InvoiceBuilder` class serves as a builder pattern implementation in Java. It provides a set of methods (`setId`, `setJob_id`, `setJob`, `setAmount`, and `setDate`) to construct an instance of the `Invoice` class with specific attributes (ID, job ID, job object, amount, and date). The `build` method is used to create the actual `Invoice` instance based on the provided attributes. If a `job` object exists, it will be used; otherwise, the `Invoice` instance will be created without a job reference.\\
## Code: 
```
class InvoiceBuilder{
		
		private int id;
		private int job_id;
		private Job job;
		private BigDecimal amount;
		private Timestamp date;
		
		public InvoiceBuilder() {}
		public InvoiceBuilder(int id, int job_id, BigDecimal amount, Timestamp date) {
			this.id = id;
			this.job_id = job_id;
			this.amount = amount;
			this.date = date;
		}
		
		public InvoiceBuilder(int id, Job job, BigDecimal amount, Timestamp date) {
			this(id, 0, amount, date);
			this.job = job;
		}
		
		public InvoiceBuilder setId(int id) {
			this.id = id;
			return this;
		}
		
		public InvoiceBuilder setJob_id(int job_id) {
			this.job_id = job_id;
			return this;
		}
		
		public InvoiceBuilder setJob(Job job) {
			this.job = job;
			return this;
		}
		
		public InvoiceBuilder setAmount(BigDecimal amount) {
			this.amount = amount;
			return this;
		}
		
		public InvoiceBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Invoice build() throws EntityException {
			if(job == null)
				return new Invoice(this);
			return new Invoice(id, job, amount, date);
		}
		
	}
```