## Expected output
`addEditButton`: The function of `addEditButton` is to create and return a JButton that toggles the editability of a JTextComponent.
**Parameters**:\
`JTextComponent textField`: This parameter represents the text field whose editability will be toggled by the button.
`Component nextFocus`: This parameter represents the component that will receive focus when the button is clicked, or null if no specific component should receive focus.

**Code Description**: The `addEditButton` function creates a JButton with an edit icon. When clicked, it checks if the text field is editable. If it is, the button's icon changes to a check icon, and the text field becomes non-editable. If the text field is not editable and its text does not match a specific initial text, the button's icon changes back to the edit icon, and the text field becomes editable. The function also ensures that focus is given to either the specified nextFocus component or the window itself when the button is clicked.\\
## Code: 
```
JButton addEditButton(JTextComponent textField, Component nextFocus) {
		JButton editButton = new JButton(new ImageIcon("src\\icon\\text_edit.png"));
		editButton.setContentAreaFilled(false);
		editButton.setFocusable(false);
		editButton.setBorderPainted(false);
		editButton.setBounds(textField.getX() + textField.getWidth() + BS, textField.getY(), BW, rowHeight);
		
		editButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(textField.isEditable()) {
					editButton.setIcon(new ImageIcon("src\\icon\\text_edit.png"));
					textField.setEditable(false);
					if(nextFocus != null) {
						nextFocus.requestFocus();
					} else {
						requestFocusInWindow();
					}
					
				} else if(!textField.getText().equals(INIT_TEXT)) {
						textField.setEditable(true);
						editButton.setIcon(new ImageIcon("src\\icon\\check.png"));
				}
				super.mouseClicked(e);
			}
		});
		
		
		
		
		return editButton;
	}
```