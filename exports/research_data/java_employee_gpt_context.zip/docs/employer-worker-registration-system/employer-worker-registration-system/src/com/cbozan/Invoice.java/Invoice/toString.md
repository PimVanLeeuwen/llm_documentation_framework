**The function of `toString` is to return a string representation of an Invoice object.**

**The code description is that the `toString` method in the Invoice class returns a string containing the id, job, amount, and date of the invoice, formatted as "Invoice [id=..., job=..., amount=..., date=...]"**,\\
## Code: 
```
String toString() {
		return "Invoice [id=" + id + ", job=" + job + ", amount=" + amount + ", date=" + date + "]";
	}
```