`build`: The function of `build` is to create an instance of Invoice based on the provided data, either with default values or with specific job information.

**Code Description**: 
The `build` method in the `InvoiceBuilder` class creates a new instance of `Invoice`. If the `job` field is null, it returns a default `Invoice` object. Otherwise, it returns an `Invoice` object with the specified `id`, `job`, `amount`, and `date`. This suggests that the `build` method is used to construct an `Invoice` object from a builder pattern, allowing for flexible creation of invoices based on different scenarios.\\
## Code: 
```
Invoice build() throws EntityException {
			if(job == null)
				return new Invoice(this);
			return new Invoice(id, job, amount, date);
		}
```