## Expected output
`mouseAction`: The function of `mouseAction` is to handle mouse actions on a job panel, specifically when an employer is selected from a search result.
**Parameters**:\
`MouseEvent e`: This parameter represents the mouse event that triggered the action.
`Object searchResultObject`: This object contains the result of a search operation, which in this case is an Employer object.
`int chooseIndex`: This integer represents the index of the chosen employer in the search results.

**Code Description**: The `mouseAction` method updates the UI components based on the selected employer. It sets the text of the employer search box to the string representation of the selected employer, makes the search box uneditable, requests focus for a price combo box, and calls the superclass's `mouseAction` method with the updated parameters.\\
## Code: 
```
void mouseAction(MouseEvent e, Object searchResultObject, int chooseIndex) {
				selectedEmployer = (Employer) searchResultObject;
				employerSearchBox.setText(selectedEmployer.toString());
				employerSearchBox.setEditable(false);
				priceComboBox.requestFocus();
				super.mouseAction(e, searchResultObject, chooseIndex);
			}
```