`update`: The function of `update` is to refresh the job panel with updated data from the database.

**Code Description**: This method, `update`, clears the existing contents of the job panel by calling the `clearPanel` method. It then updates the price combo box model with a list of prices retrieved from the PriceDAO instance and populates the employer search box with a list of employers fetched from the EmployerDAO instance.\\
## Code: 
```
void update() {
		clearPanel();
		
		priceComboBox.setModel(new DefaultComboBoxModel<>(PriceDAO.getInstance().list().toArray(new Price[0])));
		employerSearchBox.setObjectList(EmployerDAO.getInstance().list());
		
	}
```