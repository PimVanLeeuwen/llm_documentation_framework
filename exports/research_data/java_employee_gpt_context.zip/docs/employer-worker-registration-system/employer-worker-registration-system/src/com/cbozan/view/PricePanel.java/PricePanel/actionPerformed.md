`actionPerformed`: The function of `actionPerformed` is to handle the action performed on a specific button, in this case, the "saveButton".

**Parameters**: 
`ActionEvent e`: This parameter represents the event that triggered the action performed method.

**Code Description**: When the saveButton is clicked, the code retrieves the text from three text fields (fulltimeTextField, halftimeTextField, and overtimeTextField) and removes any extra spaces. It then checks if the input values are in the correct format using the `decimalControl` method from the Control class. If the input is valid, it creates a new JTextArea for each price type and displays them in a confirmation dialog box. If the user clicks "SAVE", it creates a new Price object with the retrieved prices and attempts to save it to the database using the PriceDAO instance. If the save operation is successful, it notifies all observers by calling the `notifyAllObservers` method.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == saveButton) {
			
			String fulltime, halftime, overtime;
			
			fulltime = fulltimeTextField.getText().replaceAll("\\s+", "");
			halftime = halftimeTextField.getText().replaceAll("\\s+", "");
			overtime = overtimeTextField.getText().replaceAll("\\s+", "");
			
			if(!Control.decimalControl(fulltime, halftime, overtime)) {
				
				String message = "Please fill in the required fields or enter correctly format (max 2 floatpoint)";
				JOptionPane.showMessageDialog(this, message, "ERROR", JOptionPane.ERROR_MESSAGE);
				
			} else {
				
				JTextArea fulltimeTextArea, halftimeTextArea, overtimeTextArea;
				
				fulltimeTextArea = new JTextArea(fulltime + " ₺");
				fulltimeTextArea.setEditable(false);
				
				halftimeTextArea = new JTextArea(halftime + " ₺");
				halftimeTextArea.setEditable(false);
				
				overtimeTextArea = new JTextArea(overtime + " ₺");
				overtimeTextArea.setEditable(false);
				
				Object[] pane = {
						new JLabel("Fulltime Price"),
						fulltimeTextArea,
						new JLabel("Halftime Price"),
						halftimeTextArea,
						new JLabel("Overtime Price"),
						overtimeTextArea
				};
				
				
		
				int result = JOptionPane.showOptionDialog(this, pane, "Confirmation", 1, 1, 
						new ImageIcon("src\\icon\\accounting_icon_1_32.png"), new Object[] {"SAVE", "CANCEL"}, "CANCEL");
				
				
				// System.out.println(result);
				// 0 -> SAVE
				// 1 -> CANCEL
				
				if(result == 0) {
					
					Price.PriceBuilder builder = new Price.PriceBuilder();
					builder.setId(Integer.MAX_VALUE);
					builder.setFulltime(new BigDecimal(fulltime));
					builder.setHalftime(new BigDecimal(halftime));
					builder.setOvertime(new BigDecimal(overtime));
					
					Price price = null;
					try {
						price = builder.build();
					} catch (EntityException e1) {
						System.out.println(e1.getMessage());
					}
					
					if(PriceDAO.getInstance().create(price)) { 
						JOptionPane.showMessageDialog(this, "Registration Successful");
						notifyAllObservers();
					} else {
						JOptionPane.showMessageDialog(this, "Not saved", "DataBase error", JOptionPane.ERROR_MESSAGE);
					}
				}
				
			}
			
			
		}
		
	}
```