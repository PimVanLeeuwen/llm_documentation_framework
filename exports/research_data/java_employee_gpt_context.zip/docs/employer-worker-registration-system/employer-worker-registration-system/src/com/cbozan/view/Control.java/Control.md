**The function of Control is to validate various types of input data, such as phone numbers, IBAN numbers, and decimal values.**

**Code Description:**
The Control class provides a set of static methods for validating different types of input data. These methods use regular expressions to check if the input matches specific patterns.

*   `phoneNumberControl`: This method checks if a given phone number is valid according to Turkish phone number format.
*   `ibanControl`: This method validates an IBAN (International Bank Account Number) by checking if it matches the standard Turkish IBAN pattern.
*   `decimalControl`: This method verifies that one or more input strings represent decimal numbers, following a specific pattern.

These methods can be used to ensure that user input conforms to expected formats, helping prevent errors and inconsistencies in data processing.\\
## Code: 
```
class Control {

	public static boolean phoneNumberControl(String phoneNumber) {
		return Pattern.compile("^((((\\+90)?|(0)?)\\d{10})|())$").matcher(phoneNumber.replaceAll("\\s+", "")).find();
	}
	public static boolean phoneNumberControl(String phoneNumber, String regex) {
		return Pattern.compile(regex).matcher(phoneNumber.replaceAll("\\s+", "")).find();
	}
	public static boolean phoneNumberControl(String phoneNumber, Pattern pattern) {
		return pattern.matcher(phoneNumber).find();
	}
	
	
	public static boolean ibanControl(String iban) {
		return Pattern.compile("^((TR\\d{24})|())$", Pattern.CASE_INSENSITIVE).matcher(iban).find();
	}
	public static boolean ibanControl(String iban, String regex) {
		return Pattern.compile(regex).matcher(iban).find();
	}
	public static boolean ibanControl(String iban, Pattern pattern) {
		return pattern.matcher(iban).find();
	}
	
	
	public static boolean decimalControl(String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= Pattern.compile("^((\\d+(\\.\\d{1,2})?)|())$").matcher(arg).find();
		}
		return rValue;
	}
	public static boolean decimalControl(Pattern pattern, String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= pattern.matcher(arg).find();
		}
		return rValue;
	}
	
}
```