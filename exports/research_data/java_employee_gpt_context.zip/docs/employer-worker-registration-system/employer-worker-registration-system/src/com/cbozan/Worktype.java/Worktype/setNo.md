`setNo`: The function of `setNo` is to set the worktype number.

**Parameters**:
`int no`: This parameter represents the new worktype number that will be assigned to the worktype object.

**Code Description**: 
The `setNo` method sets the worktype number (`no`) of a worktype object. It takes an integer value as input, checks if it is less than or equal to 0, and throws an `EntityException` if true. If the input is valid (i.e., greater than 0), it assigns the new worktype number to the corresponding field in the worktype object.\\
## Code: 
```
void setNo(int no) throws EntityException {
		if(no <= 0)
			throw new EntityException("Worktype no negative or zero");
		this.no = no;
	}
```