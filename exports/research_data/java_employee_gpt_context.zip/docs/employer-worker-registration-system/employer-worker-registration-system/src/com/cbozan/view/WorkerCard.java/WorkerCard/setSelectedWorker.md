`setSelectedWorker`: The function of `setSelectedWorker` is to update the UI components with the details of a newly selected worker.

**Parameters**:\
`Worker selectedWorker`: This parameter represents the worker object whose details are being updated in the UI.

**Code Description**: 
The setSelectedWorker method updates the UI components with the details of a newly selected worker. If no worker is selected, it resets all text fields to their initial values. Otherwise, it populates the text fields with the corresponding details from the selected worker. It also disables editing for most UI components and changes the icon on certain buttons.\\
## Code: 
```
void setSelectedWorker(Worker selectedWorker) {
		this.selectedWorker = selectedWorker;
		
		if(selectedWorker == null) {
			fnameTextField.setText(INIT_TEXT);
			lnameTextField.setText(INIT_TEXT);
			ibanTextField.setText(INIT_TEXT);
			telTextField.setText(INIT_TEXT);
			descriptionTextArea.setText(INIT_TEXT);
		} else {
			
			setFnameTextFieldContent(selectedWorker.getFname());
			setLnameTextFieldContent(selectedWorker.getLname());
			if(selectedWorker.getTel() == null || selectedWorker.getTel().size() == 0)
				setTelTextFieldContent("");
			else
				setTelTextFieldContent(selectedWorker.getTel().get(0));
			setIbanTextFieldContent(selectedWorker.getIban());
			setDescriptionTextAreaContent(selectedWorker.getDescription());
			
		}
		
		for(int i = 2; i < this.getComponentCount(); i += 3) {
			if(getComponent(i - 1) instanceof RecordTextField)
				((RecordTextField)this.getComponent(i - 1)).setEditable(false);
			else if(getComponent(i - 1) instanceof TextArea)
				((TextArea)getComponent(i - 1)).setEditable(false);
			
			((JButton)this.getComponent(i)).setIcon(new ImageIcon("src\\icon\\text_edit.png"));
		}
		
		
	}
```