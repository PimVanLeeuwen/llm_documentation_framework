`getAmount`: The function of `getAmount` is to return the amount associated with an invoice.

**Code Description**: This method, `getAmount`, is a getter method that retrieves and returns the value of the `amount` field. It does not modify or calculate any values; it simply provides access to the existing `amount` data. The method takes no parameters and returns a `BigDecimal` object representing the invoice amount.\\
## Code: 
```
BigDecimal getAmount() {
		return amount;
	}
```