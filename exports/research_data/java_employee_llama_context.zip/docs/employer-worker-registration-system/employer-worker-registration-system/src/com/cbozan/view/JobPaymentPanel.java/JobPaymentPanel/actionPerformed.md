`actionPerformed`: When the takePaymentButton is clicked, it triggers a series of actions to process job payment.

**Parameters**: `ActionEvent e`: The event that triggered this method call, specifically when the takePaymentButton was clicked.

**Code Description**: This method checks if the input amount is valid and if a job has been selected. If both conditions are met, it displays a confirmation dialog with the job details and the payment amount. If confirmed, it creates an invoice using the provided builder and saves it to the database. If successful, it notifies all observers of the registration completion.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		if(e.getSource() == takePaymentButton) {
			
			Job job;
			String amount;
			
			job = selectedJob;
			amount = amountTextField.getText().replaceAll("\\s+", "");

			if(!decimalControl(amount) || job == null) {
				
				String message;
				message = "Please enter job selection section or format correctly (max 2 floating point)";
				JOptionPane.showMessageDialog(this, message, "ERROR", JOptionPane.ERROR_MESSAGE);
				
			} else {
				
				JTextArea jobTextArea, amountTextArea;
				
				jobTextArea = new JTextArea(job.toString());
				jobTextArea.setEditable(false);
				
				amountTextArea = new JTextArea(amount + " ₺");
				amountTextArea.setEditable(false);
				
				Object[] pane = {
						new JLabel("Job"),
						jobTextArea,
						new JLabel("Amount of payment"),
						amountTextArea
				};
		
				int result = JOptionPane.showOptionDialog(this, pane, "Confirmation", 1, 1, 
						new ImageIcon("src\\icon\\accounting_icon_1_32.png"), new Object[] {"SAVE", "CANCEL"}, "CANCEL");
				
				
				// System.out.println(result);
				// 0 -> SAVE
				// 1 -> CANCEL
				
				if(result == 0) {
					
					Invoice.InvoiceBuilder builder = new Invoice.InvoiceBuilder();
					builder.setId(Integer.MAX_VALUE);
					builder.setJob(selectedJob);
					builder.setAmount(new BigDecimal(amount));
					
					Invoice invoice = null;
					try {
						invoice = builder.build();
					} catch (EntityException e1) {
						System.out.println(e1.getMessage());
					}
					
					if(InvoiceDAO.getInstance().create(invoice)) { 
						JOptionPane.showMessageDialog(this, "Registration successful");
						notifyAllObservers();
					} else {
						JOptionPane.showMessageDialog(this, "Not saved", "DataBase error", JOptionPane.ERROR_MESSAGE);
					}
				}
				
			}
			
		}
		
	}
```