`list`: The function of `list` is to retrieve a list of jobs from the database, either by using cached data or by executing a SQL query to fetch data from the "job" table.

**Code Description**: This code snippet defines a method called `list` in the `JobDAO` class. It appears to be part of an employer-worker registration system, responsible for managing job listings. The method is designed to return a list of jobs, either by utilizing cached data or by executing a SQL query to fetch data from the "job" table in the database. If using cached data, it iterates over the cache entries and adds each job object to the result list. If not using cached data, it clears the cache, establishes a connection to the database, executes a SELECT * FROM job; query, and populates the result list with Job objects built from the query results. The method also catches any SQL exceptions that may occur during this process and displays an error message if necessary.\\
## Code: 
```
List<Job> list(){
		
		List<Job> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Job> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM job;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			JobBuilder builder;
			Job job;
			
			while(rs.next()) {
				
				builder = new JobBuilder();
				builder.setId(rs.getInt("id"));
				builder.setEmployer_id(rs.getInt("employer_id"));
				builder.setPrice_id(rs.getInt("price_id"));
				builder.setTitle(rs.getString("title"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					job = builder.build();
					list.add(job);
					cache.put(job.getId(), job);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id") + " Title : " + rs.getString("title"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
	}
```