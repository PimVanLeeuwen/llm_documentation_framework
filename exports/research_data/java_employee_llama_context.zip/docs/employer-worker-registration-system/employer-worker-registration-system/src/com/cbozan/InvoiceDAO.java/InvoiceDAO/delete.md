`delete`: The function of `delete` is to delete an invoice from the database.

**Parameters**: Invoice invoice: This method takes an instance of the Invoice class as a parameter, which contains the ID of the invoice to be deleted.

**Code Description**: The code establishes a connection to the database using JDBC, prepares a DELETE statement with the provided invoice ID, executes the query, and updates the cache if the deletion is successful.\\
## Code: 
```
boolean delete(Invoice invoice) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM invoice WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, invoice.getId());
			
			result = ps.executeUpdate();
			
			if(result != 0) {
				cache.remove(invoice.getId());
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return result == 0 ? false : true;
		
	}
```