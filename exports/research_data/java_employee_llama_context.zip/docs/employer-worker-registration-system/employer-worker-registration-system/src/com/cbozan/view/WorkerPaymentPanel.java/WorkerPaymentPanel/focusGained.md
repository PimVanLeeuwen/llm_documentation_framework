`focusGained`: The function of `focusGained` is to handle the focus gained event for a JTextField component.

**Parameters**: 
`FocusEvent e`: This parameter represents the FocusEvent that occurred when the JTextField gained focus.

**Code Description**: When the JTextField gains focus, this method checks if the source of the event is an instance of JTextField. If it is, it sets a blue border around the JTextField and changes the foreground color of a specific label (amountLabel) to blue if the JTextField is the amountTextField.\\
## Code: 
```
void focusGained(FocusEvent e) {
		if(e.getSource() instanceof JTextField) {
			
			((JTextField)e.getSource()).setBorder(new LineBorder(Color.blue));
			
			if(((JTextField)e.getSource()) == amountTextField) {
				amountLabel.setForeground(Color.blue);
			}
			
		}
		
	}
```