`setFname`: The function of `setFname` is to set the first name of a worker.

**Parameters**: 
`String fname`: This parameter represents the new first name that will be assigned to the worker.

**Code Description**: 
The `setFname` method checks if the provided first name meets certain conditions. If it's empty (i.e., has a length of 0) or exceeds the maximum allowed length specified by `DBConst.FNAME_LENGTH`, an `EntityException` is thrown with a message indicating that the worker name is either empty or too long. Otherwise, the provided first name is assigned to the `fname` field of the current worker object.\\
## Code: 
```
void setFname(String fname) throws EntityException {
		if(fname.length() == 0 || fname.length() > DBConst.FNAME_LENGTH)
			throw new EntityException("Worker name empty or too long");
		this.fname = fname;
	}
```