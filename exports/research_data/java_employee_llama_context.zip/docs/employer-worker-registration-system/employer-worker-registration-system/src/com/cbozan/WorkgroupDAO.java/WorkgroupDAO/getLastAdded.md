**The function of `getLastAdded` is to retrieve the most recently added workgroup from the database.**

**Code Description:**
The `getLastAdded` method in the WorkgroupDAO class retrieves the most recently added workgroup from the database by executing a SQL query that selects all columns from the workgroup table, orders them by id in descending order (newest first), and limits the result to one row. The method then uses a WorkgroupBuilder object to construct a Workgroup object from the retrieved data, which is then returned as the last added workgroup. If an error occurs during this process, it is caught and printed to the console.\\
## Code: 
```
Workgroup getLastAdded() {
		
		Workgroup workgroup = null;
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM workgroup ORDER BY id DESC LIMIT 1";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			WorkgroupBuilder builder; 
			
			while(rs.next()) {
				
				builder = new WorkgroupBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setWorktype_id(rs.getInt("worktype_id"));
				builder.setWorkCount(rs.getInt("workcount"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					workgroup = builder.build();
				} catch (EntityException e) {
					System.err.println(e.getMessage());
				}
				
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return workgroup;
	}
```