`filterWorktype`: The function of `filterWorktype` is to filter a list of Work objects based on their work type.

**Parameters**: 
`List<Work> workList`: A list of Work objects that needs to be filtered.

**Code Description**: This method iterates over the provided list of Work objects and removes any items whose work type does not match the selected work type. If no work type is selected, it returns without modifying the list.\\
## Code: 
```
void filterWorktype(List<Work> workList) {
		if(selectedWorktype == null) {
			return;
		}
		
		Iterator<Work> work = workList.iterator();
		Work workItem;
		while(work.hasNext()) {
			workItem = work.next();
			if(workItem.getWorktype().getId() != selectedWorktype.getId()) {
				work.remove();
			}
		}
	}
```