## Expected output
`mouseAction`: The function of `mouseAction` is to handle mouse actions on the EmployerDisplay component.
**Parameters**:\
`MouseEvent e`: This parameter represents a mouse event, such as a click or hover action.
`Object searchResultObject`: This parameter holds an object representing the result of a search operation.
`int chooseIndex`: This parameter indicates the index of the chosen item in a list.

**Code Description**: The `mouseAction` method updates the UI components based on the mouse event and search result. It sets the selected job, updates the employer payment job filter search box, enables or disables it, changes the color of the label, shows or hides buttons, and calls other methods to update the table data.\\
## Code: 
```
void mouseAction(MouseEvent e, Object searchResultObject, int chooseIndex) {
				selectedJob = (Job) searchResultObject;
				employerPaymentJobFilterSearchBox.setText(selectedJob.toString());
				employerPaymentJobFilterSearchBox.setEditable(false);
				employerPaymentJobFilterLabel.setForeground(new Color(37, 217, 138));
				removeEmployerPaymentJobFilterButton.setVisible(true);
				updateEmployerPaymentTableData();
				super.mouseAction(e, searchResultObject, chooseIndex);
			}
```