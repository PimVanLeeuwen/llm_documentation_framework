`setAmount`: The function of `setAmount` is to validate and set the invoice amount.

**Parameters**:
`BigDecimal amount`: This parameter represents the new amount to be set for the invoice, which must be a positive value greater than zero.

**Code Description**: 
The `setAmount` method checks if the provided `amount` is valid by comparing it with a minimum threshold of "0.00". If the `amount` is less than or equal to this threshold, an `EntityException` is thrown with a message indicating that the invoice amount cannot be negative or zero. Otherwise, the `amount` is assigned to the instance variable `this.amount`.\\
## Code: 
```
void setAmount(BigDecimal amount) throws EntityException {
		if(amount.compareTo(new BigDecimal("0.00")) <= 0)
			throw new EntityException("Invoice amount negative or zero");
		this.amount = amount;
	}
```