**list**: Retrieves a list of prices from the database, either by using cached data or by executing a SQL query to fetch the latest prices.

**Code Description**: This method, `list`, is responsible for retrieving a collection of price objects from the database. It first checks if there are any cached prices available and uses them if applicable. If not, it clears the cache and executes a SQL query to select all rows from the `price` table. The retrieved data is then used to create `Price` objects using a `PriceBuilder`, which are added to the list. Any exceptions that occur during this process are handled by displaying error messages to the user.\\
## Code: 
```
List<Price> list(){
		
		List<Price> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Price> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM price;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			PriceBuilder builder;
			Price price;
			
			while(rs.next()) {
				
				builder = new PriceBuilder();
				builder.setId(rs.getInt("id"));
				builder.setFulltime(rs.getBigDecimal("fulltime"));
				builder.setHalftime(rs.getBigDecimal("halftime"));
				builder.setOvertime(rs.getBigDecimal("overtime"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					price = builder.build();
					list.add(price);
					cache.put(price.getId(), price);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
		
	}
```