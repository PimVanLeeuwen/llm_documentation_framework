`updateEmployerPaymentTableData`: The function of `updateEmployerPaymentTableData` is to update the employer's payment table data by filtering and displaying invoices associated with a selected employer.

**Code Description**: This method retrieves a list of invoices from the database for the currently selected employer, filters out any invoices that do not match the selected job, and then populates a table with the filtered invoice data. The table includes columns for invoice ID, job name, amount, date, and total amount. The total amount is calculated by summing up the amounts of all invoices in the list. Additionally, it updates two labels to display the total amount and count of records in the table.\\
## Code: 
```
void updateEmployerPaymentTableData() {
		
		if(selectedEmployer != null) {
			
			List<Invoice> invoiceList = InvoiceDAO.getInstance().list(selectedEmployer);
			filterPaymentJob(invoiceList);
			
			String[][] tableData = new String[invoiceList.size()][employerPaymentTableColumns.length];
			BigDecimal totalAmount = new BigDecimal("0.00");
			int i = 0;
			for(Invoice invoice : invoiceList) {
				tableData[i][0] = invoice.getId() + "";
				tableData[i][1] = invoice.getJob().toString();
				tableData[i][2] = invoice.getAmount() + " ₺";
				tableData[i][3] = new SimpleDateFormat("dd.MM.yyyy").format(invoice.getDate());
				totalAmount = totalAmount.add(invoice.getAmount());
				++i;
			}
			
			((JTable)employerPaymentScrollPane.getViewport().getComponent(0)).setModel(new DefaultTableModel(tableData, employerPaymentTableColumns));
			((JTable)employerPaymentScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setPreferredWidth(5);
			((JTable)employerPaymentScrollPane.getViewport().getComponent(0)).setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
			
			DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
			centerRenderer.setHorizontalAlignment( SwingConstants.CENTER );
			((JTable)employerPaymentScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
			
			employerPaymentTotalLabel.setText("Total " + totalAmount + " ₺");
			employerPaymentCountLabel.setText(invoiceList.size() + " Record");
			
		}
		
	}
```