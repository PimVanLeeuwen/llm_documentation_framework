## Expected output
`mouseAction`: The function of `mouseAction` is to handle mouse actions on a job card.
**Parameters**:\
`MouseEvent e`: This parameter represents the mouse event that triggered the action.
`Object searchResultObject`: This parameter contains the result of a search, which is used to update the job's price.
`int chooseIndex`: This parameter indicates the index of the chosen item in a list.

**Code Description**: The `mouseAction` method updates the selected job's price with the searched result and displays it in the price search box. If an EntityException occurs during the update process, it is caught and printed to the console.\\
## Code: 
```
void mouseAction(MouseEvent e, Object searchResultObject, int chooseIndex) {
				if(selectedJob != null) {
					try {
						selectedJob.setPrice((Price)searchResultObject);
						if(priceSearchBox.getSelectedObject() != null)
							priceSearchBox.setText(priceSearchBox.getSelectedObject().toString());
					} catch (EntityException e1) {
						e1.printStackTrace();
					}
				}
				super.mouseAction(e, searchResultObject, chooseIndex);
			}
```