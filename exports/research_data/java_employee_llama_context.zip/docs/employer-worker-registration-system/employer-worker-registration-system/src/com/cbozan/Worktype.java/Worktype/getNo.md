`getNo`: The function of `getNo` is to return the value of the instance variable `no`.

**Code Description**: This method, `getNo`, is a getter method that retrieves and returns the current value of the `no` field. It does not modify or update any values; it simply provides access to the existing state of the object. The `return` statement directly outputs the value of `no`.\\
## Code: 
```
int getNo() {
		return no;
	}
```