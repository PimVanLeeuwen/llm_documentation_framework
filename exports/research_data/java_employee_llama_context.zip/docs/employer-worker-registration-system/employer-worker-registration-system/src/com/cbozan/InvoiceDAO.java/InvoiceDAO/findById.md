`findById`: The function of `findById` is to retrieve an invoice from the cache or database by its ID.

**Parameters**: 
`int id`: This parameter represents the unique identifier of the invoice to be retrieved.

**Code Description**: The `findById` method first checks if it's using a cache. If not, it calls the `list()` method to populate the cache with invoices. It then checks if an invoice with the specified ID exists in the cache. If it does, it returns that invoice; otherwise, it returns null.\\
## Code: 
```
Invoice findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
	}
```