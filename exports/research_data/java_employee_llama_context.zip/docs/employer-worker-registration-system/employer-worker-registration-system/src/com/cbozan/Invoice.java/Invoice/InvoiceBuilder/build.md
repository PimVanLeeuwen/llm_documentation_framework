`build`: The function of `build` is to create an instance of Invoice based on the provided data.

**Code Description**: 
The `build` method in the `InvoiceBuilder` class creates a new instance of `Invoice`. If the `job` field is null, it returns a default `Invoice` object with the current builder's data. Otherwise, it returns a new `Invoice` object with the specified `id`, `job`, `amount`, and `date`. This method throws an `EntityException` if any error occurs during the creation process.\\
## Code: 
```
Invoice build() throws EntityException {
			if(job == null)
				return new Invoice(this);
			return new Invoice(id, job, amount, date);
		}
```