`updateControl`: The function of `updateControl` is to check if a new payment type can be updated in the system.

**Parameters**: 
`Paytype paytype`: This method takes an object of type `Paytype` as input, which represents the payment type that needs to be updated.

**Code Description**: 
The `updateControl` method iterates through a cache of existing payment types. If it finds a matching title for the new payment type (i.e., a payment type with the same title but different ID), it sets an error message and returns false, indicating that the update cannot proceed due to a duplicate title. If no match is found, the method returns true, allowing the update to proceed.\\
## Code: 
```
boolean updateControl(Paytype paytype) {
		for(Entry<Integer, Paytype> obj : cache.entrySet()) {
			if(obj.getValue().getTitle().equals(paytype.getTitle()) && obj.getValue().getId() != paytype.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getTitle() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```