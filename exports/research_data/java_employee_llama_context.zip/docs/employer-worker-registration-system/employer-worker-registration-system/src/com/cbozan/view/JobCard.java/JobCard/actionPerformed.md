`actionPerformed`: When the update button is clicked and a job is selected, this method updates the job details in the GUI application.

**Parameters**: `ActionEvent e`: The event that triggered the action performed method, specifically when the update button is clicked.

**Code Description**: This method retrieves the updated title and description from their respective text fields and areas, and then calls the JobDAO instance to update the selected job. If the update is successful, it displays a success message and notifies the parent component (which is an Observer) to update itself. If the update fails, it displays an error message.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == updateButton && selectedJob != null) {
			
			setTitleTextFieldContent(getTitleTextFieldContent());
			setDescriptionTextAreaContent(getDescriptionTextAreaContent());
			
			
			if(true == JobDAO.getInstance().update(selectedJob)) {
				JOptionPane.showMessageDialog(this, "Update successful", "SUCCESSFUL", JOptionPane.INFORMATION_MESSAGE);
				
				Component component = getParent();
				while(component != null && component.getClass() != JobDisplay.class) {
					component = component.getParent();
				}
				
				if(component != null) {
					((Observer)component).update();
				}
			} else {
				JOptionPane.showMessageDialog(this, "Update failed", "UNSUCCESSFUL", JOptionPane.ERROR_MESSAGE);
			}
		}
		
	}
```