`create`: The function of `create` is to insert a new price record into the database and update the cache with the newly inserted record.

**Parameters**:\
`Price price`: This parameter represents the price data that needs to be inserted into the database, including full-time, half-time, and overtime values.

**Code Description**: The code first checks if a price record already exists in the cache using the `createControl` method. If it does not exist, it proceeds to insert the new record into the database using a prepared statement with the provided query. After inserting the record, it retrieves the newly inserted ID and uses it to update the cache by creating a new Price object and adding it to the cache map. The code also handles any SQL exceptions that may occur during the insertion process.\\
## Code: 
```
boolean create(Price price) {
		
		if(createControl(price) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO price (fulltime,halftime,overtime) VALUES (?,?,?);";
		String query2 = "SELECT * FROM price ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			
			pst.setBigDecimal(1, price.getFulltime());
			pst.setBigDecimal(2, price.getHalftime());
			pst.setBigDecimal(3, price.getOvertime());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					PriceBuilder builder = new PriceBuilder();
					builder.setId(rs.getInt("id"));
					builder.setFulltime(rs.getBigDecimal("fulltime"));
					builder.setHalftime(rs.getBigDecimal("halftime"));
					builder.setOvertime(rs.getBigDecimal("overtime"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Price prc = builder.build();
						cache.put(prc.getId(), prc);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id"));
					}
					
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```