**The function of Control is to validate various types of input data, such as phone numbers and IBAN numbers, using regular expressions.**

**Code Description:**
The Control class provides a set of static methods for validating different types of input data. These methods use regular expressions to check if the input matches a specific pattern. The class contains three main validation methods: phoneNumberControl, ibanControl, and decimalControl.

*   **phoneNumberControl**: This method validates phone numbers by checking if they match a specific pattern that allows for optional '+' and '0' prefixes followed by 10 digits.
*   **ibanControl**: This method checks if an IBAN number matches a specific pattern that includes the country code "TR" followed by 24 digits, allowing for case-insensitive matching.
*   **decimalControl**: This method validates decimal numbers by checking if they match a pattern of one or more digits optionally followed by a single digit after a decimal point.\\
## Code: 
```
class Control {

	public static boolean phoneNumberControl(String phoneNumber) {
		return Pattern.compile("^((((\\+90)?|(0)?)\\d{10})|())$").matcher(phoneNumber.replaceAll("\\s+", "")).find();
	}
	public static boolean phoneNumberControl(String phoneNumber, String regex) {
		return Pattern.compile(regex).matcher(phoneNumber.replaceAll("\\s+", "")).find();
	}
	public static boolean phoneNumberControl(String phoneNumber, Pattern pattern) {
		return pattern.matcher(phoneNumber).find();
	}
	
	
	public static boolean ibanControl(String iban) {
		return Pattern.compile("^((TR\\d{24})|())$", Pattern.CASE_INSENSITIVE).matcher(iban).find();
	}
	public static boolean ibanControl(String iban, String regex) {
		return Pattern.compile(regex).matcher(iban).find();
	}
	public static boolean ibanControl(String iban, Pattern pattern) {
		return pattern.matcher(iban).find();
	}
	
	
	public static boolean decimalControl(String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= Pattern.compile("^((\\d+(\\.\\d{1,2})?)|())$").matcher(arg).find();
		}
		return rValue;
	}
	public static boolean decimalControl(Pattern pattern, String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= pattern.matcher(arg).find();
		}
		return rValue;
	}
	
}
```