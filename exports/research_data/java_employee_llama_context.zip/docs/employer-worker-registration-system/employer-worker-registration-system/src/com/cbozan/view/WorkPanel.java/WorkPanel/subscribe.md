`subscribe`: The function of `subscribe` is to add an observer to the list of observers.
**Parameters**: Observer observer: This parameter represents the observer that wants to be notified when something happens in the system.
**Code Description**: The subscribe method adds a given observer to the list of observers.\\
## Code: 
```
void subscribe(Observer observer) {
		observers.add(observer);
	}
```