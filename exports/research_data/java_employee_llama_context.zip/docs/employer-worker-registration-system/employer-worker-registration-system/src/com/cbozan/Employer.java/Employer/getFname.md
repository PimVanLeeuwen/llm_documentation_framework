`getFname`: The function of `getFname` is to return the first name of an employer.

**Code Description**: This method, `getFname`, is a getter method in Java that retrieves and returns the value of the instance variable `fname`. It does not modify or update any data; its sole purpose is to provide access to the stored first name.\\
## Code: 
```
String getFname() {
		return fname;
	}
```