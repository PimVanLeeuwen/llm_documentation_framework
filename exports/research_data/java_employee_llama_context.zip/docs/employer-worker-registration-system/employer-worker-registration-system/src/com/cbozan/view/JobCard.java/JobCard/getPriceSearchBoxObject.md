`getPriceSearchBoxObject`: The function of `getPriceSearchBoxObject` is to retrieve the selected object from a search box.

**Code Description**: This method, `getPriceSearchBoxObject`, is part of a class that handles job card functionality. It calls another method, `getSelectedObject`, which is located in a separate class responsible for handling search box operations. The purpose of this method is to retrieve the selected object from the search box and return it as a Price object.\\
## Code: 
```
Price getPriceSearchBoxObject() {
		return (Price) priceSearchBox.getSelectedObject();
	}
```