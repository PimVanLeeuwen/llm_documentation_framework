`notifyAllObservers`: The function of `notifyAllObservers` is to notify all registered observers that new data is available, triggering them to update their respective views.

**Code Description**: This method iterates through a list of registered observers and calls the `update()` method on each one, effectively notifying them that fresh data from the database is ready. The `update()` method in turn refreshes the graphical user interface by clearing existing data and updating search boxes and combo box models with new lists from the database.\\
## Code: 
```
void notifyAllObservers() {
		for(Observer observer : observers) {
			observer.update();
		}
	}
```