`filterPaymentJob`: The function of `filterPaymentJob` is to remove payments from the list that do not match the selected worker's payment job.

**Parameters**: 
`List<Payment> paymentList`: A list of Payment objects, which will be filtered based on the selected worker's payment job.

**Code Description**: This method iterates through a list of payments and removes any payment that does not have a matching job ID with the selected worker's payment job. If no selected worker payment job is set, the method returns without modifying the list.\\
## Code: 
```
void filterPaymentJob(List<Payment> paymentList) {
		if(selectedWorkerPaymentJob == null)
			return;
		
		Iterator<Payment> payment = paymentList.iterator();
		Payment paymentItem;
		while(payment.hasNext()) {
			paymentItem = payment.next();
			if(paymentItem.getJob().getId() != selectedWorkerPaymentJob.getId()) {
				payment.remove();
			}
		}
	}
```