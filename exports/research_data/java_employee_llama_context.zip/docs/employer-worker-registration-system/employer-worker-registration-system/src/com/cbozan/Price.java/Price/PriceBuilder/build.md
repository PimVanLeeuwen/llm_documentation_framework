`build`: The function of `build` is to create a new instance of the Price class, initialized with the data provided by the builder object.

**Code Description**: 
The `build` method in the `PriceBuilder` class creates and returns a new `Price` object. It takes no arguments and throws an `EntityException`. The method simply instantiates a new `Price` object using the current state of the builder, effectively "building" the price entity. This suggests that the builder pattern is being used to construct complex objects step-by-step, allowing for flexibility in setting properties before creating the final object.\\
## Code: 
```
Price build() throws EntityException{
			return new Price(this);
		}
```