**createControl**: The function of `createControl` is to check if a new `Worktype` can be created in the system.

**Parameters**: 
`Worktype worktype`: This parameter represents the `Worktype` object that is being checked for creation.

**Code Description**: 
The `createControl` method iterates through a cache of existing `Worktype` objects. If it finds an object with the same title as the one being checked, it returns `false`, indicating that the new `Worktype` cannot be created because a duplicate exists. If no duplicates are found, it returns `true`, allowing the creation of the new `Worktype`.\\
## Code: 
```
boolean createControl(Worktype worktype) {
		for(Entry<Integer, Worktype> obj : cache.entrySet()) {
			if(obj.getValue().getTitle().equals(worktype.getTitle())) {
				return false;
			}
		}
		return true;
	}
```