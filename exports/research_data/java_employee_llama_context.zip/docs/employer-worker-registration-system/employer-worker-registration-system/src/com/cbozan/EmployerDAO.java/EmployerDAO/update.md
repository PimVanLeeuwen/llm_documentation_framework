`update`: Updates the information of an existing employer in the database and cache.

**Parameters**: 
`Employer employer`: The employer object whose information is to be updated, containing fields such as first name, last name, phone numbers, description, and ID.

**Code Description**: This method updates the employer's details in both the database and a cache. It first checks if an update control is successful; if not, it returns false. If the update control passes, it prepares a SQL query to update the employer's information in the database. The query sets the employer's first name, last name, phone numbers (as an array), description, and ID. After executing the query, it updates the cache with the new employer details if the update is successful. If any SQL exception occurs during this process, it displays a message dialog box showing detailed information about the exception. The method returns true if the update is successful and false otherwise.\\
## Code: 
```
boolean update(Employer employer) {
		
		if(updateControl(employer) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE employer SET fname=?,"
				+ "lname=?, tel=?, description=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1, employer.getFname());
			pst.setString(2, employer.getLname());
			
			Array phones = conn.createArrayOf("VARCHAR", employer.getTel().toArray());
			pst.setArray(3, phones);
			
			pst.setString(4, employer.getDescription());
			pst.setInt(5, employer.getId());
			
			result = pst.executeUpdate();
			
			// update cache
			if(result != 0) {
				cache.put(employer.getId(), employer);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```