**updateControl**: The function of `updateControl` is to check if a new price record already exists in the cache with the same fulltime, halftime, and overtime values as the input price.

**Parameters**: 
`Price price`: This method takes an object of type `Price` as a parameter, which contains information about the price, including fulltime, halftime, and overtime values.

**Code Description**: The code iterates through the cache entries and checks if any existing entry has the same fulltime, halftime, and overtime values as the input price. If such an entry is found, it returns `false` with an error message indicating that the price record already exists. If no matching entry is found, it returns `true`, allowing the new price record to be added to the cache.\\
## Code: 
```
boolean updateControl(Price price) {
		for(Entry<Integer, Price> obj : cache.entrySet()) {
			if(obj.getValue().getFulltime().compareTo(price.getFulltime()) == 0
					&& obj.getValue().getHalftime().compareTo(price.getHalftime()) == 0
					&& obj.getValue().getOvertime().compareTo(price.getOvertime()) == 0
					&& obj.getValue().getId() != price.getId()) {
				
				DB.ERROR_MESSAGE = "Bu fiyat bilgisi kaydı zaten mevcut.";
				return false;
			}
		}
		
		return true;
	}
```