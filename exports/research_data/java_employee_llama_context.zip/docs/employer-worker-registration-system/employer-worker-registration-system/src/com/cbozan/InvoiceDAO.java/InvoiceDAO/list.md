**The function of `list` is to retrieve a list of invoices from the database based on a specified column name and ID.**

**Parameters:**
- `String columnName`: The name of the column in the invoice table to filter by.
- `int id`: The value of the ID to filter by.

**Code Description:** 
The `list` method takes two parameters, `columnName` and `id`, and uses them to construct a SQL query that selects all invoices from the database where the specified column matches the given ID. It then executes this query using a Statement object, retrieves the results as a ResultSet, and iterates over each row in the result set to create an Invoice object for each invoice found. The Invoice objects are added to a list, which is returned at the end of the method. If any errors occur during this process, they are caught and printed to the console.\\
## Code: 
```
List<Invoice> list(String columnName, int id){
		
		List<Invoice> list = new ArrayList<>();
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM invoice WHERE " + columnName + "=" + id;
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			InvoiceBuilder builder;
			Invoice invoice;
			
			while(rs.next()) {
				
				builder = new InvoiceBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setAmount(rs.getBigDecimal("amount"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					invoice = builder.build();
					list.add(invoice);
				} catch (EntityException e) {
					System.err.println(e.getMessage());
					System.out.println("!! Invoice not added list !!");
				}
				
			}
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return list;
	}
```