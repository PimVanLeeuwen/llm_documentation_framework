## EmptyInstanceSingleton: The function of EmptyInstanceSingleton is to create a singleton instance of the Invoice class, which means it will always return the same instance of Invoice.

**Code Description:** 
The code defines a class called `EmptyInstanceSingleton` that contains a static final variable `instance` of type `Invoice`. This variable is initialized with a new instance of the `Invoice` class. The purpose of this class is to provide a singleton instance of the `Invoice` class, meaning it will always return the same instance when accessed through the `EmptyInstanceSingleton` class.\\
## Code: 
```
class EmptyInstanceSingleton{
		private static final Invoice instance = new Invoice(); 
	}
```