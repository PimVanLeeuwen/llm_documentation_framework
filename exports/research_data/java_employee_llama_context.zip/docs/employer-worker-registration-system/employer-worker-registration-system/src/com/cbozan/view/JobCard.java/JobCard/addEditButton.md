## Expected output
`addEditButton`: The function of `addEditButton` is to create and return a JButton that toggles the editability of a JTextComponent.
**Parameters**:\
`JTextComponent textField`: This parameter represents the JTextComponent whose editability will be toggled by the JButton.
`Component nextFocus`: This parameter represents the Component that will receive focus when the JButton is clicked, or null if no specific Component should receive focus.

**Code Description**: The `addEditButton` function creates a JButton with an icon and sets its properties to not fill the content area, be non-focusable, and have no border. It then adds a MouseAdapter to the JButton that listens for mouse clicks. When clicked, it checks if the JTextComponent is editable; if so, it changes the JButton's icon, makes the JTextComponent uneditable, and requests focus for either the specified Component or the window itself. If the JTextComponent is not editable but has text other than a default value, it makes the JTextComponent editable and changes the JButton's icon to indicate this.\\
## Code: 
```
JButton addEditButton(JTextComponent textField, Component nextFocus) {
		JButton editButton = new JButton(new ImageIcon("src\\icon\\text_edit.png"));
		editButton.setContentAreaFilled(false);
		editButton.setFocusable(false);
		editButton.setBorderPainted(false);
		editButton.setBounds(textField.getX() + textField.getWidth() + BS, textField.getY(), BW, rowHeight);
		
		editButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(textField.isEditable()) {
					editButton.setIcon(new ImageIcon("src\\icon\\text_edit.png"));
					textField.setEditable(false);
					if(nextFocus != null) {
						nextFocus.requestFocus();
					} else {
						requestFocusInWindow();
					}
					
				} else if(!textField.getText().equals(INIT_TEXT)) {
						textField.setEditable(true);
						editButton.setIcon(new ImageIcon("src\\icon\\check.png"));
				}
				super.mouseClicked(e);
			}
		});
		
		return editButton;
	}
```