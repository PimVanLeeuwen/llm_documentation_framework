`setHalftime`: The function of `setHalftime` is to set the halftime price for a product or service.

**Parameters**: 
`BigDecimal halftime`: This parameter represents the halftime price, which must be a non-negative value greater than zero.

**Code Description**: 
The `setHalftime` method checks if the provided halftime price is valid (i.e., not null and greater than zero). If it's invalid, an `EntityException` is thrown with a message indicating that the halftime price cannot be negative or null. Otherwise, the halftime price is set for the entity.\\
## Code: 
```
void setHalftime(BigDecimal halftime) throws EntityException {
		if(halftime == null || halftime.compareTo(new BigDecimal("0.00")) <= 0)
			throw new EntityException("Price halftime negative or null or zero");
		this.halftime = halftime;
	}
```