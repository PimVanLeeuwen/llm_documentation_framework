`getFulltime`: The function of `getFulltime` is to return the full-time value.

**Code Description**: This method, `getFulltime`, is a getter method that retrieves and returns the full-time value stored in the `fulltime` variable. It does not modify or calculate any values; it simply provides access to the existing data. The returned value is of type `BigDecimal`, indicating that it represents a monetary amount or a precise numerical value.\\
## Code: 
```
BigDecimal getFulltime() {
		return fulltime;
	}
```