`filterJob`: The function of `filterJob` is to filter a list of Work objects based on the ID of the selected job.

**Parameters**: 
`List<Work> workList`: A list of Work objects that needs to be filtered.

**Code Description**: This method iterates over the provided list of Work objects and removes any items whose job ID does not match the ID of the selected job. If no job is selected, it simply returns without modifying the list.\\
## Code: 
```
void filterJob(List<Work> workList) {
		if(selectedWorkTableJob == null) {
			return;
		}
		
		Iterator<Work> work = workList.iterator();
		Work workItem;
		while(work.hasNext()) {
			workItem = work.next();
			if(workItem.getJob().getId() != selectedWorkTableJob.getId()) {
				work.remove();
			}
		}
		
	}
```