`findById`: The function of `findById` is to retrieve an employer from the database by their unique identifier.

**Parameters**:\
`int id`: This method takes an integer parameter representing the ID of the employer to be retrieved.

**Code Description**: 
The `findById` method first checks if caching is enabled. If not, it calls the `list()` method to populate the cache with all employers from the database. It then checks if the specified ID exists in the cache. If it does, it returns the cached employer object. If not, or if caching is disabled, it returns null, indicating that the employer was not found.\\
## Code: 
```
Employer findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
	}
```