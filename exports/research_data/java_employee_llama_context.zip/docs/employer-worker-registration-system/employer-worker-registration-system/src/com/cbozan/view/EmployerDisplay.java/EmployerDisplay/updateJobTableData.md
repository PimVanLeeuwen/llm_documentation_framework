`updateJobTableData`: The function of `updateJobTableData` is to update the job table data in the GUI by retrieving a list of jobs associated with the selected employer and displaying them in a table.

**Code Description**: This method retrieves a list of jobs from the database using the JobDAO instance, creates a 2D array to store the job data, populates the array with the retrieved job information, and updates the job table in the GUI with the new data. It also updates the job count label at the bottom of the table with the total number of jobs displayed.\\
## Code: 
```
void updateJobTableData() {
		
		if(selectedEmployer != null) {
			
			List<Job> jobList = JobDAO.getInstance().list(selectedEmployer);
			
			String[][] tableData = new String[jobList.size()][jobTableColumns.length];
			
			int i = 0;
			for(Job j : jobList) {
				
				tableData[i][0] = j.getId() + "";
				tableData[i][1] = j.getEmployer().toString();
				tableData[i][2] = j.getTitle();
				tableData[i][3] = j.getDescription();
				++i;
			}
			
			((JTable)jobScrollPane.getViewport().getComponent(0)).setModel(new DefaultTableModel(tableData, jobTableColumns));
			((JTable)jobScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setPreferredWidth(5);
			((JTable)jobScrollPane.getViewport().getComponent(0)).setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
			
			DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
			centerRenderer.setHorizontalAlignment( SwingConstants.CENTER );
			((JTable)jobScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
			
			jobCountLabel.setText(jobList.size() + " Kayıt");
		}
		
	}
```