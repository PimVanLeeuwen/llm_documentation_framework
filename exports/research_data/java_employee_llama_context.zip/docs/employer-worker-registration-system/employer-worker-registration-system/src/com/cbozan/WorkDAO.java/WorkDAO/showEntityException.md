**Expected Output**

`showEntityException`: The function of `showEntityException` is to display an error message to the user when there's an issue with adding a work entity.

**Parameters**:

`EntityException e`: This parameter represents the exception that occurred during the process of adding a work entity, providing detailed information about the error.

`String msg`: This parameter allows for a custom message to be displayed along with the exception details, giving context to the user about what went wrong.

**Code Description**: The `showEntityException` method takes an `EntityException` and a custom message as input. It constructs a comprehensive error message by combining the provided message with additional information from the exception (its message, localized message, and cause). This constructed message is then displayed to the user using a `JOptionPane`.\\
## Code: 
```
void showEntityException(EntityException e, String msg) {
		String message = msg + " not added" + 
				"\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + e.getCause();
			JOptionPane.showMessageDialog(null, message);
	}
```