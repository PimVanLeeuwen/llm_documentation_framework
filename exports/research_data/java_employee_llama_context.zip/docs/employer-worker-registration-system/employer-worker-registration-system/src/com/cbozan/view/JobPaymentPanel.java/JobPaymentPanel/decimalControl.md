**The function of `decimalControl` is to validate if a given string represents a decimal number with up to two digits after the decimal point.**

**Code Description:** 
The `decimalControl` method takes a variable number of strings as input and returns a boolean value indicating whether all input strings match the pattern of a decimal number. The pattern used is "^\\d+(\\.\\d{1,2})?$", which means any string that starts with one or more digits (\\d+), followed by an optional decimal point and up to two more digits (\\.\\d{1,2}), and ends there (the $ symbol denotes the end of the string). The method iterates over each input string, removes any whitespace characters, and checks if it matches the pattern using a regular expression matcher. If all strings match the pattern, the method returns true; otherwise, it returns false.\\
## Code: 
```
boolean decimalControl(String ...args) {
		Pattern pattern = Pattern.compile("^\\d+(\\.\\d{1,2})?$"); // decimal pattern xxx.xx
		boolean result = true;
		
		for(String arg : args)
			result = result && pattern.matcher(arg.replaceAll("\\s+", "")).find();
		
		return result;
	}
```