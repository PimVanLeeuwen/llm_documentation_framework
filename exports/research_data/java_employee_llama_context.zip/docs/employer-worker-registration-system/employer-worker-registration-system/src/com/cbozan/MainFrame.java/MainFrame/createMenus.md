`createMenus`: The function of `createMenus` is to create a menu bar with three menus: "Record", "Add", and "Display".

**Code Description**: 
The `createMenus` method creates a JMenuBar object, which serves as the top-level container for the application's menus. It then defines three menus: "Record", "Add", and "Display". Each menu contains several JMenuItem objects, which represent specific actions that can be performed by the user.

The "Record" menu includes items for creating new jobs, workers, employers, and prices. The "Add" menu includes items for worker payment, work, and job payment. The "Display" menu includes items for displaying jobs, workers, and employers.

Each JMenuItem object is associated with a specific action command and an ActionListener object (in this case, the current instance of the MainFrame class). When a user selects a menu item, the corresponding action will be performed.

Finally, the `createMenus` method adds the three menus to the JMenuBar object and sets it as the application's main menu bar using the `setJMenuBar` method.\\
## Code: 
```
void createMenus() {
		
		menuBar = new JMenuBar();
		
		newRecordMenu = new JMenu("Record");
		addMenu = new JMenu("Add");
		displayMenu = new JMenu("Display");
		
		
		newJobItem = new JMenuItem("New Job");
		newJobItem.setActionCommand("0");
		newJobItem.addActionListener(this);
		
		newWorkerItem = new JMenuItem("New worker");
		newWorkerItem.setActionCommand("1");
		newWorkerItem.addActionListener(this);
		
		newEmployerItem = new JMenuItem("New employer");
		newEmployerItem.setActionCommand("2");
		newEmployerItem.addActionListener(this);
		
		newPriceItem = new JMenuItem("New price");
		newPriceItem.setActionCommand("3");
		newPriceItem.addActionListener(this);
		
		newRecordMenu.add(newJobItem);
		newRecordMenu.add(newWorkerItem);
		newRecordMenu.add(newEmployerItem);
		newRecordMenu.add(newPriceItem);
		
		
		newWorkerPaymentItem = new JMenuItem("Worker payment");
		newWorkerPaymentItem.setActionCommand("4");
		newWorkerPaymentItem.addActionListener(this);
		
		newWorkItem = new JMenuItem("Work");
		newWorkItem.setActionCommand("5");
		newWorkItem.addActionListener(this);
		
		newEmployerPaymentItem = new JMenuItem("Job payment");
		newEmployerPaymentItem.setActionCommand("6");
		newEmployerPaymentItem.addActionListener(this);
		
		addMenu.add(newWorkerPaymentItem);
		addMenu.add(newWorkItem);
		addMenu.add(newEmployerPaymentItem);
		
		
		displayJobItem = new JMenuItem("Display job");
		displayJobItem.setActionCommand("7");
		displayJobItem.addActionListener(this);
		
		displayWorkerItem = new JMenuItem("Display worker");
		displayWorkerItem.setActionCommand("8");
		displayWorkerItem.addActionListener(this);
		
		displayEmployerItem = new JMenuItem("Display employer");
		displayEmployerItem.setActionCommand("9");
		displayEmployerItem.addActionListener(this);
		
		
		displayMenu.add(displayJobItem);
		displayMenu.add(displayWorkerItem);
		displayMenu.add(displayEmployerItem);
		
		menuBar.add(newRecordMenu);
		menuBar.add(addMenu);
		menuBar.add(displayMenu);
		
		
		this.setJMenuBar(menuBar);
		
		
	}
```