**The function of `createControl` is to check if a new payment type can be created in the system.**

**Parameters:**
`Paytype paytype`: The payment type object that needs to be checked for creation.

**Code Description:** 
The `createControl` method checks if a payment type with the same title already exists in the cache. If it does, an error message is set and the function returns false, indicating that the new payment type cannot be created. If no existing payment type with the same title is found, the function returns true, allowing the creation of the new payment type.\\
## Code: 
```
boolean createControl(Paytype paytype) {
		for(Entry<Integer, Paytype> obj : cache.entrySet()) {
			if(obj.getValue().getTitle().equals(paytype.getTitle())) {
				DB.ERROR_MESSAGE = obj.getValue().getTitle() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```