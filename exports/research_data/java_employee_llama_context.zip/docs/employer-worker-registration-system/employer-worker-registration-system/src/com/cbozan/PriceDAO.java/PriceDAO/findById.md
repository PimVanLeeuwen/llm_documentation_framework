`findById`: The function of `findById` is to retrieve a price from the cache or database by its unique identifier.

**Parameters**:\
`int id`: This parameter represents the unique identifier of the price to be retrieved.

**Code Description**: 
The `findById` method first checks if caching is enabled. If not, it calls the `list()` method to populate the cache with all prices from the database. It then checks if the specified ID exists in the cache. If it does, the corresponding price object is returned. If the ID is not found in the cache, the method returns null, indicating that the price was not found.\\
## Code: 
```
Price findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```