**toString**: The function of `toString` is to return a string representation of an object, in this case, the title of a job.

**Code Description**: This code defines a method named `toString` that returns the title of a job. It simply calls another method named `getTitle` and returns its result.\\
## Code: 
```
String toString() {
		return getTitle();
	}
```