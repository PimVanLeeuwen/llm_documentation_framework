`list`: The function of `list` is to retrieve a list of worktypes from the database, either by using cached data or by executing a SQL query.

**Code Description**: This code snippet defines a method called `list` in the `WorktypeDAO` class. It appears to be part of an employer-worker registration system, responsible for managing worktypes. The method is designed to return a list of worktypes, either by utilizing cached data or by executing a SQL query against a PostgreSQL database. If cache is available and enabled, it uses the cached data; otherwise, it clears the cache and executes the query to fetch all worktypes from the `worktype` table in the database. The retrieved worktypes are then added to the list and stored in the cache for future use.\\
## Code: 
```
List<Worktype> list(){
		
		List<Worktype> list = new ArrayList<>();
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Worktype> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM worktype;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorktypeBuilder builder;
			Worktype worktype;
			
			while(rs.next()) {
				
				builder = new WorktypeBuilder();
				builder.setId(rs.getInt("id"));
				builder.setTitle(rs.getString("title"));
				builder.setNo(rs.getInt("no"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					worktype = builder.build();
					list.add(worktype);
					cache.put(worktype.getId(), worktype);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id") + ", Title : " + rs.getString("title"));
				}
				
			}
			
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
		
	}
```