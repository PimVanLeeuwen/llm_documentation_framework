`findById`: Retrieves a worker from the database by their unique ID.
**Parameters**: 
`int id`: The ID of the worker to be retrieved.

**Code Description**: This method uses caching to improve performance. If cache is enabled and contains the requested worker, it returns the cached result. Otherwise, it calls the `list()` method to retrieve all workers from the database and checks if the requested worker exists in the list. If found, it caches the result for future use and returns the worker; otherwise, it returns null.\\
## Code: 
```
Worker findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```