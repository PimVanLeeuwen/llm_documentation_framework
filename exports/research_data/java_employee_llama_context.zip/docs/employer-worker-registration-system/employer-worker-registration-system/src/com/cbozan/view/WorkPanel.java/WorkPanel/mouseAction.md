## Expected output
`mouseAction`: The function of `mouseAction` is to handle mouse actions on the WorkPanel.
**Parameters**:\
`MouseEvent e`: This parameter represents a mouse event, such as a click or hover action.
`Object searchResultObject`: This object contains the result of a search operation.
`int chooseIndex`: This integer represents the index of the chosen item.

**Code Description**: The `mouseAction` method is called when a mouse event occurs on the WorkPanel. It adds the selected worker to the default list model, removes the searched object from the list, clears the text area, updates the label with the number of selected workers, and calls the superclass's `mouseAction` method.\\
## Code: 
```
void mouseAction(MouseEvent e, Object searchResultObject, int chooseIndex) {
				selectedWorkerDefaultListModel.addElement((Worker) searchResultObject);
				getObjectList().remove(searchResultObject);
				this.setText("");
				selectedInfoCountLabel.setText(selectedWorkerDefaultListModel.size() + " person");
				super.mouseAction(e, searchResultObject, chooseIndex);
			}
```