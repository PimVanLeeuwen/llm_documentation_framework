`list`: The function of `list` is to retrieve a list of Work objects from the database or cache, depending on the usage of the cache and its size.

**Code Description**: This code snippet is part of a DAO (Data Access Object) class in Java, specifically designed for interacting with a PostgreSQL database. It contains a method called `list`, which aims to fetch a collection of Work entities. The approach involves checking if there's data available in the cache; if so, it uses that instead of querying the database. If not, or if the cache is empty and caching is enabled, it clears the cache and executes a SQL query to retrieve all work records from the "work" table. Each record is then processed using a WorkBuilder object to create a corresponding Work entity, which is added to the list and stored in the cache for future use. If any EntityException occurs during this process, an error message is displayed. Finally, if any SQLExceptions occur while executing the SQL query, another error message is shown.\\
## Code: 
```
List<Work> list(){
		
		List<Work> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Work> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM work;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorkBuilder builder;
			Work work;
			
			while(rs.next()) {
				
				builder = new WorkBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setWorker_id(rs.getInt("worker_id"));
				builder.setWorktype_id(rs.getInt("worktype_id"));
				builder.setWorkgroup_id(rs.getInt("workgroup_id"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					work = builder.build();
					list.add(work);
					cache.put(work.getId(), work);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
	}
```