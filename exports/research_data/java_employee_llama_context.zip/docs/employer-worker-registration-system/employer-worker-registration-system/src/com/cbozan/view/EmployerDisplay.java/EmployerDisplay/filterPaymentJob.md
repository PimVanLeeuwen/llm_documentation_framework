`filterPaymentJob`: The function of `filterPaymentJob` is to filter out invoices that do not belong to the selected job.

**Parameters**: 
`List<Invoice> invoiceList`: A list of invoices to be filtered.

**Code Description**: This method iterates through a list of invoices and removes any invoice that does not match the ID of the currently selected job. If no job is selected, it simply returns without modifying the list.\\
## Code: 
```
void filterPaymentJob(List<Invoice> invoiceList) {
		
		if(selectedJob == null)
			return;
		
		Iterator<Invoice> invoice = invoiceList.iterator();
		Invoice invoiceItem;
		while(invoice.hasNext()) {
			invoiceItem = invoice.next();
			if(invoiceItem.getJob().getId() != selectedJob.getId()) {
				invoice.remove();
			}
		}
		
	}
```