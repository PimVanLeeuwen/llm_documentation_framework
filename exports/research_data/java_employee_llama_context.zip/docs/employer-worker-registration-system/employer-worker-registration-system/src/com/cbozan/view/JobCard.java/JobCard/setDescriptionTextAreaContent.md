`setDescriptionTextAreaContent`: The function of `setDescriptionTextAreaContent` is to set the text content of a text area and update the description of a selected job.

**Parameters**: 
`String description`: This parameter represents the new text content to be displayed in the text area and updated in the selected job's description.

**Code Description**: This method updates the text area with the provided description and also updates the description of the currently selected job, if one exists.\\
## Code: 
```
void setDescriptionTextAreaContent(String description) {
		this.descriptionTextArea.setText(description);
		
		if(getSelectedJob() != null)
			getSelectedJob().setDescription(description);
	}
```