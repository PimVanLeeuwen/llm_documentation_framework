`build`: The function of `build` is to create a new instance of the Job class, either with default values or using the provided parameters.

**Code Description**: 
The `build` method in the JobBuilder class creates a new Job object. If any of the required fields (employer and price) are null, it returns a new Job object with default values. Otherwise, it returns a new Job object with the specified id, employer, price, title, description, and date.\\
## Code: 
```
Job build() throws EntityException{
			if(this.employer == null || this.price == null)
				return new Job(this);
			return new Job(this.id, this.employer, this.price, this.title, this.description, this.date);
		}
```