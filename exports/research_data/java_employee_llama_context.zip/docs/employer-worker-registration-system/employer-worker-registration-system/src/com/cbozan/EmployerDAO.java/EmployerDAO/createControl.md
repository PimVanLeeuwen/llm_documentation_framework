**createControl**: The function of `createControl` is to check if an employer with the same first name and last name already exists in the cache before creating a new control.

**Parameters**: 
`Employer employer`: This method takes an instance of the `Employer` class as a parameter, which contains information about the employer such as their first name and last name.

**Code Description**: The code iterates through the entries in the cache, checking if there is already an entry with the same first name and last name as the provided `employer`. If such an entry exists, it sets an error message indicating that the employer's record already exists and returns false. If no matching entry is found, it returns true, allowing the creation of a new control.\\
## Code: 
```
boolean createControl(Employer employer) {
		
		for(Entry<Integer, Employer> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(employer.getFname())
					&& obj.getValue().getLname().equals(employer.getLname())) {
				
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		
		return true;
	}
```