`WorkgroupBuilder`: The function of `WorkgroupBuilder` is to create a Workgroup object by setting its attributes and then building the actual Workgroup instance.

**Code Description**: 
The `WorkgroupBuilder` class is used in a builder pattern to construct a `Workgroup` object. It provides methods to set various attributes such as ID, job ID, job, worktype ID, worktype, work count, description, and date. The `build()` method is then called to create the actual `Workgroup` instance based on the provided attributes. If all necessary attributes are not set (i.e., job and/or worktype), a new `Workgroup` object is created with default values or null for these attributes.\\
## Code: 
```
class WorkgroupBuilder {
		
		private int id;
		private int job_id;
		private Job job;
		private int worktype_id;
		private Worktype worktype;
		private int workCount;
		private String description;
		private Timestamp date;
		
		public WorkgroupBuilder() {}
		public WorkgroupBuilder(int id, int job_id, int worktype_id, int workCount, String description, Timestamp date) {
			this.id = id;
			this.job_id = job_id;
			this.worktype_id = worktype_id;
			this.workCount = workCount;
			this.description = description;
			this.date = date;
		}
		
		public WorkgroupBuilder(int id, Job job, Worktype worktype, int workCount, String description, Timestamp date) {
			this(id, 0, 0, workCount, description, date);
			this.job = job;
			this.worktype = worktype;
		}
		
		public WorkgroupBuilder setId(int id) {
			this.id = id;
			return this;
		}
		
		public WorkgroupBuilder setJob_id(int job_id) {
			this.job_id = job_id;
			return this;
		}
		
		public WorkgroupBuilder setJob(Job job) {
			this.job = job;
			return this;
		}
		
		public WorkgroupBuilder setWorktype_id(int worktype_id) {
			this.worktype_id = worktype_id;
			return this;
		}
		
		public WorkgroupBuilder setWorktype(Worktype worktype) {
			this.worktype = worktype;
			return this;
		}
		
		public WorkgroupBuilder setWorkCount(int workCount) {
			this.workCount = workCount;
			return this;
		}
		
		public WorkgroupBuilder setDescription(String description) {
			this.description = description;
			return this;
		}
		
		public WorkgroupBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Workgroup build() throws EntityException {
			if(job == null || worktype == null)
				return new Workgroup(this);
			return new Workgroup(id, job, worktype, workCount, description, date);
		}
		
	}
```