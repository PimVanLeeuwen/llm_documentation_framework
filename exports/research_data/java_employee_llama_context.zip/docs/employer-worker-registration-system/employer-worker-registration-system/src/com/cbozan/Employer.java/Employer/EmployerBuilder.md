**EmployerBuilder**: The function of `EmployerBuilder` is to create an instance of the `Employer` class with specified attributes.

**Code Description**: It provides a builder pattern implementation for creating an `Employer` object, allowing for fluent API usage and method chaining.\\
## Code: 
```
class EmployerBuilder{
		
		private int id;
		private String fname;
		private String lname;
		private List<String> tel;
		private String description;
		private Timestamp date;

		public EmployerBuilder() {}
		public EmployerBuilder(int id, String fname, String lname, List<String> tel, String description, Timestamp date) {
			super();
			this.id = id;
			this.fname = fname;
			this.lname = lname;
			this.tel = tel;
			this.description = description;
			this.date = date;
		}

		public EmployerBuilder setId(int id) {
			this.id = id;
			return this;
		}

		public EmployerBuilder setFname(String fname) {
			this.fname = fname;
			return this;
		}

		public EmployerBuilder setLname(String lname) {
			this.lname = lname;
			return this;
		}

		public EmployerBuilder setTel(List<String> tel) {
			this.tel = tel;
			return this;
		}

		public EmployerBuilder setDescription(String description) {
			this.description = description;
			return this;
		}

		public EmployerBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Employer build() throws EntityException {
			return new Employer(this);
		}		
		
	}
```