`createControl`: The function of `createControl` is to check if a worker with the same first name and last name already exists in the cache before creating a new control.

**Parameters**: 
`Worker worker`: This method takes an instance of the Worker class as a parameter, which contains information about the worker such as their first name and last name.

**Code Description**: The `createControl` method iterates through the entries in the cache. If it finds an entry with a matching first name and last name, it sets an error message indicating that the worker is already registered and returns false. If no match is found, it returns true, allowing the creation of a new control.\\
## Code: 
```
boolean createControl(Worker worker) {
		for(Entry<Integer, Worker> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(worker.getFname()) && obj.getValue().getLname().equals(worker.getLname())) {
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```