**toString**: The function of `toString` is to return a string representation of the Price object, including its fulltime, halftime, and overtime values.

**Code Description**: The `toString` method in the Price class returns a formatted string that displays the fulltime, halftime, and overtime values as separate items within parentheses. This allows for easy display or logging of the price details without requiring direct access to individual variables.\\
## Code: 
```
String toString() {
		return "(" + getFulltime() + ")  " + "(" + getHalftime() + ")  " + "(" + getOvertime() + ")";
	}
```