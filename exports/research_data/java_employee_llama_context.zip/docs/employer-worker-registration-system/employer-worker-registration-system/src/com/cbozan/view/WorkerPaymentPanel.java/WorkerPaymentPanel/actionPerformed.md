**Expected Output**

`actionPerformed`: When the payButton is clicked, this method handles the event and performs specific actions.
**Parameters**: `ActionEvent e`: The event that triggered the action performed by this method.
**Code Description**: This method checks if the selected worker, job, paytype, and amount are valid. If so, it creates a payment object using the provided details and attempts to save it to the database. If successful, it notifies all observers of the registration completion.

**Analysis**

The `actionPerformed` method is triggered when the payButton is clicked. It first checks if the selected worker, job, paytype, and amount are valid by calling the `decimalControl` method to ensure the amount is correctly formatted. If any of these selections or formatting are invalid, it displays an error message.

If all inputs are valid, it creates a payment object using the provided details (worker, job, paytype, and amount) and attempts to save it to the database using the `PaymentDAO` instance's `create` method. If the registration is successful, it notifies all observers by calling the `notifyAllObservers` method.

The method also displays a confirmation dialog with the selected worker, job, paytype, and amount details for review before proceeding with the payment creation and saving process.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		if(e.getSource() == payButton) {
			
			Worker worker;
			Job job;
			Paytype paytype;
			String amount;
			
			worker = selectedWorker;
			job = selectedJob;
			paytype = (Paytype) paytypeComboBox.getSelectedItem();
			amount = amountTextField.getText().replaceAll("\\s+", "");

			if(!decimalControl(amount) || worker == null || job == null || paytype == null) {
				
				String message;
				message = "Please enter selection parts or format correctly (max 2 floating point)";
				JOptionPane.showMessageDialog(this, message, "ERROR", JOptionPane.ERROR_MESSAGE);
				
			} else {
				
				JTextArea workerTextArea, jobTextArea, paytypeTextArea, amountTextArea;
				
				workerTextArea = new JTextArea(worker.toString());
				workerTextArea.setEditable(false);
				
				jobTextArea = new JTextArea(job.toString());
				jobTextArea.setEditable(false);
				
				paytypeTextArea = new JTextArea(paytype.toString());
				paytypeTextArea.setEditable(false);
				
				amountTextArea = new JTextArea(amount + " ₺");
				amountTextArea.setEditable(false);
				
				Object[] pane = {
						new JLabel("Worker"),
						workerTextArea,
						new JLabel("Job"),
						jobTextArea,
						new JLabel("Payment method"),
						paytypeTextArea,
						new JLabel("Amount of payment"),
						amountTextArea
				};
		
				int result = JOptionPane.showOptionDialog(this, pane, "Confirmation", 1, 1, 
						new ImageIcon("src\\icon\\accounting_icon_1_32.png"), new Object[] {"SAVE", "CANCEL"}, "CANCEL");
				
				
				// System.out.println(result);
				// 0 -> SAVE
				// 1 -> CANCEL
				
				if(result == 0) {
					
					Payment.PaymentBuilder builder = new Payment.PaymentBuilder();
					builder.setId(Integer.MAX_VALUE);
					builder.setWorker(worker);
					builder.setJob(job);
					builder.setPaytype(paytype);
					builder.setAmount(new BigDecimal(amount));
					
					Payment payment = null;
					try {
						payment = builder.build();
					} catch (EntityException e1) {
						System.out.println(e1.getMessage());
					}
					
					if(PaymentDAO.getInstance().create(payment)) { 
						JOptionPane.showMessageDialog(this, "Registraion successful");
						notifyAllObservers();
					} else {
						JOptionPane.showMessageDialog(this, "Not saved", "Database error", JOptionPane.ERROR_MESSAGE);
					}
				}
				
			}
			
			
		}
		
	}
```