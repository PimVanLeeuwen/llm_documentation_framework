**PaytypeBuilder**: The function of `PaytypeBuilder` is to create a Paytype object by setting its id, title, and date fields.

**Code Description**: 
The `PaytypeBuilder` class is used to construct a `Paytype` object. It provides methods to set the id, title, and date of the paytype, allowing for method chaining to simplify the construction process. The `build()` method is then called to create the final `Paytype` object with the specified details.\\
## Code: 
```
class PaytypeBuilder {
		
		private int id;
		private String title;
		private Timestamp date;
		
		public PaytypeBuilder() {}
		public PaytypeBuilder(int id, String title, Timestamp date) {
			this.id = id;
			this.title = title;
			this.date = date;
		}
		
		public PaytypeBuilder setId(int id) {
			this.id = id;
			return this;
		}
		
		public PaytypeBuilder setTitle(String title) {
			this.title = title;
			return this;
		}
		
		public PaytypeBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Paytype build() throws EntityException {
			return new Paytype(this);
		}
		
	}
```