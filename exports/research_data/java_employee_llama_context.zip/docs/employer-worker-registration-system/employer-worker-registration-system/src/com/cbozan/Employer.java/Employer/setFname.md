`setFname`: The function of `setFname` is to set the first name (fname) of an employer.

**Parameters**: 
`String fname`: This parameter represents the first name of the employer, which can be any string value.

**Code Description**: 
The `setFname` method checks if the provided first name is not empty and does not exceed a certain length limit defined by `DBConst.FNAME_LENGTH`. If either condition is met, it throws an `EntityException` with a message indicating that the employer's name is empty or too long. Otherwise, it sets the `fname` field of the current employer object to the provided value.\\
## Code: 
```
void setFname(String fname) throws EntityException {
		if(fname.length() == 0 || fname.length() > DBConst.FNAME_LENGTH)
			throw new EntityException("Employer name empty or too long");
		this.fname = fname;
	}
```