`findById`: The function of `findById` is to retrieve a payment by its ID from the cache or database.

**Parameters**:\
`int id`: This parameter represents the unique identifier of the payment to be retrieved.

**Code Description**: 
The `findById` method first checks if caching is enabled. If not, it calls the `list()` method to populate the cache with all payments. It then checks if a payment with the specified ID exists in the cache. If it does, the cached payment is returned. Otherwise, the method returns null, indicating that no payment was found with the given ID.\\
## Code: 
```
Payment findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```