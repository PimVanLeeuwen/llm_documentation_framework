**WorktypeBuilder**: The function of `WorktypeBuilder` is to create a Worktype object by setting its attributes and then building it.

**Code Description**: It's a builder class that allows for the creation of Worktype objects in a step-by-step manner, providing a fluent API for setting various attributes such as id, title, no, and date. The build method returns an instance of Worktype once all necessary information has been provided.\\
## Code: 
```
class WorktypeBuilder {
		private int id;
		private String title;
		private int no;
		private Timestamp date;
		
		public WorktypeBuilder() {}
		public WorktypeBuilder(int id, String title, int no, Timestamp date) {
			this.id = id;
			this.title = title;
			this.no = no;
			this.date = date;
		}
		
		public WorktypeBuilder setId(int id) {
			this.id = id;
			return this;
		}
		
		public WorktypeBuilder setTitle(String title) {
			this.title = title;
			return this;
		}
		
		public WorktypeBuilder setNo(int no) {
			this.no = no;
			return this;
		}
		
		public WorktypeBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Worktype build() throws EntityException {
			return new Worktype(this);
		}
		
	}
```