`getLname`: The function of `getLname` is to return the last name of an employer.

**Code Description**: This method, `getLname`, is a getter method in Java that retrieves and returns the value of the instance variable `lname`. It does not modify or update any data; its sole purpose is to provide access to the stored last name.\\
## Code: 
```
String getLname() {
		return lname;
	}
```