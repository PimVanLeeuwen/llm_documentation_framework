`notifyAllObservers`: The function of `notifyAllObservers` is to notify all registered observers that new data is available, triggering an update in their respective views.

**Code Description**: This method iterates through a list of registered observers and calls the `update()` method on each one, effectively notifying them that fresh data is ready.\\
## Code: 
```
void notifyAllObservers() {
		for(Observer observer : observers) {
			observer.update();
		}
	}
```