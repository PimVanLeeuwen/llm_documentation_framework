`update`: The function of `update` is to refresh and update the display with the latest data from the database, specifically for an employer selected by the user.

**Code Description**: This method updates the Employer Display view by refreshing the list of employers in the search box, updating the job table data, and updating the employer payment table data. It also reloads the employer card with the newly selected employer's information.\\
## Code: 
```
void update() {
		employerSearchBox.setObjectList(EmployerDAO.getInstance().list());
		selectedEmployer = employerCard.getSelectedEmployer();
		employerSearchBox.setText(selectedEmployer == null ? "" : selectedEmployer.toString());
		JobDAO.getInstance().refresh();
		InvoiceDAO.getInstance().refresh();
		updateJobTableData();
		updateEmployerPaymentTableData();
		employerCard.reload();
	}
```