**DBConst**: The function of `DBConst` is to define constants for database-related field lengths, specifically for first name (`FNAME_LENGTH`) and last name (`LNAME_LENGTH`).

**Code Description**: The `DBConst` class contains two public static final integer variables: `FNAME_LENGTH` and `LNAME_LENGTH`, which are set to 30 and 20 respectively. These constants can be used throughout the application to enforce a consistent maximum length for first names and last names in database fields or other data storage contexts.\\
## Code: 
```
class DBConst {
	public static final int FNAME_LENGTH = 30;
	public static final int LNAME_LENGTH = 20;
}
```