`update`: The function of `update` is to update a price record in the database.

**Parameters**:\
`Price price`: This method takes an object of type Price as input, which contains information about the price to be updated.

**Code Description**: 
This code updates a price record in the database by executing an SQL UPDATE query. It first checks if the new price record already exists in the cache using the `updateControl` method. If it does not exist, it proceeds with updating the record in the database. The update process involves setting the values of fulltime, halftime, and overtime to the corresponding values from the input Price object, and then executing the UPDATE query using a PreparedStatement. If the update is successful, it updates the cache by putting the updated price into the cache.\\
## Code: 
```
boolean update(Price price) {
		
		if(updateControl(price) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE price SET fulltime=?,"
				+ "halftime=?, overtime=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setBigDecimal(1, price.getFulltime());
			pst.setBigDecimal(2, price.getHalftime());
			pst.setBigDecimal(3, price.getOvertime());
			pst.setInt(4, price.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(price.getId(), price);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```