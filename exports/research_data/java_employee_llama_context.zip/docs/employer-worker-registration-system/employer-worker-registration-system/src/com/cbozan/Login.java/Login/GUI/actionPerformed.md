**Expected Output**
`actionPerformed`: The function of `actionPerformed` is to handle the action performed on a GUI component, such as a button click.
**Parameters**: 
`ActionEvent e`: This parameter represents the event that triggered the action performed method, which can be used to determine what action was taken.
**Code Description**: This code checks if the username and password fields are empty, and if so, displays an error message. If not, it verifies the login credentials with a LoginDAO object and either displays a success message or an error message depending on the result.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		
				if(textField_username.getText().equals("") || String.valueOf(passwordField_password.getPassword()).equals("")) {
					
					label_errorText.setText(errorText);
				
				} else {
					
					label_errorText.setText("");
					LoginDAO loginDAO = new LoginDAO();
					if(loginDAO.verifyLogin(textField_username.getText(), 
							String.valueOf(passwordField_password.getPassword()))) {
						JOptionPane.showMessageDialog(contentPane, "Login successful. Welcome", "Login", 
								JOptionPane.INFORMATION_MESSAGE);
						
						EventQueue.invokeLater(new Runnable() {
							@Override
							public void run() {
								Login.this.dispose();
								new MainFrame();
							}
						});
						
					} else {
						label_errorText.setText(errorText);
					}
					
				}
				
			}
```