`update`: Updates an existing invoice in the database with new job ID and amount details.

**Parameters**: Invoice object containing updated job ID and amount, as well as the original invoice ID.

**Code Description**: This method establishes a connection to the PostgreSQL database using JDBC, prepares a SQL query to update the specified invoice with new job ID and amount values, executes the query, and updates the cache if the update is successful. If an SQLException occurs during execution, it displays a message dialog box showing detailed information about the exception. The method returns true if the update is successful (i.e., result != 0) and false otherwise.\\
## Code: 
```
boolean update(Invoice invoice) {
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE invoice SET job_id=?,"
				+ "amount=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, invoice.getJob().getId());
			pst.setBigDecimal(2, invoice.getAmount());
			pst.setInt(5, invoice.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(invoice.getId(), invoice);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```