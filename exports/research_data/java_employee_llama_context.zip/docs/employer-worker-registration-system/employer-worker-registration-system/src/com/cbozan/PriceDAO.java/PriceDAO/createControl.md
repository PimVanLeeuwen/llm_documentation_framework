`createControl`: The function of `createControl` is to check if a new price record already exists in the cache with the same fulltime, halftime, and overtime values.

**Parameters**: 
`Price price`: This method takes an object of type Price as input, which contains the fulltime, halftime, and overtime values to be checked against existing records in the cache.

**Code Description**: The `createControl` method iterates through the entries in the cache and checks if any existing record has the same fulltime, halftime, and overtime values as the input price object. If a matching record is found, it returns false and sets an error message indicating that the price record already exists. If no matching record is found, it returns true, indicating that the new price record can be created.\\
## Code: 
```
boolean createControl(Price price) {
		for(Entry<Integer, Price> obj : cache.entrySet()) {
			if(obj.getValue().getFulltime().compareTo(price.getFulltime()) == 0
					&& obj.getValue().getHalftime().compareTo(price.getHalftime()) == 0
					&& obj.getValue().getOvertime().compareTo(price.getOvertime()) == 0) {
				
				DB.ERROR_MESSAGE = "Bu fiyat bilgisi kaydı zaten mevcut.";
				return false;
			}
		}
		
		return true;
	}
```