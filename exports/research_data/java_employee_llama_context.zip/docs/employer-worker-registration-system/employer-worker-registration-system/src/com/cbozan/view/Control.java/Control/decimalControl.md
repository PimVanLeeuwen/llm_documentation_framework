**The function of decimalControl is to validate a set of strings against a given regular expression pattern.**

**Parameters:**
- `Pattern pattern`: This parameter represents the regular expression pattern used for validation.
 
**Code Description:** The `decimalControl` method takes in a `Pattern` object and a variable number of string arguments. It iterates over each string argument, uses the provided `Pattern` to create a matcher, and checks if the string matches the pattern using the `find()` method. If any string does not match the pattern, the method returns `false`. Otherwise, it returns `true`, indicating that all strings match the given pattern.\\
## Code: 
```
boolean decimalControl(Pattern pattern, String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= pattern.matcher(arg).find();
		}
		return rValue;
	}
```