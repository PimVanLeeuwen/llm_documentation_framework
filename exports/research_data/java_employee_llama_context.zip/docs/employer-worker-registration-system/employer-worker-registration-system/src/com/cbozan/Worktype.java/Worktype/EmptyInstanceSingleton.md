## EmptyInstanceSingleton: 
The function of `EmptyInstanceSingleton` is to provide a singleton instance of the `Worktype` class.

## Code Description:
`EmptyInstanceSingleton` is a class that holds a static final instance of the `Worktype` class. The instance is created when the class is loaded, and it remains the same for all threads. This means that only one instance of `Worktype` will be created, and it can be accessed through the `instance` variable.\\
## Code: 
```
class EmptyInstanceSingleton{
		private static final Worktype instance = new Worktype(); 
	}
```