`findById`: The function of `findById` is to retrieve a job from the cache or database by its unique identifier.

**Parameters**:\
`int id`: This method takes an integer parameter representing the ID of the job to be retrieved.

**Code Description**: 
The `findById` method first checks if caching is enabled. If not, it calls the `list()` method to retrieve a list of jobs from the database. It then checks if the cache contains a job with the specified ID. If it does, it returns the cached job. If not, it returns null, indicating that the job was not found in the cache or database.\\
## Code: 
```
Job findById(int id) {
		
		if(usingCache == false)
			list();
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```