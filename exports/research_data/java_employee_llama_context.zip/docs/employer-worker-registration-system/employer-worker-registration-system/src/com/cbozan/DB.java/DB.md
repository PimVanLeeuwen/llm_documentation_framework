**The function of `DB` is to manage database connections.**

**Code Description:** 
The DB class serves as a singleton, providing a static instance that handles database connection management. It includes methods for establishing and closing connections, ensuring efficient reuse of existing connections when possible. The DBHelper inner class holds the static instance of the DB object, guaranteeing its creation only once throughout the application's execution.\\
## Code: 
```
class DB {

	public static String ERROR_MESSAGE = "";
	
	private DB() {}
	private Connection conn = null;
	
	private static class DBHelper{
		private static final DB CONNECTION = new DB();
	}
	
	public static Connection getConnection() {
		return DBHelper.CONNECTION.connect();
	}
	
	public static void destroyConnection() {
		DBHelper.CONNECTION.disconnect();
	}

	private Connection connect() {
		
		try {
			if(conn == null || conn.isClosed()) {
				try {
					conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Hesap-eProject", "Hesap-eProject", ".hesap-eProject.");
				} catch (SQLException e) {
					System.err.println(e.getMessage());
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return conn;
	}
	
	private void disconnect() {
		if(conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				System.err.println(e.getMessage());
			}
		}
	}

	
}
```