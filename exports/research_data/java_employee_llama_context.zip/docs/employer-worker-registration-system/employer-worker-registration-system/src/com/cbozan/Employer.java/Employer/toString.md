**The function of `toString` is to return a string representation of an employer's name, which is the concatenation of their first and last names.**

**Code Description: The `toString` method in the Employer class returns a string that combines the first name (fname) and last name (lname) of an employer, effectively creating a full name string. This method is likely used for displaying or logging purposes, providing a human-readable representation of the employer's identity.**\\
## Code: 
```
String toString() {
		return getFname() + " " + getLname();
	}
```