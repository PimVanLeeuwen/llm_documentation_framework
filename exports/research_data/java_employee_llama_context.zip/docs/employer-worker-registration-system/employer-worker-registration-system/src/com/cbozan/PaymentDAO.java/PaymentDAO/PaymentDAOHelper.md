## PaymentDAOHelper: 
The function of `PaymentDAOHelper` is to provide a singleton instance of the `PaymentDAO` class.

## Code Description:
The `PaymentDAOHelper` class serves as a helper for managing instances of the `PaymentDAO` class. It creates and holds a single instance of `PaymentDAO`, which can be accessed through the `instance` variable. This design pattern is known as the Singleton Pattern, where only one object of a particular class is created throughout the application's lifetime.\\
## Code: 
```
class PaymentDAOHelper {
		private static final PaymentDAO instance = new PaymentDAO();
	}
```