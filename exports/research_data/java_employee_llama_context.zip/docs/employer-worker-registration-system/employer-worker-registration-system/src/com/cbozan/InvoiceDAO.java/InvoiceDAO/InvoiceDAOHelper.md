## InvoiceDAOHelper: 
The function of `InvoiceDAOHelper` is to provide a singleton instance of the `InvoiceDAO` class.

## Code Description:
The `InvoiceDAOHelper` class serves as a helper for managing instances of the `InvoiceDAO` class. It creates and holds a single instance of `InvoiceDAO`, which can be accessed through the `instance` variable. This design pattern is known as the Singleton Pattern, where only one object of a particular class is created throughout the application's lifetime.\\
## Code: 
```
class InvoiceDAOHelper {
		private static final InvoiceDAO instance = new InvoiceDAO();
	}
```