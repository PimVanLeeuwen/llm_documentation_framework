`secondsInADay`: The function of `secondsInADay` is to calculate the total number of seconds in a day.

**Code Description**: This function uses a mathematical formula to compute the total number of seconds in 24 hours, where each hour has 3600 seconds. It returns this calculated value as a long unsigned integer.\\
## Code: 
```
static constexpr long unsigned secondsInADay() {
    return 24 * 3600;
  }
```