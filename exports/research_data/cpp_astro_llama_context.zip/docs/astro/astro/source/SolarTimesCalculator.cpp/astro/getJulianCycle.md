`getJulianCycle`: The function of `getJulianCycle` is to calculate the Julian cycle number.

**Parameters**:
`const JulianDate &date`: This parameter represents a date in the Julian Date system.
`angle_type longitudeEast`: This parameter represents the longitude east angle, which is used to adjust the Julian cycle calculation.

**Code Description**: The function uses the `std::round` function to round the result of the expression `(date.truncated2000() - C::get<PLANET, C::J0>()) / C::get<PLANET, C::J3>() + longitudeEast / 2_pi_rad`. This expression calculates the Julian cycle number by subtracting a reference value (`C::get<PLANET, C::J0>()`) from the truncated year of the input date, dividing the result by another reference value (`C::get<PLANET, C::J3>()`), and then adding the longitude east angle divided by `2_pi_rad`. The result is rounded to the nearest integer using `std::round`, which returns a `float_type` value.\\
## Code: 
```
static float_type getJulianCycle(const JulianDate &date, angle_type longitudeEast) {
    return std::round(
        (date.truncated2000() - C::get<PLANET, C::J0>()) / C::get<PLANET, C::J3>() +
         longitudeEast / 2_pi_rad);
  }
```