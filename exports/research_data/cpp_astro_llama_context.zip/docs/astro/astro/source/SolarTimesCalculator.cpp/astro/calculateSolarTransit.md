`calculateSolarTransit`: The function calculates the solar transit time for a given planet.

**Parameters**: `const angle_type hourAngle`: This parameter represents the hour angle, which is used to calculate the solar transit time.

**Code Description**: The code uses various mathematical formulas and constants (J0, J1, J2, J3) to estimate and refine the solar transit time. It takes into account the observer's position, the sun's mean anomaly, and the ecliptical longitude of the sun. The result is a Julian Date representing the solar transit time.\\
## Code: 
```
JulianDate SolarTimesCalculator<PLANET>::calculateSolarTransit(const angle_type hourAngle) const {
    const auto longitudeEast = _sun._observer.getPosition().longitude;
    const auto meanAnomaly = _sun._sun.getMeanAnomaly();
    const auto eclipticLongitudeOfTheSun = _sun.getEclipticalLongitude();

    const auto estimatedTransit =
        C::get<PLANET, C::J0>() +
        C::get<PLANET, C::J3>() * (_cycle + (hourAngle - longitudeEast) / 2_pi_rad);
    const auto transit =
        estimatedTransit +
        C::get<PLANET, C::J1>() * math::Sin(meanAnomaly) +
        C::get<PLANET, C::J2>() * math::Sin(2.0 * eclipticLongitudeOfTheSun);
    // transit -= J3 * H(transit) / 360_deg // @todo repeat to improve precision
    return JulianDate::fromTruncated2000(transit);
  }
```