`getRightAscension`: The function of `getRightAscension` is to calculate the right ascension of a celestial body.

**Code Description**: This code calculates the right ascension in astronomy using trigonometric functions. It takes three angles as input: longitude, latitude, and ecliptic longitude, and returns a value representing the right ascension. The function `getRightAscension` is part of the `SolarDescription` class, which is used to describe solar system objects. The method calls another function `rightAscension` from the `Trigonometry` class, passing in the ecliptical longitude and obliquity of the planet as arguments. This suggests that the right ascension is calculated based on the position of the planet in its orbit around the Sun.\\
## Code: 
```
angle_type SolarDescription<PLANET>::getRightAscension() const {
    return Trigonometry::rightAscension(_eclipticalLongitude, C::get<PLANET, C::Obliquity>());
  }
```