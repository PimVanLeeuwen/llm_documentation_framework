## Expected output
`azimuth`: The function of `azimuth` is to calculate the azimuth angle.
**Parameters**:
`angle_type h`: The hour angle, which is the angular distance between the observer's local meridian and the object's right ascension.
`angle_type decl`: The declination, which is the angular distance between the object's position in the sky and the celestial equator.
`angle_type lat`: The latitude of the observer's location on Earth.

**Code Description**: This function uses trigonometric functions to calculate the azimuth angle based on the given hour angle, declination, and latitude. It employs the ATan2 function to compute the arctangent of a ratio, which is then used in conjunction with sine and cosine functions to determine the azimuth angle.\\
## Code: 
```
angle_type Trigonometry::azimuth(angle_type h, angle_type decl, angle_type lat) {
    return ATan2(Sin(h), Cos(h) * Sin(lat) - Tan(decl) * Cos(lat));
  }
```