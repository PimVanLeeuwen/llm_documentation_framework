## Expected output
`altitude`: The function of `altitude` is to calculate the altitude angle.
**Parameters**:
`angle_type h`: The hour angle, which is the angular distance between the observer's local meridian and the object's right ascension.
`angle_type decl`: The declination, which is the angular distance between the object's position in the sky and the celestial equator.
`angle_type lat`: The latitude of the observer's location on Earth.

**Code Description**: This function uses trigonometric functions to calculate the altitude angle based on the hour angle, declination, and latitude. It first calculates the cosine of the hour angle, then multiplies it by the cosines of the declination and latitude, and finally adds the product of the sine of the declination and the sine of the latitude. The result is passed to the ASin function to obtain the altitude angle in radians.\\
## Code: 
```
angle_type Trigonometry::altitude(angle_type h, angle_type decl, angle_type lat) {
    return ASin(Cos(h) * Cos(decl) * Cos(lat) + Sin(decl) * Sin(lat));
  }
```