## Expected output
`rightAscension`: The function of `rightAscision` is to calculate the right ascension of a celestial object.
**Parameters**:
`angle_type l`: The local sidereal time (in radians).
`angle_type b`: The declination (in radians) of the celestial object.
`angle_type e`: The eccentricity (in radians) of the celestial object's orbit.

**Code Description**: This function uses trigonometric functions to calculate the right ascension based on the given parameters. It utilizes the ATan2 and Sin functions from the Trigonometry class to perform the calculation, which involves a combination of sine and cosine operations. The result is returned as an angle_type value.\\
## Code: 
```
angle_type Trigonometry::rightAscension(angle_type l, angle_type b, angle_type e) {
    return ATan2(Sin(l) * Cos(e) - Tan(b) * Sin(e), Cos(l));
  }
```