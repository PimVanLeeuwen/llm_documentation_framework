## Expected output
`declination`: The function of `declination` is to calculate the declination angle.
**Parameters**:\
`angle_type l`: The local hour angle, which is the difference between the object's right ascension and the observer's local sidereal time.
`angle_type b`: The object's latitude in the celestial coordinate system.
`angle_type e`: The object's longitude in the celestial coordinate system.

**Code Description**: This function uses trigonometric functions to calculate the declination angle based on the given parameters. It first calculates the sine of the latitude and longitude, then applies various cosine and sine operations to these values before finally taking the arcsine (inverse sine) of the result to obtain the declination angle.\\
## Code: 
```
angle_type Trigonometry::declination(angle_type l, angle_type b, angle_type e) {
    return ASin(Sin(b) * Cos(e) + Cos(b) * Sin(e) * Sin(l));
  }
```