# PROMPT
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/SolarTimesCalculator.cpp/astro` \
**Type:** `Method` \
**Method Name:** `SolarTimesCalculator` \
**Code Content:** \
`SolarTimesCalculator<PLANET>::SolarTimesCalculator(const Sun<PLANET> &sun) :
    _sun(sun),
    _cycle(getJulianCycle<PLANET>(
        _sun._observer.getDate(),
        _sun._observer.getPosition().longitude)),
    _transit(calculateSolarTransit(0_rad)) {}`

## Calls 
 This code calls the following methods within the repository: 
### astro/astro/source/SolarTimesCalculator.cpp/astro.getJulianCycle 
 - Explanation:  _This code calculates the Julian cycle, which is a measure of time used in astronomy, given a date and longitude. It uses a formula involving the truncated year 2000, a constant, and the longitude to compute the result._ 
### astro/astro/source/SolarTimesCalculator.cpp/astro.calculateSolarTransit 
 - Explanation:  _This code calculates the solar transit time for a given planet, taking into account various astronomical parameters such as longitude, mean anomaly, and ecliptical longitude. The result is returned as a Julian Date value._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`SolarTimesCalculator`: The function of `SolarTimesCalculator` is *FILL IN* 
**Parameters**:\
`const Sun<PLANET> &sun`: *FILL IN* \

**Code Description**: *FILL IN*
