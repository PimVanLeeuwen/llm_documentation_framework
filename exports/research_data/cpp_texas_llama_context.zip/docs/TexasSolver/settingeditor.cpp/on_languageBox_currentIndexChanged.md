## on_languageBox_currentIndexChanged: 
The function of `on_languageBox_currentIndexChanged` is to display a message box when the language selection in the program changes.

## Parameters:
`int index`: The index of the selected language in the language box.

## Code Description:
When the current index of the language box changes, the function checks if the program has been initialized. If it has, it displays a message box with a restart prompt to make the language selection effective.\\
## Code: 
```
void SettingEditor::on_languageBox_currentIndexChanged(int index)
{
    if(!initized)return;
    QString message = tr("Restart program to make language selection effective.");
    qDebug().noquote() << message;
    QMessageBox msgBox;
    msgBox.setText(message);
    msgBox.exec();
}
```