## on_cancelButton_clicked: 
The function of `on_cancelButton_clicked` is to close the current window when the cancel button is clicked.

## Code Description:
When the cancel button is clicked, this function is triggered. It simply calls the `close()` method on the current object (`this`), which closes the window associated with the `boardselector` class instance.\\
## Code: 
```
void boardselector::on_cancelButton_clicked()
{
    this->close();
}
```