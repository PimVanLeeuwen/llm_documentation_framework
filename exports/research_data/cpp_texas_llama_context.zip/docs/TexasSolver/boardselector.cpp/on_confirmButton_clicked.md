## on_confirmButton_clicked: 
The function of `on_confirmButton_clicked` is to confirm the selection made in the board selector and close the current window.

## Code Description:
When the confirm button is clicked, this function updates the text of a field called `boardEdit` with the selected value from the UI's `boardEdit` field. It then closes the current window.\\
## Code: 
```
void boardselector::on_confirmButton_clicked()
{
    this->boardEdit->setText(this->ui->boardEdit->text());
    this->close();
}
```