`boardselector`: The function of `boardselector` is to create a dialog window for selecting a board in a poker game.

**Parameters**:
`QTextEdit* boardEdit`: This parameter is a pointer to a text edit widget where the user can input or display the current board configuration.
`QSolverJob::Mode mode`: This parameter specifies the type of poker game being played, which affects the available ranks for selection.
`QWidget *parent`: This parameter is a pointer to the parent widget that owns this dialog window.

**Code Description**: The `boardselector` function creates a new instance of the `BoardSelector` class, which inherits from `QDialog`. It sets up the UI components, including a table model and delegate for displaying the available ranks. The function also initializes the rank list based on the specified game mode and populates the table with the available ranks.\\
## Code: 
```
boardselector::boardselector(QTextEdit* boardEdit,QSolverJob::Mode mode,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::boardselector)
{
    ui->setupUi(this);
    this->setWindowTitle(tr("BoardSelector"));
    this->boardEdit = boardEdit;
    this->mode = mode;

    QString ranks;
    if(mode == QSolverJob::Mode::HOLDEM){
        ranks = "A,K,Q,J,T,9,8,7,6,5,4,3,2";
    }else if(mode == QSolverJob::Mode::SHORTDECK){
        ranks = "A,K,Q,J,T,9,8,7,6";
    }else{
        throw runtime_error("mode not found in range selector");
    }
    this->rank_list = ranks.split(",");

    this->boardSelectorTableModel = new BoardSelectorTableModel(this->rank_list,boardEdit->toPlainText(),this);
    this->ui->boardSelectorTable->setModel(boardSelectorTableModel);
    this->boardSelectorTableDelegate = new BoardSelectorTableDelegate(this->rank_list,this->boardSelectorTableModel,this);
    this->ui->boardSelectorTable->setItemDelegate(this->boardSelectorTableDelegate);
    this->ui->boardEdit->setText(boardEdit->toPlainText());
}
```