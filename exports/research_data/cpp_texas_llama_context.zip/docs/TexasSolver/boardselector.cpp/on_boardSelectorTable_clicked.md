`on_boardSelectorTable_clicked`: When a table cell in the board selector table is clicked, this function toggles the state of the corresponding board position.

**Parameters**: 
`const QModelIndex &index`: The index of the clicked table cell.

**Code Description**: This function retrieves the row and column indices from the `QModelIndex` object passed as an argument. It then uses these indices to toggle the state of the board at that position by calling the `setBoardAt` method on the `boardSelectorTableModel`. If the text in the `boardEdit` field does not match the current board text, it updates the `boardEdit` field with the new board text. Finally, it sets focus back to the `boardEdit` and `boardSelectorTable` widgets.\\
## Code: 
```
void boardselector::on_boardSelectorTable_clicked(const QModelIndex &index)
{
    int row = index.row();
    int col = index.column();
    this->boardSelectorTableModel->setBoardAt(row,col,1 - this->boardSelectorTableModel->getBoardAt(row,col));
    if(this->ui->boardEdit->text() != this->boardSelectorTableModel->getBoardText()){
        this->ui->boardEdit->setText(this->boardSelectorTableModel->getBoardText());
    }
    this->ui->boardEdit->setFocus();
    this->ui->boardSelectorTable->setFocus();
}
```