`on_clearBoardButton_clicked`: The function of `on_clearBoardButton_clicked` is to clear the board by resetting all elements.

**Code Description**: When the "Clear Board" button is clicked, this function clears the current board state by calling the `clear_board()` method on the `boardSelectorTableModel`, clearing the text in the `boardEdit` field, updating and focusing the `boardSelectorTable`, and finally setting focus to the `boardEdit` field.\\
## Code: 
```
void boardselector::on_clearBoardButton_clicked()
{
    this->boardSelectorTableModel->clear_board();
    this->ui->boardEdit->clear();
    this->ui->boardSelectorTable->update();
    this->ui->boardSelectorTable->setFocus();
    this->ui->boardEdit->setFocus();
}
```