`triger_resize`: The function of `triger_resize` is to trigger a resize event in the HtmlTableView class, resizing its columns and rows proportionally among them.

**Code Description**: This code snippet appears to be part of a GUI application written in C++. It defines a method called `triger_resize` within the `HtmlTableView` class. The purpose of this method is to handle changes in the size of the table view by triggering a resize event. When triggered, it creates a new `QResizeEvent` object with the current size of the table view and passes it to the `resizeEvent` method for processing. After processing, the event is deleted.\\
## Code: 
```
void HtmlTableView::triger_resize(){
    QResizeEvent* ev = new QResizeEvent(this->size(),this->size());
    this->resizeEvent(ev);
    //this->resize(this->parentWidget()->size());
    delete ev;
}
```