`eventFilter`: The function of `eventFilter` is to filter events for the HtmlTableView object.

**Parameters**:
`QObject *watched`: The QObject that triggered the event.
`QEvent *event`: The QEvent that was triggered.

**Code Description**: 
The `eventFilter` method checks if the viewport of the HtmlTableView matches the watched QObject. If it does, it then checks the type of the QEvent. If the event is a mouse move event (QEvent::MouseMove), it gets the index of the item at the mouse position and checks if it's different from the last bearing i or j. If it is, it updates the last bearing i and j and emits an itemMouseChange signal with the new indices.\\
## Code: 
```
bool HtmlTableView::eventFilter(QObject *watched, QEvent *event){
    if(viewport() == watched){
        if(event->type() == QEvent::MouseMove){
        QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
        QModelIndex index = indexAt(mouseEvent->pos());
        if(index.isValid()){
            int i = index.row();
            int j = index.column();
            if(i != this->last_bearing_i || j != last_bearing_j){
                this->last_bearing_i = i;
                this->last_bearing_j = j;
                emit itemMouseChange(i,j);
            }
        }
        else{
        }
        }
        else if(event->type() == QEvent::Leave){
        }
    }
    return QTableView::eventFilter(watched, event);
}
```