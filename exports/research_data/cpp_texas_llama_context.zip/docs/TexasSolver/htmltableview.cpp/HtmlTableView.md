**Expected Output**

`HtmlTableView`: The function of `HtmlTableView` is to initialize a QTableView widget with the given parent.
**Parameters**: 
`QWidget *parent`: This parameter represents the parent widget that will contain the HtmlTableView instance.
**Code Description**: In this code snippet, the HtmlTableView constructor initializes a QTableView widget by calling its base class constructor. The viewport of the table view is then installed as an event filter for the current object (HtmlTableView), which allows it to receive events and track mouse movements within the table view. Additionally, mouse tracking is enabled on the table view, allowing it to detect and respond to mouse movements even when no buttons are pressed.\\
## Code: 
```
HtmlTableView::HtmlTableView(QWidget *parent):
    QTableView(parent)
{
    viewport()->installEventFilter(this);
    setMouseTracking(true);
}
```