## Expected output
`api`: The function of `api` is to execute the TexasSolver program with specified input and settings.
**Parameters**:\
`const char * input_file`: This parameter specifies the file from which to read input for the program. If empty, it will use a command-line interface instead.
`const char * resource_dir = "./resources"`: This parameter specifies the directory where resources such as card images or game data are stored.
`const char * mode = "holdem"`: This parameter specifies the poker game mode to be used, which can either be "holdem" for Texas Hold'em or "shortdeck".

**Code Description**: The `api` function first checks if the specified mode is valid. If not, it throws an error. It then creates a CommandLineTool object with the specified mode and resource directory. Depending on whether an input file was provided, it either starts working in command-line mode or executes from the given file.\\
## Code: 
```
EXPORT
int api(const char * input_file, const char * resource_dir = "./resources", const char * mode = "holdem") {
    string input_file_ = input_file;
    string resource_dir_ = resource_dir;
    string mode_ = mode;

    if(mode_ != "holdem" && mode_ != "shortdeck")
        throw runtime_error(tfm::format("mode %s error, not in ['holdem','shortdeck']", mode_));

    if(input_file_.empty()) {
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.startWorking();
    }else{
        cout << "EXEC FROM FILE" << endl;
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.execFromFile(input_file_);
    }
}
```