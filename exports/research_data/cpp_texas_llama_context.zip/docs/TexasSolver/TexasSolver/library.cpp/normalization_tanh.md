**normalization_tanh**: The function of `normalization_tanh` is to normalize a value using the hyperbolic tangent (tanh) function.

**Parameters**:
- `float stack`: This parameter represents the denominator or divisor in the calculation.
- `float ev`: This parameter represents the numerator or dividend in the calculation, which is divided by the stack.
- `float ratio`: This parameter scales the result of the division by a certain factor.

**Code Description**: The function calculates the value of x as (ev / stack) * ratio. It then applies the tanh function to x and returns half of the result plus 0.5, effectively normalizing the input values within the range [-1, 1].\\
## Code: 
```
float normalization_tanh(float stack,float ev,float ratio){
    float x = ev / stack * ratio;
    return tanh(x) / 2 + 0.5;
}
```