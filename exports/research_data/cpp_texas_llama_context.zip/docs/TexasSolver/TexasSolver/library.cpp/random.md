`random`: The function generates a random integer within a specified range.
**Parameters**:
`int min`: The minimum value (inclusive) of the desired range.
`int max`: The maximum value (exclusive) of the desired range.

**Code Description**: This function uses the `rand()` function to generate a random number, and then adds it to the minimum value (`min`) while ensuring that the result does not exceed the maximum value (`max`). The `% (( max ) - min)` operation is used to ensure that the generated random number falls within the specified range.\\
## Code: 
```
int random(int min, int max) //range : [min, max)
{
    return min + rand() % (( max ) - min);
}
```