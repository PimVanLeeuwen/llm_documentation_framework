`timeSinceEpochMillisec`: The function returns the number of milliseconds since the epoch (January 1, 1970).

**Code Description**: This function uses the C++11 chrono library to get the current system time using `system_clock::now()`. It then converts this time to a duration since the epoch using `time_since_epoch()` and casts it to milliseconds using `duration_cast<milliseconds>()`. The resulting count is returned as an unsigned 64-bit integer.\\
## Code: 
```
uint64_t timeSinceEpochMillisec() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
}
```