## toFormattedHtml: 
The function of `toFormattedHtml` is to format a card's value as HTML, replacing the first letter with a corresponding suit symbol.

## Code Description:
The `toFormattedHtml` method takes no arguments and returns a QString. It appears to be part of a class called Card, which has a member variable named "card" that stores the card's value as a string. The function iterates over each possible suit (hearts, diamonds, clubs, spades) and replaces the corresponding letter in the card's value with an HTML span element containing the suit symbol.\\
## Code: 
```
QString Card::toFormattedHtml() {
    QString qString = QString::fromStdString(this->card);
    if(qString.contains("c"))
        qString = qString.replace("c", QString::fromLocal8Bit("<span style=\"color:black;\">&#9827;<\/span>"));
    else if(qString.contains("d"))
        qString = qString.replace("d", QString::fromLocal8Bit("<span style=\"color:red;\">&#9830;<\/span>"));
    else if(qString.contains("h"))
        qString = qString.replace("h", QString::fromLocal8Bit("<span style=\"color:red;\">&#9829;<\/span>"));
    else if(qString.contains("s"))
        qString = qString.replace("s", QString::fromLocal8Bit("<span style=\"color:black;\">&#9824;<\/span>"));
    return qString;
}
```