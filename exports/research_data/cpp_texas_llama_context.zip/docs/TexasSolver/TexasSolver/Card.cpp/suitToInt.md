Here's the completed template:

`suitToInt`: The function converts a character representing a card suit to an integer value.
**Parameters**: A single character (`char`) representing the suit of a playing card, which can be 'c', 'd', 'h', or 's'.
**Code Description**: This function uses a switch statement to map each valid suit character to its corresponding integer value. If an invalid suit character is passed, it returns 0 by default.\\
## Code: 
```
int Card::suitToInt(char suit)
{
    switch(suit)
    {
        case 'c': return 0; // 梅花
        case 'd': return 1; // 方块
        case 'h': return 2; // 红桃
        case 's': return 3; // 黑桃
        default: return 0;
    }
}
```