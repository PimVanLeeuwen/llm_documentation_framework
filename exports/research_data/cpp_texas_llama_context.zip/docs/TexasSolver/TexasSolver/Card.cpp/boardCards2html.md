The function of `boardCards2html` is to convert a list of card objects into an HTML string.

**Parameters**:
`vector<Card>& cards`: A reference to a vector of Card objects, where each Card object represents a playing card.

**Code Description**: The method iterates through the provided vector of Card objects and appends the formatted HTML representation of each card to a QString. If a card is empty (i.e., its `empty` method returns true), it skips that card and continues with the next one. Finally, it returns the concatenated HTML string.\\
## Code: 
```
QString Card::boardCards2html(vector<Card>& cards){
    QString ret_html = "";
    for(auto one_card:cards){
        if(one_card.empty())continue;
        ret_html += one_card.toFormattedHtml();
    }
    return ret_html;
}
```