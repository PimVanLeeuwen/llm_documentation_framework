`Card`: The function of `Card` is to initialize a new Card object with the given string representation of a card.
**Parameters**: 
`string card`: This parameter represents the string representation of a card, which can be in the format "Ace of Hearts", "King of Diamonds", etc.

**Code Description**: 
The code initializes a new `Card` object by setting its `card` attribute to the given string representation. It then converts this string representation into an integer value using the `strCard2int` method and stores it in the `card_int` attribute. The `card_number_in_deck` attribute is set to -1, indicating that the card has not been assigned a position in a deck yet.\\
## Code: 
```
Card::Card(string card){
    this->card = card;
    this->card_int = Card::strCard2int(this->card);
    this->card_number_in_deck = -1;
}
```