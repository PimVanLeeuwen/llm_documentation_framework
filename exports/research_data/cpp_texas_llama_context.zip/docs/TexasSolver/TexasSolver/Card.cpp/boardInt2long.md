**Functionality:** 

`boardInt2long`: Converts a 0-based index of a card in a deck to a unique long integer value.

**Parameters**:
`int board`: The index of the card in the deck, ranging from 0 to 51 (inclusive).

**Code Description**: 
The function takes an `int` parameter representing the index of a card in a standard 52-card deck. It checks if the input is within the valid range (0-51). If not, it throws a runtime error with a message indicating that the card ID is invalid. Otherwise, it returns a unique `uint64_t` value corresponding to the given board index by shifting the binary representation of 1 to the left by the number of bits equal to the input index. This effectively creates a unique long integer for each card in the deck.\\
## Code: 
```
uint64_t Card::boardInt2long(int board){
    // 这里hard code了一副扑克牌是52张
    if(board < 0 || board >= 52){
        throw runtime_error(tfm::format("Card with id %s not found",board));
    }
    // uint64_7 的range 在0 ~ + 2^ 64之间,所以不用太担心溢出问题
    return ((uint64_t)(1) << board);
}
```