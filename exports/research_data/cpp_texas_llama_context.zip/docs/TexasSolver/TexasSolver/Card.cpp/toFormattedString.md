## toFormattedString: 
The function of `toFormattedString` is to convert a card's string representation into a formatted string with suit symbols.

## Code Description:
This method, `Card::toFormattedString`, takes the card's string representation and replaces specific characters ("c", "d", "h", "s") with their corresponding suit symbols (♣️, ♦️, ♥️, ♠️) using QString's replace function. The resulting formatted string is then returned as a std::string.\\
## Code: 
```
string Card::toFormattedString() {
    QString qString = QString::fromStdString(this->card);
    qString = qString.replace("c", "♣️");
    qString = qString.replace("d", "♦️");
    qString = qString.replace("h", "♥️");
    qString = qString.replace("s", "♠️");
    return qString.toStdString();
}
```