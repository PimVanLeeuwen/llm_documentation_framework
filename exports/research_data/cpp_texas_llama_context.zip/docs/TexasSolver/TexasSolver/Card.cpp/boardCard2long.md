`boardCard2long`: The function of `boardCard2long` is to convert a Card object into its corresponding long integer value.

**Parameters**: 
`Card& card`: This parameter takes a reference to a Card object, which contains the information about a specific card in a standard 52-card deck.

**Code Description**: 
The code calls the `getCardInt` method on the provided Card object to retrieve its associated integer value. It then passes this integer value to the `boardInt2long` method, which converts it into a unique long integer value using bitwise shifting operations. The resulting long integer is returned as the output of the `boardCard2long` function.\\
## Code: 
```
uint64_t Card::boardCard2long(Card& card){
    return Card::boardInt2long(card.getCardInt());
}
```