**Functionality:** 

The function `rankToInt` converts a character representation of a card's rank into its corresponding integer value.

**Parameters:**

The function takes a single parameter, `char rank`, which is the character representation of the card's rank (e.g., '2', '3', ..., 'A').

**Code Description:**

The function uses a switch statement to match the input `rank` against various cases and returns the corresponding integer value. If the input `rank` does not match any case, it defaults to returning 2.\\
## Code: 
```
int Card::rankToInt(char rank)
{
    switch(rank)
    {
        case '2': return 2;
        case '3': return 3;
        case '4': return 4;
        case '5': return 5;
        case '6': return 6;
        case '7': return 7;
        case '8': return 8;
        case '9': return 9;
        case 'T': return 10;
        case 'J': return 11;
        case 'Q': return 12;
        case 'K': return 13;
        case 'A': return 14;
        default: return 2;
    }
}
```