`rankToString`: The function of `rankToString` is to convert a given card rank from an integer value to its corresponding string representation.

**Parameters**:\
`int rank`: This parameter represents the integer value of a card's rank, ranging from 2 (Two) to 14 (Ace).

**Code Description**: 
The `rankToString` function uses a switch statement to match the input `rank` value with its corresponding string equivalent. The function returns a string representation of the card rank for values between 2 and 14. If an invalid rank is provided, it defaults to returning "2".\\
## Code: 
```
string Card::rankToString(int rank)
{
    switch(rank)
    {
        case 2: return "2";
        case 3: return "3";
        case 4: return "4";
        case 5: return "5";
        case 6: return "6";
        case 7: return "7";
        case 8: return "8";
        case 9: return "9";
        case 10: return "T";
        case 11: return "J";
        case 12: return "Q";
        case 13: return "K";
        case 14: return "A";
        default: return "2";
    }
}
```