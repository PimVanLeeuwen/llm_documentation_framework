## Expected output
`toString`: The function of `toString` is to return a string representation of the card object.

**Code Description**: The `toString` method in the `Card` class returns the value of the `card` member variable as a string. This suggests that the `card` variable stores the actual card value (e.g., "Ace", "King", etc.) and this function is used to get a human-readable representation of the card for display or logging purposes.\\
## Code: 
```
string Card::toString() {
    return this->card;
}
```