`suitToString`: The function of `suitToString` is to convert a given integer representing a card suit into its corresponding string representation.

**Parameters**:\
`int suit`: This parameter represents the integer value of a card suit, which can be 0 for clubs, 1 for diamonds, 2 for hearts, or 3 for spades. If any other value is passed, it defaults to clubs (represented by 'c').

**Code Description**: The `suitToString` function uses a switch statement to match the given integer suit against specific cases and returns the corresponding string representation of the card suit. If the suit does not match any case, it defaults to returning "c" for clubs.\\
## Code: 
```
string Card::suitToString(int suit)
{
    switch(suit)
    {
        case 0: return "c";
        case 1: return "d";
        case 2: return "h";
        case 3: return "s";
        default: return "c";
    }
}
```