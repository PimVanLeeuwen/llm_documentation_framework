**Expected Output**

`long2board`: The function of `long2board` is to convert a 64-bit unsigned integer (`uint64_t`) representing a binary long value into a vector of integers, where each integer represents the index of a card in a standard deck.

**Parameters**:\
`uint64_t board_long`: This parameter is a 64-bit unsigned integer that contains the binary representation of the long value to be converted. The function iterates through this value from right to left (i.e., least significant bit to most significant bit), treating each bit as an indicator for whether a card should be included in the output vector.

**Code Description**: 
The `long2board` function takes a `uint64_t board_long` and converts it into a vector of integers (`vector<int>`) representing the indices of cards in a standard deck. It iterates through each bit of the input value from right to left, using bitwise operations to check if the current bit is set (i.e., equals 1). If the bit is set, the corresponding card index is added to the output vector. The function then checks if the size of the resulting vector is within the expected range (between 1 and 7) and throws a runtime error if it's not.\\
## Code: 
```
vector<int> Card::long2board(uint64_t board_long) {
    vector<int> board;
    board.reserve(7);
    for(int i = 0;i < 52;i ++){
        // 看二进制最后一位是否为1
        if((board_long & 1) == 1){
            board.push_back(i);
        }
        board_long = board_long >> 1;
    }
    if (board.size() < 1 || board.size() > 7){
        throw runtime_error(tfm::format("board length not correct, board length %s",board.size()));
    }
    return board;
}
```