`intCard2Str`: The function of `intCard2Str` is to convert an integer representation of a playing card into its string equivalent.

**Parameters**:\
`int card`: This parameter represents the integer value of a playing card, where the first digit (0-3) corresponds to the suit and the second digit (1-13) corresponds to the rank.

**Code Description**: The `intCard2Str` function takes an integer `card` as input, extracts the rank and suit from it using division and modulo operations, and then calls the `rankToString` and `suitToString` methods to convert these values into their string representations. The resulting strings are concatenated and returned as a single string representing the playing card.\\
## Code: 
```
string Card::intCard2Str(int card){
    int rank = card / 4 + 2;
    int suit = card - (rank-2)*4;
    return Card::rankToString(rank) + Card::suitToString(suit);
}
```