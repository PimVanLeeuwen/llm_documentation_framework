`boardCards2long`: The function of `boardCards2long` is to convert a vector of string representations of poker cards into a single 64-bit unsigned integer representing the board.

**Parameters**:\
`vector<string> cards`: A vector of strings, where each string represents a poker card in a specific format (e.g., "AH", "KH", etc.).

**Code Description**: The function first creates a vector of `Card` objects from the input vector of strings. It then calls another overloaded version of `boardCards2long` that takes a vector of `Card` objects as input, which converts each card object to its corresponding integer value and combines these values into a single long integer.\\
## Code: 
```
uint64_t Card::boardCards2long(vector<string> cards) {
    vector<Card> cards_objs(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_objs[i] = Card(cards[i]);
    }
    return Card::boardCards2long(cards_objs);
}
```