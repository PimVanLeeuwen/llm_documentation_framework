## Expected output
`empty`: The function of `empty` is to check if a card is empty or not. 

**Code Description**: This method checks the state of a card by comparing its value with "empty". If they match, it returns true indicating that the card is indeed empty; otherwise, it returns false.\\
## Code: 
```
bool Card::empty(){
    if(this->card == "empty")return true;
    else return false;
}
```