`buildChance`: The function of `buildChance` is to recursively build the game tree for a chance node in a poker game.

**Parameters**:
- `shared_ptr<ChanceNode> root`: This parameter represents the current chance node being processed, which serves as the starting point for building the subtree.
- `Rule rule`: This parameter contains information about the current state of the game, including the round number and betting amounts.

**Code Description**: The function `buildChance` takes a shared pointer to a ChanceNode (`root`) and a Rule object (`rule`) as input. It first checks if the current round is greater than 3 (i.e., it's not valid), and throws an exception if so. If the rule's OOP commit, IP commit, and stack values are equal, it creates a ShowdownNode or ChanceNode depending on the round number. Otherwise, it creates an ActionNode. The function then calls another method (`__build`) to recursively build the game tree for the node, passing in the newly created node, the updated rule, and other parameters. Finally, it sets the children of the root chance node to the newly built subtree.\\
## Code: 
```
void GameTree::buildChance(shared_ptr<ChanceNode> root,Rule rule){
    //节点上的下注额度
    double pot = (double)rule.get_pot();
    Rule nextrule = Rule(rule);
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));

    shared_ptr<GameTreeNode> one_node;
    if(rule.oop_commit == rule.ip_commit && rule.oop_commit == rule.stack) {
        if(rule.current_round >= 3){ // 3 is river
            double p1_commit = rule.ip_commit;
            double p2_commit = rule.oop_commit;
            double peace_getback = (p1_commit + p2_commit) / 2;


            vector<vector<double>> payoffs(2);
            payoffs[0] = {p2_commit, -p2_commit};
            payoffs[1] = {-p1_commit, p1_commit};
            vector<double> peace_getback_vec = {peace_getback - p1_commit, peace_getback - p2_commit};
            one_node = make_shared<ShowdownNode>(peace_getback_vec, payoffs, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
        }else {
            nextrule.current_round += 1;
            if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
            one_node = make_shared<ChanceNode>(nullptr, GameTreeNode::intToGameRound(rule.current_round + 1), (double) rule.get_pot(), root, this->deck.getCards());
        }
    }else {
        one_node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(), 1, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
    }
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
    this->__build(one_node,nextrule,"begin",0,0);
    root->setChildren(one_node);
}
```