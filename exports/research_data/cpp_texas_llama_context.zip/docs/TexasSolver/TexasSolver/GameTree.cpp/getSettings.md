`getSettings`: The function of `getSettings` is to retrieve the settings for a specific game round and player in a Texas Hold'em game tree.

**Parameters**:
`int int_round`: This parameter represents the current game round, which can be one of four values: PREFLOP, FLOP, TURN, or RIVER.
`int player`: This parameter specifies the player whose settings are being retrieved, either 0 for the first player or 1 for the second player.
`GameTreeBuildingSettings& gameTreeBuildingSettings`: This reference parameter provides access to a set of building settings for the game tree.

**Code Description**: The `getSettings` function takes in the current game round and player as parameters and uses them to determine which settings from the `gameTreeBuildingSettings` object to return. It first converts the integer game round value to its corresponding enum value using the `intToGameRound` method. Then, it checks the combination of game round and player to decide which specific setting to retrieve from the `gameTreeBuildingSettings` object. If an invalid combination is detected, it throws a runtime error with a descriptive message.\\
## Code: 
```
StreetSetting GameTree::getSettings(int int_round, int player,GameTreeBuildingSettings& gameTreeBuildingSettings){
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(int_round);
    if(!(player == 0 || player == 1)) throw runtime_error(tfm::format("player %s not known",player));
    if(round == GameTreeNode::GameRound::RIVER && player == 0) return gameTreeBuildingSettings.river_ip;
    else if(round == GameTreeNode::GameRound::TURN && player == 0) return gameTreeBuildingSettings.turn_ip;
    else if(round == GameTreeNode::GameRound::FLOP && player == 0) return gameTreeBuildingSettings.flop_ip;
    else if(round == GameTreeNode::GameRound::RIVER && player == 1) return gameTreeBuildingSettings.river_oop;
    else if(round == GameTreeNode::GameRound::TURN && player == 1) return gameTreeBuildingSettings.turn_oop;
    else if(round == GameTreeNode::GameRound::FLOP && player == 1) return gameTreeBuildingSettings.flop_oop;
    else throw new runtime_error(tfm::format("player %s and round not known",player));
}
```