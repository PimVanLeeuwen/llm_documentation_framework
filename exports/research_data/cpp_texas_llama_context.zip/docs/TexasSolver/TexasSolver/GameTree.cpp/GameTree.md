`GameTree`: The function of `GameTree` is to initialize and build a game tree for Texas Hold'em poker.

**Parameters**:
`Deck deck`: A representation of the deck used in the game.
`float oop_commit`: The out-of-position commitment value.
`float ip_commit`: The in-position commitment value.
`int current_round`: The current round number (0-3) representing PREFLOP, FLOP, TURN, or RIVER.
`int raise_limit`: The maximum number of raises allowed.
`float small_blind`: The amount of the small blind.
`float big_blind`: The amount of the big blind.
`float stack`: The current player's stack size.
`GameTreeBuildingSettings buildingSettings`: Settings for building the game tree.
`float allin_threshold`: The threshold value for an all-in action.

**Code Description**: This code defines a constructor for the `GameTree` class, which initializes and builds a game tree based on the provided parameters. It creates a new `Rule` object using the input parameters and then calls the `__build` method to construct the game tree. The root node of the game tree is stored in the `root` member variable.\\
## Code: 
```
GameTree::GameTree(Deck deck,
                   float oop_commit,
                   float ip_commit,
                   int current_round,
                   int raise_limit,
                   float small_blind,
                   float big_blind,
                   float stack,
                   GameTreeBuildingSettings buildingSettings,
                   float allin_threshold
){
    Rule rule = Rule(deck,oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,buildingSettings,allin_threshold);
    int current_player = 1;
    this->deck = deck;
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(rule.current_round);
    shared_ptr<ActionNode> node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(),current_player, round, (double) rule.get_pot(),
                                 nullptr);
    this->__build(node,rule);
    this->root = node;
}
```