## Expected output
`readAllBytes`: The function reads all bytes from a file specified by the given file path.
**Parameters**: 
`const string& filePath`: The path to the file that contains the data to be read.

**Code Description**: This method opens an input stream to the specified file and returns it.\\
## Code: 
```
ifstream GameTree::readAllBytes(const string& filePath) {
    ifstream input_file(filePath);
    return input_file;
}
```