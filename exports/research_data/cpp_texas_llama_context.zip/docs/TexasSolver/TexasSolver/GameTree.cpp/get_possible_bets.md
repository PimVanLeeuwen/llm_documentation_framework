## Expected output
`get_possible_bets`: The function of `get_possible_bets` is to calculate the possible bets for a player in a game of Texas Hold'em based on the current game state and rules.
**Parameters**:\
`shared_ptr<ActionNode> root`: A pointer to the root node of the game tree, representing the current game state. \
`int player`: The number of the player who is making the bet (0 or 1). \
`int next_player`: The number of the player who will make the next action (0 or 1). \
`Rule rule`: An object containing the rules of the game, including the betting structure and stack sizes. \
`GameTree::BetType betType`: The type of bet being made (BET, DONK, or RAISE).

**Code Description**: This function first checks if the player is making a valid bet by comparing their number with that of the next player. If not, it throws an error. It then retrieves the current street setting based on the round and player number using the `getSettings` method. The function then calculates the possible bets based on the betting structure specified in the rule object. For each possible bet, it checks if the amount is valid (i.e., within the stack size) and adds it to a vector of possible amounts. If the all-in threshold is reached, it also adds an all-in amount to the vector. Finally, it filters out any invalid bets based on the current game state and returns the vector of possible bets.\\
## Code: 
```
vector<double> GameTree::get_possible_bets(shared_ptr<ActionNode> root, int player, int next_player, Rule rule,
                                           GameTree::BetType betType) {
    if(player != 1 - next_player)throw runtime_error("player error, player and next player not match");
    StreetSetting streetSetting = this->getSettings(root->getRound(),player,rule.build_settings);
    vector<double> bets_ratios;
    bool all_in = streetSetting.allin;
    vector<float> bets_from_rule;
    if(betType == BetType::BET)bets_from_rule = streetSetting.bet_sizes;
    else if(betType == BetType::DONK)bets_from_rule = streetSetting.donk_sizes;
    else if(betType == BetType::RAISE)bets_from_rule = streetSetting.raise_sizes;
    else throw runtime_error("bet type unknown");
    for(float one_bet:bets_from_rule){
        bets_ratios.push_back((double) one_bet / 100);
    }
    float pot = max(rule.ip_commit,rule.oop_commit) * 2;
    vector<double> possible_amounts;
    for(double one_bet: bets_ratios){
        double amount;
        if(rule.oop_commit == rule.small_blind){
            // 当德州扑克开始时，在第一个玩家动作时（sb位置玩家）,视作对手先下注一个bb,这个时候下注要扣除自己的sb
            amount = one_bet * rule.big_blind  - rule.small_blind;
            amount = this->round_nearest(amount, (double) rule.small_blind);
        }else if(rule.ip_commit == rule.big_blind && rule.oop_commit == rule.big_blind){
            // 当德州扑克开始时，在第一个玩家call 的时候第二个玩家要 raise的时候,需要特殊处理
            amount = one_bet * rule.big_blind;
            amount = this->round_nearest(amount, (double) rule.small_blind);
        }else{
            amount = one_bet * pot;
            amount = this->round_nearest(amount, (double) rule.big_blind);
        }
        if(betType == BetType::RAISE)amount += (rule.get_commit(next_player) - rule.get_commit(player));
        if(amount + rule.get_commit(player) > rule.initial_effective_stack * rule.allin_threshold)amount = (double) (rule.stack - rule.get_commit(player)); // if larget than allin thres then allin
        if(amount < rule.stack - rule.get_commit(player) && amount > 0) {
            possible_amounts.push_back(amount);
        }else if(amount == rule.stack - rule.get_commit(player)){
            possible_amounts.push_back(amount);
        }
        else if(amount > rule.stack - rule.get_commit(player)){
            possible_amounts.push_back(rule.stack - rule.get_commit(player));
        }
    }
    if(all_in) possible_amounts.push_back((double) (rule.stack - rule.get_commit(player)));

    if (rule.get_commit(player) != rule.small_blind){
        // 一开始的possible bet amount不能简单取整
        vector<double> tmp_vector;
        for(double val:possible_amounts){
            if(val > 0)tmp_vector.push_back(int(val));
        }
        possible_amounts = tmp_vector;
    }
    if (rule.get_commit(player) == rule.small_blind){
        vector<double> tmp_vector;
        for(double val:possible_amounts){
            if(val >= rule.big_blind)tmp_vector.push_back(val);
        }
        possible_amounts = tmp_vector;
    }else if (rule.get_commit(player) == rule.big_blind && rule.get_commit(next_player) == rule.big_blind){
        vector<double> tmp_vector;
        for(double val:possible_amounts){
            if(val >= rule.big_blind)tmp_vector.push_back(val);
        }
        possible_amounts = tmp_vector;
    }else{
        float gap = rule.get_commit(next_player) - rule.get_commit(player);
        vector<double> tmp_vector;
        for(double val:possible_amounts){
            if(val >= gap * 2)tmp_vector.push_back(val);
        }
        possible_amounts = tmp_vector;
    }
    vector<double> tmp_vector;
    for(double val:possible_amounts){
        if(
                (val > rule.get_commit(next_player) - rule.get_commit(player)) &&
                (val <= rule.stack - rule.get_commit(player)) &&
                find(tmp_vector.begin(),tmp_vector.end(), val) == tmp_vector.end()
        )tmp_vector.push_back(val);
    }
    possible_amounts = tmp_vector;
    return possible_amounts;
}
```