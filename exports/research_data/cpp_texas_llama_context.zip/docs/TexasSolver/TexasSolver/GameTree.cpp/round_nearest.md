**round_nearest**: The function of `round_nearest` is to round a given number to the nearest multiple of another number.

**Parameters**:
- `double number`: This parameter represents the number that needs to be rounded.
- `double round_num`: This parameter determines the multiple to which the input number should be rounded.

**Code Description**: The function first calculates the reciprocal of `round_num` and assigns it back to `round_num`. It then multiplies the input `number` by this modified `round_num`, rounds the result, and finally divides it by `round_num` to obtain the final rounded value.\\
## Code: 
```
double GameTree::round_nearest(double number, double round_num) {
    round_num = 1 / round_num;
    return round((number * round_num)) / round_num;

}
```