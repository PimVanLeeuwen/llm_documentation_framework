`recurrentSetDepth`: The function of `recurrentSetDepth` is to recursively set the depth and subtree size of a game tree node.

**Parameters**:
`shared_ptr<GameTreeNode> node`: This parameter represents the current game tree node being processed.
`int depth`: This parameter represents the current depth level in the game tree, which starts at 0 for the root node.

**Code Description**: The `recurrentSetDepth` function recursively traverses the game tree, setting the depth and subtree size of each node. It handles three types of nodes: ACTION, CHANCE, and others (which are assumed to have no children). For ACTION nodes, it recursively calls itself for each child node, incrementing the depth by 1 and summing up the subtree sizes. For CHANCE nodes, it recursively calls itself for the children of the chance node, multiplying the result by the number of cards in the chance node's collection. The function returns the total subtree size of the current node.\\
## Code: 
```
int GameTree::recurrentSetDepth(shared_ptr<GameTreeNode> node, int depth) {
    node->depth = depth;
    if(node->getType() == GameTreeNode::ACTION) {
        shared_ptr<ActionNode> actionNode = std::dynamic_pointer_cast<ActionNode>(node);
        int subtree_size = 1;
        for(shared_ptr<GameTreeNode> one_child:actionNode->getChildrens()){
            subtree_size += this->recurrentSetDepth(one_child,depth + 1);
        }
        node->subtree_size = subtree_size;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chanceNode = std::dynamic_pointer_cast<ChanceNode>(node);
        int subtree_size = 1;
        subtree_size += this->recurrentSetDepth(chanceNode->getChildren(),depth + 1) * chanceNode->getCards().size();
        node->subtree_size = subtree_size;
    }else{
        node->subtree_size = 1;
    }
    return node->subtree_size;
}
```