The function of `printTree` is to print a game tree structure to the console.

**Parameters**:
`int depth`: The depth at which to start printing the game tree. A value of -1 indicates that the entire tree should be printed, while positive values indicate the maximum depth to reach.

**Code Description**: 
The `printTree` function takes an integer parameter `depth` and calls a recursive helper function `recurrentPrintTree` to print the game tree structure. It first checks if the provided depth is valid (not less than -1 or equal to 0), and then initializes a prefix vector. The actual printing of the tree is done by calling `recurrentPrintTree` with the root node and the current depth as parameters.\\
## Code: 
```
void GameTree::printTree(int depth) {
    if(depth < -1 || depth == 0){
        throw runtime_error("depth can only be -1 or positive");
    }
    vector<string> prefix;
    this->recurrentPrintTree(this->root,0,depth);
}
```