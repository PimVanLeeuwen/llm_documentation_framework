`RoughStrategyItemDelegate`: The function of `RoughStrategyItemDelegate` is to initialize the RoughStrategyItemDelegate object with a DetailWindowSetting and a parent QObject.

**Parameters**:
`DetailWindowSetting* detailWindowSetting`: This parameter represents the settings for the detail window, which will be used by the RoughStrategyItemDelegate.
`QObject *parent`: This parameter represents the parent object of the RoughStrategyItemDelegate, which is typically used to establish an ownership relationship between objects in Qt.

**Code Description**: The code initializes a new instance of the RoughStrategyItemDelegate class with the provided DetailWindowSetting and sets it as the detail window setting for this delegate. It also passes the parent QObject to the WordItemDelegate constructor, indicating that the RoughStrategyItemDelegate is a subclass of WordItemDelegate.\\
## Code: 
```
RoughStrategyItemDelegate::RoughStrategyItemDelegate(DetailWindowSetting* detailWindowSetting,QObject *parent) :
    WordItemDelegate(parent)
{
    this->detailWindowSetting = detailWindowSetting;
}
```