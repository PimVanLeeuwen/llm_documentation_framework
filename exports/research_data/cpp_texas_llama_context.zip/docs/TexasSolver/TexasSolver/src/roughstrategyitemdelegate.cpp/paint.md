`paint`: The function of `paint` is to draw a gray rectangle and then paint the strategy item.

**Parameters**:
- `QPainter *painter`: A pointer to a QPainter object, which is used for drawing graphics.
- `const QStyleOptionViewItem &option`: A reference to a QStyleOptionViewItem object, which contains information about the item being painted.
- `const QModelIndex &index`: A reference to a QModelIndex object, which represents the index of the item in a model.

**Code Description**: The function first saves the current state of the painter using `painter->save()`. It then draws a gray rectangle by creating a QRect object from the option's rect and filling it with a gray brush. After that, it calls the `paint_strategy` method to paint the strategy item. Finally, it restores the painter's state using `painter->restore()`.\\
## Code: 
```
void RoughStrategyItemDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    painter->save();

    QRect rect(option.rect.left(), option.rect.top(),\
             option.rect.width(), option.rect.height());
    QBrush brush(Qt::gray);
    painter->fillRect(rect, brush);

    this->paint_strategy(painter,option,index);

    painter->restore();
}
```