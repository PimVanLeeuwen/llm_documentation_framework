`get_ij_text`: The function of `get_ij_text` is to generate a string representation of the ranklist values at positions `i` and `j`, with an indication of whether `i` is greater than, less than, or equal to `j`.

**Parameters**:\
`int i`: This parameter represents the row position in the ranklist.
`int j`: This parameter represents the column position in the ranklist.

**Code Description**: The function first determines which value is larger and smaller between `i` and `j`. It then constructs a string by concatenating the values at positions `smaller` and `larger` from the ranklist, separated by an "o" if `i` is greater than `j`, an "s" if `i` is less than `j`, or an empty string if they are equal. The resulting string is returned as the output of the function.\\
## Code: 
```
QString RangeSelectorTableModel::get_ij_text(int i,int j){
    int row = i;
    int col = j;
    int larger = row > col?row:col;
    int smaller = row > col?col:row;
    QString  retval = QString("%1%2%3")\
            .arg(QString(this->ranklist[smaller]))\
            .arg(QString(this->ranklist[larger]));
    if(row > col){
        retval = retval.arg("o");
    }else if(row < col){
        retval = retval.arg("s");
    }else{
        retval = retval.arg("");
    }
    return retval;
}
```