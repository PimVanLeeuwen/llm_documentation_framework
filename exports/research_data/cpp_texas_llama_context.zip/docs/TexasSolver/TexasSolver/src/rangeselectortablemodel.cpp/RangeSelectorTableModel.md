`RangeSelectorTableModel`: The function of `RangeSelectorTableModel` is to initialize and configure a table model for range selection, handling ranks, initial board settings, parent object, and thumbnail display.

**Parameters**:
`QStringList ranks`: A list of rank values used in the table model.
`QString initial_board`: An input string specifying the initial state of the range selector table.
`QObject *parent`: The parent object of the table model.
`bool thumbnail`: A boolean flag indicating whether to display a thumbnail.

**Code Description**: 
The code initializes the `RangeSelectorTableModel` class, setting up internal data structures and calling methods to populate them. It creates 2D grids for string and float values, populates the grid with text representations of indices using the `get_ij_text` method, and sets the initial board text based on the input string. The `parent` parameter is used to set the parent object of the table model.\\
## Code: 
```
RangeSelectorTableModel::RangeSelectorTableModel(QStringList ranks,QString initial_board,QObject *parent,bool thumbnail):QAbstractItemModel(parent){
    this->ranklist = ranks;
    this->thumbnail = thumbnail;

    this->grids_string = vector<vector<QString>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_string[i] = vector<QString>(this->ranklist.size());
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_string[i][j] = this->get_ij_text(i,j);
            this->string2ij[this->get_ij_text(i,j)] = pair<int,int>(i,j);
        }
    }

    this->grids_float = vector<vector<float>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_float[i] = vector<float>(this->ranklist.size(),0.0);
    }
    this->setRangeText(initial_board);
}
```