`index`: The function of `index` is to return a QModelIndex object that represents the item at the specified row and column within the table model, or an invalid QModelIndex if the index does not exist.

**Parameters**:
`int row`: The row number of the item in the table.
`int column`: The column number of the item in the table.
`const QModelIndex &parent`: A reference to the parent QModelIndex object, which is used to determine whether the item has a parent or not.

**Code Description**: This function checks if the specified index exists within the table model using the `hasIndex` method. If it does exist, it creates and returns a new QModelIndex object that represents the item at the specified row and column. If the index does not exist, it returns an invalid QModelIndex object.\\
## Code: 
```
QModelIndex RangeSelectorTableModel::index(int row, int column,
          const QModelIndex &parent) const  {
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    return createIndex(row, column, nullptr);
}
```