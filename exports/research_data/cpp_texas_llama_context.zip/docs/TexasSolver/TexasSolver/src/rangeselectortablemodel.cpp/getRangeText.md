`getRangeText`: The function of `getRangeText` is to generate a string representing the range of values in the grid, where each value is represented as "string:value" and multiple ranges are comma-separated.

**Code Description**: This method iterates over the 2D grid data stored in `grids_float` and `grids_string`, and for each non-zero value, it constructs a string in the format "string:value" using the corresponding values from `grids_string` and `grids_float`. The resulting strings are then concatenated into a single comma-separated string, which is returned as the result.\\
## Code: 
```
QString RangeSelectorTableModel::getRangeText(){
    QString retval = "";
    for(int i = 0;i < this->ranklist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            if(this->grids_float[i][j] == 0)continue;
            QString one_range_str = QString("%1:%2").arg(this->grids_string[i][j],QString::number(this->grids_float[i][j],'f',3));
            if(retval == ""){
                retval = one_range_str;
            }else{
                retval = retval + "," + one_range_str;
            }
        }
    }
    return retval;
}
```