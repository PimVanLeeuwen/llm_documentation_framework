`getPreflopCards`: The function of `getPreflopCards` is to retrieve the private cards of a specific player before the flop.

**Parameters**: 
`int player`: This parameter represents the index or ID of the player for whom the preflop cards are being retrieved.

**Code Description**: The function returns a reference to a vector of PrivateCards, which contains the private cards held by the specified player at the preflop stage.\\
## Code: 
```
vector<PrivateCards>& PrivateCardsManager::getPreflopCards(int player) {
    return this->private_cards[player];
}
```