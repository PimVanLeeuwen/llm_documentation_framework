`getInitialReachProb`: The function of `getInitialReachProb` is to calculate the initial reach probability for a given player.

**Parameters**:
`int player`: This parameter represents the index of the player for whom the initial reach probability is being calculated.
`uint64_t initialboard`: This parameter represents the state of the board at the beginning of the game, represented as a 64-bit unsigned integer.

**Code Description**: The function iterates over the private cards of the given player and checks if any of them intersect with the initial board. If an intersection is found, the corresponding probability in the output vector is set to 0; otherwise, it is set to the weight of the private card. The function returns a vector of probabilities for each private card of the player.\\
## Code: 
```
vector<float> PrivateCardsManager::getInitialReachProb(int player, uint64_t initialboard) {
    int cards_len =  this->private_cards[player].size();
    vector<float> probs = vector<float>(cards_len);
    for(int i = 0;i < cards_len;i ++){
        PrivateCards pc = this->private_cards[player][i];
        if(Card::boardsHasIntercept(initialboard,Card::boardInts2long(pc.get_hands()))) {
            probs[i] = 0;
        }else{
            probs[i] = this->private_cards[player][i].weight;
        }
    }
    return probs;
}
```