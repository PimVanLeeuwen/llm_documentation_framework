`indPlayer2Player`: The function of `indPlayer2Player` is to find the index of a card in the preflop cards of one player that corresponds to a specific card in the preflop cards of another player.

**Parameters**:
`int from_player`: The ID of the player whose preflop cards are being searched.
`int to_player`: The ID of the player whose preflop cards contain the target card.
`int index`: The index of the card in the `from_player`'s preflop cards that is being matched.

**Code Description**: This function takes three parameters: `from_player`, `to_player`, and `index`. It first checks if the provided `index` is within the valid range for the `from_player`'s preflop cards. If not, it throws a runtime error. Then, it uses the `hashCode` method of the `PrivateCards` class to generate a unique identifier for the card at the specified `index` in the `from_player`'s preflop cards. This identifier is used as a key to look up the corresponding index in the `to_player`'s preflop cards using the `card_player_index` array. If no match is found, it returns -1; otherwise, it returns the index of the matching card in the `to_player`'s preflop cards.\\
## Code: 
```
int PrivateCardsManager::indPlayer2Player(int from_player, int to_player, int index) {
    if(index < 0 || index >= this->getPreflopCards(from_player).size()) throw runtime_error("index out of range");
    //PrivateCards player_combo = this->getPreflopCards(from_player)[index];
    int to_player_index = this->card_player_index[this->private_cards[from_player][index].hashCode()][to_player];
    if(to_player_index == -1){
        return -1;
    }else {
        return to_player_index;
    }
}
```