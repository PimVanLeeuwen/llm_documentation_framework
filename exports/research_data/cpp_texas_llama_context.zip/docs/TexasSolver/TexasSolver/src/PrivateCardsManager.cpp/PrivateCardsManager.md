`PrivateCardsManager`: The function of `PrivateCardsManager` is to manage and initialize the private cards for a specified number of players in a poker game, considering the initial board state.

**Parameters**:
`vector<vector<PrivateCards>> private_cards`: A 2D vector containing the private cards for each player.
`int player_number`: The total number of players participating in the game.
`uint64_t initialboard`: The initial state of the board, represented as a 64-bit unsigned integer.

**Code Description**: 
The `PrivateCardsManager` class initializes and manages the private cards for multiple players. It takes three parameters: `private_cards`, which is a 2D vector containing the private cards for each player; `player_number`, representing the total number of players in the game; and `initialboard`, representing the initial state of the board.

Upon initialization, the class sets up an internal data structure to store the index of each private card combination for each player. It then populates this data structure by iterating through each player's private cards and storing their corresponding indices.

The `setRelativeProbs` method is called within the constructor to calculate relative probabilities for the private cards based on interactions between players' hands and the initial board state. This involves computing the relative weights of each card combination for each player, considering the opponent's card weights, and normalizing these values within each player's set of cards.

The `PrivateCardsManager` class appears to be designed to facilitate the calculation of relative probabilities for private cards in a poker game, taking into account the interactions between players' hands and the initial board state.\\
## Code: 
```
PrivateCardsManager::PrivateCardsManager(vector<vector<PrivateCards>> private_cards, int player_number,
                                         uint64_t initialboard) {
    this->private_cards = private_cards;
    this->player_number = player_number;
    this->card_player_index = vector<vector<int>>(52 * 52);
    for(int i = 0;i < 52 * 52;i ++){
        this->card_player_index[i] = vector<int>(this->player_number,-1);
    }

    // 用一个二维数组记录每个Private Combo的对应index,方便从一方的手牌找对方的同名卡牌的index
    for(int player_id = 0;player_id < player_number;player_id ++){
        vector<PrivateCards> privateCombos = private_cards[player_id];
        for(std::size_t i = 0;i < privateCombos.size();i ++){
            PrivateCards one_private_combo = privateCombos[i];
            this->card_player_index[one_private_combo.hashCode()][player_id] = i;
        }
    }

    this->initialboard = initialboard;
    this->setRelativeProbs();
}
```