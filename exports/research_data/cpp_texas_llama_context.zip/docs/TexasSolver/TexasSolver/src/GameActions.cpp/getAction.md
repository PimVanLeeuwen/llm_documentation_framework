## getAction: 
The function of `getAction` is to return the current action of a game state.

## Code Description:
The `getAction` method in the `GameActions` class returns an instance of `PokerActions` from the `GameTreeNode` class, which represents the current action of the game state. The method simply retrieves and returns the value stored in the `action` member variable of the class instance.\\
## Code: 
```
GameTreeNode::PokerActions GameActions::getAction() {
    return this->action;
}
```