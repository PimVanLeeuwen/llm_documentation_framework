`pokerActionToString`: The function of `pokerActionToString` is to convert a given Poker Actions enum value into its corresponding string representation.

**Parameters**: 
`GameTreeNode::PokerActions pokerActions`: This parameter takes an instance of the GameTreeNode's PokerActions enum, which represents different actions that can be taken in a game of poker.

**Code Description**: The function uses a switch statement to match the provided Poker Actions enum value with its corresponding string representation. If the provided enum value does not match any of the expected values, it throws a runtime_error with a message indicating that the PokerActions was not found.\\
## Code: 
```
string GameActions::pokerActionToString(GameTreeNode::PokerActions pokerActions) {
    switch (pokerActions)
    {
        case GameTreeNode::PokerActions::BEGIN :   return "BEGIN";
        case GameTreeNode::PokerActions::ROUNDBEGIN :   return "ROUNDBEGIN";
        case GameTreeNode::PokerActions::BET :   return "BET";
        case GameTreeNode::PokerActions::RAISE :   return "RAISE";
        case GameTreeNode::PokerActions::CHECK :   return "CHECK";
        case GameTreeNode::PokerActions::FOLD :   return "FOLD";
        case GameTreeNode::PokerActions::CALL :   return "CALL";
        default:{
            throw runtime_error("PokerActions not found");
        }
    }
}
```