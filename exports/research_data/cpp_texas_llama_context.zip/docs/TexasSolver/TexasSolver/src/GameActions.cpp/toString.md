`toString`: The function of `toString` is to return a string representation of the game action, including the poker action and the amount (if applicable).

**Code Description**: This method, `toString`, appears to be part of a class called `GameActions`. It takes no arguments and returns a string. The code checks if an instance variable `amount` is equal to -1. If true, it calls another method `pokerActionToString` with the value of `action` as an argument and returns the result. Otherwise, it concatenates the result of calling `pokerActionToString` with `action` and the string representation of `amount`, separated by a space, and returns this concatenated string.\\
## Code: 
```
string GameActions::toString() {
    if(this->amount == -1) {
        return this->pokerActionToString(this->action);
    }else{
        return this->pokerActionToString(this->action) + " " + to_string(amount);
    }
}
```