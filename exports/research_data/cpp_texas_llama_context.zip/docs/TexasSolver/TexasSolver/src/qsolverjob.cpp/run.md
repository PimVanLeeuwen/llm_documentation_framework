`run`: The function of `run` is to execute a specific mission or task based on the current_mission attribute of the QSolverJob object.

**Code Description**: The code describes a method called `run` in the QSolverJob class, which attempts to perform a specific mission or task depending on its current state. It tries to call one of four methods: solving, loading, build_tree, or saving, based on the value of current_mission. If an unsupported mission type is encountered, it throws a runtime_error with a descriptive message.\\
## Code: 
```
void QSolverJob::run()
{
    //QDebugStream qout(qDebug().noquote(), this->textEdit);
    try{
        if(this->current_mission == MissionType::SOLVING){
            this->solving();
        }else if(this->current_mission == MissionType::LOADING){
            this->loading();
        }else if(this->current_mission == MissionType::BUILDTREE){
            this->build_tree();
        }else if(this->current_mission == MissionType::SAVING){
            this->saving();
        }else{
            throw runtime_error("unsupported mission type");
        }
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```