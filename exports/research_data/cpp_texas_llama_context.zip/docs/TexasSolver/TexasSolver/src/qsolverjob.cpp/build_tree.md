`build_tree`: The function of `build_tree` is to build a game tree for the poker game based on the given parameters.

**Code Description**: This code defines a method called `build_tree` in the `QSolverJob` class. It checks if the current mode is either HOLDEM or SHORTDECK, and then calls the corresponding method (`ps_holdem.build_game_tree` or `ps_shortdeck.build_game_tree`) to build the game tree based on the provided parameters such as oop_commit, ip_commit, current_round, raise_limit, small_blind, big_blind, stack, gtbs, and allin_threshold. The method prints a message indicating that the tree building process has started and finished.\\
## Code: 
```
void QSolverJob::build_tree(){
    qDebug().noquote() << tr("building tree..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        ps_holdem.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }else if(this->mode == Mode::SHORTDECK){
        ps_shortdeck.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }
    qDebug().noquote() << tr("build tree finished");//.toStdString() << endl;
}
```