`get_solver`: The function of `get_solver` is to return a pointer to the appropriate PokerSolver object based on the current mode of the QSolverJob.

**Code Description**: 
The `get_solver` method in the QSolverJob class returns a reference to either the holdem or shortdeck PokerSolver object, depending on the value of the `mode` variable. If the mode is neither HOLDEM nor SHORTDECK, it throws a runtime_error with an "unknown mode" message. This suggests that the method is designed to handle different poker game modes and provide access to the corresponding solver objects.\\
## Code: 
```
PokerSolver* QSolverJob::get_solver(){
    if(this->mode == Mode::HOLDEM){
        return &this->ps_holdem;
    }else if(this->mode == Mode::SHORTDECK){
        return &this->ps_shortdeck;
    }else throw runtime_error("unknown mode in get_solver");
}
```