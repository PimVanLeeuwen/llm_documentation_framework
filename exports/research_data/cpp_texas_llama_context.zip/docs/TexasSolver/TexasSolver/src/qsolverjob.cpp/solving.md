`solving`: The function of `solving` is to train a poker solver using Monte Carlo algorithms based on given player ranges, boards, and parameters.

**Code Description**: This code snippet implements the `solving` method in the `QSolverJob` class. It checks the mode (HOLDEM or SHORTDECK) and calls the corresponding `train` method on either `ps_holdem` or `ps_shortdeck` to perform the training process. The `train` method initializes a PCfrSolver object with provided inputs and calls its own `train` method to execute the Monte Carlo algorithm for determining optimal poker strategies.\\
## Code: 
```
void QSolverJob::solving(){
    // TODO  为什么ui上多次求解会积累memory？哪里leak了？
    // TODO  为什么有时候会莫名闪退？
    qDebug().noquote() << tr("Start Solving..");//.toStdString() << std::endl;

    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }
    qDebug().noquote() << tr("Solving done.");//.toStdString() << std::endl;
}
```