`saving`: The function of `saving` is to save a JSON file with strategy data for a poker game solver job.

**Code Description**: This function, part of the QSolverJob class, saves a JSON file containing strategy data for a poker game solver job. It retrieves the dump round value from the application settings and uses it to determine which strategy data to save. The function then calls the dump_strategy method on either the Holdem or Shortdeck poker strategy object, depending on the mode of the solver job, passing in the save file path and dump round value as parameters.\\
## Code: 
```
void QSolverJob::saving(){
    qDebug().noquote() << tr("Saving json file..");//.toStdString() << std::endl;

    QSettings setting("TexasSolver", "Setting");
    setting.beginGroup("solver");
    this->dump_rounds = setting.value("dump_round").toInt();

    qDebug().noquote() << tr("Dump round: ") << this->dump_rounds;
    if(this->dump_rounds == 3){
        qDebug().noquote() << tr("This could be slow, or even blow your RAM, dump to river is not well optimized :(");
    }
    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.dump_strategy(this->savefile,this->dump_rounds);
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.dump_strategy(this->savefile,this->dump_rounds);
    }
    qDebug().noquote() << tr("Saving done.");//.toStdString() << std::endl;
}
```