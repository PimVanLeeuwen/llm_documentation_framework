**The function of `toString` is to return a string representation of two private cards in Texas Hold'em, with the lower card value first.**

**Code Description:** 
The `toString` method in the `PrivateCards` class takes no arguments and returns a string. It uses the `Card::intCard2Str` method to convert the integer values of the two private cards (`card1` and `card2`) into their corresponding string representations, and then concatenates these strings together with a space in between. The order of the cards is determined by comparing their values; if `card1` is greater than `card2`, they are returned in that order, otherwise they are returned in reverse order. This allows the method to consistently represent the two private cards as a single string, regardless of their relative values.\\
## Code: 
```
string PrivateCards::toString() {
    if (card1 > card2) {
        return Card::intCard2Str(card1) + Card::intCard2Str(card2);
    }else{
        return Card::intCard2Str(card2) + Card::intCard2Str(card1);
    }
}
```