**setTrunCard**: The function of `setTrunCard` is to set the current turn card in the game.

**Parameters**:
`Card turn_card`: This parameter represents the new turn card that will be set for the game. It is expected to be a valid Card object, which likely contains information about the rank and suit of the card.

**Code Description**: The `setTrunCard` function takes a `Card` object as input and assigns it to the instance variable `turn_card`. This means that whenever this function is called with a new `Card` object, the current turn card in the game will be updated to match the new value.\\
## Code: 
```
void TableStrategyModel::setTrunCard(Card turn_card){
    this->turn_card = turn_card;
}
```