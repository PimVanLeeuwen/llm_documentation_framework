`setupModelData`: The function of `setupModelData` is to set up the model data for a table strategy game, including initializing various vectors and maps to store card information, player ranges, and other relevant data.

**Code Description**: This code snippet appears to be part of a larger program that implements a table strategy game. It defines a method called `setupModelData` within a class named `TableStrategyModel`. The purpose of this method is to initialize various data structures used in the game, including vectors and maps to store card information, player ranges, and other relevant data.

The code first retrieves a list of cards from the deck and creates an unordered map (`cardint2card`) that maps each card's integer value to its corresponding `Card` object. It then initializes several vectors and maps to store various types of data, including:

*   A 3D vector (`ui_strategy_table`) to store strategy table information
*   Two 2D vectors (`p1_range` and `p2_range`) to store player range information
*   Three 3D vectors (`ui_p1_range`, `ui_p2_range`, and `total_strategy`) to store additional data related to the players' ranges and overall game strategy

The code also retrieves the player ranges from the solver job's solver object and populates the relevant vectors with this data. The player range information is used to update the `ui_p1_range` and `ui_p2_range` vectors, which are then used to store additional data related to the players' ranges.

Overall, the purpose of the `setupModelData` method appears to be to initialize the necessary data structures for the table strategy game, allowing it to function correctly.\\
## Code: 
```
void TableStrategyModel::setupModelData()
{
    vector<Card> cards = this->qSolverJob->get_solver()->get_deck()->getCards();
    vector<string> ranks = this->qSolverJob->get_solver()->get_deck()->getRanks();
    for(auto one_card: cards){
        this->cardint2card.insert(std::pair<int, Card>(one_card.getCardInt(), one_card));
    }

    this->ui_strategy_table = vector<vector<vector<pair<int,int>>>>(ranks.size());
    for(std::size_t i = 0;i < ranks.size();i ++){
        this->ui_strategy_table[i] = vector<vector<pair<int,int>>>(ranks.size());
        for(std::size_t j = 0;j < ranks.size();j ++){
            this->ui_strategy_table[i][j] = vector<pair<int,int>>();
        }
    }

    this->p1_range = vector<vector<float>>(52);
    for(std::size_t i = 0;i < 52;i ++){
        this->p1_range[i] = vector<float>(52);
        for(std::size_t j = 0;j < 52;j ++){
            this->p1_range[i][j] = 0;
        }
    }

    this->p2_range = vector<vector<float>>(52);
    for(std::size_t i = 0;i < 52;i ++){
        this->p2_range[i] = vector<float>(52);
        for(std::size_t j = 0;j < 52;j ++){
            this->p2_range[i][j] = 0;
        }
    }

    this->ui_p1_range = vector<vector<vector<pair<int,int>>>>(ranks.size());
    for(std::size_t i = 0;i < ranks.size();i ++){
        this->ui_p1_range[i] = vector<vector<pair<int,int>>>(ranks.size());
        for(std::size_t j = 0;j < ranks.size();j ++){
            this->ui_p1_range[i][j] = vector<pair<int,int>>();
        }
    }

    this->ui_p2_range = vector<vector<vector<pair<int,int>>>>(ranks.size());
    for(std::size_t i = 0;i < ranks.size();i ++){
        this->ui_p2_range[i] = vector<vector<pair<int,int>>>(ranks.size());
        for(std::size_t j = 0;j < ranks.size();j ++){
            this->ui_p2_range[i][j] = vector<pair<int,int>>();
        }
    }

    vector<PrivateCards>& p1range = this->qSolverJob->get_solver()->player1Range;
    vector<PrivateCards>& p2range = this->qSolverJob->get_solver()->player2Range;

    for(PrivateCards one_private: p1range){
        Card card1 = this->cardint2card[one_private.card1];
        Card card2 = this->cardint2card[one_private.card2];

        int rank1 = card1.getCardInt() / 4;
        int suit1 = card1.getCardInt() - (rank1)*4;
        int index1 = 12 - rank1; // this index is the index of the actal ui, so AKQ would be the lower index and 234 would be high

        int rank2 = card2.getCardInt() / 4;
        int suit2 = card2.getCardInt() - (rank2)*4;
        int index2 = 12 - rank2;

        if(index1 == index2){
            this->ui_p1_range[index1][index2].push_back(std::pair<int,int>(one_private.card1,one_private.card2));
        }
        else if(suit1 == suit2){
            this->ui_p1_range[min(index1,index2)][max(index1,index2)].push_back(std::pair<int,int>(one_private.card1,one_private.card2));
        }else{
            this->ui_p1_range[max(index1,index2)][min(index1,index2)].push_back(std::pair<int,int>(one_private.card1,one_private.card2));
        }
    }
    for(PrivateCards one_private: p2range){
        Card card1 = this->cardint2card[one_private.card1];
        Card card2 = this->cardint2card[one_private.card2];

        int rank1 = card1.getCardInt() / 4;
        int suit1 = card1.getCardInt() - (rank1)*4;
        int index1 = 12 - rank1; // this index is the index of the actal ui, so AKQ would be the lower index and 234 would be high

        int rank2 = card2.getCardInt() / 4;
        int suit2 = card2.getCardInt() - (rank2)*4;
        int index2 = 12 - rank2;

        if(index1 == index2){
            this->ui_p2_range[index1][index2].push_back(std::pair<int,int>(one_private.card1,one_private.card2));
        }
        else if(suit1 == suit2){
            this->ui_p2_range[min(index1,index2)][max(index1,index2)].push_back(std::pair<int,int>(one_private.card1,one_private.card2));
        }else{
            this->ui_p2_range[max(index1,index2)][min(index1,index2)].push_back(std::pair<int,int>(one_private.card1,one_private.card2));
        }
    }
    this->total_strategy = vector<pair<GameActions,pair<float,float>>>();
}
```