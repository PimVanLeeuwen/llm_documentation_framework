`setRiverCard`: The function of `setRiverCard` is to set the river card in the TableStrategyModel.

**Parameters**:
`Card river_card`: This parameter represents the card that will be assigned as the river card in the model.

**Code Description**: 
The `setRiverCard` method takes a `Card` object as input and assigns it to the `river_card` member variable of the `TableStrategyModel`.\\
## Code: 
```
void TableStrategyModel::setRiverCard(Card river_card){
    this->river_card = river_card;
}
```