`rowCount`: The function of `rowCount` is to return the number of rows in a table model.

**Parameters**: 
`const QModelIndex &parent`: This parameter represents the parent index of the item for which we want to retrieve the row count. It's used to specify the context in which the row count is being requested.

**Code Description**: The `rowCount` function retrieves the number of ranks from a deck using the `get_solver()->get_deck()->getRanks().size()` method, and returns this value as the row count for the specified parent index.\\
## Code: 
```
int TableStrategyModel::rowCount(const QModelIndex &parent) const
{
    return this->qSolverJob->get_solver()->get_deck()->getRanks().size();
}
```