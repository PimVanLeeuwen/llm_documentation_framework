`reGenerateTreeItem`: The function of `reGenerateTreeItem` is to recursively regenerate the tree item structure based on the provided game round and node to process.

**Parameters**:
`GameTreeNode::GameRound round`: This parameter represents the current game round, which is used to determine whether to continue processing child nodes.
`TreeItem* node_to_process`: This parameter points to the current tree item being processed, which serves as a starting point for the recursive regeneration of the tree structure.

**Code Description**: The `reGenerateTreeItem` function takes two parameters: `round` and `node_to_process`. It first checks if the game tree node associated with `node_to_process` is an action node. If it is, it retrieves the children nodes of the action node and recursively calls itself for each child node that matches the provided round number. If the game tree node is a chance node, it creates a new tree item representing the chance node's children and recursively calls itself for the newly created tree item.

The function uses dynamic casting to ensure that the correct type of game tree node is being processed. It also checks if the current round matches the provided round number before proceeding with the recursive regeneration of the tree structure.\\
## Code: 
```
void TreeModel::reGenerateTreeItem(GameTreeNode::GameRound round,TreeItem* node_to_process){
    const shared_ptr<GameTreeNode> gameTreeNode = node_to_process->m_treedata.lock();
    if(gameTreeNode->getType() == GameTreeNode::GameTreeNodeType::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(gameTreeNode);
        vector<shared_ptr<GameTreeNode>>& childrens = actionNode->getChildrens();
        for(shared_ptr<GameTreeNode> one_child:childrens){
            TreeItem * child_node = new TreeItem(one_child,node_to_process);
            node_to_process->insertChild(child_node);
            if(one_child->getRound() != round){
                continue;
            }
            this->reGenerateTreeItem(round,child_node);
        }
    }
    else if(gameTreeNode->getType() == GameTreeNode::GameTreeNodeType::CHANCE){
        shared_ptr<ChanceNode> chanceNode = dynamic_pointer_cast<ChanceNode>(gameTreeNode);
        TreeItem * child_node = new TreeItem(chanceNode->getChildren(),node_to_process);
        node_to_process->insertChild(child_node);
        this->reGenerateTreeItem(round,child_node);
    }
}
```