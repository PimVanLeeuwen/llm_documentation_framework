`setupModelData`: The function of `setupModelData` is to set up the model data for a tree structure, specifically in the context of poker game trees.

**Code Description**: This code snippet appears to be part of a larger system for visualizing or analyzing a game tree, likely in the context of poker or other card games. It sets up the model data by retrieving the root node of the game tree and creating a TreeItem object from it. The function then inserts this item into the tree structure as the root item. If the game tree is empty (i.e., its root node is null), the function returns without doing anything else.\\
## Code: 
```
void TreeModel::setupModelData()
{
    PokerSolver * solver;
    if(this->qSolverJob->mode == QSolverJob::Mode::HOLDEM){
        solver = &(this->qSolverJob->ps_holdem);
    }else if(this->qSolverJob->mode == QSolverJob::Mode::SHORTDECK){
        solver = &(this->qSolverJob->ps_shortdeck);
    }else{
        throw runtime_error("holdem mode incorrect");
    }

    if(solver->get_game_tree() == nullptr || solver->get_game_tree()->getRoot() == nullptr){
        return;
    }

    GameTreeNode::GameRound round =	solver->get_game_tree()->getRoot()->getRound();

    this->rootItem = new TreeItem(solver->get_game_tree()->getRoot());
    TreeItem* ti = new TreeItem(solver->get_game_tree()->getRoot(),this->rootItem);
    rootItem->insertChild(ti);
    this->reGenerateTreeItem(round,ti);
}
```