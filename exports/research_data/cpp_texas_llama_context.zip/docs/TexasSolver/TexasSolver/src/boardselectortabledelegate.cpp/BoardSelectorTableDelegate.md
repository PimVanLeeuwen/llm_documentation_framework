`BoardSelectorTableDelegate`: The function of `BoardSelectorTableDelegate` is to act as a delegate for displaying and editing data in a table view, specifically designed for selecting boards.

**Parameters**:
`QStringList ranks`: This parameter represents the list of available ranks that can be selected from the table.
`BoardSelectorTableModel *boardSelectorTableModel`: This parameter points to the model that manages the data displayed in the table, which is responsible for handling board selection logic.
`QObject *parent`: This parameter specifies the parent object of the delegate, indicating the ownership hierarchy.

**Code Description**: The `BoardSelectorTableDelegate` class inherits from `WordItemDelegate` and initializes its internal state by setting up a reference to the provided `rank_list`, `boardSelectorTableModel`, and `parent`.\\
## Code: 
```
BoardSelectorTableDelegate::BoardSelectorTableDelegate(QStringList ranks,BoardSelectorTableModel *boardSelectorTableModel,QObject *parent):WordItemDelegate(parent){
    this->rank_list = ranks;
    this->boardSelectorTableModel = boardSelectorTableModel;
}
```