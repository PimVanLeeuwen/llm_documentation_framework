`paint`: The function of `paint` is to draw a table item in the BoardSelectorTableDelegate class, representing a card from a Texas Hold'em game.

**Parameters**:
`QPainter *painter`: A pointer to a QPainter object used for drawing.
`const QStyleOptionViewItem &option`: A reference to a QStyleOptionViewItem object containing information about the item being painted.
`const QModelIndex &index`: A reference to a QModelIndex object representing the index of the item in the model.

**Code Description**: The `paint` function saves the current painter state, initializes a QStyleOptionViewItem object with the provided index, and then draws a gray rectangle for the entire item. It calculates the height of the folded part of the card based on its probability and draws a yellow rectangle for the remaining visible part. Finally, it translates the painter to the item's position, sets up a clip region, and draws the card's HTML representation using QTextDocument. The function then restores the original painter state.\\
## Code: 
```
void BoardSelectorTableDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const{

    painter->save();
    auto options = option;
    initStyleOption(&options, index);

    QRect rect(option.rect.left(), option.rect.top(),\
             option.rect.width(), option.rect.height());
    QBrush brush(Qt::gray);
    painter->fillRect(rect, brush);

    float board_float = this->boardSelectorTableModel->getBoardAt(index.row(),index.column());

    float fold_prob = 1 - board_float;
    int disable_height = (int)(fold_prob * option.rect.height());
    int remain_height = option.rect.height() - disable_height;

    rect = QRect(option.rect.left(), option.rect.top() + disable_height,\
     option.rect.width(), remain_height);
    brush = QBrush(Qt::yellow);
    painter->fillRect(rect, brush);

    QTextDocument doc;
    doc.setHtml(Card(options.text.toStdString()).toFormattedHtml());

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
    painter->restore();
}
```