`Rule`: The function of `Rule` is to initialize a rule object with given parameters and perform basic validation.

**Parameters**:
- `Deck deck`: Initializes the rule object with a given deck.
- `float oop_commit`: Sets the out-of-position commitment value for the rule.
- `float ip_commit`: Sets the in-position commitment value for the rule.
- `int current_round`: Specifies the current round of the game.
- `int raise_limit`: Sets the limit on raises allowed in the game.
- `float small_blind`: Sets the amount of the small blind.
- `float big_blind`: Sets the amount of the big blind.
- `float stack`: Initializes the rule object with a given effective stack size.
- `GameTreeBuildingSettings build_settings`: Specifies settings for building the game tree.
- `float allin_threshold`: Sets the threshold value for all-in actions.

**Code Description**: The code initializes a `Rule` object by setting its member variables based on the provided parameters. It checks if the out-of-position commitment and in-position commitment values are equal, throwing an exception if they are not. This ensures that the rule is properly configured before further processing or use.\\
## Code: 
```
Rule::Rule(Deck deck, float oop_commit, float ip_commit, int current_round, int raise_limit, float small_blind,
           float big_blind, float stack, GameTreeBuildingSettings build_settings,float allin_threshold):
           deck(deck),oop_commit(oop_commit),ip_commit(ip_commit),current_round(current_round),raise_limit(raise_limit),
           small_blind(small_blind),big_blind(big_blind),stack(stack),build_settings(build_settings),allin_threshold(allin_threshold){
    if(oop_commit != ip_commit) throw runtime_error("ip commit should equal with oop commit");
    this->initial_effective_stack = stack;
}
```