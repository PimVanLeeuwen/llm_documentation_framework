`RiverCombs`: The function of `RiverCombs` is to initialize an object of the RiverCombs class with the given parameters.

**Parameters**:
- `vector<int> board`: This parameter represents a vector of integers that stores the state of the game board.
- `PrivateCards private_cards`: This parameter represents an object of the PrivateCards class, which likely contains information about the player's private cards.
- `int rank`: This parameter is an integer representing the current rank or position in the game.
- `int reach_prob_index`: This parameter is an integer representing the index of a probability value related to reaching a certain state in the game.

**Code Description**: The RiverCombs function initializes the object's properties with the provided parameters, including the board state, private cards information, current rank, and reach probability index.\\
## Code: 
```
RiverCombs::RiverCombs(vector<int> board, PrivateCards private_cards, int rank, int reach_prob_index) {
    this->board = board;
    this->rank = rank;
    this->private_cards = private_cards;
    this->reach_prob_index = reach_prob_index;
}
```