`getChildrens`: The function of `getChildrens` is to return a vector of shared pointers to GameTreeNode objects, which represent the children nodes of the current ActionNode.

**Code Description**: This method simply returns the internal data structure "childrens" which holds the child nodes of the current ActionNode. It does not perform any additional operations or calculations, but rather provides access to the existing child nodes.\\
## Code: 
```
vector<shared_ptr<GameTreeNode>>& ActionNode::getChildrens() {
    return this->childrens;
}
```