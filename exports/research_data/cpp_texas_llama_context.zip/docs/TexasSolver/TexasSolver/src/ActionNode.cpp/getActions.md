`getActions`: The function of `getActions` is to return a reference to the vector of game actions stored in the current ActionNode.

**Code Description**: This method, `getActions`, is a member function of the `ActionNode` class. It returns a reference to a vector of `GameActions`. The vector, named `actions`, seems to be a data member of the `ActionNode` class itself, suggesting that each node in this action graph or tree stores its own set of actions. This method does not modify the state of the object; it simply provides access to the stored game actions.\\
## Code: 
```
vector<GameActions>& ActionNode::getActions() {
    return this->actions;
}
```