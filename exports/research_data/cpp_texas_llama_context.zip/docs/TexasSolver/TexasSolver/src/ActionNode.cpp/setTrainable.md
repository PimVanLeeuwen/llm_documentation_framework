`setTrainable`: The function of `setTrainable` is to set the trainable and private cards for an ActionNode.

**Parameters**:
`vector<shared_ptr<Trainable>> trainables`: A vector of shared pointers to Trainable objects, which represents the trainable cards.
`vector<PrivateCards>* player_privates`: A pointer to a vector of PrivateCards objects, which represents the private cards of a player.

**Code Description**: The `setTrainable` function takes two parameters: `trainables` and `player_privates`. It assigns the provided `trainables` vector to the `trainables` member variable of the ActionNode class. Similarly, it assigns the provided `player_privates` pointer to the `player_privates` member variable of the ActionNode class. This function is used to update the trainable and private cards for an ActionNode instance.\\
## Code: 
```
void ActionNode::setTrainable(vector<shared_ptr<Trainable>> trainables,vector<PrivateCards>* player_privates) {
    this->trainables = trainables;
    this->player_privates = player_privates;
}
```