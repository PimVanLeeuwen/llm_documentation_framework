`ActionNode`: The function of `ActionNode` is to create a new node in the game tree that represents an action taken by a player.

**Parameters**:
`vector<GameActions> actions`: A vector of possible actions that can be taken at this point in the game.
`vector<shared_ptr<GameTreeNode>> childrens`: A vector of child nodes, each representing a possible outcome of the current action.
`int player`: The ID of the player who is taking the action.
`GameTreeNode::GameRound round`: The current round number in the game.
`double pot`: The current size of the pot (the amount of money at stake).
`shared_ptr<GameTreeNode> parent`: A pointer to the parent node, representing the previous state of the game.

**Code Description**: This code snippet defines a constructor for an `ActionNode` class. It initializes the object's properties with the provided parameters and calls the base class (`GameTreeNode`) constructor to set up the node's round number, pot size, and parent pointer. The `std::move` function is used to transfer ownership of the vectors and shared pointers to the new object, ensuring efficient memory management.\\
## Code: 
```
ActionNode::ActionNode(vector<GameActions> actions, vector<shared_ptr<GameTreeNode>> childrens, int player,
                       GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent) :GameTreeNode(round,pot,std::move(parent)){
    this->actions = std::move(actions);
    this->player = player;
    this->childrens = std::move(childrens);
    //cout << "ActionNode created" << endl;
}
```