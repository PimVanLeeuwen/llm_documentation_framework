`clear_board`: The function of `clear_board` is to reset all values in the grids_float array to zero, effectively clearing the board.

**Code Description**: This method iterates through each element in the 2D grids_float array and sets its value to 0. The array represents a table with suitlist.size() rows and ranklist.size() columns, where each cell stores a float value. By setting all values to zero, the function clears any previously stored data in the board, preparing it for new input or calculations.\\
## Code: 
```
void BoardSelectorTableModel::clear_board(){
    for(int i = 0;i < this->suitlist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_float[i][j] = 0;
        }
    }
}
```