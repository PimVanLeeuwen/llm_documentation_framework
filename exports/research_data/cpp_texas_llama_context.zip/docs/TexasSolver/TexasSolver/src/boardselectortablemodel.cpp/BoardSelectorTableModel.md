`BoardSelectorTableModel`: The function of `BoardSelectorTableModel` is to initialize a table model for selecting boards in TexasSolver.

**Parameters**:
`QStringList ranks`: A list of card ranks.
`QString initial_board`: The initial board text to be set in the model.
`QObject *parent`: The parent object of the table model.

**Code Description**: 
The code initializes a `BoardSelectorTableModel` by setting up a 2D grid based on the provided ranks and suit lists. It also sets the initial board text from the input string, converting each board to a floating-point value and updating the grid accordingly. The model is initialized with an empty parent object.\\
## Code: 
```
BoardSelectorTableModel::BoardSelectorTableModel(QStringList ranks,QString initial_board,QObject *parent):QAbstractItemModel(parent){
    this->ranklist = ranks;
    this->suitlist = QString("c,d,h,s").split(",");

    this->grids_string = vector<vector<QString>>(this->suitlist.size());
    for(int i = 0;i < this->suitlist.size();i ++){
        this->grids_string[i] = vector<QString>(this->ranklist.size());
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_string[i][j] = this->get_ij_text(i,j);
            this->string2ij[this->get_ij_text(i,j)] = pair<int,int>(i,j);
        }
    }

    this->grids_float = vector<vector<float>>(this->suitlist.size());
    for(int i = 0;i < this->suitlist.size();i ++){
        this->grids_float[i] = vector<float>(this->ranklist.size(),0.0);
    }
    this->setBoardText(initial_board);
}
```