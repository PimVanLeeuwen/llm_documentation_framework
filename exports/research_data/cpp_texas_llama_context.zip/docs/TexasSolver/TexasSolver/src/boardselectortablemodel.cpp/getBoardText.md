`getBoardText`: The function of `getBoardText` is to generate a string representation of the board, where each cell in the grid that has a value (i.e., not zero) is included in the string.

**Code Description**: This method iterates over two lists (`suitlist` and `ranklist`) which are presumably used to index into a 2D array (`grids_float` or `grids_string`). For each non-zero cell, it appends the corresponding string value from `grids_string` to a result string (`retval`). The resulting string is then returned.\\
## Code: 
```
QString BoardSelectorTableModel::getBoardText(){
    QString retval = "";
    for(int i = 0;i < this->suitlist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            if(this->grids_float[i][j] == 0)continue;
            QString one_board_str = QString("%1").arg(this->grids_string[i][j]);
            if(retval == ""){
                retval = one_board_str;
            }else{
                retval = retval + "," + one_board_str;
            }
        }
    }
    return retval;
}
```