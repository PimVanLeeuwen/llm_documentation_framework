`setBoardText`: The function of `setBoardText` is to update the board grid with a new set of floating-point values based on the provided string representation.

**Parameters**: 
`QString input_board`: This parameter represents the string containing the board data, where each value is separated by commas.

**Code Description**: 
The code iterates over each value in the input string, splitting it into individual boards. It then checks if the format of each board is valid and if it exists in a predefined mapping (`string2ij`). If the format is correct and the board exists, its corresponding coordinates are retrieved from the mapping, and the floating-point value `board_float` (set to 1.0) is assigned to the grid at those coordinates.\\
## Code: 
```
void BoardSelectorTableModel::setBoardText(QString input_board){
    this->clear_board();
    for(QString one_board:input_board.split(",")){
        float board_float = 1.0;


        if(one_board.count(" ") == one_board.length() || one_board == "")continue;
        if(!this->string2ij.count(one_board)){
            qDebug().noquote() << QString(tr("skipping board %1, format error")).arg(one_board);
            continue;
        }
        pair<int,int> cord = this->string2ij[one_board];
        this->grids_float[cord.first][cord.second] = board_float;
    }
}
```