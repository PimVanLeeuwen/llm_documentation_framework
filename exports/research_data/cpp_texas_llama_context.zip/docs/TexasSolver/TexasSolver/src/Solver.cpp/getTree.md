## getTree: The function of `getTree` is to return a shared pointer to the game tree associated with the solver.

**Code Description**: The `getTree` method in the `Solver` class returns a shared pointer to the `GameTree` object, which is stored as an instance variable (`this->tree`). This suggests that the solver maintains its own internal representation of the game tree, and this method provides access to it.\\
## Code: 
```
shared_ptr<GameTree> Solver::getTree() {
    return this->tree;
}
```