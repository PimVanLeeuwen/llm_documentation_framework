`TerminalNode`: The function of `TerminalNode` is to represent a terminal node in the game tree, which signifies the end of a game round.

**Parameters**:
`vector<double> payoffs`: A vector of double values representing the payoffs for each player at this terminal node.
`int winner`: An integer indicating the winner of the current game round.
`GameTreeNode::GameRound round`: An object of type `GameTreeNode::GameRound` representing the current game round.
`double pot`: A double value representing the current pot size.
`shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node in the game tree.

**Code Description**: The `TerminalNode` constructor initializes a terminal node with the given payoffs, winner, game round, pot size, and parent node. It sets up the necessary attributes for this type of node in the game tree.\\
## Code: 
```
TerminalNode::TerminalNode(vector<double> payoffs, int winner, GameTreeNode::GameRound round, double pot,
                           shared_ptr<GameTreeNode> parent):GameTreeNode(round,pot,parent){
    this->payoffs = payoffs;
    this->winner = winner;
}
```