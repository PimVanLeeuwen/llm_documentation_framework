`getRiverCombos`: The function of `getRiverCombos` is to retrieve or generate river combinations for a Texas Hold'em poker game based on preflop hand combinations and the board state.

**Parameters**:
`int player`: This parameter represents the current player in the game.
`const vector<PrivateCards> &riverCombos`: This parameter contains a set of private cards that have been dealt to each player, which are used as input for generating river combinations.
`const vector<int> &board`: This parameter represents the state of the board, consisting of integers that correspond to card IDs.

**Code Description**: The `getRiverCombos` function first converts the board state from a vector of integers into a single 64-bit unsigned integer using the `boardInts2long` method. It then calls another instance of `getRiverCombos` with the converted board state, passing it along with the player and river combinations as parameters. The function returns a reference to a vector of river combinations.\\
## Code: 
```
const vector<RiverCombs> &
RiverRangeManager::getRiverCombos(int player, const vector<PrivateCards> &riverCombos, const vector<int> &board) {
    uint64_t board_long = Card::boardInts2long(board);
    return this->getRiverCombos(player,riverCombos,board_long);
}
```