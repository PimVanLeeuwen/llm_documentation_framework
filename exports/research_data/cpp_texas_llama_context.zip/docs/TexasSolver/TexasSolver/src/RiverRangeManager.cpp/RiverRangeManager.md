`RiverRangeManager`: The function of `RiverRangeManager` is to manage the river range in a Texas Hold'em game.

**Parameters**: 
`shared_ptr<Compairer> handEvaluator`: This parameter is an instance of a hand evaluator, which is used to evaluate the strength of hands.

**Code Description**: 
The code initializes the RiverRangeManager object by setting up its internal state. It takes a shared pointer to a Compairer object as input and stores it in the `handEvaluator` member variable. The `maplock` member variable is also initialized with a new shared pointer to a mutex, which is used for synchronization purposes.\\
## Code: 
```
RiverRangeManager::RiverRangeManager(shared_ptr<Compairer> handEvaluator) {
    this->handEvaluator = std::move(handEvaluator);
    this->maplock = std::make_shared<std::mutex>();
}
```