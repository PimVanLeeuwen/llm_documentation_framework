`GameTreeBuildingSettings`: The function of `GameTreeBuildingSettings` is to initialize and set up the settings for building a game tree in Texas Hold'em poker.

**Parameters**:
`StreetSetting flop_ip`: This parameter represents the street setting for the pre-flop phase, where "ip" likely stands for "in position", indicating the player's position relative to the dealer.
`StreetSetting turn_ip`: This parameter represents the street setting for the turn phase, also in position.
`StreetSetting river_ip`: This parameter represents the street setting for the river phase, again in position.
`StreetSetting flop_oop`: This parameter represents the street setting for the pre-flop phase, where "oop" likely stands for "out of position", indicating the player's position relative to the dealer.
`StreetSetting turn_oop`: This parameter represents the street setting for the turn phase, out of position.
`StreetSetting river_oop`: This parameter represents the street setting for the river phase, also out of position.

**Code Description**: The `GameTreeBuildingSettings` function is a constructor that initializes an object with the given parameters. It sets up the settings for building a game tree in Texas Hold'em poker, specifically for different streets (pre-flop, turn, and river) and positions (in position and out of position).\\
## Code: 
```
GameTreeBuildingSettings::GameTreeBuildingSettings(
        StreetSetting flop_ip,
        StreetSetting turn_ip,
        StreetSetting river_ip,
        StreetSetting flop_oop,
        StreetSetting turn_oop,
        StreetSetting river_oop):flop_ip(flop_ip),turn_ip(turn_ip),river_ip(river_ip),flop_oop(flop_oop),turn_oop(turn_oop),river_oop(river_oop) {
}
```