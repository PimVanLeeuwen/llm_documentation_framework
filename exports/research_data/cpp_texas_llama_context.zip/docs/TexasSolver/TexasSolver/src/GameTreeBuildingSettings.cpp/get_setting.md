`get_setting`: The function of `get_setting` is to retrieve a specific StreetSetting object based on the input parameters.

**Parameters**:
`string player`: This parameter represents the position of the player, either "ip" (inner position) or "oop" (outer position).
`string round`: This parameter represents the current round of the game, which can be "flop", "turn", or "river".

**Code Description**: The `get_setting` function takes two string parameters, `player` and `round`, and returns a reference to a StreetSetting object. It uses if-else statements to determine which StreetSetting object to return based on the input values of `player` and `round`. If the input combination is not valid, it throws a runtime_error with the message "get_setting not valid".\\
## Code: 
```
StreetSetting& GameTreeBuildingSettings::get_setting(string player,string round){
    if(player == "ip" && round == "flop") return flop_ip;
    else if(player == "ip" && round == "turn") return turn_ip;
    else if(player == "ip" && round == "river") return river_ip;
    else if(player == "oop" && round == "flop") return flop_oop;
    else if(player == "oop" && round == "turn") return turn_oop;
    else if(player == "oop" && round == "river") return river_oop;
    else throw runtime_error("get_setting not valid");
}
```