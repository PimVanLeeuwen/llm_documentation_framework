**load**: The function loads a comparison file into memory.
**Parameters**: 
`const char* file_path`: A pointer to the path of the file to be loaded.

**Code Description**: This function reads data from a binary file and populates two maps, `flush_map` and `other_map`, with key-value pairs. It first checks if the file can be opened for reading, and if not, it throws an exception. The function then reads the number of entries in each map from the file, followed by the key-value pairs themselves. After loading both maps, it asserts that their sizes match the expected count. Finally, it closes the file and returns true to indicate successful loading.\\
## Code: 
```
bool FiveCardsStrength::load(const char* file_path) {
    //ifstream file(file_path, ios::binary);
    /*if (!file) {
        file.close();
        return false;
    }*/

    QFile file(QString::fromStdString(file_path));
    if (!file.open(QIODevice::ReadOnly)){
        throw runtime_error("unable to load compairer file");
    }
    flush_map.clear(); other_map.clear();
    int size_key = sizeof(uint64_t), size_int = sizeof(int), val, cnt = 0;
    uint64_t key = 0;
    char* p_key = (char*)&key, * p_val = (char*)&val, * p_cnt = (char*)&cnt;
    file.read(p_cnt, size_int);// 读取行数
    for (int i = 0; i < cnt; i++) {
        file.read(p_key, size_key);
        file.read(p_val, size_int);
        flush_map[key] = val;
    }
    assert(flush_map.size() == cnt);
    file.read(p_cnt, size_int);// 读取行数
    for (int i = 0; i < cnt; i++) {
        file.read(p_key, size_key);
        file.read(p_val, size_int);
        other_map[key] = val;
    }
    assert(other_map.size() == cnt);
    file.close();
    return true;
}
```