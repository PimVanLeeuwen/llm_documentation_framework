`get_rank`: The function of `get_rank` is to determine the rank of a poker hand given a private hand and a public board.

**Parameters**:
`uint64_t private_hand`: A 64-bit unsigned integer representing a long that contains information about the player's private cards.
`uint64_t public_board`: A 64-bit unsigned integer representing a long that contains information about the community cards on the table.

**Code Description**: The `get_rank` function first converts the input integers into board representations using the `long2board` method from the `Card` class. It then calls another `get_rank` method (not shown in this snippet) to determine the rank of the poker hand based on the converted private hand and public board.\\
## Code: 
```
int Dic5Compairer::get_rank(uint64_t private_hand, uint64_t public_board) {
    return this->get_rank(Card::long2board(private_hand),Card::long2board(public_board));
}
```