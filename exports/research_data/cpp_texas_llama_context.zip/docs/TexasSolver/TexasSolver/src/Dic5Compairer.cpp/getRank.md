`getRank`: The function of `getRank` is to calculate the minimum rank of a given set of 5 cards in poker.

**Parameters**:\
`vector<Card> cards`: A vector of Card objects representing the 5 cards to be ranked.

**Code Description**: 
The code first converts each Card object in the input vector into an integer using the `getCardInt()` method, and stores these integers in a new vector. It then calls another function named `getRank()` (presumably defined elsewhere) with this new vector of integers as input, and returns the result. The `getCardInt()` method is assumed to return a unique integer value for each Card object, likely representing its rank or suit in poker.\\
## Code: 
```
int Dic5Compairer::getRank(vector<Card> cards) {
    vector<int> cards_int(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_int[i] = cards[i].getCardInt();
    }
    return this->getRank(cards_int);
}
```