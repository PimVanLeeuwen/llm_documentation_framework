`convert`: The function of `convert` is to process an unordered map of poker hand strengths and categorize them into flush and non-flush hands.

**Parameters**:
`unordered_map<uint64_t, int>& strength_map`: This parameter represents the input unordered map containing poker hand hashes as keys and their corresponding strengths as values.

**Code Description**: The `convert` function iterates over each entry in the input unordered map, calculates a hash value using the `ranks_hash` function, and checks if the original hash has a flush using the `is_flush` function. If it's a flush, the strength is stored in the `flush_map`. Otherwise, the strength is stored in the `other_map` with the calculated hash as the key. The function then clears the contents of both maps at the beginning and end of the process.\\
## Code: 
```
void FiveCardsStrength::convert(unordered_map<uint64_t, int>& strength_map) {
    flush_map.clear(); other_map.clear();
    auto it = strength_map.begin(), it_end = strength_map.end();
    for (; it != it_end; it++) {
        uint64_t cards_hash = it->first;
        uint64_t hash = ranks_hash(cards_hash);
        if (is_flush(cards_hash)) flush_map[cards_hash] = it->second;
        else {
            /*if (other_map.count(hash) && other_map[hash] != it->second) {
                printf("%zx,%zx:%d != %d\n", cards_hash, hash, it->second, other_map[hash]);
            }*/
            other_map[hash] = it->second;
        }
    }
}
```