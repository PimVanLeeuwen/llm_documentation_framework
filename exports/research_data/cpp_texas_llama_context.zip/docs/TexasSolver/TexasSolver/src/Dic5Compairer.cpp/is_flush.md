`is_flush`: The function of `is_flush` is to determine whether a given poker hand is a flush.
**Parameters**:\
`uint64_t hash`: A 64-bit unsigned integer representing the hash value of a poker hand, where each bit corresponds to a specific suit (0-3) in the hand.
**Code Description**: The function iterates through the bits of the input hash value, counting the number of set bits for suits 0 and 1. If this count is greater than 1, it immediately returns false, indicating that the hand is not a flush. It then continues to count the set bits for suits 2 and 3, returning false if the total count exceeds 1. Otherwise, it returns true, indicating that the hand is indeed a flush.\\
## Code: 
```
bool is_flush(uint64_t hash) {
    int cnt = (hash & SUIT_0_MASK) != 0;
    cnt += (hash & SUIT_1_MASK) != 0;
    if (cnt > 1) return false;
    cnt += (hash & SUIT_2_MASK) != 0;
    if (cnt > 1) return false;
    cnt += (hash & SUIT_3_MASK) != 0;
    return cnt > 1 ? false : true;
}
```