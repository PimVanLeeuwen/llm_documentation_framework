`compairRanks`: The function compares the ranks of two cards.
**Parameters**:
`int rank_former`: The rank of the former card.
`int rank_latter`: The rank of the latter card.

**Code Description**: This function takes two integer parameters, `rank_former` and `rank_latter`, which represent the ranks of two cards. It returns a `CompairResult` enum value indicating whether the former card is larger (`LARGER`), smaller (`SMALLER`), or equal to the latter card (`EQUAL`). The comparison is based on the standard poker ranking system, where 0 represents a straight flush and higher numbers represent higher ranks.\\
## Code: 
```
Compairer::CompairResult Dic5Compairer::compairRanks(int rank_former, int rank_latter) {
    if (rank_former < rank_latter) {
        // rank更小的牌更大，0是同花顺
        return CompairResult::LARGER;
    } else if (rank_former > rank_latter) {
        return CompairResult::SMALLER;
    } else {
        // rank_former == rank_latter
        return CompairResult::EQUAL;
    }
}
```