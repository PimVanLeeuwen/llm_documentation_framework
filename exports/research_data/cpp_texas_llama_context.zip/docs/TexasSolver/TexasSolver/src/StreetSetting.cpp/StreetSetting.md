`StreetSetting`: The function of `StreetSetting` is to initialize a StreetSetting object with the given parameters.

**Parameters**:
`vector<float> bet_sizes`: This parameter represents a vector of betting sizes.
`vector<float> raise_sizes`: This parameter represents a vector of raising sizes.
`vector<float> donk_sizes`: This parameter represents a vector of donking sizes.
`bool allin`: This parameter is a boolean indicating whether the setting is an all-in situation.

**Code Description**: The `StreetSetting` function initializes the object's member variables (`bet_sizes`, `raise_sizes`, `donk_sizes`, and `allin`) with the provided values.\\
## Code: 
```
StreetSetting::StreetSetting(vector<float> bet_sizes, vector<float> raise_sizes, vector<float> donk_sizes,
                             bool allin) {
    this->bet_sizes = bet_sizes;
    this->raise_sizes = raise_sizes;
    this->donk_sizes = donk_sizes;
    this->allin = allin;
}
```