`reset`: The function of `reset` is to reset the progress bar's state, including setting the progress to 0, indicating that no updates have been called since the last reset, and resetting the last percentage value.

**Code Description**: 
The `reset` method in the `progressbar` class resets its internal state. It sets the `progress` variable to 0, which likely represents the current progress towards a goal or completion of an operation. The `update_is_called` flag is set to false, indicating that no updates have been made since the last reset. Finally, the `last_perc` variable, which stores the last percentage value displayed by the progress bar, is also reset to 0. This ensures that the progress bar starts from a clean slate after being reset.\\
## Code: 
```
void progressbar::reset() {
    progress = 0,
            update_is_called = false;
    last_perc = 0;
    return;
}
```