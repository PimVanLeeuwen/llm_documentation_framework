`update`: The function of `update` is to update a progress bar display, showing the current percentage completion of a task.

**Code Description**: 
The `update` function updates a progress bar display by calculating and displaying the current percentage completion of a task. It first checks if the number of cycles has been set, throwing an error if not. If the progress bar is to be shown, it prints the opening bracket character, followed by 50 'todo' characters, then the closing bracket character and the initial percentage (0%). The function then calculates the current percentage completion based on the progress made so far and the total number of cycles. If the calculated percentage has not changed since the last update, the function does nothing and returns. Otherwise, it updates the display by printing the new percentage and updating the progress bar accordingly. The progress bar is updated every ten units of progress, with each unit being represented by a 'done' character replacing one 'todo' character. The function also keeps track of the last calculated percentage to avoid unnecessary updates.\\
## Code: 
```
void progressbar::update() {
    return;
    if (n_cycles == 0) throw std::runtime_error(
                "progressbar::update: number of cycles not set");

    if (!update_is_called) {
        if (do_show_bar == true) {
            std::cout << opening_bracket_char;
            for (int _ = 0; _ < 50; _++) std::cout << todo_char;
            std::cout << closing_bracket_char << " 0%";
        }
        else std::cout << "0%";
    }
    update_is_called = true;

    int perc = 0;

    // compute percentage, if did not change, do nothing and return
    perc = progress*100./(n_cycles-1);
    if (perc < last_perc) return;

    // update percentage each unit
    if (perc == last_perc + 1) {
        // erase the correct  number of characters
        if      (perc <= 10)                std::cout << "\b\b"   << perc << '%';
        else if (perc  > 10 && perc < 100) std::cout << "\b\b\b" << perc << '%';
        else if (perc == 100)               std::cout << "\b\b\b" << perc << '%';
    }
    if (do_show_bar == true) {
        // update bar every ten units
        if (perc % 2 == 0) {
            // erase closing bracket
            std::cout << std::string(closing_bracket_char.size(), '\b');
            // erase trailing percentage characters
            if      (perc  < 10)               std::cout << "\b\b\b";
            else if (perc >= 10 && perc < 100) std::cout << "\b\b\b\b";
            else if (perc == 100)              std::cout << "\b\b\b\b\b";

            // erase 'todo_char'
            for (int j = 0; j < 50-(perc-1)/2; ++j) {
                std::cout << std::string(todo_char.size(), '\b');
            }

            // add one additional 'done_char'
            if (perc == 0) std::cout << todo_char;
            else           std::cout << done_char;

            // refill with 'todo_char'
            for (int j = 0; j < 50-(perc-1)/2-1; ++j) std::cout << todo_char;

            // readd trailing percentage characters
            std::cout << closing_bracket_char << ' ' << perc << '%';
        }
    }
    last_perc = perc;
    ++progress;
    std::cout << std::flush;

    return;
}
```