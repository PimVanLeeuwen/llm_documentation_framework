`progressbar`: The function of `progressbar` is to initialize a progress bar object with the specified parameters.

**Parameters**:
- `int n`: This parameter represents the total number of cycles or iterations for which the progress bar will be updated.
- `bool showbar`: This boolean flag determines whether the progress bar should be displayed or not. If set to true, the progress bar will be shown; otherwise, it will remain hidden.

**Code Description**: The code initializes a `progressbar` object with the given parameters. It sets up internal variables such as `progress`, `n_cycles`, `last_perc`, `do_show_bar`, `update_is_called`, `done_char`, `todo_char`, `opening_bracket_char`, and `closing_bracket_char`. These variables are used to track the progress, display the progress bar, and manage its appearance. The constructor takes two parameters: the total number of cycles (`n`) and a boolean flag indicating whether to show the progress bar (`showbar`).\\
## Code: 
```
progressbar::progressbar(int n, bool showbar) :
        progress(0),
        n_cycles(n),
        last_perc(0),
        do_show_bar(showbar),
        update_is_called(false),
        done_char("#"),
        todo_char(" "),
        opening_bracket_char("["),
        closing_bracket_char("]") {}
```