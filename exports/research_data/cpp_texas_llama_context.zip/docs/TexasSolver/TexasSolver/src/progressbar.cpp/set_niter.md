`set_niter`: The function of `set_niter` is to set the number of iterations for a progress bar.

**Parameters**:
`int niter`: This parameter represents the total number of iterations that the progress bar will display. It must be a positive integer, as indicated by the error handling in the code.

**Code Description**: The `set_niter` function checks if the provided number of iterations is valid (i.e., greater than 0). If it's not, an invalid_argument exception is thrown with a message indicating that the number of iterations cannot be null or negative. Otherwise, it updates the internal variable `n_cycles` to store the new number of iterations.\\
## Code: 
```
void progressbar::set_niter(int niter) {
    if (niter <= 0) throw std::invalid_argument(
                "progressbar::set_niter: number of iterations null or negative");
    n_cycles = niter;
    return;
}
```