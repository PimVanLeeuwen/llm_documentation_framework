`getAverageStrategy`: The function calculates the average strategy for a given set of actions and cards in a discounted CFR (Counterfactual Regret Minimization) algorithm.

**Code Description**: This method appears to be part of a class called `DiscountedCfrTrainable`. It initializes an empty vector `average_strategy` with a size equal to the product of the number of actions (`action_number`) and the number of cards (`card_number`). The function then iterates over each private card, calculates the sum of regrets for all actions given that private card, and updates the average strategy for each action based on this sum. If the sum is zero, it assigns a uniform probability to each action.\\
## Code: 
```
const vector<float> DiscountedCfrTrainable::getAverageStrategy() {
    vector<float> average_strategy;
    average_strategy = vector<float>(this->action_number * this->card_number);
    for (int private_id = 0; private_id < this->card_number; private_id++) {
        float r_plus_sum = 0;
        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            r_plus_sum += this->cum_r_plus[index];
        }

        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            if(r_plus_sum) {
                average_strategy[index] = this->cum_r_plus[index] / r_plus_sum;
            }else{
                average_strategy[index] = 1.0 / this->action_number;
            }
        }
    }
    return average_strategy;
}
```