`DiscountedCfrTrainable`: The function of `DiscountedCfrTrainable` is to initialize and set up the necessary data structures for computing discounted CFR values.

**Parameters**:
`vector<PrivateCards> *privateCards`: This parameter represents a vector of private cards, which are used to determine the possible actions in the game.
`ActionNode &actionNode`: This parameter references an ActionNode object, which contains information about the current state of the game and its children nodes.

**Code Description**: The `DiscountedCfrTrainable` function initializes several vectors to store the expected values (evs), rewards plus (r_plus), cumulative rewards plus (cum_r_plus), and other necessary data. It also sets up the action number, card number, and other variables based on the input parameters. This setup is crucial for computing discounted CFR values in a game tree structure.\\
## Code: 
```
DiscountedCfrTrainable::DiscountedCfrTrainable(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();

    this->evs = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus_sum = vector<float>(this->card_number,0.0);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number,0.0);
    //this->cum_r_plus_sum = vector<float>(this->card_number);
}
```