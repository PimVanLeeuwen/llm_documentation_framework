## Expected output
`getcurrentStrategyNoCache`: The function of `getcurrentStrategyNoCache` is to return the current strategy for a game, without using any cache.

**Code Description**: This function calculates and returns the current strategy for a game, based on the values stored in the `r_plus_sum` vector. If the `r_plus_sum` vector is empty, it initializes the current strategy with equal probabilities for each action. Otherwise, it iterates over each action and private card combination, calculating the probability of choosing that action given the `r_plus_sum` value for the corresponding private card. The function returns a vector of these calculated probabilities.\\
## Code: 
```
const vector<float> DiscountedCfrTrainable::getcurrentStrategyNoCache() {
    vector<float> current_strategy;
    current_strategy = vector<float>(this->action_number * this->card_number);
    if(this->r_plus_sum.empty()){
        fill(current_strategy.begin(),current_strategy.end(),1.0 / this->action_number);
    }else {
        for (int action_id = 0; action_id < action_number; action_id++) {
            for (int private_id = 0; private_id < this->card_number; private_id++) {
                int index = action_id * this->card_number + private_id;
                if(this->r_plus_sum[private_id] != 0) {
                    current_strategy[index] = max(float(0.0),this->r_plus[index]) / this->r_plus_sum[private_id];
                }else{
                    current_strategy[index] = 1.0 / (this->action_number);
                }
#ifdef DEBUG
                if(this->r_plus[index] != this->r_plus[index]) throw runtime_error("nan found");
#endif
            }
        }
    }
```