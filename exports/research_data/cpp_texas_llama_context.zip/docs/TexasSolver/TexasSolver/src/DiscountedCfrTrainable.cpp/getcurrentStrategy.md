`getcurrentStrategy`: The function of `getcurrentStrategy` is to return the current strategy in a game, using discounted CFR values.

**Code Description**: This code snippet defines a method called `getcurrentStrategy` within the class `DiscountedCfrTrainable`. It simply calls another method named `getcurrentStrategyNoCache` and returns its result. The purpose of this method is to retrieve the current strategy in a game, utilizing discounted Counterfactual Regret (CFR) values. The implementation details are handled by the `getcurrentStrategyNoCache` method, which is not shown here but presumably calculates the current strategy based on available data or other factors.\\
## Code: 
```
const vector<float> DiscountedCfrTrainable::getcurrentStrategy() {
    return this->getcurrentStrategyNoCache();
}
```