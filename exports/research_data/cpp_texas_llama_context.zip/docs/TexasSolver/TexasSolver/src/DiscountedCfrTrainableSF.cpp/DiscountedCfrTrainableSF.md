`DiscountedCfrTrainableSF`: The function of `DiscountedCfrTrainableSF` is to initialize the object's attributes for training a discounted CFR (Counterfactual Regret Minimization) algorithm in a Texas Hold'em game.

**Parameters**:
`vector<PrivateCards> *privateCards`: This parameter represents the private cards held by each player, which are used to calculate the expected values and regrets during the training process.
`ActionNode &actionNode`: This parameter is an ActionNode object that contains information about the current game state, including the available actions and their corresponding child nodes.

**Code Description**: The code initializes the `DiscountedCfrTrainableSF` object by setting its attributes based on the provided parameters. It sets up vectors to store expected values (EvsStorage), R+ values (RplusStorage), and cumulative R+ values (CumRplusStorage) for each possible action and private card combination. The size of these vectors is determined by the number of actions and private cards available in the game state. This setup is necessary for training a discounted CFR algorithm, which requires calculating expected values and regrets for all possible game outcomes.\\
## Code: 
```
DiscountedCfrTrainableSF::DiscountedCfrTrainableSF(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();
    this->evs = vector<EvsStorage>(this->action_number * this->card_number, (EvsStorage) 0.0);
    this->r_plus = vector<RplusStorage>(this->action_number * this->card_number, (RplusStorage) 0.0);
    this->cum_r_plus = vector<CumRplusStorage>(this->action_number * this->card_number, (CumRplusStorage) 0.0);
}
```