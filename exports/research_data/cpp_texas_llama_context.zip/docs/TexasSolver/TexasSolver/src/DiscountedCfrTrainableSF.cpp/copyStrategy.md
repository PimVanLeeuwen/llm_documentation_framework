`copyStrategy`: The function of `copyStrategy` is to copy the strategy from another trainable object.

**Parameters**:\
`shared_ptr<Trainable> other_trainable`: This parameter is a shared pointer to another Trainable object, which contains the strategy to be copied.

**Code Description**: *FILL IN*
The code description should be: The `copyStrategy` function dynamically casts the input `other_trainable` to a `DiscountedCfrTrainableSF` object and then copies its `r_plus` and `cum_r_plus` data structures into the current object's corresponding data structures.\\
## Code: 
```
void DiscountedCfrTrainableSF::copyStrategy(shared_ptr<Trainable> other_trainable){
    shared_ptr<DiscountedCfrTrainableSF> trainable = dynamic_pointer_cast<DiscountedCfrTrainableSF>(other_trainable);
    this->r_plus.assign(trainable->r_plus.begin(),trainable->r_plus.end());
    this->cum_r_plus.assign(trainable->cum_r_plus.begin(),trainable->cum_r_plus.end());
}
```