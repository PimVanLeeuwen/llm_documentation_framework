`getAverageStrategy`: The function calculates the average strategy for a given game state, taking into account the cumulative regret values and the number of actions and cards.

**Code Description**: This method iterates over each private card ID and calculates the sum of cumulative regret values for all possible actions. It then divides the cumulative regret value for each action by this sum to obtain the average strategy probability for that action given the current private card. If the sum is zero, it assigns a uniform distribution across all actions. The resulting probabilities are stored in the `average_strategy` vector and returned.\\
## Code: 
```
const vector<float> DiscountedCfrTrainableSF::getAverageStrategy() {
    vector<float> average_strategy;
    average_strategy = vector<float>(this->action_number * this->card_number);
    for (int private_id = 0; private_id < this->card_number; private_id++) {
        float r_plus_sum = 0;
        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            r_plus_sum += this->cum_r_plus[index];
        }

        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            if(r_plus_sum) {
                average_strategy[index] = this->cum_r_plus[index] / r_plus_sum;
            }else{
                average_strategy[index] = 1.0 / this->action_number;
            }
        }
    }
    return average_strategy;
}
```