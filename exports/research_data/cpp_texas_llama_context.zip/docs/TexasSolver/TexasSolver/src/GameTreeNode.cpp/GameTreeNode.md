`GameTreeNode`: The function of `GameTreeNode` is to represent a node in the game tree, storing information about the current round, pot size, and its parent node.

**Parameters**:
- `GameTreeNode::GameRound round`: This parameter represents the current round of the game.
- `double pot`: This parameter stores the current pot size.
- `shared_ptr<GameTreeNode> parent`: This parameter points to the parent node in the game tree.

**Code Description**: The code snippet provided is a constructor for the `GameTreeNode` class. It initializes the object's properties with the given values and sets up the relationship between nodes by setting the parent pointer.\\
## Code: 
```
GameTreeNode::GameTreeNode(GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent) {
    this->round = round;
    this->pot = pot;
    this->parent = std::move(parent);
}
```