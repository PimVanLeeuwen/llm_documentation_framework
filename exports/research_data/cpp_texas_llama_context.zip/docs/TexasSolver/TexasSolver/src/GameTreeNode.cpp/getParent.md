`getParent`: The function of `getParent` is to retrieve the parent node from a GameTreeNode object.

**Code Description**: This method, `getParent`, returns a shared pointer to the parent node of the current GameTreeNode. It uses a lock on the `parent` member variable to ensure thread safety when accessing the parent node.\\
## Code: 
```
shared_ptr<GameTreeNode>GameTreeNode::getParent() {
    return this->parent.lock();
}
```