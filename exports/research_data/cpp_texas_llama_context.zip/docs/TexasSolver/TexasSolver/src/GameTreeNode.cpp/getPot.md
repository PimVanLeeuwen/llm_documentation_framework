`getPot`: The function of `getPot` is to return the current potential (pot) value stored in the GameTreeNode object.

**Code Description**: This method, `getPot`, simply retrieves and returns the pre-computed pot value that has been calculated and stored within the GameTreeNode instance. It does not perform any additional calculations or operations; it merely provides access to the existing pot value.\\
## Code: 
```
double GameTreeNode::getPot() {
    return this->pot;
}
```