`DetailWindowSetting`: The function of `DetailWindowSetting` is to initialize the detail window setting with a default mode, which is set to strategy.

**Code Description**: This method initializes an object of type `DetailWindowSetting`. In its constructor, it sets the mode of the detail window to `STRATEGY`, which implies that the default view or focus when opening the detail window will be on strategic aspects.\\
## Code: 
```
DetailWindowSetting::DetailWindowSetting(){
    this->mode = DetailWindowMode::STRATEGY;
}
```