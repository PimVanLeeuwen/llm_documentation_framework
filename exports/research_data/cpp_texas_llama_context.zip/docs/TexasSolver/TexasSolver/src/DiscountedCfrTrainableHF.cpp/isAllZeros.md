`isAllZeros`: The function of `isAllZeros` is to check if all elements in the given array are zero.

**Parameters**: 
`const vector<float>& input_array`: This parameter is a reference to a vector of floating-point numbers, which represents an array of values that need to be checked for being all zeros.

**Code Description**: The function iterates over each element in the input array. If any element is not equal to zero (i.e., `i != 0`), it immediately returns `false`, indicating that not all elements are zero. If the loop completes without finding a non-zero element, the function returns `true`, signifying that all elements in the array are indeed zero.\\
## Code: 
```
bool DiscountedCfrTrainableHF::isAllZeros(const vector<float>& input_array) {
    for(float i:input_array){
        if (i != 0)return false;
    }
    return true;
}
```