`DiscountedCfrTrainableHF`: The function of `DiscountedCfrTrainableHF` is to initialize the necessary data structures for a discounted CFR (Counterfactual Regret Minimization) algorithm implementation.

**Parameters**:
`vector<PrivateCards> *privateCards`: This parameter represents a vector of private cards, which are the cards held by each player in the game.
`ActionNode &actionNode`: This parameter is a reference to an ActionNode object, which represents a node in the game tree structure. The `getChildrens` method of this object returns a vector of shared pointers to GameTreeNode objects.

**Code Description**: 
The code initializes several data structures:
- It sets up vectors to store expected values (`evs`) and R+ values (`r_plus`) for each possible action and private card combination.
- It calculates the number of actions (`action_number`) and private cards (`card_number`), which are used to initialize the size of these vectors.
- The `getChildrens` method is called on the `actionNode` object, returning a reference to a vector of shared pointers to GameTreeNode objects.\\
## Code: 
```
DiscountedCfrTrainableHF::DiscountedCfrTrainableHF(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();
    this->evs = vector<EvsStorage>(this->action_number * this->card_number, (EvsStorage) 0.0);
    this->r_plus = vector<RplusStorage>(this->action_number * this->card_number, (RplusStorage) 0.0);
    this->cum_r_plus = vector<CumRplusStorage>(this->action_number * this->card_number, (CumRplusStorage) 0.0);
}
```