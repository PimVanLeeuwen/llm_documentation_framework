`copyStrategy`: The function of `copyStrategy` is to copy the strategy from another trainable object.

**Parameters**: shared_ptr<Trainable> other_trainable: A pointer to a Trainable object that contains the strategy to be copied.

**Code Description**: This method copies the strategy from another DiscountedCfrTrainableHF object by casting it to a shared pointer of type DiscountedCfrTrainableHF, and then assigns its r_plus and cum_r_plus vectors to this object's corresponding vectors.\\
## Code: 
```
void DiscountedCfrTrainableHF::copyStrategy(shared_ptr<Trainable> other_trainable){
    shared_ptr<DiscountedCfrTrainableHF> trainable = dynamic_pointer_cast<DiscountedCfrTrainableHF>(other_trainable);
    this->r_plus.assign(trainable->r_plus.begin(),trainable->r_plus.end());
    this->cum_r_plus.assign(trainable->cum_r_plus.begin(),trainable->cum_r_plus.end());
}
```