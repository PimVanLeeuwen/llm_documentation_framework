`getReachProbs`: The function of `getReachProbs` is to calculate and return the reach probabilities for each player in a Texas Hold'em game.

**Code Description**: This method, part of the PCfrSolver class, generates a 2D vector (a matrix) where each row represents a player's reach probabilities. It iterates over all players, retrieves their private cards using the `playerHands` method, and then populates the reach probability vector for each player with the weights of their private cards. The resulting matrix is returned as the output of this function.\\
## Code: 
```
vector<vector<float>> PCfrSolver::getReachProbs() {
    vector<vector<float>> retval(this->player_number);
    for(int player = 0;player < this->player_number;player ++){
        vector<PrivateCards> player_cards = this->playerHands(player);
        vector<float> reach_prob(player_cards.size());
        for(std::size_t i = 0;i < player_cards.size();i ++){
            reach_prob[i] = player_cards[i].weight;
        }
        retval[player] = reach_prob;
    }
    return retval;
}
```