`noDuplicateRange`: The function of `noDuplicateRange` is to remove duplicate private card ranges from the input vector and filter out those that do not intersect with the given board.

**Parameters**:
`const vector<PrivateCards> &private_range`: This parameter represents a vector of unique private card ranges.
`uint64_t board_long`: This parameter represents a 64-bit unsigned integer representing the poker board.

**Code Description**: The function iterates over each private card range in the input vector, checks for duplicates using a hash map, and filters out those that do not intersect with the given board. If a duplicate is found or an intersection does not occur, it throws a runtime error. Otherwise, it adds the valid private card range to a new output vector. The function returns this output vector containing unique and intersecting private card ranges.\\
## Code: 
```
vector<PrivateCards>
PCfrSolver::noDuplicateRange(const vector<PrivateCards> &private_range, uint64_t board_long) {
    vector<PrivateCards> range_array;
    unordered_map<int,bool> rangekv;
    for(PrivateCards one_range:private_range){
        if(rangekv.find(one_range.hashCode()) != rangekv.end())
            throw runtime_error(tfm::format("duplicated key %s",one_range.toString()));
        rangekv[one_range.hashCode()] = true;
        uint64_t hand_long = Card::boardInts2long(one_range.get_hands());
        if(!Card::boardsHasIntercept(hand_long,board_long)){
            range_array.push_back(one_range);
        }
    }
    return range_array;

}
```