`cfr`: The function of `cfr` is to calculate the Counterfactual Regret Minimization (CFR) value for a given player in a game tree.

**Parameters**:
- `int player`: The index of the player for whom the CFR value is being calculated.
- `shared_ptr<GameTreeNode> node`: A pointer to the current node in the game tree.
- `const vector<float> &reach_probs`: A reference to a vector containing reach probabilities for each possible outcome.
- `int iter`: The number of iterations to perform during the Monte Carlo simulation.
- `uint64_t current_board`: The current state of the board, represented as an unsigned 64-bit integer.
- `int deal`: The type of card deal being considered.

**Code Description**: 
The function uses a switch statement to determine the type of node in the game tree. Based on the node type, it calls one of four utility functions: actionUtility, showdownUtility, terminalUtility, or chanceUtility. These functions calculate the CFR value for the given player based on the specific characteristics of each node type. The function returns a vector containing the calculated CFR values.\\
## Code: 
```
vector<float> PCfrSolver::cfr(int player, shared_ptr<GameTreeNode> node, const vector<float> &reach_probs, int iter,
                                    uint64_t current_board,int deal) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
            return actionUtility(player, action_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::SHOWDOWN: {
            shared_ptr<ShowdownNode> showdown_node = std::dynamic_pointer_cast<ShowdownNode>(node);
            return showdownUtility(player, showdown_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::TERMINAL: {
            shared_ptr<TerminalNode> terminal_node = std::dynamic_pointer_cast<TerminalNode>(node);
            return terminalUtility(player, terminal_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::CHANCE: {
            shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
            return chanceUtility(player, chance_node, reach_probs, iter, current_board,deal);
        }default:
            throw runtime_error("node type unknown");
    }
}
```