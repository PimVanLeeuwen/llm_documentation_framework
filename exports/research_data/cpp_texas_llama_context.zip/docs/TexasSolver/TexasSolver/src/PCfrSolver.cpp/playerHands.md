`playerHands`: The function of `playerHands` is to return the private cards of a specific player in a Texas Hold'em game.

**Parameters**:\
`int player`: This parameter specifies which player's hands are being requested, with 0 representing one player and 1 representing the other player.

**Code Description**: *The code returns the private cards (range1 or range2) based on the input player number. If the player is not found (i.e., the input is neither 0 nor 1), it throws a runtime error.*\\
## Code: 
```
const vector<PrivateCards> &PCfrSolver::playerHands(int player) {
    if(player == 0){
        return range1;
    }else if (player == 1){
        return range2;
    }else{
        throw runtime_error("player not found");
    }
}
```