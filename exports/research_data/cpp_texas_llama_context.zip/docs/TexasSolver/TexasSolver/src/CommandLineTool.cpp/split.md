`split`: The function of `split` is to split a given input string into substrings based on a specified delimiter character.

**Parameters**:
`const string& s`: This parameter represents the input string that needs to be split.
`char c`: This parameter specifies the delimiter character used for splitting the input string.
`vector<string>& v`: This parameter is a reference to a vector of strings where the split substrings will be stored.

**Code Description**: The `split` function iterates through the input string, finding occurrences of the specified delimiter character. When a delimiter is found, it extracts the substring between the current position and the previous delimiter, adds it to the vector of strings, and then updates the current position to the position right after the delimiter. This process continues until the end of the input string is reached, at which point any remaining characters are also added to the vector as a single substring.\\
## Code: 
```
void split(const string& s, char c,
           vector<string>& v) {
    string::size_type i = 0;
    string::size_type j = s.find(c);

    while (j != string::npos) {
        v.push_back(s.substr(i, j-i));
        i = ++j;
        j = s.find(c, j);

        if (j == string::npos)
            v.push_back(s.substr(i, s.length()));
    }
}
```