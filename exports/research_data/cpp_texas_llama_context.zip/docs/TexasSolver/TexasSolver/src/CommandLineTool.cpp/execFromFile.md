**execFromFile**: The function reads a file specified by the `input_file` parameter and processes each line in the file using the `processCommand` method.

**Parameters**: 
`string input_file`: The path to the file containing commands or inputs that need to be processed.

**Code Description**: This function opens the specified file, reads it line by line, and for each line, calls the `processCommand` method.\\
## Code: 
```
void CommandLineTool::execFromFile(string input_file){
    std::ifstream infile(input_file);
    std::string input_line;
    while (std::getline(infile, input_line))
    {
        this->processCommand(input_line);
    }

}
```