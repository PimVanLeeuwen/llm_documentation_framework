`~RoughStrategyViewerModel`: The function of `~RoughStrategyViewerModel` is to perform the destructor operation for the `RoughStrategyViewerModel` class.

**Code Description**: This method, `~RoughStrategyViewerModel`, appears to be an empty destructor. It does not contain any code that would execute when an instance of the `RoughStrategyViewerModel` class is destroyed or goes out of scope. The lack of implementation suggests that this class may not have any resources (such as memory allocations) that need to be released when it is no longer in use.\\
## Code: 
```
RoughStrategyViewerModel::~RoughStrategyViewerModel()
{
}
```