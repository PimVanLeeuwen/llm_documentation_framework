`onchanged`: The function of `onchanged` is to notify that data has changed in the model, specifically by emitting a signal to update the header data.

**Code Description**: This code defines a method `onchanged` in the class `RoughStrategyViewerModel`. When called, it emits a signal to update the header data of the table view associated with this model. The signal is emitted for all columns (from 0 to the total number of columns) using the `headerDataChanged` function from Qt's `QAbstractItemModel` class. This ensures that any views displaying data from this model are updated to reflect the new or changed data.\\
## Code: 
```
void RoughStrategyViewerModel::onchanged(){
    emit headerDataChanged(Qt::Horizontal, 0 , columnCount());
}
```