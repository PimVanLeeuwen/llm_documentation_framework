`index`: The function of `index` is to return a QModelIndex object representing the item at the specified row and column in the model, with the given parent index.

**Parameters**:
`int row`: The row number of the item.
`int column`: The column number of the item.
`const QModelIndex &parent`: The parent index of the item.

**Code Description**: This function is part of the RoughStrategyViewerModel class and is used to retrieve a QModelIndex object for a specific item in the model. It first checks if the given row, column, and parent indices are valid using the hasIndex method. If they are not valid, it returns an empty QModelIndex object. Otherwise, it creates a new QModelIndex object with the specified row, column, and null pointer as its internal data.\\
## Code: 
```
QModelIndex RoughStrategyViewerModel::index(int row, int column, const QModelIndex &parent) const
{
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    return createIndex(row, column, nullptr);
}
```