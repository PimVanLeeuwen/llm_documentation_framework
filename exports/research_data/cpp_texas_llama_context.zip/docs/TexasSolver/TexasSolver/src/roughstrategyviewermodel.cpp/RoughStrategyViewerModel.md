`RoughStrategyViewerModel`: The function of `RoughStrategyViewerModel` is to initialize a new instance of the model with a given table strategy model and parent object.

**Parameters**:
`TableStrategyModel* tableStrategyModel`: This parameter represents the table strategy model that will be used by the RoughStrategyViewerModel.
`QObject *parent`: This parameter represents the parent object for the RoughStrategyViewerModel, which is typically used in Qt to establish a parent-child relationship between objects.

**Code Description**: The code initializes a new instance of the RoughStrategyViewerModel class with the given table strategy model and parent object. It sets up the internal state of the model by assigning the provided table strategy model to an internal member variable.\\
## Code: 
```
RoughStrategyViewerModel::RoughStrategyViewerModel(TableStrategyModel* tableStrategyModel, QObject *parent):QAbstractItemModel(parent){
    this->tableStrategyModel = tableStrategyModel;
}
```