`isDonk`: The function of `isDonk` is to check if the current chance node has a donk value.

**Code Description**: This method, `isDonk`, is a simple getter function that returns the boolean value of the `donk` member variable within the `ChanceNode` class. It does not modify any values or perform complex operations; it merely provides access to the existing state of the object. The purpose of this function appears to be related to determining whether a specific condition, associated with the term "donk," is met in the context of the TexasSolver project.\\
## Code: 
```
bool ChanceNode::isDonk(){
    return this->donk;
}
```