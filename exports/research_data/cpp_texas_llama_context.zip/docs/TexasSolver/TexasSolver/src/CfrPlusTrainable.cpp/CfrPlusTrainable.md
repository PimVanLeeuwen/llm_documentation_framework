`CfrPlusTrainable`: The function of `CfrPlusTrainable` is to initialize a trainable CFR+ object with the given action node and private cards.

**Parameters**:
`shared_ptr<ActionNode> action_node`: A shared pointer to an ActionNode object, which represents a node in a game tree structure.
`vector<PrivateCards> privateCards`: A vector of PrivateCards objects, representing the private cards held by each player.

**Code Description**: The `CfrPlusTrainable` constructor initializes various vectors and variables based on the input action node and private cards. It sets up data structures to store values for CFR+ calculations, including `r_plus`, `r_plus_sum`, `cum_r_plus`, `cum_r_plus_sum`, and `retval`. These vectors are initialized with sizes corresponding to the number of actions and private cards. The constructor also retrieves the number of children nodes from the action node using the `getChildrens` method.\\
## Code: 
```
CfrPlusTrainable::CfrPlusTrainable(shared_ptr<ActionNode> action_node, vector<PrivateCards> privateCards) {
    this->action_node = action_node;
    this->privateCards = privateCards;
    this->action_number = action_node->getChildrens().size();
    this->card_number = privateCards.size();

    this->r_plus = vector<float>(this->action_number * this->card_number);
    this->r_plus_sum = vector<float>(this->card_number);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number);
    this->cum_r_plus_sum = vector<float>(this->card_number);
    this->retval = vector<float>(this->action_number * this->card_number);
}
```