`ShowdownNode`: The function of `ShowdownNode` is to initialize a new node in the game tree for a showdown scenario, where multiple players are tied and their payoffs need to be determined.

**Parameters**:
`vector<double> tie_payoffs`: This parameter represents the payoffs that all tied players will receive.
`vector<vector<double>> player_payoffs`: This parameter is a 2D vector representing the payoffs for each player in the showdown scenario. The outer vector represents the different players, and the inner vectors represent their respective payoffs.
`GameTreeNode::GameRound round`: This parameter specifies the current game round being simulated.
`double pot`: This parameter represents the total pot size at this point in the game.
`shared_ptr<GameTreeNode>parent`: This parameter is a shared pointer to the parent node in the game tree, which is used to establish the hierarchy of nodes.

**Code Description**: The `ShowdownNode` constructor initializes a new node in the game tree by calling the base class constructor (`GameTreeNode`) and passing in the specified parameters. It then sets up the specific attributes for this type of node, including the tie payoffs and player payoffs, using the provided vectors.\\
## Code: 
```
ShowdownNode::ShowdownNode(vector<double> tie_payoffs, vector<vector<double>> player_payoffs,
                           GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode>parent):
                           GameTreeNode(round,pot,std::move(parent)) {
    this->tie_payoffs = std::move(tie_payoffs);
    this->player_payoffs = std::move(player_payoffs);
}
```