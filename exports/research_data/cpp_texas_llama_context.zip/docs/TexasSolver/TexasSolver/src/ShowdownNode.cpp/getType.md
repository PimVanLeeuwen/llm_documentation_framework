`getType`: The function of `getType` is to return the type of a ShowdownNode in the TexasSolver project structure.

**Code Description**: This method, `getType`, is part of the `ShowdownNode` class within the `TexasSolver` project. It specifically returns the type of a `GameTreeNode`. In this case, it returns `SHOWDOWN`, indicating that the node represents a showdown situation in the game tree. The purpose of this function is to identify and categorize nodes based on their specific characteristics or positions within the game tree.\\
## Code: 
```
GameTreeNode::GameTreeNodeType ShowdownNode::getType() {
    return SHOWDOWN;
}
```