**HtmlTableRangeView**: The function of `HtmlTableRangeView` is to initialize a new instance of the class, which inherits from `HtmlTableView`, and set up its event handling and mouse tracking behavior.

**Parameters**: 
`QWidget *parent`: This parameter represents the parent widget that will contain the `HtmlTableRangeView` instance. It allows the view to be embedded within another GUI component.

**Code Description**: The code initializes a new `HtmlTableRangeView` object, passing the `parent` widget as an argument. It then installs an event filter on the viewport of the view, enabling it to receive and handle events such as mouse clicks and movements. Additionally, it enables mouse tracking for the view, allowing it to track mouse movements without requiring actual button presses. The `mouseTracker` object is initialized with its tracking flag set to false and its pressed indices set to -1, indicating that no cells are currently selected.\\
## Code: 
```
HtmlTableRangeView::HtmlTableRangeView(QWidget *parent):
HtmlTableView(parent)
{
    viewport()->installEventFilter(this);
    setMouseTracking(true);
    mouseTracker.tracking = false;
    mouseTracker.pressed_i = -1;
    mouseTracker.pressed_j = -1;
}
```