`noDuplicateRange`: The function of `noDuplicateRange` is to remove duplicate and non-intersecting private card ranges from a given set of private card ranges, based on the provided board long.

**Parameters**:
`const vector<PrivateCards> &private_range`: This parameter represents a reference to a vector of PrivateCards objects, which are the private card ranges to be processed.
`uint64_t board_long`: This parameter is an unsigned 64-bit integer representing the board long value used for filtering out non-intersecting ranges.

**Code Description**: The `noDuplicateRange` function iterates over each PrivateCards object in the provided vector. It checks if a duplicate range exists by looking up its hash code in an unordered map. If a duplicate is found, it throws a runtime error with a message indicating the duplicated key. Otherwise, it adds the range to the result array and continues processing other ranges. The function also filters out non-intersecting ranges based on the board long value using the `boardsHasIntercept` method from Card.cpp. Finally, it returns the processed vector of PrivateCards objects.\\
## Code: 
```
vector<PrivateCards> noDuplicateRange(const vector<PrivateCards> &private_range, uint64_t board_long) {
    vector<PrivateCards> range_array;
    unordered_map<int,bool> rangekv;
    for(PrivateCards one_range:private_range){
        if(rangekv.find(one_range.hashCode()) != rangekv.end())
            throw runtime_error(tfm::format("duplicated key %s",one_range.toString()));
        rangekv[one_range.hashCode()] = true;
        uint64_t hand_long = Card::boardInts2long(one_range.get_hands());
        if(!Card::boardsHasIntercept(hand_long,board_long)){
            range_array.push_back(one_range);
        }
    }
    return range_array;
}
```