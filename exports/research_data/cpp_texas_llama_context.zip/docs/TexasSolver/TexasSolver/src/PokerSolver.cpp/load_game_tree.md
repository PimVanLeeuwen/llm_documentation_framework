`load_game_tree`: The function of `load_game_tree` is to load a game tree from a file and assign it to the PokerSolver's game tree.

**Parameters**: 
`string game_tree_file`: This parameter represents the path to the file containing the game tree data.

**Code Description**: 
The `load_game_tree` method creates a shared pointer to a GameTree object using the provided file path and deck, then assigns this new game tree to the PokerSolver's game tree member variable.\\
## Code: 
```
void PokerSolver::load_game_tree(string game_tree_file) {
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(game_tree_file,this->deck);
    this->game_tree = game_tree;
}
```