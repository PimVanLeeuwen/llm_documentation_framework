`stop`: The function of `stop` is to stop the solver if it exists.

**Code Description**: This method, `stop`, checks if a solver object (`this->solver`) has been initialized. If it has, it calls the `stop` method on that solver object, effectively stopping its execution or operation.\\
## Code: 
```
void PokerSolver::stop(){
    if(this->solver != nullptr){
        this->solver->stop();
    }
}
```