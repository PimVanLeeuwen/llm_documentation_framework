`getGameTree`: The function of `getGameTree` is to return a reference to the game tree object, which represents the entire game structure.

**Code Description**: This method is a getter for the game_tree member variable. It returns a shared pointer to the GameTree object, allowing access to the game's tree-like structure without modifying it. The const keyword indicates that this function does not modify the object and can be called on a const instance of PokerSolver.\\
## Code: 
```
const shared_ptr<GameTree> &PokerSolver::getGameTree() const {
    return game_tree;
}
```