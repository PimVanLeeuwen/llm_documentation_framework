`PokerSolver`: The function of `PokerSolver` is to initialize a poker solver object with the given parameters.

**Parameters**:
- `string ranks`: A string containing comma-separated card ranks.
- `string suits`: A string containing comma-separated card suits.
- `string compairer_file`: A file path for loading poker hand strength data.
- `int compairer_file_lines`: The number of lines in the compairer file.
- `string compairer_file_bin`: A binary file path for storing or retrieving poker hand strength data.

**Code Description**: 
The code defines a constructor for the `PokerSolver` class, which initializes an object with the provided parameters. It splits the input strings into vectors of ranks and suits using the `string_split` function from the `library.cpp` module. The resulting vectors are then used to create a deck of cards through the `Deck` class in the `Deck.cpp` module. Additionally, it creates a shared pointer to an instance of the `Dic5Compairer` class from the `Dic5Compairer.cpp` module using the provided file paths and line count. This object is stored as a member variable of the `PokerSolver` class.\\
## Code: 
```
PokerSolver::PokerSolver(string ranks, string suits, string compairer_file,int compairer_file_lines, string compairer_file_bin) {
    vector<string> ranks_vector = string_split(ranks,',');
    vector<string> suits_vector = string_split(suits,',');
    this->deck = Deck(ranks_vector,suits_vector);
    this->compairer = make_shared<Dic5Compairer>(compairer_file,compairer_file_lines,compairer_file_bin);
}
```