`build_game_tree`: The function of `build_game_tree` is to build a game tree for a poker game.

**Parameters**:
`float oop_commit`: The out-of-position commitment.
`float ip_commit`: The in-position commitment.
`int current_round`: The current round number.
`int raise_limit`: The maximum number of raises allowed.
`float small_blind`: The amount of the small blind.
`float big_blind`: The amount of the big blind.
`float stack`: The player's stack size.
`GameTreeBuildingSettings buildingSettings`: The settings for building the game tree.
`float allin_threshold`: The threshold at which to consider an all-in action.

**Code Description**: This function creates a new `GameTree` object and assigns it to the `game_tree` member variable of the `PokerSolver` class. It takes various parameters related to the poker game, such as commitment levels, round number, raise limit, blinds, stack size, and building settings, and uses them to initialize the `GameTree` object. The `allin_threshold` parameter is also used to determine when an all-in action should be considered.\\
## Code: 
```
void PokerSolver::build_game_tree(
        float oop_commit,
        float ip_commit,
        int current_round,
        int raise_limit,
        float small_blind,
        float big_blind,
        float stack,
        GameTreeBuildingSettings buildingSettings,
        float allin_threshold
){
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(
            this->deck,
            oop_commit,
            ip_commit,
            current_round,
            raise_limit,
            small_blind,
            big_blind,
            stack,
            buildingSettings,
            allin_threshold
    );
    this->game_tree = game_tree;
}
```