**Expected Output**

`anchorAt`: The function of `anchorAt` is to return the anchor for a given point in a text layout.
**Parameters**:
`QString html`: A string containing HTML code that represents the text layout.
`const QPoint &point`: The coordinates of the point at which to find the anchor.

**Code Description**: This function uses a QTextDocument object to parse the provided HTML string and create a document. It then retrieves the document's layout, asserts that it is not null, and calls the `anchorAt` method on the layout with the given point as an argument. The returned value represents the anchor for the specified point in the text layout.\\
## Code: 
```
QString WordItemDelegate::anchorAt(QString html, const QPoint &point) const {
    QTextDocument doc;
    doc.setHtml(html);

    auto textLayout = doc.documentLayout();
    Q_ASSERT(textLayout != 0);
    return textLayout->anchorAt(point);
}
```