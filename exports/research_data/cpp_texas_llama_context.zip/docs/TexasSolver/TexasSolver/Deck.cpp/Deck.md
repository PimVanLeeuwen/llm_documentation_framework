`Deck`: The function of `Deck` is to initialize a deck of cards with the given ranks and suits.

**Parameters**:
`const vector<string>& ranks`: A list of card ranks.
`const vector<string>& suits`: A list of card suits.

**Code Description**: This method populates a deck of cards by iterating over each rank and suit combination, creating a string representation of the card (e.g., "Ace of Hearts"), and adding it to the `cards_str` vector. It also creates a `Card` object for each combination and adds it to the `cards` set, incrementing a counter (`card_num`) to keep track of the card's position in the deck.\\
## Code: 
```
Deck::Deck(const vector<string>& ranks, const vector<string>& suits) {
    this->ranks = ranks;
    this->suits = suits;
    int card_num = 0;
    for(const string& one_rank : ranks){
        for(const string& one_suit: suits){
            string one_card = one_rank + one_suit;
            cards_str.push_back(one_card);
            cards.emplace_back(one_card,card_num);
            card_num += 1;
        }
    }
}
```