`on_ipRangeButtom_clicked`: The function of `on_ipRangeButtom_clicked` is to update the detail window setting mode to RANGE_IP and refresh the views.

**Code Description**: When the ipRangeButtom button is clicked, this function updates the detail window setting mode to RANGE_IP. It then triggers an update on the strategy table view, detail view, and rough strategy view, ensuring that the user interface reflects the new mode. Additionally, it calls the onchanged method of the RoughStrategyViewerModel to notify any connected views that the underlying data has changed.\\
## Code: 
```
void StrategyExplorer::on_ipRangeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::RANGE_IP;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```