`on_evOnlyModeButtom_clicked`: The function of `on_evOnlyModeButtom_clicked` is to update the detail window setting mode to EV_ONLY when the "evOnlyModeButton" is clicked.

**Code Description**: When the "evOnlyModeButton" is clicked, this function updates the detail window setting mode to EV_ONLY. It then triggers an update on the strategy table view and detail view by calling their respective viewport's update method. Additionally, it calls the `onchanged` method of the rough strategy viewer model, which likely emits a signal to update the header data of a table, indicating that the underlying data has changed. Finally, it updates the rough strategy view by calling its viewport's update method.\\
## Code: 
```
void StrategyExplorer::on_evOnlyModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::EV_ONLY;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```