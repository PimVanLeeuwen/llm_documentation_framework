`item_clicked`: The function of `item_clicked` is to process a tree click event in the strategy explorer.

**Parameters**: 
`const QModelIndex& index`: This parameter represents the index of the item that was clicked in the tree view.

**Code Description**: When an item is clicked, the `item_clicked` function retrieves the TreeItem associated with the clicked index and calls two functions: `process_treeclick` to update a UI label based on the type of game node clicked, and `process_board` to process a poker board by splitting it into individual cards. The function then updates the table strategy model with the new tree item, triggers a resize event in the rough strategy view, and updates its viewport. If any runtime errors occur during this process, they are caught and logged using qDebug().\\
## Code: 
```
void StrategyExplorer::item_clicked(const QModelIndex& index){
    try{
        TreeItem * treeNode = static_cast<TreeItem*>(index.internalPointer());
        this->process_treeclick(treeNode);
        this->process_board(treeNode);
        this->tableStrategyModel->setGameTreeNode(treeNode);
        this->tableStrategyModel->updateStrategyData();
        this->ui->strategyTableView->viewport()->update();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->triger_resize();
        this->ui->roughStrategyView->viewport()->update();
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```