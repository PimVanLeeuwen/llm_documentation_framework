`on_evModeButtom_clicked`: The function of `on_evModeButtom_clicked` is to update the mode of the detail window setting to EV (Electric Vehicle) mode.

**Code Description**: When the "evModeButtom" button is clicked, this function updates the mode of the detail window setting to EV mode. It then triggers an update of three UI elements: strategyTableView, detailView, and roughStrategyView. This suggests that the function is part of a larger system for exploring strategies related to electric vehicles, and its purpose is to switch the display to show information relevant to EVs.\\
## Code: 
```
void StrategyExplorer::on_evModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::EV;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->ui->roughStrategyView->viewport()->update();
}
```