`item_expanded`: The function of `item_expanded` is to regenerate the tree item for each child of a given TreeItem when it is expanded.

**Parameters**: 
`const QModelIndex& index`: This parameter represents the index of the TreeItem that has been expanded, allowing the function to access its internal data and children.

**Code Description**: The code retrieves the TreeItem associated with the given index, counts its children, and then iterates over each child. If a child has no further children (i.e., its child count is 0), it regenerates the tree item for that child using the `reGenerateTreeItem` method from the `TreeModel`. This process effectively updates the display of the tree view to reflect any changes or new data associated with each child.\\
## Code: 
```
void StrategyExplorer::item_expanded(const QModelIndex& index){
    TreeItem *item = static_cast<TreeItem*>(index.internalPointer());
    int num_child = item->childCount();
    for (int i = 0;i < num_child;i ++){
        TreeItem* one_child = item->child(i);
        if(one_child->childCount() != 0)continue;
        this->ui->gameTreeView->tree_model->reGenerateTreeItem(one_child->m_treedata.lock()->getRound(),one_child);
    }
}
```