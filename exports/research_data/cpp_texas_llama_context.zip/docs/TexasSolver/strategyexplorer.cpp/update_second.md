`update_second`: The function of `update_second` is to update various components of the user interface and process the poker board when there are cards available.

**Code Description**: When called, `update_second` first checks if there are any cards in the `cards` vector. If so, it updates the strategy data using the `tableStrategyModel`, emits a signal to update the header data of the rough strategy viewer table using the `onchanged` method, and then updates the viewport of the rough strategy view and the detail view. Additionally, it processes the poker board by calling the `process_board` method with the tree item from the `tableStrategyModel`. If there are no cards available, it simply updates the viewport of the strategy table view and the detail view.\\
## Code: 
```
void StrategyExplorer::update_second(){
    if(this->cards.size() > 0){
        this->tableStrategyModel->updateStrategyData();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```