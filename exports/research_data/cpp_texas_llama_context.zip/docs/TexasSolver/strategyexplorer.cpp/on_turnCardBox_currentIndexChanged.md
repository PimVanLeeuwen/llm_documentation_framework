`on_turnCardBox_currentIndexChanged`: The function of `on_turnCardBox_currentIndexChanged` is to update the table strategy model and process the poker board when a new card is selected from the turn card box.

**Parameters**:\
`int index`: This parameter represents the index of the selected card in the cards list, which is used to retrieve the corresponding Card object.

**Code Description**: The code first checks if there are cards available and if the selected index is within the valid range. If so, it sets the selected card as the turn card in the table strategy model, updates the strategy data, and processes the poker board by splitting it into individual cards, adding relevant table strategy cards, and displaying the resulting card sequence on a user interface label. Finally, it updates the viewport of several UI components to reflect the changes.\\
## Code: 
```
void StrategyExplorer::on_turnCardBox_currentIndexChanged(int index)
{
    if(this->cards.size() > 0 && index < this->cards.size()){
        this->tableStrategyModel->setTrunCard(this->cards[index]);
        this->tableStrategyModel->updateStrategyData();
        // TODO this somehow cause bugs, crashes, why?
        //this->roughStrategyViewerModel->onchanged();
        //this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```