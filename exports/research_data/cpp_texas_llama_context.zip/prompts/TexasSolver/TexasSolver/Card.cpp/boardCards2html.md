# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/Card.cpp` \
**Type:** `Method` \
**Method Name:** `boardCards2html` \
**Code Content:** \
`QString Card::boardCards2html(vector<Card>& cards){
    QString ret_html = "";
    for(auto one_card:cards){
        if(one_card.empty())continue;
        ret_html += one_card.toFormattedHtml();
    }
    return ret_html;
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/Card.cpp.empty 
 - Explanation:  _This code defines a method `empty` in the `Card` class that checks if a card is empty or not. The method returns true if the card is empty, and false otherwise._ 
### TexasSolver/TexasSolver/Card.cpp.toFormattedHtml 
 - Explanation:  _This code converts a card representation into a formatted HTML string, replacing suit characters ("c", "d", "h", "s") with corresponding HTML span tags and Unicode symbols for cards. The method returns the resulting HTML string._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`boardCards2html`: The function of `boardCards2html` is *FILL IN* 
**Parameters**:\
`vector<Card>& cards`: *FILL IN* \

**Code Description**: *FILL IN*
