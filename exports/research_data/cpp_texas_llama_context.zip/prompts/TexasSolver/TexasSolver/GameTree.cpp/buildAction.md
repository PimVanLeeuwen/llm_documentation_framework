# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/GameTree.cpp` \
**Type:** `Method` \
**Method Name:** `buildAction` \
**Code Content:** \
`void GameTree::buildAction(shared_ptr<ActionNode> root,Rule rule,string last_action,int check_times,int raise_times){
    // current player
    int player = root->getPlayer();

    vector<string> possible_actions;
    if(last_action == "roundbegin") {
        possible_actions = vector<string>{"check", "bet"};
    }else if(last_action == "begin") {
        possible_actions = vector<string>{"check", "bet"};
    }else if(last_action == "bet") {
        possible_actions = vector<string>{"call", "raise", "fold"};
    }else if(last_action == "raise") {
        possible_actions = vector<string>{"call", "raise", "fold"};
    }else if(last_action == "check") {
        possible_actions = vector<string>{"check", "raise", "bet"};
    }else if(last_action == "fold") {
        possible_actions = vector<string>{};
    }else if(last_action == "call") {
        possible_actions = vector<string>{"check", "raise"};
    }else{
        throw runtime_error(tfm::format("last action %s not found", last_action));
    }
    int nextplayer = 1 - player;

    vector<GameActions> actions;
    vector<shared_ptr<GameTreeNode>> childrens;

    if (possible_actions.empty()) return;
    for (string action : possible_actions) {
        if (action == "check") {
            // 当不是第一轮的时候 call后面是不能跟check的
            shared_ptr<GameTreeNode> nextnode;
            Rule nextrule = Rule(rule);
            if ((last_action == "call" && root->getParent() != nullptr && root->getParent()->getParent() == nullptr) || check_times >= 1) {
                // 在river check 导致游戏进入showdown
                if(rule.current_round == 3){
                    double p1_commit = rule.ip_commit;
                    double p2_commit = rule.oop_commit;
                    double peace_getback = (p1_commit + p2_commit) / 2;
                    vector<vector<double>> payoffs(2);
                    payoffs[0] = {p2_commit, -p2_commit};
                    payoffs[1] = {-p1_commit, p1_commit};
                    vector<double> peace_getback_vec = {peace_getback - p1_commit, peace_getback - p2_commit};
                    nextnode = make_shared<ShowdownNode>(peace_getback_vec,payoffs,GameTreeNode::intToGameRound(rule.current_round),(double)rule.get_pot(),root);
                }else {
                    // 在preflop/flop/turn check 导致游戏进入下一轮
                    nextrule.current_round += 1;
                    nextnode = make_shared<ChanceNode>(nullptr,GameTreeNode::intToGameRound(rule.current_round + 1), rule.get_pot(), root, this->deck.getCards());
                }
            }else if (root->getParent() == nullptr) {
                nextnode = make_shared<ActionNode>(vector<GameActions>(),vector<shared_ptr<GameTreeNode>>() , nextplayer, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
            } else {
                nextnode = make_shared<ActionNode>(vector<GameActions>(),vector<shared_ptr<GameTreeNode>>() , nextplayer, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
            }
            this->__build(nextnode, nextrule,"check",check_times + 1,0);
            actions.push_back(GameActions(GameTreeNode::PokerActions::CHECK,-1));
            childrens.push_back(nextnode);
        }else if (action == "bet"){
            BetType betType = BetType::BET;
            // if it's a donk bet
            if(root->getPlayer() == 1 && root->getParent() != nullptr && root->getParent()->getType() == GameTreeNode::GameTreeNodeType::CHANCE){
                shared_ptr<ChanceNode> chanceNodeBeforeThis = std::dynamic_pointer_cast<ChanceNode>(root->getParent());
                if(chanceNodeBeforeThis->isDonk()) betType = BetType::DONK;
            }
            vector<double> bet_sizes = this->get_possible_bets(root,player,nextplayer,rule,betType);
            for(double one_betting_size:bet_sizes){
                Rule nextrule = Rule(rule);
                if (player == 0) nextrule.ip_commit += one_betting_size;
                else if (player == 1) nextrule.oop_commit += one_betting_size;
                else throw runtime_error("unknown player");
                shared_ptr<GameTreeNode> nextnode = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(),nextplayer,GameTreeNode::intToGameRound(rule.current_round),(double) rule.get_pot(),root);
                this->__build(nextnode,nextrule,"bet",0,1);
                actions.push_back(GameActions(GameTreeNode::PokerActions::BET,one_betting_size));
                childrens.push_back(nextnode);
            }
        }else if (action == "call"){
            Rule nextrule = Rule(rule);
            if (player == 0) nextrule.ip_commit += (rule.oop_commit - rule.ip_commit);
            else if (player == 1) nextrule.oop_commit += (rule.ip_commit - rule.oop_commit);
            else throw runtime_error("unknown player");

            shared_ptr<GameTreeNode> nextnode;
            if(root->getParent() == nullptr) {
                nextnode = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(), nextplayer, GameTreeNode::intToGameRound(rule.current_round), (double) nextrule.get_pot(), root);
            }else if (rule.current_round == 3 ){ // at river
                double p1_commit = nextrule.ip_commit;
                double p2_commit = nextrule.oop_commit;
                double peace_getback = (p1_commit + p2_commit) / 2;

                vector<vector<double>> payoffs(2);
                payoffs[0] = {p2_commit, -p2_commit};
                payoffs[1] = {-p1_commit, p1_commit};
                vector<double> tie_payoffs = {peace_getback - p1_commit, peace_getback - p2_commit};
                nextnode = make_shared<ShowdownNode>(tie_payoffs,payoffs,GameTreeNode::intToGameRound(rule.current_round),(double) nextrule.get_pot(),root);
            }else{
                nextrule.current_round += 1;
                bool donk = false;
                if(player == 1) donk = true;
                nextnode = make_shared<ChanceNode>(nullptr,GameTreeNode::intToGameRound(rule.current_round + 1),(double) nextrule.get_pot(),root,this->deck.getCards(),donk);
            }
            if(nextrule.current_round > 3)throw runtime_error(tfm::format("round %d exceed 3",nextrule.current_round));
            this->__build(nextnode,nextrule,"call",0,0);
            actions.push_back(GameActions(GameTreeNode::PokerActions::CALL, -1));
            childrens.push_back(nextnode);
        }else if (action == "raise"){
            if(last_action == "call"){
                if(!(root->getParent() != nullptr && root->getParent()->getParent() == nullptr)) continue;
            }else if(last_action == "check"){
                // 第二轮之后的check后面只能跟 bet
                if(!(root->getParent() != nullptr && root->getParent()->getParent() == nullptr && rule.current_round == 0)) continue;
            }
            // 如果raise次数超出限制，则不可以继续raise
            if(raise_times >= rule.raise_limit) continue;
            vector<double> bet_sizes = this->get_possible_bets(root,player,nextplayer,rule,BetType::RAISE);
            for(double one_betting_size:bet_sizes){
                Rule nextrule = Rule(rule);
                if (player == 0) nextrule.ip_commit += one_betting_size;
                else if (player == 1) nextrule.oop_commit += one_betting_size;
                else runtime_error("unknown player");
                shared_ptr<GameTreeNode> nextnode = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(),nextplayer,GameTreeNode::intToGameRound(rule.current_round),(double) rule.get_pot(),root);
                // Calculate the raise size rather than amount being
                // added to the pot. Do this by ascending the tree until
                // reach a CHANCE node (or no parent) and extract the pot
                // size from it. This can then be used to calculate raise
                shared_ptr<GameTreeNode> roundroot = nextnode;
                while(roundroot->getParent() && roundroot->getType() != GameTreeNode::GameTreeNodeType::CHANCE) {
                    roundroot = roundroot->getParent();
                }
                double raiseto;
                double commit = player == 0 ? nextrule.ip_commit : nextrule.oop_commit;
                if(roundroot) {
                    raiseto = commit - roundroot->getPot()/2;
                } else {
                    raiseto = one_betting_size;
                }
                this->__build(nextnode,nextrule,"raise",0,raise_times + 1);
                actions.push_back(GameActions(GameTreeNode::PokerActions::RAISE,raiseto));
                childrens.push_back(nextnode);
            }

        }else if (action == "fold"){
            Rule nextrule = Rule(rule);
            vector<double> payoffs;
            if (player == 0) {
                payoffs = {-rule.ip_commit, rule.ip_commit};
            }else if(player == 1){
                payoffs = {rule.oop_commit, -rule.oop_commit};
            }else throw runtime_error("unknown player");
            shared_ptr<GameTreeNode> nextnode = make_shared<TerminalNode>(payoffs,nextplayer,GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(),root);
            this->__build(nextnode,nextrule,"fold",0,0);
            actions.push_back(GameActions(GameTreeNode::PokerActions::FOLD,-1));
            childrens.push_back(nextnode);
        }
    }
    if(actions.size() == 0)throw runtime_error("action size is 0");
    root->setActions(actions);
    root->setChildrens(childrens);
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/GameTree.cpp.__build 
 - Explanation:  _This code defines a method `__build` in the `GameTree` class, which builds or updates a game tree node based on its type and input parameters. The method calls specific building methods for different types of nodes, such as action or chance nodes._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.getParent 
 - Explanation:  _This code retrieves the parent node from a GameTreeNode object using a shared pointer lock method.

The getParent method returns a shared pointer to the parent GameTreeNode, or an empty shared pointer if no parent exists._ 
### TexasSolver/TexasSolver/src/Rule.cpp.Rule 
 - Explanation:  _This code defines a constructor for a class named `Rule`. It initializes various member variables based on input parameters, including error checking to ensure consistency between two commit values._ 
### TexasSolver/TexasSolver/src/TerminalNode.cpp.TerminalNode 
 - Explanation:  _This code defines a constructor for a `TerminalNode` class, which appears to represent a terminal node in a game tree. The constructor initializes various attributes of the node based on input parameters._ 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.isDonk 
 - Explanation:  _This code defines a method `isDonk` in the `ChanceNode` class that returns a boolean value indicating whether the node represents a donk action or not. The method simply returns the value of an instance variable named `donk`._ 
### TexasSolver/TexasSolver/GameTree.cpp.get_possible_bets 
 - Explanation:  _This code calculates possible bets in a game of Texas Hold'em based on the current game state and rules.
It takes into account various factors such as player positions, bet types, and stack sizes to determine valid betting amounts._ 
### TexasSolver/TexasSolver/src/ActionNode.cpp.setActions 
 - Explanation:  _This code sets actions for an ActionNode object using a vector of GameActions. The setActions method assigns the provided actions to the object's actions member variable._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.getPot 
 - Explanation:  _This code defines a method `getPot` in the class `GameTreeNode`, which returns the value of the instance variable `pot`. The method simply retrieves and returns the current value of `pot`._ 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.ChanceNode 
 - Explanation:  _This code defines a constructor for a `ChanceNode` class, which appears to be part of a game tree data structure in a poker-related project. The constructor initializes various member variables based on input parameters._ 
### TexasSolver/TexasSolver/src/GameActions.cpp.GameActions 
 - Explanation:  _This code defines a constructor for the `GameActions` class, which initializes its member variables based on input parameters related to poker game actions and betting amounts. The constructor enforces specific rules regarding valid action and amount combinations._ 
### TexasSolver/TexasSolver/src/ShowdownNode.cpp.ShowdownNode 
 - Explanation:  _This code defines a constructor for a class called `ShowdownNode`, which appears to be part of a game tree data structure. The constructor initializes various member variables related to payoffs and game state._ 
### TexasSolver/TexasSolver/src/ActionNode.cpp.ActionNode 
 - Explanation:  _This code defines a constructor for the `ActionNode` class, which initializes its member variables from input parameters. The constructor takes several inputs and assigns them to corresponding member variables in the object being created._ 
### TexasSolver/TexasSolver/src/Rule.cpp.get_pot 
 - Explanation:  _This code defines a method `get_pot` in a class named `Rule`. The method returns the sum of two member variables: `oop_commit` and `ip_commit`, both of which are floats._ 
### TexasSolver/TexasSolver/src/ActionNode.cpp.setChildrens 
 - Explanation:  _This code sets the children nodes for an ActionNode object in a game tree structure. The setChildrens method takes a vector of shared pointers to GameTreeNode objects as input and assigns it to the childrens member variable of the ActionNode class._ 
### TexasSolver/TexasSolver/Card.cpp.empty 
 - Explanation:  _This code defines a method `empty` in the `Card` class that checks if a card is empty or not. The method returns true if the card is empty, and false otherwise._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.intToGameRound 
 - Explanation:  _This code defines a method `intToGameRound` that converts an integer game round number to its corresponding enum value in the `GameTreeNode` class. The method uses a switch statement to map the integer values 0-3 to their respective game rounds (PREFLOP, FLOP, TURN, RIVER)._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`buildAction`: The function of `buildAction` is *FILL IN* 
**Parameters**:\
`shared_ptr<ActionNode> root`: *FILL IN* \
`Rule rule`: *FILL IN* \
`string last_action`: *FILL IN* \
`int check_times`: *FILL IN* \
`int raise_times`: *FILL IN* \

**Code Description**: *FILL IN*
