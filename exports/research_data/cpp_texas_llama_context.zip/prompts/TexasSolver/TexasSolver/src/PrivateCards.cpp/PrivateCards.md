# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/PrivateCards.cpp` \
**Type:** `Method` \
**Method Name:** `PrivateCards` \
**Code Content:** \
`PrivateCards::PrivateCards(int card1, int card2, float weight) {
    this->card1 = card1;
    this->card2 = card2;
    this->weight = weight;
    this->relative_prob = 0;
    this->card_vec = vector<int>{this->card1,this->card2};
    if (card1 > card2){
        this->hash_code = card1 * 52 + card2;
    }else{
        this->hash_code = card2 * 52 + card1;
    }
    this->board_long = Card::boardInts2long(this->card_vec);
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/Card.cpp.boardInts2long 
 - Explanation:  _This code converts a vector of integers representing a poker board into a single 64-bit unsigned integer. It checks for valid card IDs and performs bitwise operations to achieve this conversion._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`PrivateCards`: The function of `PrivateCards` is *FILL IN* 
**Parameters**:\
`int card1`: *FILL IN* \
`int card2`: *FILL IN* \
`float weight`: *FILL IN* \

**Code Description**: *FILL IN*
