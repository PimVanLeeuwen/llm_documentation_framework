# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/PrivateCardsManager.cpp` \
**Type:** `Method` \
**Method Name:** `PrivateCardsManager` \
**Code Content:** \
`PrivateCardsManager::PrivateCardsManager(vector<vector<PrivateCards>> private_cards, int player_number,
                                         uint64_t initialboard) {
    this->private_cards = private_cards;
    this->player_number = player_number;
    this->card_player_index = vector<vector<int>>(52 * 52);
    for(int i = 0;i < 52 * 52;i ++){
        this->card_player_index[i] = vector<int>(this->player_number,-1);
    }

    // 用一个二维数组记录每个Private Combo的对应index,方便从一方的手牌找对方的同名卡牌的index
    for(int player_id = 0;player_id < player_number;player_id ++){
        vector<PrivateCards> privateCombos = private_cards[player_id];
        for(std::size_t i = 0;i < privateCombos.size();i ++){
            PrivateCards one_private_combo = privateCombos[i];
            this->card_player_index[one_private_combo.hashCode()][player_id] = i;
        }
    }

    this->initialboard = initialboard;
    this->setRelativeProbs();
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/PrivateCards.cpp.hashCode 
 - Explanation:  _This code defines a method `hashCode` in the `PrivateCards` class that returns the value stored in the `hash_code` member variable.

The purpose of this method appears to be generating a unique identifier or hash for an instance of the `PrivateCards` class._ 
### TexasSolver/TexasSolver/src/PrivateCardsManager.cpp.setRelativeProbs 
 - Explanation:  _This code calculates relative probabilities for private cards in a poker game, considering interactions between players' hands and the initial board state.

The `setRelativeProbs` method iterates through each player's private cards, computes their relative probabilities based on opponent's card weights, and normalizes these values within each player's set of cards._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`PrivateCardsManager`: The function of `PrivateCardsManager` is *FILL IN* 
**Parameters**:\
`vector<vector<PrivateCards>> private_cards`: *FILL IN* \
`int player_number`: *FILL IN* \
`uint64_t initialboard`: *FILL IN* \

**Code Description**: *FILL IN*
