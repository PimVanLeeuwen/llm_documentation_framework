`SolarTimesCalculator`: The function of `SolarTimesCalculator` is to initialize a solar times calculator object for a given planet.

**Parameters**:\
`const Sun<PLANET> &sun`: This parameter represents the sun's information for the specified planet, including its date and position.

**Code Description**: 
The code initializes a `SolarTimesCalculator` object by calling the constructor with a reference to a `Sun` object. The constructor sets up three member variables: `_sun`, `_cycle`, and `_transit`. It calculates the Julian cycle using the `getJulianCycle` function, which takes into account the date and longitude of the observer on the planet. The solar transit time is calculated using the `calculateSolarTransit` function, which returns a Julian Date value representing the time when the Sun crosses the meridian at a given longitude.\\
## Code: 
```
SolarTimesCalculator<PLANET>::SolarTimesCalculator(const Sun<PLANET> &sun) :
    _sun(sun),
    _cycle(getJulianCycle<PLANET>(
        _sun._observer.getDate(),
        _sun._observer.getPosition().longitude)),
    _transit(calculateSolarTransit(0_rad)) {}
```