`getJulianCycle`: The function of `getJulianCycle` is to calculate the Julian cycle number.

**Parameters**:
`const JulianDate &date`: This parameter represents a date in the Julian Date system.
`angle_type longitudeEast`: This parameter represents the longitude east angle, which is used to adjust the Julian cycle calculation.

**Code Description**: The function uses the `std::round` function to round the result of a mathematical expression involving the truncated Julian Date (2000), the planet's J0 and J3 constants, and the longitude East angle. The result is then returned as a float value representing the Julian cycle number.\\
## Code: 
```
static float_type getJulianCycle(const JulianDate &date, angle_type longitudeEast) {
    return std::round(
        (date.truncated2000() - C::get<PLANET, C::J0>()) / C::get<PLANET, C::J3>() +
         longitudeEast / 2_pi_rad);
  }
```