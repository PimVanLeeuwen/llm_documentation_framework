## Expected output
`hourAngle`: The function of `hourAngle` is to calculate the hour angle.
**Parameters**:
`angle_type alt`: The altitude of an object above the horizon.
`angle_type dec`: The declination of the object, which is its angular distance from the celestial equator.
`angle_type lat`: The latitude of the observer's location on Earth.

**Code Description**: This function uses trigonometric functions to calculate the hour angle based on the given altitude, declination, and latitude. It returns an angle value representing the hour angle.\\
## Code: 
```
angle_type Trigonometry::hourAngle(angle_type alt, angle_type dec, angle_type lat) {
    return ACos((Sin(alt) - Sin(dec) * Sin(lat)) / (Cos(dec) * Cos(lat)));
  }
```