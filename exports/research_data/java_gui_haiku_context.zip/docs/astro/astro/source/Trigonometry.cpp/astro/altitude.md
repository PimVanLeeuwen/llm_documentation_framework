**The function of `altitude` is to calculate the altitude angle between a celestial object and an observer's horizon.**

**Parameters:**
- `angle_type h`: The hour angle, which is the angular distance between the observer's local meridian and the object's right ascension.
- `angle_type decl`: The declination, which is the angular distance of the object from the celestial equator.
- `angle_type lat`: The latitude of the observer's location on Earth.

**Code Description:** 
The function uses trigonometric functions to calculate the altitude angle. It first calculates the cosine of the hour angle (`Cos(h)`), declination (`Cos(decl) * Cos(lat)`), and then combines these with the sine of the declination (`Sin(decl)`) and latitude (`Sin(lat)`) using the `ASin` function, which returns the arcsine (inverse sine) of a given value. The result is the altitude angle between the object and the observer's horizon.\\
## Code: 
```
angle_type Trigonometry::altitude(angle_type h, angle_type decl, angle_type lat) {
    return ASin(Cos(h) * Cos(decl) * Cos(lat) + Sin(decl) * Sin(lat));
  }
```