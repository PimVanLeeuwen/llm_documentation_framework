## Expected output
`azimuth`: The function of `azimuth` is to calculate the azimuth angle.
**Parameters**:\
`angle_type h`: The hour angle, which is the angular distance between the observer's local meridian and the object's hour circle.
`angle_type decl`: The declination, which is the angular distance between the object's position on the celestial equator and its position in the sky.
`angle_type lat`: The latitude of the observer's location.
**Code Description**: The function uses trigonometric functions to calculate the azimuth angle based on the given hour angle, declination, and latitude. It utilizes the ATan2 function to compute the arctangent of the ratio between sine of the hour angle and a value derived from cosine of the hour angle, sine of the latitude, and tangent of the declination multiplied by cosine of the latitude.\\
## Code: 
```
angle_type Trigonometry::azimuth(angle_type h, angle_type decl, angle_type lat) {
    return ATan2(Sin(h), Cos(h) * Sin(lat) - Tan(decl) * Cos(lat));
  }
```