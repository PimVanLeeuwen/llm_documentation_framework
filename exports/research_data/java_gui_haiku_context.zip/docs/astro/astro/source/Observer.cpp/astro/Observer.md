`Observer`: The function of `Observer` is to initialize an observer object with a given date and position.

**Parameters**:
`const JulianDate &date`: This parameter represents the date for which the observer's information will be calculated.
`const GeographicalCoords &position`: This parameter represents the geographical coordinates (longitude) at which the observer is located.

**Code Description**: The `Observer` function initializes an object of type `Observer<PLANET>` with the provided date and position. It sets the `_date`, `_position`, and `_siderealTime` member variables to the input values, where `_siderealTime` is calculated using the `getSiderealTime` method.\\
## Code: 
```
Observer<PLANET>::Observer(const JulianDate &date, const GeographicalCoords &position) :
    _date(date),
    _position(position),
    _siderealTime(astro::getSiderealTime<PLANET>(_date, _position.longitude)) {}
```