`JulianDate`: The function of `JulianDate` is to initialize a Julian date object with the given parameters.

**Parameters**:
`long unsigned julianDay`: This parameter represents the day number in the Julian calendar, starting from 1 for January 1, 4713 BCE.
`long unsigned secondsSinceNoon`: This parameter represents the number of seconds that have passed since noon on the specified Julian day.

**Code Description**: The `JulianDate` constructor initializes a new object with the given `julianDay` and `secondsSinceNoon`. It then calls the `fix()` method to perform any necessary adjustments or calculations.\\
## Code: 
```
JulianDate::JulianDate(long unsigned julianDay, long unsigned secondsSinceNoon) :
    _day(julianDay),
    _seconds(secondsSinceNoon) {
    fix();
  }
```