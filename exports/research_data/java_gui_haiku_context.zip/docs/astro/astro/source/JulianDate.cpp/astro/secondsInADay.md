`secondsInADay`: The function of `secondsInADay` is to calculate the total number of seconds in a day.

**Code Description**: This function uses a mathematical formula to compute the total number of seconds in a 24-hour period. It multiplies the number of hours (24) by the number of seconds per hour (3600), resulting in the total number of seconds in a day, which is a constant value.\\
## Code: 
```
static constexpr long unsigned secondsInADay() {
    return 24 * 3600;
  }
```