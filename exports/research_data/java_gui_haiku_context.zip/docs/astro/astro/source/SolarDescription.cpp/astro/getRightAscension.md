`getRightAscension`: The function of `getRightAscension` is to calculate the right ascension of a celestial body.

**Code Description**: This code calculates the right ascension in astronomy using trigonometric functions. It takes three angles as input: longitude, latitude, and ecliptic longitude, and returns a calculated angle representing the right ascension. The function uses the `Trigonometry::rightAscension` method to perform this calculation.\\
## Code: 
```
angle_type SolarDescription<PLANET>::getRightAscension() const {
    return Trigonometry::rightAscension(_eclipticalLongitude, C::get<PLANET, C::Obliquity>());
  }
```