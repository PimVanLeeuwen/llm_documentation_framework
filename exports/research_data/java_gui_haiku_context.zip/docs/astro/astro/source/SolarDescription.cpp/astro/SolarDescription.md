**SolarDescription**: The function of `SolarDescription` is to calculate the solar description for a given planet at a specific date.

**Parameters**:
`const JulianDate &date`: This parameter represents the date for which the solar description is being calculated, with the date truncated to the year 2000.

**Code Description**: 
The code calculates the mean anomaly and equation of the center for a given planet based on its orbital parameters. The mean anomaly is calculated using the formula M = M0 + M1 (J - J2000), where M0 and M1 are constants specific to each planet, and J is the Julian date. The equation of the center is calculated using the formula C ~ C1 sin(M) + C2 sin(2M) + C3 sin(3M) + C4 sin(4M) + C5 sin(5M) + C6 sin(6M), where C1 to C6 are constants specific to each planet. The ecliptical longitude is then calculated using the formula l = M + C + Perihelion + 180, where Perihelion is a constant specific to each planet.\\
## Code: 
```
SolarDescription<PLANET>::SolarDescription(const JulianDate &date) {
    // M = M0 + M1 (J - J2000)
    _meanAnomaly = C::get<PLANET, C::M0>() + C::get<PLANET, C::M1>() * date.truncated2000();
    // C ~ C1 sin(M) + C2 sin(2M) + C3 sin(3M) + C4 sin(4M) + C5 sin(5M) + C6 sin(6M)
    _equationOfTheCenter = C::get<PLANET, C::C1>() * Sin(_meanAnomaly) +
                           C::get<PLANET, C::C2>() * Sin(2.0 * _meanAnomaly) +
                           C::get<PLANET, C::C3>() * Sin(3.0 * _meanAnomaly) +
                           C::get<PLANET, C::C4>() * Sin(4.0 * _meanAnomaly) +
                           C::get<PLANET, C::C5>() * Sin(5.0 * _meanAnomaly) +
                           C::get<PLANET, C::C6>() * Sin(6.0 * _meanAnomaly);
    // l = M + C + Perihelion + 180
    _eclipticalLongitude = _meanAnomaly + _equationOfTheCenter + C::get<PLANET, C::Perihelion>() + 1_pi_rad;
  }
```