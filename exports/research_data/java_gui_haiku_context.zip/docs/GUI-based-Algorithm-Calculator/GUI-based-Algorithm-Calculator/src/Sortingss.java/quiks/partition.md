`partition`: The function of `partition` is to partition the given array around a pivot element.

**Parameters**:
`int[] num`: This parameter represents the input array that needs to be partitioned.
`int start`: This parameter represents the starting index of the subarray that needs to be partitioned.
`int end`: This parameter represents the ending index of the subarray that needs to be partitioned.

**Code Description**: The `partition` function takes an array, a start index, and an end index as input. It selects the last element of the subarray (at index `end`) as the pivot element. Then, it iterates through the subarray from the start index to the second last element (at index `end-1`). If an element is less than the pivot, it swaps that element with the element at the current start index and increments the start index. Finally, it swaps the pivot element with the element at the new start index and returns the new start index.\\
## Code: 
```
int partition(int[] num, int start, int end){
	         int pivot = num[end];

	         for(int i=start; i<end; i++){
	            if(num[i]<pivot){
	            int temp= num[start];
	            num[start]=num[i];
	            num[i]=temp;
	            start++;
	        }
	        }

	        int temp = num[start];
	        num[start] = pivot;
	        num[end] = temp;
	        return start;

	        }
```