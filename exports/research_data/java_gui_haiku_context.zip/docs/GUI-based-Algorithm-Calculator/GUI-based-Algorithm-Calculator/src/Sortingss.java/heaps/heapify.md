`heapify`: The function of `heapify` is to maintain the heap property in a given array by ensuring that the parent node is greater than or equal to its child nodes.

**Parameters**:
- `int num[]`: This parameter represents the input array that needs to be heapified.
- `int size`: This parameter specifies the size of the input array, which is used to determine the valid indices within the array.
- `int i`: This parameter represents the index from which the heapification process starts.

**Code Description**: The `heapify` function takes an array `num`, its size `size`, and a starting index `i`. It first checks if the left child of the node at index `i` exists and is greater than the current largest value. If so, it updates the largest value to be the left child's index. Similarly, it checks the right child and updates the largest value if necessary. If the largest value is not at the current index `i`, it swaps the values at indices `i` and `largest`. Finally, it recursively calls itself with the updated array and the new largest value to ensure that the heap property is maintained throughout the entire array.\\
## Code: 
```
void heapify(int num[], int size, int i)
    {
        int largest = i;
        int left = 2*i + 1;
        int right = 2*i + 2;

        if (left < size && num[left] >num[largest])
            largest = left;

        if (right < size && num[right] > num[largest])
            largest = right;

        if (largest != i)
        {
        	int temp;
            temp = num[i];
            num[i]= num[largest];
            num[largest] = temp;
            heapify(num, size, largest);
        }
    }
```