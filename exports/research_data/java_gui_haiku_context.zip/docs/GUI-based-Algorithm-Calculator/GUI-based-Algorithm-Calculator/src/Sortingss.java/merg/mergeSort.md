`mergeSort`: The function of `mergeSort` is to recursively sort an array of integers using the Merge Sort algorithm.

**Parameters**:
- `int num[]`: This parameter represents the input array that needs to be sorted.
- `int l`: This parameter represents the starting index of the subarray within the input array that needs to be sorted.
- `int r`: This parameter represents the ending index of the subarray within the input array that needs to be sorted.

**Code Description**: The code implements a recursive version of the Merge Sort algorithm. It first checks if the left and right indices (`l` and `r`) are not equal, indicating that there is more than one element in the current subarray. If this condition is met, it calculates the middle index (`m`) to split the array into two halves. The function then recursively calls itself for both halves of the array (left half from `l` to `m`, and right half from `m+1` to `r`). After these recursive calls return, it merges the sorted left and right subarrays using the `merge` method, which is called with the indices `l`, `m`, and `r`. This merging step ensures that the final array is sorted.\\
## Code: 
```
void mergeSort(int num[], int l, int r)
    {
        if (l < r)
        {
                int m = l+(r-l)/2;

            mergeSort(num, l, m);
            mergeSort(num, m+1, r);
            merge(num, l, m, r);
        }
    }
```