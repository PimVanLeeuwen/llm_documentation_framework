`heapSort`: The function of `heapSort` is to sort an array in ascending order using the heap sort algorithm.

**Parameters**:
`int num[]`: This parameter represents the input array that needs to be sorted.
`int size`: This parameter represents the size of the input array.

**Code Description**: 
The code implements a heap sort algorithm, which first builds a max-heap from the unsorted array and then repeatedly removes the maximum element (the root of the heap) and places it at the end of the array. The heapify function is used to maintain the heap property after each removal.\\
## Code: 
```
void heapSort(int num[], int size)
	    {
	        int i;
	        for (i = size / 2 - 1; i >= 0; i--)
	            heapify(num, size, i);
	        for (i=size-1; i>=0; i--)
	        {
	        	int temp;
	            temp = num[0];
	            num[0]= num[i];
	            num[i] = temp;
	            heapify(num, i, 0);
	        }
	     }
```