`quickSort`: The function of `quickSort` is to recursively sort an array of integers using the Quicksort algorithm.

**Parameters**:
`int[] num`: This parameter represents the array of integers that needs to be sorted.
`int start`: This parameter represents the starting index of the subarray within the main array that needs to be sorted.
`int end`: This parameter represents the ending index of the subarray within the main array that needs to be sorted.

**Code Description**: The `quickSort` function uses a recursive approach to sort the array. It first calls the `partition` method to rearrange the elements in the array such that all elements less than the pivot are on its left, and all elements greater than the pivot are on its right. The `partition` method returns the index of the pivot element after partitioning. The function then recursively calls itself to sort the subarrays on either side of the pivot. This process continues until the entire array is sorted.\\
## Code: 
```
void quickSort(int[] num, int start, int end)
	 {
	    int partition = partition(num, start, end);
        if(partition-1>start)
        {
        	quickSort(num, start, partition - 1);
        }
    	if(partition+1<end) 
    	{
    		quickSort(num, partition + 1, end);
    	}
	 }
```