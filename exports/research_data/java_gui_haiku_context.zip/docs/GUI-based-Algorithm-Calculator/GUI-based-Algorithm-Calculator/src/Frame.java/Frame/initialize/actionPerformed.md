`actionPerformed`: The function of `actionPerformed` is to perform an action when an event occurs.
**Parameters**: 
`ActionEvent e`: This parameter represents the event that triggered the action.
**Code Description**: When the `actionPerformed` method is called, it invokes the `vis` method from the `Sortingss` class with parameters 6 and "HEAP SORT", then hides the current frame.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
				obj.vis(6,"HEAP SORT");
				frame.setVisible(false);
			}
```