# PROMPT
## Information
**Project Structure:** `GUI-based-Algorithm-Calculator` \
**File Path:** `GUI-based-Algorithm-Calculator/GUI-based-Algorithm-Calculator/src/Frame.java/Frame` \
**Type:** `Method` \
**Method Name:** `initialize` \
**Code Content:** \
`void initialize() {
		Sortingss obj = new Sortingss();
		frame = new JFrame();
		frame.setBounds(100, 100, 456, 324);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Bubble Sort");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(1,"BUBBLE SORT");
				frame.setVisible(false);	
			}
		});
		btnNewButton.setBounds(43, 48, 128, 25);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Insertion Sort");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(4,"INSERTION SORT");
				frame.setVisible(false);
			}
		});
		btnNewButton_1.setBounds(253, 48, 128, 25);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Selection Sort");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(2,"SELECTION SORT");
				frame.setVisible(false);
			}
		});
		btnNewButton_2.setBounds(43, 116, 128, 25);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Merge Sort");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(5,"MERGE SORT");
				frame.setVisible(false);
			}
		});
		btnNewButton_3.setBounds(253, 116, 128, 25);
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Quick Sort");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(3,"QUICK SORT");
				frame.setVisible(false);
			}
		});
		btnNewButton_4.setBounds(43, 178, 128, 25);
		frame.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Max Heap Sort");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				obj.vis(6,"HEAP SORT");
				frame.setVisible(false);
			}
		});
		btnNewButton_5.setBounds(253, 178, 128, 25);
		frame.getContentPane().add(btnNewButton_5);
	}`



## Children 
 This code contains the following methods/classes that are already documented: 
### actionPerformed 
This code defines an event handler for a GUI button click, which hides the current frame and displays information about the BUBBLE SORT algorithm using another method called `vis`. The `vis` method is used to display GUI-related information. 
### actionPerformed 
This code defines an event handler for a GUI button click, which triggers the visualization of the Insertion Sort algorithm when executed.

The `actionPerformed` method makes a GUI frame invisible and calls another method to visualize the sorting process. 
### actionPerformed 
This code defines an `actionPerformed` method that hides a GUI frame when triggered, and calls another method to display information about the selection sort algorithm. The `vis` method from Sortingss.java is used to display this information. 
### actionPerformed 
This code defines an event handler for GUI interactions, specifically hiding a frame when a certain action is performed. The `vis` method from another class is called to perform some algorithm-related task. 
### actionPerformed 
This code defines an event handler for a GUI component, specifically hiding the current frame when a certain action is performed. The `vis` method from another class is called to perform some visualization-related task before hiding the frame. 
### actionPerformed 
This code defines an event handler for GUI actions, specifically hiding a frame when a certain action is performed. The `vis` method from another class is called to display information about the algorithm being used. 



## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`initialize`: The function of `initialize` is *FILL IN* 

**Code Description**: *FILL IN*
