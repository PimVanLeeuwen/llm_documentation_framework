# PROMPT
## Information
**Project Structure:** `GUI-based-Algorithm-Calculator` \
**File Path:** `GUI-based-Algorithm-Calculator/GUI-based-Algorithm-Calculator/src/Sortingss.java/heaps` \
**Type:** `Method` \
**Method Name:** `heapify` \
**Code Content:** \
`void heapify(int num[], int size, int i)
    {
        int largest = i;
        int left = 2*i + 1;
        int right = 2*i + 2;

        if (left < size && num[left] >num[largest])
            largest = left;

        if (right < size && num[right] > num[largest])
            largest = right;

        if (largest != i)
        {
        	int temp;
            temp = num[i];
            num[i]= num[largest];
            num[largest] = temp;
            heapify(num, size, largest);
        }
    }`

## Calls 
 This code calls the following methods within the repository: 
### GUI-based-Algorithm-Calculator/GUI-based-Algorithm-Calculator/src/Sortingss.java/heaps.heapify 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`heapify`: The function of `heapify` is *FILL IN* 
**Parameters**:\
`int num[]`: *FILL IN* \
`int size`: *FILL IN* \
`int i`: *FILL IN* \

**Code Description**: *FILL IN*
