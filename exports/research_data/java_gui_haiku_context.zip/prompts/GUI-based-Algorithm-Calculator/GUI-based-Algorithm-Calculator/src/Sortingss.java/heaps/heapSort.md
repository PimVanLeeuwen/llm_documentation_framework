# PROMPT
## Information
**Project Structure:** `GUI-based-Algorithm-Calculator` \
**File Path:** `GUI-based-Algorithm-Calculator/GUI-based-Algorithm-Calculator/src/Sortingss.java/heaps` \
**Type:** `Method` \
**Method Name:** `heapSort` \
**Code Content:** \
`void heapSort(int num[], int size)
	    {
	        int i;
	        for (i = size / 2 - 1; i >= 0; i--)
	            heapify(num, size, i);
	        for (i=size-1; i>=0; i--)
	        {
	        	int temp;
	            temp = num[0];
	            num[0]= num[i];
	            num[i] = temp;
	            heapify(num, i, 0);
	        }
	     }`

## Calls 
 This code calls the following methods within the repository: 
### GUI-based-Algorithm-Calculator/GUI-based-Algorithm-Calculator/src/Sortingss.java/heaps.heapify 
 - Explanation:  _This code implements the heapify function, which rearranges a given array to satisfy the heap property. The heapify function recursively swaps elements in the array to ensure that the parent node is greater than or equal to its child nodes._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`heapSort`: The function of `heapSort` is *FILL IN* 
**Parameters**:\
`int num[]`: *FILL IN* \
`int size`: *FILL IN* \

**Code Description**: *FILL IN*
