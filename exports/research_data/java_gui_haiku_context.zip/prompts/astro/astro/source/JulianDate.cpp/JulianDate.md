# PROMPT
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/JulianDate.cpp` \
**Type:** `Method` \
**Method Name:** `JulianDate` \
**Code Content:** \
`JulianDate::JulianDate(const boost::posix_time::ptime &utc) :
    _day(utc.date().julian_day() - 1),
    _seconds(utc.time_of_day().total_seconds() + 12 * 3600) {
    fix();
  }`






## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`JulianDate`: The function of `JulianDate` is *FILL IN* 
**Parameters**:\
`const boost::posix_time::ptime &utc`: *FILL IN* \

**Code Description**: *FILL IN*
