# PROMPT
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/Trigonometry.cpp/astro` \
**Type:** `Method` \
**Method Name:** `azimuth` \
**Code Content:** \
`angle_type Trigonometry::azimuth(angle_type h, angle_type decl, angle_type lat) {
    return ATan2(Sin(h), Cos(h) * Sin(lat) - Tan(decl) * Cos(lat));
  }`






## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`azimuth`: The function of `azimuth` is *FILL IN* 
**Parameters**:\
`angle_type h`: *FILL IN* \
`angle_type decl`: *FILL IN* \
`angle_type lat`: *FILL IN* \

**Code Description**: *FILL IN*
