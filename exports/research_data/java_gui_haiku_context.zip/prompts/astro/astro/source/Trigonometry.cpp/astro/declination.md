# PROMPT
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/Trigonometry.cpp/astro` \
**Type:** `Method` \
**Method Name:** `declination` \
**Code Content:** \
`angle_type Trigonometry::declination(angle_type l, angle_type b, angle_type e) {
    return ASin(Sin(b) * Cos(e) + Cos(b) * Sin(e) * Sin(l));
  }`






## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`declination`: The function of `declination` is *FILL IN* 
**Parameters**:\
`angle_type l`: *FILL IN* \
`angle_type b`: *FILL IN* \
`angle_type e`: *FILL IN* \

**Code Description**: *FILL IN*
