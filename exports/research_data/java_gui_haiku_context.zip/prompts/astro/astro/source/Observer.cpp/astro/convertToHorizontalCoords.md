# PROMPT
## Information
**Project Structure:** `astro` \
**File Path:** `astro/astro/source/Observer.cpp/astro` \
**Type:** `Method` \
**Method Name:** `convertToHorizontalCoords` \
**Code Content:** \
`HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }`

## Calls 
 This code calls the following methods within the repository: 
### astro/astro/source/Trigonometry.cpp/astro.declination 
 - Explanation:  _This code calculates the declination in astronomy using trigonometric functions. It takes three angles as input: longitude, latitude, and eccentricity, and returns a calculated declination angle._ 
### astro/astro/source/Trigonometry.cpp/astro.altitude 
 - Explanation:  _This code calculates the altitude angle using trigonometric functions, specifically the arcsine function. It takes three input angles: hour angle (h), declination (decl), and latitude (lat)._ 
### astro/astro/source/Trigonometry.cpp/astro.rightAscension 
 - Explanation:  _This code calculates the right ascension in astronomy using trigonometric functions. It takes three angles as input: longitude, latitude, and ecliptic longitude, and returns a calculated angle representing the right ascension._ 
### astro/astro/source/Trigonometry.cpp/astro.hourAngle 
 - Explanation:  _This code calculates the hour angle in astronomy, given altitude, declination, and latitude angles. It uses trigonometric functions to compute this value._ 
### astro/astro/source/Trigonometry.cpp/astro.azimuth 
 - Explanation:  _This code calculates the azimuth, which is a measure of direction in astronomy, given the hour angle, declination, and latitude. The calculation uses trigonometric functions such as ATan2, Sin, Cos, and Tan to compute the result._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`convertToHorizontalCoords`: The function of `convertToHorizontalCoords` is *FILL IN* 
**Parameters**:\
`const EquatorialCoords &ec`: *FILL IN* \

**Code Description**: *FILL IN*
