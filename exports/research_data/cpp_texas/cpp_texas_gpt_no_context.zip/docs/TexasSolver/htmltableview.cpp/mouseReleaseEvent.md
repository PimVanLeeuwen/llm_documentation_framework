`mouseReleaseEvent`: The function of `mouseReleaseEvent` is to handle the mouse release event in the `HtmlTableView` class.

**Code Description**: This function is triggered when a mouse button is released. It first checks if `_mousePressAnchor` is not empty, indicating that a mouse press event was previously recorded. It then retrieves the anchor at the position of the mouse release event. If the anchor at the release position matches the stored `_mousePressAnchor`, it emits the `linkActivated` signal with `_mousePressAnchor` as the parameter. Finally, it clears `_mousePressAnchor` and calls the base class (`QTableView`) implementation of `mouseReleaseEvent` to ensure standard behavior is maintained.\\
## Code: 
```
void HtmlTableView::mouseReleaseEvent(QMouseEvent *event) {
    if (!_mousePressAnchor.isEmpty()) {
        auto anchor = anchorAt(event->pos());

        if (anchor == _mousePressAnchor) {
            emit linkActivated(_mousePressAnchor);
        }

        _mousePressAnchor.clear();
    }

    QTableView::mouseReleaseEvent(event);
}
```