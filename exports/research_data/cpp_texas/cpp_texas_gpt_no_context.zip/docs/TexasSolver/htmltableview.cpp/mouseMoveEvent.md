`mouseMoveEvent`: The function of `mouseMoveEvent` is to handle mouse movement events within an HTML table view, specifically to manage the cursor appearance and emit signals when hovering over links.

**Code Description**: This function is triggered whenever the mouse moves within the HTML table view. It first determines the anchor (link) at the current mouse position. If the anchor under the mouse has changed since the last recorded position, it updates the internal state. If the new anchor is different from the previous one, it updates the cursor to a pointing hand cursor and emits a `linkHovered` signal with the new anchor. If there is no anchor under the mouse, it restores the default cursor and emits a `linkUnhovered` signal. This provides visual feedback and interaction cues to the user when hovering over links in the HTML table view.\\
## Code: 
```
void HtmlTableView::mouseMoveEvent(QMouseEvent *event) {
    auto anchor = anchorAt(event->pos());

    if (_mousePressAnchor != anchor) {
        _mousePressAnchor.clear();
    }

    if (_lastHoveredAnchor != anchor) {
        _lastHoveredAnchor = anchor;
        if (!_lastHoveredAnchor.isEmpty()) {
            QApplication::setOverrideCursor(QCursor(Qt::PointingHandCursor));
            emit linkHovered(_lastHoveredAnchor);
        } else {
            QApplication::restoreOverrideCursor();
            emit linkUnhovered();
        }
    }
}
```