`resizeEvent`: The function of `resizeEvent` is to handle the resizing of an `HtmlTableView` object when the window or container it resides in is resized.

**Code Description**: 
- The `resizeEvent` function is triggered whenever the `HtmlTableView` object is resized.
- It first checks if the table view has an associated model. If there is no model, the function exits early.
- It retrieves the number of columns and rows from the model.
- If there are columns present, it calculates the new width for each column based on the total available width. Each column's width is set to a percentage of the total width, ensuring that the last column takes up any remaining space.
- Similarly, if there are rows present, it calculates the new height for each row based on the total available height. Each row's height is set to a percentage of the total height, ensuring that the last row takes up any remaining space.
- Finally, it calls the base class's `resizeEvent` method to ensure any default resizing behavior is also executed.\\
## Code: 
```
void HtmlTableView::resizeEvent(QResizeEvent* ev){
    if(model() != NULL){
        int num_columns = this->model()->columnCount(QModelIndex());
        int num_rows = this->model()->rowCount(QModelIndex());
        if (num_columns > 0) {
        int width = ev->size().width();
        int used_width = 0;
        // Set our widths to be a percentage of the available width
        for (int i = 0; i < num_columns - 1; i++) {
            //int column_width = width / num_columns;
            int column_width = (int)((float)width * (i + 1) / num_columns) -  (int)((float)width * (i) / num_columns);
            this->setColumnWidth(i, column_width);
            used_width += column_width;
        }

        // Set our last column to the remaining width
        this->setColumnWidth(num_columns - 1, width - used_width);
        }
        if (num_columns > 0) {
        int height = ev->size().height();
        int used_height = 0;
        for (int i = 0; i < num_columns - 1; i++) {
            //int column_height = height / num_rows;
            int column_height = (int)((float)height * (i + 1) / num_rows) -  (int)((float)height * (i) / num_rows);
            this->setRowHeight(i, column_height);
            used_height += column_height;
        }
        this->setRowHeight(num_columns - 1, height - used_height);
        }
    }
    QTableView::resizeEvent(ev);
}
```