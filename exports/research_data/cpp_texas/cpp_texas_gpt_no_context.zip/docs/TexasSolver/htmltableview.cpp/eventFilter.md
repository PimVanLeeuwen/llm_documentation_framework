`eventFilter`: The function of `eventFilter` is to handle specific events for the `HtmlTableView` object, particularly mouse movements and when the mouse leaves the viewport.

**Code Description**: 
- The `eventFilter` method is overridden to monitor events on the `HtmlTableView`'s viewport.
- It first checks if the event is associated with the viewport.
- If the event is a `QEvent::MouseMove`, it casts the event to a `QMouseEvent` and retrieves the position of the mouse.
- It then determines the table cell (row and column) at the mouse position using `indexAt`.
- If the cell index is valid and different from the last recorded cell (tracked by `last_bearing_i` and `last_bearing_j`), it updates these values and emits the `itemMouseChange` signal with the new row and column indices.
- If the event is a `QEvent::Leave`, it does nothing specific but acknowledges the event.
- Finally, it calls the base class `QTableView`'s `eventFilter` method to ensure standard event processing.\\
## Code: 
```
bool HtmlTableView::eventFilter(QObject *watched, QEvent *event){
    if(viewport() == watched){
        if(event->type() == QEvent::MouseMove){
        QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
        QModelIndex index = indexAt(mouseEvent->pos());
        if(index.isValid()){
            int i = index.row();
            int j = index.column();
            if(i != this->last_bearing_i || j != last_bearing_j){
                this->last_bearing_i = i;
                this->last_bearing_j = j;
                emit itemMouseChange(i,j);
            }
        }
        else{
        }
        }
        else if(event->type() == QEvent::Leave){
        }
    }
    return QTableView::eventFilter(watched, event);
}
```