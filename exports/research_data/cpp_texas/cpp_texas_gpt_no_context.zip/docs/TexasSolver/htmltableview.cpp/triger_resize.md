`triger_resize`: The function of `triger_resize` is to programmatically trigger a resize event for the `HtmlTableView` object.

**Code Description**: The `triger_resize` function creates a new `QResizeEvent` object with the current size of the `HtmlTableView` object. It then calls the `resizeEvent` method with this event to simulate a resize operation. After the event is processed, the dynamically allocated `QResizeEvent` object is deleted to free up memory.\\
## Code: 
```
void HtmlTableView::triger_resize(){
    QResizeEvent* ev = new QResizeEvent(this->size(),this->size());
    this->resizeEvent(ev);
    //this->resize(this->parentWidget()->size());
    delete ev;
}
```