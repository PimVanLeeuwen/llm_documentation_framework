`HtmlTableView`: The function of `HtmlTableView` is to create a custom table view widget that inherits from `QTableView`.

**Code Description**: The `HtmlTableView` constructor initializes the custom table view by calling the parent class `QTableView` constructor with the provided parent widget. It installs an event filter on the viewport of the table view to intercept and handle events, and enables mouse tracking to detect mouse movements over the table view.\\
## Code: 
```
HtmlTableView::HtmlTableView(QWidget *parent):
    QTableView(parent)
{
    viewport()->installEventFilter(this);
    setMouseTracking(true);
}
```