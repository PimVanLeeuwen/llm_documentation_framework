`mousePressEvent`: The function of `mousePressEvent` is to handle mouse press events in the `HtmlTableView` class.

**Code Description**: This function first calls the base class (`QTableView`) implementation of `mousePressEvent` to ensure that any default behavior is executed. It then retrieves the anchor (if any) at the position of the mouse press event using the `anchorAt` method and stores it in the `_mousePressAnchor` member variable. This allows the `HtmlTableView` to keep track of the anchor element that was clicked.\\
## Code: 
```
void HtmlTableView::mousePressEvent(QMouseEvent *event) {
    QTableView::mousePressEvent(event);

    auto anchor = anchorAt(event->pos());
    _mousePressAnchor = anchor;
}
```