`on_confirmBox_accepted`: The function of `on_confirmBox_accepted` is to save user settings for language and round number into a QSettings object when the confirmation box is accepted.

**Code Description**: 
- The function starts by creating a QSettings object with the organization name "TexasSolver" and the application name "Setting".
- It then begins a settings group called "solver".
- The current text from the `languageBox` UI element is retrieved and stored in the `lang` variable.
- Depending on the value of `lang`, the corresponding language code ("EN" for English, "CN" for Chinese) is assigned to the `language_str` variable. If the language is unknown, a debug message is printed.
- The language code is saved in the settings under the key "language".
- The current text from the `roundBox` UI element is converted to an integer and stored in the `round` variable.
- The round number is saved in the settings under the key "dump_round".\\
## Code: 
```
void SettingEditor::on_confirmBox_accepted()
{
    QSettings setting("TexasSolver", "Setting");
    setting.beginGroup("solver");
    QString lang = this->ui->languageBox->currentText();
    QString language_str;
    if(lang == "English"){
        language_str = "EN";
    }else if(lang == "Chinese"){
        language_str = "CN";
    }else{
        qDebug().noquote() << tr("Unknown language: ") << lang << tr("Setting fail");
    }
    setting.setValue("language",language_str);

    int round = this->ui->roundBox->currentText().toInt();
    setting.setValue("dump_round",round);
}
```