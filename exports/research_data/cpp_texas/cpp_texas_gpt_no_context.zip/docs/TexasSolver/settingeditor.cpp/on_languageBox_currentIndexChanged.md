`on_languageBox_currentIndexChanged`: The function of `on_languageBox_currentIndexChanged` is to display a message prompting the user to restart the program when the language selection is changed.

**Code Description**: 
- The function `on_languageBox_currentIndexChanged` is triggered when the current index of a language selection box changes.
- It first checks if the `initized` flag is set to `true`. If not, the function returns immediately without performing any actions.
- If `initized` is `true`, it creates a message indicating that the user needs to restart the program for the language change to take effect.
- This message is logged to the debug output using `qDebug()`.
- A `QMessageBox` is then created, and the message is set as its text.
- The message box is displayed to the user by calling `msgBox.exec()`.\\
## Code: 
```
void SettingEditor::on_languageBox_currentIndexChanged(int index)
{
    if(!initized)return;
    QString message = tr("Restart program to make language selection effective.");
    qDebug().noquote() << message;
    QMessageBox msgBox;
    msgBox.setText(message);
    msgBox.exec();
}
```