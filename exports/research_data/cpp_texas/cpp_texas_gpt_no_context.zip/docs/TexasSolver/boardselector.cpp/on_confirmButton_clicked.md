`on_confirmButton_clicked`: The function of `on_confirmButton_clicked` is to update the text of `boardEdit` and then close the current window.

**Code Description**: When the `confirmButton` is clicked, this function is triggered. It sets the text of the `boardEdit` widget to the current text of the `boardEdit` widget (essentially refreshing or confirming the text). After updating the text, it closes the current window.\\
## Code: 
```
void boardselector::on_confirmButton_clicked()
{
    this->boardEdit->setText(this->ui->boardEdit->text());
    this->close();
}
```