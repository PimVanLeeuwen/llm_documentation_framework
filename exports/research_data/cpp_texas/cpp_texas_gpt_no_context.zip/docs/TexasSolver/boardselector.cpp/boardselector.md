`boardselector`: The function of `boardselector` is to initialize a dialog window for selecting a board configuration in a poker game, based on the specified mode (HOLDEM or SHORTDECK).

**Code Description**: 
- The `boardselector` constructor initializes a `QDialog` with a given `QTextEdit` for board input, a mode (`QSolverJob::Mode`), and an optional parent widget.
- It sets up the user interface and window title.
- Depending on the mode, it sets the available card ranks: "A,K,Q,J,T,9,8,7,6,5,4,3,2" for HOLDEM and "A,K,Q,J,T,9,8,7,6" for SHORTDECK.
- It splits the ranks into a list and initializes a `BoardSelectorTableModel` with the rank list and the current text from `boardEdit`.
- The model is set to a table view in the UI, and a `BoardSelectorTableDelegate` is created and set as the item delegate for the table.
- Finally, it sets the text of `boardEdit` to the current text from the provided `QTextEdit`.\\
## Code: 
```
boardselector::boardselector(QTextEdit* boardEdit,QSolverJob::Mode mode,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::boardselector)
{
    ui->setupUi(this);
    this->setWindowTitle(tr("BoardSelector"));
    this->boardEdit = boardEdit;
    this->mode = mode;

    QString ranks;
    if(mode == QSolverJob::Mode::HOLDEM){
        ranks = "A,K,Q,J,T,9,8,7,6,5,4,3,2";
    }else if(mode == QSolverJob::Mode::SHORTDECK){
        ranks = "A,K,Q,J,T,9,8,7,6";
    }else{
        throw runtime_error("mode not found in range selector");
    }
    this->rank_list = ranks.split(",");

    this->boardSelectorTableModel = new BoardSelectorTableModel(this->rank_list,boardEdit->toPlainText(),this);
    this->ui->boardSelectorTable->setModel(boardSelectorTableModel);
    this->boardSelectorTableDelegate = new BoardSelectorTableDelegate(this->rank_list,this->boardSelectorTableModel,this);
    this->ui->boardSelectorTable->setItemDelegate(this->boardSelectorTableDelegate);
    this->ui->boardEdit->setText(boardEdit->toPlainText());
}
```