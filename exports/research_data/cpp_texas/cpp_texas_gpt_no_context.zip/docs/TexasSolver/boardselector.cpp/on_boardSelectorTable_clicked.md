`on_boardSelectorTable_clicked`: The function of `on_boardSelectorTable_clicked` is to handle the event when a cell in the board selector table is clicked.

**Code Description**: When a cell in the board selector table is clicked, this function retrieves the row and column of the clicked cell. It then toggles the value at that cell in the `boardSelectorTableModel` (changing it from 0 to 1 or from 1 to 0). If the text in the `boardEdit` UI element does not match the current board text from the model, it updates the `boardEdit` text to reflect the current board state. Finally, it sets the focus back to the `boardEdit` and `boardSelectorTable` UI elements.\\
## Code: 
```
void boardselector::on_boardSelectorTable_clicked(const QModelIndex &index)
{
    int row = index.row();
    int col = index.column();
    this->boardSelectorTableModel->setBoardAt(row,col,1 - this->boardSelectorTableModel->getBoardAt(row,col));
    if(this->ui->boardEdit->text() != this->boardSelectorTableModel->getBoardText()){
        this->ui->boardEdit->setText(this->boardSelectorTableModel->getBoardText());
    }
    this->ui->boardEdit->setFocus();
    this->ui->boardSelectorTable->setFocus();
}
```