`recurrentGenerateTreeNode`: The function of `recurrentGenerateTreeNode` is to recursively generate a game tree node based on the provided JSON data and its parent node.

**Code Description**: 
The `recurrentGenerateTreeNode` function takes a JSON object `node_json` and a shared pointer to a parent `GameTreeNode` and returns a shared pointer to a newly created `GameTreeNode`. The function performs the following steps:

1. Extracts the metadata from the JSON object, specifically the `round` and `node_type` fields.
2. Validates the `round` field to ensure it is one of the expected values: "preflop", "flop", "turn", or "river". If not, it throws a runtime error.
3. Validates the `node_type` field to ensure it is one of the expected values: "Terminal", "Showdown", "Action", or "Chance". If not, it throws a runtime error.
4. Depending on the `node_type`, it processes the node differently:
   - For "Action" nodes, it retrieves the list of children actions and corresponding children nodes, ensuring their sizes match. It then generates an action node using these details.
   - For "Showdown" nodes, it generates a showdown node.
   - For "Terminal" nodes, it generates a terminal node.
   - For "Chance" nodes, it ensures there is exactly one child node and generates a chance node using this child.
5. Returns the newly created node as a shared pointer to `GameTreeNode`.

The function ensures the integrity and correctness of the game tree structure by validating the input data and handling different node types appropriately.\\
## Code: 
```
shared_ptr<GameTreeNode> GameTree::recurrentGenerateTreeNode(json node_json, const shared_ptr<GameTreeNode>& parent) {
    json meta = node_json["meta"];
    string round = meta["round"];
    if(round.empty()){
        throw runtime_error("node json get round null pointer");
    }

    if(! (round == "preflop"
          || round == "flop"
          || round == "turn"
          || round == "river"
          )
            ){
        throw runtime_error(tfm::format("round %s not found",round));
    }

    string node_type = meta["node_type"];
    if(node_type.empty()){
        throw runtime_error("node json get round null pointer");
    }
    if (! (   node_type == "Terminal"
           || node_type == "Showdown"
           || node_type ==  "Action"
           || node_type ==  "Chance"
    )
            ){
        throw runtime_error(tfm::format("node type %s not found",node_type));
    }

    if(node_type == "Action") {
        // 孩子节点的动作，存在list里
        auto childrens_actions = node_json["children_actions"].get<std::vector<string>>();
        // 孩子节点本身，同样存在list里,和上面的children_actions 一一对应,事实上两者的长度一致
        vector<json> childrens = node_json["children"].get<std::vector<json>>();
        if (childrens.size() != childrens_actions.size()) {
            throw runtime_error("action node child length mismatch");
        }
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateActionNode(meta, childrens_actions, childrens, round,parent));
    }
    else if(node_type == "Showdown") {
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateShowdownNode(meta, round,parent));
    }
    else if(node_type == "Terminal") {
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateTerminalNode(meta, round,parent));
    }
    else if(node_type == "Chance") {
        auto childrens = node_json["children"].get<std::vector<json>>();
        if(childrens.size() != 1) throw runtime_error("Chance node should have only one child");
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateChanceNode(meta, childrens[0], round,parent));
    }
    else{
        throw runtime_error(tfm::format("node type %s not found",node_type));
    }
}
```