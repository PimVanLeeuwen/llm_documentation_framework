`generateShowdownNode`: The function of `generateShowdownNode` is to create and return a shared pointer to a `ShowdownNode` object based on the provided metadata, round information, and parent node.

**Code Description**: This function takes three parameters: `meta` (a JSON object containing metadata about the game), `round` (a string representing the current round of the game), and `parent` (a shared pointer to the parent `GameTreeNode`). It extracts the payoffs for each player and the tie payoffs from the `meta` JSON object. It then converts the round string to a `GameRound` enum and uses the extracted information to create a `ShowdownNode` object. The function returns a shared pointer to this newly created `ShowdownNode`. The function also includes error handling to ensure that player IDs are valid.\\
## Code: 
```
shared_ptr<ShowdownNode> GameTree::generateShowdownNode(json meta, string round, shared_ptr<GameTreeNode> parent) {
    json meta_payoffs = meta["payoffs"];
    vector<double> tie_payoffs = meta_payoffs["tie"];

    // meta_payoffs 的key有 n个玩家+1个平局,代表某个玩家赢了的时候如何分配payoff
    vector<vector<double>> player_payoffs(2);
    double pot = meta["pot"];

    for(auto one_player_meta=meta_payoffs.begin(); one_player_meta!=meta_payoffs.end(); one_player_meta++){
        const string& one_player = one_player_meta.key();
        if(one_player == "tie"){
            continue;
        }
        // 获胜玩家id
        int player_id = atoi(one_player.c_str());
        if(player_id < 0 or player_id > 1) throw runtime_error("player id json convert fail");

        // 玩家在当前Showdown节点能获得的收益
        //List<Object> tmp_payoffs =  (List<Object>)meta_payoffs.get(one_player);
        vector<double> player_payoff = one_player_meta.value();

        player_payoffs[atoi(one_player.c_str())] = player_payoff;
    }
    GameTreeNode::GameRound game_round = strToGameRound(std::move(round));
    return make_shared<ShowdownNode>(tie_payoffs,player_payoffs,game_round,pot,parent);
}
```