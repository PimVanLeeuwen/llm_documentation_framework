`recurrentSetDepth`: The function of `recurrentSetDepth` is to set the depth and calculate the subtree size for each node in a game tree.

**Code Description**: 
- The function `recurrentSetDepth` takes a shared pointer to a `GameTreeNode` and an integer `depth` as parameters.
- It sets the `depth` attribute of the current node to the provided `depth` value.
- If the node is of type `ACTION`, it dynamically casts the node to an `ActionNode`, initializes `subtree_size` to 1, and recursively calls `recurrentSetDepth` on each child node, incrementing the depth by 1. The subtree size is updated by summing the sizes of all child subtrees.
- If the node is of type `CHANCE`, it dynamically casts the node to a `ChanceNode`, initializes `subtree_size` to 1, and recursively calls `recurrentSetDepth` on the child node, incrementing the depth by 1. The subtree size is updated by multiplying the size of the child subtree by the number of cards in the `ChanceNode`.
- If the node is of any other type, it sets the `subtree_size` to 1.
- The function returns the `subtree_size` of the current node.\\
## Code: 
```
int GameTree::recurrentSetDepth(shared_ptr<GameTreeNode> node, int depth) {
    node->depth = depth;
    if(node->getType() == GameTreeNode::ACTION) {
        shared_ptr<ActionNode> actionNode = std::dynamic_pointer_cast<ActionNode>(node);
        int subtree_size = 1;
        for(shared_ptr<GameTreeNode> one_child:actionNode->getChildrens()){
            subtree_size += this->recurrentSetDepth(one_child,depth + 1);
        }
        node->subtree_size = subtree_size;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chanceNode = std::dynamic_pointer_cast<ChanceNode>(node);
        int subtree_size = 1;
        subtree_size += this->recurrentSetDepth(chanceNode->getChildren(),depth + 1) * chanceNode->getCards().size();
        node->subtree_size = subtree_size;
    }else{
        node->subtree_size = 1;
    }
    return node->subtree_size;
}
```