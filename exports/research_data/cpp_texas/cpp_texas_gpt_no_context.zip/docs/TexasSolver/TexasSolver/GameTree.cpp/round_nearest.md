`round_nearest`: The function of `round_nearest` is to round a given number to the nearest multiple of a specified rounding number.

**Code Description**: The `round_nearest` function takes two arguments: `number` (the number to be rounded) and `round_num` (the rounding precision). It first calculates the reciprocal of `round_num` and stores it back in `round_num`. Then, it multiplies the `number` by this reciprocal, rounds the result to the nearest integer, and finally divides by the reciprocal to obtain the number rounded to the nearest multiple of the original `round_num`.\\
## Code: 
```
double GameTree::round_nearest(double number, double round_num) {
    round_num = 1 / round_num;
    return round((number * round_num)) / round_num;

}
```