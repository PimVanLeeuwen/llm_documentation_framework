`getSettings`: The function of `getSettings` is to retrieve the appropriate `StreetSetting` for a given game round and player based on the provided `GameTreeBuildingSettings`.

**Code Description**: 
- The function `getSettings` takes four parameters: `int_round` (an integer representing the game round), `player` (an integer representing the player), and `gameTreeBuildingSettings` (an object containing settings for different game rounds and players).
- It first converts the integer `int_round` to a `GameTreeNode::GameRound` enum using the `intToGameRound` method.
- It checks if the `player` is either 0 or 1. If not, it throws a runtime error indicating an unknown player.
- Depending on the game round and player, it returns the corresponding `StreetSetting` from the `gameTreeBuildingSettings`:
  - If the round is `RIVER` and the player is 0, it returns `gameTreeBuildingSettings.river_ip`.
  - If the round is `TURN` and the player is 0, it returns `gameTreeBuildingSettings.turn_ip`.
  - If the round is `FLOP` and the player is 0, it returns `gameTreeBuildingSettings.flop_ip`.
  - If the round is `RIVER` and the player is 1, it returns `gameTreeBuildingSettings.river_oop`.
  - If the round is `TURN` and the player is 1, it returns `gameTreeBuildingSettings.turn_oop`.
  - If the round is `FLOP` and the player is 1, it returns `gameTreeBuildingSettings.flop_oop`.
- If none of the conditions match, it throws a runtime error indicating an unknown combination of player and round.\\
## Code: 
```
StreetSetting GameTree::getSettings(int int_round, int player,GameTreeBuildingSettings& gameTreeBuildingSettings){
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(int_round);
    if(!(player == 0 || player == 1)) throw runtime_error(tfm::format("player %s not known",player));
    if(round == GameTreeNode::GameRound::RIVER && player == 0) return gameTreeBuildingSettings.river_ip;
    else if(round == GameTreeNode::GameRound::TURN && player == 0) return gameTreeBuildingSettings.turn_ip;
    else if(round == GameTreeNode::GameRound::FLOP && player == 0) return gameTreeBuildingSettings.flop_ip;
    else if(round == GameTreeNode::GameRound::RIVER && player == 1) return gameTreeBuildingSettings.river_oop;
    else if(round == GameTreeNode::GameRound::TURN && player == 1) return gameTreeBuildingSettings.turn_oop;
    else if(round == GameTreeNode::GameRound::FLOP && player == 1) return gameTreeBuildingSettings.flop_oop;
    else throw new runtime_error(tfm::format("player %s and round not known",player));
}
```