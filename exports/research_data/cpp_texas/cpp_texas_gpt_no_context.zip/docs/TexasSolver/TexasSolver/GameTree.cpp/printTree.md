`printTree`: The function of `printTree` is to print the game tree up to a specified depth.

**Code Description**: 
The `printTree` function in the `GameTree` class is designed to print the structure of the game tree starting from the root node up to a specified depth. The function takes an integer parameter `depth` which determines how many levels of the tree should be printed. If `depth` is -1, the entire tree is printed. If `depth` is a positive integer, only that many levels of the tree are printed. If `depth` is less than -1 or equal to 0, the function throws a runtime error indicating that the depth can only be -1 or a positive integer. The function initializes a vector `prefix` and then calls a helper function `recurrentPrintTree` with the root node, the current level (0), and the specified depth.\\
## Code: 
```
void GameTree::printTree(int depth) {
    if(depth < -1 || depth == 0){
        throw runtime_error("depth can only be -1 or positive");
    }
    vector<string> prefix;
    this->recurrentPrintTree(this->root,0,depth);
}
```