`generateChanceNode`: The function of `generateChanceNode` is to create and initialize a `ChanceNode` in the game tree.

**Code Description**: This function takes in metadata (`meta`), a JSON object representing a child node (`child`), a string representing the game round (`round`), and a shared pointer to the parent node (`parent`). It extracts the pot value from the metadata and generates a child node by calling `recurrentGenerateTreeNode`. The game round string is converted to a `GameRound` enum. A new `ChanceNode` is created with the child node, game round, pot value, parent node, and the current deck of cards. The child node's parent is set to the newly created `ChanceNode`. Finally, the function returns the newly created `ChanceNode`.\\
## Code: 
```
shared_ptr<ChanceNode>
GameTree::generateChanceNode(json meta, const json& child, string round, shared_ptr<GameTreeNode> parent) {
    //节点上的下注额度
    double pot = meta["pot"];
    shared_ptr<GameTreeNode> one_child = recurrentGenerateTreeNode(child, nullptr);
    GameTreeNode::GameRound game_round = strToGameRound(std::move(round));
    shared_ptr<ChanceNode> chanceNode = make_shared<ChanceNode>(one_child,game_round,pot,parent,this->deck.getCards());
    shared_ptr<GameTreeNode> gameTreeNode = chanceNode->getChildren();
    gameTreeNode->setParent(chanceNode);
    return chanceNode;
}
```