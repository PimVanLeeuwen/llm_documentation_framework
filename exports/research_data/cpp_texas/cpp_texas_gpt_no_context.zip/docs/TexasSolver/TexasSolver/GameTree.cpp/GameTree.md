`GameTree`: The function of `GameTree` is to initialize a game tree for a poker game based on the provided parameters.

**Code Description**: The `GameTree` constructor initializes a game tree using the given parameters: `deck`, `oop_commit`, `ip_commit`, `current_round`, `raise_limit`, `small_blind`, `big_blind`, `stack`, `buildingSettings`, and `allin_threshold`. It first creates a `Rule` object with these parameters to define the rules of the game. The current player is set to 1, and the deck is assigned to the `deck` member variable. The current game round is determined by converting the `current_round` from the `Rule` object to a `GameTreeNode::GameRound` type. An `ActionNode` is then created with an empty list of game actions and child nodes, the current player, the game round, the pot size from the `Rule` object, and a null pointer for the parent node. The `__build` method is called to construct the game tree starting from this node, and the root of the game tree is set to this node.\\
## Code: 
```
GameTree::GameTree(Deck deck,
                   float oop_commit,
                   float ip_commit,
                   int current_round,
                   int raise_limit,
                   float small_blind,
                   float big_blind,
                   float stack,
                   GameTreeBuildingSettings buildingSettings,
                   float allin_threshold
){
    Rule rule = Rule(deck,oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,buildingSettings,allin_threshold);
    int current_player = 1;
    this->deck = deck;
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(rule.current_round);
    shared_ptr<ActionNode> node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(),current_player, round, (double) rule.get_pot(),
                                 nullptr);
    this->__build(node,rule);
    this->root = node;
}
```