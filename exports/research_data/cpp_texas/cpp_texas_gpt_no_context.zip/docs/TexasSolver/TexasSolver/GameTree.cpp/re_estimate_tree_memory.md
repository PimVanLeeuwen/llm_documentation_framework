`re_estimate_tree_memory`: The function of `re_estimate_tree_memory` is to recursively estimate the memory usage of a game tree starting from a given node.

**Code Description**: 
- The function `re_estimate_tree_memory` takes five parameters: a shared pointer to a `GameTreeNode` object (`node`), and four integers (`deck_num`, `p1range_num`, `p2range_num`, `num_current_deal`).
- It first checks the type of the node. If the node is of type `ACTION`, it casts the node to an `ActionNode` and retrieves its children and actions.
- It initializes a variable `retnum` to accumulate the memory estimate.
- It iterates over the children of the action node, recursively calling `re_estimate_tree_memory` for each child and adding the result to `retnum`.
- Depending on the player associated with the action node (`getPlayer()`), it adds to `retnum` a value based on `num_current_deal`, `p1range_num` or `p2range_num`, the number of children, and a constant factor.
- If the node is of type `CHANCE`, it casts the node to a `ChanceNode`, retrieves its single child, and recursively calls `re_estimate_tree_memory` with an updated `num_current_deal` multiplied by `deck_num`.
- If the node is neither `ACTION` nor `CHANCE`, it returns 0.
- The function returns the accumulated memory estimate (`retnum`).\\
## Code: 
```
long long GameTree::re_estimate_tree_memory(const shared_ptr<GameTreeNode>& node,int deck_num,int p1range_num,int p2range_num,int num_current_deal){
    if(node->getType() == GameTreeNode::ACTION){
        shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
        vector<shared_ptr<GameTreeNode>> childrens = action_node->getChildrens();
        vector<GameActions> actions = action_node->getActions();

        long long retnum = 0;
        for(std::size_t i = 0;i < childrens.size();i++){
            shared_ptr<GameTreeNode> one_child = childrens[i];
            retnum += re_estimate_tree_memory(one_child,deck_num, p1range_num, p2range_num, num_current_deal);
        }
        if(action_node->getPlayer() == 0){
            retnum += num_current_deal * p1range_num * (childrens.size() + 1) * 3;
        }else{
            retnum += num_current_deal * p2range_num * (childrens.size() + 1) * 3;
        }
        return retnum;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
        shared_ptr<GameTreeNode> children = chance_node->getChildren();
        return re_estimate_tree_memory(children,deck_num, p1range_num, p2range_num, num_current_deal * (deck_num));
    }
    return 0;
}
```