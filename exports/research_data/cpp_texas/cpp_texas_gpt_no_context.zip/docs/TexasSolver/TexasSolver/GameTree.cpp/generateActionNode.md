`generateActionNode`: The function of `generateActionNode` is to create and initialize an `ActionNode` object for a game tree based on the provided metadata, children's actions, and children's nodes.

**Code Description**: 
- The function `generateActionNode` takes in metadata (`meta`), a list of children's actions (`childrens_actions`), a list of children's nodes (`childrens_nodes`), the current round (`round`), and a parent node (`parent`).
- It first checks if the sizes of `childrens_actions` and `childrens_nodes` match. If not, it throws a runtime error.
- It validates the `round` parameter to ensure it is one of the valid game rounds: "preflop", "flop", "turn", or "river". If not, it throws a runtime error.
- It initializes two vectors: `actions` to store `GameActions` and `childrens` to store child nodes.
- It iterates over the `childrens_actions` and `childrens_nodes` to process each action and corresponding child node:
  - It determines the type of poker action (e.g., CHECK, FOLD, CALL, BET, RAISE) and the amount if applicable.
  - It creates a `GameActions` object for each action and adds it to the `actions` vector.
  - It generates a child node using `recurrentGenerateTreeNode` and adds it to the `childrens` vector.
- It retrieves the player and pot information from the `meta` JSON object.
- It validates that the sizes of `childrens` and `actions` match. If not, it throws a runtime error.
- It converts the `round` string to a `GameRound` enum.
- It creates an `ActionNode` object using the collected actions, children nodes, player, game round, pot, and parent.
- It sets the parent of each child node to the newly created `ActionNode`.
- Finally, it returns the created `ActionNode`.\\
## Code: 
```
shared_ptr<ActionNode>
GameTree::generateActionNode(json meta, vector<string> childrens_actions, vector<json> childrens_nodes, const string& round,
                             shared_ptr<GameTreeNode> parent) {
    if(childrens_actions.size() != childrens_nodes.size()){
        throw runtime_error(
                tfm::format(
                        "mismatch when generate ActionNode, childrens_action length %s children_nodes length %s",
                        childrens_actions.size(),
                        childrens_nodes.size()
                ));
    }

    if(! (   round == "preflop"
          || round == "flop"
          || round == "turn"
          || round == "river"
          )
            ){
        throw runtime_error(tfm::format("round %s not found",round));
    }

    vector<GameActions> actions;
    vector<shared_ptr<GameTreeNode>> childrens;

    // 遍历所有children actions 来生成GameAction 的list，用于初始化ActionNode
    for(std::size_t i = 0;i < childrens_actions.size();i++){
        string one_action = childrens_actions[i];
        json one_children_map = childrens_nodes[i];
        if(one_action.empty()) throw runtime_error("action is null");

        GameTreeNode::PokerActions action;
        double amount = -1;
        if(one_action == "check"){
            action = GameTreeNode::PokerActions::CHECK;
        }
        else if(one_action == "fold"){
            action = GameTreeNode::PokerActions::FOLD;
        }
        else if(one_action == "call"){
            action = GameTreeNode::PokerActions::CALL;
        }
        else{
            if(one_action.find("bet")  != string::npos){
                vector<string> action_sp = string_split(one_action,'_');
                if(action_sp.size() != 2)
                    throw runtime_error(tfm::format("bet action sp length %s",action_sp.size()));
                string action_str = action_sp[0];
                action = GameTreeNode::PokerActions::BET;
                if(!(action_str == "bet")) throw runtime_error(tfm::format("Action %s not found",action_str));
                amount = stod(action_sp[1]);

            }else if (one_action.find("raise") != string::npos){
                vector<string> action_sp = string_split(one_action,'_');
                if(action_sp.size() != 2)
                    throw runtime_error(tfm::format("raise action sp length %s",action_sp.size()));
                string action_str = action_sp[0];
                action = GameTreeNode::PokerActions::RAISE;
                if(!(action_str == "raise"))
                    throw runtime_error(tfm::format("Action %s not found",action_str));
                amount = stod(action_sp[1]);
            }else{
                throw runtime_error(tfm::format("%s action not found",one_action));
            }
        }
        shared_ptr<GameTreeNode> one_children_node = recurrentGenerateTreeNode(one_children_map,parent);
        childrens.push_back(one_children_node);

        GameActions game_action = GameActions(action,amount);
        actions.push_back(game_action);
    }
    int player = meta["player"];
    double pot = meta["pot"];
    if(childrens.size() != actions.size()){
        throw runtime_error(tfm::format("childrens length %s, actions length %s"
                ,childrens.size()
                ,actions.size()));
    }
    GameTreeNode::GameRound game_round = strToGameRound(round);
    shared_ptr<ActionNode> actionNode = make_shared<ActionNode>(actions,childrens,player,game_round,pot,parent);
    for(const shared_ptr<GameTreeNode>& one_node: childrens){
        one_node->setParent(std::dynamic_pointer_cast<GameTreeNode>(actionNode));
    }
    return actionNode;

}
```