`__build`: The function of `__build` is to construct different types of game tree nodes based on the node type.

**Code Description**: The `__build` function takes a shared pointer to a `GameTreeNode`, a `Rule` object, a string representing the last action, and two integers representing the number of check and raise times. It uses a switch statement to determine the type of the node and calls the appropriate build function for each node type. If the node is of type `ACTION`, it calls `buildAction` with the casted `ActionNode`, rule, last action, check times, and raise times. If the node is of type `CHANCE`, it calls `buildChance` with the casted `ChanceNode` and rule. For `SHOWDOWN` and `TERMINAL` node types, no additional actions are taken. If the node type is unknown, a runtime error is thrown. The function returns the modified node.\\
## Code: 
```
shared_ptr<GameTreeNode> GameTree::__build(shared_ptr<GameTreeNode> node, Rule rule, string last_action,
                                           int check_times, int raise_times) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            this->buildAction(std::dynamic_pointer_cast<ActionNode>(node),rule,last_action,check_times,raise_times);
            break;
        }case GameTreeNode::SHOWDOWN: {
            break;
        }case GameTreeNode::TERMINAL: {
            break;
        }case GameTreeNode::CHANCE: {
            this->buildChance(std::dynamic_pointer_cast<ChanceNode>(node),rule);
            break;
        }default:
            throw runtime_error("node type unknown");
    }
    return node;
}
```