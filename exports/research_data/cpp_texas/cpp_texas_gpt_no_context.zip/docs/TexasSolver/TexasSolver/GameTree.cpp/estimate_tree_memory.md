`estimate_tree_memory`: The function of `estimate_tree_memory` is to estimate the memory usage of a game tree based on the given parameters.

**Code Description**: This method, `estimate_tree_memory`, is a member of the `GameTree` class. It takes four integer parameters: `deck_num`, `p1range_num`, `p2range_num`, and `num_current_deal`. The function calls another method, `re_estimate_tree_memory`, passing the root of the game tree and the four parameters to it. The purpose of this function is to calculate and return the estimated memory usage of the game tree. The actual estimation logic is handled by the `re_estimate_tree_memory` method.\\
## Code: 
```
long long GameTree::estimate_tree_memory(int deck_num,int p1range_num,int p2range_num,int num_current_deal){
    return this->re_estimate_tree_memory(this->root,deck_num, p1range_num, p2range_num, num_current_deal);
}
```