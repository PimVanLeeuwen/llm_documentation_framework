`readAllBytes`: The function of `readAllBytes` is to open a file specified by the given file path and return an input file stream object associated with that file.

**Code Description**: The `readAllBytes` function takes a single parameter, `filePath`, which is a string representing the path to a file. It creates an `ifstream` object named `input_file` and initializes it with the provided `filePath`. This `ifstream` object is then returned, allowing the caller to read from the specified file. Note that this function does not handle any errors that might occur during the file opening process, such as the file not existing or lacking read permissions.\\
## Code: 
```
ifstream GameTree::readAllBytes(const string& filePath) {
    ifstream input_file(filePath);
    return input_file;
}
```