`strToGameRound`: The function of `strToGameRound` is to convert a string representing a poker game round into its corresponding `GameTreeNode::GameRound` enumeration value.

**Code Description**: 
The `strToGameRound` function takes a string input `round` and maps it to the corresponding `GameTreeNode::GameRound` enumeration value. The function checks the input string against predefined poker game rounds: "preflop", "flop", "turn", and "river". If the input string matches one of these rounds, the function assigns the corresponding enumeration value (`PREFLOP`, `FLOP`, `TURN`, `RIVER`) to the variable `game_round`. If the input string does not match any of these predefined rounds, the function throws a runtime error with a message indicating that the game round was not found. The function then returns the `game_round` enumeration value.\\
## Code: 
```
GameTreeNode::GameRound GameTree::strToGameRound(const string& round) {
    GameTreeNode::GameRound game_round;
    if(round == "preflop"){
        game_round = GameTreeNode::GameRound::PREFLOP;
    }
    else if (round == "flop"){
        game_round = GameTreeNode::GameRound::FLOP;
    }
    else if(round == "turn"){
        game_round = GameTreeNode::GameRound::TURN;
    }
    else if(round == "river"){
        game_round = GameTreeNode::GameRound::RIVER;
    }
    else{
        throw runtime_error(tfm::format("game round not found: %s",round));
    }
    return game_round;
}
```