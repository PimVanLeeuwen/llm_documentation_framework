`getRoot`: The function of `getRoot` is to return the root node of the game tree.

**Code Description**: This method, `getRoot`, is a member function of the `GameTree` class. It returns a `shared_ptr` to the root node of the game tree, which is stored in the private member variable `root` of the `GameTree` instance. This allows other parts of the program to access the root node of the game tree safely, leveraging the reference counting mechanism of `shared_ptr` to manage the node's lifetime.\\
## Code: 
```
shared_ptr<GameTreeNode> GameTree::getRoot() {
    return this->root;
}
```