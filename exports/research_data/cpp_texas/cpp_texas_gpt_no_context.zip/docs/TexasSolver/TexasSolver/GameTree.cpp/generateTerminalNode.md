`generateTerminalNode`: The function of `generateTerminalNode` is to create and return a shared pointer to a `TerminalNode` object, initialized with the provided metadata, round information, and parent node.

**Code Description**: This function takes three parameters: a JSON object `meta` containing metadata, a string `round` representing the game round, and a shared pointer to a `GameTreeNode` object `parent`. It extracts the player payoff list from the `meta` JSON object and copies it into a vector `player_payoff`. It also retrieves the pot value and the player index from the `meta` JSON object. The function then converts the `round` string to a `GameRound` enum using the `strToGameRound` method. Finally, it creates and returns a shared pointer to a `TerminalNode` object, initialized with the player payoff vector, player index, game round, pot value, and parent node.\\
## Code: 
```
shared_ptr<TerminalNode> GameTree::generateTerminalNode(json meta, string round, shared_ptr<GameTreeNode> parent) {
    vector<double> player_payoff_list = meta["payoff"];
    vector<double> player_payoff(player_payoff_list.size());
    for(std::size_t one_player = 0;one_player < player_payoff_list.size();one_player ++){

        double tmp_payoff = player_payoff_list[one_player];
        player_payoff[one_player] = tmp_payoff;
    }

    //节点上的下注额度
    double pot = meta["pot"];

    GameTreeNode::GameRound game_round = this->strToGameRound(std::move(round));
    // 多人游戏的时候winner就不等于当前节点的玩家了，这里要注意
    int player = meta["player"];

    return make_shared<TerminalNode>(player_payoff,player,game_round,pot,parent);
}
```