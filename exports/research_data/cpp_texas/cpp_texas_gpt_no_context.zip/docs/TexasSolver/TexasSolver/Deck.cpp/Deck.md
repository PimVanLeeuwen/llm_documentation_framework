`Deck`: The function of `Deck` is to initialize a deck of cards with given ranks and suits.

**Code Description**: 
The `Deck` constructor takes two vectors of strings as input parameters: `ranks` and `suits`. It initializes the `ranks` and `suits` member variables with these input vectors. The constructor then creates a deck of cards by combining each rank with each suit. For each combination, it forms a string representing the card (e.g., "Ace of Spades") and adds this string to the `cards_str` vector. Additionally, it creates a `Card` object with the card string and a unique card number, and adds this object to the `cards` vector. The card number is incremented sequentially for each new card.\\
## Code: 
```
Deck::Deck(const vector<string>& ranks, const vector<string>& suits) {
    this->ranks = ranks;
    this->suits = suits;
    int card_num = 0;
    for(const string& one_rank : ranks){
        for(const string& one_suit: suits){
            string one_card = one_rank + one_suit;
            cards_str.push_back(one_card);
            cards.emplace_back(one_card,card_num);
            card_num += 1;
        }
    }
}
```