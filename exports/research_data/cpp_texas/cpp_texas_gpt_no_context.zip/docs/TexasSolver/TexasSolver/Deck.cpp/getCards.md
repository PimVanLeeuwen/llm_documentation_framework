`getCards`: The function of `getCards` is to return a reference to the `cards` vector stored in the `Deck` object.

**Code Description**: This method, `getCards`, is a member function of the `Deck` class. It returns a reference to the `cards` vector, which is a private member of the `Deck` class. This allows external code to access and manipulate the `cards` vector directly. The use of a reference ensures that the actual `cards` vector is returned, not a copy, which can be more efficient for performance.\\
## Code: 
```
vector<Card>& Deck::getCards() {
    return this->cards;
}
```