`boardInts2long`: The function of `boardInts2long` is to convert a vector of card indices into a single 64-bit integer representation.

**Code Description**: 
- The function `boardInts2long` takes a constant reference to a vector of integers, `board`, as its parameter.
- It first checks if the size of the `board` vector is between 1 and 7 (inclusive). If not, it throws a runtime error with a message indicating the incorrect length.
- It initializes a 64-bit unsigned integer `board_long` to 0.
- The function then iterates over each integer in the `board` vector.
  - For each integer `one_card`, it checks if the value is between 0 and 51 (inclusive). If not, it throws a runtime error with a message indicating the card ID is not found.
  - It then sets the bit at the position `one_card` in `board_long` by performing a bitwise OR operation with `1` shifted left by `one_card` positions.
- Finally, the function returns the resulting `board_long` value, which is a 64-bit integer representing the set of card indices.\\
## Code: 
```
uint64_t Card::boardInts2long(const vector<int>& board){
    if(board.size() < 1 || board.size() > 7){
        throw runtime_error(tfm::format("Card length incorrect: %s",board.size()));
    }
    uint64_t board_long = 0;
    for(int one_card: board){
        // 这里hard code了一副扑克牌是52张
        if(one_card < 0 || one_card >= 52){
            throw runtime_error(tfm::format("Card with id %s not found",one_card));
        }
        // uint64_7 的range 在0 ~ + 2^ 64之间,所以不用太担心溢出问题
        board_long += ((uint64_t)(1) << one_card);
    }
    return board_long;
}
```