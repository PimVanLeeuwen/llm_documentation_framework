`boardCard2long`: The function of `boardCard2long` is to convert a `Card` object into a 64-bit unsigned integer representation.

**Code Description**: The `boardCard2long` function takes a reference to a `Card` object as its parameter. It calls the `getCardInt` method on the `Card` object to retrieve an integer representation of the card. This integer is then passed to the `Card::boardInt2long` function, which converts the integer into a 64-bit unsigned integer. The resulting 64-bit unsigned integer is returned by the `boardCard2long` function.\\
## Code: 
```
uint64_t Card::boardCard2long(Card& card){
    return Card::boardInt2long(card.getCardInt());
}
```