`toString`: The function of `toString` is to return the string representation of the card.

**Code Description**: The `toString` method is a member function of the `Card` class. It returns the value of the `card` attribute, which is a string representing the card. This method allows other parts of the program to obtain the string representation of the card object.\\
## Code: 
```
string Card::toString() {
    return this->card;
}
```