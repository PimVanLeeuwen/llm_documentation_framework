`getCardInt`: The function of `getCardInt` is to return the integer value associated with a card object.

**Code Description**: This method, `getCardInt`, is a member function of the `Card` class. It returns the value of the private member variable `card_int` of the `Card` object on which it is called. The `this` pointer is used to access the `card_int` variable of the current instance of the `Card` class.\\
## Code: 
```
int Card::getCardInt() {
    return this->card_int;
}
```