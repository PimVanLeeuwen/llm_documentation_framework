`boardCards2long`: The function of `boardCards2long` is to convert a vector of card strings into a 64-bit unsigned integer representation.

**Code Description**: This function takes a vector of strings, where each string represents a card. It first creates a vector of `Card` objects of the same size as the input vector. Then, it iterates over the input vector, converting each string into a `Card` object and storing it in the corresponding position in the `cards_objs` vector. Finally, it calls another `boardCards2long` function that takes a vector of `Card` objects and returns a 64-bit unsigned integer representation of the board cards.\\
## Code: 
```
uint64_t Card::boardCards2long(vector<string> cards) {
    vector<Card> cards_objs(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_objs[i] = Card(cards[i]);
    }
    return Card::boardCards2long(cards_objs);
}
```