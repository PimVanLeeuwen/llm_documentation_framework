`intCard2Str`: The function of `intCard2Str` is to convert an integer representation of a card into its string representation.

**Code Description**: The `intCard2Str` function takes an integer `card` as input, which represents a playing card. It calculates the rank of the card by dividing the integer by 4 and adding 2. The suit of the card is determined by subtracting `(rank-2)*4` from the original integer. The function then converts the rank and suit into their respective string representations using the `rankToString` and `suitToString` methods of the `Card` class, and concatenates these strings to form the final string representation of the card. The resulting string is returned.\\
## Code: 
```
string Card::intCard2Str(int card){
    int rank = card / 4 + 2;
    int suit = card - (rank-2)*4;
    return Card::rankToString(rank) + Card::suitToString(suit);
}
```