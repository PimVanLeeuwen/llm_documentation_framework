`empty`: The function of `empty` is to check if the `card` attribute of the `Card` object is set to the string "empty".

**Code Description**: The `empty` function is a member of the `Card` class. It checks if the `card` attribute of the current `Card` object (referred to by `this`) is equal to the string "empty". If it is, the function returns `true`; otherwise, it returns `false`.\\
## Code: 
```
bool Card::empty(){
    if(this->card == "empty")return true;
    else return false;
}
```