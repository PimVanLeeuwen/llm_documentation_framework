`rankToInt`: The function of `rankToInt` is to convert a card rank represented by a character into its corresponding integer value.

**Code Description**: The `rankToInt` function takes a single character `rank` as input and uses a `switch` statement to map the character to its corresponding integer value. The characters '2' to '9' are mapped to their respective integer values (2 to 9). The character 'T' (representing 10) is mapped to 10, 'J' (Jack) to 11, 'Q' (Queen) to 12, 'K' (King) to 13, and 'A' (Ace) to 14. If the input character does not match any of these cases, the function returns a default value of 2.\\
## Code: 
```
int Card::rankToInt(char rank)
{
    switch(rank)
    {
        case '2': return 2;
        case '3': return 3;
        case '4': return 4;
        case '5': return 5;
        case '6': return 6;
        case '7': return 7;
        case '8': return 8;
        case '9': return 9;
        case 'T': return 10;
        case 'J': return 11;
        case 'Q': return 12;
        case 'K': return 13;
        case 'A': return 14;
        default: return 2;
    }
}
```