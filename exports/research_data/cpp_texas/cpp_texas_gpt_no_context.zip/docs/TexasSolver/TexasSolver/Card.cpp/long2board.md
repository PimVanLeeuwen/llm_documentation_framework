`long2board`: The function of `long2board` is to convert a 64-bit integer representation of a card board into a vector of integers representing the positions of the cards.

**Code Description**: The `long2board` function takes a 64-bit integer (`board_long`) as input, which represents a board of cards where each bit corresponds to a card position (0-51). The function iterates through each bit of the integer, checking if the least significant bit is set to 1. If it is, the current position (index) is added to the `board` vector. The integer is then right-shifted by one bit to check the next position. This process continues for all 52 possible card positions. After the loop, the function checks if the size of the `board` vector is between 1 and 7 (inclusive). If not, it throws a runtime error indicating an incorrect board length. Finally, the function returns the `board` vector containing the positions of the cards.\\
## Code: 
```
vector<int> Card::long2board(uint64_t board_long) {
    vector<int> board;
    board.reserve(7);
    for(int i = 0;i < 52;i ++){
        // 看二进制最后一位是否为1
        if((board_long & 1) == 1){
            board.push_back(i);
        }
        board_long = board_long >> 1;
    }
    if (board.size() < 1 || board.size() > 7){
        throw runtime_error(tfm::format("board length not correct, board length %s",board.size()));
    }
    return board;
}
```