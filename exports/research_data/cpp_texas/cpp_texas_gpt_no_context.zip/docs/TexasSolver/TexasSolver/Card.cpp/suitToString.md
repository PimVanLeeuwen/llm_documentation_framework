`suitToString`: The function of `suitToString` is to convert an integer representing a card suit into its corresponding string abbreviation.

**Code Description**: The `suitToString` function takes an integer `suit` as input and returns a string representing the suit of a card. The function uses a switch statement to map the integer values 0, 1, 2, and 3 to the strings "c" (clubs), "d" (diamonds), "h" (hearts), and "s" (spades), respectively. If the input integer does not match any of these cases, the function defaults to returning "c" (clubs).\\
## Code: 
```
string Card::suitToString(int suit)
{
    switch(suit)
    {
        case 0: return "c";
        case 1: return "d";
        case 2: return "h";
        case 3: return "s";
        default: return "c";
    }
}
```