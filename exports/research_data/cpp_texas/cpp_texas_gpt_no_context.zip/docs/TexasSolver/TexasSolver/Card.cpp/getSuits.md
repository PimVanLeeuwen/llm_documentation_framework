`getSuits`: The function of `getSuits` is to return a list of card suits.

**Code Description**: The `getSuits` function is a member of the `Card` class. When called, it returns a vector containing four strings, each representing a suit in a standard deck of cards: "c" for clubs, "d" for diamonds, "h" for hearts, and "s" for spades.\\
## Code: 
```
vector<string> Card::getSuits(){
    return {"c","d","h","s"};
}
```