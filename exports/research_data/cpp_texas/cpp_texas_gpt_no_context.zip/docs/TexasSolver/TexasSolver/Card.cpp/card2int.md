`card2int`: The function of `card2int` is to convert a `Card` object to an integer representation.

**Code Description**: The `card2int` function takes a `Card` object as an argument and returns an integer. It does this by calling the `getCard` method on the `Card` object to retrieve its string representation, and then passing this string to the `strCard2int` function, which converts the string to an integer.\\
## Code: 
```
int Card::card2int(Card card) {
    return strCard2int(card.getCard());
}
```