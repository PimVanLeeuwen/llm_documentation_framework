`suitToInt`: The function of `suitToInt` is to convert a card suit character to its corresponding integer value.

**Code Description**: The `suitToInt` function takes a single character representing a card suit ('c' for clubs, 'd' for diamonds, 'h' for hearts, 's' for spades) and returns an integer value associated with that suit. The mapping is as follows: 'c' to 0, 'd' to 1, 'h' to 2, and 's' to 3. If the input character does not match any of these suits, the function defaults to returning 0.\\
## Code: 
```
int Card::suitToInt(char suit)
{
    switch(suit)
    {
        case 'c': return 0; // 梅花
        case 'd': return 1; // 方块
        case 'h': return 2; // 红桃
        case 's': return 3; // 黑桃
        default: return 0;
    }
}
```