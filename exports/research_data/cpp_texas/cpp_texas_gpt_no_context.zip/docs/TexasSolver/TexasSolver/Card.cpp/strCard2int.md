`strCard2int`: The function of `strCard2int` is to convert a string representation of a card into an integer value.

**Code Description**: 
- The function `strCard2int` takes a string `card` as input, which is expected to be a two-character string representing a playing card (e.g., "5H" for the 5 of Hearts).
- It extracts the rank (first character) and suit (second character) from the string.
- It checks if the length of the input string is exactly 2 characters. If not, it throws a runtime error with a formatted message indicating that the card was not found.
- It converts the rank to an integer using the `rankToInt` function and adjusts it by subtracting 2.
- It converts the suit to an integer using the `suitToInt` function.
- Finally, it calculates and returns the integer value of the card using the formula `(rankToInt(rank) - 2) * 4 + suitToInt(suit)`.\\
## Code: 
```
int Card::strCard2int(string card) {
    char rank = card.at(0);
    char suit = card.at(1);
    if(card.length() != 2){
        throw runtime_error( tfm::format("card %s not found",card));
    }
    return (rankToInt(rank) - 2) * 4 + suitToInt(suit);
}
```