`boardCards2html`: The function of `boardCards2html` is to convert a vector of `Card` objects into an HTML formatted string.

**Code Description**: 
- The function `boardCards2html` takes a vector of `Card` objects as input.
- It initializes an empty `QString` named `ret_html` to accumulate the HTML formatted string.
- The function iterates over each `Card` object in the input vector using a range-based for loop.
- For each `Card` object, it checks if the card is empty using the `empty()` method. If the card is empty, it skips to the next iteration.
- If the card is not empty, it converts the card to a formatted HTML string using the `toFormattedHtml()` method and appends this string to `ret_html`.
- After processing all the cards, the function returns the accumulated HTML formatted string `ret_html`.\\
## Code: 
```
QString Card::boardCards2html(vector<Card>& cards){
    QString ret_html = "";
    for(auto one_card:cards){
        if(one_card.empty())continue;
        ret_html += one_card.toFormattedHtml();
    }
    return ret_html;
}
```