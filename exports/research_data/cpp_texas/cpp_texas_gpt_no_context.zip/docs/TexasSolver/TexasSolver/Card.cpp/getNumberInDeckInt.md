`getNumberInDeckInt`: The function of `getNumberInDeckInt` is to return the card's number in the deck.

**Code Description**: This method, `getNumberInDeckInt`, is a member of the `Card` class. It checks if the `card_number_in_deck` attribute of the `Card` object is set to -1. If it is, the method throws a `runtime_error` with the message "card number in deck cannot be -1". If the `card_number_in_deck` is not -1, the method returns the value of `card_number_in_deck`. This ensures that the card number in the deck is always a valid value when accessed.\\
## Code: 
```
int Card::getNumberInDeckInt(){
    if(this->card_number_in_deck == -1)throw runtime_error("card number in deck cannot be -1");
    return this->card_number_in_deck;
}
```