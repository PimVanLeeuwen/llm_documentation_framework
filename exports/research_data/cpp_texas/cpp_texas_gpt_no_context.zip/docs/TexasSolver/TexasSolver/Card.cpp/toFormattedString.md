`toFormattedString`: The function of `toFormattedString` is to convert a card string representation into a formatted string with suit symbols.

**Code Description**: 
The `toFormattedString` method in the `Card` class converts the card's string representation into a formatted string that includes the corresponding suit symbols. It uses the `QString` class to handle the string manipulation. The method performs the following steps:
1. Converts the card's string representation from a standard string to a `QString`.
2. Replaces the character 'c' with the club symbol (♣️).
3. Replaces the character 'd' with the diamond symbol (♦️).
4. Replaces the character 'h' with the heart symbol (♥️).
5. Replaces the character 's' with the spade symbol (♠️).
6. Converts the modified `QString` back to a standard string and returns it.\\
## Code: 
```
string Card::toFormattedString() {
    QString qString = QString::fromStdString(this->card);
    qString = qString.replace("c", "♣️");
    qString = qString.replace("d", "♦️");
    qString = qString.replace("h", "♥️");
    qString = qString.replace("s", "♠️");
    return qString.toStdString();
}
```