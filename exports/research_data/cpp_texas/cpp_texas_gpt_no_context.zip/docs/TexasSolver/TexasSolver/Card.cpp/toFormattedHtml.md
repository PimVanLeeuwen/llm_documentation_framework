`toFormattedHtml`: The function of `toFormattedHtml` is to convert a card string into an HTML formatted string with appropriate colors and symbols for card suits.

**Code Description**: The `toFormattedHtml` function takes the `card` string from the `Card` object and converts it into a `QString`. It then checks for the presence of specific characters representing card suits ('c' for clubs, 'd' for diamonds, 'h' for hearts, and 's' for spades). Depending on the suit character found, it replaces the character with an HTML span element containing the corresponding Unicode symbol for the suit, styled with the appropriate color (black for clubs and spades, red for diamonds and hearts). The function returns the resulting HTML formatted `QString`.\\
## Code: 
```
QString Card::toFormattedHtml() {
    QString qString = QString::fromStdString(this->card);
    if(qString.contains("c"))
        qString = qString.replace("c", QString::fromLocal8Bit("<span style=\"color:black;\">&#9827;<\/span>"));
    else if(qString.contains("d"))
        qString = qString.replace("d", QString::fromLocal8Bit("<span style=\"color:red;\">&#9830;<\/span>"));
    else if(qString.contains("h"))
        qString = qString.replace("h", QString::fromLocal8Bit("<span style=\"color:red;\">&#9829;<\/span>"));
    else if(qString.contains("s"))
        qString = qString.replace("s", QString::fromLocal8Bit("<span style=\"color:black;\">&#9824;<\/span>"));
    return qString;
}
```