`Card`: The function of `Card` is to initialize a card object with a given string representation of the card.

**Code Description**: 
- The constructor `Card::Card(string card)` initializes a `Card` object.
- It takes a string parameter `card` which represents the card.
- The constructor assigns the input string `card` to the member variable `this->card`.
- It then converts this string representation to an integer using the static method `Card::strCard2int` and assigns the result to the member variable `this->card_int`.
- Finally, it initializes the member variable `this->card_number_in_deck` to `-1`.\\
## Code: 
```
Card::Card(string card){
    this->card = card;
    this->card_int = Card::strCard2int(this->card);
    this->card_number_in_deck = -1;
}
```