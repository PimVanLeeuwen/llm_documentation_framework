`boardInt2long`: The function of `boardInt2long` is to convert a given board index (representing a card in a deck) into a unique 64-bit integer representation.

**Code Description**: 
- The function `boardInt2long` takes an integer `board` as input, which represents the index of a card in a standard deck of 52 cards.
- It first checks if the input `board` is within the valid range (0 to 51). If the input is out of this range, it throws a runtime error with a message indicating that the card with the given id was not found.
- If the input is valid, the function returns a 64-bit unsigned integer where the bit at the position corresponding to the `board` index is set to 1. This is achieved by left-shifting the number 1 by `board` positions.
- The use of `uint64_t` ensures that the function can handle the bit manipulation without overflow issues, as it supports values from 0 to 2^64 - 1.\\
## Code: 
```
uint64_t Card::boardInt2long(int board){
    // 这里hard code了一副扑克牌是52张
    if(board < 0 || board >= 52){
        throw runtime_error(tfm::format("Card with id %s not found",board));
    }
    // uint64_7 的range 在0 ~ + 2^ 64之间,所以不用太担心溢出问题
    return ((uint64_t)(1) << board);
}
```