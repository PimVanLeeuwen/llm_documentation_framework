`rankToString`: The function of `rankToString` is to convert a given integer rank of a playing card to its corresponding string representation.

**Code Description**: The `rankToString` function takes an integer `rank` as input and uses a `switch` statement to map the integer to its corresponding string representation. The mapping is as follows:
- 2 to "2"
- 3 to "3"
- 4 to "4"
- 5 to "5"
- 6 to "6"
- 7 to "7"
- 8 to "8"
- 9 to "9"
- 10 to "T" (for Ten)
- 11 to "J" (for Jack)
- 12 to "Q" (for Queen)
- 13 to "K" (for King)
- 14 to "A" (for Ace)

If the input rank does not match any of the specified cases, the function defaults to returning "2".\\
## Code: 
```
string Card::rankToString(int rank)
{
    switch(rank)
    {
        case 2: return "2";
        case 3: return "3";
        case 4: return "4";
        case 5: return "5";
        case 6: return "6";
        case 7: return "7";
        case 8: return "8";
        case 9: return "9";
        case 10: return "T";
        case 11: return "J";
        case 12: return "Q";
        case 13: return "K";
        case 14: return "A";
        default: return "2";
    }
}
```