`long2boardCards`: The function of `long2boardCards` is to convert a 64-bit integer representation of a board into a vector of `Card` objects.

**Code Description**: This function takes a 64-bit integer (`board_long`) as input, which represents a board in a card game. It first converts this integer into a vector of integers using the `long2board` function. Each integer in this vector represents a card. The function then converts these integers into `Card` objects using the `intCard2Str` function and stores them in a vector called `board_cards`. It checks if the number of cards is between 1 and 7, throwing a runtime error if the number of cards is outside this range. Finally, it copies the `board_cards` vector into another vector `retval` and returns it.\\
## Code: 
```
vector<Card> Card::long2boardCards(uint64_t board_long){
        vector<int> board = long2board(board_long);
        vector<Card> board_cards(board.size());
        for(std::size_t i = 0;i < board.size();i ++){
            int one_board = board[i];
            board_cards[i] = Card(intCard2Str(one_board));
        }
        if (board_cards.size() < 1 || board_cards.size() > 7){
            throw runtime_error(tfm::format("board length not correct, board length %s",board_cards.size()));
        }
        vector<Card> retval(board_cards.size());
        for(std::size_t i = 0;i < board_cards.size();i ++){
            retval[i] = board_cards[i];
        }
        return retval;
}
```