`getInitialReachProb`: The function of `getInitialReachProb` is to calculate the initial reach probabilities for a player's private cards given an initial board state.

**Code Description**: 
- The function `getInitialReachProb` takes two parameters: `player` (an integer representing the player index) and `initialboard` (a 64-bit unsigned integer representing the initial board state).
- It retrieves the number of private cards the specified player has and initializes a vector `probs` of floats with the same length.
- The function then iterates over each private card of the player.
- For each private card, it checks if the card's hands intersect with the initial board using the `Card::boardsHasIntercept` method.
- If there is an intersection, the probability for that card is set to 0.
- If there is no intersection, the probability is set to the weight of the private card.
- Finally, the function returns the vector `probs` containing the initial reach probabilities for the player's private cards.\\
## Code: 
```
vector<float> PrivateCardsManager::getInitialReachProb(int player, uint64_t initialboard) {
    int cards_len =  this->private_cards[player].size();
    vector<float> probs = vector<float>(cards_len);
    for(int i = 0;i < cards_len;i ++){
        PrivateCards pc = this->private_cards[player][i];
        if(Card::boardsHasIntercept(initialboard,Card::boardInts2long(pc.get_hands()))) {
            probs[i] = 0;
        }else{
            probs[i] = this->private_cards[player][i].weight;
        }
    }
    return probs;
}
```