`rowCount`: The function of `rowCount` is to return the number of rows in the table model.

**Code Description**: This method, `rowCount`, is a member of the `TableStrategyModel` class. It takes a constant reference to a `QModelIndex` object named `parent` as its parameter, although this parameter is not used within the function. The method returns an integer representing the number of rows in the table model. It does this by accessing the `qSolverJob` member of the class, calling its `get_solver()` method to retrieve a solver object, then calling `get_deck()` on the solver object to get a deck object, and finally calling `getRanks()` on the deck object to obtain a list of ranks. The size of this list, which represents the number of ranks in the deck, is returned as the row count.\\
## Code: 
```
int TableStrategyModel::rowCount(const QModelIndex &parent) const
{
    return this->qSolverJob->get_solver()->get_deck()->getRanks().size();
}
```