`compairRanks`: The function of `compairRanks` is to compare two integer ranks and determine their relative order.

**Code Description**: The `compairRanks` function takes two integer parameters, `rank_former` and `rank_latter`, representing the ranks to be compared. It returns a `CompairResult` enum value indicating the comparison result:
- If `rank_former` is less than `rank_latter`, it returns `CompairResult::LARGER`, indicating that the former rank is considered larger.
- If `rank_former` is greater than `rank_latter`, it returns `CompairResult::SMALLER`, indicating that the former rank is considered smaller.
- If `rank_former` is equal to `rank_latter`, it returns `CompairResult::EQUAL`, indicating that both ranks are equal.\\
## Code: 
```
Compairer::CompairResult Dic5Compairer::compairRanks(int rank_former, int rank_latter) {
    if (rank_former < rank_latter) {
        // rank更小的牌更大，0是同花顺
        return CompairResult::LARGER;
    } else if (rank_former > rank_latter) {
        return CompairResult::SMALLER;
    } else {
        // rank_former == rank_latter
        return CompairResult::EQUAL;
    }
}
```