`setBoardAt`: The function of `setBoardAt` is to set a specific value in a 2D grid at the given row and column indices.

**Code Description**: The `setBoardAt` method in the `BoardSelectorTableModel` class takes three parameters: two integers `i` and `j`, and a float `value`. It first checks if the row index `i` is within the valid range of the `suitlist` size and if the column index `j` is within the valid range of the `ranklist` size. If either index is out of bounds, it logs an error message indicating the invalid index. If both indices are valid, it sets the specified `value` at the position `[i][j]` in the `grids_float` 2D array.\\
## Code: 
```
void BoardSelectorTableModel::setBoardAt(int i, int j,float value){
    if(i < 0 || i >= this->suitlist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::setBoardAt i not valid: " << i;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::setBoardAt j not valid: " << j;
    }
    else{
        this->grids_float[i][j] = value;
    }
}
```