`getGameTree`: The function of `getGameTree` is to return a constant reference to the `game_tree` member variable of the `PokerSolver` class.

**Code Description**: This method, `getGameTree`, is a member function of the `PokerSolver` class. It returns a constant reference to a `shared_ptr` that points to a `GameTree` object. The `const` at the end of the method signature indicates that this function does not modify any member variables of the `PokerSolver` class. This ensures that the `game_tree` can be accessed without altering its state.\\
## Code: 
```
const shared_ptr<GameTree> &PokerSolver::getGameTree() const {
    return game_tree;
}
```