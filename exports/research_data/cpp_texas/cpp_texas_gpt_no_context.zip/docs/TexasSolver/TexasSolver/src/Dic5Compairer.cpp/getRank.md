`getRank`: The function of `getRank` is to calculate and return the rank of a given set of cards.

**Code Description**: This method takes a vector of `Card` objects as input and converts each `Card` object to its integer representation using the `getCardInt` method. It stores these integer values in a new vector called `cards_int`. Finally, it calls another `getRank` method (presumably overloaded) that takes a vector of integers and returns the rank of the cards.\\
## Code: 
```
int Dic5Compairer::getRank(vector<Card> cards) {
    vector<int> cards_int(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_int[i] = cards[i].getCardInt();
    }
    return this->getRank(cards_int);
}
```