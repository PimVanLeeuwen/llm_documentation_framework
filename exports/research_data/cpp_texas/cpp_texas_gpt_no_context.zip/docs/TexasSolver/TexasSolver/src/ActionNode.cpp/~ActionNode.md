`~ActionNode`: The function of `~ActionNode` is to serve as the destructor for the `ActionNode` class.

**Code Description**: The `~ActionNode` destructor is called when an `ActionNode` object is destroyed. It currently contains a commented-out line that would print "ActionNode destroyed" to the console if it were uncommented. This destructor ensures that any cleanup required when an `ActionNode` object is no longer needed is performed, although in its current state, it does not perform any specific actions.\\
## Code: 
```
ActionNode::~ActionNode(){
    //cout << "ActionNode destroyed" << endl;
}
```