`setRelativeProbs`: The function of `setRelativeProbs` is to calculate and set the relative probabilities of private cards for each player based on their weights and the absence of conflicts with the initial board and other players' cards.

**Code Description**: 
- The function `setRelativeProbs` iterates through each player's private cards.
- For each player's card, it calculates the sum of the weights of the opponent's cards that do not conflict with the initial board or the player's card.
- It then sets the relative probability of the player's card as the product of its weight and the sum of the valid opponent card weights.
- After calculating the relative probabilities for all cards of a player, it normalizes these probabilities by dividing each by the total sum of the player's relative probabilities.
- The function assumes there are only two players and uses the `Card::boardInts2long` and `Card::boardsHasIntercept` methods to handle card representations and conflict checks.\\
## Code: 
```
void PrivateCardsManager::setRelativeProbs() {
    int players = this->private_cards.size();
    for(int player_id = 0; player_id < players;player_id ++){
        // TODO 这里只考虑了两个玩家的情况
        int oppo = 1 - player_id;
        float player_prob_sum = 0;

        for(std::size_t i = 0;i < this->private_cards[player_id].size();i ++) {
            float oppo_prob_sum = 0;
            PrivateCards* player_card = &this->private_cards[player_id][i];
            uint64_t player_long = Card::boardInts2long(player_card->get_hands());

            //
            if (Card::boardsHasIntercept(player_long,this->initialboard)){
                continue;
            }

            for (auto oppo_card : this->private_cards[oppo]) {
                uint64_t oppo_long = Card::boardInts2long(oppo_card.get_hands());
                if (Card::boardsHasIntercept(oppo_long,this->initialboard)
                    || Card::boardsHasIntercept(oppo_long,player_long)
                        ){
                    continue;
                }
                oppo_prob_sum += oppo_card.weight;

            }
            player_card->relative_prob = oppo_prob_sum * player_card->weight;
            player_prob_sum += player_card->relative_prob;
        }
        for(std::size_t i = 0;i < this->private_cards[player_id].size();i ++) {
            this->private_cards[player_id][i].relative_prob = this->private_cards[player_id][i].relative_prob / player_prob_sum;
            //player_card.relative_prob = player_card.relative_prob / player_prob_sum;
        }

    }
}
```