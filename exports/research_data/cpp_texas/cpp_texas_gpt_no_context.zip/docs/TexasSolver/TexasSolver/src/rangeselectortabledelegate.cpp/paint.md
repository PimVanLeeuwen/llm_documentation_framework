`paint`: The function of `paint` is to render the visual representation of a cell in a table view, with specific styling based on the cell's position and data.

**Code Description**: 
- The `paint` function begins by saving the current state of the `QPainter` object to ensure any changes can be reverted.
- It initializes the style options for the item using `initStyleOption`.
- It defines a rectangle representing the cell's area and fills it with a gray brush. If the cell is on the diagonal (where the row and column indices are equal), it uses a darker gray brush.
- It retrieves a range value for the cell from the `rangeSelectorTableModel` and calculates the height of the area to be filled with yellow based on this range.
- The cell is then partially filled with yellow, representing the range value.
- A `QTextDocument` is created to render the cell's text. If the table model is not in thumbnail mode, the text is drawn within the cell.
- Finally, the painter's state is restored to its original state.\\
## Code: 
```
void RangeSelectorTableDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const{

    painter->save();
    auto options = option;
    initStyleOption(&options, index);

    QRect rect(option.rect.left(), option.rect.top(),\
             option.rect.width(), option.rect.height());
    QBrush brush(Qt::gray);
    if(index.column() == index.row())brush = QBrush(Qt::darkGray);
    painter->fillRect(rect, brush);

    float range_float = this->rangeSelectorTableModel->getRangeAt(index.row(),index.column());

    float fold_prob = 1 - range_float;
    int disable_height = (int)(fold_prob * option.rect.height());
    int remain_height = option.rect.height() - disable_height;

    rect = QRect(option.rect.left(), option.rect.top() + disable_height,\
     option.rect.width(), remain_height);
    brush = QBrush(Qt::yellow);
    painter->fillRect(rect, brush);

    QTextDocument doc;
    doc.setHtml(options.text);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    if(!this->rangeSelectorTableModel->in_thumbnail_mode()){
        doc.drawContents(painter, clip);
    }
    painter->restore();
}
```