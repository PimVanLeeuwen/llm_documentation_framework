`compair`: The function of `compair` is to compare two sets of private cards combined with a public board of cards and determine which set has a higher rank.

**Code Description**: 
The `compair` function in the `Dic5Compairer` class takes three vectors of integers as input: `private_former`, `private_latter`, and `public_board`. It first checks if the sizes of these vectors are correct: `private_former` and `private_latter` should each contain exactly 2 elements, and `public_board` should contain exactly 5 elements. If any of these conditions are not met, the function throws a runtime error with a descriptive message.

Next, the function combines the `private_former` cards with the `public_board` cards to form a complete set of cards for the former player and calculates its rank using the `getRank` method. Similarly, it combines the `private_latter` cards with the `public_board` cards to form a complete set of cards for the latter player and calculates its rank.

Finally, the function compares the two ranks using the `compairRanks` method and returns the result, indicating which set of cards has a higher rank.\\
## Code: 
```
Compairer::CompairResult
Dic5Compairer::compair(vector<int> private_former, vector<int> private_latter, vector<int> public_board) {
    if(private_former.size() != 2)
        throw runtime_error(
                tfm::format("private former size incorrect,excepted 2, actually %s",private_former.size())
        );
    if(private_latter.size() != 2)
        throw runtime_error(
                tfm::format("private latter size incorrect,excepted 2, actually %s",private_latter.size())
        );
    if(public_board.size() != 5)
        throw runtime_error(
                tfm::format("public board size incorrect,excepted 2, actually %s",public_board.size())
        );

    vector<int> former_cards(private_former);
    former_cards.insert(former_cards.end(),public_board.begin(),public_board.end());
    int rank_former = this->getRank(former_cards);

    vector<int> latter_cards(private_latter);
    latter_cards.insert(latter_cards.end(),public_board.begin(),public_board.end());
    int rank_latter = this->getRank(latter_cards);

    return this->compairRanks(rank_former,rank_latter);
}
```