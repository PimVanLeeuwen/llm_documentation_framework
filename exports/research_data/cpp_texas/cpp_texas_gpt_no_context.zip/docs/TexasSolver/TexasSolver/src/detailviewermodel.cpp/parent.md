`parent`: The function of `parent` is to return the parent index of a given child index.

**Code Description**: This `parent` function is a member of the `DetailViewerModel` class. It takes a constant reference to a `QModelIndex` object named `child` as its parameter and returns a `QModelIndex` object. In this implementation, the function always returns an invalid `QModelIndex` object, indicating that the given `child` index does not have a parent. This could be used in models where items are not organized in a hierarchical structure.\\
## Code: 
```
QModelIndex DetailViewerModel::parent(const QModelIndex &child) const{
    return QModelIndex();
}
```