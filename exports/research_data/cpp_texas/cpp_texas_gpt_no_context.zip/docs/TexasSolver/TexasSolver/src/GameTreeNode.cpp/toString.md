`toString`: The function of `toString` is to generate a string representation of the `GameTreeNode` object.

**Code Description**: The `toString` method in the `GameTreeNode` class is intended to create a string that describes the current node in the game tree. The commented-out code suggests that it checks the type of the parent node and constructs a string based on whether the parent node is an `ActionNode` or a `ChanceNode`. If the parent node is an `ActionNode`, it iterates through the actions and matches the current node to its corresponding action, then formats a string indicating the player and action. If the parent node is a `ChanceNode`, it iterates through the children and matches the current node to its corresponding card, then formats a string indicating the dealt card. However, the actual implementation is incomplete and currently returns an empty string.\\
## Code: 
```
string GameTreeNode::toString(){
    /*
    shared_ptr<GameTreeNode>parent_node = node->parent;
    string round;
    if (parent_node == nullptr) return tfm::format("%s begin",round);
    if(parent_node->getType() == GameTreeNodeType::ACTION){
        ActionNode action_node = (ActionNode)parent_node;
        for(int i = 0;i < action_node.getActions().size();i ++){
            if(action_node.getChildrens().get(i) == node){
                System.out.print(String.format("<- (player %s %s)",
                           action_node.getPlayer(),
                           action_node.getActions().get(i).toString()
                    ));
        }
        }
    }else if(parent_node->getType() == GameTreeNodeType::CHANCE){
        ChanceNode chance_node = (ChanceNode)parent_node;
        for(int i = 0;i < chance_node.getChildrens().size();i ++){
            if(chance_node.getChildrens().get(i) == node){
                System.out.print(String.format("<- (deal card %s)",
                       chance_node.getCards().get(i).toString()
            ));
        }
    }
    */
    return "";
}
```