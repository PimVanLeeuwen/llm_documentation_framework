`getPreflopCards`: The function of `getPreflopCards` is to retrieve the private cards of a specified player before the flop in a poker game.

**Code Description**: This method, `getPreflopCards`, is a member of the `PrivateCardsManager` class. It takes an integer parameter `player`, which represents the index or identifier of a player. The method returns a reference to a `vector` of `PrivateCards` that contains the private cards dealt to the specified player. The `private_cards` is presumably a member variable of the `PrivateCardsManager` class that stores the private cards for all players.\\
## Code: 
```
vector<PrivateCards>& PrivateCardsManager::getPreflopCards(int player) {
    return this->private_cards[player];
}
```