`copyStrategy`: The function of `copyStrategy` is to copy the strategy-related data from another `DiscountedCfrTrainable` object to the current object.

**Code Description**: This method takes a shared pointer to a `Trainable` object as an argument and attempts to cast it to a shared pointer of type `DiscountedCfrTrainable`. If the cast is successful, it copies the `r_plus` and `cum_r_plus` vectors from the other `DiscountedCfrTrainable` object to the current object. The `assign` method is used to copy the contents of the vectors.\\
## Code: 
```
void DiscountedCfrTrainable::copyStrategy(shared_ptr<Trainable> other_trainable){
    shared_ptr<DiscountedCfrTrainable> trainable = dynamic_pointer_cast<DiscountedCfrTrainable>(other_trainable);
    this->r_plus.assign(trainable->r_plus.begin(),trainable->r_plus.end());
    this->cum_r_plus.assign(trainable->cum_r_plus.begin(),trainable->cum_r_plus.end());
}
```