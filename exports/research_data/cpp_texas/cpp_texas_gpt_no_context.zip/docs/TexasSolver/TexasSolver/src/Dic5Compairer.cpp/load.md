`load`: The function of `load` is to load data from a binary file into two maps, `flush_map` and `other_map`.

**Code Description**: 
- The function `load` takes a file path as a parameter and attempts to open the file in read-only mode.
- If the file cannot be opened, it throws a runtime error indicating that the file could not be loaded.
- It then clears the existing contents of `flush_map` and `other_map`.
- The function reads an integer from the file, which represents the number of entries to be read into `flush_map`.
- For each entry, it reads a 64-bit key and a 32-bit value from the file and inserts them into `flush_map`.
- It asserts that the number of entries read matches the expected count.
- The function repeats the process for `other_map`, reading another integer count and then the corresponding key-value pairs.
- Finally, it asserts that the number of entries read into `other_map` matches the expected count and closes the file.
- If all operations are successful, the function returns `true`.\\
## Code: 
```
bool FiveCardsStrength::load(const char* file_path) {
    //ifstream file(file_path, ios::binary);
    /*if (!file) {
        file.close();
        return false;
    }*/

    QFile file(QString::fromStdString(file_path));
    if (!file.open(QIODevice::ReadOnly)){
        throw runtime_error("unable to load compairer file");
    }
    flush_map.clear(); other_map.clear();
    int size_key = sizeof(uint64_t), size_int = sizeof(int), val, cnt = 0;
    uint64_t key = 0;
    char* p_key = (char*)&key, * p_val = (char*)&val, * p_cnt = (char*)&cnt;
    file.read(p_cnt, size_int);// 读取行数
    for (int i = 0; i < cnt; i++) {
        file.read(p_key, size_key);
        file.read(p_val, size_int);
        flush_map[key] = val;
    }
    assert(flush_map.size() == cnt);
    file.read(p_cnt, size_int);// 读取行数
    for (int i = 0; i < cnt; i++) {
        file.read(p_key, size_key);
        file.read(p_val, size_int);
        other_map[key] = val;
    }
    assert(other_map.size() == cnt);
    file.close();
    return true;
}
```