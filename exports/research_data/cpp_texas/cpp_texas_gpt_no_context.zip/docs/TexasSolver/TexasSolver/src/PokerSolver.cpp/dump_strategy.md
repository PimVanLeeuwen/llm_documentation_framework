`dump_strategy`: The function of `dump_strategy` is to save the current poker strategy to a specified file in JSON format.

**Code Description**: 
- The function `dump_strategy` takes two parameters: `dump_file` (a QString representing the file path where the strategy will be saved) and `dump_rounds` (an integer specifying the number of rounds to include in the dump).
- It sets the locale for the program to the default locale using `setlocale(LC_ALL, "")`.
- It calls the `dumps` method of the `solver` object to generate a JSON representation of the current strategy, including the specified number of rounds.
- It then attempts to open the specified file for writing using an `ofstream` object.
- If the file is successfully opened, it writes the JSON data to the file, flushes the stream, and closes the file. It also logs a success message using `qDebug()`.
- If the file cannot be opened, it logs a failure message using `qDebug()`.
- Finally, it resets the locale for character type functions to the default "C" locale using `setlocale(LC_CTYPE, "C")`.\\
## Code: 
```
void PokerSolver::dump_strategy(QString dump_file,int dump_rounds) {
    //locale &loc=locale::global(locale(locale(),"",LC_CTYPE));
    setlocale(LC_ALL,"");

    json dump_json = this->solver->dumps(false,dump_rounds);
    //QFile ofile( QString::fromStdString(dump_file));
    ofstream fileWriter;
    fileWriter.open(dump_file.toLocal8Bit());
    if(!fileWriter.fail()){
        fileWriter << dump_json;
        fileWriter.flush();
        fileWriter.close();
        qDebug().noquote() << QObject::tr("save success");
    }else{
        qDebug().noquote() << QObject::tr("save failed, file cannot be open");
    }
    setlocale(LC_CTYPE, "C");
}
```