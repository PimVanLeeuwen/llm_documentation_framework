`get_strategies_evs`: The function of `get_strategies_evs` is to calculate and return the expected values (EVs) of strategies for a given position in a strategy table.

**Code Description**: 
- The function `get_strategies_evs` takes two integer parameters `i` and `j` and returns a vector of floats representing the expected values of strategies.
- It first checks if the `treeItem` is `NULL` or if `current_evs` is empty. If either condition is true, it returns an empty vector.
- It determines the current player's range (`current_range`) based on the value of `current_player`. If either `p1_range` or `p2_range` is empty, it returns an empty vector.
- It locks the `treeItem` to get a shared pointer to a `GameTreeNode` object.
- If the node type is `ACTION`, it proceeds to calculate the EVs:
  - It retrieves the actions from the `ActionNode`.
  - It initializes vectors `ret_evs` and `strategy_p` to store the expected values and strategy probabilities, respectively.
  - It iterates over the indices in `ui_strategy_table[i][j]` to accumulate the EVs and strategy probabilities.
  - For each index pair, it retrieves the corresponding strategy, EV, and range values.
  - It checks if the sizes of the strategy, EV, and actions match. If not, it throws a runtime error.
  - It updates `ret_evs` and `strategy_p` by multiplying the strategy, EV, and range values.
  - It normalizes the EVs by dividing by the strategy probabilities if they are greater than zero.
- If the node type is not `ACTION`, it returns an empty vector.
- Finally, it returns the calculated `ret_evs` vector.\\
## Code: 
```
const vector<float> TableStrategyModel::get_strategies_evs(int i,int j)const{
    vector<float> ret_evs;
    if(this->treeItem == NULL || this->current_evs.empty())return ret_evs;

    const vector<vector<float>> *current_range;
    current_range = (0 == current_player ) ? & p1_range : & p2_range;
    if(p1_range.empty() || p2_range.empty()){
        return ret_evs;
    }

    shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();

    if(node->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);
        vector<GameActions>& gameActions = actionNode->getActions();

        vector<float> strategy_p;
        if(this->ui_strategy_table[i][j].size() > 0){
            ret_evs = vector<float>(gameActions.size());
            std::fill(ret_evs.begin(), ret_evs.end(), 0.);
            strategy_p = vector<float>(gameActions.size());
            std::fill(strategy_p.begin(), strategy_p.end(), 0.);
        }
        float range = 0;
        for(std::pair<int,int> index:this->ui_strategy_table[i][j]){
            int index1 = index.first;
            int index2 = index.second;
            const vector<float>& one_strategy = this->current_strategy[index1][index2];
            const vector<float>& one_ev = this->current_evs[index1][index2];
            const float one_range = (*current_range)[index1][index2];
            if(gameActions.size() != one_strategy.size() || one_ev.size() != one_strategy.size()){
                cout << "index: " << index1 << " " << index2 << endl;
                cout << "i,j: " << i << " " << j << endl;
                cout << "size not match between one_ev, gameAction and one_stragegy: "
                     << one_ev.size() << " " << gameActions.size() << " " << one_strategy.size() << endl;
                throw runtime_error("size not match between one_ev, gameAction and one_stragegy");
            }
            for(std::size_t indi = 0;indi < ret_evs.size();indi ++){
                ret_evs[indi] += one_strategy[indi] * one_ev[indi] * one_range;
                strategy_p[indi] += one_strategy[indi] * one_range;
            }
            range += one_range;
        }
        for(std::size_t indi = 0;indi < ret_evs.size();indi ++){
            if (strategy_p[indi] > 0. && range > 0.) {
                ret_evs[indi] = ret_evs[indi] / strategy_p[indi];
            }
        }
        return ret_evs;
    }else{
        return ret_evs;
    }
}
```