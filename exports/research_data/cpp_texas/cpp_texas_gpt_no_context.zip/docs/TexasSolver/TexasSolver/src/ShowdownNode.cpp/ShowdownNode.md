`ShowdownNode`: The function of `ShowdownNode` is to initialize a node in a game tree that represents a showdown in a poker game, where the final payoffs to players are determined.

**Code Description**: 
- The constructor `ShowdownNode` takes four parameters: `tie_payoffs` (a vector of doubles representing the payoffs in case of a tie), `player_payoffs` (a vector of vectors of doubles representing the payoffs for each player), `round` (an enumeration value representing the current game round), `pot` (a double representing the total pot size), and `parent` (a shared pointer to the parent node in the game tree).
- The constructor initializes the base class `GameTreeNode` with the `round`, `pot`, and `parent` parameters.
- It then assigns the `tie_payoffs` and `player_payoffs` to the corresponding member variables of the `ShowdownNode` class using `std::move` to transfer ownership and avoid unnecessary copying.\\
## Code: 
```
ShowdownNode::ShowdownNode(vector<double> tie_payoffs, vector<vector<double>> player_payoffs,
                           GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode>parent):
                           GameTreeNode(round,pot,std::move(parent)) {
    this->tie_payoffs = std::move(tie_payoffs);
    this->player_payoffs = std::move(player_payoffs);
}
```