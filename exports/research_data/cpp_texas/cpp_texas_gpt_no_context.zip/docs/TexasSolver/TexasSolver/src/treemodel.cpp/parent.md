`parent`: The function of `parent` is to return the parent index of a given index in a tree model.

**Code Description**: This function takes a `QModelIndex` object as input and returns its parent index. If the input index is invalid, it returns an empty `QModelIndex`. It retrieves the `TreeItem` associated with the input index and then gets its parent item. If the parent item is the root item, it returns an empty `QModelIndex`. Otherwise, it creates and returns a new `QModelIndex` for the parent item, using the parent's row number and a column index of 0.\\
## Code: 
```
QModelIndex TreeModel::parent(const QModelIndex &index) const
{
    if (!index.isValid())
        return QModelIndex();

    TreeItem *childItem = static_cast<TreeItem*>(index.internalPointer());
    TreeItem *parentItem = childItem->parentItem();

    if (parentItem == rootItem)
        return QModelIndex();

    return createIndex(parentItem->row(), 0, parentItem);
}
```