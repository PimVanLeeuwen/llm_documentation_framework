`onchanged`: The function of `onchanged` is to notify that the header data has changed.

**Code Description**: The `onchanged` function in the `RoughStrategyViewerModel` class emits the `headerDataChanged` signal. This signal indicates that the header data for the model has been modified. The signal is emitted with the `Qt::Horizontal` orientation, starting from the first column (index 0) to the total number of columns in the model, which is determined by the `columnCount()` function. This allows any connected views to update their display of the header accordingly.\\
## Code: 
```
void RoughStrategyViewerModel::onchanged(){
    emit headerDataChanged(Qt::Horizontal, 0 , columnCount());
}
```