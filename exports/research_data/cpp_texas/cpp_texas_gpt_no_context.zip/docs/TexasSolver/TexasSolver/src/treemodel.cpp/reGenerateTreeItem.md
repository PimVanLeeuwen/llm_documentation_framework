`reGenerateTreeItem`: The function of `reGenerateTreeItem` is to recursively regenerate the tree structure starting from a given node based on the specified game round.

**Code Description**: 
- The function `reGenerateTreeItem` takes two parameters: `round` of type `GameTreeNode::GameRound` and `node_to_process` of type `TreeItem*`.
- It first locks the weak pointer `m_treedata` of `node_to_process` to get a shared pointer to `GameTreeNode`.
- It checks the type of `gameTreeNode`:
  - If the type is `GameTreeNode::GameTreeNodeType::ACTION`, it casts `gameTreeNode` to `ActionNode` and retrieves its children.
    - For each child, it creates a new `TreeItem` and inserts it as a child of `node_to_process`.
    - If the child's round matches the specified `round`, it recursively calls `reGenerateTreeItem` with the child node.
  - If the type is `GameTreeNode::GameTreeNodeType::CHANCE`, it casts `gameTreeNode` to `ChanceNode` and retrieves its single child.
    - It creates a new `TreeItem` for this child and inserts it as a child of `node_to_process`.
    - It then recursively calls `reGenerateTreeItem` with the child node.
- The function effectively rebuilds the tree structure by traversing and processing nodes based on their type and the specified game round.\\
## Code: 
```
void TreeModel::reGenerateTreeItem(GameTreeNode::GameRound round,TreeItem* node_to_process){
    const shared_ptr<GameTreeNode> gameTreeNode = node_to_process->m_treedata.lock();
    if(gameTreeNode->getType() == GameTreeNode::GameTreeNodeType::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(gameTreeNode);
        vector<shared_ptr<GameTreeNode>>& childrens = actionNode->getChildrens();
        for(shared_ptr<GameTreeNode> one_child:childrens){
            TreeItem * child_node = new TreeItem(one_child,node_to_process);
            node_to_process->insertChild(child_node);
            if(one_child->getRound() != round){
                continue;
            }
            this->reGenerateTreeItem(round,child_node);
        }
    }
    else if(gameTreeNode->getType() == GameTreeNode::GameTreeNodeType::CHANCE){
        shared_ptr<ChanceNode> chanceNode = dynamic_pointer_cast<ChanceNode>(gameTreeNode);
        TreeItem * child_node = new TreeItem(chanceNode->getChildren(),node_to_process);
        node_to_process->insertChild(child_node);
        this->reGenerateTreeItem(round,child_node);
    }
}
```