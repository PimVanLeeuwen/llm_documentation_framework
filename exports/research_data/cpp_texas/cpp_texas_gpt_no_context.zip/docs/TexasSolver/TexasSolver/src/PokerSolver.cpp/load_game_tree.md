`load_game_tree`: The function of `load_game_tree` is to load a game tree from a specified file and assign it to the `game_tree` member variable of the `PokerSolver` object.

**Code Description**: The `load_game_tree` function takes a string parameter `game_tree_file`, which represents the file path of the game tree to be loaded. It creates a shared pointer to a `GameTree` object, initializing it with the provided file path and the `deck` member variable of the `PokerSolver` object. This shared pointer is then assigned to the `game_tree` member variable of the `PokerSolver` object, effectively loading the game tree into the solver.\\
## Code: 
```
void PokerSolver::load_game_tree(string game_tree_file) {
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(game_tree_file,this->deck);
    this->game_tree = game_tree;
}
```