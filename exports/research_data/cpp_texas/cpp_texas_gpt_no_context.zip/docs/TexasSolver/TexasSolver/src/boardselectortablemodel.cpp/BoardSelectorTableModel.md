`BoardSelectorTableModel`: The function of `BoardSelectorTableModel` is to initialize a table model for selecting a board configuration based on given ranks and an initial board setup.

**Code Description**: 
- The constructor `BoardSelectorTableModel` initializes the table model with a list of ranks, an initial board configuration, and an optional parent object.
- It assigns the provided `ranks` to the member variable `ranklist`.
- It initializes `suitlist` with the suits "c", "d", "h", and "s".
- It creates a 2D vector `grids_string` to store string representations of the grid cells, with dimensions based on the number of suits and ranks.
- It populates `grids_string` with text values for each cell using the `get_ij_text` method and maps these text values to their corresponding grid coordinates in the `string2ij` map.
- It creates a 2D vector `grids_float` to store float values for the grid cells, initializing all values to 0.0.
- It calls the `setBoardText` method to set up the initial board configuration based on the provided `initial_board` string.\\
## Code: 
```
BoardSelectorTableModel::BoardSelectorTableModel(QStringList ranks,QString initial_board,QObject *parent):QAbstractItemModel(parent){
    this->ranklist = ranks;
    this->suitlist = QString("c,d,h,s").split(",");

    this->grids_string = vector<vector<QString>>(this->suitlist.size());
    for(int i = 0;i < this->suitlist.size();i ++){
        this->grids_string[i] = vector<QString>(this->ranklist.size());
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_string[i][j] = this->get_ij_text(i,j);
            this->string2ij[this->get_ij_text(i,j)] = pair<int,int>(i,j);
        }
    }

    this->grids_float = vector<vector<float>>(this->suitlist.size());
    for(int i = 0;i < this->suitlist.size();i ++){
        this->grids_float[i] = vector<float>(this->ranklist.size(),0.0);
    }
    this->setBoardText(initial_board);
}
```