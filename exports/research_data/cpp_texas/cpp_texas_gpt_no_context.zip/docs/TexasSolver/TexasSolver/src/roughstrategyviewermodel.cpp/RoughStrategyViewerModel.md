`RoughStrategyViewerModel`: The function of `RoughStrategyViewerModel` is to initialize an instance of the `RoughStrategyViewerModel` class.

**Code Description**: This constructor for the `RoughStrategyViewerModel` class takes two parameters: a pointer to a `TableStrategyModel` object (`tableStrategyModel`) and an optional `QObject` parent (`parent`). It initializes the `tableStrategyModel` member variable with the provided `tableStrategyModel` argument and passes the `parent` argument to the base class `QAbstractItemModel` constructor. This sets up the `RoughStrategyViewerModel` object with the necessary table strategy model and parent object.\\
## Code: 
```
RoughStrategyViewerModel::RoughStrategyViewerModel(TableStrategyModel* tableStrategyModel, QObject *parent):QAbstractItemModel(parent){
    this->tableStrategyModel = tableStrategyModel;
}
```