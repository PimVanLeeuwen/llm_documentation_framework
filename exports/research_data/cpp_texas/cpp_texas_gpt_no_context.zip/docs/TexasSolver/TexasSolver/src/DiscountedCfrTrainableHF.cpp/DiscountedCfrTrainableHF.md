`DiscountedCfrTrainableHF`: The function of `DiscountedCfrTrainableHF` is to initialize an object that handles the training of a discounted counterfactual regret minimization (CFR) algorithm with specific private cards and an action node.

**Code Description**: 
- The constructor `DiscountedCfrTrainableHF` takes two parameters: a pointer to a vector of `PrivateCards` and a reference to an `ActionNode`.
- It initializes the `privateCards` member variable with the provided pointer to the vector of `PrivateCards`.
- It initializes the `action_node` member variable with the provided `ActionNode` reference.
- It sets the `action_number` member variable to the number of children of the `action_node`.
- It sets the `card_number` member variable to the size of the `privateCards` vector.
- It initializes the `evs` vector with a size equal to the product of `action_number` and `card_number`, and fills it with zeros of type `EvsStorage`.
- It initializes the `r_plus` vector with a size equal to the product of `action_number` and `card_number`, and fills it with zeros of type `RplusStorage`.
- It initializes the `cum_r_plus` vector with a size equal to the product of `action_number` and `card_number`, and fills it with zeros of type `CumRplusStorage`.\\
## Code: 
```
DiscountedCfrTrainableHF::DiscountedCfrTrainableHF(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();
    this->evs = vector<EvsStorage>(this->action_number * this->card_number, (EvsStorage) 0.0);
    this->r_plus = vector<RplusStorage>(this->action_number * this->card_number, (RplusStorage) 0.0);
    this->cum_r_plus = vector<CumRplusStorage>(this->action_number * this->card_number, (CumRplusStorage) 0.0);
}
```