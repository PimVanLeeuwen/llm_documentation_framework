`get_rank`: The function of `get_rank` is to calculate and return the rank of a poker hand based on the given private hand and public board.

**Code Description**: 
- The method `get_rank` is a member of the `Dic5Compairer` class.
- It takes two parameters: `private_hand` and `public_board`, both of which are 64-bit unsigned integers (`uint64_t`).
- The method converts these integer representations of the private hand and public board into a board format using the `Card::long2board` method.
- It then calls another `get_rank` method (likely an overloaded version) with the converted board representations to compute the rank of the poker hand.
- Finally, it returns the computed rank as an integer.\\
## Code: 
```
int Dic5Compairer::get_rank(uint64_t private_hand, uint64_t public_board) {
    return this->get_rank(Card::long2board(private_hand),Card::long2board(public_board));
}
```