`DiscountedCfrTrainableSF`: The function of `DiscountedCfrTrainableSF` is to initialize an object that manages the training of a strategy using Discounted Counterfactual Regret Minimization (CFR) in a poker game setting.

**Code Description**: 
- The constructor `DiscountedCfrTrainableSF` takes two parameters: a pointer to a vector of `PrivateCards` and a reference to an `ActionNode`.
- It initializes the `privateCards` member variable with the provided pointer.
- It sets the `action_node` member variable with the provided `ActionNode` reference.
- It calculates the number of actions (`action_number`) by getting the size of the children of the `action_node`.
- It calculates the number of private cards (`card_number`) by getting the size of the `privateCards` vector.
- It initializes three vectors: `evs`, `r_plus`, and `cum_r_plus`, each with a size equal to the product of `action_number` and `card_number`, and fills them with initial values of 0.0. These vectors are used to store expected values, positive regrets, and cumulative positive regrets, respectively.\\
## Code: 
```
DiscountedCfrTrainableSF::DiscountedCfrTrainableSF(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();
    this->evs = vector<EvsStorage>(this->action_number * this->card_number, (EvsStorage) 0.0);
    this->r_plus = vector<RplusStorage>(this->action_number * this->card_number, (RplusStorage) 0.0);
    this->cum_r_plus = vector<CumRplusStorage>(this->action_number * this->card_number, (CumRplusStorage) 0.0);
}
```