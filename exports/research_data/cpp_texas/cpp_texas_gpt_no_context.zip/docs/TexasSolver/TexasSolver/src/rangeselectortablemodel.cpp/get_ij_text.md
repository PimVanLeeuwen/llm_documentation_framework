`get_ij_text`: The function of `get_ij_text` is to generate a formatted string based on the values at the specified indices in the `ranklist` and the relative positions of the indices.

**Code Description**: The `get_ij_text` function takes two integer parameters, `i` and `j`, representing row and column indices. It determines the larger and smaller of the two indices and retrieves the corresponding values from the `ranklist` array. It then concatenates these values into a string. Depending on whether the row index is greater than, less than, or equal to the column index, it appends "o", "s", or an empty string, respectively, to the concatenated string. The resulting string is returned.\\
## Code: 
```
QString RangeSelectorTableModel::get_ij_text(int i,int j){
    int row = i;
    int col = j;
    int larger = row > col?row:col;
    int smaller = row > col?col:row;
    QString  retval = QString("%1%2%3")\
            .arg(QString(this->ranklist[smaller]))\
            .arg(QString(this->ranklist[larger]));
    if(row > col){
        retval = retval.arg("o");
    }else if(row < col){
        retval = retval.arg("s");
    }else{
        retval = retval.arg("");
    }
    return retval;
}
```