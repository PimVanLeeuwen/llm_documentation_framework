`stop`: The function of `stop` is to halt the operation of the solver if it is currently running.

**Code Description**: The `stop` method in the `PokerSolver` class checks if the `solver` member variable is not a null pointer. If `solver` is not null, it calls the `stop` method on the `solver` object, effectively stopping its operation. This ensures that the solver is only stopped if it has been initialized and is currently active.\\
## Code: 
```
void PokerSolver::stop(){
    if(this->solver != nullptr){
        this->solver->stop();
    }
}
```