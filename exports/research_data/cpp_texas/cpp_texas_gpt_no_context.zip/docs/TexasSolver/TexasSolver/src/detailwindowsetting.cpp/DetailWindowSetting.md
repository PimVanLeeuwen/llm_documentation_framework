`DetailWindowSetting`: The function of `DetailWindowSetting` is to initialize an instance of the `DetailWindowSetting` class.

**Code Description**: This constructor sets the `mode` attribute of the `DetailWindowSetting` object to `DetailWindowMode::STRATEGY` when a new instance is created. This means that by default, the detail window will be in the "strategy" mode unless it is changed later in the code.\\
## Code: 
```
DetailWindowSetting::DetailWindowSetting(){
    this->mode = DetailWindowMode::STRATEGY;
}
```