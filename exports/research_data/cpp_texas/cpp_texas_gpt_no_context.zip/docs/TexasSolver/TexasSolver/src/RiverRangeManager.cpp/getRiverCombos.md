`getRiverCombos`: The function of `getRiverCombos` is to retrieve a list of river combinations for a given player based on their private cards and the current board state.

**Code Description**: This method, `getRiverCombos`, takes three parameters: an integer `player` representing the player ID, a vector of `PrivateCards` named `riverCombos` representing the possible river combinations, and a vector of integers `board` representing the current state of the board. It first converts the board state from a vector of integers to a single 64-bit integer using the `Card::boardInts2long` method. Then, it calls another overloaded version of `getRiverCombos` with the `player`, `riverCombos`, and the converted board state (`board_long`) as arguments, and returns the result.\\
## Code: 
```
const vector<RiverCombs> &
RiverRangeManager::getRiverCombos(int player, const vector<PrivateCards> &riverCombos, const vector<int> &board) {
    uint64_t board_long = Card::boardInts2long(board);
    return this->getRiverCombos(player,riverCombos,board_long);
}
```