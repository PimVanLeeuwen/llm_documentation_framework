`getRound`: The function of `getRound` is to return the current game round stored in the `GameTreeNode` object.

**Code Description**: This method, `getRound`, is a member function of the `GameTreeNode` class. It returns the value of the `round` member variable, which is of type `GameTreeNode::GameRound`. The `this` pointer is used to access the `round` variable of the current instance of the `GameTreeNode` class.\\
## Code: 
```
GameTreeNode::GameRound GameTreeNode::getRound() {
    return this->round;
}
```