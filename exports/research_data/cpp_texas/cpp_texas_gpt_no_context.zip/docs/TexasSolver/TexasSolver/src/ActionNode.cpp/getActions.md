`getActions`: The function of `getActions` is to return a reference to the `actions` member variable of the `ActionNode` object.

**Code Description**: This method, `getActions`, is a member function of the `ActionNode` class. It returns a reference to the `actions` vector, which contains elements of type `GameActions`. This allows the caller to access and modify the `actions` vector directly.\\
## Code: 
```
vector<GameActions>& ActionNode::getActions() {
    return this->actions;
}
```