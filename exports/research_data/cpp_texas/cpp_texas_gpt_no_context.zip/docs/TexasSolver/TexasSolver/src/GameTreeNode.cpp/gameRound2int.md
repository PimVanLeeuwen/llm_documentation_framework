`gameRound2int`: The function of `gameRound2int` is to convert a `GameRound` enum value to its corresponding integer representation.

**Code Description**: The `gameRound2int` function takes a `GameRound` enum value as input and returns an integer based on the specific game round. If the input is `GameRound::PREFLOP`, it returns 0. If the input is `GameRound::FLOP`, it returns 1. If the input is `GameRound::TURN`, it returns 2. If the input is `GameRound::RIVER`, it returns 3. If the input does not match any of these values, the function throws a runtime error with the message "round not found".\\
## Code: 
```
int GameTreeNode::gameRound2int(GameTreeNode::GameRound gameRound) {
    if(gameRound == GameRound::PREFLOP) {
        return 0;
    }else if(gameRound == GameRound::FLOP){
        return 1;
    } else if(gameRound == GameRound::TURN) {
        return 2;
    } else if(gameRound == GameRound::RIVER) {
        return 3;
    }
    throw runtime_error("round not found");
}
```