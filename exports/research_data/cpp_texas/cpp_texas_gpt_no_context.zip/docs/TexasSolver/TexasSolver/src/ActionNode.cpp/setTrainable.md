`setTrainable`: The function of `setTrainable` is to set the trainable objects and player private cards for the `ActionNode` instance.

**Code Description**: The `setTrainable` method of the `ActionNode` class takes two parameters: a vector of shared pointers to `Trainable` objects and a pointer to a vector of `PrivateCards`. It assigns these parameters to the member variables `trainables` and `player_privates` of the `ActionNode` instance, respectively. This allows the `ActionNode` to store and later use the provided trainable objects and player private cards.\\
## Code: 
```
void ActionNode::setTrainable(vector<shared_ptr<Trainable>> trainables,vector<PrivateCards>* player_privates) {
    this->trainables = trainables;
    this->player_privates = player_privates;
}
```