`setTrainable`: The function of `setTrainable` is to recursively set the training method for each node in a game tree based on the type of node and the specified training algorithm.

**Code Description**: 
- The function `setTrainable` takes a shared pointer to a `GameTreeNode` object as its parameter.
- It first checks the type of the node:
  - If the node is of type `ACTION`, it casts the node to an `ActionNode` and retrieves the player associated with the node.
    - If the trainer is "cfr_plus", it throws a runtime error indicating that this trainer is not supported.
    - If the trainer is "discounted_cfr", it calculates the number of trainable objects needed based on the gap between the current round and the root round, and sets the trainable objects for the action node.
    - If the trainer is neither "cfr_plus" nor "discounted_cfr", it throws a runtime error indicating that the trainer is not found.
    - It then recursively calls `setTrainable` on each child node of the action node.
  - If the node is of type `CHANCE`, it casts the node to a `ChanceNode` and recursively calls `setTrainable` on its child node.
  - If the node is of type `TERMINAL` or `SHOWDOWN`, it does nothing.
- The function ensures that each node in the game tree is appropriately set up for training based on its type and the specified training algorithm.\\
## Code: 
```
void PCfrSolver::setTrainable(shared_ptr<GameTreeNode> root) {
    if(root->getType() == GameTreeNode::ACTION){
        shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(root);

        int player = action_node->getPlayer();

        if(this->trainer == "cfr_plus"){
            //vector<PrivateCards> player_privates = this->ranges[player];
            //action_node->setTrainable(make_shared<CfrPlusTrainable>(action_node,player_privates));
            throw runtime_error(tfm::format("trainer %s not supported",this->trainer));
        }else if(this->trainer == "discounted_cfr"){
            vector<PrivateCards>* player_privates = &this->ranges[player];
            //action_node->setTrainable(make_shared<DiscountedCfrTrainable>(action_node,player_privates));
            int num;
            GameTreeNode::GameRound gr = this->tree->getRoot()->getRound();
            int root_round = GameTreeNode::gameRound2int(gr);
            int current_round = GameTreeNode::gameRound2int(root->getRound());
            int gap = current_round - root_round;

            if(gap == 2) {
                num = this->deck.getCards().size() * this->deck.getCards().size() +
                          this->deck.getCards().size() + 1;
            }else if(gap == 1) {
                num = this->deck.getCards().size() + 1;
            }else if(gap == 0) {
                num =  1;
            }else{
                throw runtime_error("gap not understand");
            }
            action_node->setTrainable(vector<shared_ptr<Trainable>>(num),player_privates);
        }else{
            throw runtime_error(tfm::format("trainer %s not found",this->trainer));
        }

        vector<shared_ptr<GameTreeNode>> childrens =  action_node->getChildrens();
        for(shared_ptr<GameTreeNode> one_child:childrens) setTrainable(one_child);
    }else if(root->getType() == GameTreeNode::CHANCE) {
        shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(root);
        shared_ptr<GameTreeNode> children = chance_node->getChildren();
        setTrainable(children);
    }
    else if(root->getType() == GameTreeNode::TERMINAL){

    }else if(root->getType() == GameTreeNode::SHOWDOWN){

    }
}
```