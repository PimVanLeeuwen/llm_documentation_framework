`setRiverCard`: The function of `setRiverCard` is to set the river card in the `TableStrategyModel` object.

**Code Description**: This method, `setRiverCard`, takes a `Card` object as an argument and assigns it to the `river_card` member variable of the `TableStrategyModel` class. This effectively updates the river card for the table strategy model with the provided card.\\
## Code: 
```
void TableStrategyModel::setRiverCard(Card river_card){
    this->river_card = river_card;
}
```