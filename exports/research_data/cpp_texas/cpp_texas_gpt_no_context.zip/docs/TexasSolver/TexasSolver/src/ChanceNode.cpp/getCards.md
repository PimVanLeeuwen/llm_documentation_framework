`getCards`: The function of `getCards` is to return a constant reference to the `cards` member variable of the `ChanceNode` object.

**Code Description**: This method, `getCards`, is a member function of the `ChanceNode` class. It returns a constant reference to the `cards` vector, which contains objects of type `Card`. This allows the caller to access the `cards` without modifying the original vector stored in the `ChanceNode` object.\\
## Code: 
```
const vector<Card>& ChanceNode::getCards() {
    return this->cards;
}
```