`noDuplicateRange`: The function of `noDuplicateRange` is to filter out duplicate and conflicting private card ranges based on a given board state.

**Code Description**: 
- The function `noDuplicateRange` takes two parameters: a vector of `PrivateCards` objects (`private_range`) and a `uint64_t` representing the board state (`board_long`).
- It initializes an empty vector `range_array` to store the filtered `PrivateCards` objects and an unordered map `rangekv` to track the hash codes of the `PrivateCards` objects.
- The function iterates over each `PrivateCards` object in `private_range`.
- For each `PrivateCards` object (`one_range`), it checks if its hash code already exists in `rangekv`. If it does, a runtime error is thrown indicating a duplicate key.
- If the hash code is not found in `rangekv`, it is added to the map.
- The function then converts the hands of `one_range` to a `uint64_t` representation (`hand_long`) using `Card::boardInts2long`.
- It checks if `hand_long` and `board_long` have any intersecting cards using `Card::boardsHasIntercept`.
- If there is no intersection, `one_range` is added to `range_array`.
- Finally, the function returns `range_array`, which contains the filtered `PrivateCards` objects without duplicates and conflicts with the board state.\\
## Code: 
```
vector<PrivateCards> noDuplicateRange(const vector<PrivateCards> &private_range, uint64_t board_long) {
    vector<PrivateCards> range_array;
    unordered_map<int,bool> rangekv;
    for(PrivateCards one_range:private_range){
        if(rangekv.find(one_range.hashCode()) != rangekv.end())
            throw runtime_error(tfm::format("duplicated key %s",one_range.toString()));
        rangekv[one_range.hashCode()] = true;
        uint64_t hand_long = Card::boardInts2long(one_range.get_hands());
        if(!Card::boardsHasIntercept(hand_long,board_long)){
            range_array.push_back(one_range);
        }
    }
    return range_array;
}
```