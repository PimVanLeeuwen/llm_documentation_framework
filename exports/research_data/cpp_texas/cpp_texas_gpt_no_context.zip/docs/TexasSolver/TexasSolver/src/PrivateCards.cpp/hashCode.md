`hashCode`: The function of `hashCode` is to return the hash code of the `PrivateCards` object.

**Code Description**: This method, `hashCode`, is a member of the `PrivateCards` class. It returns the value of the private member variable `hash_code` of the `PrivateCards` object. This value is used to uniquely identify the object, typically for purposes such as storing the object in a hash table.\\
## Code: 
```
int PrivateCards::hashCode() {
    return this->hash_code;
}
```