`copyStrategy`: The function of `copyStrategy` is to copy the strategy data from another `DiscountedCfrTrainableSF` object to the current object.

**Code Description**: The `copyStrategy` method takes a shared pointer to a `Trainable` object as an argument. It first attempts to cast this pointer to a shared pointer of type `DiscountedCfrTrainableSF`. If the cast is successful, it copies the contents of the `r_plus` and `cum_r_plus` vectors from the other `DiscountedCfrTrainableSF` object to the corresponding vectors in the current object using the `assign` method. This ensures that the current object has the same strategy data as the other object.\\
## Code: 
```
void DiscountedCfrTrainableSF::copyStrategy(shared_ptr<Trainable> other_trainable){
    shared_ptr<DiscountedCfrTrainableSF> trainable = dynamic_pointer_cast<DiscountedCfrTrainableSF>(other_trainable);
    this->r_plus.assign(trainable->r_plus.begin(),trainable->r_plus.end());
    this->cum_r_plus.assign(trainable->cum_r_plus.begin(),trainable->cum_r_plus.end());
}
```