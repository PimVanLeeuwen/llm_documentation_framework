`insertChild`: The function of `insertChild` is to insert a child item into the list of child items at a specified position.

**Code Description**: The `insertChild` function takes two parameters: a pointer to a `TreeItem` object (`child`) and an integer (`i`). It checks if the specified position `i` is within the valid range of the current list of child items (`m_childItems`). If `i` is out of range (either greater than or equal to the count of child items or less than 0), the function appends the `child` to the end of the list. Otherwise, it inserts the `child` at the specified position `i` in the list. The function always returns `true`.\\
## Code: 
```
bool TreeItem::insertChild(TreeItem *child,int i)
{
    if (i >= m_childItems.count() || i < 0)
        m_childItems.append(child);
    else
        m_childItems.insert(i, child);

    return true;
}
```