`GameActions`: The function of `GameActions` is to initialize a game action with a specified type and amount, ensuring the amount is valid for the given action type.

**Code Description**: 
- The constructor `GameActions` takes two parameters: `action` of type `GameTreeNode::PokerActions` and `amount` of type `double`.
- It assigns the provided `action` to the member variable `this->action`.
- If the `action` is either `RAISE` or `BET`, it checks if the `amount` is `-1`. If so, it throws a runtime error indicating that the amount should not be `-1`.
- If the `action` is not `RAISE` or `BET` (i.e., it is `CHECK`, `FOLD`, or `CALL`), it checks if the `amount` is not `-1`. If so, it throws a runtime error indicating that the amount should be `-1`.
- Finally, it assigns the provided `amount` to the member variable `this->amount`.\\
## Code: 
```
GameActions::GameActions(GameTreeNode::PokerActions action, double amount) {
    this->action = action;
    if (action == GameTreeNode::PokerActions::RAISE || action == GameTreeNode::PokerActions::BET ) {
        if (amount == -1) throw runtime_error(tfm::format("raise/bet amount should not be -1, find %s",amount));
    } else {
        if (amount != -1) throw runtime_error(tfm::format("check/fold/call amount should be -1, find %s",amount));
    }
    this->amount = amount;
}
```