`mouseReleaseEvent`: The function of `mouseReleaseEvent` is to handle mouse release events for the `HtmlTableRangeView` class.

**Code Description**: This method overrides the `mouseReleaseEvent` function in the `HtmlTableRangeView` class. When a mouse release event occurs, it calls the `mouseReleaseEvent` method of its parent class, `HtmlTableView`, passing the `QMouseEvent` object `event` as an argument. This ensures that the `HtmlTableView` class's implementation of `mouseReleaseEvent` is executed, allowing for any specific behavior defined in the parent class to be applied to the `HtmlTableRangeView` as well.\\
## Code: 
```
void HtmlTableRangeView::mouseReleaseEvent(QMouseEvent *event) {
    HtmlTableView::mouseReleaseEvent(event);
}
```