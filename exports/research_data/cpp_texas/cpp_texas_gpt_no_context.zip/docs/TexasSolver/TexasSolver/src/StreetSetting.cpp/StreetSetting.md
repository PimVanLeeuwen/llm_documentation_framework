`StreetSetting`: The function of `StreetSetting` is to initialize an object with specific betting, raising, and donking sizes, and an all-in option.

**Code Description**: The constructor `StreetSetting` takes four parameters: `bet_sizes`, `raise_sizes`, `donk_sizes`, and `allin`. It initializes the object's member variables `bet_sizes`, `raise_sizes`, `donk_sizes`, and `allin` with the provided values. The `bet_sizes`, `raise_sizes`, and `donk_sizes` are vectors of floats representing different sizes for betting, raising, and donking, respectively. The `allin` is a boolean indicating whether the all-in option is available.\\
## Code: 
```
StreetSetting::StreetSetting(vector<float> bet_sizes, vector<float> raise_sizes, vector<float> donk_sizes,
                             bool allin) {
    this->bet_sizes = bet_sizes;
    this->raise_sizes = raise_sizes;
    this->donk_sizes = donk_sizes;
    this->allin = allin;
}
```