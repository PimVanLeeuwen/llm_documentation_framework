`setBoardText`: The function of `setBoardText` is to update the board's grid values based on a comma-separated string input.

**Code Description**: 
- The function `setBoardText` takes a `QString` parameter `input_board`.
- It first clears the current board state by calling `this->clear_board()`.
- It then splits the `input_board` string by commas to get individual board entries.
- For each entry, it initializes a float value `board_float` to 1.0.
- It skips entries that are either empty or consist only of spaces.
- It checks if the entry exists in the `string2ij` map. If not, it logs a debug message indicating a format error and skips the entry.
- For valid entries, it retrieves the corresponding coordinates from the `string2ij` map.
- It updates the `grids_float` at the specified coordinates with the value of `board_float`.\\
## Code: 
```
void BoardSelectorTableModel::setBoardText(QString input_board){
    this->clear_board();
    for(QString one_board:input_board.split(",")){
        float board_float = 1.0;


        if(one_board.count(" ") == one_board.length() || one_board == "")continue;
        if(!this->string2ij.count(one_board)){
            qDebug().noquote() << QString(tr("skipping board %1, format error")).arg(one_board);
            continue;
        }
        pair<int,int> cord = this->string2ij[one_board];
        this->grids_float[cord.first][cord.second] = board_float;
    }
}
```