`headerData`: The function of `headerData` is to provide the data for the headers in a tree model.

**Code Description**: This function takes three parameters: `section`, `orientation`, and `role`. If the `orientation` is horizontal and the `role` is `Qt::DisplayRole`, it returns the data from the `rootItem`. Otherwise, it returns an empty `QVariant`. This is typically used to display the header data in a tree view.\\
## Code: 
```
QVariant TreeModel::headerData(int section, Qt::Orientation orientation,
                               int role) const
{
    if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
        return rootItem->data();

    return QVariant();
}
```