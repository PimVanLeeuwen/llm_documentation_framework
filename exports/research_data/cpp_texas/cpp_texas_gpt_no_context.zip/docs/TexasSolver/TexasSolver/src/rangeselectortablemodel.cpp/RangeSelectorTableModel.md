`RangeSelectorTableModel`: The function of `RangeSelectorTableModel` is to initialize a table model for selecting ranges, with the ability to handle both string and float grid representations based on a list of ranks and an initial board configuration.

**Code Description**: 
- The constructor `RangeSelectorTableModel` initializes the table model with a list of ranks, an initial board configuration, a parent object, and a thumbnail flag.
- `this->ranklist` is assigned the provided list of ranks.
- `this->thumbnail` is assigned the provided thumbnail flag.
- `this->grids_string` is initialized as a 2D vector of QStrings with dimensions based on the size of `ranklist`.
- A nested loop populates `this->grids_string` with text values obtained from the `get_ij_text` method and maps these text values to their corresponding grid coordinates in `this->string2ij`.
- `this->grids_float` is initialized as a 2D vector of floats with dimensions based on the size of `ranklist`, and all values are set to 0.0.
- The `setRangeText` method is called with the `initial_board` parameter to set the initial range text.\\
## Code: 
```
RangeSelectorTableModel::RangeSelectorTableModel(QStringList ranks,QString initial_board,QObject *parent,bool thumbnail):QAbstractItemModel(parent){
    this->ranklist = ranks;
    this->thumbnail = thumbnail;

    this->grids_string = vector<vector<QString>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_string[i] = vector<QString>(this->ranklist.size());
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_string[i][j] = this->get_ij_text(i,j);
            this->string2ij[this->get_ij_text(i,j)] = pair<int,int>(i,j);
        }
    }

    this->grids_float = vector<vector<float>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_float[i] = vector<float>(this->ranklist.size(),0.0);
    }
    this->setRangeText(initial_board);
}
```