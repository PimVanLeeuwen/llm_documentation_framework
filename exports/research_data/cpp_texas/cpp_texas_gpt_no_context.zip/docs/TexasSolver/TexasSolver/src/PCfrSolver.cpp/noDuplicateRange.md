`noDuplicateRange`: The function of `noDuplicateRange` is to filter out duplicate and invalid private card ranges based on a given board state.

**Code Description**: 
- The function `noDuplicateRange` takes two parameters: a vector of `PrivateCards` objects (`private_range`) and a `uint64_t` representing the board state (`board_long`).
- It initializes an empty vector `range_array` to store the filtered `PrivateCards` objects and an unordered map `rangekv` to keep track of the unique `PrivateCards` based on their hash codes.
- The function iterates over each `PrivateCards` object in `private_range`.
- For each `PrivateCards` object, it checks if its hash code already exists in `rangekv`. If it does, a runtime error is thrown indicating a duplicate key.
- If the hash code is unique, it is added to `rangekv`.
- The function then converts the hands of the `PrivateCards` object to a `uint64_t` representation (`hand_long`) using `Card::boardInts2long`.
- It checks if `hand_long` intersects with `board_long` using `Card::boardsHasIntercept`. If there is no intersection, the `PrivateCards` object is added to `range_array`.
- Finally, the function returns `range_array`, which contains the filtered `PrivateCards` objects without duplicates and invalid entries based on the board state.\\
## Code: 
```
vector<PrivateCards>
PCfrSolver::noDuplicateRange(const vector<PrivateCards> &private_range, uint64_t board_long) {
    vector<PrivateCards> range_array;
    unordered_map<int,bool> rangekv;
    for(PrivateCards one_range:private_range){
        if(rangekv.find(one_range.hashCode()) != rangekv.end())
            throw runtime_error(tfm::format("duplicated key %s",one_range.toString()));
        rangekv[one_range.hashCode()] = true;
        uint64_t hand_long = Card::boardInts2long(one_range.get_hands());
        if(!Card::boardsHasIntercept(hand_long,board_long)){
            range_array.push_back(one_range);
        }
    }
    return range_array;

}
```