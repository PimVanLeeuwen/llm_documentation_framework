`PokerSolver`: The function of `PokerSolver` is to initialize a poker solver object with a given set of card ranks, suits, and a comparison file.

**Code Description**: 
- The constructor `PokerSolver` takes four parameters: `ranks` (a string of card ranks separated by commas), `suits` (a string of card suits separated by commas), `compairer_file` (a string representing the path to a comparison file), `compairer_file_lines` (an integer representing the number of lines in the comparison file), and `compairer_file_bin` (a string representing the binary path of the comparison file).
- It splits the `ranks` and `suits` strings into vectors of strings using the `string_split` function.
- It initializes a `Deck` object with the vectors of ranks and suits.
- It creates a shared pointer to a `Dic5Compairer` object using the provided comparison file details and assigns it to the `compairer` member variable.\\
## Code: 
```
PokerSolver::PokerSolver(string ranks, string suits, string compairer_file,int compairer_file_lines, string compairer_file_bin) {
    vector<string> ranks_vector = string_split(ranks,',');
    vector<string> suits_vector = string_split(suits,',');
    this->deck = Deck(ranks_vector,suits_vector);
    this->compairer = make_shared<Dic5Compairer>(compairer_file,compairer_file_lines,compairer_file_bin);
}
```