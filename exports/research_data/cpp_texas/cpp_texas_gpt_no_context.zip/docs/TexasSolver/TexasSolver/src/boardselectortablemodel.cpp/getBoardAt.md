`getBoardAt`: The function of `getBoardAt` is to retrieve a floating-point value from a 2D grid at the specified row and column indices.

**Code Description**: The `getBoardAt` function takes two integer parameters, `i` and `j`, which represent the row and column indices, respectively. It first checks if the row index `i` is within the valid range (0 to the size of `ranklist` - 1). If `i` is out of bounds, it logs an error message and returns 0. Similarly, it checks if the column index `j` is within the valid range. If `j` is out of bounds, it logs an error message and returns 0. If both indices are valid, it returns the floating-point value located at the specified position in the `grids_float` 2D array.\\
## Code: 
```
float BoardSelectorTableModel::getBoardAt(int i, int j){
    if(i < 0 || i >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::getBoardAt i not valid: " << i;
        return 0;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::getBoardAt j not valid: " << j;
        return 0;
    }
    else{
        return this->grids_float[i][j];
    }
}
```