`convert`: The function of `convert` is to populate two maps, `flush_map` and `other_map`, based on the strength of five-card poker hands.

**Code Description**: 
- The function `convert` takes an unordered map `strength_map` as input, where the keys are 64-bit integers representing card combinations, and the values are integers representing the strength of those combinations.
- It first clears the `flush_map` and `other_map` to ensure they are empty before populating them.
- It then iterates through each entry in `strength_map`.
- For each entry, it calculates a hash of the card ranks using the `ranks_hash` function.
- It checks if the card combination is a flush using the `is_flush` function.
- If the combination is a flush, it adds the entry to `flush_map` with the original card combination as the key and its strength as the value.
- If the combination is not a flush, it adds the entry to `other_map` with the rank hash as the key and its strength as the value.\\
## Code: 
```
void FiveCardsStrength::convert(unordered_map<uint64_t, int>& strength_map) {
    flush_map.clear(); other_map.clear();
    auto it = strength_map.begin(), it_end = strength_map.end();
    for (; it != it_end; it++) {
        uint64_t cards_hash = it->first;
        uint64_t hash = ranks_hash(cards_hash);
        if (is_flush(cards_hash)) flush_map[cards_hash] = it->second;
        else {
            /*if (other_map.count(hash) && other_map[hash] != it->second) {
                printf("%zx,%zx:%d != %d\n", cards_hash, hash, it->second, other_map[hash]);
            }*/
            other_map[hash] = it->second;
        }
    }
}
```