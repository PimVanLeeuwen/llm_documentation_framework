`intToGameRound`: The function of `intToGameRound` is to convert an integer representing a game round into its corresponding `GameRound` enumeration value.

**Code Description**: The `intToGameRound` function takes an integer `round` as input and maps it to a `GameTreeNode::GameRound` enumeration value. The mapping is as follows: 0 to `PREFLOP`, 1 to `FLOP`, 2 to `TURN`, and 3 to `RIVER`. If the input integer does not match any of these cases, the function throws a runtime error indicating that the round is not found. The function returns the corresponding `GameRound` enumeration value based on the input integer.\\
## Code: 
```
GameTreeNode::GameRound GameTreeNode::intToGameRound(int round){
    GameTreeNode::GameRound game_round;
    switch(round){
        case 0:{
            game_round = GameTreeNode::GameRound::PREFLOP;
            break;
        }
        case 1:{
            game_round = GameTreeNode::GameRound::FLOP;
            break;
        }
        case 2:{
            game_round = GameTreeNode::GameRound::TURN;
            break;
        }
        case 3:{
            game_round = GameTreeNode::GameRound::RIVER;
            break;
        }
        default:{
            throw runtime_error(tfm::format("round %s not found",round));
        }
    }
    return game_round;
}
```