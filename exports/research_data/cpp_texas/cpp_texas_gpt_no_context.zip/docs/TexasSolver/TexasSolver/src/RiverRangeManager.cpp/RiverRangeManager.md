`RiverRangeManager`: The function of `RiverRangeManager` is to initialize an instance of the `RiverRangeManager` class with a given hand evaluator and a mutex for thread safety.

**Code Description**: 
- The constructor `RiverRangeManager(shared_ptr<Compairer> handEvaluator)` initializes a `RiverRangeManager` object.
- It takes a `shared_ptr` to a `Compairer` object as an argument, which is used to evaluate hands.
- The `handEvaluator` member variable is assigned the provided `handEvaluator` argument using `std::move` to transfer ownership.
- A `shared_ptr` to a `std::mutex` is created and assigned to the `maplock` member variable to ensure thread safety when accessing shared resources.\\
## Code: 
```
RiverRangeManager::RiverRangeManager(shared_ptr<Compairer> handEvaluator) {
    this->handEvaluator = std::move(handEvaluator);
    this->maplock = std::make_shared<std::mutex>();
}
```