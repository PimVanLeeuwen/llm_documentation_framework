`set_niter`: The function of `set_niter` is to set the number of iterations for the progress bar.

**Code Description**: The `set_niter` function takes an integer parameter `niter` and sets the member variable `n_cycles` to this value. If the provided `niter` is less than or equal to zero, the function throws an `std::invalid_argument` exception with a descriptive error message indicating that the number of iterations cannot be null or negative. This ensures that the progress bar is configured with a valid number of iterations.\\
## Code: 
```
void progressbar::set_niter(int niter) {
    if (niter <= 0) throw std::invalid_argument(
                "progressbar::set_niter: number of iterations null or negative");
    n_cycles = niter;
    return;
}
```