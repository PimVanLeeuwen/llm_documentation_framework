`operator[]`: The function of `operator[]` is to retrieve the strength value associated with a given hash.

**Code Description**: This function overloads the `operator[]` to allow accessing elements in a `FiveCardsStrength` object using a hash value. It first searches for the hash in the `flush_map`. If the hash is found, it returns the corresponding strength value. If the hash is not found in `flush_map`, it computes a new hash using the `ranks_hash` function and then retrieves the strength value from `other_map` using the new hash. If the new hash is not found in `other_map`, it will throw an exception since `at` is used, which checks for the existence of the key and throws an `out_of_range` exception if the key is not found.\\
## Code: 
```
int FiveCardsStrength::operator[](uint64_t hash) {
    auto it = flush_map.find(hash);
    if (it != flush_map.end()) return it->second;
    hash = ranks_hash(hash);
    return other_map.at(hash);
}
```