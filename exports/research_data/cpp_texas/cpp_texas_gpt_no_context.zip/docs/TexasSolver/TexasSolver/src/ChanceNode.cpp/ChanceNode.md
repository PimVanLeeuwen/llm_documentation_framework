`ChanceNode`: The function of `ChanceNode` is to initialize a new instance of the `ChanceNode` class, which represents a node in a game tree where chance events occur.

**Code Description**: 
- The constructor `ChanceNode` initializes a `ChanceNode` object with the following parameters:
  - `children`: A shared pointer to a `GameTreeNode` object representing the children of this node.
  - `round`: An enumeration value of type `GameTreeNode::GameRound` indicating the current round of the game.
  - `pot`: A double value representing the current pot size.
  - `parent`: A shared pointer to a `GameTreeNode` object representing the parent of this node.
  - `cards`: A vector of `Card` objects representing the cards involved in this chance event.
  - `donk`: A boolean value indicating whether a specific condition (donk) is true or false.
- The constructor initializes the base class `GameTreeNode` with `round`, `pot`, and `parent`.
- It then sets the `children` and `donk` attributes of the `ChanceNode` object to the provided values.
- The `cards` attribute is initialized using the member initializer list.\\
## Code: 
```
ChanceNode::ChanceNode(const shared_ptr<GameTreeNode> children, GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent,
                       const vector<Card>& cards,bool donk): GameTreeNode(round,pot,std::move(parent)),cards(cards) {
    this->children = children;
    this->donk = donk;
}
```