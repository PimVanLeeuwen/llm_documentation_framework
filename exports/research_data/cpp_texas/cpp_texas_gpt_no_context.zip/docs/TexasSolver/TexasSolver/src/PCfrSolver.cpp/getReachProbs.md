`getReachProbs`: The function of `getReachProbs` is to calculate and return the reach probabilities for each player in a game.

**Code Description**: This function, `getReachProbs`, returns a 2D vector of floats, where each inner vector contains the reach probabilities for a specific player. The outer vector has a size equal to the number of players (`this->player_number`). For each player, the function retrieves their private cards using `playerHands(player)`, which returns a vector of `PrivateCards`. It then initializes a `reach_prob` vector with the same size as the number of private cards. The reach probability for each card is set to the card's weight (`player_cards[i].weight`). Finally, the reach probabilities for each player are stored in the `retval` vector, which is returned at the end of the function.\\
## Code: 
```
vector<vector<float>> PCfrSolver::getReachProbs() {
    vector<vector<float>> retval(this->player_number);
    for(int player = 0;player < this->player_number;player ++){
        vector<PrivateCards> player_cards = this->playerHands(player);
        vector<float> reach_prob(player_cards.size());
        for(std::size_t i = 0;i < player_cards.size();i ++){
            reach_prob[i] = player_cards[i].weight;
        }
        retval[player] = reach_prob;
    }
    return retval;
}
```