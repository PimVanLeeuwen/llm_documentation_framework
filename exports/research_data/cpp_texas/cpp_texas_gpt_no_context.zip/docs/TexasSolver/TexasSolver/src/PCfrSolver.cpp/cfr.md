`cfr`: The function of `cfr` is to compute the counterfactual regret (CFR) for a given player at a specific node in the game tree.

**Code Description**: The `cfr` function takes in several parameters: the player index, a shared pointer to the current game tree node, a vector of reach probabilities, the current iteration number, the current board state, and the deal identifier. It determines the type of the current node and delegates the computation to the appropriate utility function based on the node type. The node types include `ACTION`, `SHOWDOWN`, `TERMINAL`, and `CHANCE`, each corresponding to different stages or actions in the game. If the node type is not recognized, the function throws a runtime error.\\
## Code: 
```
vector<float> PCfrSolver::cfr(int player, shared_ptr<GameTreeNode> node, const vector<float> &reach_probs, int iter,
                                    uint64_t current_board,int deal) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
            return actionUtility(player, action_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::SHOWDOWN: {
            shared_ptr<ShowdownNode> showdown_node = std::dynamic_pointer_cast<ShowdownNode>(node);
            return showdownUtility(player, showdown_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::TERMINAL: {
            shared_ptr<TerminalNode> terminal_node = std::dynamic_pointer_cast<TerminalNode>(node);
            return terminalUtility(player, terminal_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::CHANCE: {
            shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
            return chanceUtility(player, chance_node, reach_probs, iter, current_board,deal);
        }default:
            throw runtime_error("node type unknown");
    }
}
```