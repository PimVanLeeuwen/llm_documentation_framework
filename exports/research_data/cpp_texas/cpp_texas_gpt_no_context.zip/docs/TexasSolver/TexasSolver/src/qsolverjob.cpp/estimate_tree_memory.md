`estimate_tree_memory`: The function of `estimate_tree_memory` is to estimate the memory required for a decision tree based on the given ranges and board configuration for different poker modes.

**Code Description**: 
The `estimate_tree_memory` function in the `QSolverJob` class estimates the memory needed for a decision tree in a poker game. It takes three `QString` parameters: `range1`, `range2`, and `board`. The function first logs a debug message indicating that it is estimating tree memory. It then checks the mode of the poker game. If the mode is `HOLDEM`, it calls the `estimate_tree_memory` method of the `ps_holdem` object with the provided parameters. If the mode is `SHORTDECK`, it calls the `estimate_tree_memory` method of the `ps_shortdeck` object with the same parameters. If neither mode is set, the function returns 0.\\
## Code: 
```
long long QSolverJob::estimate_tree_memory(QString range1,QString range2,QString board){
    qDebug().noquote() << tr("Estimating tree memory..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        return ps_holdem.estimate_tree_memory(range1,range2,board);
    }else if(this->mode == Mode::SHORTDECK){
        return ps_shortdeck.estimate_tree_memory(range1,range2,board);
    }
    return 0;
}
```