`build_tree`: The function of `build_tree` is to construct a game tree based on the current mode of the game (either HOLDEM or SHORTDECK).

**Code Description**: The `build_tree` function starts by logging a message indicating the beginning of the tree-building process. It then checks the mode of the game. If the mode is HOLDEM, it calls the `build_game_tree` method of the `ps_holdem` object with various parameters related to the game state, such as commitments, current round, raise limit, blinds, stack size, and an all-in threshold. If the mode is SHORTDECK, it calls the `build_game_tree` method of the `ps_shortdeck` object with the same parameters. Finally, it logs a message indicating that the tree-building process has finished.\\
## Code: 
```
void QSolverJob::build_tree(){
    qDebug().noquote() << tr("building tree..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        ps_holdem.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }else if(this->mode == Mode::SHORTDECK){
        ps_shortdeck.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }
    qDebug().noquote() << tr("build tree finished");//.toStdString() << endl;
}
```