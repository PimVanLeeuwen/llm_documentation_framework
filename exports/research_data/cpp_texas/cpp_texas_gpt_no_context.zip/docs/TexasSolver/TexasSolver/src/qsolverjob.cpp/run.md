`run`: The function of `run` is to execute a specific task based on the current mission type.

**Code Description**: The `run` function in the `QSolverJob` class determines the task to execute by checking the `current_mission` attribute. It supports four mission types: `SOLVING`, `LOADING`, `BUILDTREE`, and `SAVING`. Depending on the mission type, it calls the corresponding method: `solving()`, `loading()`, `build_tree()`, or `saving()`. If the mission type is unsupported, it throws a `runtime_error`. Any exceptions are caught, and an error message is logged using `qDebug()`.\\
## Code: 
```
void QSolverJob::run()
{
    //QDebugStream qout(qDebug().noquote(), this->textEdit);
    try{
        if(this->current_mission == MissionType::SOLVING){
            this->solving();
        }else if(this->current_mission == MissionType::LOADING){
            this->loading();
        }else if(this->current_mission == MissionType::BUILDTREE){
            this->build_tree();
        }else if(this->current_mission == MissionType::SAVING){
            this->saving();
        }else{
            throw runtime_error("unsupported mission type");
        }
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```