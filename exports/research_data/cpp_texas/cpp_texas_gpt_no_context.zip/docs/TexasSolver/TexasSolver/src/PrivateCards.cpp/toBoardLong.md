`toBoardLong`: The function of `toBoardLong` is to return the value of the `board_long` member variable of the `PrivateCards` object.

**Code Description**: This method, `toBoardLong`, is a member function of the `PrivateCards` class. When called, it returns the value of the `board_long` attribute, which is of type `uint64_t`. The commented-out line suggests that there might be an alternative implementation that converts a vector of cards (`card_vec`) to a long integer representation using a function `Card::boardInts2long`, but this is not currently in use.\\
## Code: 
```
uint64_t PrivateCards::toBoardLong() {
    return this->board_long;
    //return Card::boardInts2long(this->card_vec);
}
```