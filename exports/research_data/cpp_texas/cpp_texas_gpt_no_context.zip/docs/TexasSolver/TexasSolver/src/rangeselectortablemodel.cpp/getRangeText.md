`getRangeText`: The function of `getRangeText` is to generate a comma-separated string representation of non-zero grid values from a 2D array.

**Code Description**: 
- The function `getRangeText` initializes an empty string `retval`.
- It iterates over a 2D array `grids_float` using nested loops.
- For each non-zero element in `grids_float`, it constructs a string `one_range_str` in the format "string_value:float_value", where `string_value` is taken from the corresponding position in `grids_string` and `float_value` is the non-zero float value formatted to three decimal places.
- If `retval` is empty, it assigns `one_range_str` to `retval`. Otherwise, it appends `one_range_str` to `retval`, separated by a comma.
- Finally, the function returns the constructed `retval` string.\\
## Code: 
```
QString RangeSelectorTableModel::getRangeText(){
    QString retval = "";
    for(int i = 0;i < this->ranklist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            if(this->grids_float[i][j] == 0)continue;
            QString one_range_str = QString("%1:%2").arg(this->grids_string[i][j],QString::number(this->grids_float[i][j],'f',3));
            if(retval == ""){
                retval = one_range_str;
            }else{
                retval = retval + "," + one_range_str;
            }
        }
    }
    return retval;
}
```