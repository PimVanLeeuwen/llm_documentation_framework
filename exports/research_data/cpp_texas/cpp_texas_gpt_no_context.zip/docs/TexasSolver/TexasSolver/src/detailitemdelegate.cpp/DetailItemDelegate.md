`DetailItemDelegate`: The function of `DetailItemDelegate` is to initialize a `DetailItemDelegate` object with a given `DetailWindowSetting` and an optional parent object.

**Code Description**: 
- The constructor `DetailItemDelegate` takes two parameters: a pointer to a `DetailWindowSetting` object and an optional pointer to a `QObject` parent.
- It calls the constructor of its base class `WordItemDelegate` with the `parent` parameter.
- It assigns the provided `detailWindowSetting` to the member variable `this->detailWindowSetting`.\\
## Code: 
```
DetailItemDelegate::DetailItemDelegate(DetailWindowSetting* detailWindowSetting,QObject *parent) :
    WordItemDelegate(parent)
{
    this->detailWindowSetting = detailWindowSetting;
}
```