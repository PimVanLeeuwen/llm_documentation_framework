`setChildrens`: The function of `setChildrens` is to set the child nodes of the current `ActionNode` object.

**Code Description**: This method, `setChildrens`, takes a constant reference to a vector of shared pointers to `GameTreeNode` objects as its parameter. It assigns this vector to the `childrens` member variable of the `ActionNode` class. This effectively updates the child nodes of the current `ActionNode` instance to the provided vector of `GameTreeNode` objects.\\
## Code: 
```
void ActionNode::setChildrens(const vector<shared_ptr<GameTreeNode>> &childrens) {
    ActionNode::childrens = childrens;
}
```