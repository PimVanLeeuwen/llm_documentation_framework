`execFromFile`: The function of `execFromFile` is to read commands from a specified file and process each command line by line.

**Code Description**: 
- The function `execFromFile` takes a single parameter `input_file`, which is a string representing the path to the input file.
- It opens the file using an `std::ifstream` object named `infile`.
- It reads the file line by line using a `while` loop and the `std::getline` function, storing each line in the `input_line` string variable.
- For each line read from the file, it calls the `processCommand` method on the current object (`this`), passing the line as an argument.
- The function continues to read and process lines until the end of the file is reached.\\
## Code: 
```
void CommandLineTool::execFromFile(string input_file){
    std::ifstream infile(input_file);
    std::string input_line;
    while (std::getline(infile, input_line))
    {
        this->processCommand(input_line);
    }

}
```