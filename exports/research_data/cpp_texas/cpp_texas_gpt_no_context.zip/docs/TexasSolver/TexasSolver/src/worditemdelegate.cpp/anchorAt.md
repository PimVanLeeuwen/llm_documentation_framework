`anchorAt`: The function of `anchorAt` is to find and return the anchor (hyperlink) at a specified point within an HTML document.

**Code Description**: 
- The `anchorAt` function takes an HTML string and a `QPoint` object as input parameters.
- It creates a `QTextDocument` object and sets its content to the provided HTML string.
- It retrieves the document layout from the `QTextDocument` object.
- It asserts that the document layout is not null.
- It calls the `anchorAt` method on the document layout, passing the specified point, and returns the result, which is the anchor (hyperlink) at that point in the HTML document.\\
## Code: 
```
QString WordItemDelegate::anchorAt(QString html, const QPoint &point) const {
    QTextDocument doc;
    doc.setHtml(html);

    auto textLayout = doc.documentLayout();
    Q_ASSERT(textLayout != 0);
    return textLayout->anchorAt(point);
}
```