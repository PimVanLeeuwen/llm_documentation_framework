`getType`: The function of `getType` is to return the type of the node.

**Code Description**: This method, `getType`, is a member of the `ShowdownNode` class. When called, it returns a value of the enumeration `GameTreeNode::GameTreeNodeType`, specifically the constant `SHOWDOWN`. This indicates that the type of the current node is a showdown node.\\
## Code: 
```
GameTreeNode::GameTreeNodeType ShowdownNode::getType() {
    return SHOWDOWN;
}
```