`columnCount`: The function of `columnCount` is to return the number of columns in the table model.

**Code Description**: This method, `columnCount`, is a member of the `RoughStrategyViewerModel` class. It takes a constant reference to a `QModelIndex` object named `parent` as its parameter, although this parameter is not used within the function. The method returns an integer representing the number of columns in the table model by accessing the `total_strategy` member of the `tableStrategyModel` object and returning its size. This indicates that the number of columns is determined by the size of the `total_strategy` container.\\
## Code: 
```
int RoughStrategyViewerModel::columnCount(const QModelIndex &parent) const
{
    return this->tableStrategyModel->total_strategy.size();
}
```