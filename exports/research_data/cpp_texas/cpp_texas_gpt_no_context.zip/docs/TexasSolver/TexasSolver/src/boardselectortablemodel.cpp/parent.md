`parent`: The function of `parent` is to return the parent index of a given child index.

**Code Description**: This `parent` function is a member of the `BoardSelectorTableModel` class. It takes a `QModelIndex` object named `child` as an argument and returns a `QModelIndex` object. In this implementation, the function always returns an invalid `QModelIndex` object, which indicates that the model does not have a hierarchical structure and all items are top-level with no parent-child relationships.\\
## Code: 
```
QModelIndex BoardSelectorTableModel::parent(const QModelIndex &child) const {
    return QModelIndex();
}
```