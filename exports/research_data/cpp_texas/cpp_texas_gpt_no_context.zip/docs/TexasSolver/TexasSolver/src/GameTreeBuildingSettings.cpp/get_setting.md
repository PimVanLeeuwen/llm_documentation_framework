`get_setting`: The function of `get_setting` is to retrieve the appropriate `StreetSetting` based on the player's position and the current round in a game.

**Code Description**: The `get_setting` function takes two string parameters, `player` and `round`. It checks the combination of these parameters to determine which `StreetSetting` to return. If the player is "ip" (in position) and the round is "flop", it returns `flop_ip`. If the player is "ip" and the round is "turn", it returns `turn_ip`. If the player is "ip" and the round is "river", it returns `river_ip`. Similarly, if the player is "oop" (out of position) and the round is "flop", it returns `flop_oop`. If the player is "oop" and the round is "turn", it returns `turn_oop`. If the player is "oop" and the round is "river", it returns `river_oop`. If none of these conditions are met, it throws a runtime error indicating that the combination of player and round is not valid.\\
## Code: 
```
StreetSetting& GameTreeBuildingSettings::get_setting(string player,string round){
    if(player == "ip" && round == "flop") return flop_ip;
    else if(player == "ip" && round == "turn") return turn_ip;
    else if(player == "ip" && round == "river") return river_ip;
    else if(player == "oop" && round == "flop") return flop_oop;
    else if(player == "oop" && round == "turn") return turn_oop;
    else if(player == "oop" && round == "river") return river_oop;
    else throw runtime_error("get_setting not valid");
}
```