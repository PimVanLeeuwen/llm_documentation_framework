`Rule`: The function of `Rule` is to initialize a set of game rules and settings for a poker game.

**Code Description**: 
The `Rule` constructor initializes a `Rule` object with various parameters related to the game settings. These parameters include:
- `deck`: An object representing the deck of cards used in the game.
- `oop_commit`: A float representing the amount committed by the out-of-position player.
- `ip_commit`: A float representing the amount committed by the in-position player.
- `current_round`: An integer indicating the current round of the game.
- `raise_limit`: An integer specifying the limit on the number of raises allowed.
- `small_blind`: A float representing the small blind amount.
- `big_blind`: A float representing the big blind amount.
- `stack`: A float representing the stack size of the players.
- `build_settings`: An object containing settings for building the game tree.
- `allin_threshold`: A float representing the threshold for going all-in.

The constructor also checks if the committed amounts by both players (`oop_commit` and `ip_commit`) are equal. If they are not, it throws a runtime error with the message "ip commit should equal with oop commit". Finally, it sets the `initial_effective_stack` to the provided stack size.\\
## Code: 
```
Rule::Rule(Deck deck, float oop_commit, float ip_commit, int current_round, int raise_limit, float small_blind,
           float big_blind, float stack, GameTreeBuildingSettings build_settings,float allin_threshold):
           deck(deck),oop_commit(oop_commit),ip_commit(ip_commit),current_round(current_round),raise_limit(raise_limit),
           small_blind(small_blind),big_blind(big_blind),stack(stack),build_settings(build_settings),allin_threshold(allin_threshold){
    if(oop_commit != ip_commit) throw runtime_error("ip commit should equal with oop commit");
    this->initial_effective_stack = stack;
}
```