`DiscountedCfrTrainable`: The function of `DiscountedCfrTrainable` is to initialize an object that manages the training of a Counterfactual Regret Minimization (CFR) algorithm with discounting for a given set of private cards and an action node.

**Code Description**: 
- The constructor `DiscountedCfrTrainable` takes two parameters: a pointer to a vector of `PrivateCards` and a reference to an `ActionNode`.
- It initializes the `privateCards` member variable with the provided pointer to the vector of `PrivateCards`.
- It initializes the `action_node` member variable with the provided `ActionNode` reference.
- It sets the `action_number` member variable to the number of children of the `action_node`.
- It sets the `card_number` member variable to the size of the `privateCards` vector.
- It initializes the `evs` vector with a size of `action_number * card_number`, filled with zeros. This vector likely stores expected values for each action and card combination.
- It initializes the `r_plus` vector with a size of `action_number * card_number`, filled with zeros. This vector likely stores positive regrets for each action and card combination.
- It initializes the `r_plus_sum` vector with a size of `card_number`, filled with zeros. This vector likely stores the sum of positive regrets for each card.
- It initializes the `cum_r_plus` vector with a size of `action_number * card_number`, filled with zeros. This vector likely stores cumulative positive regrets for each action and card combination.
- The commented-out line suggests that there was an intention to initialize a `cum_r_plus_sum` vector with a size of `card_number`, but it is not currently in use.\\
## Code: 
```
DiscountedCfrTrainable::DiscountedCfrTrainable(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();

    this->evs = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus_sum = vector<float>(this->card_number,0.0);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number,0.0);
    //this->cum_r_plus_sum = vector<float>(this->card_number);
}
```