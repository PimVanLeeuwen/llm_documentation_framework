`parent`: The function of `parent` is to return the parent index of a given child index in a model.

**Code Description**: This `parent` function is a member of the `RoughStrategyViewerModel` class. It takes a `QModelIndex` object named `child` as an argument and returns a `QModelIndex` object. In this implementation, the function always returns an invalid `QModelIndex` (i.e., a default-constructed `QModelIndex`), indicating that the given child index does not have a parent. This could imply that the model is either flat (with no hierarchical structure) or that the parent-child relationships are not being utilized in this specific model.\\
## Code: 
```
QModelIndex RoughStrategyViewerModel::parent(const QModelIndex &child) const{
    return QModelIndex();
}
```