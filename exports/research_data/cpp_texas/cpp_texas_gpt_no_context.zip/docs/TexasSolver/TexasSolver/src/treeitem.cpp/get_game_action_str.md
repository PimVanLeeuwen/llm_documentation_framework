`get_game_action_str`: The function of `get_game_action_str` is to convert a given poker action and an optional amount into a corresponding QString representation.

**Code Description**: 
- The function `get_game_action_str` takes two parameters: a `PokerActions` enum value named `action` and a float named `amount`.
- It checks the value of the `action` parameter and returns a localized string representation of the action.
- If the action is `CHECK`, it returns the string "CHECK".
- If the action is `BET`, it returns the string "BET " followed by the `amount` converted to a string.
- If the action is `RAISE`, it returns the string "RAISE " followed by the `amount` converted to a string.
- If the action is `FOLD`, it returns the string "FOLD".
- If the action is `CALL`, it returns the string "CALL".
- If the action does not match any of the predefined cases, it throws a runtime error indicating an unknown action.\\
## Code: 
```
QString TreeItem::get_game_action_str(GameTreeNode::PokerActions action,float amount) const{
    if(action == GameTreeNode::PokerActions::CHECK){
        return QObject::tr("CHECK");
    }
    else if(action == GameTreeNode::PokerActions::BET){
        return QObject::tr("BET ") + QString::number(amount);
    }
    else if(action == GameTreeNode::PokerActions::RAISE){
        return QObject::tr("RAISE ") + QString::number(amount);
    }
    else if(action == GameTreeNode::PokerActions::FOLD){
        return QObject::tr("FOLD ");
    }
    else if(action == GameTreeNode::PokerActions::CALL){
        return QObject::tr("CALL");
    }else{
        throw runtime_error("unknown action when converting in get_game_action_str");
    }

}
```