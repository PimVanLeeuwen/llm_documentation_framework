`ActionNode`: The function of `ActionNode` is to initialize an `ActionNode` object, which represents a node in a game tree with specific actions, child nodes, player information, game round, pot value, and a parent node.

**Code Description**: 
- The constructor `ActionNode` takes the following parameters:
  - `vector<GameActions> actions`: A vector of game actions associated with this node.
  - `vector<shared_ptr<GameTreeNode>> childrens`: A vector of shared pointers to child nodes of this node.
  - `int player`: The player associated with this node.
  - `GameTreeNode::GameRound round`: The game round associated with this node.
  - `double pot`: The pot value associated with this node.
  - `shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node of this node.
- The constructor initializes the base class `GameTreeNode` with `round`, `pot`, and `parent`.
- It then assigns the provided `actions`, `player`, and `childrens` to the corresponding member variables of the `ActionNode` object.
- The commented-out line `//cout << "ActionNode created" << endl;` suggests that there was originally a debug print statement to indicate the creation of an `ActionNode` object.\\
## Code: 
```
ActionNode::ActionNode(vector<GameActions> actions, vector<shared_ptr<GameTreeNode>> childrens, int player,
                       GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent) :GameTreeNode(round,pot,std::move(parent)){
    this->actions = std::move(actions);
    this->player = player;
    this->childrens = std::move(childrens);
    //cout << "ActionNode created" << endl;
}
```