`toString`: The function of `toString` is to return a string representation of two private cards in a specific order.

**Code Description**: The `toString` method in the `PrivateCards` class compares two card values, `card1` and `card2`. It uses the `Card::intCard2Str` method to convert these integer card values to their string representations. If `card1` is greater than `card2`, the method returns the string representation of `card1` followed by the string representation of `card2`. Otherwise, it returns the string representation of `card2` followed by the string representation of `card1`. This ensures that the resulting string always lists the higher card first.\\
## Code: 
```
string PrivateCards::toString() {
    if (card1 > card2) {
        return Card::intCard2Str(card1) + Card::intCard2Str(card2);
    }else{
        return Card::intCard2Str(card2) + Card::intCard2Str(card1);
    }
}
```