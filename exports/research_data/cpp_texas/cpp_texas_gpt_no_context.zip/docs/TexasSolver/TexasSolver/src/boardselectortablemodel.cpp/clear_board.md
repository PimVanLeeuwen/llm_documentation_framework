`clear_board`: The function of `clear_board` is to reset all elements in the `grids_float` 2D array to zero.

**Code Description**: The `clear_board` method iterates through each element of the `grids_float` 2D array, which is indexed by `suitlist` and `ranklist`. For each element, it sets the value to zero, effectively clearing or resetting the board. The outer loop runs through the indices of `suitlist`, and the inner loop runs through the indices of `ranklist`.\\
## Code: 
```
void BoardSelectorTableModel::clear_board(){
    for(int i = 0;i < this->suitlist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_float[i][j] = 0;
        }
    }
}
```