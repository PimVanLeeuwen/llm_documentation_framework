`GameTreeNode`: The function of `GameTreeNode` is to initialize a new node in a game tree with a specified game round, pot value, and parent node.

**Code Description**: This constructor for the `GameTreeNode` class takes three parameters: `round` (of type `GameTreeNode::GameRound`), `pot` (of type `double`), and `parent` (a shared pointer to another `GameTreeNode`). It initializes the member variables `round`, `pot`, and `parent` with the provided arguments. The `parent` pointer is moved to ensure efficient transfer of ownership.\\
## Code: 
```
GameTreeNode::GameTreeNode(GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent) {
    this->round = round;
    this->pot = pot;
    this->parent = std::move(parent);
}
```