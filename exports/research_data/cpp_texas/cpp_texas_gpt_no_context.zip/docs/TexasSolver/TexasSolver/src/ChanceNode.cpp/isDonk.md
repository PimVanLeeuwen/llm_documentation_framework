`isDonk`: The function of `isDonk` is to check if the `donk` attribute of the `ChanceNode` object is set to `true`.

**Code Description**: This method, `isDonk`, is a member function of the `ChanceNode` class. It returns a boolean value indicating the state of the `donk` attribute of the `ChanceNode` instance. If `donk` is `true`, the method returns `true`; otherwise, it returns `false`.\\
## Code: 
```
bool ChanceNode::isDonk(){
    return this->donk;
}
```