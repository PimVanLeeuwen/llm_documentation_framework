`estimate_tree_memory`: The function of `estimate_tree_memory` is to estimate the memory usage of a game tree based on the provided player ranges and the board state.

**Code Description**: 
- The function `estimate_tree_memory` takes three parameters: `range1` (a QString representing the range of the first player), `range2` (a QString representing the range of the second player), and `board` (a QString representing the current board state).
- It first checks if the `game_tree` member is `nullptr`. If it is, it logs a message indicating that the tree needs to be built first and returns 0.
- If the `game_tree` is not `nullptr`, it converts the player ranges from QString to standard strings.
- It then splits the board string into individual card strings and converts these to integers representing the cards.
- The function converts the player ranges from strings to `PrivateCards` objects, taking into account the initial board state.
- Finally, it calls the `estimate_tree_memory` method of the `game_tree` object, passing the number of remaining cards in the deck and the sizes of the two player ranges, and returns the estimated memory usage.\\
## Code: 
```
long long PokerSolver::estimate_tree_memory(QString range1,QString range2,QString board){
    if(this->game_tree == nullptr){
        qDebug().noquote() << QObject::tr("Please buld tree first.");
        return 0;
    }
    else{
        string player1RangeStr = range1.toStdString();
        string player2RangeStr = range2.toStdString();

        vector<string> board_str_arr = string_split(board.toStdString(),',');
        vector<int> initialBoard;
        for(string one_board_str:board_str_arr){
            initialBoard.push_back(Card::strCard2int(one_board_str));
        }

        vector<PrivateCards> range1 = PrivateRangeConverter::rangeStr2Cards(player1RangeStr,initialBoard);
        vector<PrivateCards> range2 = PrivateRangeConverter::rangeStr2Cards(player2RangeStr,initialBoard);
        return this->game_tree->estimate_tree_memory(this->deck.getCards().size() - initialBoard.size(),range1.size(),range2.size());
    }
}
```