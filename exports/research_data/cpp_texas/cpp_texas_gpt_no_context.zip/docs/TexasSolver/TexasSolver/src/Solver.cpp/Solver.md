`Solver`: The function of `Solver` is to initialize a `Solver` object with a given `GameTree`.

**Code Description**: The constructor `Solver::Solver(shared_ptr<GameTree> tree)` initializes a `Solver` object by assigning the provided `shared_ptr<GameTree>` to the member variable `tree` of the `Solver` class. This allows the `Solver` object to have access to the `GameTree` for further operations.\\
## Code: 
```
Solver::Solver(shared_ptr<GameTree> tree) {
    this->tree = tree;
}
```