`pokerActionToString`: The function of `pokerActionToString` is to convert a `PokerActions` enum value to its corresponding string representation.

**Code Description**: This function takes an enum value of type `GameTreeNode::PokerActions` as input and returns a string that represents the action. The function uses a switch statement to match the input enum value to its corresponding string. If the input value is `BEGIN`, `ROUNDBEGIN`, `BET`, `RAISE`, `CHECK`, `FOLD`, or `CALL`, the function returns the respective string. If the input value does not match any of these cases, the function throws a runtime error indicating that the `PokerActions` value was not found.\\
## Code: 
```
string GameActions::pokerActionToString(GameTreeNode::PokerActions pokerActions) {
    switch (pokerActions)
    {
        case GameTreeNode::PokerActions::BEGIN :   return "BEGIN";
        case GameTreeNode::PokerActions::ROUNDBEGIN :   return "ROUNDBEGIN";
        case GameTreeNode::PokerActions::BET :   return "BET";
        case GameTreeNode::PokerActions::RAISE :   return "RAISE";
        case GameTreeNode::PokerActions::CHECK :   return "CHECK";
        case GameTreeNode::PokerActions::FOLD :   return "FOLD";
        case GameTreeNode::PokerActions::CALL :   return "CALL";
        default:{
            throw runtime_error("PokerActions not found");
        }
    }
}
```