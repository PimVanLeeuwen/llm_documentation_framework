`clear_range`: The function of `clear_range` is to reset all elements in the `grids_float` 2D array to zero.

**Code Description**: The `clear_range` method iterates through each element of the `grids_float` 2D array, which is assumed to be a square matrix based on the nested loops using the size of `ranklist`. For each element, it sets the value to zero, effectively clearing or resetting the grid.\\
## Code: 
```
void RangeSelectorTableModel::clear_range(){
    for(int i = 0;i < this->ranklist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_float[i][j] = 0;
        }
    }
}
```