`PrivateCardsManager`: The function of `PrivateCardsManager` is to initialize and manage private card combinations for a given number of players in a card game.

**Code Description**: 
- The constructor `PrivateCardsManager` initializes the private card combinations for each player, sets up an index to track the players' cards, and prepares the initial board state.
- `private_cards` is a 2D vector where each sub-vector contains the private card combinations for a specific player.
- `player_number` is the total number of players in the game.
- `initialboard` is a 64-bit integer representing the initial state of the board.
- `card_player_index` is a 2D vector where each element is a vector of integers initialized to -1. It is used to map each card combination to the corresponding player and their index.
- The nested loops populate `card_player_index` with the indices of the private card combinations for each player.
- The method `setRelativeProbs` is called at the end to set up relative probabilities, though its implementation is not shown in the provided code.\\
## Code: 
```
PrivateCardsManager::PrivateCardsManager(vector<vector<PrivateCards>> private_cards, int player_number,
                                         uint64_t initialboard) {
    this->private_cards = private_cards;
    this->player_number = player_number;
    this->card_player_index = vector<vector<int>>(52 * 52);
    for(int i = 0;i < 52 * 52;i ++){
        this->card_player_index[i] = vector<int>(this->player_number,-1);
    }

    // 用一个二维数组记录每个Private Combo的对应index,方便从一方的手牌找对方的同名卡牌的index
    for(int player_id = 0;player_id < player_number;player_id ++){
        vector<PrivateCards> privateCombos = private_cards[player_id];
        for(std::size_t i = 0;i < privateCombos.size();i ++){
            PrivateCards one_private_combo = privateCombos[i];
            this->card_player_index[one_private_combo.hashCode()][player_id] = i;
        }
    }

    this->initialboard = initialboard;
    this->setRelativeProbs();
}
```