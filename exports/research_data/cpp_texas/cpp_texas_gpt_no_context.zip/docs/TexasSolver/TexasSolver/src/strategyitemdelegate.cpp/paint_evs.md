`paint_evs`: The function of `paint_evs` is to render a visual representation of expected values (EVs) in a table cell using a gradient color scheme.

**Code Description**: 
- The function `paint_evs` is a member of the `StrategyItemDelegate` class and is used to customize the painting of table cells in a Qt application.
- It takes a `QPainter` pointer, a `QStyleOptionViewItem` reference, and a `QModelIndex` reference as parameters.
- The function initializes the style options for the item using `initStyleOption`.
- It retrieves the `TableStrategyModel` from the model associated with the `QModelIndex`.
- It fetches the EV grid for the specified row and column and sorts the EVs in ascending order.
- The function then iterates through the sorted EVs, normalizes each EV using a hyperbolic tangent function, and calculates the corresponding color.
- The color is determined by mapping the normalized EV to a gradient between red and green.
- It fills the cell with colored rectangles, each representing a portion of the EVs.
- The function uses a `QTextDocument` to handle any HTML text that needs to be rendered within the cell.
- Finally, it translates the painter to the top-left corner of the cell and draws the contents of the `QTextDocument` within the cell's rectangle.\\
## Code: 
```
void StrategyItemDelegate::paint_evs(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);
    const TableStrategyModel * tableStrategyModel = qobject_cast<const TableStrategyModel*>(index.model());
    vector<float> evs = tableStrategyModel->get_ev_grid(index.row(),index.column());
    sort(evs.begin(), evs.end());

    int last_left = 0;
    for(std::size_t i = 0;i < evs.size();i ++ ){
        float one_ev = evs[evs.size() - i - 1];
        float normalized_ev = normalization_tanh(this->qSolverJob->stack,one_ev);
        //options.text += QString("</br>%1").arg(QString::number(normalized_ev));

        int red = max((int)(255 - normalized_ev * 255),0);
        int green = min((int)(normalized_ev * 255),255);
        int blue = min(red, green);

        QBrush brush = QBrush(QColor(red,green,blue));

        int this_width = (int)((float(i + 1) / evs.size()) * options.rect.width()) - last_left;

        QRect rect(option.rect.left() + last_left, option.rect.top(),\
             this_width , (int) (options.rect.height()));
        painter->fillRect(rect, brush);
        last_left += this_width;
    }
    QTextDocument doc;
    doc.setHtml(options.text);
    options.text = "";
    //options.widget->style()->drawControl(QStyle::CE_ItemViewItem, &option, painter);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```