`loading`: The function of `loading` is to initialize and load the necessary resources for the PokerSolver objects used in both holdem and shortdeck poker games.

**Code Description**: 
- The function starts by defining the suits and ranks for the poker cards.
- It sets the `resource_dir` to the path where the resource files are located.
- It then prints a debug message indicating the start of loading the holdem comparing file.
- For holdem poker, it sets the ranks, file paths for the comparing files, and the number of lines in the file.
- It initializes the `ps_holdem` PokerSolver object with these parameters.
- It prints a debug message indicating the start of loading the shortdeck comparing file.
- For shortdeck poker, it sets the ranks, file paths for the comparing files, and the number of lines in the file.
- It initializes the `ps_shortdeck` PokerSolver object with these parameters.
- Finally, it prints a debug message indicating that the loading process is finished.\\
## Code: 
```
void QSolverJob::loading(){
    string suits = "c,d,h,s";
    string ranks;
    this->resource_dir =  ":/resources";
    string compairer_file, compairer_file_bin;
    int lines;
    qDebug().noquote() << tr("Loading holdem compairing file");//.toStdString() << endl;
    //if(mode == "holdem"){
    ranks = "2,3,4,5,6,7,8,9,T,J,Q,K,A";
    compairer_file = this->resource_dir + "/compairer/card5_dic_sorted.txt";
    compairer_file_bin = this->resource_dir + "/compairer/card5_dic_zipped.bin";
    //qDebug().noquote() << compairer_file_bin.c_str();
    lines = 2598961;
    this->ps_holdem = PokerSolver(ranks,suits,compairer_file,lines,compairer_file_bin);

    qDebug().noquote() << tr("Loading shortdeck compairing file");//.toStdString() << endl;
    //}else if(mode == "shortdeck"){
    ranks = "6,7,8,9,T,J,Q,K,A";
    compairer_file = this->resource_dir + "/compairer/card5_dic_sorted_shortdeck.txt";
    compairer_file_bin = this->resource_dir + "/compairer/card5_dic_zipped_shortdeck.bin";
    lines = 376993;
    this->ps_shortdeck = PokerSolver(ranks,suits,compairer_file,lines,compairer_file_bin);
    qDebug().noquote() << tr("Loading finished. Good to go.");//.toStdString() << endl;
}
```