`progressbar`: The function of `progressbar` is to initialize a progress bar object with specified parameters.

**Code Description**: 
The `progressbar` constructor initializes a progress bar with the following parameters:
- `n`: The total number of cycles or steps the progress bar will represent.
- `showbar`: A boolean indicating whether the progress bar should be displayed.

The constructor sets the following member variables:
- `progress` to 0, representing the initial progress.
- `n_cycles` to `n`, representing the total number of cycles.
- `last_perc` to 0, representing the last percentage of progress displayed.
- `do_show_bar` to `showbar`, determining if the progress bar should be shown.
- `update_is_called` to false, indicating that the update function has not been called yet.
- `done_char` to "#", representing the character used to display completed progress.
- `todo_char` to " ", representing the character used to display remaining progress.
- `opening_bracket_char` to "[", representing the opening bracket of the progress bar.
- `closing_bracket_char` to "]", representing the closing bracket of the progress bar.\\
## Code: 
```
progressbar::progressbar(int n, bool showbar) :
        progress(0),
        n_cycles(n),
        last_perc(0),
        do_show_bar(showbar),
        update_is_called(false),
        done_char("#"),
        todo_char(" "),
        opening_bracket_char("["),
        closing_bracket_char("]") {}
```