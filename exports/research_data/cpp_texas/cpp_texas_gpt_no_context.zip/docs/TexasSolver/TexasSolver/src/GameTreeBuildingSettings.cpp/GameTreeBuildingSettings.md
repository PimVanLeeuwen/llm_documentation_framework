`GameTreeBuildingSettings`: The function of `GameTreeBuildingSettings` is to initialize the settings for building a game tree with specific configurations for different streets in a poker game.

**Code Description**: The constructor `GameTreeBuildingSettings` takes six parameters: `flop_ip`, `turn_ip`, `river_ip`, `flop_oop`, `turn_oop`, and `river_oop`, which are of type `StreetSetting`. These parameters represent the settings for the flop, turn, and river streets for both in-position (ip) and out-of-position (oop) players. The constructor initializes the corresponding member variables with the provided values.\\
## Code: 
```
GameTreeBuildingSettings::GameTreeBuildingSettings(
        StreetSetting flop_ip,
        StreetSetting turn_ip,
        StreetSetting river_ip,
        StreetSetting flop_oop,
        StreetSetting turn_oop,
        StreetSetting river_oop):flop_ip(flop_ip),turn_ip(turn_ip),river_ip(river_ip),flop_oop(flop_oop),turn_oop(turn_oop),river_oop(river_oop) {
}
```