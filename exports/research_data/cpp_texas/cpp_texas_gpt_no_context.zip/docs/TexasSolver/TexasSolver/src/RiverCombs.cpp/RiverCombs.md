`RiverCombs`: The function of `RiverCombs` is to initialize an object with the given board, private cards, rank, and reach probability index.

**Code Description**: The constructor `RiverCombs` takes four parameters: `board` (a vector of integers), `private_cards` (an object of type `PrivateCards`), `rank` (an integer), and `reach_prob_index` (an integer). It initializes the object's member variables `board`, `private_cards`, `rank`, and `reach_prob_index` with the provided values.\\
## Code: 
```
RiverCombs::RiverCombs(vector<int> board, PrivateCards private_cards, int rank, int reach_prob_index) {
    this->board = board;
    this->rank = rank;
    this->private_cards = private_cards;
    this->reach_prob_index = reach_prob_index;
}
```