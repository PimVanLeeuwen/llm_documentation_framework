`solving`: The function of `solving` is to initiate and manage the training process for different poker game modes (HOLDEM and SHORTDECK) based on the specified parameters.

**Code Description**: 
- The function starts by printing a debug message indicating the start of the solving process.
- It checks the mode of the solver (`HOLDEM` or `SHORTDECK`).
- Depending on the mode, it calls the `train` method of either `ps_holdem` or `ps_shortdeck` with the following parameters:
  - `range_ip`: The range of hands for the in-position player.
  - `range_oop`: The range of hands for the out-of-position player.
  - `board`: The current board state.
  - An empty string (possibly for additional configuration or logging).
  - `max_iteration`: The maximum number of iterations for the training process.
  - `print_interval`: The interval at which progress is printed.
  - `"discounted_cfr"`: The algorithm used for training.
  - `-1`: A placeholder or default value for an unspecified parameter.
  - `accuracy`: The desired accuracy of the training.
  - `use_isomorphism`: A flag indicating whether to use isomorphism in the training.
  - `use_halffloats`: A flag indicating whether to use half-precision floats.
  - `thread_number`: The number of threads to use for the training process.
- After the training process is complete, it prints another debug message indicating the end of the solving process.\\
## Code: 
```
void QSolverJob::solving(){
    // TODO  为什么ui上多次求解会积累memory？哪里leak了？
    // TODO  为什么有时候会莫名闪退？
    qDebug().noquote() << tr("Start Solving..");//.toStdString() << std::endl;

    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }
    qDebug().noquote() << tr("Solving done.");//.toStdString() << std::endl;
}
```