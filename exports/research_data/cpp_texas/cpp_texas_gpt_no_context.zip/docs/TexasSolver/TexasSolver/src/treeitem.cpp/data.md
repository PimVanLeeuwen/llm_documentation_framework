`data`: The function of `data` is to return a string representation of the current game tree node's state based on its type and context within the tree.

**Code Description**: 
- The function first retrieves the parent node and the current node from the `m_treedata` member variable.
- If the parent node is `nullptr`, it returns a string indicating the beginning of the round.
- If the parent node is of type `ACTION`, it iterates through the parent's children to find the current node and returns a string describing the action taken by the player (either "IP" for in-position or "OOP" for out-of-position) along with the action details.
- If the parent node is of type `CHANCE`, it returns a string indicating the dealing of a card based on the round (FLOP, TURN, or RIVER).
- If none of these conditions are met, it returns "NodeError".\\
## Code: 
```
QVariant TreeItem::data() const
{
    shared_ptr<GameTreeNode> parentNode = this->m_treedata.lock()->getParent();
    shared_ptr<GameTreeNode> currentNode = this->m_treedata.lock();
    if(parentNode == nullptr){
        return TreeItem::get_round_str(currentNode->getRound()) + QObject::tr(" begin");
    }
    if(parentNode->getType() == GameTreeNode::GameTreeNodeType::ACTION){
        shared_ptr<ActionNode> parentActionNode = dynamic_pointer_cast<ActionNode>(parentNode);
        vector<GameActions>& actions = parentActionNode->getActions();
        vector<shared_ptr<GameTreeNode>>& childrens = parentActionNode->getChildrens();
        for(std::size_t i = 0;i < childrens.size();i ++){
            if(childrens[i] == currentNode){
                float amount = childrens[i]->getPot() - parentNode->getPot();
                return (parentActionNode->getPlayer() == 0 ? QObject::tr("IP "):QObject::tr("OOP ")) + \
                       TreeItem::get_game_action_str(actions[i].getAction(),actions[i].getAmount());
            }
        }
    }if(parentNode->getType() == GameTreeNode::GameTreeNodeType::CHANCE){
        shared_ptr<ChanceNode> chanceNode = dynamic_pointer_cast<ChanceNode>(parentNode);
        if(chanceNode->getRound() == GameTreeNode::GameRound::FLOP){
            return QObject::tr("DEAL FLOP CARD");
        }
        else if(chanceNode->getRound() == GameTreeNode::GameRound::TURN){
            return QObject::tr("DEAL TURN CARD");
        }
        else if(chanceNode->getRound() == GameTreeNode::GameRound::RIVER){
            return QObject::tr("DEAL RIVER CARD");
        }else throw runtime_error("round not recognized");
    }
    return "NodeError";
}
```