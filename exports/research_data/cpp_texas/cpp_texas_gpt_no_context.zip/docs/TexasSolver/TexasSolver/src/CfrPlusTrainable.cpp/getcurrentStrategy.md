`getcurrentStrategy`: The function of `getcurrentStrategy` is to compute and return the current strategy based on the regret values stored in the `r_plus` and `r_plus_sum` vectors.

**Code Description**: 
- The function `getcurrentStrategy` is a member of the `CfrPlusTrainable` class.
- It returns a `vector<float>` representing the current strategy.
- If the `r_plus_sum` vector is empty, it initializes the `retval` vector with equal probabilities for each action (1.0 divided by the number of actions).
- If `r_plus_sum` is not empty, it iterates over each action and private card combination to compute the strategy.
- For each combination, it calculates the strategy probability as the ratio of `r_plus` value to the corresponding `r_plus_sum` value.
- If `r_plus_sum` for a private card is zero, it assigns an equal probability for each action.
- The function includes a check for NaN values in the `r_plus` vector and throws a runtime error if any are found.
- The function returns the computed strategy vector `retval`.\\
## Code: 
```
const vector<float> CfrPlusTrainable::getcurrentStrategy() {
    if(this->r_plus_sum.empty()){
        fill(retval.begin(),retval.end(),1.0 / this->action_number);
    }else {
        for (int action_id = 0; action_id < action_number; action_id++) {
            for (int private_id = 0; private_id < this->card_number; private_id++) {
                int index = action_id * this->card_number + private_id;
                if(this->r_plus_sum[private_id] != 0) {
                    retval[index] = this->r_plus[index] / this->r_plus_sum[private_id];
                }else{
                    retval[index] = 1.0 / this->action_number;
                }
                if(this->r_plus[index] != this->r_plus[index]) throw runtime_error("nan found");
                /*
                if(this.r_plus_sum[private_id] == 0)
                {
                    System.out.println("Exception regret status, r_plus_sum == 0:");
                    System.out.println(String.format("r plus length %s , card num %s",r_plus.length,this.card_number));
                    for(int i = index % this.card_number;i < this.r_plus.length;i += this.card_number){
                        System.out.print(String.format("%s:%s ",i,this.r_plus[i]));
                        if(i == index){
                            System.out.print("[current]");
                        }
                    }
                    System.out.println();
                    System.out.println();
                    throw new RuntimeException();
                }
                 */
            }
        }
    }
    return retval;
}
```