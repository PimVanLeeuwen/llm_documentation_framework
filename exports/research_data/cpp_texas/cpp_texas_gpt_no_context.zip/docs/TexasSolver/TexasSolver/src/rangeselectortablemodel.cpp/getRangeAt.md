`getRangeAt`: The function of `getRangeAt` is to retrieve a floating-point value from a 2D grid at specified indices, with bounds checking.

**Code Description**: The `getRangeAt` function takes two integer parameters, `i` and `j`, which represent the row and column indices, respectively. It first checks if `i` is within the valid range of the `ranklist` size. If `i` is out of bounds, it logs an error message and returns 0. Similarly, it checks if `j` is within the valid range of the `ranklist` size. If `j` is out of bounds, it logs an error message and returns 0. If both indices are valid, it returns the floating-point value located at `grids_float[i][j]`.\\
## Code: 
```
float RangeSelectorTableModel::getRangeAt(int i, int j){
    if(i < 0 || i >= this->ranklist.size()){
        qDebug().noquote() << "RangeSelectorTableModel::getRangeAt i not valid: " << i;
        return 0;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "RangeSelectorTableModel::getRangeAt j not valid: " << j;
        return 0;
    }
    else{
        return this->grids_float[i][j];
    }
}
```