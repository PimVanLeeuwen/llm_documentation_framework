`updateRegrets`: The function of `updateRegrets` is to update the regret values and cumulative positive regrets for a given iteration in a Counterfactual Regret Minimization (CFR) algorithm.

**Code Description**: This method takes three parameters: `regrets` (a vector of regret values), `iteration_number` (the current iteration number), and `reach_probs` (a vector of reach probabilities). It first assigns the input `regrets` to the class member `regrets`. It then checks if the size of `regrets` matches the expected size, which is the product of `action_number` and `card_number`. If not, it throws a runtime error.

Next, it initializes the `r_plus_sum` and `cum_r_plus_sum` vectors to zero. The method then iterates over each action and private card combination, updating the positive regret values (`r_plus`) and their sums (`r_plus_sum`). It also updates the cumulative positive regrets (`cum_r_plus`) and their sums (`cum_r_plus_sum`) by multiplying the positive regrets by the iteration number. This process helps in tracking and accumulating the regrets over multiple iterations, which is essential for the CFR algorithm to converge to an optimal strategy.\\
## Code: 
```
void CfrPlusTrainable::updateRegrets(const vector<float>& regrets, int iteration_number, const vector<float>& reach_probs) {
    this->regrets = regrets;
    if(regrets.size() != this->action_number * this->card_number) throw runtime_error("length not match");

    //Arrays.fill(this.r_plus_sum,0);
    fill(r_plus_sum.begin(),r_plus_sum.end(),0);
    fill(cum_r_plus_sum.begin(),cum_r_plus_sum.end(),0);
    for (int action_id = 0;action_id < action_number;action_id ++) {
        for(int private_id = 0;private_id < this->card_number;private_id ++){
            int index = action_id * this->card_number + private_id;
            float one_reg = regrets[index];

            // 更新 R+
            this->r_plus[index] = max((float)0.0,one_reg + this->r_plus[index]);
            this->r_plus_sum[private_id] += this->r_plus[index];

            // 更新累计策略
            this->cum_r_plus[index] += this->r_plus[index] * iteration_number;
            this->cum_r_plus_sum[private_id] += this->cum_r_plus[index];
        }
    }
}
```