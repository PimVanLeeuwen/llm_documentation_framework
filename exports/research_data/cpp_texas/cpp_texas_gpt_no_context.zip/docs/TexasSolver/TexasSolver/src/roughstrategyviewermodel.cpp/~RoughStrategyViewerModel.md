`~RoughStrategyViewerModel`: The function of `~RoughStrategyViewerModel` is to serve as the destructor for the `RoughStrategyViewerModel` class.

**Code Description**: This destructor is called when an instance of the `RoughStrategyViewerModel` class is destroyed. It is responsible for performing any necessary cleanup to free resources that the object may have acquired during its lifetime. In this specific implementation, the destructor is empty, which means no special cleanup actions are required when an object of this class is destroyed.\\
## Code: 
```
RoughStrategyViewerModel::~RoughStrategyViewerModel()
{
}
```