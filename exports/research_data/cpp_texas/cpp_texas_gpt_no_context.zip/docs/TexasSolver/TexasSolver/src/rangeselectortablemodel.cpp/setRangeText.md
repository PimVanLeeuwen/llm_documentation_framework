`setRangeText`: The function of `setRangeText` is to parse a given input string representing ranges and update the internal grid values accordingly.

**Code Description**: 
- The function `setRangeText` takes a `QString` parameter `input_range`.
- It first clears any existing range data by calling `this->clear_range()`.
- The input string `input_range` is split by commas to handle multiple ranges.
- Each range string is trimmed of whitespace and further split by a colon to separate the key and the value.
- If the split results in more than two parts or less than one part, an error message is logged, and the range is skipped.
- The first part of the split string is treated as the key. If the key exists in the `string2ij` map, it is used directly; otherwise, the function appends "o" and "s" to the key to form new keys.
- For each valid key, the function checks if it exists in the `string2ij` map. If not, an error message is logged, and the range is skipped.
- If the key is valid, the corresponding grid coordinates are retrieved from the `string2ij` map.
- The second part of the split string, if present, is converted to a float and used as the range value. If not present, the default value of 1.0 is used.
- The grid value at the retrieved coordinates is updated with the range value.\\
## Code: 
```
void RangeSelectorTableModel::setRangeText(QString input_range){
    this->clear_range();
    for(QString one_range:input_range.split(",")){
        if(one_range.trimmed() == "")continue;
        QStringList one_range_list = one_range.split(":");

        if(one_range_list.size() > 2 || one_range_list.size() < 1){
            qDebug().noquote() << QString(tr("skipping range %1, format error, range list should contain two part seperate by ':'")).arg(one_range);
        }

        float range_float = 1.0;
        QString key_range = one_range_list[0];
        QStringList keys;
        if(this->string2ij.count(one_range_list[0])){
            keys.append(key_range);
        }else{
            keys.append(key_range + "o");
            keys.append(key_range + "s");
        }

        for(QString one_key: keys){
            if(one_key.count(" ") == one_key.length() || one_key == "")continue;
            if(!this->string2ij.count(one_key)){
                qDebug().noquote() << QString(tr("skipping range %1, format error")).arg(one_range);
                continue;
            }
            pair<int,int> cord = this->string2ij[one_key];
            if(one_range_list.size() > 1)range_float = one_range_list[1].toFloat();
            this->grids_float[cord.first][cord.second] = range_float;
        }
    }
}
```