`printNodeHistory`: The function of `printNodeHistory` is to print the history of actions leading to the current node in a game tree.

**Code Description**: The `printNodeHistory` function takes a `GameTreeNode` pointer as an argument and prints the sequence of actions that led to the given node. It traverses the tree from the given node to the root, printing details about each parent node. If the parent node is an `ActionNode`, it prints the player and the action taken. If the parent node is a `ChanceNode`, it prints the card dealt. If the parent node is of any other type, it prints the node's string representation. The traversal stops when it reaches a node with no parent.\\
## Code: 
```
void GameTreeNode::printNodeHistory(GameTreeNode* node) {
    /*
    while(node != nullptr) {
        shared_ptr<GameTreeNode>parent_node = node->parent;
        if (parent_node == nullptr) break;
        if(parent_node instanceof ActionNode){
            ActionNode action_node = (ActionNode)parent_node;
            for(int i = 0;i < action_node.getActions().size();i ++){
                if(action_node.getChildrens().get(i) == node){
                    System.out.print(String.format("<- (player %s %s)",
                                                   action_node.getPlayer(),
                                                   action_node.getActions().get(i).toString()
                    ));
                }
            }
        }else if(parent_node instanceof ChanceNode) {
            ChanceNode chance_node = (ChanceNode)parent_node;
            for(int i = 0;i < chance_node.getChildrens().size();i ++){
                if(chance_node.getChildrens().get(i) == node){
                    System.out.print(String.format("<- (deal card %s)",
                                                   chance_node.getCards().get(i).toString()
                    ));
                }
            }

        }else{
            System.out.print(String.format("<- (%s)",node.toString()));
        }
        node = parent_node;
    }
    System.out.println()
    }
     */
}
```