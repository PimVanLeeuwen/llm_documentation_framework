`getAverageStrategy`: The function of `getAverageStrategy` is to compute and return the average strategy for a game based on cumulative positive rewards.

**Code Description**: 
- The function initializes a vector `average_strategy` with a size equal to the product of `action_number` and `card_number`.
- It iterates over each private card (indexed by `private_id`).
- For each private card, it calculates the sum of cumulative positive rewards (`r_plus_sum`) for all actions.
- It then iterates over each action (indexed by `action_id`) and calculates the average strategy for each action and private card combination.
- If `r_plus_sum` is non-zero, the average strategy for each action is the ratio of the cumulative positive reward for that action to `r_plus_sum`.
- If `r_plus_sum` is zero, the average strategy for each action is set to a uniform probability (1 divided by the number of actions).
- Finally, the function returns the `average_strategy` vector.\\
## Code: 
```
const vector<float> DiscountedCfrTrainable::getAverageStrategy() {
    vector<float> average_strategy;
    average_strategy = vector<float>(this->action_number * this->card_number);
    for (int private_id = 0; private_id < this->card_number; private_id++) {
        float r_plus_sum = 0;
        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            r_plus_sum += this->cum_r_plus[index];
        }

        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            if(r_plus_sum) {
                average_strategy[index] = this->cum_r_plus[index] / r_plus_sum;
            }else{
                average_strategy[index] = 1.0 / this->action_number;
            }
        }
    }
    return average_strategy;
}
```