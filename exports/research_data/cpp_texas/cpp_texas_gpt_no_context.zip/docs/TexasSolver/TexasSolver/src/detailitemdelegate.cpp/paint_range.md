`paint_range`: The function of `paint_range` is to render a custom visual representation of a data item in a table view, based on specific strategy data and settings.

**Code Description**: 
- The function `paint_range` is a member of the `DetailItemDelegate` class and is used to draw a custom item in a table view.
- It initializes the style options for the item using `initStyleOption`.
- It retrieves the `DetailViewerModel` from the provided `QModelIndex`.
- Depending on the mode specified in `detailWindowSetting`, it fetches the appropriate card coordinates from the model.
- It calculates the index of the current item and retrieves the corresponding card coordinates.
- Based on the mode, it fetches the range number for the card coordinates.
- It validates the range number to ensure it is between 0 and 1.
- It calculates the height for the fold probability and the remaining height for the item.
- It draws a yellow background for the fold probability area.
- It constructs the HTML text for the item, including the card details and the range number.
- It uses a `QTextDocument` to render the HTML content within the item's rectangle.
- The painter is translated to the item's top-left corner, and the HTML content is drawn within the specified clipping rectangle.\\
## Code: 
```
void DetailItemDelegate::paint_range(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);

    const DetailViewerModel * detailViewerModel = qobject_cast<const DetailViewerModel*>(index.model());
    //vector<pair<GameActions,float>> strategy = detailViewerModel->tableStrategyModel->get_strategy(this->detailWindowSetting->grid_i,this->detailWindowSetting->grid_j);
    options.text = "";

    if(detailViewerModel->tableStrategyModel->treeItem != NULL){
        vector<pair<int,int>> card_cords;
        if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP){
            card_cords = detailViewerModel->tableStrategyModel->ui_p1_range[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j];
        }else{
            card_cords = detailViewerModel->tableStrategyModel->ui_p2_range[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j];
        }

        int ind = index.row() * detailViewerModel->columns + index.column();
        if(ind < card_cords.size()){
            pair<int,int> cord = card_cords[ind];
            float range_number;
            if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP){
                range_number = detailViewerModel->tableStrategyModel->p1_range[cord.first][cord.second];
            }else{
                range_number = detailViewerModel->tableStrategyModel->p2_range[cord.first][cord.second];
            }

            if(range_number < 0 || range_number > 1) throw runtime_error("range number incorrect in strategyitemdeletage");

            float fold_prob = 1 - range_number;
            int disable_height = (int)(fold_prob * option.rect.height());
            int remain_height = option.rect.height() - disable_height;

            // draw background for flod
            QRect rect(option.rect.left(), option.rect.top() + disable_height,\
             option.rect.width(), remain_height);
            QBrush brush(Qt::yellow);
            painter->fillRect(rect, brush);

            options.text = "";
            options.text += detailViewerModel->tableStrategyModel->cardint2card[cord.first].toFormattedHtml();
            options.text += detailViewerModel->tableStrategyModel->cardint2card[cord.second].toFormattedHtml();
            options.text = "<h2>" + options.text + "<\/h2>";

            options.text +=  QString(" <h2>%1<\/h2>").arg(QString::number(range_number,'f',3));
        }
    }

    QTextDocument doc;
    doc.setHtml(options.text);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```