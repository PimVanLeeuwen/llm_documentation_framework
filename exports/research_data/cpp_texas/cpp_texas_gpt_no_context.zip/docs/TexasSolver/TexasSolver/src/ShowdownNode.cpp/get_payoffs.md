`get_payoffs`: The function of `get_payoffs` is to return the payoffs for players based on the result of a showdown and the winner.

**Code Description**: The `get_payoffs` function takes two parameters: `result` of type `ShowDownResult` and `winner` of type `int`. If the result is `ShowDownResult::NOTTIE`, it checks if the `winner` is valid (not equal to -1). If valid, it returns the payoffs for the winning player from the `player_payoffs` vector. If the result indicates a tie, it ensures that the `winner` is -1 and returns the `tie_payoffs` vector. If the conditions are not met, it throws a runtime error.\\
## Code: 
```
vector<double> ShowdownNode::get_payoffs(ShowdownNode::ShowDownResult result, int winner) {
    if(result == ShowDownResult::NOTTIE){
        if(winner == -1) throw runtime_error("winner == -1 in tie");
        vector<double> retval = player_payoffs[winner];
        return retval;
    }else{
        // if the showdown is a tie
        if(winner != -1) throw runtime_error("winner != -1 in not tie");
        return this->tie_payoffs;
    }
}
```