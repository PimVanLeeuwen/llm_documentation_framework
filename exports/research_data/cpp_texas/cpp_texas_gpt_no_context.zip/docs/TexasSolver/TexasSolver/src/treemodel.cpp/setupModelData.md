`setupModelData`: The function of `setupModelData` is to initialize and set up the model data for a tree structure based on the game mode and game tree provided by a poker solver.

**Code Description**: 
- The function begins by declaring a pointer to a `PokerSolver` object.
- It checks the mode of the `qSolverJob` object. If the mode is `HOLDEM`, it assigns the `ps_holdem` solver to the `solver` pointer. If the mode is `SHORTDECK`, it assigns the `ps_shortdeck` solver to the `solver` pointer. If the mode is neither, it throws a runtime error.
- It then checks if the game tree or the root of the game tree is null. If either is null, the function returns early.
- If the game tree and its root are valid, it retrieves the game round from the root node.
- It initializes the `rootItem` with a new `TreeItem` based on the root of the game tree.
- It creates a new `TreeItem` as a child of `rootItem` and inserts it into `rootItem`.
- Finally, it calls the `reGenerateTreeItem` function to further process and generate the tree items based on the game round and the newly created child `TreeItem`.\\
## Code: 
```
void TreeModel::setupModelData()
{
    PokerSolver * solver;
    if(this->qSolverJob->mode == QSolverJob::Mode::HOLDEM){
        solver = &(this->qSolverJob->ps_holdem);
    }else if(this->qSolverJob->mode == QSolverJob::Mode::SHORTDECK){
        solver = &(this->qSolverJob->ps_shortdeck);
    }else{
        throw runtime_error("holdem mode incorrect");
    }

    if(solver->get_game_tree() == nullptr || solver->get_game_tree()->getRoot() == nullptr){
        return;
    }

    GameTreeNode::GameRound round =	solver->get_game_tree()->getRoot()->getRound();

    this->rootItem = new TreeItem(solver->get_game_tree()->getRoot());
    TreeItem* ti = new TreeItem(solver->get_game_tree()->getRoot(),this->rootItem);
    rootItem->insertChild(ti);
    this->reGenerateTreeItem(round,ti);
}
```