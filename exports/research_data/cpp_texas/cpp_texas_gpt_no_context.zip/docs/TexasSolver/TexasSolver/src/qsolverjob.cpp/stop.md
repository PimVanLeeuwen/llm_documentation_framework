`stop`: The function of `stop` is to attempt to stop the solver process based on the current mode of operation.

**Code Description**: The `stop` function first logs a message indicating that it is attempting to stop the solver. It then checks the current mode of the solver. If the mode is `HOLDEM`, it calls the `stop` method on the `ps_holdem` object. If the mode is `SHORTDECK`, it calls the `stop` method on the `ps_shortdeck` object. This ensures that the appropriate solver process is stopped based on the current mode.\\
## Code: 
```
void QSolverJob::stop(){
    qDebug().noquote() << tr("Trying to stop solver.");
    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.stop();
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.stop();
    }
}
```