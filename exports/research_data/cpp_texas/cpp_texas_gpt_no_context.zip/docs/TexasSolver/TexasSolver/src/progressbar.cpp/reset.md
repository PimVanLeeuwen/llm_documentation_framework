`reset`: The function of `reset` is to reinitialize the progress bar's state to its default values.

**Code Description**: The `reset` function sets the `progress` variable to 0, indicating that no progress has been made. It also sets the `update_is_called` flag to `false`, indicating that the update function has not been called yet. Additionally, it resets the `last_perc` variable to 0, which likely represents the last recorded percentage of progress. This function ensures that the progress bar starts from a clean state.\\
## Code: 
```
void progressbar::reset() {
    progress = 0,
            update_is_called = false;
    last_perc = 0;
    return;
}
```