`HtmlTableRangeView`: The function of `HtmlTableRangeView` is to initialize an HTML table view with additional mouse tracking and event filtering capabilities.

**Code Description**: 
- The constructor `HtmlTableRangeView(QWidget *parent)` initializes an instance of `HtmlTableRangeView` with a parent widget.
- It calls the constructor of its base class `HtmlTableView` with the parent widget.
- The `viewport()` method is called to get the viewport widget of the table view, and an event filter is installed on it using `installEventFilter(this)`.
- Mouse tracking is enabled by calling `setMouseTracking(true)`.
- The `mouseTracker` object is initialized with `tracking` set to `false`, and `pressed_i` and `pressed_j` set to `-1`, indicating no mouse button is currently pressed.\\
## Code: 
```
HtmlTableRangeView::HtmlTableRangeView(QWidget *parent):
HtmlTableView(parent)
{
    viewport()->installEventFilter(this);
    setMouseTracking(true);
    mouseTracker.tracking = false;
    mouseTracker.pressed_i = -1;
    mouseTracker.pressed_j = -1;
}
```