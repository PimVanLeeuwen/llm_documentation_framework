`get_commit`: The function of `get_commit` is to return the commit value for a specified player.

**Code Description**: The `get_commit` function takes an integer parameter `player` and returns a floating-point value. If `player` is 0, it returns the value of `ip_commit`. If `player` is 1, it returns the value of `oop_commit`. If `player` is neither 0 nor 1, it throws a runtime error with the message "unknown player".\\
## Code: 
```
float Rule::get_commit(int player) {
    if (player == 0) return this->ip_commit;
    else if(player == 1) return this->oop_commit;
    else throw runtime_error("unknown player");
}
```