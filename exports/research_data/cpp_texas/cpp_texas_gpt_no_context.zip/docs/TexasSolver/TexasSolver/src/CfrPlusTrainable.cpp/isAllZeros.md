`isAllZeros`: The function of `isAllZeros` is to check if all elements in a given vector of floats are zero.

**Code Description**: The `isAllZeros` function takes a vector of floats as input and iterates through each element in the vector. If it encounters any element that is not equal to zero, it immediately returns `false`. If all elements are zero, it returns `true` after completing the iteration.\\
## Code: 
```
bool CfrPlusTrainable::isAllZeros(vector<float> input_array) {
    for(float i:input_array){
        if (i != 0)return false;
    }
    return true;
}
```