`getAverageStrategy`: The function of `getAverageStrategy` is to return the current strategy for the game.

**Code Description**: This function, `getAverageStrategy`, is designed to compute and return the current strategy for a game. The commented-out section of the code suggests an alternative method for calculating the average strategy based on cumulative regret values. If the cumulative regret sums are empty or all zeros, it initializes the strategy with equal probabilities for each action. Otherwise, it calculates the strategy by normalizing the cumulative regrets. However, the actual implementation simply calls and returns the result of `getcurrentStrategy()`, which is assumed to provide the current strategy directly.\\
## Code: 
```
const vector<float> CfrPlusTrainable::getAverageStrategy() {
    /*
    vector<float> retval(this->action_number * this->card_number);
    if(this->cum_r_plus_sum.empty() || this->isAllZeros(this->cum_r_plus_sum)){
        fill(retval.begin(),retval.end(),1.0 / this->action_number);
    }else {
        for (int action_id = 0; action_id < action_number; action_id++) {
            for (int private_id = 0; private_id < this->card_number; private_id++) {
                int index = action_id * this->card_number + private_id;
                if(this->cum_r_plus_sum[private_id] != 0) {
                    retval[index] = this->cum_r_plus[index] / this->cum_r_plus_sum[private_id];
                }else{
                    retval[index] = 1.0 / this->action_number;
                }
            }
        }
    }
    */
    return this->getcurrentStrategy();
}
```