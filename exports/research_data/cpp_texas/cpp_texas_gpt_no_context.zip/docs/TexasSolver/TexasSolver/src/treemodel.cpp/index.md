`index`: The function of `index` is to return a QModelIndex object that corresponds to the item in the model specified by the given row, column, and parent index.

**Code Description**: This function first checks if the specified row and column are valid within the context of the given parent index using the `hasIndex` method. If they are not valid, it returns an invalid QModelIndex. If the parent index is not valid, it sets `parentItem` to `rootItem`, otherwise, it retrieves the `parentItem` by casting the internal pointer of the parent index to a `TreeItem` object. It then attempts to retrieve the child item at the specified row from the `parentItem`. If the child item exists, it creates and returns a QModelIndex for the child item using the `createIndex` method. If the child item does not exist, it returns an invalid QModelIndex.\\
## Code: 
```
QModelIndex TreeModel::index(int row, int column, const QModelIndex &parent) const
{
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    TreeItem *parentItem;

    if (!parent.isValid())
        parentItem = rootItem;
    else
        parentItem = static_cast<TreeItem*>(parent.internalPointer());

    TreeItem *childItem = parentItem->child(row);
    if (childItem)
        return createIndex(row, column, childItem);
    return QModelIndex();
}
```