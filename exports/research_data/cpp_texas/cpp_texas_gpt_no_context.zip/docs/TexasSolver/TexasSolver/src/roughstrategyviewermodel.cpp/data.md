`data`: The function of `data` is to return the data stored at a given index in the model.

**Code Description**: The `data` function takes a `QModelIndex` object and an integer `role` as parameters. It retrieves the column index from the `QModelIndex` object. If the column index is within the bounds of the `total_strategy` vector in the `tableStrategyModel` object, it fetches the strategy data at that column and returns the second float value from the pair. If the column index is out of bounds, it returns the string "Rough Strategy".\\
## Code: 
```
QVariant RoughStrategyViewerModel::data(const QModelIndex &index, int role) const
{
    std::size_t col = index.column();
    if(col < this->tableStrategyModel->total_strategy.size()){
        pair<GameActions,pair<float,float>> one_strategy = this->tableStrategyModel->total_strategy[col];
        return QString::number(one_strategy.second.second);
    }else{
        return "Rough Strategy";
    }
}
```