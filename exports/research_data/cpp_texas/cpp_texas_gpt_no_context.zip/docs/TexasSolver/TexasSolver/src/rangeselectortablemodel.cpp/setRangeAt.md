`setRangeAt`: The function of `setRangeAt` is to set a specific value in a 2D grid at the specified row and column indices.

**Code Description**: 
The `setRangeAt` method in the `RangeSelectorTableModel` class takes three parameters: two integers `i` and `j`, and a float `value`. It first checks if the indices `i` and `j` are within the valid range of the `ranklist` size. If either index is out of bounds, it logs an error message indicating which index is invalid. If both indices are valid, it sets the specified `value` at the position `[i][j]` in the `grids_float` 2D array.\\
## Code: 
```
void RangeSelectorTableModel::setRangeAt(int i, int j,float value){
    if(i < 0 || i >= this->ranklist.size()){
        qDebug().noquote() << "RangeSelectorTableModel::setRangeAt i not valid: " << i;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "RangeSelectorTableModel::setRangeAt j not valid: " << j;
    }
    else{
        this->grids_float[i][j] = value;
    }
}
```