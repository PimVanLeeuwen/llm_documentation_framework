`get_round_str`: The function of `get_round_str` is to convert a `GameTreeNode::GameRound` enum value to its corresponding string representation.

**Code Description**: This method takes a `GameTreeNode::GameRound` enum value as an argument and returns a localized string representation of the game round. It checks if the provided `round` is one of the predefined enum values (`FLOP`, `TURN`, `RIVER`). If the `round` is `FLOP`, it returns the string "FLOP". If the `round` is `TURN`, it returns the string "TURN". If the `round` is `RIVER`, it returns the string "RIVER". If the `round` does not match any of these values, it throws a runtime error indicating that the round is not recognized and must be one of the specified values. The function uses `QObject::tr` for translation, which allows the returned strings to be localized.\\
## Code: 
```
QString TreeItem::get_round_str(GameTreeNode::GameRound round) const{
    if(round == GameTreeNode::GameRound::FLOP){
        return QObject::tr("FLOP");
    }
    else if(round == GameTreeNode::GameRound::TURN){
        return QObject::tr("TURN");
    }
    else if(round == GameTreeNode::GameRound::RIVER){
        return QObject::tr("RIVER");
    }
    else throw runtime_error("round not recognized, must be in flop,turn,river");
}
```