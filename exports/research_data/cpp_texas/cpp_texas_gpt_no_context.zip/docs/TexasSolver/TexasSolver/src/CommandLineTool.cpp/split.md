`split`: The function of `split` is to divide a given string `s` into substrings based on a specified delimiter character `c` and store these substrings in a vector `v`.

**Code Description**: 
- The function `split` takes three parameters: a constant reference to a string `s`, a character `c` which acts as the delimiter, and a reference to a vector of strings `v` where the resulting substrings will be stored.
- It initializes two variables `i` and `j` to keep track of the positions within the string. `i` is set to 0, and `j` is set to the position of the first occurrence of the delimiter `c` in the string `s`.
- The function enters a `while` loop that continues as long as `j` is not equal to `string::npos` (which indicates the delimiter was found).
- Inside the loop, it extracts the substring from position `i` to `j-i` and adds it to the vector `v`.
- It then updates `i` to the position just after the delimiter and searches for the next occurrence of the delimiter starting from the updated position.
- If no more delimiters are found (`j` becomes `string::npos`), it adds the remaining part of the string from position `i` to the end of the string to the vector `v`.
- The function effectively splits the string `s` into multiple substrings based on the delimiter `c` and stores these substrings in the vector `v`.\\
## Code: 
```
void split(const string& s, char c,
           vector<string>& v) {
    string::size_type i = 0;
    string::size_type j = s.find(c);

    while (j != string::npos) {
        v.push_back(s.substr(i, j-i));
        i = ++j;
        j = s.find(c, j);

        if (j == string::npos)
            v.push_back(s.substr(i, s.length()));
    }
}
```