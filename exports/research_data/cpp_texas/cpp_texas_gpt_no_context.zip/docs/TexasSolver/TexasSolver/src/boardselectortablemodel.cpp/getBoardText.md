`getBoardText`: The function of `getBoardText` is to generate a comma-separated string representation of non-zero grid values from a 2D array.

**Code Description**: 
The `getBoardText` function iterates through a 2D array (`grids_float`) and its corresponding string representation (`grids_string`). For each non-zero value in `grids_float`, it retrieves the corresponding string from `grids_string` and appends it to a result string (`retval`). The values are concatenated with commas. The function returns this comma-separated string of non-zero grid values.\\
## Code: 
```
QString BoardSelectorTableModel::getBoardText(){
    QString retval = "";
    for(int i = 0;i < this->suitlist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            if(this->grids_float[i][j] == 0)continue;
            QString one_board_str = QString("%1").arg(this->grids_string[i][j]);
            if(retval == ""){
                retval = one_board_str;
            }else{
                retval = retval + "," + one_board_str;
            }
        }
    }
    return retval;
}
```