`getType`: The function of `getType` is to return the type of the node.

**Code Description**: This method, `getType`, is a member of the `ActionNode` class. When called, it returns the enumerated value `ACTION` of the `GameTreeNodeType` type, indicating that the node is of the action type.\\
## Code: 
```
GameTreeNode::GameTreeNodeType ActionNode::getType() {
    return ACTION;
}
```