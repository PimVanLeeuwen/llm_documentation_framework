`getParent`: The function of `getParent` is to retrieve the parent node of the current `GameTreeNode` instance.

**Code Description**: This method returns a `shared_ptr` to the parent node of the current `GameTreeNode` instance. It achieves this by calling the `lock()` method on a `weak_ptr` named `parent`, which is a member of the `GameTreeNode` class. The `lock()` method converts the `weak_ptr` to a `shared_ptr`, allowing access to the parent node if it still exists. If the parent node has been destroyed, the `shared_ptr` will be empty.\\
## Code: 
```
shared_ptr<GameTreeNode>GameTreeNode::getParent() {
    return this->parent.lock();
}
```