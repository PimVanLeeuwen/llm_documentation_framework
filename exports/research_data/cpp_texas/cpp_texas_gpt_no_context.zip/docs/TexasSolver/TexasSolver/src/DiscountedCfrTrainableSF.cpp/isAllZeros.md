`isAllZeros`: The function of `isAllZeros` is to check if all elements in a given vector of floats are zero.

**Code Description**: This function, `isAllZeros`, takes a vector of floats as input and iterates through each element in the vector. If it encounters any element that is not zero, it immediately returns `false`. If it completes the iteration without finding any non-zero elements, it returns `true`. This function is useful for verifying that all elements in the input vector are zero.\\
## Code: 
```
bool DiscountedCfrTrainableSF::isAllZeros(const vector<float>& input_array) {
    for(float i:input_array){
        if (i != 0)return false;
    }
    return true;
}
```