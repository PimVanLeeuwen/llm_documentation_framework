`get_total_strategy`: The function of `get_total_strategy` is to compute and return the total strategy for a game tree node, including the combination and average strategy for each game action.

**Code Description**: 
- The function `get_total_strategy` returns a vector of pairs, where each pair consists of a `GameActions` object and another pair of floats representing the combination and average strategy for that action.
- It first checks if `treeItem` is `NULL`. If it is, it returns an empty vector.
- It locks the `treeItem` to get a shared pointer to the `GameTreeNode`.
- If the node type is `ACTION`, it proceeds to calculate the strategy:
  - It retrieves the actions and the current player from the `ActionNode`.
  - It initializes vectors to store combinations and average strategies, and a float to sum the strategies.
  - It iterates through the `current_strategy` matrix to accumulate the probabilities and ranges for each action.
  - It checks for index errors and size mismatches between game actions and strategies, throwing runtime errors if any are found.
  - It calculates the average strategy by dividing the accumulated values by the total sum of strategies.
  - It constructs the return vector with pairs of game actions and their corresponding combination and average strategy.
- If the node type is not `ACTION`, it returns an empty vector.\\
## Code: 
```
const vector<pair<GameActions,pair<float,float>>> TableStrategyModel::get_total_strategy() const{
    vector<pair<GameActions,pair<float,float>>> ret_strategy;
    if(this->treeItem == NULL)return ret_strategy;


    shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();

    if(node->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);
        vector<GameActions>& gameActions = actionNode->getActions();
        int current_player = actionNode->getPlayer();

        vector<float> combos(gameActions.size(),0.0);
        vector<float> avg_strategy(gameActions.size(),0.0);
        float sum_strategy = 0;

        for(std::size_t index1 = 0;index1 < this->current_strategy.size() ;index1 ++){
            for(std::size_t index2 = 0;index2 < this->current_strategy.size() ;index2 ++){
                const vector<float>& one_strategy = this->current_strategy[index1][index2];
                if(one_strategy.empty())continue;

                const vector<vector<float>>& range = current_player == 0? this->p1_range:this->p2_range;
                if(range.size() <= index1 || range[index1].size() < index2) throw runtime_error(" index error when get range in tablestrategymodel");
                const float one_range = range[index1][index2];

                for(std::size_t i = 0;i < one_strategy.size(); i ++ ){
                    float one_prob = one_strategy[i];
                    combos[i] += one_prob * one_range;
                    avg_strategy[i] += one_prob * one_range;
                    sum_strategy += one_prob * one_range;
                }

                if(gameActions.size() != one_strategy.size()){
                    cout << "index: " << index1 << " " << index2 << endl;
                    cout << "size not match between gameAction and stragegy: " << gameActions.size() << " " << one_strategy.size() << endl;
                    throw runtime_error("size not match between gameAction and stragegy");
                }
            }
        }

        for(std::size_t i = 0;i < gameActions.size(); i ++ ){
            avg_strategy[i] = avg_strategy[i] / sum_strategy;
            pair<float,float> statics = pair<float,float>(combos[i],avg_strategy[i]);
            pair<GameActions,pair<float,float>> one_ret = pair<GameActions,pair<float,float>>(gameActions[i],statics);
            ret_strategy.push_back(one_ret);
        }
        return ret_strategy;
    }else{
        return ret_strategy;
    }


}
```