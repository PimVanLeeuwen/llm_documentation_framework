`columnCount`: The function of `columnCount` is to return the number of columns in the table model.

**Code Description**: This function, `columnCount`, is a member of the `TableStrategyModel` class. It takes a constant reference to a `QModelIndex` object named `parent` as its parameter. The function returns an integer representing the number of columns in the table model. It does this by accessing the `qSolverJob` member of the class, calling its `get_solver()` method to get a solver object, then calling `get_deck()` on the solver object to get a deck object, and finally calling `getRanks().size()` on the deck object to get the number of ranks, which corresponds to the number of columns.\\
## Code: 
```
int TableStrategyModel::columnCount(const QModelIndex &parent) const
{
    return this->qSolverJob->get_solver()->get_deck()->getRanks().size();
}
```