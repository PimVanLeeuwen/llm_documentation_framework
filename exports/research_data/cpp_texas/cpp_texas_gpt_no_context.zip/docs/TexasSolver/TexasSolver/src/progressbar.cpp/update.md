`update`: The function of `update` is to update the progress bar display based on the current progress.

**Code Description**: 
- The `update` function is designed to update a progress bar display.
- The function starts with a `return` statement, which means the rest of the code will not execute.
- If the `return` statement is removed, the function will first check if `n_cycles` is set to 0 and throw a runtime error if true.
- If `update_is_called` is false, it initializes the progress bar display. If `do_show_bar` is true, it prints the opening bracket and a series of `todo_char` characters followed by the closing bracket and "0%". If `do_show_bar` is false, it simply prints "0%".
- The `update_is_called` flag is then set to true.
- The function calculates the percentage of progress (`perc`) based on the current progress and total cycles.
- If the new percentage is less than the last recorded percentage (`last_perc`), the function returns without making any changes.
- If the percentage has increased by one unit, it updates the displayed percentage by erasing the previous percentage and printing the new one.
- If `do_show_bar` is true and the percentage is a multiple of 2, it updates the progress bar by:
  - Erasing the closing bracket and the trailing percentage characters.
  - Erasing the appropriate number of `todo_char` characters.
  - Adding one `done_char` to the progress bar.
  - Refilling the remaining space with `todo_char` characters.
  - Re-adding the closing bracket and the updated percentage.
- The `last_perc` is updated to the new percentage, and the `progress` counter is incremented.
- The function flushes the output stream to ensure the display is updated immediately.\\
## Code: 
```
void progressbar::update() {
    return;
    if (n_cycles == 0) throw std::runtime_error(
                "progressbar::update: number of cycles not set");

    if (!update_is_called) {
        if (do_show_bar == true) {
            std::cout << opening_bracket_char;
            for (int _ = 0; _ < 50; _++) std::cout << todo_char;
            std::cout << closing_bracket_char << " 0%";
        }
        else std::cout << "0%";
    }
    update_is_called = true;

    int perc = 0;

    // compute percentage, if did not change, do nothing and return
    perc = progress*100./(n_cycles-1);
    if (perc < last_perc) return;

    // update percentage each unit
    if (perc == last_perc + 1) {
        // erase the correct  number of characters
        if      (perc <= 10)                std::cout << "\b\b"   << perc << '%';
        else if (perc  > 10 && perc < 100) std::cout << "\b\b\b" << perc << '%';
        else if (perc == 100)               std::cout << "\b\b\b" << perc << '%';
    }
    if (do_show_bar == true) {
        // update bar every ten units
        if (perc % 2 == 0) {
            // erase closing bracket
            std::cout << std::string(closing_bracket_char.size(), '\b');
            // erase trailing percentage characters
            if      (perc  < 10)               std::cout << "\b\b\b";
            else if (perc >= 10 && perc < 100) std::cout << "\b\b\b\b";
            else if (perc == 100)              std::cout << "\b\b\b\b\b";

            // erase 'todo_char'
            for (int j = 0; j < 50-(perc-1)/2; ++j) {
                std::cout << std::string(todo_char.size(), '\b');
            }

            // add one additional 'done_char'
            if (perc == 0) std::cout << todo_char;
            else           std::cout << done_char;

            // refill with 'todo_char'
            for (int j = 0; j < 50-(perc-1)/2-1; ++j) std::cout << todo_char;

            // readd trailing percentage characters
            std::cout << closing_bracket_char << ' ' << perc << '%';
        }
    }
    last_perc = perc;
    ++progress;
    std::cout << std::flush;

    return;
}
```