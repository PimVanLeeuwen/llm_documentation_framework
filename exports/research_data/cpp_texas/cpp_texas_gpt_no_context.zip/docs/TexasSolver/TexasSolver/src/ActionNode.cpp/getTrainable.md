`getTrainable`: The function of `getTrainable` is to retrieve or create a `Trainable` object at a specified index in the `trainables` vector.

**Code Description**: 
- The function `getTrainable` takes three parameters: an integer `i`, a boolean `create_on_site`, and an integer `use_halffloats`.
- It first checks if the index `i` is within the bounds of the `trainables` vector. If `i` is greater than the size of the vector, it throws a runtime error.
- If the `trainables` vector at index `i` is `nullptr` and `create_on_site` is `true`, it creates a new `Trainable` object based on the value of `use_halffloats` and the current round of the game.
  - If the current round is `RIVER` and `use_halffloats` is 0, it creates a `DiscountedCfrTrainable` object.
  - If `use_halffloats` is 1, it creates a `DiscountedCfrTrainableSF` object.
  - If `use_halffloats` is 2, it creates a `DiscountedCfrTrainableHF` object.
- Finally, it returns the `Trainable` object at the specified index `i`.\\
## Code: 
```
shared_ptr<Trainable> ActionNode::getTrainable(int i,bool create_on_site, int use_halffloats) {
    if(i > this->trainables.size()){
        throw runtime_error(tfm::format("size unacceptable %s > %s ",i,this->trainables.size()));
    }
    if(this->trainables[i] == nullptr && create_on_site){
        switch ((this->getRound() == GameTreeNode::RIVER) ? use_halffloats : 0 ){
        case 0:
            this->trainables[i] = make_shared<DiscountedCfrTrainable>(player_privates,*this);
            break;
        case 1:
            this->trainables[i] = make_shared<DiscountedCfrTrainableSF>(player_privates,*this);
            break;
        case 2:
            this->trainables[i] = make_shared<DiscountedCfrTrainableHF>(player_privates,*this);
            break;
        }
    }
    return this->trainables[i];
}
```