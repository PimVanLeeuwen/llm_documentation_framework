`CfrPlusTrainable`: The function of `CfrPlusTrainable` is to initialize an object that manages the training state for a Counterfactual Regret Minimization (CFR) algorithm in a game setting.

**Code Description**: 
- The constructor `CfrPlusTrainable` takes two parameters: a shared pointer to an `ActionNode` object and a vector of `PrivateCards`.
- It initializes the member variables `action_node` and `privateCards` with the provided arguments.
- It calculates the number of possible actions (`action_number`) by getting the size of the children of the `action_node`.
- It calculates the number of private cards (`card_number`) by getting the size of the `privateCards` vector.
- It initializes several vectors (`r_plus`, `r_plus_sum`, `cum_r_plus`, `cum_r_plus_sum`, and `retval`) to store floating-point values. These vectors are sized based on the number of actions and private cards, and they are used to keep track of various metrics needed for the CFR algorithm.\\
## Code: 
```
CfrPlusTrainable::CfrPlusTrainable(shared_ptr<ActionNode> action_node, vector<PrivateCards> privateCards) {
    this->action_node = action_node;
    this->privateCards = privateCards;
    this->action_number = action_node->getChildrens().size();
    this->card_number = privateCards.size();

    this->r_plus = vector<float>(this->action_number * this->card_number);
    this->r_plus_sum = vector<float>(this->card_number);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number);
    this->cum_r_plus_sum = vector<float>(this->card_number);
    this->retval = vector<float>(this->action_number * this->card_number);
}
```