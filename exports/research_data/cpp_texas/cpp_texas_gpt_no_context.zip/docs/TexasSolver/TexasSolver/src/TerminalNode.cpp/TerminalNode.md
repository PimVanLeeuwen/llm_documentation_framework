`TerminalNode`: The function of `TerminalNode` is to initialize a terminal node in a game tree with specific payoffs, winner information, game round, pot value, and a reference to its parent node.

**Code Description**: 
- The constructor `TerminalNode` takes the following parameters:
  - `vector<double> payoffs`: A vector containing the payoffs for the players.
  - `int winner`: An integer representing the winner of the game.
  - `GameTreeNode::GameRound round`: The current round of the game.
  - `double pot`: The total pot value at this node.
  - `shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node in the game tree.
- The constructor initializes the base class `GameTreeNode` with the `round`, `pot`, and `parent` parameters.
- It then sets the `payoffs` and `winner` member variables to the provided values.\\
## Code: 
```
TerminalNode::TerminalNode(vector<double> payoffs, int winner, GameTreeNode::GameRound round, double pot,
                           shared_ptr<GameTreeNode> parent):GameTreeNode(round,pot,parent){
    this->payoffs = payoffs;
    this->winner = winner;
}
```