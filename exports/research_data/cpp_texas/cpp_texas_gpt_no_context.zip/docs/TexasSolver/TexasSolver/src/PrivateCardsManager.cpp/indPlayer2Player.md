`indPlayer2Player`: The function of `indPlayer2Player` is to map the index of a card from one player's hand to the corresponding index in another player's hand.

**Code Description**: 
- The function `indPlayer2Player` takes three parameters: `from_player` (the player from whom the card index is taken), `to_player` (the player to whom the card index is mapped), and `index` (the index of the card in the `from_player`'s hand).
- It first checks if the provided `index` is within the valid range of the `from_player`'s hand. If the index is out of range, it throws a runtime error.
- It then retrieves the index of the card in the `to_player`'s hand using the `card_player_index` map and the hash code of the card from the `from_player`'s hand.
- If the mapped index for the `to_player` is `-1`, it returns `-1`, indicating that the card is not present in the `to_player`'s hand.
- Otherwise, it returns the mapped index for the `to_player`.\\
## Code: 
```
int PrivateCardsManager::indPlayer2Player(int from_player, int to_player, int index) {
    if(index < 0 || index >= this->getPreflopCards(from_player).size()) throw runtime_error("index out of range");
    //PrivateCards player_combo = this->getPreflopCards(from_player)[index];
    int to_player_index = this->card_player_index[this->private_cards[from_player][index].hashCode()][to_player];
    if(to_player_index == -1){
        return -1;
    }else {
        return to_player_index;
    }
}
```