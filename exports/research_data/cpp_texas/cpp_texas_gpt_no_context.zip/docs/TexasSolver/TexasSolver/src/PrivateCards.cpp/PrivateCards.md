`PrivateCards`: The function of `PrivateCards` is to initialize an instance of the `PrivateCards` class with two card values and a weight.

**Code Description**: 
- The constructor `PrivateCards(int card1, int card2, float weight)` initializes the object with the provided card values (`card1` and `card2`) and a weight (`weight`).
- It sets the instance variables `card1`, `card2`, and `weight` to the provided values.
- It initializes `relative_prob` to 0.
- It creates a vector `card_vec` containing `card1` and `card2`.
- It calculates a `hash_code` based on the card values, ensuring the smaller card value is always multiplied by 52.
- It converts the `card_vec` to a long integer representation using the `Card::boardInts2long` method and assigns it to `board_long`.\\
## Code: 
```
PrivateCards::PrivateCards(int card1, int card2, float weight) {
    this->card1 = card1;
    this->card2 = card2;
    this->weight = weight;
    this->relative_prob = 0;
    this->card_vec = vector<int>{this->card1,this->card2};
    if (card1 > card2){
        this->hash_code = card1 * 52 + card2;
    }else{
        this->hash_code = card2 * 52 + card1;
    }
    this->board_long = Card::boardInts2long(this->card_vec);
}
```