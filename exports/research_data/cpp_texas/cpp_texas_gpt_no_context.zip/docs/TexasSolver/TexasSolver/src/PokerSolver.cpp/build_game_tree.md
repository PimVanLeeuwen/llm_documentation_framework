`build_game_tree`: The function of `build_game_tree` is to initialize and construct a game tree for a poker game based on the provided parameters.

**Code Description**: This function initializes a `GameTree` object using various parameters such as the out-of-position (oop) and in-position (ip) player commitments, the current round of the game, the raise limit, the small and big blinds, the stack size, game tree building settings, and an all-in threshold. It then assigns this newly created `GameTree` object to the `game_tree` member variable of the `PokerSolver` class. The `shared_ptr` is used to manage the memory of the `GameTree` object automatically.\\
## Code: 
```
void PokerSolver::build_game_tree(
        float oop_commit,
        float ip_commit,
        int current_round,
        int raise_limit,
        float small_blind,
        float big_blind,
        float stack,
        GameTreeBuildingSettings buildingSettings,
        float allin_threshold
){
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(
            this->deck,
            oop_commit,
            ip_commit,
            current_round,
            raise_limit,
            small_blind,
            big_blind,
            stack,
            buildingSettings,
            allin_threshold
    );
    this->game_tree = game_tree;
}
```