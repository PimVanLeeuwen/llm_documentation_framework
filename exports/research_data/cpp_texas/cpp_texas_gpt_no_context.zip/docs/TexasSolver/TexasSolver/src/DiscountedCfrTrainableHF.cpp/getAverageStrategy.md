`getAverageStrategy`: The function of `getAverageStrategy` is to compute and return the average strategy for a game based on cumulative positive rewards.

**Code Description**: 
- The function initializes a vector `average_strategy` with a size equal to the product of `action_number` and `card_number`.
- It iterates over each private card (indexed by `private_id`).
- For each private card, it calculates the sum of cumulative positive rewards (`r_plus_sum`) for all actions.
- It then normalizes the cumulative positive rewards for each action by dividing by `r_plus_sum` to get the average strategy.
- If `r_plus_sum` is zero, it assigns an equal probability to all actions.
- Finally, it returns the `average_strategy` vector.\\
## Code: 
```
const vector<float> DiscountedCfrTrainableHF::getAverageStrategy() {
    vector<float> average_strategy;
    average_strategy = vector<float>(this->action_number * this->card_number);
    for (int private_id = 0; private_id < this->card_number; private_id++) {
        float r_plus_sum = 0;
        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            average_strategy[index] = this->cum_r_plus[index];
            r_plus_sum += average_strategy[index];
        }

        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            if(r_plus_sum) {
                // we stored this->cum_r_plus[index] in average_strategy[index] above
                // this is to avoid converting from half float twice
                average_strategy[index] = average_strategy[index] / r_plus_sum;
            }else{
                average_strategy[index] = 1.0 / this->action_number;
            }
        }
    }
    return average_strategy;
}
```