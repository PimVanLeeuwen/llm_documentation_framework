`toString`: The function of `toString` is to convert the game action and its associated amount into a string representation.

**Code Description**: The `toString` method in the `GameActions` class checks if the `amount` attribute is equal to -1. If it is, the method returns the string representation of the `action` attribute by calling the `pokerActionToString` method. If `amount` is not -1, it returns the string representation of the `action` followed by the `amount` value, separated by a space. The `to_string` function is used to convert the `amount` integer to a string.\\
## Code: 
```
string GameActions::toString() {
    if(this->amount == -1) {
        return this->pokerActionToString(this->action);
    }else{
        return this->pokerActionToString(this->action) + " " + to_string(amount);
    }
}
```