`playerHands`: The function of `playerHands` is to return the private card range for a specified player.

**Code Description**: The `playerHands` function takes an integer `player` as an argument and returns a reference to a vector of `PrivateCards` corresponding to the player's hand. If the `player` argument is `0`, it returns `range1`. If the `player` argument is `1`, it returns `range2`. If the `player` argument is neither `0` nor `1`, the function throws a runtime error with the message "player not found".\\
## Code: 
```
const vector<PrivateCards> &PCfrSolver::playerHands(int player) {
    if(player == 0){
        return range1;
    }else if (player == 1){
        return range2;
    }else{
        throw runtime_error("player not found");
    }
}
```