`setTrunCard`: The function of `setTrunCard` is to set the `turn_card` attribute of the `TableStrategyModel` object.

**Code Description**: This method, `setTrunCard`, takes a `Card` object as an argument and assigns it to the `turn_card` member variable of the `TableStrategyModel` class. This allows the `TableStrategyModel` to update its internal state to reflect the current turn card in a game or strategy context.\\
## Code: 
```
void TableStrategyModel::setTrunCard(Card turn_card){
    this->turn_card = turn_card;
}
```