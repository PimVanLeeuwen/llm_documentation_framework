`saving`: The function of `saving` is to save the current strategy to a JSON file based on the mode of the solver (HOLDEM or SHORTDECK) and the configured dump round.

**Code Description**: 
The `saving` function begins by logging a message indicating that the saving process has started. It then retrieves the dump round setting from the application's settings stored under the "solver" group. The dump round value is logged, and if it is set to 3, a warning message is logged about potential performance issues. Depending on the mode of the solver (HOLDEM or SHORTDECK), the function calls the appropriate method to dump the strategy to the specified save file. Finally, a message is logged indicating that the saving process is complete.\\
## Code: 
```
void QSolverJob::saving(){
    qDebug().noquote() << tr("Saving json file..");//.toStdString() << std::endl;

    QSettings setting("TexasSolver", "Setting");
    setting.beginGroup("solver");
    this->dump_rounds = setting.value("dump_round").toInt();

    qDebug().noquote() << tr("Dump round: ") << this->dump_rounds;
    if(this->dump_rounds == 3){
        qDebug().noquote() << tr("This could be slow, or even blow your RAM, dump to river is not well optimized :(");
    }
    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.dump_strategy(this->savefile,this->dump_rounds);
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.dump_strategy(this->savefile,this->dump_rounds);
    }
    qDebug().noquote() << tr("Saving done.");//.toStdString() << std::endl;
}
```