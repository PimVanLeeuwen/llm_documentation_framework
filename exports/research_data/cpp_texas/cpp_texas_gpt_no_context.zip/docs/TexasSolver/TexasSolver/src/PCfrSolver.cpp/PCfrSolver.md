`PCfrSolver`: The function of `PCfrSolver` is to initialize a solver for a poker game tree using the Potential-aware Counterfactual Regret Minimization (PCFR) algorithm.

**Code Description**: 
- The constructor `PCfrSolver` initializes the solver with various parameters including the game tree, player ranges, initial board state, comparison logic, deck, iteration number, debug mode, print interval, log file, trainer, Monte Carlo algorithm, warmup period, accuracy, isomorphism usage, half-floats usage, and number of threads.
- It sets up the initial board and converts it to a long integer representation.
- It removes duplicate ranges from the provided ranges for both players based on the initial board.
- It initializes the ranges for both players and sets the number of players to 2.
- It sets up the comparison logic, deck, isomorphism usage, and half-floats usage.
- It initializes the RiverRangeManager with the comparison logic.
- It sets the iteration number and initializes the PrivateCardsManager with the private cards and player number.
- It configures the debug mode, print interval, Monte Carlo algorithm, accuracy, and number of threads (defaulting to the number of processors if not specified).
- It sets the number of OpenMP threads and marks the task distribution as false.
- It sets the trainable nodes in the game tree and determines the split round based on the root round of the game tree, avoiding multithreading for the river round.\\
## Code: 
```
PCfrSolver::PCfrSolver(shared_ptr<GameTree> tree, vector<PrivateCards> range1, vector<PrivateCards> range2,
                     vector<int> initial_board, shared_ptr<Compairer> compairer, Deck deck, int iteration_number, bool debug,
                     int print_interval, string logfile, string trainer, Solver::MonteCarolAlg monteCarolAlg,int warmup,float accuracy,bool use_isomorphism,int use_halffloats,int num_threads) :Solver(tree){
    this->initial_board = initial_board;
    this->initial_board_long = Card::boardInts2long(initial_board);
    this->logfile = logfile;
    this->trainer = trainer;
    this->warmup = warmup;

    range1 = this->noDuplicateRange(range1,initial_board_long);
    range2 = this->noDuplicateRange(range2,initial_board_long);

    this->range1 = range1;
    this->range2 = range2;
    this->player_number = 2;
    this->ranges = vector<vector<PrivateCards>>(this->player_number);
    this->ranges[0] = range1;
    this->ranges[1] = range2;

    this->compairer = compairer;

    this->deck = deck;
    this->use_isomorphism = use_isomorphism;
    this->use_halffloats = use_halffloats;

    this->rrm = RiverRangeManager(compairer);
    this->iteration_number = iteration_number;

    vector<vector<PrivateCards>> private_cards(this->player_number);
    private_cards[0] = range1;
    private_cards[1] = range2;
    pcm = PrivateCardsManager(private_cards,this->player_number,Card::boardInts2long(this->initial_board));
    this->debug = debug;
    this->print_interval = print_interval;
    this->monteCarolAlg = monteCarolAlg;
    this->accuracy = accuracy;
    if(num_threads == -1){
        num_threads = omp_get_num_procs();
    }
    qDebug().noquote() << QString::fromStdString(tfm::format(QObject::tr("Using %s threads").toStdString().c_str(),num_threads));
    this->num_threads = num_threads;
    this->distributing_task = false;
    omp_set_num_threads(this->num_threads);
    setTrainable(this->tree->getRoot());
    this->root_round = this->tree->getRoot()->getRound();
    if(this->root_round == GameTreeNode::GameRound::PREFLOP){
        this->split_round = GameTreeNode::GameRound::FLOP;
    }else if(this->root_round == GameTreeNode::GameRound::FLOP){
        this->split_round = GameTreeNode::GameRound::TURN;
    }else if(this->root_round == GameTreeNode::GameRound::TURN){
        this->split_round = GameTreeNode::GameRound::RIVER;
    }else{
        // do not use multithread in river, really not necessary
        this->split_round = GameTreeNode::GameRound::PREFLOP;
    }
}
```