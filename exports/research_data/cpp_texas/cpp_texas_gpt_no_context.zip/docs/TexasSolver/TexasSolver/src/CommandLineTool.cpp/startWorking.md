`startWorking`: The function of `startWorking` is to continuously read input lines from the standard input and process each line as a command.

**Code Description**: The `startWorking` function is a member of the `CommandLineTool` class. It enters an infinite loop where it reads lines of input from the standard input (typically the console) using `getline`. For each line read, it calls the `processCommand` method of the `CommandLineTool` instance, passing the input line as an argument. The loop continues until the end-of-file (EOF) is reached on the standard input.\\
## Code: 
```
void CommandLineTool::startWorking() {
    string input_line;
    while(cin) {
        getline(cin, input_line);
        this->processCommand(input_line);
    };
}
```