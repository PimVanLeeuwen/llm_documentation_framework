`get_ev_grid`: The function of `get_ev_grid` is to calculate and return a vector of expected values (EVs) for a given strategy at a specific position in a strategy table.

**Code Description**: 
- The function `get_ev_grid` takes two integer parameters `i` and `j` and returns a vector of floats.
- It initializes an empty vector `ret_evs` to store the resulting EVs.
- If the `treeItem` is `NULL` or `current_evs` is empty, it returns the empty `ret_evs` vector.
- It retrieves the number of strategies at position `[i][j]` in the `ui_strategy_table`.
- It locks and retrieves the `GameTreeNode` from `treeItem`.
- If the node type is `ACTION`, it casts the node to an `ActionNode` and retrieves the game actions.
- For each pair of indices in `ui_strategy_table[i][j]`, it retrieves the corresponding strategy and EV vectors.
- It checks if the sizes of the strategy and EV vectors match. If not, it returns an empty vector.
- It also checks if the size of the game actions matches the size of the strategy vector. If not, it throws a runtime error.
- It calculates the EV for each strategy by multiplying the strategy values with the corresponding EV values and summing them up.
- The calculated EVs are added to the `ret_evs` vector.
- Finally, it returns the `ret_evs` vector. If the node type is not `ACTION`, it returns the empty `ret_evs` vector.\\
## Code: 
```
const vector<float> TableStrategyModel::get_ev_grid(int i,int j)const{
    vector<float> ret_evs;
    if(this->treeItem == NULL || this->current_evs.empty())return ret_evs;

    int strategy_number = this->ui_strategy_table[i][j].size();

    shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();

    if(node->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);

        vector<GameActions>& gameActions = actionNode->getActions();

//        vector<float> strategies;

//        if(this->ui_strategy_table[i][j].size() > 0){
//            strategies = vector<float>(gameActions.size());
//            std::fill(strategies.begin(), strategies.end(), 0.);
//        }
        for(std::pair<int,int> index:this->ui_strategy_table[i][j]){
            int index1 = index.first;
            int index2 = index.second;
            const vector<float>& one_strategy = this->current_strategy[index1][index2];
            const vector<float>& one_ev = this->current_evs[index1][index2];
            if(one_ev.size() != one_strategy.size()) return vector<float>();

            if(gameActions.size() != one_strategy.size()){
                cout << "index: " << index1 << " " << index2 << endl;
                cout << "i,j: " << i << " " << j << endl;
                cout << "size not match between gameAction and stragegy: " << gameActions.size() << " " << one_strategy.size() << endl;
                throw runtime_error("size not match between gameAction and stragegy");
            }
            float one_ev_float = 0;
            for(std::size_t indi = 0;indi < one_strategy.size();indi ++){
                one_ev_float += one_strategy[indi] * one_ev[indi];
            }
            ret_evs.push_back(one_ev_float);
        }

        return ret_evs;
    }else{
        return ret_evs;
    }
}
```