`getAmount`: The function of `getAmount` is to return the value of the `amount` member variable of the `GameActions` object.

**Code Description**: This method, `getAmount`, is a member function of the `GameActions` class. When called, it returns the value of the private member variable `amount` associated with the instance of the `GameActions` class. The return type of this function is `double`, indicating that the `amount` variable is expected to hold a floating-point number.\\
## Code: 
```
double GameActions::getAmount() {
    return this->amount;
}
```