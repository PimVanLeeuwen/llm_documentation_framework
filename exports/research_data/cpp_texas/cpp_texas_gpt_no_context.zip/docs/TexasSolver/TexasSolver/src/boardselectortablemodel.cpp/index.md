`index`: The function of `index` is to return a QModelIndex object for a given row and column in the model.

**Code Description**: This function takes three parameters: `row`, `column`, and `parent`. It first checks if the specified row and column are valid within the context of the parent index using the `hasIndex` method. If the indices are valid, it creates and returns a QModelIndex object for the specified row and column using the `createIndex` method. If the indices are not valid, it returns an invalid QModelIndex object.\\
## Code: 
```
QModelIndex BoardSelectorTableModel::index(int row, int column,
          const QModelIndex &parent) const  {
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    return createIndex(row, column, nullptr);
}
```