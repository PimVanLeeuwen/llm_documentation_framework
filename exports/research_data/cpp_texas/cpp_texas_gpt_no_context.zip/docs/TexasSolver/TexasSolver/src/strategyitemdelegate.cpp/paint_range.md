`paint_range`: The function of `paint_range` is to render a specific cell in a table view based on the strategy model's data and the current mode of the detail window settings.

**Code Description**: 
- The function starts by initializing the style options for the item to be painted.
- It retrieves the `TableStrategyModel` from the provided `QModelIndex`.
- It checks if the model or the required data ranges (`ui_p1_range` and `ui_p2_range`) are valid and within bounds for the given row and column. If not, it exits early.
- Depending on the mode of the `detailWindowSetting`, it selects the appropriate range data (`ui_p1_range` or `ui_p2_range`).
- It verifies that the primary range data (`p1_range` or `p2_range`) is not empty.
- If the selected range data (`card_cords`) is not empty, it calculates the average range number by summing up the values from the primary range data and dividing by the number of coordinates.
- It ensures the calculated range number is between 0 and 1, throwing an error if it is not.
- It calculates the fold probability and determines the height of the disabled (folded) area in the cell.
- It draws the background for the folded area using a yellow brush.
- It prepares a `QTextDocument` to render the text content of the cell.
- Finally, it translates the painter to the top-left corner of the cell and draws the text content within the cell's rectangle.\\
## Code: 
```
void StrategyItemDelegate::paint_range(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);
    const TableStrategyModel * tableStrategyModel = qobject_cast<const TableStrategyModel*>(index.model());

    vector<pair<int,int>> card_cords;
    if(tableStrategyModel == NULL
            || tableStrategyModel->ui_p1_range.size() <= index.row()
            || tableStrategyModel->ui_p1_range.size() <= index.column()
            || tableStrategyModel->ui_p2_range.size() <= index.row()
            || tableStrategyModel->ui_p2_range.size() <= index.column()
            ){
        return;
    }
    if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP){
        card_cords = tableStrategyModel->ui_p1_range[index.row()][index.column()];
    }else{
        card_cords = tableStrategyModel->ui_p2_range[index.row()][index.column()];
    }

    if(tableStrategyModel->p1_range.empty() || tableStrategyModel->p2_range.empty()){
        return;
    }

    if(!card_cords.empty()){
        float range_number = 0;
        for(auto one_cord:card_cords){
            if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP){
                range_number += tableStrategyModel->p1_range[one_cord.first][one_cord.second];
            }else{
                // when it's oop, which is p1
                range_number += tableStrategyModel->p2_range[one_cord.first][one_cord.second];
            }
        }
        range_number = range_number / card_cords.size();

        if(range_number < 0 || range_number > 1) throw runtime_error("range number incorrect in strategyitemdeletage");

        float fold_prob = 1 - range_number;
        int disable_height = (int)(fold_prob * option.rect.height());
        int remain_height = option.rect.height() - disable_height;

        // draw background for flod
        QRect rect(option.rect.left(), option.rect.top() + disable_height,\
         option.rect.width(), remain_height);
        QBrush brush(Qt::yellow);
        painter->fillRect(rect, brush);
    }
    QTextDocument doc;
    doc.setHtml(options.text);

    options.text = "";
    //options.widget->style()->drawControl(QStyle::CE_ItemViewItem, &option, painter);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```