`timeSinceEpochMillisec`: The function of `timeSinceEpochMillisec` is to return the current time in milliseconds since the Unix epoch (January 1, 1970).

**Code Description**: This function uses the C++ `<chrono>` library to get the current time from the system clock. It then calculates the duration in milliseconds from the Unix epoch to the current time. The `system_clock::now()` function retrieves the current time point, and `time_since_epoch()` returns the duration since the epoch. This duration is then cast to milliseconds using `duration_cast<milliseconds>`, and the count of milliseconds is returned as a `uint64_t` value.\\
## Code: 
```
uint64_t timeSinceEpochMillisec() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
}
```