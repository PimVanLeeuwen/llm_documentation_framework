`normalization_tanh`: The function of `normalization_tanh` is to normalize a given value using the hyperbolic tangent function.

**Code Description**: 
The `normalization_tanh` function takes three float parameters: `stack`, `ev`, and `ratio`. It first calculates the intermediate value `x` by dividing `ev` by `stack` and then multiplying the result by `ratio`. The function then applies the hyperbolic tangent function (`tanh`) to `x`, scales the result to the range [0, 1] by dividing by 2 and adding 0.5, and returns this normalized value. This normalization technique ensures that the output is always between 0 and 1, providing a smooth transition for values centered around zero.\\
## Code: 
```
float normalization_tanh(float stack,float ev,float ratio){
    float x = ev / stack * ratio;
    return tanh(x) / 2 + 0.5;
}
```