`random`: The function of `random` is to generate a random integer within a specified range.

**Code Description**: The `random` function takes two integer parameters, `min` and `max`. It returns a random integer that is greater than or equal to `min` and less than `max`. The function uses the `rand()` function from the C standard library to generate a random number, then scales and shifts this number to fit within the specified range. The expression `rand() % ((max) - min)` generates a random number between 0 (inclusive) and `(max - min)` (exclusive), and adding `min` shifts this range to be between `min` (inclusive) and `max` (exclusive).\\
## Code: 
```
int random(int min, int max) //range : [min, max)
{
    return min + rand() % (( max ) - min);
}
```