`string_split`: The function of `string_split` is to split a given string into a vector of substrings based on a specified delimiter character.

**Code Description**: The `string_split` function takes two parameters: a string `strin` and a character `split`. It initializes an empty vector of strings `retval` to store the resulting substrings. A `stringstream` object `ss` is created from the input string `strin`. The function then uses a `while` loop to read substrings from the `stringstream` object, using the specified delimiter `split`. Each extracted substring (`token`) is added to the `retval` vector. Finally, the function returns the `retval` vector containing all the substrings.\\
## Code: 
```
vector<string> string_split(string strin,char split){
    vector<string> retval;
    stringstream ss(strin);
    string token;
    while (getline(ss,token, split))
    {
        retval.push_back(token);
    }
    return retval;
}
```