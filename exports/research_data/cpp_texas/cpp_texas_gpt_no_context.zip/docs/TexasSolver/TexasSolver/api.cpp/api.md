`api`: The function of `api` is to execute a command-line tool for poker game simulations based on the specified mode and resource directory, either from a file or interactively.

**Code Description**: 
- The `api` function takes three parameters: `input_file` (a string representing the path to an input file), `resource_dir` (a string representing the path to the resource directory, defaulting to "./resources"), and `mode` (a string representing the game mode, defaulting to "holdem").
- The function converts the C-style string parameters to C++ `string` objects.
- It checks if the `mode` is either "holdem" or "shortdeck". If not, it throws a runtime error with a descriptive message.
- If `input_file` is empty, it creates an instance of `CommandLineTool` with the specified `mode` and `resource_dir`, and starts the tool interactively by calling `startWorking()`.
- If `input_file` is not empty, it prints "EXEC FROM FILE" to the console, creates an instance of `CommandLineTool` with the specified `mode` and `resource_dir`, and executes commands from the file by calling `execFromFile(input_file)`.\\
## Code: 
```
EXPORT
int api(const char * input_file, const char * resource_dir = "./resources", const char * mode = "holdem") {
    string input_file_ = input_file;
    string resource_dir_ = resource_dir;
    string mode_ = mode;

    if(mode_ != "holdem" && mode_ != "shortdeck")
        throw runtime_error(tfm::format("mode %s error, not in ['holdem','shortdeck']", mode_));

    if(input_file_.empty()) {
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.startWorking();
    }else{
        cout << "EXEC FROM FILE" << endl;
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.execFromFile(input_file_);
    }
}
```