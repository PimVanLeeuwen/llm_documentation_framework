`on_turnCardBox_currentIndexChanged`: The function of `on_turnCardBox_currentIndexChanged` is to update the strategy model and the user interface when the selected card in the turn card box changes.

**Code Description**: 
- The function `on_turnCardBox_currentIndexChanged` is triggered when the current index of the turn card box changes.
- It first checks if there are any cards in the `cards` vector and if the new index is within the bounds of this vector.
- If both conditions are met, it sets the turn card in the `tableStrategyModel` to the card at the new index.
- It then calls `updateStrategyData` on the `tableStrategyModel` to refresh the strategy data.
- The commented-out lines indicate that calling `onchanged` on `roughStrategyViewerModel` and updating the viewport of `roughStrategyView` may cause bugs or crashes.
- The function proceeds to call `process_board` with the `treeItem` from `tableStrategyModel`.
- Finally, it updates the viewports of `strategyTableView` and `detailView` to reflect the changes.\\
## Code: 
```
void StrategyExplorer::on_turnCardBox_currentIndexChanged(int index)
{
    if(this->cards.size() > 0 && index < this->cards.size()){
        this->tableStrategyModel->setTrunCard(this->cards[index]);
        this->tableStrategyModel->updateStrategyData();
        // TODO this somehow cause bugs, crashes, why?
        //this->roughStrategyViewerModel->onchanged();
        //this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```