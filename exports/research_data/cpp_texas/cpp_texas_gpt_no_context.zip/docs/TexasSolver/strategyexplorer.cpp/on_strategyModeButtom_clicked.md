`on_strategyModeButtom_clicked`: The function of `on_strategyModeButtom_clicked` is to update the user interface and internal settings to reflect the strategy mode.

**Code Description**: 
- The function sets the `mode` attribute of the `detailWindowSetting` object to `DetailWindowSetting::DetailWindowMode::STRATEGY`.
- It then updates the viewports of `strategyTableView`, `detailView`, and `roughStrategyView` to reflect any changes.
- The `onchanged` method of the `roughStrategyViewerModel` is called to handle any necessary updates or changes in the model.
\\
## Code: 
```
void StrategyExplorer::on_strategyModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::STRATEGY;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```