`onMouseMoveEvent`: The function of `onMouseMoveEvent` is to update the grid coordinates and refresh the display of the detail view and strategy table view when the mouse is moved.

**Code Description**: The `onMouseMoveEvent` function takes two integer parameters, `i` and `j`, which represent the new grid coordinates. It updates the `grid_i` and `grid_j` properties of the `detailWindowSetting` object with these new coordinates. Then, it calls the `update` method on the `viewport` of both `detailView` and `strategyTableView` to refresh their displays, ensuring that any changes in the grid coordinates are visually reflected in the user interface.\\
## Code: 
```
void StrategyExplorer::onMouseMoveEvent(int i,int j){
    this->detailWindowSetting.grid_i = i;
    this->detailWindowSetting.grid_j = j;
    this->ui->detailView->viewport()->update();
    this->ui->strategyTableView->viewport()->update();
}
```