`update_second`: The function of `update_second` is to update various UI components and strategy data within the `StrategyExplorer` object.

**Code Description**: 
- The function first checks if there are any cards in the `cards` vector.
- If there are cards, it updates the strategy data in `tableStrategyModel` by calling `updateStrategyData()`.
- It then triggers the `onchanged()` method of `roughStrategyViewerModel`.
- The viewport of `roughStrategyView` is updated by calling its `update()` method.
- The `process_board` method is called with `tableStrategyModel->treeItem` as an argument to process the board state.
- Regardless of whether there are cards or not, the viewports of `strategyTableView` and `detailView` are updated by calling their `update()` methods.\\
## Code: 
```
void StrategyExplorer::update_second(){
    if(this->cards.size() > 0){
        this->tableStrategyModel->updateStrategyData();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```