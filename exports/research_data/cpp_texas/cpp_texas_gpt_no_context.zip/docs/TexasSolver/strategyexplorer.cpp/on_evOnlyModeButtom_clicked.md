`on_evOnlyModeButtom_clicked`: The function of `on_evOnlyModeButtom_clicked` is to set the detail window mode to "EV_ONLY" and update the relevant UI components.

**Code Description**: This function is a slot that gets triggered when the "EV Only Mode" button is clicked. It performs the following actions:
1. Sets the `mode` attribute of the `detailWindowSetting` object to `DetailWindowSetting::DetailWindowMode::EV_ONLY`.
2. Updates the viewports of `strategyTableView` and `detailView` to reflect the change.
3. Calls the `onchanged` method of the `roughStrategyViewerModel` to handle any necessary updates.
4. Updates the viewport of `roughStrategyView` to ensure all changes are displayed.\\
## Code: 
```
void StrategyExplorer::on_evOnlyModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::EV_ONLY;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```