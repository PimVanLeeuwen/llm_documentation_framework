`item_clicked`: The function of `item_clicked` is to handle the event when an item in a tree view is clicked.

**Code Description**: 
- The function takes a `QModelIndex` object as a parameter, which represents the index of the clicked item.
- It attempts to cast the internal pointer of the index to a `TreeItem` object.
- It processes the clicked tree node by calling `process_treeclick` and `process_board` methods with the tree node as an argument.
- It updates the `tableStrategyModel` with the new tree node by calling `setGameTreeNode` and `updateStrategyData`.
- It refreshes the `strategyTableView` by updating its viewport.
- It triggers the `roughStrategyViewerModel` to handle changes by calling `onchanged`.
- It resizes and updates the viewport of `roughStrategyView`.
- If a runtime error occurs during these operations, it catches the exception, logs an error message, and prints the error details using `qDebug`.\\
## Code: 
```
void StrategyExplorer::item_clicked(const QModelIndex& index){
    try{
        TreeItem * treeNode = static_cast<TreeItem*>(index.internalPointer());
        this->process_treeclick(treeNode);
        this->process_board(treeNode);
        this->tableStrategyModel->setGameTreeNode(treeNode);
        this->tableStrategyModel->updateStrategyData();
        this->ui->strategyTableView->viewport()->update();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->triger_resize();
        this->ui->roughStrategyView->viewport()->update();
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```