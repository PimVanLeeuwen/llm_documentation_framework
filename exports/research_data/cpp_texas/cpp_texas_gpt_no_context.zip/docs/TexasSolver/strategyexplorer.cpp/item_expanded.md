`item_expanded`: The function of `item_expanded` is to handle the event when an item in the tree view is expanded.

**Code Description**: This function is triggered when an item in the tree view is expanded. It first retrieves the `TreeItem` associated with the expanded index. It then iterates through all the children of this `TreeItem`. For each child, if the child has no further children, it calls the `reGenerateTreeItem` method on the tree model to regenerate the tree item based on the round data of the child. This ensures that the tree view is dynamically updated with the latest data when an item is expanded.\\
## Code: 
```
void StrategyExplorer::item_expanded(const QModelIndex& index){
    TreeItem *item = static_cast<TreeItem*>(index.internalPointer());
    int num_child = item->childCount();
    for (int i = 0;i < num_child;i ++){
        TreeItem* one_child = item->child(i);
        if(one_child->childCount() != 0)continue;
        this->ui->gameTreeView->tree_model->reGenerateTreeItem(one_child->m_treedata.lock()->getRound(),one_child);
    }
}
```