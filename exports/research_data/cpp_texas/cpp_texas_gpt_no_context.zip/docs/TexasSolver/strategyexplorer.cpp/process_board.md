`process_board`: The function of `process_board` is to process and display the current state of the game board based on the provided `TreeItem` and the current game round.

**Code Description**: 
- The function `process_board` takes a `TreeItem` pointer as an argument.
- It splits the board string from `qSolverJob` using commas as delimiters and stores the resulting substrings in a vector of strings (`board_str_arr`).
- Each string in `board_str_arr` is converted into a `Card` object and added to the `cards` vector.
- If the `treeitem` is not null, the function checks the current game round:
  - If the round is `TURN` and the turn card is not empty, it adds the turn card to the `cards` vector.
  - If the round is `RIVER`, it adds both the turn card and the river card to the `cards` vector if they are not empty.
- Finally, the function updates the `boardLabel` in the UI to display the current board cards in HTML format.\\
## Code: 
```
void StrategyExplorer::process_board(TreeItem* treeitem){
    vector<string> board_str_arr = string_split(this->qSolverJob->board,',');
    vector<Card> cards;
    for(string one_board_str:board_str_arr){
        cards.push_back(Card(one_board_str));
    }
    if(treeitem != NULL){
        if(treeitem->m_treedata.lock()->getRound() == GameTreeNode::GameRound::TURN && !this->tableStrategyModel->getTrunCard().empty()){
            cards.push_back(Card(this->tableStrategyModel->getTrunCard()));
        }
        else if(treeitem->m_treedata.lock()->getRound() == GameTreeNode::GameRound::RIVER){
            if(!this->tableStrategyModel->getTrunCard().empty())
                cards.push_back(Card(this->tableStrategyModel->getTrunCard()));
            if(!this->tableStrategyModel->getRiverCard().empty())
                cards.push_back(Card(this->tableStrategyModel->getRiverCard()));
        }
    }
    this->ui->boardLabel->setText(QString("<b>%1: </b>").arg(tr("board")) + Card::boardCards2html(cards));
}
```