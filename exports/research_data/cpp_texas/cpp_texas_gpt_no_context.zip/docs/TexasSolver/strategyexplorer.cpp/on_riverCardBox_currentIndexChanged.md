`on_riverCardBox_currentIndexChanged`: The function of `on_riverCardBox_currentIndexChanged` is to update the strategy model and the user interface when the selected river card changes.

**Code Description**: This function is triggered when the current index of the `riverCardBox` changes. It first checks if there are any cards available and if the new index is within the bounds of the `cards` list. If both conditions are met, it updates the `tableStrategyModel` with the new river card and refreshes the strategy data. It then processes the board state using the updated strategy model. Finally, it updates the viewports of the `strategyTableView` and `detailView` to reflect the changes.\\
## Code: 
```
void StrategyExplorer::on_riverCardBox_currentIndexChanged(int index)
{
    if(this->cards.size() > 0  && index < this->cards.size()){
        this->tableStrategyModel->setRiverCard(this->cards[index]);
        this->tableStrategyModel->updateStrategyData();
        //this->roughStrategyViewerModel->onchanged();
        //this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```