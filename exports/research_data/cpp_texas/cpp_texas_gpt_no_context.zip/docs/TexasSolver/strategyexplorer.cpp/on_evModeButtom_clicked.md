`on_evModeButtom_clicked`: The function of `on_evModeButtom_clicked` is to handle the event when the EV mode button is clicked.

**Code Description**: This function sets the mode of the `detailWindowSetting` object to `DetailWindowSetting::DetailWindowMode::EV`. It then updates the viewports of three UI components: `strategyTableView`, `detailView`, and `roughStrategyView`. This ensures that the user interface reflects the changes associated with switching to EV mode.\\
## Code: 
```
void StrategyExplorer::on_evModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::EV;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->ui->roughStrategyView->viewport()->update();
}
```