`on_ipRangeButtom_clicked`: The function of `on_ipRangeButtom_clicked` is to handle the event when the IP range button is clicked.

**Code Description**: This function sets the mode of the `detailWindowSetting` to `RANGE_IP`. It then updates the viewports of `strategyTableView`, `detailView`, and `roughStrategyView` to reflect any changes. Additionally, it triggers the `onchanged` method of the `roughStrategyViewerModel` to ensure that the model is updated accordingly.\\
## Code: 
```
void StrategyExplorer::on_ipRangeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::RANGE_IP;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```