`process_treeclick`: The function of `process_treeclick` is to update the UI label with the type of game tree node that was clicked.

**Code Description**: 
- The function `process_treeclick` takes a `TreeItem` pointer as an argument.
- It retrieves the associated `GameTreeNode` from the `TreeItem`.
- Depending on the type of `GameTreeNode` (ACTION, CHANCE, TERMINAL, SHOWDOWN), it updates the `nodeDisplayLabel` in the UI with a corresponding description.
- For ACTION nodes, it specifies whether the player is "IP" (in position) or "OOP" (out of position) and labels it as a "decision node".
- For CHANCE nodes, it labels it as a "Chance node".
- For TERMINAL nodes, it labels it as a "Terminal node".
- For SHOWDOWN nodes, it labels it as a "Showdown node".\\
## Code: 
```
void StrategyExplorer::process_treeclick(TreeItem* treeitem){
    shared_ptr<GameTreeNode> treenode = treeitem->m_treedata.lock();
    if(treenode->getType() == GameTreeNode::GameTreeNodeType::ACTION){
        shared_ptr<ActionNode> actionnode = static_pointer_cast<ActionNode>(treenode);
        QString action_str = QString("<b>%1 %2</b>").arg(actionnode->getPlayer() == 0?tr("IP"):tr("OOP"),tr(" decision node"));
        this->ui->nodeDisplayLabel->setText(action_str);
    }
    else if(treenode->getType() == GameTreeNode::GameTreeNodeType::CHANCE){
        QString chance_str = tr("<b>Chance node</b>");
        this->ui->nodeDisplayLabel->setText(chance_str);
    }
    else if(treenode->getType() == GameTreeNode::GameTreeNodeType::TERMINAL){
        QString terminal_str = tr("<b>Terminal node</b>");
        this->ui->nodeDisplayLabel->setText(terminal_str);
    }
    else if(treenode->getType() == GameTreeNode::GameTreeNodeType::SHOWDOWN){
        QString showdown_str = tr("<b>Showdown node</b>");
        this->ui->nodeDisplayLabel->setText(showdown_str);
    }
}
```