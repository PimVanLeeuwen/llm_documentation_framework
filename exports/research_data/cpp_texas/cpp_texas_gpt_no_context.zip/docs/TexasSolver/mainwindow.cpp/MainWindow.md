`MainWindow`: The function of `MainWindow` is to initialize the main window of the application, set up the user interface, connect UI actions to their respective slots, and start a solver job.

**Code Description**: 
- The `MainWindow` constructor initializes the main window by calling the parent class `QMainWindow` constructor and setting up the user interface using `ui->setupUi(this)`.
- It assigns a log window to `MainWindow::s_textEdit` by calling `this->get_logwindow()`.
- It connects various UI actions (like `actionjson`, `actionSettings`, `actionimport`, `actionexport`, and `actionclear_all`) to their respective slot functions (`on_actionjson_triggered`, `on_actionSettings_triggered`, `on_actionimport_triggered`, `on_actionexport_triggered`, and `on_actionclear_all_triggered`) using the `connect` function.
- It creates a new `QSovlerJob` object, sets its context to the log area, assigns it a mission type of `LOADING`, and starts the job.
- The window title is set to "TexasSolver".
- It sets up a file system model to filter and display `.txt` files from the "parameters" directory.\\
## Code: 
```
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    MainWindow::s_textEdit = this->get_logwindow();
    connect(this->ui->actionjson, &QAction::triggered, this, &MainWindow::on_actionjson_triggered);
    connect(this->ui->actionSettings, &QAction::triggered, this, &MainWindow::on_actionSettings_triggered);
    connect(this->ui->actionimport, &QAction::triggered, this, &MainWindow::on_actionimport_triggered);
    connect(this->ui->actionexport, &QAction::triggered, this, &MainWindow::on_actionexport_triggered);
    connect(this->ui->actionclear_all, &QAction::triggered, this, &MainWindow::on_actionclear_all_triggered);
    qSolverJob = new QSolverJob;
    qSolverJob->setContext(this->getLogArea());
    qSolverJob->current_mission = QSolverJob::MissionType::LOADING;
    qSolverJob->start();
    this->setWindowTitle(tr("TexasSolver"));

    // parameters tree view
    QStringList filters;
    filters << "*.txt";
    qFileSystemModel = new QFileSystemModel(this);
    QDir filedir = QDir::current().filePath("parameters");
    qFileSystemModel->setRootPath(filedir.path());
#ifdef Q_OS_MAC
```