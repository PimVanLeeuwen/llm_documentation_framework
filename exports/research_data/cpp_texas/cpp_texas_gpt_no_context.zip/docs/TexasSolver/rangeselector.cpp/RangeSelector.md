`RangeSelector`: The function of `RangeSelector` is to create a dialog for selecting ranges of poker hands based on the game mode (HOLDEM or SHORTDECK).

**Code Description**: 
- The constructor `RangeSelector::RangeSelector` initializes a dialog for selecting poker hand ranges.
- It takes three parameters: a `QTextEdit` pointer `rangeEdit`, a `QWidget` pointer `parent`, and a `QSolverJob::Mode` enumeration `mode`.
- Depending on the `mode`, it sets the `ranks` string to a list of poker hand ranks suitable for either HOLDEM or SHORTDECK.
- The `ranks` string is split into a list and stored in `rank_list`.
- It initializes `rangeSelectorTableModel` and `rangeSelectorTableDelegate` with the `rank_list` and the text from `rangeEdit`.
- The UI is set up using `ui->setupUi(this)`.
- The `rangeTableView` is configured with the model and delegate.
- The `rangeEdit` is assigned to the class member and its text is set in `ui->textEdit`.
- The `rangeNumberSlider` is configured with a maximum value and set to that value.
- The window title is set to "RangeSelector".
- Connections are made to handle item press, area selection, and item release events in the `rangeTableView`.
- A `QFileSystemModel` is initialized to filter and display `.txt` files from the "ranges" directory.\\
## Code: 
```
RangeSelector::RangeSelector(QTextEdit* rangeEdit,QWidget *parent,QSolverJob::Mode mode) :
    QDialog(parent),
    ui(new Ui::RangeSelector)
{

    QString ranks;
    if(mode == QSolverJob::Mode::HOLDEM){
        ranks = "A,K,Q,J,T,9,8,7,6,5,4,3,2";
    }else if(mode == QSolverJob::Mode::SHORTDECK){
        ranks = "A,K,Q,J,T,9,8,7,6";
    }else{
        throw runtime_error("mode not found in range selector");
    }
    this->rank_list = ranks.split(",");
    this->rangeSelectorTableModel = new RangeSelectorTableModel(this->rank_list,rangeEdit->toPlainText(),this);
    this->rangeSelectorTableDelegate = new RangeSelectorTableDelegate(this->rank_list,this->rangeSelectorTableModel,this);
    ui->setupUi(this);
    this->ui->rangeTableView->setModel(this->rangeSelectorTableModel);
    this->ui->rangeTableView->setItemDelegate(this->rangeSelectorTableDelegate);
    this->rangeEdit = rangeEdit;
    this->ui->textEdit->setText(this->rangeEdit->toPlainText());
    this->ui->rangeNumberSlider->setMaximum(this->max_val);
    this->ui->rangeNumberSlider->setValue(this->max_val);
    this->setWindowTitle(tr("RangeSelector"));
    connect(this->ui->rangeTableView,SIGNAL(view_item_pressed(int,int)),this,SLOT(grid_pressed(int,int)));
    connect(this->ui->rangeTableView,SIGNAL(view_item_area(int,int,int,int)),this,SLOT(grid_area(int,int,int,int)));
    connect(this->ui->rangeTableView,SIGNAL(item_release(int,int)),this,SLOT(grid_release(int,int)));

    QStringList filters;
    filters << "*.txt";
    qFileSystemModel = new QFileSystemModel(this);
    QDir filedir = QDir::current().filePath("ranges");
    qFileSystemModel->setRootPath(filedir.path());
#ifdef Q_OS_MAC
```