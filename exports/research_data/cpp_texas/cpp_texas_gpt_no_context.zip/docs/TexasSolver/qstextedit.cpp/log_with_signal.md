`log_with_signal`: The function of `log_with_signal` is to emit a signal with a given message.

**Code Description**: The `log_with_signal` function in the `QSTextEdit` class takes a `QString` parameter named `message` and emits a signal called `message_signal`, passing the `message` as an argument. This allows other parts of the application to be notified and respond to the message when the signal is emitted.\\
## Code: 
```
void QSTextEdit::log_with_signal(QString message){
    emit message_signal(message);
}
```