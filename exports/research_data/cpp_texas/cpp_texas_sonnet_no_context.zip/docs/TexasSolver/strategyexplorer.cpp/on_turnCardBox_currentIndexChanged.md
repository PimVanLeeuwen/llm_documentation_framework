`on_turnCardBox_currentIndexChanged`: The function of `on_turnCardBox_currentIndexChanged` is to update the strategy and views when a new turn card is selected.

**Code Description**: This method is triggered when the index of a turn card selection box changes. It first checks if there are cards available and if the selected index is valid. If so, it updates the table strategy model with the newly selected turn card and refreshes the strategy data. The function then processes the board using the updated strategy tree item. Finally, it updates the viewport of the strategy table view and detail view to reflect the changes. There's a commented-out section that suggests potential issues with updating the rough strategy viewer, which has been disabled to prevent crashes.\\
## Code: 
```
void StrategyExplorer::on_turnCardBox_currentIndexChanged(int index)
{
    if(this->cards.size() > 0 && index < this->cards.size()){
        this->tableStrategyModel->setTrunCard(this->cards[index]);
        this->tableStrategyModel->updateStrategyData();
        // TODO this somehow cause bugs, crashes, why?
        //this->roughStrategyViewerModel->onchanged();
        //this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```