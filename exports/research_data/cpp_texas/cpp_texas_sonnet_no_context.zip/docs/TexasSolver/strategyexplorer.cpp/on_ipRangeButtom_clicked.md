`on_ipRangeButtom_clicked`: The function of `on_ipRangeButtom_clicked` is to update the UI and models when the IP range button is clicked.

**Code Description**: This method is triggered when an IP range button is clicked in the StrategyExplorer interface. It performs the following actions:

1. Sets the `mode` of `detailWindowSetting` to `RANGE_IP`, indicating that the detail window should display IP range information.

2. Updates the viewport of the strategy table view (`strategyTableView`) to reflect any changes.

3. Updates the viewport of the detail view (`detailView`) to show the new IP range information.

4. Calls the `onchanged()` method of the `roughStrategyViewerModel` to update its data or state.

5. Updates the viewport of the rough strategy view (`roughStrategyView`) to display any changes in the model.

These actions ensure that all relevant UI components and underlying models are refreshed to reflect the new IP range selection, providing a consistent and up-to-date view for the user.\\
## Code: 
```
void StrategyExplorer::on_ipRangeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::RANGE_IP;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```