`item_clicked`: The function of `item_clicked` is to handle the event when an item in a tree view is clicked.

**Code Description**: This method is part of the StrategyExplorer class and is triggered when a user clicks on an item in a tree view. It performs several actions:

1. It retrieves the TreeItem object associated with the clicked index.
2. Calls process_treeclick and process_board methods with the retrieved TreeItem.
3. Updates the tableStrategyModel with the new TreeItem and refreshes its data.
4. Updates the viewport of the strategyTableView.
5. Notifies the roughStrategyViewerModel of changes.
6. Triggers a resize and viewport update for the roughStrategyView.

The method is wrapped in a try-catch block to handle runtime errors, which are logged using qDebug(). This error handling ensures that any exceptions during the click processing don't crash the application.\\
## Code: 
```
void StrategyExplorer::item_clicked(const QModelIndex& index){
    try{
        TreeItem * treeNode = static_cast<TreeItem*>(index.internalPointer());
        this->process_treeclick(treeNode);
        this->process_board(treeNode);
        this->tableStrategyModel->setGameTreeNode(treeNode);
        this->tableStrategyModel->updateStrategyData();
        this->ui->strategyTableView->viewport()->update();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->triger_resize();
        this->ui->roughStrategyView->viewport()->update();
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```