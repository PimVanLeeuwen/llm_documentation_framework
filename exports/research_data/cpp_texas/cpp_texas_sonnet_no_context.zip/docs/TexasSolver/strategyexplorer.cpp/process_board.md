`process_board`: The function of `process_board` is to update and display the current board state in a poker game.

**Code Description**: This method takes a TreeItem pointer as an argument and processes the board state for a poker game. It first splits the board string from qSolverJob into individual card strings. These strings are then converted into Card objects and stored in a vector. 

If a valid TreeItem is provided, the function checks the game round (TURN or RIVER) and adds additional cards to the board based on the current round. For the TURN round, it adds the turn card if available. For the RIVER round, it adds both the turn and river cards if they are available.

Finally, the function updates the UI by setting the text of a QLabel (boardLabel) with the processed board cards. The cards are displayed using HTML formatting, with a bold "board:" label preceding the card representation.\\
## Code: 
```
void StrategyExplorer::process_board(TreeItem* treeitem){
    vector<string> board_str_arr = string_split(this->qSolverJob->board,',');
    vector<Card> cards;
    for(string one_board_str:board_str_arr){
        cards.push_back(Card(one_board_str));
    }
    if(treeitem != NULL){
        if(treeitem->m_treedata.lock()->getRound() == GameTreeNode::GameRound::TURN && !this->tableStrategyModel->getTrunCard().empty()){
            cards.push_back(Card(this->tableStrategyModel->getTrunCard()));
        }
        else if(treeitem->m_treedata.lock()->getRound() == GameTreeNode::GameRound::RIVER){
            if(!this->tableStrategyModel->getTrunCard().empty())
                cards.push_back(Card(this->tableStrategyModel->getTrunCard()));
            if(!this->tableStrategyModel->getRiverCard().empty())
                cards.push_back(Card(this->tableStrategyModel->getRiverCard()));
        }
    }
    this->ui->boardLabel->setText(QString("<b>%1: </b>").arg(tr("board")) + Card::boardCards2html(cards));
}
```