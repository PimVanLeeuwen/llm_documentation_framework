`on_riverCardBox_currentIndexChanged`: The function of `on_riverCardBox_currentIndexChanged` is to update the strategy and UI elements when a new river card is selected.

**Code Description**: This method is triggered when the index of the river card selection box changes. It first checks if there are cards available and if the selected index is valid. If so, it updates the river card in the table strategy model, recalculates the strategy data, and processes the board with the updated information. Finally, it refreshes the strategy table view and detail view to reflect the changes. The function ensures that the strategy explorer's display is synchronized with the newly selected river card.\\
## Code: 
```
void StrategyExplorer::on_riverCardBox_currentIndexChanged(int index)
{
    if(this->cards.size() > 0  && index < this->cards.size()){
        this->tableStrategyModel->setRiverCard(this->cards[index]);
        this->tableStrategyModel->updateStrategyData();
        //this->roughStrategyViewerModel->onchanged();
        //this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```