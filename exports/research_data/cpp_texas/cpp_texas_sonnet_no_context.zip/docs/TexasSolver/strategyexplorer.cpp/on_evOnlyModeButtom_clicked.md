`on_evOnlyModeButtom_clicked`: The function of `on_evOnlyModeButtom_clicked` is to switch the detail window mode to EV_ONLY and update related views.

**Code Description**: This method is triggered when the EV-only mode button is clicked. It sets the `mode` of `detailWindowSetting` to `EV_ONLY`. Then, it updates several UI components:
1. The `strategyTableView`'s viewport is updated.
2. The `detailView`'s viewport is updated.
3. The `roughStrategyViewerModel` is notified of changes.
4. The `roughStrategyView`'s viewport is updated.

These updates ensure that all relevant parts of the user interface reflect the change to EV-only mode.\\
## Code: 
```
void StrategyExplorer::on_evOnlyModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::EV_ONLY;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```