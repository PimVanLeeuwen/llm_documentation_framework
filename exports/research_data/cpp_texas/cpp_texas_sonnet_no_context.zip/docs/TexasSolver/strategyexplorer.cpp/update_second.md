`update_second`: The function of `update_second` is to refresh and update various strategy-related views and models.

**Code Description**: This method performs several update operations if there are cards present. It updates the strategy data in the table model, triggers changes in the rough strategy viewer model, and refreshes the viewport of the rough strategy view. It then processes the board using the tree item from the table strategy model. Regardless of whether there are cards or not, it updates the viewports of the strategy table view and detail view. This function seems to be responsible for keeping the UI elements synchronized with the current game state and strategy information.\\
## Code: 
```
void StrategyExplorer::update_second(){
    if(this->cards.size() > 0){
        this->tableStrategyModel->updateStrategyData();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```