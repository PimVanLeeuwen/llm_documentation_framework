`onMouseMoveEvent`: The function of `onMouseMoveEvent` is to update the display based on the current mouse position.

**Code Description**: This method is part of the StrategyExplorer class and is triggered when the mouse moves. It takes two integer parameters, i and j, which likely represent grid coordinates. The function updates the detailWindowSetting's grid_i and grid_j properties with these new coordinates. It then calls the update() method on the viewport of both the detailView and strategyTableView UI elements, which likely refreshes their display to reflect the new mouse position. This suggests the StrategyExplorer interface uses a grid system and updates detailed information or highlights based on the mouse's current location.\\
## Code: 
```
void StrategyExplorer::onMouseMoveEvent(int i,int j){
    this->detailWindowSetting.grid_i = i;
    this->detailWindowSetting.grid_j = j;
    this->ui->detailView->viewport()->update();
    this->ui->strategyTableView->viewport()->update();
}
```