`on_evModeButtom_clicked`: The function of `on_evModeButtom_clicked` is to switch the detail window mode to EV and update related views.

**Code Description**: This method is part of the StrategyExplorer class and is triggered when the EV mode button is clicked. It sets the mode of the detailWindowSetting to EV (Expected Value) mode. After changing the mode, it updates three different views: the strategy table view, the detail view, and the rough strategy view. This is done by calling the update() method on their respective viewports. The updates likely refresh the display to reflect the new EV mode in these views.\\
## Code: 
```
void StrategyExplorer::on_evModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::EV;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->ui->roughStrategyView->viewport()->update();
}
```