`on_oopRangeButtom_clicked`: The function of `on_oopRangeButtom_clicked` is to update the UI and models when the OOP Range button is clicked.

**Code Description**: This method is part of the StrategyExplorer class and is triggered when the OOP Range button is clicked. It performs the following actions:

1. Sets the mode of detailWindowSetting to RANGE_OOP.
2. Updates the viewport of the strategyTableView.
3. Updates the viewport of the detailView.
4. Calls the onchanged() method of the roughStrategyViewerModel.
5. Updates the viewport of the roughStrategyView.

These actions likely refresh the display to show OOP (Out of Position) range information in various parts of the user interface, including the strategy table, detail view, and rough strategy view.\\
## Code: 
```
void StrategyExplorer::on_oopRangeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::RANGE_OOP;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```