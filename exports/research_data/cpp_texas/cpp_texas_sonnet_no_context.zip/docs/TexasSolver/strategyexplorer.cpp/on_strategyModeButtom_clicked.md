`on_strategyModeButtom_clicked`: The function of `on_strategyModeButtom_clicked` is to update the UI and models when the strategy mode button is clicked.

**Code Description**: This method is triggered when a strategy mode button is clicked in the StrategyExplorer interface. It performs several actions:

1. Sets the mode of `detailWindowSetting` to STRATEGY.
2. Updates the viewport of the strategy table view.
3. Updates the viewport of the detail view.
4. Calls the `onchanged()` method of the `roughStrategyViewerModel`.
5. Updates the viewport of the rough strategy view.

These actions likely refresh the UI components to reflect the change to strategy mode, ensuring that the correct information is displayed to the user. The method appears to be part of a larger application dealing with strategy visualization or management.\\
## Code: 
```
void StrategyExplorer::on_strategyModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::STRATEGY;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```