`item_expanded`: The function of `item_expanded` is to regenerate child items of an expanded tree item that have no children.

**Code Description**: This method is part of the StrategyExplorer class and is triggered when a tree item is expanded in a QTreeView. It takes a QModelIndex as an argument, which represents the expanded item. The function first retrieves the TreeItem object associated with the index. It then iterates through all the immediate children of this item. For each child that has no children of its own (i.e., childCount() == 0), it calls the reGenerateTreeItem method of the tree model to populate that child with new data. This regeneration is based on the round information stored in the child's associated tree data. The function effectively ensures that when a parent item is expanded, any of its childless children are populated with up-to-date information.\\
## Code: 
```
void StrategyExplorer::item_expanded(const QModelIndex& index){
    TreeItem *item = static_cast<TreeItem*>(index.internalPointer());
    int num_child = item->childCount();
    for (int i = 0;i < num_child;i ++){
        TreeItem* one_child = item->child(i);
        if(one_child->childCount() != 0)continue;
        this->ui->gameTreeView->tree_model->reGenerateTreeItem(one_child->m_treedata.lock()->getRound(),one_child);
    }
}
```