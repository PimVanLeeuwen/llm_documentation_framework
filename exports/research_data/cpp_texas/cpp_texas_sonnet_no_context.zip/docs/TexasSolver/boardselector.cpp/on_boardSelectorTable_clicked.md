`on_boardSelectorTable_clicked`: The function of `on_boardSelectorTable_clicked` is to handle clicks on a board selector table, toggling the state of the clicked cell and updating the UI accordingly.

**Code Description**: This function is triggered when a cell in the boardSelectorTable is clicked. It performs the following actions:

1. Retrieves the row and column of the clicked cell.
2. Toggles the state of the clicked cell by inverting its current value (0 to 1 or 1 to 0) using the boardSelectorTableModel.
3. Checks if the current text in the boardEdit UI element matches the updated board text from the model.
4. If there's a mismatch, it updates the boardEdit text to reflect the new board state.
5. Sets focus to the boardEdit element.
6. Finally, sets focus back to the boardSelectorTable.

This function essentially allows users to interact with a visual representation of a board, toggling cell states and keeping a text representation of the board synchronized with the visual changes.\\
## Code: 
```
void boardselector::on_boardSelectorTable_clicked(const QModelIndex &index)
{
    int row = index.row();
    int col = index.column();
    this->boardSelectorTableModel->setBoardAt(row,col,1 - this->boardSelectorTableModel->getBoardAt(row,col));
    if(this->ui->boardEdit->text() != this->boardSelectorTableModel->getBoardText()){
        this->ui->boardEdit->setText(this->boardSelectorTableModel->getBoardText());
    }
    this->ui->boardEdit->setFocus();
    this->ui->boardSelectorTable->setFocus();
}
```