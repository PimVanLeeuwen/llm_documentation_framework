`getCards`: The function of `getCards` is to return a reference to the vector of Card objects stored in the Deck.

**Code Description**: This is a member function of the Deck class that provides access to the private 'cards' member variable. It returns a reference to the vector<Card> object, allowing the caller to directly access and potentially modify the cards in the deck. The function doesn't perform any operations on the cards; it simply returns the existing vector by reference. This approach is efficient as it avoids copying the entire vector when the function is called.\\
## Code: 
```
vector<Card>& Deck::getCards() {
    return this->cards;
}
```