`Deck`: The function of `Deck` is to initialize a deck of playing cards.

**Code Description**: This constructor takes two vectors of strings as input: `ranks` and `suits`. It initializes the deck by combining each rank with each suit to create individual cards. The constructor performs the following steps:

1. Assigns the input `ranks` and `suits` to the corresponding member variables.
2. Initializes a counter `card_num` to keep track of card numbers.
3. Uses nested loops to iterate through all combinations of ranks and suits.
4. For each combination, it creates a string representation of the card by concatenating the rank and suit.
5. Adds the string representation to the `cards_str` vector.
6. Creates a `Card` object with the string representation and current card number, adding it to the `cards` vector.
7. Increments the `card_num` counter for the next card.

This process results in a fully initialized deck of cards, where each card has a string representation and a unique number assigned to it.\\
## Code: 
```
Deck::Deck(const vector<string>& ranks, const vector<string>& suits) {
    this->ranks = ranks;
    this->suits = suits;
    int card_num = 0;
    for(const string& one_rank : ranks){
        for(const string& one_suit: suits){
            string one_card = one_rank + one_suit;
            cards_str.push_back(one_card);
            cards.emplace_back(one_card,card_num);
            card_num += 1;
        }
    }
}
```