`boardCards2long`: The function of `boardCards2long` is to convert a vector of card strings into a 64-bit integer representation.

**Code Description**: This method takes a vector of strings representing cards and converts it into a 64-bit unsigned integer. It first creates a vector of Card objects from the input strings. Each string is used to construct a Card object. Then, it calls another overloaded version of `boardCards2long` that takes a vector of Card objects as input, passing the newly created vector of Card objects. The result of this call, which is a uint64_t (64-bit unsigned integer), is then returned. This method serves as a convenience function, allowing users to pass card representations as strings instead of Card objects, while still obtaining the same 64-bit integer output.\\
## Code: 
```
uint64_t Card::boardCards2long(vector<string> cards) {
    vector<Card> cards_objs(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_objs[i] = Card(cards[i]);
    }
    return Card::boardCards2long(cards_objs);
}
```