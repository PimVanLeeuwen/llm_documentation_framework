`boardCards2html`: The function of `boardCards2html` is to convert a vector of Card objects into an HTML string representation.

**Code Description**: This method takes a vector of Card objects as input and iterates through each card. For each non-empty card, it calls the `toFormattedHtml()` method to get its HTML representation and appends it to a QString. The function skips empty cards. Finally, it returns the concatenated HTML string containing the formatted representation of all non-empty cards in the input vector.\\
## Code: 
```
QString Card::boardCards2html(vector<Card>& cards){
    QString ret_html = "";
    for(auto one_card:cards){
        if(one_card.empty())continue;
        ret_html += one_card.toFormattedHtml();
    }
    return ret_html;
}
```