`getSuits`: The function of `getSuits` is to return a vector of strings representing card suits.

**Code Description**: This method is a member function of the `Card` class. It returns a vector containing four string elements: "c", "d", "h", and "s", which represent the four standard playing card suits (clubs, diamonds, hearts, and spades) respectively. The function doesn't take any parameters and always returns the same fixed set of suits. This implementation suggests that the suits are not stored as a member variable but are instead generated on demand when the function is called.\\
## Code: 
```
vector<string> Card::getSuits(){
    return {"c","d","h","s"};
}
```