`rankToString`: The function of `rankToString` is to convert a numeric card rank to its corresponding string representation.

**Code Description**: This method is a member function of the Card class that takes an integer parameter 'rank' and returns a string. It uses a switch statement to map numeric card ranks to their string equivalents. For ranks 2 through 9, it returns the number as a string. For 10, it returns "T". Jack, Queen, King, and Ace are represented by "J", "Q", "K", and "A" respectively. If an invalid rank is provided (outside the range 2-14), it defaults to returning "2". This function is likely used in displaying or representing card ranks in a more readable format, especially for face cards and ten.\\
## Code: 
```
string Card::rankToString(int rank)
{
    switch(rank)
    {
        case 2: return "2";
        case 3: return "3";
        case 4: return "4";
        case 5: return "5";
        case 6: return "6";
        case 7: return "7";
        case 8: return "8";
        case 9: return "9";
        case 10: return "T";
        case 11: return "J";
        case 12: return "Q";
        case 13: return "K";
        case 14: return "A";
        default: return "2";
    }
}
```