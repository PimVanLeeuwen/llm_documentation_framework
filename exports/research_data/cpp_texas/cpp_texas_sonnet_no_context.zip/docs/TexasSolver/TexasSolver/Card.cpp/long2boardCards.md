`long2boardCards`: The function of `long2boardCards` is to convert a 64-bit integer representation of a poker board into a vector of Card objects.

**Code Description**: This function takes a uint64_t parameter `board_long` and performs the following steps:

1. It calls `long2board` to convert the 64-bit integer into a vector of integers representing individual cards.

2. It creates a vector of Card objects (`board_cards`) with the same size as the integer vector.

3. It iterates through the integer vector, converting each integer to a string representation using `intCard2Str`, and then creates a Card object for each string, storing them in `board_cards`.

4. It checks if the number of cards is between 1 and 7 (inclusive). If not, it throws a runtime_error with a formatted error message.

5. It creates a new vector `retval` and copies the Card objects from `board_cards` into it.

6. Finally, it returns `retval`, which is a vector of Card objects representing the poker board.

The function essentially transforms a compact 64-bit representation of a poker board into a more usable format of Card objects, while also performing validation on the number of cards.\\
## Code: 
```
vector<Card> Card::long2boardCards(uint64_t board_long){
        vector<int> board = long2board(board_long);
        vector<Card> board_cards(board.size());
        for(std::size_t i = 0;i < board.size();i ++){
            int one_board = board[i];
            board_cards[i] = Card(intCard2Str(one_board));
        }
        if (board_cards.size() < 1 || board_cards.size() > 7){
            throw runtime_error(tfm::format("board length not correct, board length %s",board_cards.size()));
        }
        vector<Card> retval(board_cards.size());
        for(std::size_t i = 0;i < board_cards.size();i ++){
            retval[i] = board_cards[i];
        }
        return retval;
}
```