`boardInts2long`: The function of `boardInts2long` is to convert a vector of card integers into a single 64-bit unsigned integer representation.

**Code Description**: This method takes a vector of integers representing cards and converts it into a 64-bit unsigned integer (uint64_t). It first checks if the input vector's size is between 1 and 7, throwing a runtime error if not. Then, it iterates through each card in the input vector, ensuring each card's value is between 0 and 51 (representing a standard 52-card deck). For each valid card, it sets the corresponding bit in the uint64_t result by left-shifting 1 by the card's value and adding it to the result. This creates a bit mask where each set bit represents the presence of a specific card. The function returns this uint64_t representation, which efficiently encodes the presence of up to 52 different cards in a single 64-bit integer.\\
## Code: 
```
uint64_t Card::boardInts2long(const vector<int>& board){
    if(board.size() < 1 || board.size() > 7){
        throw runtime_error(tfm::format("Card length incorrect: %s",board.size()));
    }
    uint64_t board_long = 0;
    for(int one_card: board){
        // 这里hard code了一副扑克牌是52张
        if(one_card < 0 || one_card >= 52){
            throw runtime_error(tfm::format("Card with id %s not found",one_card));
        }
        // uint64_7 的range 在0 ~ + 2^ 64之间,所以不用太担心溢出问题
        board_long += ((uint64_t)(1) << one_card);
    }
    return board_long;
}
```