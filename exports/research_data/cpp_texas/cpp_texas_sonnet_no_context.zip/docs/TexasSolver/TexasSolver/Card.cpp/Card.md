`Card`: The function of `Card` is to initialize a Card object with a given card string.

**Code Description**: This is a constructor for the Card class that takes a string parameter 'card'. It initializes the object's 'card' member variable with the input string. It then converts the card string to an integer representation using a static method 'strCard2int' and stores it in the 'card_int' member variable. Finally, it sets the 'card_number_in_deck' member variable to -1, likely as a default value indicating that the card's position in a deck has not been assigned yet.\\
## Code: 
```
Card::Card(string card){
    this->card = card;
    this->card_int = Card::strCard2int(this->card);
    this->card_number_in_deck = -1;
}
```