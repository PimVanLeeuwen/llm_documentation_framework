`suitToInt`: The function of `suitToInt` is to convert a character representing a card suit to its corresponding integer value.

**Code Description**: This method is a member function of the Card class. It takes a single character parameter 'suit' and returns an integer. The function uses a switch statement to map specific suit characters to integer values:
- 'c' (representing clubs) returns 0
- 'd' (representing diamonds) returns 1
- 'h' (representing hearts) returns 2
- 's' (representing spades) returns 3
If the input character doesn't match any of these cases, the function defaults to returning 0. This mapping allows for easy numerical representation of card suits, which can be useful for sorting, comparison, or other game logic operations.\\
## Code: 
```
int Card::suitToInt(char suit)
{
    switch(suit)
    {
        case 'c': return 0; // 梅花
        case 'd': return 1; // 方块
        case 'h': return 2; // 红桃
        case 's': return 3; // 黑桃
        default: return 0;
    }
}
```