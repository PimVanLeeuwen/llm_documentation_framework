`suitToString`: The function of `suitToString` is to convert a numeric suit value to its corresponding string representation.

**Code Description**: This method is a member function of the `Card` class. It takes an integer parameter `suit` and returns a string representation of the card suit. The function uses a switch statement to map numeric values to their corresponding suit abbreviations:

- 0 returns "c" (representing Clubs)
- 1 returns "d" (representing Diamonds)
- 2 returns "h" (representing Hearts)
- 3 returns "s" (representing Spades)

If the input is not 0, 1, 2, or 3, the function defaults to returning "c". This suggests that Clubs is treated as the default suit in case of an invalid input.\\
## Code: 
```
string Card::suitToString(int suit)
{
    switch(suit)
    {
        case 0: return "c";
        case 1: return "d";
        case 2: return "h";
        case 3: return "s";
        default: return "c";
    }
}
```