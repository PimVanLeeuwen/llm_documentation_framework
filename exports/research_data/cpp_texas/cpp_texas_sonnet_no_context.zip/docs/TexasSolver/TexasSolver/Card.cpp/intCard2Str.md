`intCard2Str`: The function of `intCard2Str` is to convert an integer representation of a playing card to its string representation.

**Code Description**: This method takes an integer `card` as input and converts it to a string representation of a playing card. It first calculates the rank by integer division of `card` by 4 and adding 2. The suit is then determined by subtracting the product of (rank-2) and 4 from the input `card`. The method then combines the string representations of the rank and suit, obtained through calls to `Card::rankToString()` and `Card::suitToString()` respectively, and returns the resulting string. This approach allows for a compact integer encoding of cards while providing a human-readable string output.\\
## Code: 
```
string Card::intCard2Str(int card){
    int rank = card / 4 + 2;
    int suit = card - (rank-2)*4;
    return Card::rankToString(rank) + Card::suitToString(suit);
}
```