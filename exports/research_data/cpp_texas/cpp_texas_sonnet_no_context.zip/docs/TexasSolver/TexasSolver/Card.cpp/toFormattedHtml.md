`toFormattedHtml`: The function of `toFormattedHtml` is to convert a card's string representation into an HTML-formatted string with colored suit symbols.

**Code Description**: This method belongs to a Card class and operates on a string representation of a card stored in the `card` member variable. It first converts the card string to a QString. Then, it checks for the presence of suit identifiers ('c' for clubs, 'd' for diamonds, 'h' for hearts, 's' for spades) and replaces them with their corresponding HTML-encoded Unicode symbols. The suits are color-coded: black for clubs and spades, red for diamonds and hearts. The symbols are wrapped in HTML span tags to apply the appropriate color. The resulting QString with formatted HTML is returned, ready for display in a Qt application that supports HTML rendering.\\
## Code: 
```
QString Card::toFormattedHtml() {
    QString qString = QString::fromStdString(this->card);
    if(qString.contains("c"))
        qString = qString.replace("c", QString::fromLocal8Bit("<span style=\"color:black;\">&#9827;<\/span>"));
    else if(qString.contains("d"))
        qString = qString.replace("d", QString::fromLocal8Bit("<span style=\"color:red;\">&#9830;<\/span>"));
    else if(qString.contains("h"))
        qString = qString.replace("h", QString::fromLocal8Bit("<span style=\"color:red;\">&#9829;<\/span>"));
    else if(qString.contains("s"))
        qString = qString.replace("s", QString::fromLocal8Bit("<span style=\"color:black;\">&#9824;<\/span>"));
    return qString;
}
```