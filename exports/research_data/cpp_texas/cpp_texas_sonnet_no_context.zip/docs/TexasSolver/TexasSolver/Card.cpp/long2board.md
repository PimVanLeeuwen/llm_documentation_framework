`long2board`: The function of `long2board` is to convert a 64-bit integer representation of a card board into a vector of card indices.

**Code Description**: This method takes a uint64_t parameter `board_long`, which represents a card board using a bitwise encoding. It iterates through the 52 bits (corresponding to 52 cards in a deck) of the input, checking each bit. If a bit is set (1), the corresponding card index is added to the output vector. The function uses bitwise operations to efficiently process the input. It reserves space for up to 7 cards in the output vector for performance. After processing, it verifies that the resulting board size is between 1 and 7 cards, throwing a runtime error if this condition is not met. The function returns the vector of card indices representing the board.\\
## Code: 
```
vector<int> Card::long2board(uint64_t board_long) {
    vector<int> board;
    board.reserve(7);
    for(int i = 0;i < 52;i ++){
        // 看二进制最后一位是否为1
        if((board_long & 1) == 1){
            board.push_back(i);
        }
        board_long = board_long >> 1;
    }
    if (board.size() < 1 || board.size() > 7){
        throw runtime_error(tfm::format("board length not correct, board length %s",board.size()));
    }
    return board;
}
```