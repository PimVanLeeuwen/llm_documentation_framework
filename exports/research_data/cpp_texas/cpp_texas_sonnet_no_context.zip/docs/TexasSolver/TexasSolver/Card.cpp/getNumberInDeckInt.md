`getNumberInDeckInt`: The function of `getNumberInDeckInt` is to return the card's number in the deck.

**Code Description**: This method is a member function of the `Card` class. It retrieves and returns the value of the `card_number_in_deck` member variable. Before returning the value, it performs a validation check. If `card_number_in_deck` is equal to -1, the function throws a `runtime_error` with the message "card number in deck cannot be -1". This error handling ensures that the card has a valid number assigned within the deck. If the check passes, the function returns the integer value of `card_number_in_deck`.\\
## Code: 
```
int Card::getNumberInDeckInt(){
    if(this->card_number_in_deck == -1)throw runtime_error("card number in deck cannot be -1");
    return this->card_number_in_deck;
}
```