`strCard2int`: The function of `strCard2int` is to convert a string representation of a playing card to an integer value.

**Code Description**: This method takes a string parameter 'card' representing a playing card. It first checks if the string length is exactly 2 characters. If not, it throws a runtime error with a formatted message. The function then extracts the rank (first character) and suit (second character) from the string. It uses helper functions 'rankToInt' and 'suitToInt' to convert the rank and suit to integer values. The final integer representation is calculated using the formula: (rankToInt(rank) - 2) * 4 + suitToInt(suit). This creates a unique integer for each card in a standard 52-card deck.\\
## Code: 
```
int Card::strCard2int(string card) {
    char rank = card.at(0);
    char suit = card.at(1);
    if(card.length() != 2){
        throw runtime_error( tfm::format("card %s not found",card));
    }
    return (rankToInt(rank) - 2) * 4 + suitToInt(suit);
}
```