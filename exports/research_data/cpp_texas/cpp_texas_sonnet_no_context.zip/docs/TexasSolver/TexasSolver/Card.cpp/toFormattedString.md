`toFormattedString`: The function of `toFormattedString` is to convert a card's string representation to a formatted version with Unicode suit symbols.

**Code Description**: This method is a member of the Card class and returns a string. It takes the card's string representation stored in the 'card' member variable and converts it to a QString. Then, it replaces the single-character suit indicators (c, d, h, s) with their corresponding Unicode symbols (♣️, ♦️, ♥️, ♠️). Finally, it converts the formatted QString back to a standard string and returns it. This transformation enhances the visual representation of the card by using easily recognizable suit symbols instead of letters.\\
## Code: 
```
string Card::toFormattedString() {
    QString qString = QString::fromStdString(this->card);
    qString = qString.replace("c", "♣️");
    qString = qString.replace("d", "♦️");
    qString = qString.replace("h", "♥️");
    qString = qString.replace("s", "♠️");
    return qString.toStdString();
}
```