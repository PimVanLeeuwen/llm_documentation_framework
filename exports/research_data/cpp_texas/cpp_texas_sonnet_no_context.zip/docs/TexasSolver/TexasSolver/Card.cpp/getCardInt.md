`getCardInt`: The function of `getCardInt` is to return the integer value of a card.

**Code Description**: This is a member function of the `Card` class that returns the value stored in the `card_int` member variable. It uses the `this` pointer to access the current object's `card_int` attribute and simply returns its value. The function does not modify any data and has no parameters, suggesting it is likely used as a getter method to retrieve the card's integer representation.\\
## Code: 
```
int Card::getCardInt() {
    return this->card_int;
}
```