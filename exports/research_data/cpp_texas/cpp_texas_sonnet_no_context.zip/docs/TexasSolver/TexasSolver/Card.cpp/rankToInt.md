`rankToInt`: The function of `rankToInt` is to convert a card rank character to its corresponding integer value.

**Code Description**: This method is a member function of the Card class that takes a single character parameter representing a card's rank. It uses a switch statement to map each valid rank character to its numerical equivalent. For standard playing cards, '2' through '9' are mapped to their face values (2-9), while 'T' (10), 'J' (Jack), 'Q' (Queen), 'K' (King), and 'A' (Ace) are mapped to 10, 11, 12, 13, and 14 respectively. If an invalid rank is provided, the function defaults to returning 2. This conversion is useful for comparing card ranks or performing calculations based on card values in card game implementations.\\
## Code: 
```
int Card::rankToInt(char rank)
{
    switch(rank)
    {
        case '2': return 2;
        case '3': return 3;
        case '4': return 4;
        case '5': return 5;
        case '6': return 6;
        case '7': return 7;
        case '8': return 8;
        case '9': return 9;
        case 'T': return 10;
        case 'J': return 11;
        case 'Q': return 12;
        case 'K': return 13;
        case 'A': return 14;
        default: return 2;
    }
}
```