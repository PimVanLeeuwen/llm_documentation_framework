`boardInt2long`: The function of `boardInt2long` is to convert a board integer to a 64-bit long integer representation.

**Code Description**: This function takes an integer `board` as input, which represents a card in a standard 52-card deck. It performs the following operations:

1. It first checks if the input `board` is within the valid range (0 to 51). If not, it throws a runtime error with a formatted error message.

2. If the input is valid, it performs a bitwise left shift operation on the value 1 (as a 64-bit unsigned integer) by the number of positions specified by `board`.

3. The result is a 64-bit unsigned integer (uint64_t) where only one bit is set to 1, and its position corresponds to the input `board` value.

This function is likely used for efficient card representation in memory, where each card is represented by a single bit in a 64-bit integer. This allows for fast bitwise operations when dealing with sets of cards.\\
## Code: 
```
uint64_t Card::boardInt2long(int board){
    // 这里hard code了一副扑克牌是52张
    if(board < 0 || board >= 52){
        throw runtime_error(tfm::format("Card with id %s not found",board));
    }
    // uint64_7 的range 在0 ~ + 2^ 64之间,所以不用太担心溢出问题
    return ((uint64_t)(1) << board);
}
```