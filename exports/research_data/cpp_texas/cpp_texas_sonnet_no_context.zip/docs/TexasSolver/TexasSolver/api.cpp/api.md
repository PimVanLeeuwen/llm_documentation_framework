`api`: The function of `api` is to initialize and execute a command-line tool for poker game analysis.

**Code Description**: This function takes three parameters: `input_file` (a file path for input), `resource_dir` (directory path for resources, defaulting to "./resources"), and `mode` (game mode, defaulting to "holdem"). It first validates the `mode` parameter, ensuring it's either "holdem" or "shortdeck". If an invalid mode is provided, it throws a runtime error. The function then creates a CommandLineTool object with the specified mode and resource directory. If no input file is provided, it starts the tool in an interactive mode using `startWorking()`. If an input file is specified, it executes commands from that file using `execFromFile()`. This allows the tool to be used both interactively and with pre-defined input files, supporting different poker variants and customizable resource locations.\\
## Code: 
```
EXPORT
int api(const char * input_file, const char * resource_dir = "./resources", const char * mode = "holdem") {
    string input_file_ = input_file;
    string resource_dir_ = resource_dir;
    string mode_ = mode;

    if(mode_ != "holdem" && mode_ != "shortdeck")
        throw runtime_error(tfm::format("mode %s error, not in ['holdem','shortdeck']", mode_));

    if(input_file_.empty()) {
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.startWorking();
    }else{
        cout << "EXEC FROM FILE" << endl;
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.execFromFile(input_file_);
    }
}
```