`string_split`: The function of `string_split` is to split a string into substrings based on a specified delimiter character.

**Code Description**: This function takes two parameters: a string `strin` to be split and a character `split` that serves as the delimiter. It uses a `stringstream` to process the input string and `getline()` to extract substrings. Each substring is stored in a `vector<string>` called `retval`. The function iterates through the input string, separating it at each occurrence of the delimiter character, and adds each resulting substring to the vector. Finally, it returns the vector containing all the split substrings.\\
## Code: 
```
vector<string> string_split(string strin,char split){
    vector<string> retval;
    stringstream ss(strin);
    string token;
    while (getline(ss,token, split))
    {
        retval.push_back(token);
    }
    return retval;
}
```