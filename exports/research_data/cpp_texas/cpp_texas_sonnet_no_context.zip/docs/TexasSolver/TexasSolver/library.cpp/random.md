`random`: The function of `random` is to generate a random integer within a specified range.

**Code Description**: This function takes two integer parameters, `min` and `max`, and returns a random integer between `min` (inclusive) and `max` (exclusive). It uses the C++ `rand()` function to generate a random number, then applies modulo arithmetic to constrain the result within the desired range. The function adds `min` to ensure the lower bound is included, while the upper bound is excluded due to the use of modulo. This approach provides a simple way to obtain random integers within a custom range.\\
## Code: 
```
int random(int min, int max) //range : [min, max)
{
    return min + rand() % (( max ) - min);
}
```