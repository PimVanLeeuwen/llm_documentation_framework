`isAllZeros`: The function of `isAllZeros` is to check if all elements in a vector of floats are zero.

**Code Description**: This function takes a vector of float values as input and iterates through each element. It returns false immediately if any non-zero element is found. If the loop completes without finding any non-zero elements, the function returns true, indicating that all elements in the vector are zero. The function uses a range-based for loop for efficient iteration over the vector elements.\\
## Code: 
```
bool DiscountedCfrTrainable::isAllZeros(const vector<float>& input_array) {
    for(float i:input_array){
        if (i != 0)return false;
    }
    return true;
}
```