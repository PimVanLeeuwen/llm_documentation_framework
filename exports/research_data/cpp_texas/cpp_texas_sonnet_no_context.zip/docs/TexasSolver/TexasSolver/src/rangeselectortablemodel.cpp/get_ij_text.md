`get_ij_text`: The function of `get_ij_text` is to generate a formatted string based on the input row and column indices.

**Code Description**: This method takes two integer parameters, `i` and `j`, representing row and column indices. It determines the larger and smaller of these values, then uses them to access elements from a `ranklist` array. The function constructs a string using these elements and appends a suffix based on the relationship between `i` and `j`. If `i` is greater than `j`, it adds "o"; if `i` is less than `j`, it adds "s"; and if they're equal, it adds an empty string. The resulting formatted string is then returned.\\
## Code: 
```
QString RangeSelectorTableModel::get_ij_text(int i,int j){
    int row = i;
    int col = j;
    int larger = row > col?row:col;
    int smaller = row > col?col:row;
    QString  retval = QString("%1%2%3")\
            .arg(QString(this->ranklist[smaller]))\
            .arg(QString(this->ranklist[larger]));
    if(row > col){
        retval = retval.arg("o");
    }else if(row < col){
        retval = retval.arg("s");
    }else{
        retval = retval.arg("");
    }
    return retval;
}
```