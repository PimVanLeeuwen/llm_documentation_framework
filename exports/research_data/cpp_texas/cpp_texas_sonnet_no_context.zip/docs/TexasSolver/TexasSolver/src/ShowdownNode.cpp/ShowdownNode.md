`ShowdownNode`: The function of `ShowdownNode` is to initialize a showdown node in a game tree, representing the final stage of a poker game where players reveal their hands.

**Code Description**: This is a constructor for the `ShowdownNode` class, which is derived from `GameTreeNode`. It takes several parameters:
1. `tie_payoffs`: A vector of doubles representing payoffs in case of a tie.
2. `player_payoffs`: A 2D vector of doubles representing payoffs for each player in different scenarios.
3. `round`: An enum value indicating the current game round.
4. `pot`: A double representing the current pot size.
5. `parent`: A shared pointer to the parent `GameTreeNode`.

The constructor initializes the base class `GameTreeNode` with the `round`, `pot`, and `parent` parameters. It then moves the `tie_payoffs` and `player_payoffs` vectors into the class member variables, allowing for efficient transfer of ownership. This node likely represents the final state of a poker game, where payoffs are determined based on the outcome of the showdown.\\
## Code: 
```
ShowdownNode::ShowdownNode(vector<double> tie_payoffs, vector<vector<double>> player_payoffs,
                           GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode>parent):
                           GameTreeNode(round,pot,std::move(parent)) {
    this->tie_payoffs = std::move(tie_payoffs);
    this->player_payoffs = std::move(player_payoffs);
}
```