`GameActions`: The function of `GameActions` is to construct a game action object with a specified action type and amount.

**Code Description**: This is a constructor for the `GameActions` class that takes two parameters: an `action` of type `GameTreeNode::PokerActions` and an `amount` of type `double`. The constructor initializes the object's `action` member with the provided action type. It then performs validation on the `amount` parameter based on the action type:

1. For RAISE or BET actions:
   - The amount must not be -1, or it throws a runtime error.
2. For other actions (presumably CHECK, FOLD, or CALL):
   - The amount must be -1, or it throws a runtime error.

If the validation passes, the constructor sets the object's `amount` member to the provided value. This ensures that raise and bet actions always have a valid amount specified, while other actions do not have an associated amount.\\
## Code: 
```
GameActions::GameActions(GameTreeNode::PokerActions action, double amount) {
    this->action = action;
    if (action == GameTreeNode::PokerActions::RAISE || action == GameTreeNode::PokerActions::BET ) {
        if (amount == -1) throw runtime_error(tfm::format("raise/bet amount should not be -1, find %s",amount));
    } else {
        if (amount != -1) throw runtime_error(tfm::format("check/fold/call amount should be -1, find %s",amount));
    }
    this->amount = amount;
}
```