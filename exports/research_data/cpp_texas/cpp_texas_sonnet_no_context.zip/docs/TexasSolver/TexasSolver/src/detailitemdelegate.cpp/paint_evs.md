`paint_evs`: The function of `paint_evs` is to paint expected value (EV) information for poker hands in a custom Qt item delegate.

**Code Description**: This method is part of a `DetailItemDelegate` class and is responsible for rendering complex poker strategy information in a Qt view. It paints a visual representation of expected values (EVs) and strategies for different poker actions based on the current game state and player's hand.

The function first retrieves the model data and checks if it's dealing with an action node in a game tree. It then processes strategy and EV data for the current hand (represented by two cards) and available actions.

The painting process involves several steps:
1. Calculating the proportions of the item rectangle to represent different aspects of the strategy (folding probability, actions not in range, and other actions).
2. Drawing colored rectangles to visually represent different actions and their probabilities. The colors are determined based on the action type (fold, check/call, bet/raise) and the normalized expected value.
3. Rendering text information including the hand cards and EVs for each possible action.

The color scheme used is:
- Blue for fold actions
- Shades of green and blue for check/call actions, with the intensity based on the EV
- Shades of red and blue for bet/raise actions, with the intensity based on the EV and the number of bet/raise actions

The function also handles error cases, such as mismatched sizes of action and EV vectors. The final output is a rich text document containing the hand cards and EV information for each action, which is then drawn onto the painter.\\
## Code: 
```
void DetailItemDelegate::paint_evs(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);

    const DetailViewerModel * detailViewerModel = qobject_cast<const DetailViewerModel*>(index.model());

    options.text = "";
    if(detailViewerModel->tableStrategyModel->treeItem != NULL &&
            detailViewerModel->tableStrategyModel->treeItem->m_treedata.lock()->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<GameTreeNode> node = detailViewerModel->tableStrategyModel->treeItem->m_treedata.lock();
        int strategy_number = 0;
        if(this->detailWindowSetting->grid_i >= 0 && this->detailWindowSetting->grid_j >= 0){
           strategy_number = detailViewerModel->tableStrategyModel->ui_strategy_table[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j].size();
        }
        int ind = index.row() * detailViewerModel->columns + index.column();

        if(ind < strategy_number){

            pair<int,int> strategy_ui_table = detailViewerModel->tableStrategyModel->ui_strategy_table[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j][ind];
            int card1 = strategy_ui_table.first;
            int card2 = strategy_ui_table.second;
            shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);
            vector<GameActions>& gameActions = actionNode->getActions();
            vector<float> evs = detailViewerModel->tableStrategyModel->current_evs.empty()? vector<float>(gameActions.size(),-1.0):detailViewerModel->tableStrategyModel->current_evs[card1][card2] ;
            if(gameActions.size() != evs.size())throw runtime_error("evs size mismatch in DetailItemItemDelegate paint");

            vector<float> strategy = detailViewerModel->tableStrategyModel->current_strategy[card1][card2];
            if(gameActions.size() != strategy.size())throw runtime_error("strategy size mismatch in DetailItemItemDelegate paint");

            float fold_prob = 0;
            vector<float> strategy_without_fold;
            float strategy_without_fold_sum = 0;
            for(std::size_t i = 0;i < strategy.size();i ++){
                GameActions one_action = gameActions[i];
                if(one_action.getAction() == GameTreeNode::PokerActions::FOLD){
                    fold_prob = strategy[i];
                }else{
                    strategy_without_fold.push_back(strategy[i]);
                    strategy_without_fold_sum += strategy[i];
                }
            }

            for(std::size_t i = 0;i < strategy_without_fold.size();i ++){
                strategy_without_fold[i] = strategy_without_fold[i] / strategy_without_fold_sum;
            }

            // get range data - copied initally from paint_range - probably could need cleanup
            float range_number;
            if(0 == detailViewerModel->tableStrategyModel->current_player){
                range_number = detailViewerModel->tableStrategyModel->p1_range[card1][card2];
            }else{
                range_number = detailViewerModel->tableStrategyModel->p2_range[card1][card2];
            }

            if(range_number < 0 || range_number > 1) throw runtime_error("range number incorrect in strategyitemdeletage");
            // got range data

            float not_in_range = 1 - range_number;
            int niR_height = (int)(not_in_range * option.rect.height() * 0.975);

            int disable_height = (int)(0.5 + fold_prob * (option.rect.height()-niR_height));
            int remain_height = option.rect.height() - niR_height - disable_height;

            // draw background for flod
        if (disable_height > 0) {
            QRect rect(option.rect.left(), option.rect.top() + niR_height,\
                 option.rect.width(), disable_height);
            QBrush brush(QColor	(0,191,255));
            painter->fillRect(rect, brush);
        }
        if (remain_height > 0){
            int ind = 0;
            float last_prob = 0;
            int bet_raise_num = 0;
            for(std::size_t i = 0;i < strategy.size();i ++){
                GameActions one_action = gameActions[i];
                float normalized_ev = normalization_tanh(node->getPot() * 3,evs[i]);
                QBrush brush(Qt::gray);
                if(one_action.getAction() != GameTreeNode::PokerActions::FOLD){
                    if(one_action.getAction() == GameTreeNode::PokerActions::CHECK
                    || one_action.getAction() == GameTreeNode::PokerActions::CALL){
                        int green = 255;
                        int blue = max((int)(225 - normalized_ev * 175),55);
                        int red = 55;
                        brush = QBrush(QColor(red,green,blue));
                }
                else if(one_action.getAction() == GameTreeNode::PokerActions::BET
                || one_action.getAction() == GameTreeNode::PokerActions::RAISE){
                     int color_base = max(128 - 32 * bet_raise_num - 1,0);
                     int blue = max((int)(255 - normalized_ev * (255 - color_base)), color_base);
                     int red = color_base + min((int)(normalized_ev * (255-color_base)),255-color_base);;
                     int green = color_base;
                     brush = QBrush(QColor(red,green,blue));

                    bet_raise_num += 1;
                }else{
                brush = QBrush(Qt::blue);
                }

                int delta_x = (int)(option.rect.width() * last_prob);
                int delta_width = (int)(option.rect.width() * (last_prob + strategy_without_fold[ind])) - (int)(option.rect.width() * last_prob);

                QRect rect(option.rect.left() + delta_x, option.rect.top() + niR_height + disable_height,\
                 delta_width , remain_height);
                painter->fillRect(rect, brush);
            }

                last_prob += strategy_without_fold[ind];
                ind += 1;
                }
            }

            options.text = "";
            options.text += detailViewerModel->tableStrategyModel->cardint2card[card1].toFormattedHtml();
            options.text += detailViewerModel->tableStrategyModel->cardint2card[card2].toFormattedHtml();
            options.text = "<h2>" + options.text + "<\/h2>";
            for(std::size_t i = 0;i < evs.size();i ++){
                GameActions one_action = gameActions[i];
                QString one_ev = evs[i] != evs[i]? tr("Can't calculate"):QString::number(evs[i],'f',1);
                QString ev_str = tr("EV");
                if(one_action.getAction() ==  GameTreeNode::PokerActions::FOLD){
                    options.text +=  QString(" <h5> %1 %2: %3<\/h5>").arg(tr("FOLD"),ev_str,one_ev);
                }
                else if(one_action.getAction() ==  GameTreeNode::PokerActions::CALL){
                    options.text +=  QString(" <h5> %1 %2: %3<\/h5>").arg(tr("CALL"),ev_str,one_ev);
                }
                else if(one_action.getAction() ==  GameTreeNode::PokerActions::CHECK){
                    options.text +=  QString(" <h5> %1 %2: %3<\/h5>").arg(tr("CHECK"),ev_str,one_ev);
                }
                else if(one_action.getAction() ==  GameTreeNode::PokerActions::BET){
                    options.text +=  QString(" <h5> %1 %2 %3: %4<\/h5>").arg(tr("BET"),QString::number(one_action.getAmount()),ev_str,one_ev);
                }
                else if(one_action.getAction() ==  GameTreeNode::PokerActions::RAISE){
                    options.text +=  QString(" <h5> %1 %2 %3: %4<\/h5>").arg(tr("RAISE"),QString::number(one_action.getAmount()),ev_str,one_ev);
                }
            }
        }
    }

    QTextDocument doc;
    doc.setHtml(options.text);

    options.text = "";
    //options.widget->style()->drawControl(QStyle::CE_ItemViewItem, &option, painter);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```