`getPlayer`: The function of `getPlayer` is to return the player value of an ActionNode object.

**Code Description**: This is a member function of the ActionNode class that returns an integer value representing the player associated with the ActionNode. The function simply returns the value of the private member variable 'player' using the 'this' pointer, which refers to the current instance of the ActionNode object.\\
## Code: 
```
int ActionNode::getPlayer() {
    return this->player;
}
```