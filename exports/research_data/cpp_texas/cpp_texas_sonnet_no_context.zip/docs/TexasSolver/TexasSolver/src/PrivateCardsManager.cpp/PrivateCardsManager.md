`PrivateCardsManager`: The function of `PrivateCardsManager` is to initialize and manage private card information for multiple players in a card game.

**Code Description**: This constructor initializes a `PrivateCardsManager` object with the following key operations:

1. It takes three parameters: a vector of private cards for each player, the number of players, and an initial board state.

2. It stores the private cards and player number as member variables.

3. It initializes a 2D vector `card_player_index` with dimensions 52*52 x player_number, initially filled with -1. This structure is likely used to map card combinations to player indices.

4. It populates `card_player_index` by iterating through each player's private card combinations. For each combination, it stores the index of that combination in the player's hand at the position determined by the combination's hash code.

5. It stores the initial board state.

6. Finally, it calls a method `setRelativeProbs()`, which is not defined in this snippet but likely sets up probability calculations based on the initialized data.

This class appears to be part of a larger system for managing and analyzing card distributions in a multi-player card game, possibly for game AI or probability calculations.\\
## Code: 
```
PrivateCardsManager::PrivateCardsManager(vector<vector<PrivateCards>> private_cards, int player_number,
                                         uint64_t initialboard) {
    this->private_cards = private_cards;
    this->player_number = player_number;
    this->card_player_index = vector<vector<int>>(52 * 52);
    for(int i = 0;i < 52 * 52;i ++){
        this->card_player_index[i] = vector<int>(this->player_number,-1);
    }

    // 用一个二维数组记录每个Private Combo的对应index,方便从一方的手牌找对方的同名卡牌的index
    for(int player_id = 0;player_id < player_number;player_id ++){
        vector<PrivateCards> privateCombos = private_cards[player_id];
        for(std::size_t i = 0;i < privateCombos.size();i ++){
            PrivateCards one_private_combo = privateCombos[i];
            this->card_player_index[one_private_combo.hashCode()][player_id] = i;
        }
    }

    this->initialboard = initialboard;
    this->setRelativeProbs();
}
```