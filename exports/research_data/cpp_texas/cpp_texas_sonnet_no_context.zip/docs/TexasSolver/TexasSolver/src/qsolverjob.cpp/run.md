`run`: The function of `run` is to execute different tasks based on the current mission type.

**Code Description**: This method is part of the QSolverJob class and serves as the main execution point for various operations. It uses a series of conditional statements to determine which specific task to perform based on the value of `current_mission`. The possible tasks include solving, loading, building a tree, and saving. If the mission type is not recognized, it throws a runtime error. The method is wrapped in a try-catch block to handle any runtime errors that may occur during execution, logging the error message using qDebug(). The commented-out line at the beginning suggests there might be an option to redirect debug output to a text edit widget.\\
## Code: 
```
void QSolverJob::run()
{
    //QDebugStream qout(qDebug().noquote(), this->textEdit);
    try{
        if(this->current_mission == MissionType::SOLVING){
            this->solving();
        }else if(this->current_mission == MissionType::LOADING){
            this->loading();
        }else if(this->current_mission == MissionType::BUILDTREE){
            this->build_tree();
        }else if(this->current_mission == MissionType::SAVING){
            this->saving();
        }else{
            throw runtime_error("unsupported mission type");
        }
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```