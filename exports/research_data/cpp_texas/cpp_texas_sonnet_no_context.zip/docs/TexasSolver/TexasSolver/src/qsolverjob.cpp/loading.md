`loading`: The function of `loading` is to initialize and load necessary resources for poker game solvers.

**Code Description**: This method sets up two poker solvers: one for Texas Hold'em and another for Short Deck poker. It defines the suits and ranks for the cards, specifies resource directories, and loads comparison files for hand rankings. The method creates instances of PokerSolver for both game types, using different rank sets and comparison files. It uses debug output to log the loading process. The loading of resources is done sequentially, first for Hold'em and then for Short Deck, with each step involving the specification of ranks, file paths for comparison data, and the number of lines in the comparison files. The method concludes by indicating that the loading process is complete.\\
## Code: 
```
void QSolverJob::loading(){
    string suits = "c,d,h,s";
    string ranks;
    this->resource_dir =  ":/resources";
    string compairer_file, compairer_file_bin;
    int lines;
    qDebug().noquote() << tr("Loading holdem compairing file");//.toStdString() << endl;
    //if(mode == "holdem"){
    ranks = "2,3,4,5,6,7,8,9,T,J,Q,K,A";
    compairer_file = this->resource_dir + "/compairer/card5_dic_sorted.txt";
    compairer_file_bin = this->resource_dir + "/compairer/card5_dic_zipped.bin";
    //qDebug().noquote() << compairer_file_bin.c_str();
    lines = 2598961;
    this->ps_holdem = PokerSolver(ranks,suits,compairer_file,lines,compairer_file_bin);

    qDebug().noquote() << tr("Loading shortdeck compairing file");//.toStdString() << endl;
    //}else if(mode == "shortdeck"){
    ranks = "6,7,8,9,T,J,Q,K,A";
    compairer_file = this->resource_dir + "/compairer/card5_dic_sorted_shortdeck.txt";
    compairer_file_bin = this->resource_dir + "/compairer/card5_dic_zipped_shortdeck.bin";
    lines = 376993;
    this->ps_shortdeck = PokerSolver(ranks,suits,compairer_file,lines,compairer_file_bin);
    qDebug().noquote() << tr("Loading finished. Good to go.");//.toStdString() << endl;
}
```