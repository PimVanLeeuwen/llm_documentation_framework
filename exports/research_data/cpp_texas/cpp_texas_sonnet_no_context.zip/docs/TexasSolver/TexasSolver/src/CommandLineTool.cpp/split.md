`split`: The function of `split` is to divide a string into substrings based on a specified delimiter character.

**Code Description**: This function takes three parameters: a constant reference to a string `s` to be split, a character `c` that serves as the delimiter, and a reference to a vector of strings `v` where the resulting substrings will be stored. 

The function uses two string::size_type variables, `i` and `j`, to keep track of positions within the string. It initializes `i` to 0 and `j` to the position of the first occurrence of the delimiter character.

In a while loop, the function continues as long as the delimiter is found (j != string::npos). For each iteration:
1. It extracts the substring from position `i` to `j` (excluding the delimiter) and adds it to the vector `v`.
2. It updates `i` to the position just after the found delimiter.
3. It searches for the next occurrence of the delimiter starting from the new position of `j`.

If no more delimiters are found (j == string::npos), the loop ends. The function then adds the remaining part of the string (from `i` to the end) to the vector, ensuring that the last substring is not omitted.

This implementation allows for efficient splitting of strings, handling cases where delimiters appear at the beginning, middle, or end of the string, as well as consecutive delimiters or strings without the delimiter.\\
## Code: 
```
void split(const string& s, char c,
           vector<string>& v) {
    string::size_type i = 0;
    string::size_type j = s.find(c);

    while (j != string::npos) {
        v.push_back(s.substr(i, j-i));
        i = ++j;
        j = s.find(c, j);

        if (j == string::npos)
            v.push_back(s.substr(i, s.length()));
    }
}
```