`columnCount`: The function of `columnCount` is to return the number of columns in the strategy table.

**Code Description**: This method is a member of the `RoughStrategyViewerModel` class and overrides the `columnCount` function from the base model class. It takes a `QModelIndex` parameter `parent`, which is not used in this implementation. The function returns the size of the `total_strategy` vector from the `tableStrategyModel` object, which represents the number of columns in the strategy table. This allows the view to determine how many columns should be displayed when rendering the model data.\\
## Code: 
```
int RoughStrategyViewerModel::columnCount(const QModelIndex &parent) const
{
    return this->tableStrategyModel->total_strategy.size();
}
```