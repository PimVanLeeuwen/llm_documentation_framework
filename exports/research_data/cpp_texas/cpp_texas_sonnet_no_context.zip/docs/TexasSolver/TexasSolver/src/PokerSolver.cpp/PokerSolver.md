`PokerSolver`: The function of `PokerSolver` is to initialize a poker solver with a specified deck and card comparison mechanism.

**Code Description**: This constructor for the PokerSolver class takes five parameters: ranks and suits as strings, a compairer file name, the number of lines in the compairer file, and a binary compairer file name. It performs the following operations:

1. Splits the input ranks and suits strings into vectors using a helper function `string_split`.
2. Creates a Deck object using the rank and suit vectors.
3. Initializes a shared pointer to a Dic5Compairer object, which is likely used for comparing poker hands, using the provided compairer file information.

The constructor sets up the basic components needed for solving poker-related problems, including a customized deck of cards and a mechanism for comparing hands.\\
## Code: 
```
PokerSolver::PokerSolver(string ranks, string suits, string compairer_file,int compairer_file_lines, string compairer_file_bin) {
    vector<string> ranks_vector = string_split(ranks,',');
    vector<string> suits_vector = string_split(suits,',');
    this->deck = Deck(ranks_vector,suits_vector);
    this->compairer = make_shared<Dic5Compairer>(compairer_file,compairer_file_lines,compairer_file_bin);
}
```