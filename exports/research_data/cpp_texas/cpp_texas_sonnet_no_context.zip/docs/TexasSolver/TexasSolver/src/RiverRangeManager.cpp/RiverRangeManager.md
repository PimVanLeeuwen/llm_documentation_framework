`RiverRangeManager`: The function of `RiverRangeManager` is to initialize a river range manager with a hand evaluator and a mutex for thread-safe operations.

**Code Description**: This is a constructor for the `RiverRangeManager` class. It takes a shared pointer to a `Compairer` object, which is likely used for hand evaluation in poker. The constructor moves this shared pointer to its member variable `handEvaluator`. Additionally, it creates a new shared pointer to a `std::mutex` object and assigns it to the `maplock` member variable. This mutex is probably used to ensure thread-safe access to some map data structure within the `RiverRangeManager` class.\\
## Code: 
```
RiverRangeManager::RiverRangeManager(shared_ptr<Compairer> handEvaluator) {
    this->handEvaluator = std::move(handEvaluator);
    this->maplock = std::make_shared<std::mutex>();
}
```