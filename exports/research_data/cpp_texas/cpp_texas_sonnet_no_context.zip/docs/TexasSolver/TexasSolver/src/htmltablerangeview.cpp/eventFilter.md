`eventFilter`: The function of `eventFilter` is to handle mouse events on the viewport of an HtmlTableRangeView.

**Code Description**: This method overrides the default event filter to implement custom mouse event handling for a table view. It tracks mouse press, move, and release events, as well as when the mouse leaves the viewport.

When a mouse button is pressed, it records the row and column of the clicked cell and starts tracking. During mouse movement, it emits a signal with the area between the initially clicked cell and the current cell if tracking is active. On mouse release, it stops tracking and emits a release signal with the current cell's position. If the mouse leaves the viewport, tracking is stopped.

The method uses the indexAt function to convert mouse coordinates to table cell indices. It maintains state using a mouseTracker object and class variables for the last known position. Custom signals (view_item_area and item_release) are emitted to communicate the user's interactions with the table.

Finally, it calls the parent class's eventFilter to ensure proper event handling for unhandled events.\\
## Code: 
```
bool HtmlTableRangeView::eventFilter(QObject *watched, QEvent *event){
    if(viewport() == watched){
        if(event->type() == QEvent::MouseButtonPress){
            QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
            QModelIndex index = indexAt(mouseEvent->pos());
            if(index.isValid()){
                int i = index.row();
                int j = index.column();
                mouseTracker.tracking = true;
                mouseTracker.pressed_i = i;
                mouseTracker.pressed_j = j;
            }
        }
        else if(event->type() == QEvent::MouseMove){
            QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
            QModelIndex index = indexAt(mouseEvent->pos());
            if(index.isValid()){
                int i = index.row();
                int j = index.column();
                if(i != this->last_bearing_i || j != last_bearing_j){
                    this->last_bearing_i = i;
                    this->last_bearing_j = j;
                    if(mouseTracker.tracking == true){
                        emit view_item_area(mouseTracker.pressed_i,mouseTracker.pressed_j,i,j);
                    }
                }
            }
        }
        else if(event->type() == QEvent::MouseButtonRelease){
            QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
            QModelIndex index = indexAt(mouseEvent->pos());
            if(index.isValid()){
                int i = index.row();
                int j = index.column();
                mouseTracker.tracking = false;
                emit item_release(i,j);
            }
        }
        else if(event->type() == QEvent::Leave){
                mouseTracker.tracking = false;
        }else{

        }
    }
    return QTableView::eventFilter(watched, event);
}
```