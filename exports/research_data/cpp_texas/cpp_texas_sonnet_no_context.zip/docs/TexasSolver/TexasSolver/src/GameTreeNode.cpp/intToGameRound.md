`intToGameRound`: The function of `intToGameRound` is to convert an integer value to a corresponding GameRound enum value.

**Code Description**: This function takes an integer parameter `round` and returns a `GameTreeNode::GameRound` enum value. It uses a switch statement to map integer values to specific game rounds:

- 0 maps to PREFLOP
- 1 maps to FLOP
- 2 maps to TURN
- 3 maps to RIVER

If the input integer doesn't match any of these cases, the function throws a runtime_error with a formatted error message. The function is part of the GameTreeNode class or namespace, as indicated by the scope resolution operator (::) in the function signature and return type.\\
## Code: 
```
GameTreeNode::GameRound GameTreeNode::intToGameRound(int round){
    GameTreeNode::GameRound game_round;
    switch(round){
        case 0:{
            game_round = GameTreeNode::GameRound::PREFLOP;
            break;
        }
        case 1:{
            game_round = GameTreeNode::GameRound::FLOP;
            break;
        }
        case 2:{
            game_round = GameTreeNode::GameRound::TURN;
            break;
        }
        case 3:{
            game_round = GameTreeNode::GameRound::RIVER;
            break;
        }
        default:{
            throw runtime_error(tfm::format("round %s not found",round));
        }
    }
    return game_round;
}
```