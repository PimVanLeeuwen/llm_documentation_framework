`ActionNode`: The function of `ActionNode` is to create an action node in a game tree for a poker-like game.

**Code Description**: This is a constructor for the `ActionNode` class, which is derived from `GameTreeNode`. It initializes an action node with specific game-related information. The constructor takes several parameters:

1. `actions`: A vector of `GameActions` representing possible actions at this node.
2. `childrens`: A vector of shared pointers to child `GameTreeNode` objects.
3. `player`: An integer representing the current player.
4. `round`: A `GameRound` enum indicating the current round of the game.
5. `pot`: A double value representing the current pot size.
6. `parent`: A shared pointer to the parent `GameTreeNode`.

The constructor uses a member initializer list to call the base class (`GameTreeNode`) constructor with `round`, `pot`, and `parent` parameters. It then assigns the `actions`, `player`, and `childrens` parameters to the corresponding member variables using move semantics for efficiency. The commented-out cout statement suggests that debugging output was previously used to confirm the creation of an `ActionNode`.\\
## Code: 
```
ActionNode::ActionNode(vector<GameActions> actions, vector<shared_ptr<GameTreeNode>> childrens, int player,
                       GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent) :GameTreeNode(round,pot,std::move(parent)){
    this->actions = std::move(actions);
    this->player = player;
    this->childrens = std::move(childrens);
    //cout << "ActionNode created" << endl;
}
```