`compairRanks`: The function of `compairRanks` is to compare two ranks and determine their relative order.

**Code Description**: This method is part of the `Dic5Compairer` class and compares two integer ranks. It takes two parameters: `rank_former` and `rank_latter`. The comparison logic is inverse to typical numerical ordering - a smaller rank value is considered larger. The function returns a `CompairResult` enum value:

1. If `rank_former` is less than `rank_latter`, it returns `LARGER`.
2. If `rank_former` is greater than `rank_latter`, it returns `SMALLER`.
3. If the ranks are equal, it returns `EQUAL`.

The comment suggests that a rank of 0 represents a straight flush, which is typically the highest hand in poker. This inverse ranking system likely corresponds to a specific game rule where lower numbers represent stronger hands.\\
## Code: 
```
Compairer::CompairResult Dic5Compairer::compairRanks(int rank_former, int rank_latter) {
    if (rank_former < rank_latter) {
        // rank更小的牌更大，0是同花顺
        return CompairResult::LARGER;
    } else if (rank_former > rank_latter) {
        return CompairResult::SMALLER;
    } else {
        // rank_former == rank_latter
        return CompairResult::EQUAL;
    }
}
```