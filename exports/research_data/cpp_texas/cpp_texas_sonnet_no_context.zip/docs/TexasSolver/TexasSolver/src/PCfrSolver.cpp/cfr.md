`cfr`: The function of `cfr` is to calculate the counterfactual regret for a given player at a specific node in a game tree.

**Code Description**: This function implements the Counterfactual Regret Minimization (CFR) algorithm for a poker game. It takes parameters including the current player, a shared pointer to a game tree node, reach probabilities, iteration number, current board state, and deal information. The function uses a switch statement to handle different types of nodes in the game tree:

1. For ACTION nodes, it calls `actionUtility` to calculate the utility and update strategies.
2. For SHOWDOWN nodes, it calls `showdownUtility` to determine the outcome of the hand.
3. For TERMINAL nodes, it calls `terminalUtility` to calculate the final payoff.
4. For CHANCE nodes, it calls `chanceUtility` to handle probability distributions of chance events.

If an unknown node type is encountered, it throws a runtime error. The function returns a vector of float values, likely representing the expected utility or regret for each action at the current node. This recursive structure allows the CFR algorithm to traverse the entire game tree, updating strategies and calculating regrets at each decision point.\\
## Code: 
```
vector<float> PCfrSolver::cfr(int player, shared_ptr<GameTreeNode> node, const vector<float> &reach_probs, int iter,
                                    uint64_t current_board,int deal) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
            return actionUtility(player, action_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::SHOWDOWN: {
            shared_ptr<ShowdownNode> showdown_node = std::dynamic_pointer_cast<ShowdownNode>(node);
            return showdownUtility(player, showdown_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::TERMINAL: {
            shared_ptr<TerminalNode> terminal_node = std::dynamic_pointer_cast<TerminalNode>(node);
            return terminalUtility(player, terminal_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::CHANCE: {
            shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
            return chanceUtility(player, chance_node, reach_probs, iter, current_board,deal);
        }default:
            throw runtime_error("node type unknown");
    }
}
```