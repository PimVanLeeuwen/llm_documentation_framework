`getAmount`: The function of `getAmount` is to return the value of the `amount` member variable.

**Code Description**: This is a member function of the `GameActions` class that retrieves the current value stored in the `amount` variable. It's a simple getter method that doesn't modify any data but provides read access to the private `amount` member. The function returns a `double` value, indicating that `amount` is likely a floating-point number used to represent some quantity in the game, such as a score, currency, or measurement.\\
## Code: 
```
double GameActions::getAmount() {
    return this->amount;
}
```