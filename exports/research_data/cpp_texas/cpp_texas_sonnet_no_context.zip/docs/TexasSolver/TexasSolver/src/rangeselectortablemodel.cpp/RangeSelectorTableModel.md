`RangeSelectorTableModel`: The function of `RangeSelectorTableModel` is to initialize a table model for a range selector with customizable ranks and initial board state.

**Code Description**: This constructor initializes a `RangeSelectorTableModel` object, which is derived from `QAbstractItemModel`. It takes four parameters: a list of ranks, an initial board state, a parent object, and a boolean flag for thumbnail mode.

The constructor performs the following tasks:
1. Stores the provided ranks in `ranklist` and the thumbnail flag.
2. Creates a 2D vector `grids_string` to store string representations of each cell in the table. It populates this vector with text obtained from the `get_ij_text` function for each cell position.
3. Builds a map `string2ij` that associates each cell's text with its row and column indices.
4. Initializes a 2D vector `grids_float` with the same dimensions as `grids_string`, filled with 0.0 values. This vector likely represents numerical values associated with each cell.
5. Calls `setRangeText` with the provided `initial_board` to set up the initial state of the range selector.

The class appears to be designed for managing a grid-based range selector, where each cell can have both string and float representations. The use of ranks suggests it might be used for poker hand range selection or similar applications where ranked items are arranged in a grid format.\\
## Code: 
```
RangeSelectorTableModel::RangeSelectorTableModel(QStringList ranks,QString initial_board,QObject *parent,bool thumbnail):QAbstractItemModel(parent){
    this->ranklist = ranks;
    this->thumbnail = thumbnail;

    this->grids_string = vector<vector<QString>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_string[i] = vector<QString>(this->ranklist.size());
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_string[i][j] = this->get_ij_text(i,j);
            this->string2ij[this->get_ij_text(i,j)] = pair<int,int>(i,j);
        }
    }

    this->grids_float = vector<vector<float>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_float[i] = vector<float>(this->ranklist.size(),0.0);
    }
    this->setRangeText(initial_board);
}
```