`pokerActionToString`: The function of `pokerActionToString` is to convert a PokerActions enum value to its corresponding string representation.

**Code Description**: This function takes a `GameTreeNode::PokerActions` enum value as input and returns a string representation of that action. It uses a switch statement to match the input enum value with its corresponding string. The function handles the following poker actions: BEGIN, ROUNDBEGIN, BET, RAISE, CHECK, FOLD, and CALL. If the input doesn't match any of these cases, it throws a runtime_error with the message "PokerActions not found". This function is useful for converting internal enum representations of poker actions to human-readable strings, which can be used for logging, display purposes, or debugging.\\
## Code: 
```
string GameActions::pokerActionToString(GameTreeNode::PokerActions pokerActions) {
    switch (pokerActions)
    {
        case GameTreeNode::PokerActions::BEGIN :   return "BEGIN";
        case GameTreeNode::PokerActions::ROUNDBEGIN :   return "ROUNDBEGIN";
        case GameTreeNode::PokerActions::BET :   return "BET";
        case GameTreeNode::PokerActions::RAISE :   return "RAISE";
        case GameTreeNode::PokerActions::CHECK :   return "CHECK";
        case GameTreeNode::PokerActions::FOLD :   return "FOLD";
        case GameTreeNode::PokerActions::CALL :   return "CALL";
        default:{
            throw runtime_error("PokerActions not found");
        }
    }
}
```