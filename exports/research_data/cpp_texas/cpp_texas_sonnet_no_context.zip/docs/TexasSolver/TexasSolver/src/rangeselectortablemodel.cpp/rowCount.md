`rowCount`: The function of `rowCount` is to return the number of rows in the range selector table model.

**Code Description**: This method is a member of the `RangeSelectorTableModel` class and overrides the `rowCount` function from the base model class. It takes a `QModelIndex` parameter `parent`, which is not used in this implementation. The function returns the size of the `ranklist` member variable, which represents the number of items (rows) in the model. This is typically used by views to determine how many rows should be displayed.\\
## Code: 
```
int RangeSelectorTableModel::rowCount(const QModelIndex &parent) const {
    return this->ranklist.size();
}
```