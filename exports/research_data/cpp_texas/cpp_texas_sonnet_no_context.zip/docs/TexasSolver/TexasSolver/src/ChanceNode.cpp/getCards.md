`getCards`: The function of `getCards` is to return a constant reference to the vector of Card objects stored in the ChanceNode.

**Code Description**: This is a member function of the ChanceNode class that provides read-only access to the private 'cards' member variable. It returns a constant reference to a vector of Card objects, preventing any modifications to the original data. The 'const' qualifier before the function ensures that the method doesn't modify the object's state. This getter method allows other parts of the program to view the cards associated with the ChanceNode without being able to alter them directly.\\
## Code: 
```
const vector<Card>& ChanceNode::getCards() {
    return this->cards;
}
```