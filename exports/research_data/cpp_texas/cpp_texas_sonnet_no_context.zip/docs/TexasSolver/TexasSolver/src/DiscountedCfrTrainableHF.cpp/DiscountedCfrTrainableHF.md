`DiscountedCfrTrainableHF`: The function of `DiscountedCfrTrainableHF` is to initialize a discounted counterfactual regret minimization (CFR) trainable object for a game with hidden information.

**Code Description**: This constructor initializes a `DiscountedCfrTrainableHF` object with given private cards and an action node. It sets up data structures for storing expected values (evs), regret values (r_plus), and cumulative regret values (cum_r_plus) for each action and private card combination. The constructor takes two parameters: a pointer to a vector of `PrivateCards` and a reference to an `ActionNode`. It initializes member variables including `privateCards`, `action_number` (number of possible actions), and `card_number` (number of private card combinations). The `evs`, `r_plus`, and `cum_r_plus` vectors are initialized with sizes equal to the product of `action_number` and `card_number`, and filled with initial values of 0.0. This setup allows for efficient storage and retrieval of game-specific information during the CFR training process.\\
## Code: 
```
DiscountedCfrTrainableHF::DiscountedCfrTrainableHF(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();
    this->evs = vector<EvsStorage>(this->action_number * this->card_number, (EvsStorage) 0.0);
    this->r_plus = vector<RplusStorage>(this->action_number * this->card_number, (RplusStorage) 0.0);
    this->cum_r_plus = vector<CumRplusStorage>(this->action_number * this->card_number, (CumRplusStorage) 0.0);
}
```