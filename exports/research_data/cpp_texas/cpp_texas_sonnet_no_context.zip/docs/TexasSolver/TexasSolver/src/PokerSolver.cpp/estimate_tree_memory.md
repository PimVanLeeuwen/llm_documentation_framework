`estimate_tree_memory`: The function of `estimate_tree_memory` is to calculate the estimated memory usage of a poker game tree based on given player ranges and the board.

**Code Description**: This method is part of a PokerSolver class and estimates the memory required for a poker game tree. It first checks if a game tree exists, returning 0 and displaying a debug message if not. If the tree exists, it processes the input parameters:

1. Converts player range strings and the board string to C++ standard strings.
2. Splits the board string into individual card strings.
3. Converts each board card string to an integer representation.
4. Converts player range strings to vectors of PrivateCards objects, considering the initial board.

Finally, it calls the game tree's `estimate_tree_memory` method, passing:
- The number of remaining cards in the deck (total deck size minus the number of board cards)
- The size of player 1's range
- The size of player 2's range

This calculation likely considers the possible combinations and game states to estimate the memory required for the entire game tree structure.\\
## Code: 
```
long long PokerSolver::estimate_tree_memory(QString range1,QString range2,QString board){
    if(this->game_tree == nullptr){
        qDebug().noquote() << QObject::tr("Please buld tree first.");
        return 0;
    }
    else{
        string player1RangeStr = range1.toStdString();
        string player2RangeStr = range2.toStdString();

        vector<string> board_str_arr = string_split(board.toStdString(),',');
        vector<int> initialBoard;
        for(string one_board_str:board_str_arr){
            initialBoard.push_back(Card::strCard2int(one_board_str));
        }

        vector<PrivateCards> range1 = PrivateRangeConverter::rangeStr2Cards(player1RangeStr,initialBoard);
        vector<PrivateCards> range2 = PrivateRangeConverter::rangeStr2Cards(player2RangeStr,initialBoard);
        return this->game_tree->estimate_tree_memory(this->deck.getCards().size() - initialBoard.size(),range1.size(),range2.size());
    }
}
```