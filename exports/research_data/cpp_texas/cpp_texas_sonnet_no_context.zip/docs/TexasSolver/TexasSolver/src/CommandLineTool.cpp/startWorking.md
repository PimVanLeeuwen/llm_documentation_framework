`startWorking`: The function of `startWorking` is to continuously read and process user input from the command line.

**Code Description**: This method implements a loop that reads input lines from the standard input (cin) using the getline function. For each line of input, it calls the processCommand method, passing the input line as an argument. The loop continues until there is no more input available (i.e., when cin becomes false, typically when the end-of-file is reached or an error occurs). This structure allows the CommandLineTool to repeatedly accept and handle user commands until the program is terminated or the input stream ends.\\
## Code: 
```
void CommandLineTool::startWorking() {
    string input_line;
    while(cin) {
        getline(cin, input_line);
        this->processCommand(input_line);
    };
}
```