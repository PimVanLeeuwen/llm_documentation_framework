`getChildrens`: The function of `getChildrens` is to return a reference to the vector of child nodes.

**Code Description**: This method is a member function of the `ActionNode` class. It returns a reference to the `childrens` member variable, which is a vector of shared pointers to `GameTreeNode` objects. The function does not modify the vector; it simply provides access to it. By returning a reference, it allows the caller to directly manipulate or read the contents of the `childrens` vector without creating a copy.\\
## Code: 
```
vector<shared_ptr<GameTreeNode>>& ActionNode::getChildrens() {
    return this->childrens;
}
```