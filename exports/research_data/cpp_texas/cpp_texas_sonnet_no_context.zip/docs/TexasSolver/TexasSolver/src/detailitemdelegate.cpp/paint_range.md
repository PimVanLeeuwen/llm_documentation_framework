`paint_range`: The function of `paint_range` is to paint a range of cards with their probabilities in a custom view item.

**Code Description**: This method is part of a `DetailItemDelegate` class and is responsible for painting custom items in a view. It takes a painter, style options, and a model index as parameters. The function retrieves range data from a `DetailViewerModel` and paints each card in the range with its corresponding probability.

The painting process involves:
1. Initializing style options and retrieving the model.
2. Fetching card coordinates based on the current mode (IP or OOP).
3. Calculating the range number (probability) for the current card.
4. Painting a yellow background for the non-folded portion of the range.
5. Creating HTML text with card symbols and the range number.
6. Drawing the formatted text using a QTextDocument.

The function handles different modes (IP and OOP) and accesses range data from the model. It also performs error checking on the range numbers and uses HTML formatting to display card symbols. The painted item includes visual representation of the fold probability and textual information about the cards and their range number.\\
## Code: 
```
void DetailItemDelegate::paint_range(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);

    const DetailViewerModel * detailViewerModel = qobject_cast<const DetailViewerModel*>(index.model());
    //vector<pair<GameActions,float>> strategy = detailViewerModel->tableStrategyModel->get_strategy(this->detailWindowSetting->grid_i,this->detailWindowSetting->grid_j);
    options.text = "";

    if(detailViewerModel->tableStrategyModel->treeItem != NULL){
        vector<pair<int,int>> card_cords;
        if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP){
            card_cords = detailViewerModel->tableStrategyModel->ui_p1_range[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j];
        }else{
            card_cords = detailViewerModel->tableStrategyModel->ui_p2_range[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j];
        }

        int ind = index.row() * detailViewerModel->columns + index.column();
        if(ind < card_cords.size()){
            pair<int,int> cord = card_cords[ind];
            float range_number;
            if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP){
                range_number = detailViewerModel->tableStrategyModel->p1_range[cord.first][cord.second];
            }else{
                range_number = detailViewerModel->tableStrategyModel->p2_range[cord.first][cord.second];
            }

            if(range_number < 0 || range_number > 1) throw runtime_error("range number incorrect in strategyitemdeletage");

            float fold_prob = 1 - range_number;
            int disable_height = (int)(fold_prob * option.rect.height());
            int remain_height = option.rect.height() - disable_height;

            // draw background for flod
            QRect rect(option.rect.left(), option.rect.top() + disable_height,\
             option.rect.width(), remain_height);
            QBrush brush(Qt::yellow);
            painter->fillRect(rect, brush);

            options.text = "";
            options.text += detailViewerModel->tableStrategyModel->cardint2card[cord.first].toFormattedHtml();
            options.text += detailViewerModel->tableStrategyModel->cardint2card[cord.second].toFormattedHtml();
            options.text = "<h2>" + options.text + "<\/h2>";

            options.text +=  QString(" <h2>%1<\/h2>").arg(QString::number(range_number,'f',3));
        }
    }

    QTextDocument doc;
    doc.setHtml(options.text);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```