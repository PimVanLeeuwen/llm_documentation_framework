`getAverageStrategy`: The function of `getAverageStrategy` is to calculate and return the average strategy for each action and private information combination.

**Code Description**: This method computes the average strategy for a game scenario using discounted cumulative regret matching. It initializes a vector `average_strategy` with size equal to the product of `action_number` and `card_number`. The function then iterates through each private information (represented by `private_id`) and calculates the sum of cumulative regrets (`r_plus_sum`) for all actions associated with that private information. For each action, it computes the average strategy by dividing the cumulative regret for that action by the total sum. If the sum is zero, it assigns a uniform probability of 1/action_number to each action. The resulting `average_strategy` vector contains the probability distribution over actions for each private information state, representing the agent's learned strategy over time.\\
## Code: 
```
const vector<float> DiscountedCfrTrainableSF::getAverageStrategy() {
    vector<float> average_strategy;
    average_strategy = vector<float>(this->action_number * this->card_number);
    for (int private_id = 0; private_id < this->card_number; private_id++) {
        float r_plus_sum = 0;
        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            r_plus_sum += this->cum_r_plus[index];
        }

        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            if(r_plus_sum) {
                average_strategy[index] = this->cum_r_plus[index] / r_plus_sum;
            }else{
                average_strategy[index] = 1.0 / this->action_number;
            }
        }
    }
    return average_strategy;
}
```