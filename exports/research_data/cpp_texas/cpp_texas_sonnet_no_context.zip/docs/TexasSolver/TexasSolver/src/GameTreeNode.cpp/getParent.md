`getParent`: The function of `getParent` is to return a shared pointer to the parent node of the current GameTreeNode.

**Code Description**: This method is a member function of the GameTreeNode class. It returns a shared_ptr to the parent GameTreeNode. The parent is stored as a weak_ptr (this->parent), which is converted to a shared_ptr using the lock() function before being returned. This approach helps prevent circular references in tree-like structures while still allowing access to the parent node when needed.\\
## Code: 
```
shared_ptr<GameTreeNode>GameTreeNode::getParent() {
    return this->parent.lock();
}
```