`setTrunCard`: The function of `setTrunCard` is to set the turn card for the table strategy model.

**Code Description**: This method is a member function of the `TableStrategyModel` class. It takes a single parameter `turn_card` of type `Card`. The function assigns the value of `turn_card` to the member variable `this->turn_card`, effectively updating the turn card for the current instance of the `TableStrategyModel`. This method allows the model to keep track of the current turn card, which is likely an important piece of information for the game strategy being modeled.\\
## Code: 
```
void TableStrategyModel::setTrunCard(Card turn_card){
    this->turn_card = turn_card;
}
```