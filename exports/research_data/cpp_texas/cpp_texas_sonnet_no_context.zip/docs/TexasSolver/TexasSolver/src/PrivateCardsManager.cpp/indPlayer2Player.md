`indPlayer2Player`: The function of `indPlayer2Player` is to find the corresponding index of a card in one player's hand in another player's hand.

**Code Description**: This method takes three parameters: `from_player` (the source player), `to_player` (the target player), and `index` (the card index in the source player's hand). It first checks if the given index is valid for the source player's hand. If not, it throws a runtime error. Then, it uses the `card_player_index` data structure to find the corresponding index of the card in the target player's hand. This structure appears to be a hash map that stores card indices for each player. If the card is found in the target player's hand, the method returns its index; otherwise, it returns -1.\\
## Code: 
```
int PrivateCardsManager::indPlayer2Player(int from_player, int to_player, int index) {
    if(index < 0 || index >= this->getPreflopCards(from_player).size()) throw runtime_error("index out of range");
    //PrivateCards player_combo = this->getPreflopCards(from_player)[index];
    int to_player_index = this->card_player_index[this->private_cards[from_player][index].hashCode()][to_player];
    if(to_player_index == -1){
        return -1;
    }else {
        return to_player_index;
    }
}
```