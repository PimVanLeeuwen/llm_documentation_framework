`load_game_tree`: The function of `load_game_tree` is to load a game tree from a file and store it in the PokerSolver object.

**Code Description**: This method takes a string parameter `game_tree_file`, which represents the file path of the game tree to be loaded. It creates a shared pointer to a new GameTree object, initializing it with the provided file and the deck stored in the PokerSolver instance. The newly created game tree is then assigned to the `game_tree` member of the PokerSolver object, effectively loading and storing the game tree for future use in poker solving operations.\\
## Code: 
```
void PokerSolver::load_game_tree(string game_tree_file) {
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(game_tree_file,this->deck);
    this->game_tree = game_tree;
}
```