`paint_strategy`: The function of `paint_strategy` is to render a visual representation of poker game strategies within a table cell.

**Code Description**: This method is part of a `StrategyItemDelegate` class and is responsible for painting strategy information in a custom table view. It takes a painter, style options, model index, and a boolean flag for EVs (expected values) as parameters.

The function first retrieves the strategy data and EVs from the model. It then processes this data, separating fold probabilities from other actions and normalizing the remaining strategy probabilities.

The painting process involves several steps:
1. It calculates the portion of the cell that represents the range of hands not in play.
2. It draws a background for the fold action using a light blue color.
3. For non-fold actions, it assigns different colors based on the action type:
   - Check/Call actions are represented in shades of green and blue.
   - Bet/Raise actions use varying shades of red and blue.
4. The intensity of these colors is adjusted based on the normalized expected values if the `withEVs` flag is true.

The function draws rectangles for each action, with widths proportional to their probabilities in the strategy. This creates a visual bar chart within the table cell, representing the likelihood of each action.

Finally, it renders any text content associated with the cell using a QTextDocument.

This visualization allows users to quickly interpret complex poker strategies, with color coding and proportional sizing providing intuitive representation of action probabilities and their relative expected values.\\
## Code: 
```
void StrategyItemDelegate::paint_strategy(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index, bool withEVs) const {
    auto options = option;
    initStyleOption(&options, index);
    const TableStrategyModel * tableStrategyModel = qobject_cast<const TableStrategyModel*>(index.model());
    if(tableStrategyModel->treeItem != NULL &&
            tableStrategyModel->treeItem->m_treedata.lock()->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<GameTreeNode> node = tableStrategyModel->treeItem->m_treedata.lock();
        vector<pair<GameActions,float>> strategy = tableStrategyModel->get_strategy(index.row(),index.column());
        vector<float> evs = tableStrategyModel->get_strategies_evs(index.row(),index.column());
        if(!strategy.empty()){
            float fold_prob = 0;
            vector<float> strategy_without_fold;
            vector<float> evs_without_fold;
            float strategy_without_fold_sum = 0;
            for(std::size_t i = 0;i < strategy.size();i ++){
                GameActions one_action = strategy[i].first;
                if(one_action.getAction() == GameTreeNode::PokerActions::FOLD){
                    fold_prob = strategy[i].second;
                }else{
                    strategy_without_fold.push_back(strategy[i].second);
                    strategy_without_fold_sum += strategy[i].second;
                    evs_without_fold.push_back(evs[i]);
                }
            }
            if(strategy_without_fold_sum > 0.){
                for(std::size_t i = 0;i < strategy_without_fold.size();i ++){
                    strategy_without_fold[i] = strategy_without_fold[i] / strategy_without_fold_sum;
                }
            }

            // get range data
            vector<pair<int,int>> card_cords;
            card_cords = tableStrategyModel->ui_strategy_table[index.row()][index.column()];
            float range_number = 0;
            if(!card_cords.empty()){
                for(auto one_cord:card_cords){
                    if(0 == tableStrategyModel->current_player){
                        range_number += tableStrategyModel->p1_range[one_cord.first][one_cord.second];
                    }else{
                        // when it's oop, which is p1
                        range_number += tableStrategyModel->p2_range[one_cord.first][one_cord.second];
                    }
                }
                range_number = range_number / card_cords.size();
                if(range_number < 0 || range_number > 1) throw runtime_error("range number incorrect in strategyitemdeletage");
            }
            float not_in_range = (this->detailWindowSetting->grid_i == index.row()) &&
                                   (this->detailWindowSetting->grid_j == index.column())
                                    ? 0 : 1 - range_number;
            int niR_height = (int)(not_in_range * option.rect.height() * 0.95);
            // got range data

            int disable_height = (int)(0.5+fold_prob * (option.rect.height() - niR_height));
            int remain_height = option.rect.height() - niR_height - disable_height;

            // draw background for flod
        if (disable_height > 0) {
            QRect rect(option.rect.left(), option.rect.top() + niR_height,\
             option.rect.width(), disable_height);
            QBrush brush(QColor	(0,191,255));
            painter->fillRect(rect, brush);
        }

        if (remain_height > 0){
            int ind = 0;
            float last_prob = 0;
            int bet_raise_num = 0;
            for(std::size_t i = 0;i < strategy.size();i ++){
                GameActions one_action = strategy[i].first;
                float normalized_ev = withEVs ? normalization_tanh(node->getPot() * 3, evs_without_fold[i]) : 1.;
                QBrush brush(Qt::gray);
                if(one_action.getAction() != GameTreeNode::PokerActions::FOLD){
                    if(one_action.getAction() == GameTreeNode::PokerActions::CHECK
                            || one_action.getAction() == GameTreeNode::PokerActions::CALL){
                        int green = 255;
                        int blue = max((int)(225 - normalized_ev * 175),55);
                        int red = 55;
                        brush = QBrush(QColor(red,green,blue));
                    }
                    else if(one_action.getAction() == GameTreeNode::PokerActions::BET
                            || one_action.getAction() == GameTreeNode::PokerActions::RAISE){
                        int color_base = max(128 - 32 * bet_raise_num - 1,0);
                        int blue = max((int)(255 - normalized_ev * (255 - color_base)), color_base);
                        int red = color_base + min((int)(normalized_ev * (255-color_base)),255-color_base);;
                        int green = color_base;
                        brush = QBrush(QColor(red,green,blue));

                        bet_raise_num += 1;
                    }else{
                        brush = QBrush(Qt::blue);
                    }

                    int delta_x = (int)(option.rect.width() * last_prob);
                    int delta_width = (int)(option.rect.width() * (last_prob + strategy_without_fold[ind])) - (int)(option.rect.width() * last_prob);

                    QRect rect(option.rect.left() + delta_x, option.rect.top() + niR_height + disable_height,\
                         delta_width , remain_height);
                    painter->fillRect(rect, brush);

                    last_prob += strategy_without_fold[ind];
                    ind += 1;
                }
            }
        }
        }
    }
    QTextDocument doc;
    doc.setHtml(options.text);

    options.text = "";
    //options.widget->style()->drawControl(QStyle::CE_ItemViewItem, &option, painter);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```