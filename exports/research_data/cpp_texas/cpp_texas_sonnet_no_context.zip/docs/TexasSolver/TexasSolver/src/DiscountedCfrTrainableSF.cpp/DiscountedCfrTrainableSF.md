`DiscountedCfrTrainableSF`: The function of `DiscountedCfrTrainableSF` is to initialize a discounted counterfactual regret minimization (CFR) trainable object for a specific action node in a game tree.

**Code Description**: This constructor initializes a `DiscountedCfrTrainableSF` object with given private cards and an action node. It sets up data structures for storing expected values (evs), regret values (r_plus), and cumulative regret values (cum_r_plus) for each action and private card combination. The constructor takes two parameters: a pointer to a vector of `PrivateCards` and a reference to an `ActionNode`. It initializes member variables including `privateCards`, `action_number` (number of possible actions), and `card_number` (number of private card combinations). The constructor then creates vectors to store evs, r_plus, and cum_r_plus, each with a size equal to the product of `action_number` and `card_number`, initialized with zero values. This setup allows for efficient storage and retrieval of CFR-related data during the training process.\\
## Code: 
```
DiscountedCfrTrainableSF::DiscountedCfrTrainableSF(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();
    this->evs = vector<EvsStorage>(this->action_number * this->card_number, (EvsStorage) 0.0);
    this->r_plus = vector<RplusStorage>(this->action_number * this->card_number, (RplusStorage) 0.0);
    this->cum_r_plus = vector<CumRplusStorage>(this->action_number * this->card_number, (CumRplusStorage) 0.0);
}
```