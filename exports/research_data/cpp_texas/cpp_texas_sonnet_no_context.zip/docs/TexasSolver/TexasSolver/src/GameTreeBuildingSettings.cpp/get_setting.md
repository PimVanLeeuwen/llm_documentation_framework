`get_setting`: The function of `get_setting` is to retrieve the appropriate StreetSetting based on the given player position and game round.

**Code Description**: This method is part of the GameTreeBuildingSettings class and takes two string parameters: 'player' and 'round'. It uses a series of if-else statements to determine which StreetSetting object to return based on these inputs. The function handles six different combinations:

1. In-position (ip) player on the flop
2. In-position (ip) player on the turn
3. In-position (ip) player on the river
4. Out-of-position (oop) player on the flop
5. Out-of-position (oop) player on the turn
6. Out-of-position (oop) player on the river

If the input doesn't match any of these combinations, the function throws a runtime_error with the message "get_setting not valid". The method returns a reference to a StreetSetting object, which likely contains specific settings or strategies for the given player position and game round.\\
## Code: 
```
StreetSetting& GameTreeBuildingSettings::get_setting(string player,string round){
    if(player == "ip" && round == "flop") return flop_ip;
    else if(player == "ip" && round == "turn") return turn_ip;
    else if(player == "ip" && round == "river") return river_ip;
    else if(player == "oop" && round == "flop") return flop_oop;
    else if(player == "oop" && round == "turn") return turn_oop;
    else if(player == "oop" && round == "river") return river_oop;
    else throw runtime_error("get_setting not valid");
}
```