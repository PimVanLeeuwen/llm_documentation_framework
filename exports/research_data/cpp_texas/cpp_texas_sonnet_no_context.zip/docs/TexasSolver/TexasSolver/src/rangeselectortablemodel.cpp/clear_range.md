`clear_range`: The function of `clear_range` is to reset all elements in the `grids_float` 2D array to zero.

**Code Description**: This method iterates through each element of the `grids_float` 2D array using nested loops. The outer loop runs from 0 to the size of `ranklist`, and the inner loop does the same. For each iteration, it sets the corresponding element in `grids_float` to 0. This effectively clears or resets all values in the array to zero, regardless of their previous values.\\
## Code: 
```
void RangeSelectorTableModel::clear_range(){
    for(int i = 0;i < this->ranklist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_float[i][j] = 0;
        }
    }
}
```