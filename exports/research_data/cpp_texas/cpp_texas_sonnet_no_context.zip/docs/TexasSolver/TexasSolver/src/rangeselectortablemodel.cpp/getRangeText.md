`getRangeText`: The function of `getRangeText` is to generate a formatted string representation of non-zero range values from a 2D grid.

**Code Description**: This method iterates through a 2D grid stored in `grids_float` and `grids_string`. For each non-zero value in `grids_float`, it creates a string in the format "string:float" using the corresponding entries from `grids_string` and `grids_float`. These individual range strings are then concatenated into a single comma-separated string. The method uses nested loops to traverse the grid, skips zero values, and builds the return string incrementally. The float values are formatted to three decimal places. If the result string is empty, it returns an empty string; otherwise, it returns the concatenated range text.\\
## Code: 
```
QString RangeSelectorTableModel::getRangeText(){
    QString retval = "";
    for(int i = 0;i < this->ranklist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            if(this->grids_float[i][j] == 0)continue;
            QString one_range_str = QString("%1:%2").arg(this->grids_string[i][j],QString::number(this->grids_float[i][j],'f',3));
            if(retval == ""){
                retval = one_range_str;
            }else{
                retval = retval + "," + one_range_str;
            }
        }
    }
    return retval;
}
```