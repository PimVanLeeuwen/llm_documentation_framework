`get_game_action_str`: The function of `get_game_action_str` is to convert a poker action and amount into a human-readable string representation.

**Code Description**: This method takes two parameters: a `GameTreeNode::PokerActions` enum representing the poker action and a float value for the bet or raise amount. It uses a series of if-else statements to check the action type and returns an appropriate QString. For CHECK, FOLD, and CALL actions, it returns a simple translated string. For BET and RAISE actions, it appends the amount to the action string. If an unknown action is provided, it throws a runtime_error. The method uses QObject::tr() for string translation, suggesting it's part of a Qt application with internationalization support.\\
## Code: 
```
QString TreeItem::get_game_action_str(GameTreeNode::PokerActions action,float amount) const{
    if(action == GameTreeNode::PokerActions::CHECK){
        return QObject::tr("CHECK");
    }
    else if(action == GameTreeNode::PokerActions::BET){
        return QObject::tr("BET ") + QString::number(amount);
    }
    else if(action == GameTreeNode::PokerActions::RAISE){
        return QObject::tr("RAISE ") + QString::number(amount);
    }
    else if(action == GameTreeNode::PokerActions::FOLD){
        return QObject::tr("FOLD ");
    }
    else if(action == GameTreeNode::PokerActions::CALL){
        return QObject::tr("CALL");
    }else{
        throw runtime_error("unknown action when converting in get_game_action_str");
    }

}
```