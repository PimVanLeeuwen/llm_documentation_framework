`columnCount`: The function of `columnCount` is to return the number of columns in the table model.

**Code Description**: This method is part of the `TableStrategyModel` class and implements the `columnCount` function, which is typically required for Qt's model/view framework. It takes a `QModelIndex` parameter `parent`, although it's not used in this implementation. The function returns the size of the ranks vector obtained from the solver's deck. It does this by accessing the solver job (`qSolverJob`), getting the solver from it, then accessing the deck, and finally calling `getRanks().size()` on the deck. This suggests that the number of columns in the table corresponds to the number of ranks in the deck used by the solver.\\
## Code: 
```
int TableStrategyModel::columnCount(const QModelIndex &parent) const
{
    return this->qSolverJob->get_solver()->get_deck()->getRanks().size();
}
```