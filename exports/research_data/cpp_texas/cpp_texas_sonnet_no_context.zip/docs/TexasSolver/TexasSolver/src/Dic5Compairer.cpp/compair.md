`compair`: The function of `compair` is to compare two poker hands and determine which one is stronger.

**Code Description**: This method takes three vectors of integers as input: `private_former` and `private_latter` representing two private hands (2 cards each), and `public_board` representing the community cards (5 cards). It first checks if the input vectors have the correct sizes, throwing runtime errors if they don't. Then, it combines each private hand with the public board to create two 7-card hands. It calls the `getRank` method (not shown) to evaluate each hand, likely assigning a numerical rank based on poker hand strength. Finally, it calls the `compairRanks` method (not shown) to compare these ranks and return a `CompairResult`, which likely indicates which hand is stronger or if they're equal.\\
## Code: 
```
Compairer::CompairResult
Dic5Compairer::compair(vector<int> private_former, vector<int> private_latter, vector<int> public_board) {
    if(private_former.size() != 2)
        throw runtime_error(
                tfm::format("private former size incorrect,excepted 2, actually %s",private_former.size())
        );
    if(private_latter.size() != 2)
        throw runtime_error(
                tfm::format("private latter size incorrect,excepted 2, actually %s",private_latter.size())
        );
    if(public_board.size() != 5)
        throw runtime_error(
                tfm::format("public board size incorrect,excepted 2, actually %s",public_board.size())
        );

    vector<int> former_cards(private_former);
    former_cards.insert(former_cards.end(),public_board.begin(),public_board.end());
    int rank_former = this->getRank(former_cards);

    vector<int> latter_cards(private_latter);
    latter_cards.insert(latter_cards.end(),public_board.begin(),public_board.end());
    int rank_latter = this->getRank(latter_cards);

    return this->compairRanks(rank_former,rank_latter);
}
```