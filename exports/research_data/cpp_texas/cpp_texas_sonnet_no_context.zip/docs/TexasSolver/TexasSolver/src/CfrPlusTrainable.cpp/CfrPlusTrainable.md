`CfrPlusTrainable`: The function of `CfrPlusTrainable` is to initialize a CFR+ (Counterfactual Regret Minimization Plus) trainable object for game theory calculations.

**Code Description**: This constructor initializes a `CfrPlusTrainable` object with given parameters. It sets up the necessary data structures for CFR+ algorithm implementation. The constructor takes two parameters: a shared pointer to an `ActionNode` and a vector of `PrivateCards`. It initializes member variables including the action node, private cards, action number, and card number. It then creates vectors for storing regret values (r_plus), cumulative regret values (cum_r_plus), sums of these values (r_plus_sum and cum_r_plus_sum), and a return value vector (retval). These vectors are sized based on the number of actions and private cards, allowing for efficient storage and manipulation of CFR+ algorithm data during training and strategy computation in game theory scenarios.\\
## Code: 
```
CfrPlusTrainable::CfrPlusTrainable(shared_ptr<ActionNode> action_node, vector<PrivateCards> privateCards) {
    this->action_node = action_node;
    this->privateCards = privateCards;
    this->action_number = action_node->getChildrens().size();
    this->card_number = privateCards.size();

    this->r_plus = vector<float>(this->action_number * this->card_number);
    this->r_plus_sum = vector<float>(this->card_number);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number);
    this->cum_r_plus_sum = vector<float>(this->card_number);
    this->retval = vector<float>(this->action_number * this->card_number);
}
```