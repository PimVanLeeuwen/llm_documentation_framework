`TerminalNode`: The function of `TerminalNode` is to create a terminal node in a game tree, representing the end state of a game with payoffs and a winner.

**Code Description**: This is a constructor for the `TerminalNode` class, which is derived from the `GameTreeNode` class. It initializes a terminal node with specific game-ending information. The constructor takes several parameters:

1. `payoffs`: A vector of doubles representing the payoffs for each player at the end of the game.
2. `winner`: An integer indicating the index of the winning player.
3. `round`: A `GameRound` enum value representing the game round when the game ended.
4. `pot`: A double value representing the total pot at the end of the game.
5. `parent`: A shared pointer to the parent `GameTreeNode`.

The constructor first calls the base class constructor `GameTreeNode(round, pot, parent)` to initialize the common attributes. Then, it sets the `payoffs` member variable to the provided payoffs vector and the `winner` member variable to the given winner index. This structure allows the terminal node to store and provide access to the final game state information, which is crucial for game tree analysis and decision-making algorithms.\\
## Code: 
```
TerminalNode::TerminalNode(vector<double> payoffs, int winner, GameTreeNode::GameRound round, double pot,
                           shared_ptr<GameTreeNode> parent):GameTreeNode(round,pot,parent){
    this->payoffs = payoffs;
    this->winner = winner;
}
```