`getTree`: The function of `getTree` is to return the game tree stored in the Solver object.

**Code Description**: This method is a simple getter function that returns a shared pointer to a GameTree object. The shared pointer is stored as a member variable named `tree` within the Solver class. By returning a shared pointer, the function allows multiple parts of the program to safely access and manage the lifetime of the GameTree object without the risk of premature deletion or memory leaks.\\
## Code: 
```
shared_ptr<GameTree> Solver::getTree() {
    return this->tree;
}
```