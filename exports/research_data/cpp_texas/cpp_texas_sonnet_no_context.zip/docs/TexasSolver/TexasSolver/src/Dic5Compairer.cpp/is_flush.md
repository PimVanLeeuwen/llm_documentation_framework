`is_flush`: The function of `is_flush` is to determine if a hand of cards represents a flush.

**Code Description**: This function takes a 64-bit unsigned integer `hash` as input, which represents a hand of cards. It uses bitwise operations to check if all the cards in the hand belong to the same suit. The function employs four predefined bitmasks (SUIT_0_MASK, SUIT_1_MASK, SUIT_2_MASK, SUIT_3_MASK) to isolate the bits corresponding to each suit. It counts the number of suits present in the hand by performing bitwise AND operations with these masks. If more than one suit is present, the function returns false, indicating that the hand is not a flush. If only one suit is present, it returns true, confirming that the hand is a flush. The function is optimized for early termination, returning false as soon as it detects more than one suit, without needing to check all four suits in every case.\\
## Code: 
```
bool is_flush(uint64_t hash) {
    int cnt = (hash & SUIT_0_MASK) != 0;
    cnt += (hash & SUIT_1_MASK) != 0;
    if (cnt > 1) return false;
    cnt += (hash & SUIT_2_MASK) != 0;
    if (cnt > 1) return false;
    cnt += (hash & SUIT_3_MASK) != 0;
    return cnt > 1 ? false : true;
}
```