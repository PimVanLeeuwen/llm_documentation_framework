`get_solver`: The function of `get_solver` is to return the appropriate poker solver based on the game mode.

**Code Description**: This method is part of the `QSolverJob` class and returns a pointer to a `PokerSolver` object. It checks the `mode` member variable of the class to determine which solver to return. If the mode is `Mode::HOLDEM`, it returns a pointer to the `ps_holdem` member. If the mode is `Mode::SHORTDECK`, it returns a pointer to the `ps_shortdeck` member. If the mode is neither of these, it throws a runtime error with the message "unknown mode in get_solver". This function allows the class to manage different types of poker solvers and provide the correct one based on the current game mode.\\
## Code: 
```
PokerSolver* QSolverJob::get_solver(){
    if(this->mode == Mode::HOLDEM){
        return &this->ps_holdem;
    }else if(this->mode == Mode::SHORTDECK){
        return &this->ps_shortdeck;
    }else throw runtime_error("unknown mode in get_solver");
}
```