`toBoardLong`: The function of `toBoardLong` is to return the board_long member variable of the PrivateCards object.

**Code Description**: This method is a simple accessor function that returns the value of the `board_long` member variable. It's part of the `PrivateCards` class and doesn't perform any calculations or modifications. The commented-out line suggests there might have been an alternative implementation using a `Card::boardInts2long` function to convert a vector of cards to a long integer representation, but this is not currently in use. The function returns a `uint64_t` type, which is an unsigned 64-bit integer, likely used to represent the board state in a compact form.\\
## Code: 
```
uint64_t PrivateCards::toBoardLong() {
    return this->board_long;
    //return Card::boardInts2long(this->card_vec);
}
```