`index`: The function of `index` is to create and return a model index for a given row and column in a table model.

**Code Description**: This method is part of the `BoardSelectorTableModel` class and implements the `index` function from the Qt Model/View framework. It takes three parameters: `row`, `column`, and `parent`. First, it checks if the requested index is valid using the `hasIndex` function. If the index is not valid, it returns an invalid `QModelIndex`. If the index is valid, it creates and returns a new model index using `createIndex` with the provided row and column, and a null pointer as the internal ID. This implementation suggests a simple table structure without hierarchical data, as it doesn't use the parent index and passes nullptr as the internal pointer.\\
## Code: 
```
QModelIndex BoardSelectorTableModel::index(int row, int column,
          const QModelIndex &parent) const  {
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    return createIndex(row, column, nullptr);
}
```