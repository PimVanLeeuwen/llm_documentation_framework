`load`: The function of `load` is to read binary data from a file and populate two maps with key-value pairs.

**Code Description**: This method attempts to open a file specified by `file_path` using QFile. If the file cannot be opened, it throws a runtime error. The function then clears two maps: `flush_map` and `other_map`. It reads an integer value representing the count of entries for the first map. For each entry, it reads a 64-bit key and a 32-bit value, storing them in `flush_map`. This process is repeated for `other_map`. The function uses low-level file reading operations, directly reading bytes into memory locations of variables. It performs assertions to ensure the correct number of entries are read for each map. Finally, it closes the file and returns true if the operation was successful. The commented-out code suggests an alternative file opening method using ifstream was considered but not implemented.\\
## Code: 
```
bool FiveCardsStrength::load(const char* file_path) {
    //ifstream file(file_path, ios::binary);
    /*if (!file) {
        file.close();
        return false;
    }*/

    QFile file(QString::fromStdString(file_path));
    if (!file.open(QIODevice::ReadOnly)){
        throw runtime_error("unable to load compairer file");
    }
    flush_map.clear(); other_map.clear();
    int size_key = sizeof(uint64_t), size_int = sizeof(int), val, cnt = 0;
    uint64_t key = 0;
    char* p_key = (char*)&key, * p_val = (char*)&val, * p_cnt = (char*)&cnt;
    file.read(p_cnt, size_int);// 读取行数
    for (int i = 0; i < cnt; i++) {
        file.read(p_key, size_key);
        file.read(p_val, size_int);
        flush_map[key] = val;
    }
    assert(flush_map.size() == cnt);
    file.read(p_cnt, size_int);// 读取行数
    for (int i = 0; i < cnt; i++) {
        file.read(p_key, size_key);
        file.read(p_val, size_int);
        other_map[key] = val;
    }
    assert(other_map.size() == cnt);
    file.close();
    return true;
}
```