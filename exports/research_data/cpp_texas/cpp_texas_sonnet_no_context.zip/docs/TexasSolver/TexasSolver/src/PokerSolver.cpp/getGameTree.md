`getGameTree`: The function of `getGameTree` is to return a constant reference to the game tree.

**Code Description**: This is a member function of the `PokerSolver` class that provides read-only access to the `game_tree` member variable. The function returns a constant reference to a `shared_ptr` of type `GameTree`. By returning a constant reference, it ensures that the caller cannot modify the `game_tree` object, maintaining the integrity of the game state within the `PokerSolver` instance. The use of `shared_ptr` suggests that the game tree is dynamically allocated and its lifetime is managed through shared ownership.\\
## Code: 
```
const shared_ptr<GameTree> &PokerSolver::getGameTree() const {
    return game_tree;
}
```