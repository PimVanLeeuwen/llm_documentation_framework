`getRiverCombos`: The function of `getRiverCombos` is to retrieve river combinations for a specific player given private cards and the board.

**Code Description**: This method is part of the `RiverRangeManager` class and serves as an overloaded version of another `getRiverCombos` function. It takes three parameters: an integer representing the player, a vector of `PrivateCards` objects called `riverCombos`, and a vector of integers representing the board cards. 

The function first converts the board vector into a 64-bit integer representation using the `Card::boardInts2long` static method. This conversion likely compresses the board information into a more efficient format for further processing.

After the conversion, the method calls another version of `getRiverCombos` with the same player and `riverCombos` parameters, but passes the newly created `board_long` instead of the original board vector. This suggests that the class has an internal implementation that works with the 64-bit board representation.

The function returns a constant reference to a vector of `RiverCombs` objects, which likely contain the calculated river combinations for the specified player. By returning a const reference, the method allows efficient access to the data without unnecessary copying while preventing modifications to the internal data structure.\\
## Code: 
```
const vector<RiverCombs> &
RiverRangeManager::getRiverCombos(int player, const vector<PrivateCards> &riverCombos, const vector<int> &board) {
    uint64_t board_long = Card::boardInts2long(board);
    return this->getRiverCombos(player,riverCombos,board_long);
}
```