`anchorAt`: The function of `anchorAt` is to retrieve the anchor at a specified point within an HTML document.

**Code Description**: This method takes two parameters: an HTML string and a QPoint representing a position. It creates a QTextDocument object and sets its content to the provided HTML. The document layout is then accessed, and the anchorAt method of the layout is called with the given point. This effectively determines if there's an anchor (like a hyperlink) at the specified coordinates within the rendered HTML document, returning the anchor text if found, or an empty string if not.\\
## Code: 
```
QString WordItemDelegate::anchorAt(QString html, const QPoint &point) const {
    QTextDocument doc;
    doc.setHtml(html);

    auto textLayout = doc.documentLayout();
    Q_ASSERT(textLayout != 0);
    return textLayout->anchorAt(point);
}
```