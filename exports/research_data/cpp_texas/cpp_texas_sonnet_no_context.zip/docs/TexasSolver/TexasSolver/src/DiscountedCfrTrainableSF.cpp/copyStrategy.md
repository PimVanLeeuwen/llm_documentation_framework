`copyStrategy`: The function of `copyStrategy` is to copy strategy data from another DiscountedCfrTrainableSF object to the current object.

**Code Description**: This method takes a shared pointer to a Trainable object as its parameter. It first attempts to cast the input to a DiscountedCfrTrainableSF object using dynamic_pointer_cast. Then, it copies two vectors, r_plus and cum_r_plus, from the input object to the current object using the assign method. This effectively transfers the strategy data from one DiscountedCfrTrainableSF object to another, ensuring that both objects have identical r_plus and cum_r_plus vectors after the operation.\\
## Code: 
```
void DiscountedCfrTrainableSF::copyStrategy(shared_ptr<Trainable> other_trainable){
    shared_ptr<DiscountedCfrTrainableSF> trainable = dynamic_pointer_cast<DiscountedCfrTrainableSF>(other_trainable);
    this->r_plus.assign(trainable->r_plus.begin(),trainable->r_plus.end());
    this->cum_r_plus.assign(trainable->cum_r_plus.begin(),trainable->cum_r_plus.end());
}
```