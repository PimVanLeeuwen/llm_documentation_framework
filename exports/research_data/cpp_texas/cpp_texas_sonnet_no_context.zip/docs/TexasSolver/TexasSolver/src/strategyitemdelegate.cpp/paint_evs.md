`paint_evs`: The function of `paint_evs` is to paint a visual representation of expected values (EVs) for a strategy item in a table view.

**Code Description**: This method is part of the `StrategyItemDelegate` class and is responsible for custom painting of table cells. It takes a painter, style options, and a model index as parameters. The function performs the following steps:

1. Initializes style options and retrieves the table strategy model.
2. Obtains and sorts the EV grid for the current cell.
3. Iterates through the sorted EVs, calculating a normalized value for each using a tanh function.
4. For each EV, it determines a color based on the normalized value, with red representing lower values and green representing higher values.
5. Paints rectangles within the cell, with widths proportional to the number of EVs and colors corresponding to their values.
6. Finally, it sets up a QTextDocument to render any HTML text associated with the cell.

The result is a color-coded visualization of the EVs within the table cell, providing a quick visual representation of the strategy's expected values.\\
## Code: 
```
void StrategyItemDelegate::paint_evs(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);
    const TableStrategyModel * tableStrategyModel = qobject_cast<const TableStrategyModel*>(index.model());
    vector<float> evs = tableStrategyModel->get_ev_grid(index.row(),index.column());
    sort(evs.begin(), evs.end());

    int last_left = 0;
    for(std::size_t i = 0;i < evs.size();i ++ ){
        float one_ev = evs[evs.size() - i - 1];
        float normalized_ev = normalization_tanh(this->qSolverJob->stack,one_ev);
        //options.text += QString("</br>%1").arg(QString::number(normalized_ev));

        int red = max((int)(255 - normalized_ev * 255),0);
        int green = min((int)(normalized_ev * 255),255);
        int blue = min(red, green);

        QBrush brush = QBrush(QColor(red,green,blue));

        int this_width = (int)((float(i + 1) / evs.size()) * options.rect.width()) - last_left;

        QRect rect(option.rect.left() + last_left, option.rect.top(),\
             this_width , (int) (options.rect.height()));
        painter->fillRect(rect, brush);
        last_left += this_width;
    }
    QTextDocument doc;
    doc.setHtml(options.text);
    options.text = "";
    //options.widget->style()->drawControl(QStyle::CE_ItemViewItem, &option, painter);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```