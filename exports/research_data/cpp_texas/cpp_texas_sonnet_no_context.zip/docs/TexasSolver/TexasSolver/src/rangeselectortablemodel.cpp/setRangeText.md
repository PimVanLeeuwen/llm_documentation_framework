`setRangeText`: The function of `setRangeText` is to parse and process a string input representing ranges and update the internal grid structure accordingly.

**Code Description**: This method takes a QString `input_range` as input. It first clears the existing range data using `clear_range()`. The input string is split by commas, and each resulting substring is treated as a separate range. For each range:

1. Empty ranges are skipped.
2. The range is split by ':' into a key and an optional value.
3. If the split results in more than 2 or less than 1 part, an error is logged and the range is skipped.
4. A default range value of 1.0 is set.
5. The key is processed:
   - If it exists in `string2ij`, it's used as is.
   - If not, two variations are created by appending 'o' and 's' to the key.
6. For each processed key:
   - Empty keys are skipped.
   - If the key doesn't exist in `string2ij`, an error is logged and it's skipped.
   - The corresponding grid coordinates are retrieved from `string2ij`.
   - If a value was provided in the range, it's converted to float.
   - The `grids_float` 2D array is updated at the retrieved coordinates with the range value.

This method appears to be part of a class that manages a grid-based range selector, where keys are mapped to grid coordinates and associated with float values.\\
## Code: 
```
void RangeSelectorTableModel::setRangeText(QString input_range){
    this->clear_range();
    for(QString one_range:input_range.split(",")){
        if(one_range.trimmed() == "")continue;
        QStringList one_range_list = one_range.split(":");

        if(one_range_list.size() > 2 || one_range_list.size() < 1){
            qDebug().noquote() << QString(tr("skipping range %1, format error, range list should contain two part seperate by ':'")).arg(one_range);
        }

        float range_float = 1.0;
        QString key_range = one_range_list[0];
        QStringList keys;
        if(this->string2ij.count(one_range_list[0])){
            keys.append(key_range);
        }else{
            keys.append(key_range + "o");
            keys.append(key_range + "s");
        }

        for(QString one_key: keys){
            if(one_key.count(" ") == one_key.length() || one_key == "")continue;
            if(!this->string2ij.count(one_key)){
                qDebug().noquote() << QString(tr("skipping range %1, format error")).arg(one_range);
                continue;
            }
            pair<int,int> cord = this->string2ij[one_key];
            if(one_range_list.size() > 1)range_float = one_range_list[1].toFloat();
            this->grids_float[cord.first][cord.second] = range_float;
        }
    }
}
```