`progressbar`: The function of `progressbar` is to initialize a progress bar object with specified parameters.

**Code Description**: This is a constructor for a `progressbar` class. It takes two parameters: an integer `n` representing the total number of cycles, and a boolean `showbar` indicating whether to display the progress bar. The constructor initializes several member variables:

1. `progress`: Set to 0, likely representing the current progress.
2. `n_cycles`: Set to the input parameter `n`, representing the total number of cycles.
3. `last_perc`: Set to 0, possibly used to track the last displayed percentage.
4. `do_show_bar`: Set to the input parameter `showbar`, determining whether to show the progress bar.
5. `update_is_called`: Set to false, potentially used to track if an update method has been called.
6. `done_char`: Set to "#", representing the character used for completed progress.
7. `todo_char`: Set to " " (space), representing the character used for remaining progress.
8. `opening_bracket_char`: Set to "[", used as the opening bracket for the progress bar.
9. `closing_bracket_char`: Set to "]", used as the closing bracket for the progress bar.

These initializations set up the initial state of the progress bar, including its appearance and behavior. The actual display and updating of the progress bar would likely be handled by other methods in the class.\\
## Code: 
```
progressbar::progressbar(int n, bool showbar) :
        progress(0),
        n_cycles(n),
        last_perc(0),
        do_show_bar(showbar),
        update_is_called(false),
        done_char("#"),
        todo_char(" "),
        opening_bracket_char("["),
        closing_bracket_char("]") {}
```