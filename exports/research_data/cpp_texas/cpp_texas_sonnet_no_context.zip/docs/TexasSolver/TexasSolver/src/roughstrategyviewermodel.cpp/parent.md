`parent`: The function of `parent` is to return the parent index of a given child index in a model.

**Code Description**: This method is part of the `RoughStrategyViewerModel` class and implements the `parent` function required by Qt's model/view framework. It takes a `QModelIndex` parameter named `child` representing a child item in the model. However, in this implementation, the function always returns an invalid `QModelIndex()`, regardless of the input. This suggests that the model represents a flat list or table structure where items don't have parent-child relationships, or that the parent-child hierarchy is not implemented in this particular model.\\
## Code: 
```
QModelIndex RoughStrategyViewerModel::parent(const QModelIndex &child) const{
    return QModelIndex();
}
```