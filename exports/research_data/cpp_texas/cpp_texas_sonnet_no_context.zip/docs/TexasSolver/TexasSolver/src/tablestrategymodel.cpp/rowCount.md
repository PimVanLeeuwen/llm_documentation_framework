`rowCount`: The function of `rowCount` is to return the number of rows in the table model.

**Code Description**: This method is part of the TableStrategyModel class and implements the rowCount function, which is typically used in Qt's Model/View framework. It takes a QModelIndex parameter named 'parent' (which is not used in this implementation) and returns an integer. The function accesses the solver object through the qSolverJob member, retrieves the deck from the solver, and then returns the size of the ranks collection from that deck. This size represents the number of rows in the table model.\\
## Code: 
```
int TableStrategyModel::rowCount(const QModelIndex &parent) const
{
    return this->qSolverJob->get_solver()->get_deck()->getRanks().size();
}
```