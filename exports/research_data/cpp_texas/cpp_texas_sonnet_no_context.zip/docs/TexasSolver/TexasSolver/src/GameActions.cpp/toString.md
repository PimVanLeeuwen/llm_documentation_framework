`toString`: The function of `toString` is to convert a GameAction object to a string representation.

**Code Description**: This method returns a string that describes the poker action. If the `amount` is -1, it simply returns the string representation of the action. Otherwise, it returns the action string followed by a space and the amount. The `pokerActionToString` method (not shown here) is likely used to convert the action enum to its string equivalent. The `to_string` function is used to convert the numeric amount to a string.\\
## Code: 
```
string GameActions::toString() {
    if(this->amount == -1) {
        return this->pokerActionToString(this->action);
    }else{
        return this->pokerActionToString(this->action) + " " + to_string(amount);
    }
}
```