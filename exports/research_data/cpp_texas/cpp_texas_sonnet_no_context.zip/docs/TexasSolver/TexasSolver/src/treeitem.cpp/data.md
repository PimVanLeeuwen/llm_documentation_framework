`data`: The function of `data` is to return a QVariant representing the current node's data in a game tree.

**Code Description**: This method retrieves and formats information about the current node in a game tree structure. It first attempts to get the parent and current nodes from the m_treedata member. If there's no parent node, it returns a string indicating the beginning of a round. For nodes with an ACTION parent, it searches for the current node among the parent's children, then returns a string describing the player's action and amount. For nodes with a CHANCE parent, it returns a string indicating which card is being dealt (flop, turn, or river). If none of these conditions are met, it returns "NodeError". The function uses dynamic casting to handle different node types and accesses various properties of the game tree nodes to construct the return value.\\
## Code: 
```
QVariant TreeItem::data() const
{
    shared_ptr<GameTreeNode> parentNode = this->m_treedata.lock()->getParent();
    shared_ptr<GameTreeNode> currentNode = this->m_treedata.lock();
    if(parentNode == nullptr){
        return TreeItem::get_round_str(currentNode->getRound()) + QObject::tr(" begin");
    }
    if(parentNode->getType() == GameTreeNode::GameTreeNodeType::ACTION){
        shared_ptr<ActionNode> parentActionNode = dynamic_pointer_cast<ActionNode>(parentNode);
        vector<GameActions>& actions = parentActionNode->getActions();
        vector<shared_ptr<GameTreeNode>>& childrens = parentActionNode->getChildrens();
        for(std::size_t i = 0;i < childrens.size();i ++){
            if(childrens[i] == currentNode){
                float amount = childrens[i]->getPot() - parentNode->getPot();
                return (parentActionNode->getPlayer() == 0 ? QObject::tr("IP "):QObject::tr("OOP ")) + \
                       TreeItem::get_game_action_str(actions[i].getAction(),actions[i].getAmount());
            }
        }
    }if(parentNode->getType() == GameTreeNode::GameTreeNodeType::CHANCE){
        shared_ptr<ChanceNode> chanceNode = dynamic_pointer_cast<ChanceNode>(parentNode);
        if(chanceNode->getRound() == GameTreeNode::GameRound::FLOP){
            return QObject::tr("DEAL FLOP CARD");
        }
        else if(chanceNode->getRound() == GameTreeNode::GameRound::TURN){
            return QObject::tr("DEAL TURN CARD");
        }
        else if(chanceNode->getRound() == GameTreeNode::GameRound::RIVER){
            return QObject::tr("DEAL RIVER CARD");
        }else throw runtime_error("round not recognized");
    }
    return "NodeError";
}
```