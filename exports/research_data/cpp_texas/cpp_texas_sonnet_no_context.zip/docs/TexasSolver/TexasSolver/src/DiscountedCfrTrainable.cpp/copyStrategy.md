`copyStrategy`: The function of `copyStrategy` is to copy strategy data from another DiscountedCfrTrainable object to the current object.

**Code Description**: This method takes a shared pointer to a Trainable object as its parameter. It first performs a dynamic cast to convert the input to a DiscountedCfrTrainable pointer. Then, it copies two vectors, r_plus and cum_r_plus, from the source object to the current object using the assign() method. This effectively transfers the strategy data from one DiscountedCfrTrainable object to another.\\
## Code: 
```
void DiscountedCfrTrainable::copyStrategy(shared_ptr<Trainable> other_trainable){
    shared_ptr<DiscountedCfrTrainable> trainable = dynamic_pointer_cast<DiscountedCfrTrainable>(other_trainable);
    this->r_plus.assign(trainable->r_plus.begin(),trainable->r_plus.end());
    this->cum_r_plus.assign(trainable->cum_r_plus.begin(),trainable->cum_r_plus.end());
}
```