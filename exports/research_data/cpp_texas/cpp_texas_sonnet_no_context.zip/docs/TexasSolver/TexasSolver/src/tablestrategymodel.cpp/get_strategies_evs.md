`get_strategies_evs`: The function of `get_strategies_evs` is to calculate and return the expected values (EVs) of strategies for a specific game state.

**Code Description**: This method takes two integer parameters (i and j) and returns a vector of floats representing the EVs of different strategies. It first checks if the necessary data structures are initialized. If not, it returns an empty vector. 

The function then determines the current player's range based on the `current_player` value. It retrieves the game tree node and checks if it's an action node. For action nodes, it processes the strategies and EVs for the specified game state (i, j).

The core of the function involves iterating through the strategy table for the given i and j indices. For each entry, it combines the strategy probabilities, current EVs, and range values to calculate weighted EVs. It also keeps track of the total range and strategy probabilities.

Finally, it normalizes the calculated EVs by dividing them by the corresponding strategy probabilities, ensuring the results are properly scaled. The function returns these normalized EVs for the given game state.

If the node is not an action node or if any required data is missing, the function returns an empty vector.\\
## Code: 
```
const vector<float> TableStrategyModel::get_strategies_evs(int i,int j)const{
    vector<float> ret_evs;
    if(this->treeItem == NULL || this->current_evs.empty())return ret_evs;

    const vector<vector<float>> *current_range;
    current_range = (0 == current_player ) ? & p1_range : & p2_range;
    if(p1_range.empty() || p2_range.empty()){
        return ret_evs;
    }

    shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();

    if(node->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);
        vector<GameActions>& gameActions = actionNode->getActions();

        vector<float> strategy_p;
        if(this->ui_strategy_table[i][j].size() > 0){
            ret_evs = vector<float>(gameActions.size());
            std::fill(ret_evs.begin(), ret_evs.end(), 0.);
            strategy_p = vector<float>(gameActions.size());
            std::fill(strategy_p.begin(), strategy_p.end(), 0.);
        }
        float range = 0;
        for(std::pair<int,int> index:this->ui_strategy_table[i][j]){
            int index1 = index.first;
            int index2 = index.second;
            const vector<float>& one_strategy = this->current_strategy[index1][index2];
            const vector<float>& one_ev = this->current_evs[index1][index2];
            const float one_range = (*current_range)[index1][index2];
            if(gameActions.size() != one_strategy.size() || one_ev.size() != one_strategy.size()){
                cout << "index: " << index1 << " " << index2 << endl;
                cout << "i,j: " << i << " " << j << endl;
                cout << "size not match between one_ev, gameAction and one_stragegy: "
                     << one_ev.size() << " " << gameActions.size() << " " << one_strategy.size() << endl;
                throw runtime_error("size not match between one_ev, gameAction and one_stragegy");
            }
            for(std::size_t indi = 0;indi < ret_evs.size();indi ++){
                ret_evs[indi] += one_strategy[indi] * one_ev[indi] * one_range;
                strategy_p[indi] += one_strategy[indi] * one_range;
            }
            range += one_range;
        }
        for(std::size_t indi = 0;indi < ret_evs.size();indi ++){
            if (strategy_p[indi] > 0. && range > 0.) {
                ret_evs[indi] = ret_evs[indi] / strategy_p[indi];
            }
        }
        return ret_evs;
    }else{
        return ret_evs;
    }
}
```