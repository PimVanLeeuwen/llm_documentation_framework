`setRelativeProbs`: The function of `setRelativeProbs` is to calculate and set relative probabilities for private cards of players in a card game.

**Code Description**: This method iterates through each player's private cards and calculates their relative probabilities based on the opponent's cards and the initial board state. It performs the following steps:

1. Loops through each player (currently assumes two players).
2. For each player's private card:
   - Converts the player's card to a 64-bit integer representation.
   - Checks if the player's card intersects with the initial board, skipping if it does.
   - Calculates a sum of probabilities for the opponent's cards that don't intersect with the player's card or the initial board.
   - Computes the relative probability for the player's card by multiplying the opponent's probability sum with the player's card weight.
3. Sums up all relative probabilities for the player.
4. Normalizes the relative probabilities by dividing each by the sum, ensuring they add up to 1.

The code uses bitwise operations to efficiently check for card intersections and handles card representations using both integer arrays and 64-bit long integers. It also accounts for card weights in probability calculations, suggesting this might be used in a poker-like game with imperfect information.\\
## Code: 
```
void PrivateCardsManager::setRelativeProbs() {
    int players = this->private_cards.size();
    for(int player_id = 0; player_id < players;player_id ++){
        // TODO 这里只考虑了两个玩家的情况
        int oppo = 1 - player_id;
        float player_prob_sum = 0;

        for(std::size_t i = 0;i < this->private_cards[player_id].size();i ++) {
            float oppo_prob_sum = 0;
            PrivateCards* player_card = &this->private_cards[player_id][i];
            uint64_t player_long = Card::boardInts2long(player_card->get_hands());

            //
            if (Card::boardsHasIntercept(player_long,this->initialboard)){
                continue;
            }

            for (auto oppo_card : this->private_cards[oppo]) {
                uint64_t oppo_long = Card::boardInts2long(oppo_card.get_hands());
                if (Card::boardsHasIntercept(oppo_long,this->initialboard)
                    || Card::boardsHasIntercept(oppo_long,player_long)
                        ){
                    continue;
                }
                oppo_prob_sum += oppo_card.weight;

            }
            player_card->relative_prob = oppo_prob_sum * player_card->weight;
            player_prob_sum += player_card->relative_prob;
        }
        for(std::size_t i = 0;i < this->private_cards[player_id].size();i ++) {
            this->private_cards[player_id][i].relative_prob = this->private_cards[player_id][i].relative_prob / player_prob_sum;
            //player_card.relative_prob = player_card.relative_prob / player_prob_sum;
        }

    }
}
```