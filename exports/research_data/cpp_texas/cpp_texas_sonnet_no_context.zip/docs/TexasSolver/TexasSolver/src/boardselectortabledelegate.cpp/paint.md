`paint`: The function of `paint` is to render a custom cell in a table view, displaying a card with a colored background based on probability values.

**Code Description**: This method is part of a custom delegate for a board selector table. It paints each cell with the following elements:

1. A gray background for the entire cell.
2. A yellow rectangle at the bottom of the cell, with its height proportional to the board probability (1 - fold probability).
3. A card representation using HTML formatting.

The painting process involves these steps:
1. Save the painter's state and initialize style options.
2. Draw a gray background for the entire cell.
3. Retrieve the board probability value for the current cell.
4. Calculate the height of the yellow rectangle based on the board probability.
5. Draw the yellow rectangle at the bottom of the cell.
6. Create a QTextDocument with HTML-formatted text representing a card.
7. Translate the painter to the cell's top-left corner.
8. Draw the card content within the cell's boundaries.
9. Restore the painter's state.

This custom painting allows for a visual representation of probabilities and card information within each cell of the board selector table.\\
## Code: 
```
void BoardSelectorTableDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const{

    painter->save();
    auto options = option;
    initStyleOption(&options, index);

    QRect rect(option.rect.left(), option.rect.top(),\
             option.rect.width(), option.rect.height());
    QBrush brush(Qt::gray);
    painter->fillRect(rect, brush);

    float board_float = this->boardSelectorTableModel->getBoardAt(index.row(),index.column());

    float fold_prob = 1 - board_float;
    int disable_height = (int)(fold_prob * option.rect.height());
    int remain_height = option.rect.height() - disable_height;

    rect = QRect(option.rect.left(), option.rect.top() + disable_height,\
     option.rect.width(), remain_height);
    brush = QBrush(Qt::yellow);
    painter->fillRect(rect, brush);

    QTextDocument doc;
    doc.setHtml(Card(options.text.toStdString()).toFormattedHtml());

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
    painter->restore();
}
```