`execFromFile`: The function of `execFromFile` is to execute commands from a specified input file.

**Code Description**: This method takes a string parameter `input_file` representing the path to a file containing commands. It opens the file using an `ifstream` object and reads it line by line. For each line read from the file, it calls the `processCommand` method of the current object (`this`), passing the line as an argument. This process continues until all lines in the file have been read and processed. The method effectively allows batch processing of commands stored in a text file.\\
## Code: 
```
void CommandLineTool::execFromFile(string input_file){
    std::ifstream infile(input_file);
    std::string input_line;
    while (std::getline(infile, input_line))
    {
        this->processCommand(input_line);
    }

}
```