`PrivateCards`: The function of `PrivateCards` is to initialize a private card combination in a poker game.

**Code Description**: This constructor initializes a `PrivateCards` object with two card values and a weight. It sets the `card1` and `card2` member variables to the provided values and assigns the given weight. The `relative_prob` is initialized to 0. A vector `card_vec` is created containing both card values. The constructor then calculates a unique `hash_code` for the card combination, ensuring the order of cards doesn't matter by using the larger value first. Finally, it converts the card vector to a long integer representation of the board using the `Card::boardInts2long` method.\\
## Code: 
```
PrivateCards::PrivateCards(int card1, int card2, float weight) {
    this->card1 = card1;
    this->card2 = card2;
    this->weight = weight;
    this->relative_prob = 0;
    this->card_vec = vector<int>{this->card1,this->card2};
    if (card1 > card2){
        this->hash_code = card1 * 52 + card2;
    }else{
        this->hash_code = card2 * 52 + card1;
    }
    this->board_long = Card::boardInts2long(this->card_vec);
}
```