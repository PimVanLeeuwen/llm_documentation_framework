`RoughStrategyViewerModel`: The function of `RoughStrategyViewerModel` is to create a new model for viewing rough strategies, initialized with a table strategy model.

**Code Description**: This code defines the constructor for the `RoughStrategyViewerModel` class. It inherits from `QAbstractItemModel` and takes two parameters: a pointer to a `TableStrategyModel` and an optional `QObject` parent. The constructor initializes the base class with the provided parent and stores the `tableStrategyModel` pointer as a member variable. This setup suggests that the `RoughStrategyViewerModel` will use the `TableStrategyModel` to provide a different view or representation of the strategy data.\\
## Code: 
```
RoughStrategyViewerModel::RoughStrategyViewerModel(TableStrategyModel* tableStrategyModel, QObject *parent):QAbstractItemModel(parent){
    this->tableStrategyModel = tableStrategyModel;
}
```