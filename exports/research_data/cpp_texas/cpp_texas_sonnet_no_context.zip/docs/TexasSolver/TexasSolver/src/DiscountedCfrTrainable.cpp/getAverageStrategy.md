`getAverageStrategy`: The function of `getAverageStrategy` is to calculate and return the average strategy for each action and private information combination.

**Code Description**: This method computes the average strategy for a game scenario using discounted cumulative regret matching. It initializes a vector `average_strategy` with size equal to the product of `action_number` and `card_number`. The function then iterates through each private information (represented by `private_id`) and calculates the strategy for each possible action.

For each `private_id`, it first computes the sum of cumulative regrets (`r_plus_sum`) across all actions. Then, for each action, it calculates the average strategy by dividing the cumulative regret for that action by the total sum. If the sum is zero, it assigns a uniform probability of 1/action_number to each action.

The average strategy is stored in the `average_strategy` vector, where each element represents the probability of taking a specific action given a particular private information. The index for each strategy value is calculated as `action_id * card_number + private_id`.

Finally, the function returns the `average_strategy` vector containing the computed average strategies for all action-information combinations.\\
## Code: 
```
const vector<float> DiscountedCfrTrainable::getAverageStrategy() {
    vector<float> average_strategy;
    average_strategy = vector<float>(this->action_number * this->card_number);
    for (int private_id = 0; private_id < this->card_number; private_id++) {
        float r_plus_sum = 0;
        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            r_plus_sum += this->cum_r_plus[index];
        }

        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            if(r_plus_sum) {
                average_strategy[index] = this->cum_r_plus[index] / r_plus_sum;
            }else{
                average_strategy[index] = 1.0 / this->action_number;
            }
        }
    }
    return average_strategy;
}
```