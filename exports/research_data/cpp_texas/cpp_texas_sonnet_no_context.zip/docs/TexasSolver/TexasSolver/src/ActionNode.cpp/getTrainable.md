`getTrainable`: The function of `getTrainable` is to retrieve or create a trainable object for a specific index.

**Code Description**: This method is part of the ActionNode class and returns a shared pointer to a Trainable object. It takes three parameters: an index i, a boolean create_on_site, and an integer use_halffloats.

The function first checks if the requested index is within bounds of the trainables vector. If not, it throws a runtime error with a formatted message.

If the trainable at the specified index is null and create_on_site is true, the function creates a new trainable object. The type of trainable created depends on the game round and the use_halffloats parameter:

1. If it's not the RIVER round or use_halffloats is 0, it creates a DiscountedCfrTrainable.
2. If it's the RIVER round and use_halffloats is 1, it creates a DiscountedCfrTrainableSF.
3. If it's the RIVER round and use_halffloats is 2, it creates a DiscountedCfrTrainableHF.

All these trainable objects are initialized with player_privates and a reference to the current object (*this).

Finally, the function returns the shared pointer to the trainable object at the specified index, whether it was newly created or already existed.\\
## Code: 
```
shared_ptr<Trainable> ActionNode::getTrainable(int i,bool create_on_site, int use_halffloats) {
    if(i > this->trainables.size()){
        throw runtime_error(tfm::format("size unacceptable %s > %s ",i,this->trainables.size()));
    }
    if(this->trainables[i] == nullptr && create_on_site){
        switch ((this->getRound() == GameTreeNode::RIVER) ? use_halffloats : 0 ){
        case 0:
            this->trainables[i] = make_shared<DiscountedCfrTrainable>(player_privates,*this);
            break;
        case 1:
            this->trainables[i] = make_shared<DiscountedCfrTrainableSF>(player_privates,*this);
            break;
        case 2:
            this->trainables[i] = make_shared<DiscountedCfrTrainableHF>(player_privates,*this);
            break;
        }
    }
    return this->trainables[i];
}
```