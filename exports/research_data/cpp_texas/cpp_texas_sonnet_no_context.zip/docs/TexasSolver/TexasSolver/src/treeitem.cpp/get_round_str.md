`get_round_str`: The function of `get_round_str` is to convert a GameRound enum value to its corresponding string representation.

**Code Description**: This method takes a `GameTreeNode::GameRound` enum as input and returns a `QString` representing the round name. It uses a series of if-else statements to check the input value:

1. If the round is `GameTreeNode::GameRound::FLOP`, it returns the translated string "FLOP".
2. If the round is `GameTreeNode::GameRound::TURN`, it returns the translated string "TURN".
3. If the round is `GameTreeNode::GameRound::RIVER`, it returns the translated string "RIVER".
4. If the input doesn't match any of these values, it throws a `runtime_error` with the message "round not recognized, must be in flop,turn,river".

The function uses `QObject::tr()` for string translation, making it internationalization-friendly. This method is likely part of a larger system for managing or displaying game states in a poker-like card game.\\
## Code: 
```
QString TreeItem::get_round_str(GameTreeNode::GameRound round) const{
    if(round == GameTreeNode::GameRound::FLOP){
        return QObject::tr("FLOP");
    }
    else if(round == GameTreeNode::GameRound::TURN){
        return QObject::tr("TURN");
    }
    else if(round == GameTreeNode::GameRound::RIVER){
        return QObject::tr("RIVER");
    }
    else throw runtime_error("round not recognized, must be in flop,turn,river");
}
```