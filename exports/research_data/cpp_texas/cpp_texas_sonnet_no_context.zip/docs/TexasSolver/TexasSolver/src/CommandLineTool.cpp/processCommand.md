`processCommand`: The function of `processCommand` is to parse and execute various commands related to poker game settings and strategy solving.

**Code Description**: This method takes a string input and processes it as a command. It first splits the input into command and parameter parts. The function then uses a series of if-else statements to identify the command and execute the corresponding action. Here's a breakdown of the main commands:

1. `set_pot`: Sets the pot size, dividing it equally between in-position (ip) and out-of-position (oop) players.
2. `set_effective_stack`: Sets the effective stack size.
3. `set_board`: Sets the community cards and determines the current round based on the number of cards.
4. `set_range_ip` and `set_range_oop`: Set the ranges for in-position and out-of-position players.
5. `set_bet_sizes`: Configures betting sizes for different scenarios (bet, raise, donk) for a specific player and round.
6. `set_accuracy`, `set_allin_threshold`, `set_thread_num`: Set various solver parameters.
7. `build_tree`: Builds the game tree based on current settings.
8. `set_max_iteration`, `set_use_isomorphism`, `set_print_interval`: Set additional solver parameters.
9. `start_solve`: Initiates the solving process with specified parameters.
10. `dump_result`: Saves the solved strategy to a file.
11. `set_dump_rounds`: Sets the number of rounds to dump in the result.

The function throws runtime errors for invalid inputs or unrecognized commands. It interacts with various member variables and objects (like `ps` for PokerSolver) to manage the poker game state and solver configuration.\\
## Code: 
```
void CommandLineTool::processCommand(string input) {
    vector<string> contents;
    split(input,' ',contents);
    if(contents.size() == 0) contents = {input};
    if(contents.size() > 2 || contents.size() < 1)throw runtime_error(tfm::format("command not valid: %s",input));
    string command = contents[0];
    string paramstr = contents.size() == 1 ? "" : contents[1];
    if(command == "set_pot"){
        this->ip_commit = stof(paramstr) / 2;
        this->oop_commit = stof(paramstr) / 2;
    }else if(command == "set_effective_stack"){
        this->stack = stof(paramstr) + this->ip_commit;
    }else if(command == "set_board"){
        this->board = paramstr;
        vector<string> board_str_arr = string_split(board,',');
        if(board_str_arr.size() == 3){
            this->current_round = 1;
        }else if(board_str_arr.size() == 4){
            this->current_round = 2;
        }else if(board_str_arr.size() == 5){
            this->current_round = 3;
        }else{
            throw runtime_error(tfm::format("board %s not recognized",this->board));
        }
    }else if(command == "set_range_ip"){
        this->range_ip = paramstr;
    }else if(command == "set_range_oop"){
        this->range_oop = paramstr;
    }else if(command == "set_bet_sizes"){
        vector<string> params;
        split(paramstr,',',params);
        if(params.size() < 3)throw runtime_error("param number error");
        // oop,turn,bet,30,70,100
        string player = params[0];
        string round = params[1];
        string bet_type = params[2];
        StreetSetting& streetSetting = this->gtbs->get_setting(player,round);
        vector<float>* sizes;
        if(bet_type == "allin") streetSetting.allin = true;
        else if(bet_type == "bet") sizes = &(streetSetting.bet_sizes);
        else if(bet_type == "raise") sizes = &(streetSetting.raise_sizes);
        else if(bet_type == "donk") sizes = &(streetSetting.donk_sizes);
        else throw runtime_error("");

        if(bet_type == "bet" || bet_type == "raise" || bet_type == "donk"){
            sizes->clear();
            for(std::size_t i = 3;i < params.size();i ++ ){
                sizes->push_back(stof(params[i]));
            }
        }
    }else if(command == "set_accuracy"){
        this->accuracy = stof(paramstr);
    }else if(command == "set_allin_threshold"){
        this->allin_threshold = stof(paramstr);
    }else if(command == "set_thread_num"){
        this->thread_number = stoi(paramstr);
    }else if(command == "build_tree"){
        this->ps.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }else if(command == "set_max_iteration"){
        this->max_iteration = stoi(paramstr);
    }else if(command == "set_use_isomorphism"){
        this->use_isomorphism = stoi(paramstr);
    }else if(command == "set_print_interval"){
        this->print_interval = stoi(paramstr);
    }else if(command == "start_solve"){
        cout << "<<<START SOLVING>>>" << endl;
        this->ps.train(
                this->range_ip,
                this->range_oop,
                this->board,
                "tmp_log.txt",
                max_iteration,
                this->print_interval,
                "discounted_cfr",
                -1,
                this->accuracy,
                this->use_isomorphism,
                0, // TODO: enable half float option for command line tool
                this->thread_number
        );
    }else if(command == "dump_result"){
        string output_file = paramstr;
        this->ps.dump_strategy(QString::fromStdString(output_file),this->dump_rounds);
    }else if(command == "set_dump_rounds"){
        this->dump_rounds = stoi(paramstr);
    }else{
        cout << "command not recognized: " << command << endl;
    }
}
```