`get_rank`: The function of `get_rank` is to determine the rank of a poker hand given private cards and public board cards.

**Code Description**: This method is part of the `Dic5Compairer` class and takes two parameters: `private_hand` and `public_board`, both of type `uint64_t`. It converts these 64-bit integer representations of cards into a board format using the `Card::long2board` function. Then, it calls another overloaded version of `get_rank` with these converted board representations. The function likely calculates and returns the rank or strength of the resulting poker hand based on the combination of private and public cards.\\
## Code: 
```
int Dic5Compairer::get_rank(uint64_t private_hand, uint64_t public_board) {
    return this->get_rank(Card::long2board(private_hand),Card::long2board(public_board));
}
```