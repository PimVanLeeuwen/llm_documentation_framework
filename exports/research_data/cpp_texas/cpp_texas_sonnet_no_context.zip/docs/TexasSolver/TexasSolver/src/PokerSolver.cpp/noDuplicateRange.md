`noDuplicateRange`: The function of `noDuplicateRange` is to filter out duplicate private cards and those that conflict with the given board cards.

**Code Description**: This function takes two parameters: a vector of `PrivateCards` objects representing a range of private hands, and a 64-bit integer representing the board cards. It performs the following steps:

1. Initializes an empty vector `range_array` to store the filtered results.
2. Creates an unordered map `rangekv` to track unique hand combinations.
3. Iterates through each `PrivateCards` object in the input `private_range`:
   - Checks if the hand's hash code already exists in `rangekv`.
   - If it exists, throws a runtime error for duplicate hands.
   - If not, adds the hash code to `rangekv`.
   - Converts the hand to a 64-bit integer representation.
   - Checks if the hand has no cards in common with the board cards.
   - If there's no overlap, adds the hand to `range_array`.
4. Returns the filtered `range_array`.

The function ensures that the resulting range contains only unique private hands that don't share any cards with the board, effectively removing duplicates and conflicting hands from the input range.\\
## Code: 
```
vector<PrivateCards> noDuplicateRange(const vector<PrivateCards> &private_range, uint64_t board_long) {
    vector<PrivateCards> range_array;
    unordered_map<int,bool> rangekv;
    for(PrivateCards one_range:private_range){
        if(rangekv.find(one_range.hashCode()) != rangekv.end())
            throw runtime_error(tfm::format("duplicated key %s",one_range.toString()));
        rangekv[one_range.hashCode()] = true;
        uint64_t hand_long = Card::boardInts2long(one_range.get_hands());
        if(!Card::boardsHasIntercept(hand_long,board_long)){
            range_array.push_back(one_range);
        }
    }
    return range_array;
}
```