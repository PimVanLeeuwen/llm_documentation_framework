`HtmlTableRangeView`: The function of `HtmlTableRangeView` is to create a specialized HTML table view with range selection capabilities.

**Code Description**: This code defines the constructor for the `HtmlTableRangeView` class, which inherits from `HtmlTableView`. It sets up the view for mouse tracking and range selection. The constructor installs an event filter on the viewport, enables mouse tracking, and initializes the `mouseTracker` struct with default values. The `mouseTracker.tracking` is set to false, and the `pressed_i` and `pressed_j` values are set to -1, indicating no cell is currently selected. These preparations allow the view to handle mouse events for selecting ranges within the HTML table.\\
## Code: 
```
HtmlTableRangeView::HtmlTableRangeView(QWidget *parent):
HtmlTableView(parent)
{
    viewport()->installEventFilter(this);
    setMouseTracking(true);
    mouseTracker.tracking = false;
    mouseTracker.pressed_i = -1;
    mouseTracker.pressed_j = -1;
}
```