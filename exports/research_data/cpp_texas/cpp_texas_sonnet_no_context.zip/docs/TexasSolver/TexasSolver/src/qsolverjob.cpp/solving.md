`solving`: The function of `solving` is to initiate and execute a poker hand solving process.

**Code Description**: This method begins by logging a debug message indicating the start of the solving process. It then checks the game mode (HOLDEM or SHORTDECK) and calls the appropriate train method on either the `ps_holdem` or `ps_shortdeck` object. The train method is called with several parameters including ranges for in-position and out-of-position players, the board, maximum iterations, print interval, solver algorithm (set to "discounted_cfr"), accuracy, and various optimization flags. After the solving process is complete, it logs a debug message indicating the end of the process. The code includes TODO comments noting potential memory leak and crash issues that need to be addressed.\\
## Code: 
```
void QSolverJob::solving(){
    // TODO  为什么ui上多次求解会积累memory？哪里leak了？
    // TODO  为什么有时候会莫名闪退？
    qDebug().noquote() << tr("Start Solving..");//.toStdString() << std::endl;

    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }
    qDebug().noquote() << tr("Solving done.");//.toStdString() << std::endl;
}
```