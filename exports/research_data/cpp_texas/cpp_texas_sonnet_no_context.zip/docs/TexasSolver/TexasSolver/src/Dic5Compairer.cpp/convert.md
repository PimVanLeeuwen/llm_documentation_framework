`convert`: The function of `convert` is to categorize and reorganize poker hand strengths based on flush and non-flush hands.

**Code Description**: This method takes an unordered map `strength_map` as input, where the keys are 64-bit integers representing card combinations, and the values are their corresponding strength rankings. The function processes this map and separates the hands into two categories: flush hands and non-flush hands.

The function first clears two member variables, `flush_map` and `other_map`. It then iterates through the input `strength_map`. For each entry:

1. It extracts the cards_hash (key) and its strength (value).
2. It computes a new hash value using the `ranks_hash` function, which likely creates a hash based on the ranks of the cards.
3. It checks if the hand is a flush using the `is_flush` function.
4. If the hand is a flush, it's added to the `flush_map` with the original cards_hash as the key.
5. If the hand is not a flush, it's added to the `other_map` with the new rank-based hash as the key.

The commented-out code suggests there was once a check for inconsistencies in non-flush hand strengths, but it's currently disabled.

This separation allows for more efficient lookup and comparison of hand strengths later, as flush hands and non-flush hands can be evaluated separately.\\
## Code: 
```
void FiveCardsStrength::convert(unordered_map<uint64_t, int>& strength_map) {
    flush_map.clear(); other_map.clear();
    auto it = strength_map.begin(), it_end = strength_map.end();
    for (; it != it_end; it++) {
        uint64_t cards_hash = it->first;
        uint64_t hash = ranks_hash(cards_hash);
        if (is_flush(cards_hash)) flush_map[cards_hash] = it->second;
        else {
            /*if (other_map.count(hash) && other_map[hash] != it->second) {
                printf("%zx,%zx:%d != %d\n", cards_hash, hash, it->second, other_map[hash]);
            }*/
            other_map[hash] = it->second;
        }
    }
}
```