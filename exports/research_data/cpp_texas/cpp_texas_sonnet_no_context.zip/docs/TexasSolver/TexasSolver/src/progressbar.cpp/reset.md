`reset`: The function of `reset` is to reinitialize the progress bar to its starting state.

**Code Description**: This method resets the internal state of a progress bar object. It sets the `progress` variable to 0, indicating the progress bar is back at the beginning. The `update_is_called` flag is set to false, likely used to track whether an update method has been called since the last reset. The `last_perc` variable, probably representing the last displayed percentage, is also set to 0. After resetting these values, the function returns without any further action.\\
## Code: 
```
void progressbar::reset() {
    progress = 0,
            update_is_called = false;
    last_perc = 0;
    return;
}
```