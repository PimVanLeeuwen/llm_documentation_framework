`gameRound2int`: The function of `gameRound2int` is to convert a GameRound enum value to its corresponding integer representation.

**Code Description**: This method is a member function of the GameTreeNode class. It takes a GameRound enum as input and returns an integer based on the game round. The function uses a series of if-else statements to check the input GameRound value and return the appropriate integer:

- For GameRound::PREFLOP, it returns 0
- For GameRound::FLOP, it returns 1
- For GameRound::TURN, it returns 2
- For GameRound::RIVER, it returns 3

If the input doesn't match any of these cases, the function throws a runtime_error with the message "round not found". This error handling ensures that only valid GameRound values are processed.\\
## Code: 
```
int GameTreeNode::gameRound2int(GameTreeNode::GameRound gameRound) {
    if(gameRound == GameRound::PREFLOP) {
        return 0;
    }else if(gameRound == GameRound::FLOP){
        return 1;
    } else if(gameRound == GameRound::TURN) {
        return 2;
    } else if(gameRound == GameRound::RIVER) {
        return 3;
    }
    throw runtime_error("round not found");
}
```