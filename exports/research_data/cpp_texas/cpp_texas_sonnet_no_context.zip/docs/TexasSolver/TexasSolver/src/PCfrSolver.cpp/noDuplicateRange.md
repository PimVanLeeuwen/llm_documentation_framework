`noDuplicateRange`: The function of `noDuplicateRange` is to filter a range of private cards, removing any that conflict with the given board cards.

**Code Description**: This function takes two parameters: a vector of `PrivateCards` representing a range of private hands, and a `uint64_t` representing the board cards. It returns a new vector of `PrivateCards` containing only the hands that don't share any cards with the board.

The function first creates an empty vector `range_array` to store the filtered hands and an unordered map `rangekv` to check for duplicates. It then iterates through each `PrivateCards` object in the input range.

For each hand, it checks if its hash code already exists in `rangekv`. If it does, the function throws a runtime error with a message indicating a duplicate key. Otherwise, it adds the hash code to `rangekv`.

Next, it converts the hand to a `uint64_t` representation using `Card::boardInts2long`. It then checks if this hand has any cards in common with the board using `Card::boardsHasIntercept`. If there's no intersection, the hand is added to `range_array`.

Finally, the function returns `range_array`, which contains all the private hands from the input range that don't conflict with the board cards and have no duplicates.\\
## Code: 
```
vector<PrivateCards>
PCfrSolver::noDuplicateRange(const vector<PrivateCards> &private_range, uint64_t board_long) {
    vector<PrivateCards> range_array;
    unordered_map<int,bool> rangekv;
    for(PrivateCards one_range:private_range){
        if(rangekv.find(one_range.hashCode()) != rangekv.end())
            throw runtime_error(tfm::format("duplicated key %s",one_range.toString()));
        rangekv[one_range.hashCode()] = true;
        uint64_t hand_long = Card::boardInts2long(one_range.get_hands());
        if(!Card::boardsHasIntercept(hand_long,board_long)){
            range_array.push_back(one_range);
        }
    }
    return range_array;

}
```