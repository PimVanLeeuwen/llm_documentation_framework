`clear_board`: The function of `clear_board` is to reset all elements in the `grids_float` 2D array to zero.

**Code Description**: This method iterates through a 2D array called `grids_float` using nested loops. The outer loop runs from 0 to the size of `suitlist`, while the inner loop runs from 0 to the size of `ranklist`. For each element in the array, it sets the value to 0, effectively clearing or resetting the entire board represented by `grids_float`.\\
## Code: 
```
void BoardSelectorTableModel::clear_board(){
    for(int i = 0;i < this->suitlist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_float[i][j] = 0;
        }
    }
}
```