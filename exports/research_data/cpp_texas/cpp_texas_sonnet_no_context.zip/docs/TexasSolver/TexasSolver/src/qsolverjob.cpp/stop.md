`stop`: The function of `stop` is to halt the execution of a solver based on the current game mode.

**Code Description**: This method is part of the `QSolverJob` class and is responsible for stopping the solver's operation. It first logs a debug message indicating an attempt to stop the solver. Then, it checks the current mode of the solver (stored in the `mode` member variable) and calls the appropriate `stop()` method on the corresponding solver object. If the mode is `Mode::HOLDEM`, it stops the `ps_holdem` solver. If the mode is `Mode::SHORTDECK`, it stops the `ps_shortdeck` solver. This design allows for different solvers to be used depending on the poker variant being analyzed.\\
## Code: 
```
void QSolverJob::stop(){
    qDebug().noquote() << tr("Trying to stop solver.");
    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.stop();
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.stop();
    }
}
```