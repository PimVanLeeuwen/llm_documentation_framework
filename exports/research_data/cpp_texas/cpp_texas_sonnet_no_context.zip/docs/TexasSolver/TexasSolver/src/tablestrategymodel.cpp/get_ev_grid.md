`get_ev_grid`: The function of `get_ev_grid` is to calculate and return a vector of expected values for a specific cell in a strategy table.

**Code Description**: This method is part of the TableStrategyModel class and takes two integer parameters, i and j, which represent the coordinates of a cell in the strategy table. It returns a vector of float values.

The function first checks if the treeItem is null or if current_evs is empty. If either condition is true, it returns an empty vector.

It then retrieves the number of strategies for the given cell and the corresponding GameTreeNode. If the node is an ActionNode, it proceeds with the calculation.

The function iterates through the strategy indices stored in ui_strategy_table[i][j]. For each index pair, it retrieves the corresponding strategy and expected value vectors from current_strategy and current_evs.

It performs a consistency check to ensure that the sizes of the game actions, strategy, and expected value vectors match. If they don't, it throws a runtime error.

The function then calculates the weighted average of expected values for each strategy, multiplying each action's probability by its expected value and summing the results. This calculated value is added to the return vector.

If the node is not an ActionNode, or if any errors occur during the process, the function returns an empty vector.

Overall, this function computes the expected values for a specific cell in the strategy table, considering the current strategies and their corresponding expected values.\\
## Code: 
```
const vector<float> TableStrategyModel::get_ev_grid(int i,int j)const{
    vector<float> ret_evs;
    if(this->treeItem == NULL || this->current_evs.empty())return ret_evs;

    int strategy_number = this->ui_strategy_table[i][j].size();

    shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();

    if(node->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);

        vector<GameActions>& gameActions = actionNode->getActions();

//        vector<float> strategies;

//        if(this->ui_strategy_table[i][j].size() > 0){
//            strategies = vector<float>(gameActions.size());
//            std::fill(strategies.begin(), strategies.end(), 0.);
//        }
        for(std::pair<int,int> index:this->ui_strategy_table[i][j]){
            int index1 = index.first;
            int index2 = index.second;
            const vector<float>& one_strategy = this->current_strategy[index1][index2];
            const vector<float>& one_ev = this->current_evs[index1][index2];
            if(one_ev.size() != one_strategy.size()) return vector<float>();

            if(gameActions.size() != one_strategy.size()){
                cout << "index: " << index1 << " " << index2 << endl;
                cout << "i,j: " << i << " " << j << endl;
                cout << "size not match between gameAction and stragegy: " << gameActions.size() << " " << one_strategy.size() << endl;
                throw runtime_error("size not match between gameAction and stragegy");
            }
            float one_ev_float = 0;
            for(std::size_t indi = 0;indi < one_strategy.size();indi ++){
                one_ev_float += one_strategy[indi] * one_ev[indi];
            }
            ret_evs.push_back(one_ev_float);
        }

        return ret_evs;
    }else{
        return ret_evs;
    }
}
```