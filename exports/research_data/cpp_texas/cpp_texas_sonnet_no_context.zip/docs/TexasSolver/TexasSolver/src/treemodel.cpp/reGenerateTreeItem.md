`reGenerateTreeItem`: The function of `reGenerateTreeItem` is to recursively regenerate the tree structure for a given game round.

**Code Description**: This method takes two parameters: a `GameRound` enum and a pointer to a `TreeItem`. It processes the tree node based on its type (ACTION or CHANCE). For ACTION nodes, it iterates through the children, creates new TreeItems for each child, and recursively calls itself if the child's round matches the given round. For CHANCE nodes, it creates a single child TreeItem and recursively processes it. The function uses dynamic casting to handle different node types and manages the tree structure by inserting child nodes. It effectively rebuilds a portion of the game tree for a specific round, maintaining the hierarchical structure of the game state.\\
## Code: 
```
void TreeModel::reGenerateTreeItem(GameTreeNode::GameRound round,TreeItem* node_to_process){
    const shared_ptr<GameTreeNode> gameTreeNode = node_to_process->m_treedata.lock();
    if(gameTreeNode->getType() == GameTreeNode::GameTreeNodeType::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(gameTreeNode);
        vector<shared_ptr<GameTreeNode>>& childrens = actionNode->getChildrens();
        for(shared_ptr<GameTreeNode> one_child:childrens){
            TreeItem * child_node = new TreeItem(one_child,node_to_process);
            node_to_process->insertChild(child_node);
            if(one_child->getRound() != round){
                continue;
            }
            this->reGenerateTreeItem(round,child_node);
        }
    }
    else if(gameTreeNode->getType() == GameTreeNode::GameTreeNodeType::CHANCE){
        shared_ptr<ChanceNode> chanceNode = dynamic_pointer_cast<ChanceNode>(gameTreeNode);
        TreeItem * child_node = new TreeItem(chanceNode->getChildren(),node_to_process);
        node_to_process->insertChild(child_node);
        this->reGenerateTreeItem(round,child_node);
    }
}
```