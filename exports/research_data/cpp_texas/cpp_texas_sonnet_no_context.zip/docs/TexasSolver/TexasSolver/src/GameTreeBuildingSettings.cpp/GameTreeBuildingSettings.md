`GameTreeBuildingSettings`: The function of `GameTreeBuildingSettings` is to initialize a game tree building configuration with specific settings for different streets and positions in a poker game.

**Code Description**: This is a constructor for the `GameTreeBuildingSettings` class. It takes six parameters, each of type `StreetSetting`, representing the settings for different streets (flop, turn, river) and positions (in position - IP, out of position - OOP) in a poker game. The constructor uses an initialization list to set the corresponding member variables of the class with the provided arguments. This allows for customized configuration of game tree building for various stages and positions in poker strategy analysis or simulation.\\
## Code: 
```
GameTreeBuildingSettings::GameTreeBuildingSettings(
        StreetSetting flop_ip,
        StreetSetting turn_ip,
        StreetSetting river_ip,
        StreetSetting flop_oop,
        StreetSetting turn_oop,
        StreetSetting river_oop):flop_ip(flop_ip),turn_ip(turn_ip),river_ip(river_ip),flop_oop(flop_oop),turn_oop(turn_oop),river_oop(river_oop) {
}
```