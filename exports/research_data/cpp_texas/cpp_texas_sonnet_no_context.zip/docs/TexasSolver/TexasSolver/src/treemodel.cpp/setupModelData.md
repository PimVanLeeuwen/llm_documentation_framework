`setupModelData`: The function of `setupModelData` is to initialize and populate a tree model structure based on a poker solver's game tree.

**Code Description**: This method sets up the data for a tree model representation of a poker game. It first determines which poker solver to use (Holdem or Shortdeck) based on the mode of the `qSolverJob`. If the mode is invalid, it throws a runtime error.

The function then checks if the game tree and its root exist in the solver. If not, it returns early. Otherwise, it retrieves the game round from the root node.

The method creates a root item for the tree model using the game tree's root node. It then creates a child item and inserts it into the root item. Finally, it calls a recursive function `reGenerateTreeItem` to populate the rest of the tree structure based on the current game round and the newly created child item.

This setup allows for a hierarchical representation of the poker game states, likely for display or further analysis in a user interface or other parts of the application.\\
## Code: 
```
void TreeModel::setupModelData()
{
    PokerSolver * solver;
    if(this->qSolverJob->mode == QSolverJob::Mode::HOLDEM){
        solver = &(this->qSolverJob->ps_holdem);
    }else if(this->qSolverJob->mode == QSolverJob::Mode::SHORTDECK){
        solver = &(this->qSolverJob->ps_shortdeck);
    }else{
        throw runtime_error("holdem mode incorrect");
    }

    if(solver->get_game_tree() == nullptr || solver->get_game_tree()->getRoot() == nullptr){
        return;
    }

    GameTreeNode::GameRound round =	solver->get_game_tree()->getRoot()->getRound();

    this->rootItem = new TreeItem(solver->get_game_tree()->getRoot());
    TreeItem* ti = new TreeItem(solver->get_game_tree()->getRoot(),this->rootItem);
    rootItem->insertChild(ti);
    this->reGenerateTreeItem(round,ti);
}
```