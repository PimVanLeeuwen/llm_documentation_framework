`toString`: The function of `toString` is to return an empty string.

**Code Description**: The `toString` method of the `GameTreeNode` class is currently implemented to return an empty string. The entire body of the function contains commented-out code that appears to be intended for generating a string representation of a game tree node. However, since this code is commented out, it is not executed. The function simply returns an empty string ("") when called. The commented code suggests that the original intention may have been to provide a more detailed string representation of the node's position in the game tree, including information about its parent node and the action or chance event that led to this node. But in its current state, the function does not perform any of these operations.\\
## Code: 
```
string GameTreeNode::toString(){
    /*
    shared_ptr<GameTreeNode>parent_node = node->parent;
    string round;
    if (parent_node == nullptr) return tfm::format("%s begin",round);
    if(parent_node->getType() == GameTreeNodeType::ACTION){
        ActionNode action_node = (ActionNode)parent_node;
        for(int i = 0;i < action_node.getActions().size();i ++){
            if(action_node.getChildrens().get(i) == node){
                System.out.print(String.format("<- (player %s %s)",
                           action_node.getPlayer(),
                           action_node.getActions().get(i).toString()
                    ));
        }
        }
    }else if(parent_node->getType() == GameTreeNodeType::CHANCE){
        ChanceNode chance_node = (ChanceNode)parent_node;
        for(int i = 0;i < chance_node.getChildrens().size();i ++){
            if(chance_node.getChildrens().get(i) == node){
                System.out.print(String.format("<- (deal card %s)",
                       chance_node.getCards().get(i).toString()
            ));
        }
    }
    */
    return "";
}
```