`playerHands`: The function of `playerHands` is to return the private cards (hand) of a specified player.

**Code Description**: This method is part of the `PCfrSolver` class and takes an integer parameter `player` to identify which player's hand to return. It uses a simple conditional structure to determine the correct hand:

1. If `player` is 0, it returns `range1`, which presumably represents the first player's hand.
2. If `player` is 1, it returns `range2`, which likely represents the second player's hand.
3. If `player` is neither 0 nor 1, it throws a runtime error with the message "player not found".

The method returns a constant reference to a vector of `PrivateCards` objects, suggesting that `range1` and `range2` are member variables of the `PCfrSolver` class, each containing a collection of private cards for the respective players. The use of a constant reference ensures that the original data cannot be modified through this method call, providing both efficiency and data protection.\\
## Code: 
```
const vector<PrivateCards> &PCfrSolver::playerHands(int player) {
    if(player == 0){
        return range1;
    }else if (player == 1){
        return range2;
    }else{
        throw runtime_error("player not found");
    }
}
```