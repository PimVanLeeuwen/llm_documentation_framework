`ChanceNode`: The function of `ChanceNode` is to create a chance node in a game tree, representing a point where random events occur.

**Code Description**: This is a constructor for the `ChanceNode` class, which is derived from `GameTreeNode`. It initializes a chance node with specific properties:

1. It takes several parameters:
   - `children`: A shared pointer to a `GameTreeNode`, representing the child nodes.
   - `round`: The current game round, of type `GameTreeNode::GameRound`.
   - `pot`: A double value representing the current pot size.
   - `parent`: A shared pointer to the parent `GameTreeNode`.
   - `cards`: A vector of `Card` objects, representing the cards in play.
   - `donk`: A boolean flag, likely indicating a specific game state or action.

2. The constructor calls the base class constructor `GameTreeNode(round, pot, std::move(parent))` to initialize the inherited properties.

3. It initializes the `cards` member variable with the provided `cards` vector.

4. The `children` member is set to the provided `children` shared pointer.

5. The `donk` member is set to the provided `donk` boolean value.

This constructor sets up a chance node with its specific game state, including the current round, pot size, parent node, available cards, and child nodes. The `donk` flag is also set, which may represent a specific game condition or possible action.\\
## Code: 
```
ChanceNode::ChanceNode(const shared_ptr<GameTreeNode> children, GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent,
                       const vector<Card>& cards,bool donk): GameTreeNode(round,pot,std::move(parent)),cards(cards) {
    this->children = children;
    this->donk = donk;
}
```