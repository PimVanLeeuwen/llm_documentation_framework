`getcurrentStrategy`: The function of `getcurrentStrategy` is to calculate and return the current strategy probabilities for each action and private card combination.

**Code Description**: This method computes the current strategy probabilities based on the regret-matching principle used in Counterfactual Regret Minimization (CFR) algorithms. It returns a vector of float values representing the probabilities.

The function first checks if the `r_plus_sum` vector is empty. If it is, it initializes the `retval` vector with uniform probabilities (1.0 / action_number) for all actions.

If `r_plus_sum` is not empty, it iterates through all possible combinations of actions and private cards. For each combination, it calculates the probability by dividing the corresponding `r_plus` value by the `r_plus_sum` for that private card. If the `r_plus_sum` for a particular private card is zero, it assigns a uniform probability.

The function includes a check for NaN (Not a Number) values in the calculated probabilities, throwing a runtime error if one is found. There's also commented-out code for additional error checking and debugging, which is not currently in use.

The calculated probabilities are stored in the `retval` vector, which is then returned as the current strategy.\\
## Code: 
```
const vector<float> CfrPlusTrainable::getcurrentStrategy() {
    if(this->r_plus_sum.empty()){
        fill(retval.begin(),retval.end(),1.0 / this->action_number);
    }else {
        for (int action_id = 0; action_id < action_number; action_id++) {
            for (int private_id = 0; private_id < this->card_number; private_id++) {
                int index = action_id * this->card_number + private_id;
                if(this->r_plus_sum[private_id] != 0) {
                    retval[index] = this->r_plus[index] / this->r_plus_sum[private_id];
                }else{
                    retval[index] = 1.0 / this->action_number;
                }
                if(this->r_plus[index] != this->r_plus[index]) throw runtime_error("nan found");
                /*
                if(this.r_plus_sum[private_id] == 0)
                {
                    System.out.println("Exception regret status, r_plus_sum == 0:");
                    System.out.println(String.format("r plus length %s , card num %s",r_plus.length,this.card_number));
                    for(int i = index % this.card_number;i < this.r_plus.length;i += this.card_number){
                        System.out.print(String.format("%s:%s ",i,this.r_plus[i]));
                        if(i == index){
                            System.out.print("[current]");
                        }
                    }
                    System.out.println();
                    System.out.println();
                    throw new RuntimeException();
                }
                 */
            }
        }
    }
    return retval;
}
```