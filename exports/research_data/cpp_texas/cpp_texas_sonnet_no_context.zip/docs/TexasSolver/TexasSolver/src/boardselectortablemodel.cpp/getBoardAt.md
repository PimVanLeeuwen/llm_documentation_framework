`getBoardAt`: The function of `getBoardAt` is to retrieve a float value from a 2D grid at the specified row and column indices.

**Code Description**: This method is part of the `BoardSelectorTableModel` class and takes two integer parameters, `i` and `j`, representing row and column indices respectively. It first checks if the provided indices are within valid ranges by comparing them against the size of `this->ranklist`. If either index is out of bounds, it logs a debug message with the invalid index and returns 0. If both indices are valid, it returns the float value stored at the specified position in the `this->grids_float` 2D array. The method uses Qt's `qDebug()` for logging error messages.\\
## Code: 
```
float BoardSelectorTableModel::getBoardAt(int i, int j){
    if(i < 0 || i >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::getBoardAt i not valid: " << i;
        return 0;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::getBoardAt j not valid: " << j;
        return 0;
    }
    else{
        return this->grids_float[i][j];
    }
}
```