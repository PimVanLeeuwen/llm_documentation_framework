`estimate_tree_memory`: The function of `estimate_tree_memory` is to estimate the memory required for a game tree based on the given ranges and board.

**Code Description**: This method is part of the `QSolverJob` class and is responsible for estimating the memory needed for a game tree in poker simulations. It takes three QString parameters: `range1`, `range2`, and `board`. The function first logs a debug message indicating that it's estimating tree memory. Then, it checks the `mode` of the current object. If the mode is `Mode::HOLDEM`, it calls the `estimate_tree_memory` method of the `ps_holdem` object. If the mode is `Mode::SHORTDECK`, it calls the same method on the `ps_shortdeck` object. Both of these calls pass along the input parameters. If neither mode matches, the function returns 0. The return type is `long long`, suggesting it returns a large integer value representing the estimated memory in bytes or another unit.\\
## Code: 
```
long long QSolverJob::estimate_tree_memory(QString range1,QString range2,QString board){
    qDebug().noquote() << tr("Estimating tree memory..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        return ps_holdem.estimate_tree_memory(range1,range2,board);
    }else if(this->mode == Mode::SHORTDECK){
        return ps_shortdeck.estimate_tree_memory(range1,range2,board);
    }
    return 0;
}
```