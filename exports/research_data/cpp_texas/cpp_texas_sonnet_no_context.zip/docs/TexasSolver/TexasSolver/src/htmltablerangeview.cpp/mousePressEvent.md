`mousePressEvent`: The function of `mousePressEvent` is to handle mouse press events on the HtmlTableRangeView widget.

**Code Description**: This method overrides the `mousePressEvent` of the parent class `HtmlTableView`. When a mouse press event occurs, it first calls the parent class implementation to ensure default behavior is maintained. Then, it determines the table cell (represented by row and column indices) where the mouse press occurred using the `indexAt` function with the event's position. Finally, it emits a custom signal `view_item_pressed` with the row and column indices of the pressed cell, allowing other parts of the application to respond to this specific user interaction.\\
## Code: 
```
void HtmlTableRangeView::mousePressEvent(QMouseEvent *event) {
    HtmlTableView::mousePressEvent(event);
    QModelIndex index = indexAt(event->pos());
    emit view_item_pressed(index.row(),index.column());
}
```