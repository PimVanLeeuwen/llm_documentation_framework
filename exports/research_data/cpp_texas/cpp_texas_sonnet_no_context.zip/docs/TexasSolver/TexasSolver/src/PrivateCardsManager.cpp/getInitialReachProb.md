`getInitialReachProb`: The function of `getInitialReachProb` is to calculate and return initial reach probabilities for a player's private cards based on the initial board state.

**Code Description**: This method takes two parameters: an integer `player` representing the player's index, and a `uint64_t initialboard` representing the initial board state. It returns a vector of float values, which are the initial reach probabilities for each of the player's possible private card combinations.

The function first determines the number of possible private card combinations for the player. It then creates a vector `probs` of the same length to store the probabilities.

For each private card combination:
1. It checks if there's an intersection between the initial board and the private cards using `Card::boardsHasIntercept`.
2. If there's an intersection (meaning the private cards conflict with the board), the probability is set to 0.
3. If there's no intersection, the probability is set to the weight of that private card combination.

The weights are presumably pre-calculated values stored in the `PrivateCards` objects.

This function is likely part of a poker game simulation or analysis tool, where it's important to calculate the likelihood of players having certain private cards given the known board state.\\
## Code: 
```
vector<float> PrivateCardsManager::getInitialReachProb(int player, uint64_t initialboard) {
    int cards_len =  this->private_cards[player].size();
    vector<float> probs = vector<float>(cards_len);
    for(int i = 0;i < cards_len;i ++){
        PrivateCards pc = this->private_cards[player][i];
        if(Card::boardsHasIntercept(initialboard,Card::boardInts2long(pc.get_hands()))) {
            probs[i] = 0;
        }else{
            probs[i] = this->private_cards[player][i].weight;
        }
    }
    return probs;
}
```