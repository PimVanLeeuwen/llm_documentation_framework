`RiverCombs`: The function of `RiverCombs` is to initialize a RiverCombs object with given parameters.

**Code Description**: This is a constructor for the RiverCombs class. It takes four parameters: a vector of integers representing the board, a PrivateCards object, an integer rank, and an integer reach_prob_index. The constructor initializes the object's member variables with these input parameters. Specifically, it sets the 'board' member to the input board vector, the 'rank' member to the input rank value, the 'private_cards' member to the input PrivateCards object, and the 'reach_prob_index' member to the input reach_prob_index value. This constructor allows for the creation of a RiverCombs object with specific initial values, likely used in poker-related calculations or simulations.\\
## Code: 
```
RiverCombs::RiverCombs(vector<int> board, PrivateCards private_cards, int rank, int reach_prob_index) {
    this->board = board;
    this->rank = rank;
    this->private_cards = private_cards;
    this->reach_prob_index = reach_prob_index;
}
```