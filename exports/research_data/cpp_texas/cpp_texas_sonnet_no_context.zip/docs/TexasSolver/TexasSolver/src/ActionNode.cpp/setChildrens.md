`setChildrens`: The function of `setChildrens` is to set the children nodes of an ActionNode object.

**Code Description**: This method is a member function of the ActionNode class. It takes a constant reference to a vector of shared pointers to GameTreeNode objects as its parameter. The function assigns this vector to the 'childrens' member variable of the ActionNode class. By using shared pointers, it ensures proper memory management for the child nodes. The method allows for updating or replacing the entire set of child nodes for an ActionNode in a single operation.\\
## Code: 
```
void ActionNode::setChildrens(const vector<shared_ptr<GameTreeNode>> &childrens) {
    ActionNode::childrens = childrens;
}
```