`get_payoffs`: The function of `get_payoffs` is to return the appropriate payoffs based on the showdown result and winner.

**Code Description**: This method takes two parameters: a `ShowDownResult` enum value `result` and an integer `winner`. It returns a vector of doubles representing payoffs.

The function first checks if the result is not a tie (`ShowDownResult::NOTTIE`). If so, it ensures the winner is not -1 (throwing an exception if it is) and returns the payoffs for the winning player from the `player_payoffs` array.

If the result is a tie, it verifies that the winner is -1 (throwing an exception if it's not) and returns the `tie_payoffs` vector.

The function uses error handling to ensure the input parameters are consistent with the showdown result, throwing runtime errors if inconsistencies are detected.\\
## Code: 
```
vector<double> ShowdownNode::get_payoffs(ShowdownNode::ShowDownResult result, int winner) {
    if(result == ShowDownResult::NOTTIE){
        if(winner == -1) throw runtime_error("winner == -1 in tie");
        vector<double> retval = player_payoffs[winner];
        return retval;
    }else{
        // if the showdown is a tie
        if(winner != -1) throw runtime_error("winner != -1 in not tie");
        return this->tie_payoffs;
    }
}
```