`getActions`: The function of `getActions` is to return a reference to the vector of GameActions stored in the ActionNode object.

**Code Description**: This method is a simple getter function that provides access to the private member variable `actions` of the ActionNode class. It returns a reference to a vector of GameActions, allowing the caller to read or modify the actions associated with this ActionNode without creating a copy of the vector. The use of a reference return type (`vector<GameActions>&`) ensures efficient access to the original data.\\
## Code: 
```
vector<GameActions>& ActionNode::getActions() {
    return this->actions;
}
```