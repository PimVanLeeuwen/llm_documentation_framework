`paint`: The function of `paint` is to render a custom item in a view with formatted HTML text.

**Code Description**: This method overrides the default paint function for a custom item delegate in Qt. It takes a QPainter, style options, and a model index as parameters. The function first initializes the style options and saves the painter's state. It then creates a QTextDocument to handle HTML-formatted text from the item's data. The original item is drawn using the widget's style, but with empty text. The painter is then translated to the item's position, and the HTML content is drawn within the item's rectangle. Finally, the painter's state is restored. This approach allows for rich text formatting within list or tree view items while maintaining the standard item appearance.\\
## Code: 
```
void WordItemDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);

    painter->save();

    QTextDocument doc;
    doc.setHtml(options.text);

    options.text = "";
    options.widget->style()->drawControl(QStyle::CE_ItemViewItem, &option, painter);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);

    painter->restore();
}
```