`getReachProbs`: The function of `getReachProbs` is to calculate and return the reach probabilities for each player's private cards.

**Code Description**: This method creates a 2D vector to store reach probabilities for each player. It iterates through all players, retrieves their private cards, and assigns the weight of each card combination as its reach probability. The function returns a vector of vectors, where each inner vector represents a player's reach probabilities for their possible private card combinations.\\
## Code: 
```
vector<vector<float>> PCfrSolver::getReachProbs() {
    vector<vector<float>> retval(this->player_number);
    for(int player = 0;player < this->player_number;player ++){
        vector<PrivateCards> player_cards = this->playerHands(player);
        vector<float> reach_prob(player_cards.size());
        for(std::size_t i = 0;i < player_cards.size();i ++){
            reach_prob[i] = player_cards[i].weight;
        }
        retval[player] = reach_prob;
    }
    return retval;
}
```