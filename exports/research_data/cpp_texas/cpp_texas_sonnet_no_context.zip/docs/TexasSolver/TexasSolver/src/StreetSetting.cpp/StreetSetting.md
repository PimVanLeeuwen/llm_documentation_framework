`StreetSetting`: The function of `StreetSetting` is to initialize a street setting object with specified betting parameters.

**Code Description**: This is a constructor for the `StreetSetting` class. It takes four parameters: three vectors of floats (`bet_sizes`, `raise_sizes`, and `donk_sizes`) and a boolean `allin`. The constructor initializes the object's member variables with these input parameters. It assigns the input vectors to the corresponding member variables of the same name, and sets the `allin` member variable to the input boolean value. This constructor allows for the creation of a `StreetSetting` object with customized betting options for different actions in a poker game, including betting, raising, and donk betting, as well as an all-in option.\\
## Code: 
```
StreetSetting::StreetSetting(vector<float> bet_sizes, vector<float> raise_sizes, vector<float> donk_sizes,
                             bool allin) {
    this->bet_sizes = bet_sizes;
    this->raise_sizes = raise_sizes;
    this->donk_sizes = donk_sizes;
    this->allin = allin;
}
```