`DiscountedCfrTrainable`: The function of `DiscountedCfrTrainable` is to initialize a trainable object for Discounted Counterfactual Regret Minimization (CFR) in game theory.

**Code Description**: This constructor initializes a `DiscountedCfrTrainable` object with given private cards and an action node. It sets up data structures for storing expected values, regrets, and cumulative regrets for each action and private card combination. The constructor performs the following steps:

1. Stores the provided `privateCards` pointer and `actionNode` reference.
2. Calculates the number of actions and private cards.
3. Initializes vectors for expected values (evs), positive regrets (r_plus), sum of positive regrets (r_plus_sum), and cumulative positive regrets (cum_r_plus).
4. All vectors are initialized with zeros, except for cum_r_plus_sum which is left uninitialized.

The size of most vectors is the product of action_number and card_number, allowing for separate values for each action-card combination. This setup enables the implementation of the Discounted CFR algorithm for game-theoretic analysis and strategy computation.\\
## Code: 
```
DiscountedCfrTrainable::DiscountedCfrTrainable(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();

    this->evs = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus_sum = vector<float>(this->card_number,0.0);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number,0.0);
    //this->cum_r_plus_sum = vector<float>(this->card_number);
}
```