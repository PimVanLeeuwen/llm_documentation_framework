`toString`: The function of `toString` is to convert two private cards into a string representation.

**Code Description**: This method belongs to the `PrivateCards` class and returns a string representation of two cards. It compares the values of `card1` and `card2`, then uses the `Card::intCard2Str` method to convert each card from its integer representation to a string. The cards are ordered so that the higher-valued card is placed first in the resulting string. This ensures a consistent string representation regardless of the original order of the cards.\\
## Code: 
```
string PrivateCards::toString() {
    if (card1 > card2) {
        return Card::intCard2Str(card1) + Card::intCard2Str(card2);
    }else{
        return Card::intCard2Str(card2) + Card::intCard2Str(card1);
    }
}
```