`build_game_tree`: The function of `build_game_tree` is to create and initialize a game tree for a poker game simulation.

**Code Description**: This method is part of the PokerSolver class and is responsible for constructing a new GameTree object. It takes several parameters that define the current state and rules of the poker game:

1. oop_commit and ip_commit: The amount of money committed by out-of-position and in-position players.
2. current_round: The current round of the game.
3. raise_limit: The maximum number of raises allowed.
4. small_blind and big_blind: The small and big blind amounts.
5. stack: The total amount of chips each player has.
6. buildingSettings: A GameTreeBuildingSettings object containing additional configuration.
7. allin_threshold: The threshold for considering a bet as an all-in move.

The function creates a shared pointer to a new GameTree object using these parameters. This GameTree object likely represents the structure of possible actions and outcomes in the poker game. After creation, the function assigns this new game tree to the game_tree member variable of the PokerSolver instance, effectively updating the solver's current game state.\\
## Code: 
```
void PokerSolver::build_game_tree(
        float oop_commit,
        float ip_commit,
        int current_round,
        int raise_limit,
        float small_blind,
        float big_blind,
        float stack,
        GameTreeBuildingSettings buildingSettings,
        float allin_threshold
){
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(
            this->deck,
            oop_commit,
            ip_commit,
            current_round,
            raise_limit,
            small_blind,
            big_blind,
            stack,
            buildingSettings,
            allin_threshold
    );
    this->game_tree = game_tree;
}
```