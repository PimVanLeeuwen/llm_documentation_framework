`build_tree`: The function of `build_tree` is to construct a game tree for poker variants (Texas Hold'em or Short Deck).

**Code Description**: This method is part of the QSolverJob class and is responsible for building a game tree based on the selected poker variant. It first logs a debug message indicating the start of the tree-building process. The function then checks the game mode (HOLDEM or SHORTDECK) and calls the appropriate method to build the game tree using the specified parameters. These parameters include out-of-position and in-position commitments, current round, raise limit, blinds, stack size, game tree builder settings, and all-in threshold. After the tree is built, it logs another debug message to indicate completion. The method uses Qt's debugging and internationalization features for logging messages.\\
## Code: 
```
void QSolverJob::build_tree(){
    qDebug().noquote() << tr("building tree..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        ps_holdem.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }else if(this->mode == Mode::SHORTDECK){
        ps_shortdeck.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }
    qDebug().noquote() << tr("build tree finished");//.toStdString() << endl;
}
```