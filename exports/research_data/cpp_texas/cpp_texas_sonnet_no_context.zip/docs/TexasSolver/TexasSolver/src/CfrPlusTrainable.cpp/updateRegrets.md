`updateRegrets`: The function of `updateRegrets` is to update regret values and cumulative strategies in a Counterfactual Regret Minimization (CFR+) algorithm implementation.

**Code Description**: This method takes three parameters: a vector of regrets, the current iteration number, and a vector of reach probabilities. It first updates the internal regrets vector and checks if its size matches the expected length (action_number * card_number). The function then initializes r_plus_sum and cum_r_plus_sum vectors to zero.

The core of the function is a nested loop that iterates over all actions and private cards. For each combination, it:

1. Calculates the index in the regrets vector.
2. Updates the R+ value by taking the maximum of 0 and the sum of the current regret and previous R+ value.
3. Accumulates the R+ values for each private card.
4. Updates the cumulative R+ strategy by adding the product of the current R+ value and the iteration number.
5. Accumulates the cumulative R+ strategy for each private card.

This process implements the CFR+ algorithm's core mechanics, which involve maintaining positive regrets and using iteration weighting to update cumulative strategies. The function is crucial for the convergence properties of the CFR+ algorithm in game-theoretic scenarios.\\
## Code: 
```
void CfrPlusTrainable::updateRegrets(const vector<float>& regrets, int iteration_number, const vector<float>& reach_probs) {
    this->regrets = regrets;
    if(regrets.size() != this->action_number * this->card_number) throw runtime_error("length not match");

    //Arrays.fill(this.r_plus_sum,0);
    fill(r_plus_sum.begin(),r_plus_sum.end(),0);
    fill(cum_r_plus_sum.begin(),cum_r_plus_sum.end(),0);
    for (int action_id = 0;action_id < action_number;action_id ++) {
        for(int private_id = 0;private_id < this->card_number;private_id ++){
            int index = action_id * this->card_number + private_id;
            float one_reg = regrets[index];

            // 更新 R+
            this->r_plus[index] = max((float)0.0,one_reg + this->r_plus[index]);
            this->r_plus_sum[private_id] += this->r_plus[index];

            // 更新累计策略
            this->cum_r_plus[index] += this->r_plus[index] * iteration_number;
            this->cum_r_plus_sum[private_id] += this->cum_r_plus[index];
        }
    }
}
```