`getBoardText`: The function of `getBoardText` is to generate a comma-separated string of selected board values.

**Code Description**: This method iterates through a 2D grid represented by `grids_float` and `grids_string`. It checks each cell in the grid, and if the corresponding `grids_float` value is non-zero, it adds the `grids_string` value to the return string. The selected values are concatenated with commas between them. The method uses nested loops to traverse the grid, with the outer loop iterating over `suitlist` and the inner loop over `ranklist`. The resulting string is built incrementally, starting empty and adding each selected value. If it's the first value, it's added directly; otherwise, a comma is prepended before adding it to the existing string. Finally, the method returns the compiled string of selected board values.\\
## Code: 
```
QString BoardSelectorTableModel::getBoardText(){
    QString retval = "";
    for(int i = 0;i < this->suitlist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            if(this->grids_float[i][j] == 0)continue;
            QString one_board_str = QString("%1").arg(this->grids_string[i][j]);
            if(retval == ""){
                retval = one_board_str;
            }else{
                retval = retval + "," + one_board_str;
            }
        }
    }
    return retval;
}
```