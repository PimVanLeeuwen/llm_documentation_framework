`getRank`: The function of `getRank` is to determine the rank of a hand of cards.

**Code Description**: This method takes a vector of Card objects as input and converts it into a vector of integers representing the card values. It then calls another overloaded version of `getRank` with this integer vector to determine the rank of the hand. The method first creates a new vector `cards_int` with the same size as the input `cards` vector. It then iterates through each Card object in the input vector, calls the `getCardInt()` method on each Card to get its integer representation, and stores these values in the `cards_int` vector. Finally, it calls the overloaded `getRank` method with `cards_int` as the argument and returns the result, which is presumably the rank of the hand.\\
## Code: 
```
int Dic5Compairer::getRank(vector<Card> cards) {
    vector<int> cards_int(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_int[i] = cards[i].getCardInt();
    }
    return this->getRank(cards_int);
}
```