`onchanged`: The function of `onchanged` is to emit a signal indicating that horizontal header data has changed.

**Code Description**: This method is a member of the `RoughStrategyViewerModel` class. When called, it emits a `headerDataChanged` signal for the horizontal header, covering all columns from index 0 to the last column. The `emit` keyword suggests this is using Qt's signal-slot mechanism. The signal indicates that the header data has been modified, which could trigger updates in views or other components connected to this model.\\
## Code: 
```
void RoughStrategyViewerModel::onchanged(){
    emit headerDataChanged(Qt::Horizontal, 0 , columnCount());
}
```