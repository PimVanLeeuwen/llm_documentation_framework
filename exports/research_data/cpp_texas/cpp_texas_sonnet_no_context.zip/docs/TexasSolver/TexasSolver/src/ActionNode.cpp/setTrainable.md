`setTrainable`: The function of `setTrainable` is to set the trainable objects and player private cards for an ActionNode.

**Code Description**: This method is a member function of the ActionNode class. It takes two parameters: a vector of shared pointers to Trainable objects and a pointer to a vector of PrivateCards. The function assigns these parameters to the corresponding member variables of the ActionNode instance. Specifically, it sets the 'trainables' member variable to the provided vector of trainable objects and the 'player_privates' member variable to the provided pointer to player private cards. This allows the ActionNode to store and access these important pieces of information for further processing or decision-making within the node.\\
## Code: 
```
void ActionNode::setTrainable(vector<shared_ptr<Trainable>> trainables,vector<PrivateCards>* player_privates) {
    this->trainables = trainables;
    this->player_privates = player_privates;
}
```