`GameTreeNode`: The function of `GameTreeNode` is to initialize a new game tree node with specified round, pot, and parent node.

**Code Description**: This is a constructor for the `GameTreeNode` class. It takes three parameters: `round` of type `GameTreeNode::GameRound`, `pot` of type `double`, and `parent` which is a `shared_ptr` to another `GameTreeNode`. The constructor initializes the member variables of the new `GameTreeNode` object. It sets the `round` member to the provided `round` parameter, the `pot` member to the given `pot` value, and moves the `parent` shared pointer to the `parent` member of the object. The use of `std::move` for the parent pointer suggests efficient transfer of ownership of the shared pointer.\\
## Code: 
```
GameTreeNode::GameTreeNode(GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent) {
    this->round = round;
    this->pot = pot;
    this->parent = std::move(parent);
}
```