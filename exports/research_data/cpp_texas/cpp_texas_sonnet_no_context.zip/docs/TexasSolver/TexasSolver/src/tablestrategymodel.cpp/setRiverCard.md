`setRiverCard`: The function of `setRiverCard` is to set the river card in a TableStrategyModel object.

**Code Description**: This method is a member function of the TableStrategyModel class. It takes a single parameter 'river_card' of type Card and assigns it to the 'river_card' member variable of the current object (referred to by 'this'). The function is void, meaning it doesn't return any value. It's likely used to update the state of the TableStrategyModel object with a new river card in a poker game context.\\
## Code: 
```
void TableStrategyModel::setRiverCard(Card river_card){
    this->river_card = river_card;
}
```