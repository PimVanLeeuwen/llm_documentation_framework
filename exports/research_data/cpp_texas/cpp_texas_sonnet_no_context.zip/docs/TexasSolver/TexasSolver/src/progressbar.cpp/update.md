`update`: The function of `update` is to update and display a progress bar.

**Code Description**: This method updates a progress bar display in the console. It calculates the current progress percentage based on the number of cycles completed. If the percentage has increased, it updates the display accordingly. For every 1% increase, it updates the percentage number. Every 2% increase, it updates the visual bar representation if enabled. The bar consists of 50 characters, with 'done' characters replacing 'todo' characters as progress increases. The function uses backspace characters to erase and redraw parts of the display for a smooth update effect. It handles different formatting for percentages below 10, between 10 and 99, and at 100. The function also includes error checking for uninitialized cycle count and handles the first call to the function differently, initializing the display. The progress is tracked using the 'progress' variable, which is incremented with each call to the function.\\
## Code: 
```
void progressbar::update() {
    return;
    if (n_cycles == 0) throw std::runtime_error(
                "progressbar::update: number of cycles not set");

    if (!update_is_called) {
        if (do_show_bar == true) {
            std::cout << opening_bracket_char;
            for (int _ = 0; _ < 50; _++) std::cout << todo_char;
            std::cout << closing_bracket_char << " 0%";
        }
        else std::cout << "0%";
    }
    update_is_called = true;

    int perc = 0;

    // compute percentage, if did not change, do nothing and return
    perc = progress*100./(n_cycles-1);
    if (perc < last_perc) return;

    // update percentage each unit
    if (perc == last_perc + 1) {
        // erase the correct  number of characters
        if      (perc <= 10)                std::cout << "\b\b"   << perc << '%';
        else if (perc  > 10 && perc < 100) std::cout << "\b\b\b" << perc << '%';
        else if (perc == 100)               std::cout << "\b\b\b" << perc << '%';
    }
    if (do_show_bar == true) {
        // update bar every ten units
        if (perc % 2 == 0) {
            // erase closing bracket
            std::cout << std::string(closing_bracket_char.size(), '\b');
            // erase trailing percentage characters
            if      (perc  < 10)               std::cout << "\b\b\b";
            else if (perc >= 10 && perc < 100) std::cout << "\b\b\b\b";
            else if (perc == 100)              std::cout << "\b\b\b\b\b";

            // erase 'todo_char'
            for (int j = 0; j < 50-(perc-1)/2; ++j) {
                std::cout << std::string(todo_char.size(), '\b');
            }

            // add one additional 'done_char'
            if (perc == 0) std::cout << todo_char;
            else           std::cout << done_char;

            // refill with 'todo_char'
            for (int j = 0; j < 50-(perc-1)/2-1; ++j) std::cout << todo_char;

            // readd trailing percentage characters
            std::cout << closing_bracket_char << ' ' << perc << '%';
        }
    }
    last_perc = perc;
    ++progress;
    std::cout << std::flush;

    return;
}
```