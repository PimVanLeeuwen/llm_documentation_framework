`buildChance`: The function of `buildChance` is to construct the game tree for a chance node in a poker game simulation.

**Code Description**: This method builds the game tree structure starting from a given chance node. It handles different scenarios based on the current game state, represented by the `Rule` object. The function creates appropriate child nodes depending on the game round and betting situation.

If both players have committed their entire stack, the function creates either a ShowdownNode (for the river round) or a new ChanceNode (for earlier rounds). The ShowdownNode represents the end of the hand, calculating payoffs for different outcomes. The new ChanceNode represents moving to the next round of betting.

If the players haven't committed their entire stacks, an ActionNode is created to represent possible betting actions.

The function then calls a private method `__build` to continue constructing the tree from the newly created node. Finally, it sets the created node as a child of the root chance node.

The code includes several checks to ensure the current round is valid (not exceeding 3, which represents the river). It uses smart pointers (shared_ptr) for memory management of the tree nodes.\\
## Code: 
```
void GameTree::buildChance(shared_ptr<ChanceNode> root,Rule rule){
    //节点上的下注额度
    double pot = (double)rule.get_pot();
    Rule nextrule = Rule(rule);
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));

    shared_ptr<GameTreeNode> one_node;
    if(rule.oop_commit == rule.ip_commit && rule.oop_commit == rule.stack) {
        if(rule.current_round >= 3){ // 3 is river
            double p1_commit = rule.ip_commit;
            double p2_commit = rule.oop_commit;
            double peace_getback = (p1_commit + p2_commit) / 2;


            vector<vector<double>> payoffs(2);
            payoffs[0] = {p2_commit, -p2_commit};
            payoffs[1] = {-p1_commit, p1_commit};
            vector<double> peace_getback_vec = {peace_getback - p1_commit, peace_getback - p2_commit};
            one_node = make_shared<ShowdownNode>(peace_getback_vec, payoffs, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
        }else {
            nextrule.current_round += 1;
            if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
            one_node = make_shared<ChanceNode>(nullptr, GameTreeNode::intToGameRound(rule.current_round + 1), (double) rule.get_pot(), root, this->deck.getCards());
        }
    }else {
        one_node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(), 1, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
    }
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
    this->__build(one_node,nextrule,"begin",0,0);
    root->setChildren(one_node);
}
```