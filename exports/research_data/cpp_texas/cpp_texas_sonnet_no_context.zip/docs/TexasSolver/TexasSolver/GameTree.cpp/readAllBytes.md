`readAllBytes`: The function of `readAllBytes` is to open a file for reading.

**Code Description**: This function takes a file path as a string parameter and creates an input file stream (ifstream) object. It opens the specified file for reading and returns the ifstream object. The function does not actually read the file contents; it merely sets up the stream for subsequent read operations. If the file cannot be opened, the returned ifstream object will be in an error state, which should be checked by the caller.\\
## Code: 
```
ifstream GameTree::readAllBytes(const string& filePath) {
    ifstream input_file(filePath);
    return input_file;
}
```