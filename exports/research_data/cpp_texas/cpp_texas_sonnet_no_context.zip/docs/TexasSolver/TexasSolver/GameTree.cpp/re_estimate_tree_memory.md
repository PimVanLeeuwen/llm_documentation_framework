`re_estimate_tree_memory`: The function of `re_estimate_tree_memory` is to recursively estimate the memory usage of a game tree.

**Code Description**: This function takes a shared pointer to a GameTreeNode and several integer parameters representing deck size, player range sizes, and current deal count. It recursively traverses the game tree, estimating memory usage for different node types:

1. For ACTION nodes:
   - It casts the node to an ActionNode.
   - Recursively estimates memory for all child nodes.
   - Calculates additional memory based on the player (0 or 1) and the number of children.
   - For player 0, it adds: num_current_deal * p1range_num * (childrens.size() + 1) * 3
   - For player 1, it adds: num_current_deal * p2range_num * (childrens.size() + 1) * 3

2. For CHANCE nodes:
   - It casts the node to a ChanceNode.
   - Recursively estimates memory for the single child node.
   - Multiplies the current deal count by the deck size for the recursive call.

3. For other node types, it returns 0.

The function returns a long long integer representing the estimated memory usage in some unit (possibly bytes). This estimation takes into account the tree structure, player ranges, and the number of possible deals at each stage of the game.\\
## Code: 
```
long long GameTree::re_estimate_tree_memory(const shared_ptr<GameTreeNode>& node,int deck_num,int p1range_num,int p2range_num,int num_current_deal){
    if(node->getType() == GameTreeNode::ACTION){
        shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
        vector<shared_ptr<GameTreeNode>> childrens = action_node->getChildrens();
        vector<GameActions> actions = action_node->getActions();

        long long retnum = 0;
        for(std::size_t i = 0;i < childrens.size();i++){
            shared_ptr<GameTreeNode> one_child = childrens[i];
            retnum += re_estimate_tree_memory(one_child,deck_num, p1range_num, p2range_num, num_current_deal);
        }
        if(action_node->getPlayer() == 0){
            retnum += num_current_deal * p1range_num * (childrens.size() + 1) * 3;
        }else{
            retnum += num_current_deal * p2range_num * (childrens.size() + 1) * 3;
        }
        return retnum;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
        shared_ptr<GameTreeNode> children = chance_node->getChildren();
        return re_estimate_tree_memory(children,deck_num, p1range_num, p2range_num, num_current_deal * (deck_num));
    }
    return 0;
}
```