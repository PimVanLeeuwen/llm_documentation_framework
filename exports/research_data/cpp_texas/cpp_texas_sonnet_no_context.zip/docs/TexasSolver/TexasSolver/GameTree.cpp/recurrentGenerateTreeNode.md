`recurrentGenerateTreeNode`: The function of `recurrentGenerateTreeNode` is to recursively generate a game tree node based on JSON input.

**Code Description**: This function takes a JSON object representing a node and its parent node as input. It first extracts and validates the 'round' and 'node_type' from the JSON metadata. The round must be one of "preflop", "flop", "turn", or "river", while the node_type must be "Terminal", "Showdown", "Action", or "Chance".

Based on the node_type, the function creates different types of nodes:

1. For "Action" nodes, it extracts children actions and their corresponding JSON data, ensuring they match in length. It then calls generateActionNode to create the node.

2. For "Showdown" nodes, it calls generateShowdownNode.

3. For "Terminal" nodes, it calls generateTerminalNode.

4. For "Chance" nodes, it ensures there's exactly one child node and calls generateChanceNode.

The function uses dynamic_pointer_cast to convert the specific node types to the base GameTreeNode type before returning. If any validation fails or an unknown node type is encountered, it throws a runtime_error with a descriptive message. This recursive approach allows for the construction of a complex game tree structure from JSON data.\\
## Code: 
```
shared_ptr<GameTreeNode> GameTree::recurrentGenerateTreeNode(json node_json, const shared_ptr<GameTreeNode>& parent) {
    json meta = node_json["meta"];
    string round = meta["round"];
    if(round.empty()){
        throw runtime_error("node json get round null pointer");
    }

    if(! (round == "preflop"
          || round == "flop"
          || round == "turn"
          || round == "river"
          )
            ){
        throw runtime_error(tfm::format("round %s not found",round));
    }

    string node_type = meta["node_type"];
    if(node_type.empty()){
        throw runtime_error("node json get round null pointer");
    }
    if (! (   node_type == "Terminal"
           || node_type == "Showdown"
           || node_type ==  "Action"
           || node_type ==  "Chance"
    )
            ){
        throw runtime_error(tfm::format("node type %s not found",node_type));
    }

    if(node_type == "Action") {
        // 孩子节点的动作，存在list里
        auto childrens_actions = node_json["children_actions"].get<std::vector<string>>();
        // 孩子节点本身，同样存在list里,和上面的children_actions 一一对应,事实上两者的长度一致
        vector<json> childrens = node_json["children"].get<std::vector<json>>();
        if (childrens.size() != childrens_actions.size()) {
            throw runtime_error("action node child length mismatch");
        }
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateActionNode(meta, childrens_actions, childrens, round,parent));
    }
    else if(node_type == "Showdown") {
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateShowdownNode(meta, round,parent));
    }
    else if(node_type == "Terminal") {
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateTerminalNode(meta, round,parent));
    }
    else if(node_type == "Chance") {
        auto childrens = node_json["children"].get<std::vector<json>>();
        if(childrens.size() != 1) throw runtime_error("Chance node should have only one child");
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateChanceNode(meta, childrens[0], round,parent));
    }
    else{
        throw runtime_error(tfm::format("node type %s not found",node_type));
    }
}
```