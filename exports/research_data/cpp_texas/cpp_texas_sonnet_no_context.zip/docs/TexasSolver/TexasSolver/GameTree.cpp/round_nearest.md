`round_nearest`: The function of `round_nearest` is to round a given number to the nearest multiple of a specified value.

**Code Description**: This method takes two double parameters: `number` (the value to be rounded) and `round_num` (the rounding interval). It first inverts `round_num` by calculating its reciprocal. Then, it multiplies the input `number` by this inverted value, rounds the result to the nearest integer using the `round()` function, and finally divides by the inverted `round_num`. This process effectively rounds the input `number` to the nearest multiple of `round_num`. The method returns the rounded value as a double.\\
## Code: 
```
double GameTree::round_nearest(double number, double round_num) {
    round_num = 1 / round_num;
    return round((number * round_num)) / round_num;

}
```