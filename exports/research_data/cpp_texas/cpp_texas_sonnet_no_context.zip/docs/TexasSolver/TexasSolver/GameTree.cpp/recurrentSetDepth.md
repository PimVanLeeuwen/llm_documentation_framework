`recurrentSetDepth`: The function of `recurrentSetDepth` is to recursively set the depth and calculate the subtree size for nodes in a game tree.

**Code Description**: This function takes a shared pointer to a GameTreeNode and an integer depth as input. It sets the depth of the current node and calculates its subtree size based on its type:

1. For ACTION nodes:
   - Sets the node's depth
   - Recursively calls itself for each child node, incrementing the depth
   - Calculates the subtree size by summing the sizes of all child subtrees plus one (for the current node)

2. For CHANCE nodes:
   - Sets the node's depth
   - Recursively calls itself for the single child node, incrementing the depth
   - Calculates the subtree size by multiplying the child's subtree size by the number of cards, then adding one (for the current node)

3. For other node types:
   - Sets the node's depth
   - Sets the subtree size to 1 (only counting itself)

The function returns the calculated subtree size for the current node. This allows for efficient calculation of subtree sizes throughout the entire game tree structure.\\
## Code: 
```
int GameTree::recurrentSetDepth(shared_ptr<GameTreeNode> node, int depth) {
    node->depth = depth;
    if(node->getType() == GameTreeNode::ACTION) {
        shared_ptr<ActionNode> actionNode = std::dynamic_pointer_cast<ActionNode>(node);
        int subtree_size = 1;
        for(shared_ptr<GameTreeNode> one_child:actionNode->getChildrens()){
            subtree_size += this->recurrentSetDepth(one_child,depth + 1);
        }
        node->subtree_size = subtree_size;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chanceNode = std::dynamic_pointer_cast<ChanceNode>(node);
        int subtree_size = 1;
        subtree_size += this->recurrentSetDepth(chanceNode->getChildren(),depth + 1) * chanceNode->getCards().size();
        node->subtree_size = subtree_size;
    }else{
        node->subtree_size = 1;
    }
    return node->subtree_size;
}
```