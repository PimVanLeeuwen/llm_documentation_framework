`generateActionNode`: The function of `generateActionNode` is to create and return a shared pointer to an ActionNode object based on the provided game information and child actions.

**Code Description**: This function takes several parameters including game metadata, children's actions, children's nodes, the current round, and a parent node. It performs the following steps:

1. Validates input data, ensuring the number of children's actions matches the number of children's nodes, and the round is valid.

2. Iterates through the children's actions to create a list of GameActions:
   - Parses each action string to determine the action type (check, fold, call, bet, or raise).
   - For bet and raise actions, extracts the amount from the action string.
   - Creates a GameActions object for each action.

3. Generates child nodes by recursively calling a function (recurrentGenerateTreeNode) for each child node data.

4. Extracts player and pot information from the metadata.

5. Creates an ActionNode object using the parsed actions, generated child nodes, player information, game round, pot size, and parent node.

6. Sets the parent of each child node to the newly created ActionNode.

7. Returns the shared pointer to the created ActionNode.

The function handles various error cases, throwing runtime exceptions for invalid inputs or mismatches in data. It uses helper functions like string_split and strToGameRound for string manipulation and enum conversion, respectively.\\
## Code: 
```
shared_ptr<ActionNode>
GameTree::generateActionNode(json meta, vector<string> childrens_actions, vector<json> childrens_nodes, const string& round,
                             shared_ptr<GameTreeNode> parent) {
    if(childrens_actions.size() != childrens_nodes.size()){
        throw runtime_error(
                tfm::format(
                        "mismatch when generate ActionNode, childrens_action length %s children_nodes length %s",
                        childrens_actions.size(),
                        childrens_nodes.size()
                ));
    }

    if(! (   round == "preflop"
          || round == "flop"
          || round == "turn"
          || round == "river"
          )
            ){
        throw runtime_error(tfm::format("round %s not found",round));
    }

    vector<GameActions> actions;
    vector<shared_ptr<GameTreeNode>> childrens;

    // 遍历所有children actions 来生成GameAction 的list，用于初始化ActionNode
    for(std::size_t i = 0;i < childrens_actions.size();i++){
        string one_action = childrens_actions[i];
        json one_children_map = childrens_nodes[i];
        if(one_action.empty()) throw runtime_error("action is null");

        GameTreeNode::PokerActions action;
        double amount = -1;
        if(one_action == "check"){
            action = GameTreeNode::PokerActions::CHECK;
        }
        else if(one_action == "fold"){
            action = GameTreeNode::PokerActions::FOLD;
        }
        else if(one_action == "call"){
            action = GameTreeNode::PokerActions::CALL;
        }
        else{
            if(one_action.find("bet")  != string::npos){
                vector<string> action_sp = string_split(one_action,'_');
                if(action_sp.size() != 2)
                    throw runtime_error(tfm::format("bet action sp length %s",action_sp.size()));
                string action_str = action_sp[0];
                action = GameTreeNode::PokerActions::BET;
                if(!(action_str == "bet")) throw runtime_error(tfm::format("Action %s not found",action_str));
                amount = stod(action_sp[1]);

            }else if (one_action.find("raise") != string::npos){
                vector<string> action_sp = string_split(one_action,'_');
                if(action_sp.size() != 2)
                    throw runtime_error(tfm::format("raise action sp length %s",action_sp.size()));
                string action_str = action_sp[0];
                action = GameTreeNode::PokerActions::RAISE;
                if(!(action_str == "raise"))
                    throw runtime_error(tfm::format("Action %s not found",action_str));
                amount = stod(action_sp[1]);
            }else{
                throw runtime_error(tfm::format("%s action not found",one_action));
            }
        }
        shared_ptr<GameTreeNode> one_children_node = recurrentGenerateTreeNode(one_children_map,parent);
        childrens.push_back(one_children_node);

        GameActions game_action = GameActions(action,amount);
        actions.push_back(game_action);
    }
    int player = meta["player"];
    double pot = meta["pot"];
    if(childrens.size() != actions.size()){
        throw runtime_error(tfm::format("childrens length %s, actions length %s"
                ,childrens.size()
                ,actions.size()));
    }
    GameTreeNode::GameRound game_round = strToGameRound(round);
    shared_ptr<ActionNode> actionNode = make_shared<ActionNode>(actions,childrens,player,game_round,pot,parent);
    for(const shared_ptr<GameTreeNode>& one_node: childrens){
        one_node->setParent(std::dynamic_pointer_cast<GameTreeNode>(actionNode));
    }
    return actionNode;

}
```