`generateTerminalNode`: The function of `generateTerminalNode` is to create and return a shared pointer to a TerminalNode object representing the end state of a game.

**Code Description**: This method takes three parameters: a JSON object `meta` containing game state information, a string `round` representing the current game round, and a shared pointer to the parent GameTreeNode. 

The function first extracts player payoffs from the `meta` JSON object and stores them in a vector. It then retrieves the pot value from the meta data. The game round is converted from a string to an enumeration using the `strToGameRound` method. The player number is also extracted from the meta data.

Finally, the function creates and returns a shared pointer to a new TerminalNode object, initialized with the extracted payoffs, player number, game round, pot value, and a pointer to the parent node. This TerminalNode represents the final state of a game branch in the game tree.\\
## Code: 
```
shared_ptr<TerminalNode> GameTree::generateTerminalNode(json meta, string round, shared_ptr<GameTreeNode> parent) {
    vector<double> player_payoff_list = meta["payoff"];
    vector<double> player_payoff(player_payoff_list.size());
    for(std::size_t one_player = 0;one_player < player_payoff_list.size();one_player ++){

        double tmp_payoff = player_payoff_list[one_player];
        player_payoff[one_player] = tmp_payoff;
    }

    //节点上的下注额度
    double pot = meta["pot"];

    GameTreeNode::GameRound game_round = this->strToGameRound(std::move(round));
    // 多人游戏的时候winner就不等于当前节点的玩家了，这里要注意
    int player = meta["player"];

    return make_shared<TerminalNode>(player_payoff,player,game_round,pot,parent);
}
```