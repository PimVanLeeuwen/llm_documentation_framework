`getRoot`: The function of `getRoot` is to return the root node of the game tree.

**Code Description**: This method is a member function of the `GameTree` class. It returns a `shared_ptr` to a `GameTreeNode` object, which represents the root node of the game tree. The root is stored as a member variable named `root` within the `GameTree` object, and this function simply returns that stored pointer. By using a `shared_ptr`, the ownership of the root node is shared, allowing for safe access to the root from multiple parts of the program without risking premature deletion.\\
## Code: 
```
shared_ptr<GameTreeNode> GameTree::getRoot() {
    return this->root;
}
```