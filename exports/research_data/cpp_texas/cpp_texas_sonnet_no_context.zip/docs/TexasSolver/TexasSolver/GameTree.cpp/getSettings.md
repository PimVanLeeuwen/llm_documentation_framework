`getSettings`: The function of `getSettings` is to retrieve the appropriate StreetSetting based on the given game round and player.

**Code Description**: This method takes three parameters: an integer representing the game round, an integer representing the player (0 or 1), and a reference to a GameTreeBuildingSettings object. It first converts the integer round to a GameRound enum using the intToGameRound function. The function then checks if the player is valid (0 or 1), throwing a runtime error if not. 

Based on the combination of game round and player, it returns the corresponding StreetSetting from the gameTreeBuildingSettings object. For player 0 (in position), it returns river_ip, turn_ip, or flop_ip settings. For player 1 (out of position), it returns river_oop, turn_oop, or flop_oop settings. If an invalid combination of round and player is provided, it throws a runtime error.

The function uses a series of if-else statements to determine which setting to return, making it easy to add or modify conditions for different game rounds or players if needed in the future.\\
## Code: 
```
StreetSetting GameTree::getSettings(int int_round, int player,GameTreeBuildingSettings& gameTreeBuildingSettings){
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(int_round);
    if(!(player == 0 || player == 1)) throw runtime_error(tfm::format("player %s not known",player));
    if(round == GameTreeNode::GameRound::RIVER && player == 0) return gameTreeBuildingSettings.river_ip;
    else if(round == GameTreeNode::GameRound::TURN && player == 0) return gameTreeBuildingSettings.turn_ip;
    else if(round == GameTreeNode::GameRound::FLOP && player == 0) return gameTreeBuildingSettings.flop_ip;
    else if(round == GameTreeNode::GameRound::RIVER && player == 1) return gameTreeBuildingSettings.river_oop;
    else if(round == GameTreeNode::GameRound::TURN && player == 1) return gameTreeBuildingSettings.turn_oop;
    else if(round == GameTreeNode::GameRound::FLOP && player == 1) return gameTreeBuildingSettings.flop_oop;
    else throw new runtime_error(tfm::format("player %s and round not known",player));
}
```