`generateChanceNode`: The function of `generateChanceNode` is to create and return a new ChanceNode in a game tree.

**Code Description**: This function takes several parameters: a JSON object `meta`, a JSON object `child`, a string `round`, and a shared pointer to a `GameTreeNode` called `parent`. It creates a new `ChanceNode` and sets up its relationships within the game tree.

The function first extracts the `pot` value from the `meta` JSON object. It then recursively generates a child node using the `recurrentGenerateTreeNode` function with the `child` JSON data. The `round` string is converted to a `GameRound` enum using the `strToGameRound` function.

A new `ChanceNode` is created using these parameters, along with the `parent` node and the cards from the `deck` member variable. The function then sets up the parent-child relationship between the new `ChanceNode` and its child node.

Finally, the function returns the newly created `ChanceNode` as a shared pointer, which can be used to integrate this node into the larger game tree structure.\\
## Code: 
```
shared_ptr<ChanceNode>
GameTree::generateChanceNode(json meta, const json& child, string round, shared_ptr<GameTreeNode> parent) {
    //节点上的下注额度
    double pot = meta["pot"];
    shared_ptr<GameTreeNode> one_child = recurrentGenerateTreeNode(child, nullptr);
    GameTreeNode::GameRound game_round = strToGameRound(std::move(round));
    shared_ptr<ChanceNode> chanceNode = make_shared<ChanceNode>(one_child,game_round,pot,parent,this->deck.getCards());
    shared_ptr<GameTreeNode> gameTreeNode = chanceNode->getChildren();
    gameTreeNode->setParent(chanceNode);
    return chanceNode;
}
```