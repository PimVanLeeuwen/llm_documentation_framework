`strToGameRound`: The function of `strToGameRound` is to convert a string representation of a poker game round to its corresponding enumeration value.

**Code Description**: This function takes a string parameter `round` and returns a `GameTreeNode::GameRound` enumeration value. It uses a series of if-else statements to match the input string with predefined round names: "preflop", "flop", "turn", and "river". If a match is found, it assigns the corresponding enumeration value to the `game_round` variable. If no match is found, it throws a runtime error with a formatted error message. The function handles case-sensitive input and provides a direct mapping between string representations and enumeration values for poker game rounds.\\
## Code: 
```
GameTreeNode::GameRound GameTree::strToGameRound(const string& round) {
    GameTreeNode::GameRound game_round;
    if(round == "preflop"){
        game_round = GameTreeNode::GameRound::PREFLOP;
    }
    else if (round == "flop"){
        game_round = GameTreeNode::GameRound::FLOP;
    }
    else if(round == "turn"){
        game_round = GameTreeNode::GameRound::TURN;
    }
    else if(round == "river"){
        game_round = GameTreeNode::GameRound::RIVER;
    }
    else{
        throw runtime_error(tfm::format("game round not found: %s",round));
    }
    return game_round;
}
```