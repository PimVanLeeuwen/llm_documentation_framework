`generateShowdownNode`: The function of `generateShowdownNode` is to create and return a shared pointer to a ShowdownNode object based on the provided game metadata and parent node.

**Code Description**: This function takes JSON metadata, a round string, and a parent node as input. It processes the payoff information from the metadata to construct a ShowdownNode. The function performs the following steps:

1. Extracts tie payoffs from the metadata.
2. Initializes a vector to store player payoffs.
3. Iterates through the payoff data for each player:
   - Skips the "tie" entry.
   - Converts the player ID from string to integer.
   - Validates the player ID (must be 0 or 1).
   - Stores the player's payoff vector.
4. Converts the round string to a GameRound enum value.
5. Creates and returns a shared pointer to a new ShowdownNode object, passing:
   - Tie payoffs
   - Player payoffs
   - Game round
   - Pot value
   - Parent node

The function handles payoff distribution for two players and a tie scenario in a poker-like game, preparing the data for use in a game tree structure.\\
## Code: 
```
shared_ptr<ShowdownNode> GameTree::generateShowdownNode(json meta, string round, shared_ptr<GameTreeNode> parent) {
    json meta_payoffs = meta["payoffs"];
    vector<double> tie_payoffs = meta_payoffs["tie"];

    // meta_payoffs 的key有 n个玩家+1个平局,代表某个玩家赢了的时候如何分配payoff
    vector<vector<double>> player_payoffs(2);
    double pot = meta["pot"];

    for(auto one_player_meta=meta_payoffs.begin(); one_player_meta!=meta_payoffs.end(); one_player_meta++){
        const string& one_player = one_player_meta.key();
        if(one_player == "tie"){
            continue;
        }
        // 获胜玩家id
        int player_id = atoi(one_player.c_str());
        if(player_id < 0 or player_id > 1) throw runtime_error("player id json convert fail");

        // 玩家在当前Showdown节点能获得的收益
        //List<Object> tmp_payoffs =  (List<Object>)meta_payoffs.get(one_player);
        vector<double> player_payoff = one_player_meta.value();

        player_payoffs[atoi(one_player.c_str())] = player_payoff;
    }
    GameTreeNode::GameRound game_round = strToGameRound(std::move(round));
    return make_shared<ShowdownNode>(tie_payoffs,player_payoffs,game_round,pot,parent);
}
```