`GameTree`: The function of `GameTree` is to initialize a game tree for a poker game.

**Code Description**: This constructor initializes a `GameTree` object for a poker game. It takes several parameters to set up the initial game state, including the deck, player commitments, current round, raise limit, blinds, stack size, building settings, and all-in threshold. 

The constructor creates a `Rule` object using these parameters, which likely encapsulates the game rules. It then sets the current player to 1 and stores the provided deck.

The constructor converts the current round to a `GameRound` enum and creates a shared pointer to an `ActionNode`. This node represents the root of the game tree, initialized with empty action and child node vectors, the current player, game round, pot size, and a null parent.

Finally, it calls a private `__build` method to construct the rest of the game tree starting from this root node, and sets the `root` member variable to the created node.

This setup allows for the creation of a complete game tree structure that can be used for game analysis or AI decision-making in poker.\\
## Code: 
```
GameTree::GameTree(Deck deck,
                   float oop_commit,
                   float ip_commit,
                   int current_round,
                   int raise_limit,
                   float small_blind,
                   float big_blind,
                   float stack,
                   GameTreeBuildingSettings buildingSettings,
                   float allin_threshold
){
    Rule rule = Rule(deck,oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,buildingSettings,allin_threshold);
    int current_player = 1;
    this->deck = deck;
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(rule.current_round);
    shared_ptr<ActionNode> node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(),current_player, round, (double) rule.get_pot(),
                                 nullptr);
    this->__build(node,rule);
    this->root = node;
}
```