`__build`: The function of `__build` is to construct and expand a game tree node based on its type and game rules.

**Code Description**: This method takes a shared pointer to a GameTreeNode, along with game rule parameters, and processes the node according to its type. For ACTION nodes, it calls the buildAction method to expand the node with possible actions. SHOWDOWN and TERMINAL nodes are left as-is without further processing. For CHANCE nodes, it calls the buildChance method to handle probability-based events. If an unknown node type is encountered, it throws a runtime error. The function returns the processed node, allowing for recursive tree construction. The use of shared pointers suggests memory management for complex tree structures, while the switch statement efficiently handles different node types.\\
## Code: 
```
shared_ptr<GameTreeNode> GameTree::__build(shared_ptr<GameTreeNode> node, Rule rule, string last_action,
                                           int check_times, int raise_times) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            this->buildAction(std::dynamic_pointer_cast<ActionNode>(node),rule,last_action,check_times,raise_times);
            break;
        }case GameTreeNode::SHOWDOWN: {
            break;
        }case GameTreeNode::TERMINAL: {
            break;
        }case GameTreeNode::CHANCE: {
            this->buildChance(std::dynamic_pointer_cast<ChanceNode>(node),rule);
            break;
        }default:
            throw runtime_error("node type unknown");
    }
    return node;
}
```