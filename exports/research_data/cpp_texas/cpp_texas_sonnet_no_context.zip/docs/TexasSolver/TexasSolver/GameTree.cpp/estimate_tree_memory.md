`estimate_tree_memory`: The function of `estimate_tree_memory` is to calculate an estimate of the memory required for the game tree.

**Code Description**: This method is a member of the `GameTree` class and serves as a wrapper for a recursive function `re_estimate_tree_memory`. It takes four integer parameters: `deck_num`, `p1range_num`, `p2range_num`, and `num_current_deal`. These parameters likely represent the number of cards in the deck, the range of possible hands for player 1 and player 2, and the number of cards currently dealt, respectively. The function calls `re_estimate_tree_memory` with these parameters and the root of the game tree (accessed via `this->root`), then returns the result as a `long long` integer. This suggests that the actual memory estimation logic is implemented in the recursive function, which traverses the game tree structure to compute the total memory requirement.\\
## Code: 
```
long long GameTree::estimate_tree_memory(int deck_num,int p1range_num,int p2range_num,int num_current_deal){
    return this->re_estimate_tree_memory(this->root,deck_num, p1range_num, p2range_num, num_current_deal);
}
```