`resizeEvent`: The function of `resizeEvent` is to adjust the column widths and row heights of an HTML table view when the widget is resized.

**Code Description**: This method is triggered when a resize event occurs on the HtmlTableView widget. It first checks if a model is associated with the view. If so, it retrieves the number of columns and rows from the model. 

For column resizing, it calculates new widths for each column as a percentage of the total width. It iterates through all columns except the last one, setting their widths proportionally. The last column is then set to occupy the remaining width.

Similarly for row resizing, it calculates new heights for each row as a percentage of the total height. It iterates through all rows except the last one, setting their heights proportionally. The last row is then set to occupy the remaining height.

Finally, it calls the parent class's resizeEvent method to ensure proper handling of the resize event by the base QTableView class.

This approach ensures that the table columns and rows are resized dynamically to fit the available space while maintaining proportional sizes.\\
## Code: 
```
void HtmlTableView::resizeEvent(QResizeEvent* ev){
    if(model() != NULL){
        int num_columns = this->model()->columnCount(QModelIndex());
        int num_rows = this->model()->rowCount(QModelIndex());
        if (num_columns > 0) {
        int width = ev->size().width();
        int used_width = 0;
        // Set our widths to be a percentage of the available width
        for (int i = 0; i < num_columns - 1; i++) {
            //int column_width = width / num_columns;
            int column_width = (int)((float)width * (i + 1) / num_columns) -  (int)((float)width * (i) / num_columns);
            this->setColumnWidth(i, column_width);
            used_width += column_width;
        }

        // Set our last column to the remaining width
        this->setColumnWidth(num_columns - 1, width - used_width);
        }
        if (num_columns > 0) {
        int height = ev->size().height();
        int used_height = 0;
        for (int i = 0; i < num_columns - 1; i++) {
            //int column_height = height / num_rows;
            int column_height = (int)((float)height * (i + 1) / num_rows) -  (int)((float)height * (i) / num_rows);
            this->setRowHeight(i, column_height);
            used_height += column_height;
        }
        this->setRowHeight(num_columns - 1, height - used_height);
        }
    }
    QTableView::resizeEvent(ev);
}
```