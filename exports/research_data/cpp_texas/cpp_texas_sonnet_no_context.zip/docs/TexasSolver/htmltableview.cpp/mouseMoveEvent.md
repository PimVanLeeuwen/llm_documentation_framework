`mouseMoveEvent`: The function of `mouseMoveEvent` is to handle mouse movement events and update the cursor and link hover state accordingly.

**Code Description**: This method is part of the HtmlTableView class and is triggered when the mouse moves over the view. It performs the following actions:

1. Retrieves the anchor (likely a hyperlink) at the current mouse position.

2. Clears the _mousePressAnchor if it doesn't match the current anchor, which helps track if the mouse has moved away from the initially clicked anchor.

3. Compares the current anchor with the last hovered anchor (_lastHoveredAnchor). If they're different:
   - Updates _lastHoveredAnchor with the new anchor.
   - If the new anchor is not empty:
     - Changes the cursor to a pointing hand cursor.
     - Emits a linkHovered signal with the new anchor.
   - If the new anchor is empty:
     - Restores the default cursor.
     - Emits a linkUnhovered signal.

This implementation provides visual feedback when hovering over links and notifies other parts of the application about link hover state changes.\\
## Code: 
```
void HtmlTableView::mouseMoveEvent(QMouseEvent *event) {
    auto anchor = anchorAt(event->pos());

    if (_mousePressAnchor != anchor) {
        _mousePressAnchor.clear();
    }

    if (_lastHoveredAnchor != anchor) {
        _lastHoveredAnchor = anchor;
        if (!_lastHoveredAnchor.isEmpty()) {
            QApplication::setOverrideCursor(QCursor(Qt::PointingHandCursor));
            emit linkHovered(_lastHoveredAnchor);
        } else {
            QApplication::restoreOverrideCursor();
            emit linkUnhovered();
        }
    }
}
```