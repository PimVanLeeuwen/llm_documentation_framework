`triger_resize`: The function of `triger_resize` is to manually trigger a resize event for the HtmlTableView widget.

**Code Description**: This method creates a new QResizeEvent with the current size of the widget, calls the resizeEvent method with this event, and then deletes the event object. It essentially simulates a resize event without actually changing the widget's size. The commented-out line suggests that at some point, there was consideration to resize the widget to its parent's size, but this functionality is currently disabled.\\
## Code: 
```
void HtmlTableView::triger_resize(){
    QResizeEvent* ev = new QResizeEvent(this->size(),this->size());
    this->resizeEvent(ev);
    //this->resize(this->parentWidget()->size());
    delete ev;
}
```