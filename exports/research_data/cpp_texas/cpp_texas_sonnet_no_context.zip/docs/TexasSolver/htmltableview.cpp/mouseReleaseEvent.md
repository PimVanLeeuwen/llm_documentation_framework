`mouseReleaseEvent`: The function of `mouseReleaseEvent` is to handle mouse release events in an HTML table view.

**Code Description**: This method is part of the `HtmlTableView` class and overrides the default `mouseReleaseEvent` behavior. It checks if a mouse press anchor was previously set. If so, it compares the anchor at the current mouse position with the stored press anchor. If they match, it emits a `linkActivated` signal with the anchor. The press anchor is then cleared. Finally, it calls the parent class's `mouseReleaseEvent` to ensure default behavior is maintained.\\
## Code: 
```
void HtmlTableView::mouseReleaseEvent(QMouseEvent *event) {
    if (!_mousePressAnchor.isEmpty()) {
        auto anchor = anchorAt(event->pos());

        if (anchor == _mousePressAnchor) {
            emit linkActivated(_mousePressAnchor);
        }

        _mousePressAnchor.clear();
    }

    QTableView::mouseReleaseEvent(event);
}
```