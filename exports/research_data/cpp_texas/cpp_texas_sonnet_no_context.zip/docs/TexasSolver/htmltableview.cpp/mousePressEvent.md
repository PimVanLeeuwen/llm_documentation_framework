`mousePressEvent`: The function of `mousePressEvent` is to handle mouse press events in an HTML table view.

**Code Description**: This method overrides the default `mousePressEvent` of `QTableView`. It first calls the parent class implementation to ensure default behavior is maintained. Then, it retrieves the anchor (likely a hyperlink) at the position where the mouse was pressed using the `anchorAt` function. This anchor is stored in the `_mousePressAnchor` member variable, presumably for later use in determining if a link was clicked when the mouse is released.\\
## Code: 
```
void HtmlTableView::mousePressEvent(QMouseEvent *event) {
    QTableView::mousePressEvent(event);

    auto anchor = anchorAt(event->pos());
    _mousePressAnchor = anchor;
}
```