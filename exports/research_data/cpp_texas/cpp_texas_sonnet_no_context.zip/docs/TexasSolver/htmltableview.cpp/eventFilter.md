`eventFilter`: The function of `eventFilter` is to handle mouse move events over the table view and emit signals when the mouse hovers over different cells.

**Code Description**: This method overrides the `eventFilter` function of the `HtmlTableView` class, which is likely derived from `QTableView`. It specifically watches for mouse move events on the viewport of the table. When a mouse move event occurs, it determines the table cell (row and column) under the mouse cursor using the `indexAt` method. If the cell is different from the last recorded position, it updates the last known position and emits an `itemMouseChange` signal with the new row and column indices. The function also handles leave events, though no specific action is defined for this event type in the given code. Finally, it calls the base class implementation of `eventFilter` to ensure proper event handling for unhandled events.\\
## Code: 
```
bool HtmlTableView::eventFilter(QObject *watched, QEvent *event){
    if(viewport() == watched){
        if(event->type() == QEvent::MouseMove){
        QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
        QModelIndex index = indexAt(mouseEvent->pos());
        if(index.isValid()){
            int i = index.row();
            int j = index.column();
            if(i != this->last_bearing_i || j != last_bearing_j){
                this->last_bearing_i = i;
                this->last_bearing_j = j;
                emit itemMouseChange(i,j);
            }
        }
        else{
        }
        }
        else if(event->type() == QEvent::Leave){
        }
    }
    return QTableView::eventFilter(watched, event);
}
```