`on_confirmBox_accepted`: The function of `on_confirmBox_accepted` is to save user settings when a confirmation box is accepted.

**Code Description**: This method is part of the SettingEditor class and is triggered when a confirmation box is accepted. It performs the following actions:

1. Creates a QSettings object for storing application settings.
2. Begins a settings group named "solver".
3. Retrieves the selected language from a UI element (languageBox).
4. Converts the language selection to a two-letter code (EN for English, CN for Chinese).
5. Saves the language setting using the key "language".
6. If an unknown language is selected, it outputs a debug message.
7. Retrieves the selected round number from a UI element (roundBox).
8. Converts the round number to an integer.
9. Saves the round number setting using the key "dump_round".

The function uses Qt's QSettings class to persistently store these configuration options, allowing the application to remember user preferences between sessions.\\
## Code: 
```
void SettingEditor::on_confirmBox_accepted()
{
    QSettings setting("TexasSolver", "Setting");
    setting.beginGroup("solver");
    QString lang = this->ui->languageBox->currentText();
    QString language_str;
    if(lang == "English"){
        language_str = "EN";
    }else if(lang == "Chinese"){
        language_str = "CN";
    }else{
        qDebug().noquote() << tr("Unknown language: ") << lang << tr("Setting fail");
    }
    setting.setValue("language",language_str);

    int round = this->ui->roundBox->currentText().toInt();
    setting.setValue("dump_round",round);
}
```