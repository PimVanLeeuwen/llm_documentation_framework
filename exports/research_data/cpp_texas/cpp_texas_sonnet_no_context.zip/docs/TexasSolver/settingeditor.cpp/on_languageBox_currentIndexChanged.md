`on_languageBox_currentIndexChanged`: The function of `on_languageBox_currentIndexChanged` is to handle language selection changes and notify the user to restart the program.

**Code Description**: This function is a slot that responds to changes in a language selection box. When the selected language is changed, it first checks if the application is fully initialized. If not, it returns without action. If initialized, it creates a message informing the user that a restart is required for the language change to take effect. This message is then logged using qDebug() and displayed to the user through a QMessageBox. The function uses Qt's internationalization system (tr()) for potential translation of the message.\\
## Code: 
```
void SettingEditor::on_languageBox_currentIndexChanged(int index)
{
    if(!initized)return;
    QString message = tr("Restart program to make language selection effective.");
    qDebug().noquote() << message;
    QMessageBox msgBox;
    msgBox.setText(message);
    msgBox.exec();
}
```