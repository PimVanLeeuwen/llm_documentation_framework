# PROMPT
## Information
**Code Content:** \
`void boardselector::on_boardEdit_textChanged(const QString &arg1)
{
    this->boardSelectorTableModel->setBoardText(arg1);
    this->ui->boardSelectorTable->update();
    this->ui->boardSelectorTable->setFocus();
    this->ui->boardEdit->setFocus();
}`

## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`on_boardEdit_textChanged`: The function of `on_boardEdit_textChanged` is *FILL IN* 

**Code Description**: *FILL IN*
