# PROMPT
## Information
**Code Content:** \
`void boardselector::on_boardSelectorTable_clicked(const QModelIndex &index)
{
    int row = index.row();
    int col = index.column();
    this->boardSelectorTableModel->setBoardAt(row,col,1 - this->boardSelectorTableModel->getBoardAt(row,col));
    if(this->ui->boardEdit->text() != this->boardSelectorTableModel->getBoardText()){
        this->ui->boardEdit->setText(this->boardSelectorTableModel->getBoardText());
    }
    this->ui->boardEdit->setFocus();
    this->ui->boardSelectorTable->setFocus();
}`

## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`on_boardSelectorTable_clicked`: The function of `on_boardSelectorTable_clicked` is *FILL IN* 

**Code Description**: *FILL IN*
