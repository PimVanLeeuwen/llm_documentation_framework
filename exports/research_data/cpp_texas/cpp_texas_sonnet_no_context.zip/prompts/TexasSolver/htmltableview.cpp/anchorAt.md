# PROMPT
## Information
**Code Content:** \
`QString HtmlTableView::anchorAt(const QPoint &pos) const {
    auto index = indexAt(pos);
    if (index.isValid()) {
        auto delegate = itemDelegate(index);
        auto wordDelegate = qobject_cast<WordItemDelegate *>(delegate);
        if (wordDelegate != 0) {
            auto itemRect = visualRect(index);
            auto relativeClickPosition = pos - itemRect.topLeft();

            if(model() != NULL){
                auto html = model()->data(index, Qt::DisplayRole).toString();
                return wordDelegate->anchorAt(html, relativeClickPosition);
            }
        }
    }

    return QString();
}`

## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`anchorAt`: The function of `anchorAt` is *FILL IN* 

**Code Description**: *FILL IN*
