# PROMPT
## Information
**Code Content:** \
`Rule::Rule(Deck deck, float oop_commit, float ip_commit, int current_round, int raise_limit, float small_blind,
           float big_blind, float stack, GameTreeBuildingSettings build_settings,float allin_threshold):
           deck(deck),oop_commit(oop_commit),ip_commit(ip_commit),current_round(current_round),raise_limit(raise_limit),
           small_blind(small_blind),big_blind(big_blind),stack(stack),build_settings(build_settings),allin_threshold(allin_threshold){
    if(oop_commit != ip_commit) throw runtime_error("ip commit should equal with oop commit");
    this->initial_effective_stack = stack;
}`

## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`Rule`: The function of `Rule` is *FILL IN* 

**Code Description**: *FILL IN*
