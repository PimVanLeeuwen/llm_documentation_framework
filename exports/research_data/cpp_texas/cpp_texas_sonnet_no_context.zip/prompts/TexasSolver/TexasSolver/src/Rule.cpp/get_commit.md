# PROMPT
## Information
**Code Content:** \
`float Rule::get_commit(int player) {
    if (player == 0) return this->ip_commit;
    else if(player == 1) return this->oop_commit;
    else throw runtime_error("unknown player");
}`

## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`get_commit`: The function of `get_commit` is *FILL IN* 

**Code Description**: *FILL IN*
