# PROMPT
## Information
**Code Content:** \
`int Dic5Compairer::getRank(vector<Card> cards) {
    vector<int> cards_int(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_int[i] = cards[i].getCardInt();
    }
    return this->getRank(cards_int);
}`

## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`getRank`: The function of `getRank` is *FILL IN* 

**Code Description**: *FILL IN*
