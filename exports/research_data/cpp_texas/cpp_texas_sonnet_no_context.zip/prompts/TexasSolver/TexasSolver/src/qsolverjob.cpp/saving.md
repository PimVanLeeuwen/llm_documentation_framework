# PROMPT
## Information
**Code Content:** \
`void QSolverJob::saving(){
    qDebug().noquote() << tr("Saving json file..");//.toStdString() << std::endl;

    QSettings setting("TexasSolver", "Setting");
    setting.beginGroup("solver");
    this->dump_rounds = setting.value("dump_round").toInt();

    qDebug().noquote() << tr("Dump round: ") << this->dump_rounds;
    if(this->dump_rounds == 3){
        qDebug().noquote() << tr("This could be slow, or even blow your RAM, dump to river is not well optimized :(");
    }
    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.dump_strategy(this->savefile,this->dump_rounds);
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.dump_strategy(this->savefile,this->dump_rounds);
    }
    qDebug().noquote() << tr("Saving done.");//.toStdString() << std::endl;
}`

## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`saving`: The function of `saving` is *FILL IN* 

**Code Description**: *FILL IN*
