# PROMPT
## Information
**Code Content:** \
`void SettingEditor::on_confirmBox_accepted()
{
    QSettings setting("TexasSolver", "Setting");
    setting.beginGroup("solver");
    QString lang = this->ui->languageBox->currentText();
    QString language_str;
    if(lang == "English"){
        language_str = "EN";
    }else if(lang == "Chinese"){
        language_str = "CN";
    }else{
        qDebug().noquote() << tr("Unknown language: ") << lang << tr("Setting fail");
    }
    setting.setValue("language",language_str);

    int round = this->ui->roundBox->currentText().toInt();
    setting.setValue("dump_round",round);
}`

## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`on_confirmBox_accepted`: The function of `on_confirmBox_accepted` is *FILL IN* 

**Code Description**: *FILL IN*
