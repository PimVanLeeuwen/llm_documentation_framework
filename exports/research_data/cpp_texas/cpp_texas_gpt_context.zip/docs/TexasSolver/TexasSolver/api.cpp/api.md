## Expected output
`api`: The function of `api` is to execute the Texas Hold'em solver based on the provided input and settings.
**Parameters**:\
`const char * input_file`: This parameter specifies the file from which to read the input for the solver. If empty, it will use a command-line interface instead.
`const char * resource_dir = "./resources"`: This parameter sets the directory where resources such as images or data files are located.
`const char * mode = "holdem"`: This parameter specifies the game mode, which can be either "holdem" for Texas Hold'em or "shortdeck" for a variant of short deck poker.

**Code Description**: The `api` function first checks if the provided mode is valid. If not, it throws an error. It then creates a `CommandLineTool` object based on the specified mode and resource directory. Depending on whether an input file was provided, it either starts working with the command-line tool or executes from a file using the `execFromFile` method of the `CommandLineTool`.\\
## Code: 
```
EXPORT
int api(const char * input_file, const char * resource_dir = "./resources", const char * mode = "holdem") {
    string input_file_ = input_file;
    string resource_dir_ = resource_dir;
    string mode_ = mode;

    if(mode_ != "holdem" && mode_ != "shortdeck")
        throw runtime_error(tfm::format("mode %s error, not in ['holdem','shortdeck']", mode_));

    if(input_file_.empty()) {
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.startWorking();
    }else{
        cout << "EXEC FROM FILE" << endl;
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.execFromFile(input_file_);
    }
}
```