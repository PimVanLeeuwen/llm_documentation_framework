`api`: The function of `api` is to initialize and execute the poker solver based on the provided input file, resource directory, and game mode.

**Parameters**:\
`const char * input_file`: The path to the input file containing poker game data. If empty, the solver will run interactively.\
`const char * resource_dir = "./resources"`: The directory where resource files needed for the solver are located. Defaults to "./resources".\
`const char * mode = "holdem"`: The game mode for the solver, either "holdem" or "shortdeck". Defaults to "holdem".

**Code Description**: 
The `api` function initializes the poker solver environment by setting up the input file, resource directory, and game mode. It checks if the provided game mode is valid (either "holdem" or "shortdeck"). If the input file is empty, it starts the solver in interactive mode using the `startWorking` method of the `CommandLineTool` class. If an input file is provided, it executes the solver using the data from the file with the `execFromFile` method of the `CommandLineTool` class.\\
## Code: 
```
EXPORT
int api(const char * input_file, const char * resource_dir = "./resources", const char * mode = "holdem") {
    string input_file_ = input_file;
    string resource_dir_ = resource_dir;
    string mode_ = mode;

    if(mode_ != "holdem" && mode_ != "shortdeck")
        throw runtime_error(tfm::format("mode %s error, not in ['holdem','shortdeck']", mode_));

    if(input_file_.empty()) {
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.startWorking();
    }else{
        cout << "EXEC FROM FILE" << endl;
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.execFromFile(input_file_);
    }
}
```