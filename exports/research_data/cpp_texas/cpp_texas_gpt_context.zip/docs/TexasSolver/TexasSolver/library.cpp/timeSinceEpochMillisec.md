`timeSinceEpochMillisec`: The function of `timeSinceEpochMillisec` is to return the current time in milliseconds since the Unix epoch.

**Code Description**: This method uses the C++ `<chrono>` library to get the current time from the system clock. It then calculates the duration in milliseconds from the Unix epoch (January 1, 1970) to the current time. The result is returned as an unsigned 64-bit integer (`uint64_t`).\\
## Code: 
```
uint64_t timeSinceEpochMillisec() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
}
```