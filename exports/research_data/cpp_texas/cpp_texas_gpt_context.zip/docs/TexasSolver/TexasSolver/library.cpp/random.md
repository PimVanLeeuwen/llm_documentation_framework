`random`: The function of `random` is to generate a random integer within a specified range.

**Parameters**:\
`int min`: The lower bound of the range (inclusive).\
`int max`: The upper bound of the range (exclusive).

**Code Description**: The `random` function takes two integer parameters, `min` and `max`, and returns a random integer in the range `[min, max)`. It uses the `rand()` function from the C++ standard library to generate a random number, then scales and shifts this number to fit within the specified range. The expression `rand() % ((max) - min)` generates a random number between `0` and `(max - min - 1)`, and adding `min` shifts this range to `[min, max - 1]`.\\
## Code: 
```
int random(int min, int max) //range : [min, max)
{
    return min + rand() % (( max ) - min);
}
```