`normalization_tanh`: The function of `normalization_tanh` is to normalize a value using the hyperbolic tangent function.

**Parameters**:\
`float stack`: The base value used for normalization. \
`float ev`: The expected value to be normalized. \
`float ratio`: A scaling factor applied during normalization.

**Code Description**: This function first calculates a scaled value `x` by dividing the expected value `ev` by the base value `stack` and then multiplying by the scaling factor `ratio`. It then applies the hyperbolic tangent function to `x`, scales the result to the range [0, 1], and returns the normalized value. The formula used is `tanh(x) / 2 + 0.5`.\\
## Code: 
```
float normalization_tanh(float stack,float ev,float ratio){
    float x = ev / stack * ratio;
    return tanh(x) / 2 + 0.5;
}
```