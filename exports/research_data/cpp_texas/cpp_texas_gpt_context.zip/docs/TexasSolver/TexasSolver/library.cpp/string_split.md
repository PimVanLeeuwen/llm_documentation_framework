`string_split`: The function of `string_split` is to split a given string into substrings based on a specified delimiter character.

**Parameters**:\
`string strin`: The input string that needs to be split.\
`char split`: The delimiter character used to split the input string.

**Code Description**: The `string_split` function takes an input string `strin` and a delimiter character `split`. It uses a `stringstream` to process the input string and the `getline` function to extract substrings separated by the delimiter. Each extracted substring (token) is added to a vector of strings (`retval`). The function returns this vector containing all the substrings.\\
## Code: 
```
vector<string> string_split(string strin,char split){
    vector<string> retval;
    stringstream ss(strin);
    string token;
    while (getline(ss,token, split))
    {
        retval.push_back(token);
    }
    return retval;
}
```