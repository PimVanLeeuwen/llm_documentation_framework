`generateTerminalNode`: The function of `generateTerminalNode` is to create and return a shared pointer to a `TerminalNode` object, initialized with the provided metadata, game round, and parent node.

**Parameters**:\
`json meta`: A JSON object containing metadata for the terminal node, including player payoffs, the pot size, and the player index. \
`string round`: A string representing the current game round (e.g., "preflop", "flop", "turn", "river"). \
`shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node in the game tree.

**Code Description**: The `generateTerminalNode` method begins by extracting the player payoffs from the `meta` JSON object and storing them in a vector. It then retrieves the pot size from the `meta` object. The method converts the `round` string into a `GameTreeNode::GameRound` enum value using the `strToGameRound` method. It also extracts the player index from the `meta` object. Finally, it creates and returns a shared pointer to a new `TerminalNode` object, initialized with the extracted payoffs, player index, game round, pot size, and parent node.\\
## Code: 
```
shared_ptr<TerminalNode> GameTree::generateTerminalNode(json meta, string round, shared_ptr<GameTreeNode> parent) {
    vector<double> player_payoff_list = meta["payoff"];
    vector<double> player_payoff(player_payoff_list.size());
    for(std::size_t one_player = 0;one_player < player_payoff_list.size();one_player ++){

        double tmp_payoff = player_payoff_list[one_player];
        player_payoff[one_player] = tmp_payoff;
    }

    //节点上的下注额度
    double pot = meta["pot"];

    GameTreeNode::GameRound game_round = this->strToGameRound(std::move(round));
    // 多人游戏的时候winner就不等于当前节点的玩家了，这里要注意
    int player = meta["player"];

    return make_shared<TerminalNode>(player_payoff,player,game_round,pot,parent);
}
```