`getSettings`: The function of `getSettings` is to retrieve the appropriate `StreetSetting` for a given game round and player based on the provided game tree building settings.

**Parameters**:\
`int int_round`: An integer representing the current game round (e.g., FLOP, TURN, RIVER). \
`int player`: An integer representing the player (0 for in-position player, 1 for out-of-position player). \
`GameTreeBuildingSettings& gameTreeBuildingSettings`: A reference to a `GameTreeBuildingSettings` object that contains the settings for different game rounds and player positions.

**Code Description**: The `getSettings` method first converts the integer `int_round` to its corresponding `GameRound` enum value using the `intToGameRound` method. It then checks if the `player` value is either 0 or 1; if not, it throws a runtime error. Depending on the game round and player, it returns the appropriate `StreetSetting` from the `gameTreeBuildingSettings` object. If the combination of player and round is not recognized, it throws a runtime error.\\
## Code: 
```
StreetSetting GameTree::getSettings(int int_round, int player,GameTreeBuildingSettings& gameTreeBuildingSettings){
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(int_round);
    if(!(player == 0 || player == 1)) throw runtime_error(tfm::format("player %s not known",player));
    if(round == GameTreeNode::GameRound::RIVER && player == 0) return gameTreeBuildingSettings.river_ip;
    else if(round == GameTreeNode::GameRound::TURN && player == 0) return gameTreeBuildingSettings.turn_ip;
    else if(round == GameTreeNode::GameRound::FLOP && player == 0) return gameTreeBuildingSettings.flop_ip;
    else if(round == GameTreeNode::GameRound::RIVER && player == 1) return gameTreeBuildingSettings.river_oop;
    else if(round == GameTreeNode::GameRound::TURN && player == 1) return gameTreeBuildingSettings.turn_oop;
    else if(round == GameTreeNode::GameRound::FLOP && player == 1) return gameTreeBuildingSettings.flop_oop;
    else throw new runtime_error(tfm::format("player %s and round not known",player));
}
```