`readAllBytes`: The function of `readAllBytes` is to open a file at the specified path and return an input file stream object for reading the file's contents.

**Parameters**:\
`const string& filePath`: A constant reference to a string that specifies the path to the file to be opened.

**Code Description**: The `readAllBytes` method takes a file path as input, opens the file at the given path using an `ifstream` object, and returns this `ifstream` object. This allows the caller to read the contents of the file using the returned input file stream.\\
## Code: 
```
ifstream GameTree::readAllBytes(const string& filePath) {
    ifstream input_file(filePath);
    return input_file;
}
```