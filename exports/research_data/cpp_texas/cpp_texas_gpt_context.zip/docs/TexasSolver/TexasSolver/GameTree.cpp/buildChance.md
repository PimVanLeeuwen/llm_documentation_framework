`buildChance`: The function of `buildChance` is to construct the game tree starting from a given `ChanceNode` based on the current game rules and state.

**Parameters**:\
`shared_ptr<ChanceNode> root`: A shared pointer to the root `ChanceNode` from which the game tree will be built. \
`Rule rule`: An object representing the current game rules and state, including the pot size, current round, and player commitments.

**Code Description**: 
The `buildChance` method constructs the game tree by evaluating the current game state and creating appropriate nodes (`ShowdownNode`, `ChanceNode`, or `ActionNode`). It first checks the current round and pot size from the `rule` object. If the game is in the final round (river) and both players have committed their entire stacks, it creates a `ShowdownNode` to determine the payoffs. If the game is not in the final round, it increments the round and creates a new `ChanceNode` for the next round. If neither condition is met, it creates an `ActionNode` for the players to make their moves. The method then recursively builds the tree by calling `__build` on the newly created node and sets this node as a child of the root `ChanceNode`.\\
## Code: 
```
void GameTree::buildChance(shared_ptr<ChanceNode> root,Rule rule){
    //节点上的下注额度
    double pot = (double)rule.get_pot();
    Rule nextrule = Rule(rule);
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));

    shared_ptr<GameTreeNode> one_node;
    if(rule.oop_commit == rule.ip_commit && rule.oop_commit == rule.stack) {
        if(rule.current_round >= 3){ // 3 is river
            double p1_commit = rule.ip_commit;
            double p2_commit = rule.oop_commit;
            double peace_getback = (p1_commit + p2_commit) / 2;


            vector<vector<double>> payoffs(2);
            payoffs[0] = {p2_commit, -p2_commit};
            payoffs[1] = {-p1_commit, p1_commit};
            vector<double> peace_getback_vec = {peace_getback - p1_commit, peace_getback - p2_commit};
            one_node = make_shared<ShowdownNode>(peace_getback_vec, payoffs, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
        }else {
            nextrule.current_round += 1;
            if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
            one_node = make_shared<ChanceNode>(nullptr, GameTreeNode::intToGameRound(rule.current_round + 1), (double) rule.get_pot(), root, this->deck.getCards());
        }
    }else {
        one_node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(), 1, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
    }
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
    this->__build(one_node,nextrule,"begin",0,0);
    root->setChildren(one_node);
}
```