`recurrentGenerateTreeNode`: The function of `recurrentGenerateTreeNode` is to recursively generate a game tree node based on the provided JSON data and its parent node.

**Parameters**:\
`json node_json`: A JSON object containing the metadata and children information for the node to be generated. \
`const shared_ptr<GameTreeNode>& parent`: A shared pointer to the parent node of the node being generated.

**Code Description**: This method begins by extracting the metadata from the provided JSON object and validating the `round` and `node_type` fields. It ensures that the `round` is one of the valid poker rounds (`preflop`, `flop`, `turn`, `river`) and that the `node_type` is one of the valid node types (`Terminal`, `Showdown`, `Action`, `Chance`). 

Depending on the `node_type`, the method then generates the appropriate type of game tree node:
- For `Action` nodes, it retrieves the list of children actions and corresponding children nodes, ensuring their sizes match, and calls `generateActionNode`.
- For `Showdown` nodes, it calls `generateShowdownNode`.
- For `Terminal` nodes, it calls `generateTerminalNode`.
- For `Chance` nodes, it ensures there is exactly one child node and calls `generateChanceNode`.

If the `node_type` is not recognized, it throws a runtime error. The method returns a dynamically cast shared pointer to the generated `GameTreeNode`.\\
## Code: 
```
shared_ptr<GameTreeNode> GameTree::recurrentGenerateTreeNode(json node_json, const shared_ptr<GameTreeNode>& parent) {
    json meta = node_json["meta"];
    string round = meta["round"];
    if(round.empty()){
        throw runtime_error("node json get round null pointer");
    }

    if(! (round == "preflop"
          || round == "flop"
          || round == "turn"
          || round == "river"
          )
            ){
        throw runtime_error(tfm::format("round %s not found",round));
    }

    string node_type = meta["node_type"];
    if(node_type.empty()){
        throw runtime_error("node json get round null pointer");
    }
    if (! (   node_type == "Terminal"
           || node_type == "Showdown"
           || node_type ==  "Action"
           || node_type ==  "Chance"
    )
            ){
        throw runtime_error(tfm::format("node type %s not found",node_type));
    }

    if(node_type == "Action") {
        // 孩子节点的动作，存在list里
        auto childrens_actions = node_json["children_actions"].get<std::vector<string>>();
        // 孩子节点本身，同样存在list里,和上面的children_actions 一一对应,事实上两者的长度一致
        vector<json> childrens = node_json["children"].get<std::vector<json>>();
        if (childrens.size() != childrens_actions.size()) {
            throw runtime_error("action node child length mismatch");
        }
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateActionNode(meta, childrens_actions, childrens, round,parent));
    }
    else if(node_type == "Showdown") {
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateShowdownNode(meta, round,parent));
    }
    else if(node_type == "Terminal") {
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateTerminalNode(meta, round,parent));
    }
    else if(node_type == "Chance") {
        auto childrens = node_json["children"].get<std::vector<json>>();
        if(childrens.size() != 1) throw runtime_error("Chance node should have only one child");
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateChanceNode(meta, childrens[0], round,parent));
    }
    else{
        throw runtime_error(tfm::format("node type %s not found",node_type));
    }
}
```