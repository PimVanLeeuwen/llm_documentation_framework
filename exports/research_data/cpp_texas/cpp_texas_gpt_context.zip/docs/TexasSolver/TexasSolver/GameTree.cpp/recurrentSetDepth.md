`recurrentSetDepth`: The function of `recurrentSetDepth` is to set the depth and calculate the subtree size for each node in a game tree recursively.

**Parameters**:\
`shared_ptr<GameTreeNode> node`: A shared pointer to the current node in the game tree. \
`int depth`: The depth level of the current node in the game tree.

**Code Description**: This method sets the depth of the given node and calculates the size of its subtree. It first assigns the provided depth to the node. If the node is of type `ACTION`, it dynamically casts the node to an `ActionNode`, iterates through its children, and recursively calls `recurrentSetDepth` on each child, accumulating the subtree sizes. If the node is of type `CHANCE`, it dynamically casts the node to a `ChanceNode`, recursively calls `recurrentSetDepth` on its single child, and multiplies the result by the number of cards associated with the `ChanceNode`. For other node types, it sets the subtree size to 1. Finally, it returns the calculated subtree size for the node.\\
## Code: 
```
int GameTree::recurrentSetDepth(shared_ptr<GameTreeNode> node, int depth) {
    node->depth = depth;
    if(node->getType() == GameTreeNode::ACTION) {
        shared_ptr<ActionNode> actionNode = std::dynamic_pointer_cast<ActionNode>(node);
        int subtree_size = 1;
        for(shared_ptr<GameTreeNode> one_child:actionNode->getChildrens()){
            subtree_size += this->recurrentSetDepth(one_child,depth + 1);
        }
        node->subtree_size = subtree_size;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chanceNode = std::dynamic_pointer_cast<ChanceNode>(node);
        int subtree_size = 1;
        subtree_size += this->recurrentSetDepth(chanceNode->getChildren(),depth + 1) * chanceNode->getCards().size();
        node->subtree_size = subtree_size;
    }else{
        node->subtree_size = 1;
    }
    return node->subtree_size;
}
```