`strToGameRound`: The function of `strToGameRound` is to convert a string representing a poker game round into its corresponding `GameTreeNode::GameRound` enumeration value.

**Parameters**:\
`const string& round`: A string representing the name of the poker game round (e.g., "preflop", "flop", "turn", "river").

**Code Description**: The `strToGameRound` method takes a string input and matches it to one of the predefined poker game rounds. It checks the input string against known round names ("preflop", "flop", "turn", "river") and assigns the corresponding `GameTreeNode::GameRound` enumeration value. If the input string does not match any of the known round names, the method throws a runtime error indicating that the game round was not found. The function returns the matched `GameTreeNode::GameRound` enumeration value.\\
## Code: 
```
GameTreeNode::GameRound GameTree::strToGameRound(const string& round) {
    GameTreeNode::GameRound game_round;
    if(round == "preflop"){
        game_round = GameTreeNode::GameRound::PREFLOP;
    }
    else if (round == "flop"){
        game_round = GameTreeNode::GameRound::FLOP;
    }
    else if(round == "turn"){
        game_round = GameTreeNode::GameRound::TURN;
    }
    else if(round == "river"){
        game_round = GameTreeNode::GameRound::RIVER;
    }
    else{
        throw runtime_error(tfm::format("game round not found: %s",round));
    }
    return game_round;
}
```