`re_estimate_tree_memory`: The function of `re_estimate_tree_memory` is to recursively estimate the memory usage of a game tree in a poker game.

**Parameters**:\
`const shared_ptr<GameTreeNode>& node`: A shared pointer to the current node in the game tree. This node can be either an `ActionNode` or a `ChanceNode`.\
`int deck_num`: The number of cards in the deck.\
`int p1range_num`: The number of possible hands for player 1.\
`int p2range_num`: The number of possible hands for player 2.\
`int num_current_deal`: The current number of deals being considered.

**Code Description**: This method estimates the memory usage of a game tree by traversing it recursively. It first checks the type of the current node. If the node is an `ActionNode`, it retrieves its children and actions, then recursively calls `re_estimate_tree_memory` on each child. It calculates the memory usage based on the number of current deals and the range of possible hands for the player associated with the node. If the node is a `ChanceNode`, it retrieves its child and recursively calls `re_estimate_tree_memory` on the child, adjusting the number of current deals by multiplying it with the number of cards in the deck. The function returns the total estimated memory usage for the subtree rooted at the given node.\\
## Code: 
```
long long GameTree::re_estimate_tree_memory(const shared_ptr<GameTreeNode>& node,int deck_num,int p1range_num,int p2range_num,int num_current_deal){
    if(node->getType() == GameTreeNode::ACTION){
        shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
        vector<shared_ptr<GameTreeNode>> childrens = action_node->getChildrens();
        vector<GameActions> actions = action_node->getActions();

        long long retnum = 0;
        for(std::size_t i = 0;i < childrens.size();i++){
            shared_ptr<GameTreeNode> one_child = childrens[i];
            retnum += re_estimate_tree_memory(one_child,deck_num, p1range_num, p2range_num, num_current_deal);
        }
        if(action_node->getPlayer() == 0){
            retnum += num_current_deal * p1range_num * (childrens.size() + 1) * 3;
        }else{
            retnum += num_current_deal * p2range_num * (childrens.size() + 1) * 3;
        }
        return retnum;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
        shared_ptr<GameTreeNode> children = chance_node->getChildren();
        return re_estimate_tree_memory(children,deck_num, p1range_num, p2range_num, num_current_deal * (deck_num));
    }
    return 0;
}
```