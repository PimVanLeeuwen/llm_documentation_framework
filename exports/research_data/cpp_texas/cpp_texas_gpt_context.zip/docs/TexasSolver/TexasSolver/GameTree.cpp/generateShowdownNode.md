`generateShowdownNode`: The function of `generateShowdownNode` is to create and initialize a `ShowdownNode` object based on the provided metadata, game round, and parent node.

**Parameters**:\
`json meta`: A JSON object containing metadata about the game, including payoffs for each player and the pot size. \
`string round`: A string representing the current round of the poker game (e.g., "preflop", "flop", "turn", "river"). \
`shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node in the game tree.

**Code Description**: This method begins by extracting the payoffs for each player and the tie payoffs from the provided JSON metadata. It initializes vectors to store the payoffs for two players and retrieves the pot size from the metadata. The method then iterates over the player payoffs in the metadata, skipping the tie payoffs, and assigns the payoffs to the corresponding player based on their ID. It converts the round string to a `GameTreeNode::GameRound` enum value using the `strToGameRound` method. Finally, it creates and returns a shared pointer to a new `ShowdownNode` object, initialized with the tie payoffs, player payoffs, game round, pot, and parent node.\\
## Code: 
```
shared_ptr<ShowdownNode> GameTree::generateShowdownNode(json meta, string round, shared_ptr<GameTreeNode> parent) {
    json meta_payoffs = meta["payoffs"];
    vector<double> tie_payoffs = meta_payoffs["tie"];

    // meta_payoffs 的key有 n个玩家+1个平局,代表某个玩家赢了的时候如何分配payoff
    vector<vector<double>> player_payoffs(2);
    double pot = meta["pot"];

    for(auto one_player_meta=meta_payoffs.begin(); one_player_meta!=meta_payoffs.end(); one_player_meta++){
        const string& one_player = one_player_meta.key();
        if(one_player == "tie"){
            continue;
        }
        // 获胜玩家id
        int player_id = atoi(one_player.c_str());
        if(player_id < 0 or player_id > 1) throw runtime_error("player id json convert fail");

        // 玩家在当前Showdown节点能获得的收益
        //List<Object> tmp_payoffs =  (List<Object>)meta_payoffs.get(one_player);
        vector<double> player_payoff = one_player_meta.value();

        player_payoffs[atoi(one_player.c_str())] = player_payoff;
    }
    GameTreeNode::GameRound game_round = strToGameRound(std::move(round));
    return make_shared<ShowdownNode>(tie_payoffs,player_payoffs,game_round,pot,parent);
}
```