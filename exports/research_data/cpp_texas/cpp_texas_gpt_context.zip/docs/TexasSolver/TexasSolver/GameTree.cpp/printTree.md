`printTree`: The function of `printTree` is to print the structure of the game tree up to a specified depth.

**Parameters**:\
`int depth`: The depth up to which the game tree should be printed. A value of -1 indicates that the entire tree should be printed, while positive values specify the number of levels to print.

**Code Description**: The `printTree` method in the `GameTree` class is responsible for printing the structure of the game tree up to a specified depth. It first checks if the provided depth is valid (either -1 or a positive integer). If the depth is invalid, it throws a runtime error. If the depth is valid, it initializes a vector to store prefixes and then calls the `recurrentPrintTree` method, starting from the root of the tree and with the initial depth set to 0. The `recurrentPrintTree` method handles the actual recursive printing of the tree structure.\\
## Code: 
```
void GameTree::printTree(int depth) {
    if(depth < -1 || depth == 0){
        throw runtime_error("depth can only be -1 or positive");
    }
    vector<string> prefix;
    this->recurrentPrintTree(this->root,0,depth);
}
```