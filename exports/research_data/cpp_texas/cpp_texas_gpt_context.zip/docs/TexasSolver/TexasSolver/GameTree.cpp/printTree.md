`printTree`: The function of `printTree` is to print the game tree structure according to a given depth.

**Parameters**:\
`int depth`: This parameter specifies the level of detail in which the game tree should be printed, with -1 indicating no printing and positive values indicating the maximum depth to which the tree should be traversed.

**Code Description**: The `printTree` function initializes a recursive traversal of the game tree starting from its root node. It calls the `recurrentPrintTree` method to perform this traversal, passing in the current node and the specified depth as parameters. This allows for efficient printing of the game tree at various levels of detail.\\
## Code: 
```
void GameTree::printTree(int depth) {
    if(depth < -1 || depth == 0){
        throw runtime_error("depth can only be -1 or positive");
    }
    vector<string> prefix;
    this->recurrentPrintTree(this->root,0,depth);
}
```