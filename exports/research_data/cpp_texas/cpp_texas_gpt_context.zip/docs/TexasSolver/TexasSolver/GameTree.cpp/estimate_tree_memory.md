`estimate_tree_memory`: The function of `estimate_tree_memory` is to estimate the memory usage of the game tree based on the given parameters.

**Parameters**:\
`int deck_num`: The number of cards in the deck.\
`int p1range_num`: The number of possible hands or ranges for player 1.\
`int p2range_num`: The number of possible hands or ranges for player 2.\
`int num_current_deal`: The number of cards currently dealt.

**Code Description**: This method calls the `re_estimate_tree_memory` method on the root of the game tree, passing along the parameters to estimate the memory usage of the game tree. The result is returned as a `long long` value representing the estimated memory in bytes.\\
## Code: 
```
long long GameTree::estimate_tree_memory(int deck_num,int p1range_num,int p2range_num,int num_current_deal){
    return this->re_estimate_tree_memory(this->root,deck_num, p1range_num, p2range_num, num_current_deal);
}
```