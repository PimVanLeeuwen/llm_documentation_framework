`generateChanceNode`: The function of `generateChanceNode` is to create and initialize a `ChanceNode` in the game tree based on the provided metadata, child node, game round, and parent node.

**Parameters**:\
`json meta`: A JSON object containing metadata for the node, including the pot size.\
`const json& child`: A JSON object representing the child node configuration.\
`string round`: A string indicating the current game round (e.g., "preflop", "flop", "turn", "river").\
`shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node of the new `ChanceNode`.

**Code Description**: This method first extracts the pot size from the `meta` JSON object. It then generates a child node by calling `recurrentGenerateTreeNode` with the `child` JSON object. The game round string is converted to its corresponding `GameTreeNode::GameRound` enum value using `strToGameRound`. A new `ChanceNode` is created with the generated child node, game round, pot size, parent node, and the deck's cards. The child node's parent is set to the newly created `ChanceNode`. Finally, the method returns the newly created `ChanceNode`.\\
## Code: 
```
shared_ptr<ChanceNode>
GameTree::generateChanceNode(json meta, const json& child, string round, shared_ptr<GameTreeNode> parent) {
    //节点上的下注额度
    double pot = meta["pot"];
    shared_ptr<GameTreeNode> one_child = recurrentGenerateTreeNode(child, nullptr);
    GameTreeNode::GameRound game_round = strToGameRound(std::move(round));
    shared_ptr<ChanceNode> chanceNode = make_shared<ChanceNode>(one_child,game_round,pot,parent,this->deck.getCards());
    shared_ptr<GameTreeNode> gameTreeNode = chanceNode->getChildren();
    gameTreeNode->setParent(chanceNode);
    return chanceNode;
}
```