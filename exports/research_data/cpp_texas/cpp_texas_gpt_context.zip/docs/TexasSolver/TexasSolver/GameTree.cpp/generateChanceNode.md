`generateChanceNode`: The function of `generateChanceNode` is to generate a chance node in the game tree.

**Parameters**:
- `json meta`: A JSON object containing metadata for the chance node, including the pot.
- `const json& child`: A reference to a JSON object representing the child node.
- `string round`: The string representation of the current game round.
- `shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node in the game tree.

**Code Description**: 
The function generates a chance node by creating a new instance of the ChanceNode class, passing in the provided parameters. It then sets the parent of the child node to the newly created chance node and returns the chance node itself. The function also calls other methods such as `strToGameRound` to convert the game round string into an enum value and `recurrentGenerateTreeNode` to generate a child node based on the provided metadata.\\
## Code: 
```
shared_ptr<ChanceNode>
GameTree::generateChanceNode(json meta, const json& child, string round, shared_ptr<GameTreeNode> parent) {
    //节点上的下注额度
    double pot = meta["pot"];
    shared_ptr<GameTreeNode> one_child = recurrentGenerateTreeNode(child, nullptr);
    GameTreeNode::GameRound game_round = strToGameRound(std::move(round));
    shared_ptr<ChanceNode> chanceNode = make_shared<ChanceNode>(one_child,game_round,pot,parent,this->deck.getCards());
    shared_ptr<GameTreeNode> gameTreeNode = chanceNode->getChildren();
    gameTreeNode->setParent(chanceNode);
    return chanceNode;
}
```