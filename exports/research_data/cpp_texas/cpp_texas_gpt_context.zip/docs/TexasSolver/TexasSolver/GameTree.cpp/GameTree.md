`GameTree`: The function of `GameTree` is to initialize the game tree for a poker game scenario based on the provided parameters and settings.

**Parameters**:\
`Deck deck`: The deck of cards used in the game.\
`float oop_commit`: The amount of chips committed by the out-of-position player.\
`float ip_commit`: The amount of chips committed by the in-position player.\
`int current_round`: The current round of the game (e.g., pre-flop, flop, turn, river).\
`int raise_limit`: The maximum number of raises allowed in the current round.\
`float small_blind`: The value of the small blind in the game.\
`float big_blind`: The value of the big blind in the game.\
`float stack`: The total stack size for each player.\
`GameTreeBuildingSettings buildingSettings`: Settings that control how the game tree is built.\
`float allin_threshold`: The threshold at which a player is considered to be all-in.

**Code Description**: The `GameTree` constructor initializes a game tree for a poker game by first creating a `Rule` object with the provided parameters. It sets the current player to 1 and converts the current round integer to a `GameRound` enum. An `ActionNode` is then created as the root node of the game tree, initialized with empty game actions, child nodes, the current player, the game round, the pot size, and no parent node. The `__build` method is called to construct the rest of the game tree, and the root node is assigned to the `root` attribute of the `GameTree` object.\\
## Code: 
```
GameTree::GameTree(Deck deck,
                   float oop_commit,
                   float ip_commit,
                   int current_round,
                   int raise_limit,
                   float small_blind,
                   float big_blind,
                   float stack,
                   GameTreeBuildingSettings buildingSettings,
                   float allin_threshold
){
    Rule rule = Rule(deck,oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,buildingSettings,allin_threshold);
    int current_player = 1;
    this->deck = deck;
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(rule.current_round);
    shared_ptr<ActionNode> node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(),current_player, round, (double) rule.get_pot(),
                                 nullptr);
    this->__build(node,rule);
    this->root = node;
}
```