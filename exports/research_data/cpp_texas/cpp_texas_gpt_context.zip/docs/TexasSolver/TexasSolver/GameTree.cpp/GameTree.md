`GameTree`: The function of `GameTree` is to initialize and build a game tree for Texas Hold'em poker.

**Parameters**:
`Deck deck`: A representation of the deck used in the game.
`float oop_commit`: The odds-on commitment value, which determines the betting structure.
`float ip_commit`: The odds-off commitment value, which also affects the betting structure.
`int current_round`: The current round number in the game.
`int raise_limit`: The maximum number of raises allowed in a hand.
`float small_blind`: The size of the small blind bet.
`float big_blind`: The size of the big blind bet.
`float stack`: The initial stack size for each player.
`GameTreeBuildingSettings buildingSettings`: Settings used to build the game tree, such as the depth and breadth of the tree.
`float allin_threshold`: A threshold value that determines when a player is considered "all-in".

**Code Description**: This code defines a constructor for the `GameTree` class, which initializes various member variables based on input parameters. It creates a new `Rule` object using the provided deck and betting settings, then uses this rule to build a game tree starting from an initial node. The tree is built recursively by calling the `__build` method, which is not shown in this code snippet but presumably handles the recursive construction of the game tree.\\
## Code: 
```
GameTree::GameTree(Deck deck,
                   float oop_commit,
                   float ip_commit,
                   int current_round,
                   int raise_limit,
                   float small_blind,
                   float big_blind,
                   float stack,
                   GameTreeBuildingSettings buildingSettings,
                   float allin_threshold
){
    Rule rule = Rule(deck,oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,buildingSettings,allin_threshold);
    int current_player = 1;
    this->deck = deck;
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(rule.current_round);
    shared_ptr<ActionNode> node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(),current_player, round, (double) rule.get_pot(),
                                 nullptr);
    this->__build(node,rule);
    this->root = node;
}
```