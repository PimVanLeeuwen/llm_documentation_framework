`getRoot`: The function of `getRoot` is to return the root node of the game tree.

**Code Description**: This method, `getRoot`, is a member of the `GameTree` class. It returns a shared pointer to the root node of the game tree, which is stored in the `root` member variable of the `GameTree` instance. The return type is `shared_ptr<GameTreeNode>`, indicating that the root node is managed using a shared pointer for automatic memory management.\\
## Code: 
```
shared_ptr<GameTreeNode> GameTree::getRoot() {
    return this->root;
}
```