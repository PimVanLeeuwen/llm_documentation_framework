`generateActionNode`: The function of `generateActionNode` is to create an `ActionNode` in the game tree based on the provided metadata, children's actions, children's nodes, the current round, and the parent node.

**Parameters**:\
`json meta`: A JSON object containing metadata about the current game state, including the player and pot size. \
`vector<string> childrens_actions`: A vector of strings representing the actions taken by the children nodes. \
`vector<json> childrens_nodes`: A vector of JSON objects representing the children nodes in the game tree. \
`const string& round`: A string representing the current round of the game (e.g., "preflop", "flop", "turn", "river"). \
`shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node in the game tree.

**Code Description**: The `generateActionNode` method first checks if the sizes of `childrens_actions` and `childrens_nodes` match, throwing a runtime error if they do not. It then validates the `round` parameter to ensure it is one of the recognized game rounds. The method iterates over the `childrens_actions` to create a list of `GameActions` and corresponding child nodes. For each action, it determines the type of poker action (e.g., check, fold, call, bet, raise) and the associated amount if applicable. It then recursively generates the child nodes using the `recurrentGenerateTreeNode` method. After creating the actions and child nodes, it validates their sizes to ensure they match. The method converts the `round` string to a `GameTreeNode::GameRound` enum value and creates an `ActionNode` with the generated actions, child nodes, player, game round, pot, and parent. Finally, it sets the parent of each child node to the newly created `ActionNode` and returns the `ActionNode`.\\
## Code: 
```
shared_ptr<ActionNode>
GameTree::generateActionNode(json meta, vector<string> childrens_actions, vector<json> childrens_nodes, const string& round,
                             shared_ptr<GameTreeNode> parent) {
    if(childrens_actions.size() != childrens_nodes.size()){
        throw runtime_error(
                tfm::format(
                        "mismatch when generate ActionNode, childrens_action length %s children_nodes length %s",
                        childrens_actions.size(),
                        childrens_nodes.size()
                ));
    }

    if(! (   round == "preflop"
          || round == "flop"
          || round == "turn"
          || round == "river"
          )
            ){
        throw runtime_error(tfm::format("round %s not found",round));
    }

    vector<GameActions> actions;
    vector<shared_ptr<GameTreeNode>> childrens;

    // 遍历所有children actions 来生成GameAction 的list，用于初始化ActionNode
    for(std::size_t i = 0;i < childrens_actions.size();i++){
        string one_action = childrens_actions[i];
        json one_children_map = childrens_nodes[i];
        if(one_action.empty()) throw runtime_error("action is null");

        GameTreeNode::PokerActions action;
        double amount = -1;
        if(one_action == "check"){
            action = GameTreeNode::PokerActions::CHECK;
        }
        else if(one_action == "fold"){
            action = GameTreeNode::PokerActions::FOLD;
        }
        else if(one_action == "call"){
            action = GameTreeNode::PokerActions::CALL;
        }
        else{
            if(one_action.find("bet")  != string::npos){
                vector<string> action_sp = string_split(one_action,'_');
                if(action_sp.size() != 2)
                    throw runtime_error(tfm::format("bet action sp length %s",action_sp.size()));
                string action_str = action_sp[0];
                action = GameTreeNode::PokerActions::BET;
                if(!(action_str == "bet")) throw runtime_error(tfm::format("Action %s not found",action_str));
                amount = stod(action_sp[1]);

            }else if (one_action.find("raise") != string::npos){
                vector<string> action_sp = string_split(one_action,'_');
                if(action_sp.size() != 2)
                    throw runtime_error(tfm::format("raise action sp length %s",action_sp.size()));
                string action_str = action_sp[0];
                action = GameTreeNode::PokerActions::RAISE;
                if(!(action_str == "raise"))
                    throw runtime_error(tfm::format("Action %s not found",action_str));
                amount = stod(action_sp[1]);
            }else{
                throw runtime_error(tfm::format("%s action not found",one_action));
            }
        }
        shared_ptr<GameTreeNode> one_children_node = recurrentGenerateTreeNode(one_children_map,parent);
        childrens.push_back(one_children_node);

        GameActions game_action = GameActions(action,amount);
        actions.push_back(game_action);
    }
    int player = meta["player"];
    double pot = meta["pot"];
    if(childrens.size() != actions.size()){
        throw runtime_error(tfm::format("childrens length %s, actions length %s"
                ,childrens.size()
                ,actions.size()));
    }
    GameTreeNode::GameRound game_round = strToGameRound(round);
    shared_ptr<ActionNode> actionNode = make_shared<ActionNode>(actions,childrens,player,game_round,pot,parent);
    for(const shared_ptr<GameTreeNode>& one_node: childrens){
        one_node->setParent(std::dynamic_pointer_cast<GameTreeNode>(actionNode));
    }
    return actionNode;

}
```