`round_nearest`: The function of `round_nearest` is to round a given number to the nearest multiple of another specified number.
**Parameters**:\
`double number`: The number that needs to be rounded.\
`double round_num`: The number to which `number` will be rounded to the nearest multiple of.

**Code Description**: The `round_nearest` method takes two parameters: `number` and `round_num`. It first calculates the reciprocal of `round_num` and stores it back in `round_num`. Then, it multiplies `number` by this reciprocal, rounds the result to the nearest integer, and finally divides the rounded result by the reciprocal of `round_num` to obtain the number rounded to the nearest multiple of the original `round_num`.\\
## Code: 
```
double GameTree::round_nearest(double number, double round_num) {
    round_num = 1 / round_num;
    return round((number * round_num)) / round_num;

}
```