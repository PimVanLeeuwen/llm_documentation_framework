`__build`: The function of `__build` is to construct and initialize different types of game tree nodes based on the node type.

**Parameters**:\
`shared_ptr<GameTreeNode> node`: A shared pointer to the current game tree node that needs to be built or initialized. \
`Rule rule`: The game rule set that dictates how the game should be played and how nodes should be constructed. \
`string last_action`: The last action taken in the game, which may influence the construction of the current node. \
`int check_times`: The number of times a check action has been performed, used to manage game state and node construction. \
`int raise_times`: The number of times a raise action has been performed, used to manage game state and node construction.

**Code Description**: The `__build` method is responsible for constructing different types of game tree nodes based on the type of the provided node. It uses a switch statement to determine the node type and calls the appropriate method to build the node:

- If the node type is `ACTION`, it calls `buildAction` to construct an `ActionNode`.
- If the node type is `SHOWDOWN` or `TERMINAL`, it does nothing and simply breaks out of the switch statement.
- If the node type is `CHANCE`, it calls `buildChance` to construct a `ChanceNode`.
- If the node type is unknown, it throws a runtime error indicating an unknown node type.

The method returns the constructed or initialized node.\\
## Code: 
```
shared_ptr<GameTreeNode> GameTree::__build(shared_ptr<GameTreeNode> node, Rule rule, string last_action,
                                           int check_times, int raise_times) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            this->buildAction(std::dynamic_pointer_cast<ActionNode>(node),rule,last_action,check_times,raise_times);
            break;
        }case GameTreeNode::SHOWDOWN: {
            break;
        }case GameTreeNode::TERMINAL: {
            break;
        }case GameTreeNode::CHANCE: {
            this->buildChance(std::dynamic_pointer_cast<ChanceNode>(node),rule);
            break;
        }default:
            throw runtime_error("node type unknown");
    }
    return node;
}
```