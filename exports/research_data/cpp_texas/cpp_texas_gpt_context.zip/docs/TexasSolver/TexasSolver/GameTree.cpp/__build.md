## Expected output
`__build`: The function of `__build` is to recursively build the game tree by processing each node based on its type.
**Parameters**:\
`shared_ptr<GameTreeNode> node`: A pointer to the current node in the game tree being built.
`Rule rule`: The set of rules governing the game, used for decision-making and gameplay progression.
`string last_action`: The most recent action taken in the game, influencing subsequent decisions.
`int check_times`: The number of times a player has checked during their turn.
`int raise_times`: The number of times a player has raised the bet during their turn.

**Code Description**: This function uses a switch statement to determine the type of the current node and calls specific methods (`buildAction`, `buildChance`) based on that type. If the node type is unknown, it throws a runtime error.\\
## Code: 
```
shared_ptr<GameTreeNode> GameTree::__build(shared_ptr<GameTreeNode> node, Rule rule, string last_action,
                                           int check_times, int raise_times) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            this->buildAction(std::dynamic_pointer_cast<ActionNode>(node),rule,last_action,check_times,raise_times);
            break;
        }case GameTreeNode::SHOWDOWN: {
            break;
        }case GameTreeNode::TERMINAL: {
            break;
        }case GameTreeNode::CHANCE: {
            this->buildChance(std::dynamic_pointer_cast<ChanceNode>(node),rule);
            break;
        }default:
            throw runtime_error("node type unknown");
    }
    return node;
}
```