`getCards`: The function of `getCards` is to return a reference to the vector of `Card` objects contained within the `Deck` object.

**Code Description**: This method, `getCards`, is a member of the `Deck` class. It returns a reference to the private member variable `cards`, which is a vector containing `Card` objects. This allows external code to access and manipulate the deck's cards directly.\\
## Code: 
```
vector<Card>& Deck::getCards() {
    return this->cards;
}
```