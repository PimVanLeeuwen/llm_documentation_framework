`Deck`: The function of `Deck` is to initialize a deck of cards with given ranks and suits.

**Parameters**:\
`const vector<string>& ranks`: A vector of strings representing the ranks of the cards (e.g., "2", "3", "4", ..., "K", "A").\
`const vector<string>& suits`: A vector of strings representing the suits of the cards (e.g., "Hearts", "Diamonds", "Clubs", "Spades").

**Code Description**: The constructor initializes the `Deck` object by storing the provided ranks and suits. It then generates all possible combinations of ranks and suits to create a full deck of cards. Each card is represented as a string (e.g., "2Hearts") and is stored in the `cards_str` vector. Additionally, each card is paired with a unique integer identifier and stored in the `cards` vector as a tuple. The integer identifier starts at 0 and increments by 1 for each new card.\\
## Code: 
```
Deck::Deck(const vector<string>& ranks, const vector<string>& suits) {
    this->ranks = ranks;
    this->suits = suits;
    int card_num = 0;
    for(const string& one_rank : ranks){
        for(const string& one_suit: suits){
            string one_card = one_rank + one_suit;
            cards_str.push_back(one_card);
            cards.emplace_back(one_card,card_num);
            card_num += 1;
        }
    }
}
```