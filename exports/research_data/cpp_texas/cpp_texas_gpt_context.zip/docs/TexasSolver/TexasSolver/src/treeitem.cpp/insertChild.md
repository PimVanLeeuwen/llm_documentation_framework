`insertChild`: The function of `insertChild` is to insert a child item into the list of child items at a specified position or append it if the position is out of range.

**Parameters**:\
`TreeItem *child`: A pointer to the child item that needs to be inserted.\
`int i`: The index at which the child item should be inserted. If the index is out of range (negative or greater than the current count of child items), the child item is appended to the end of the list.

**Code Description**: The `insertChild` method first checks if the provided index `i` is within the valid range of the current list of child items. If the index is valid, it inserts the child item at the specified position. If the index is out of range, it appends the child item to the end of the list. The method always returns `true` after performing the insertion or append operation.\\
## Code: 
```
bool TreeItem::insertChild(TreeItem *child,int i)
{
    if (i >= m_childItems.count() || i < 0)
        m_childItems.append(child);
    else
        m_childItems.insert(i, child);

    return true;
}
```