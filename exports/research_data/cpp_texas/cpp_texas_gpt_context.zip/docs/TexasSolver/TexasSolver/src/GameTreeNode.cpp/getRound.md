`getRound`: The function of `getRound` is to return the current game round of the `GameTreeNode` object.

**Code Description**: This method, `getRound`, is a member of the `GameTreeNode` class. It returns the value of the `round` attribute, which is of type `GameRound`. The method does not take any parameters and simply accesses and returns the `round` attribute of the `GameTreeNode` instance.\\
## Code: 
```
GameTreeNode::GameRound GameTreeNode::getRound() {
    return this->round;
}
```