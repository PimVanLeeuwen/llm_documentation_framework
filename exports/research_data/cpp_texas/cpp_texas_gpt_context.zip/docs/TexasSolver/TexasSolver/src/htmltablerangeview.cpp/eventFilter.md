`eventFilter`: The function of `eventFilter` is to handle mouse events for a table view, such as mouse button press, mouse move, mouse button release, and mouse leave events, and to track the mouse position and emit signals based on these events.

**Parameters**:\
`QObject *watched`: The object that is being watched for events. In this context, it is the viewport of the table view.\
`QEvent *event`: The event that occurred, which can be a mouse button press, mouse move, mouse button release, or mouse leave event.

**Code Description**: The `eventFilter` method is designed to intercept and handle specific mouse events for a table view's viewport. When a mouse button is pressed, it records the row and column of the cell where the press occurred and starts tracking the mouse. When the mouse moves, it updates the last known position and emits a signal if the mouse is being tracked. When the mouse button is released, it stops tracking and emits a signal indicating the release position. If the mouse leaves the viewport, it stops tracking. The method returns the result of the base class's `eventFilter` method for any events it does not handle.\\
## Code: 
```
bool HtmlTableRangeView::eventFilter(QObject *watched, QEvent *event){
    if(viewport() == watched){
        if(event->type() == QEvent::MouseButtonPress){
            QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
            QModelIndex index = indexAt(mouseEvent->pos());
            if(index.isValid()){
                int i = index.row();
                int j = index.column();
                mouseTracker.tracking = true;
                mouseTracker.pressed_i = i;
                mouseTracker.pressed_j = j;
            }
        }
        else if(event->type() == QEvent::MouseMove){
            QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
            QModelIndex index = indexAt(mouseEvent->pos());
            if(index.isValid()){
                int i = index.row();
                int j = index.column();
                if(i != this->last_bearing_i || j != last_bearing_j){
                    this->last_bearing_i = i;
                    this->last_bearing_j = j;
                    if(mouseTracker.tracking == true){
                        emit view_item_area(mouseTracker.pressed_i,mouseTracker.pressed_j,i,j);
                    }
                }
            }
        }
        else if(event->type() == QEvent::MouseButtonRelease){
            QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
            QModelIndex index = indexAt(mouseEvent->pos());
            if(index.isValid()){
                int i = index.row();
                int j = index.column();
                mouseTracker.tracking = false;
                emit item_release(i,j);
            }
        }
        else if(event->type() == QEvent::Leave){
                mouseTracker.tracking = false;
        }else{

        }
    }
    return QTableView::eventFilter(watched, event);
}
```