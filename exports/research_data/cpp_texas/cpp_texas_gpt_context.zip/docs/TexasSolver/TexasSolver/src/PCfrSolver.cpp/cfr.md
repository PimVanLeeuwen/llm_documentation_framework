`cfr`: The function of `cfr` is to compute the counterfactual regret minimization (CFR) utility for a given player at a specific node in the game tree, based on the type of node encountered.

**Parameters**:\
`int player`: The index of the player for whom the utility is being calculated.\
`shared_ptr<GameTreeNode> node`: A shared pointer to the current node in the game tree.\
`const vector<float> &reach_probs`: A vector representing the reach probabilities for each player up to the current node.\
`int iter`: The current iteration number of the CFR algorithm.\
`uint64_t current_board`: The current state of the game board, represented as a 64-bit integer.\
`int deal`: The current deal number or identifier.

**Code Description**: The `cfr` method determines the type of the current game tree node and delegates the utility calculation to the appropriate utility function based on the node type. It handles four types of nodes: `ACTION`, `SHOWDOWN`, `TERMINAL`, and `CHANCE`. For each node type, it dynamically casts the node to its specific type and calls the corresponding utility function (`actionUtility`, `showdownUtility`, `terminalUtility`, or `chanceUtility`). If the node type is unknown, it throws a runtime error. This method is essential for traversing the game tree and computing the expected utility for the player using the CFR algorithm.\\
## Code: 
```
vector<float> PCfrSolver::cfr(int player, shared_ptr<GameTreeNode> node, const vector<float> &reach_probs, int iter,
                                    uint64_t current_board,int deal) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
            return actionUtility(player, action_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::SHOWDOWN: {
            shared_ptr<ShowdownNode> showdown_node = std::dynamic_pointer_cast<ShowdownNode>(node);
            return showdownUtility(player, showdown_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::TERMINAL: {
            shared_ptr<TerminalNode> terminal_node = std::dynamic_pointer_cast<TerminalNode>(node);
            return terminalUtility(player, terminal_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::CHANCE: {
            shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
            return chanceUtility(player, chance_node, reach_probs, iter, current_board,deal);
        }default:
            throw runtime_error("node type unknown");
    }
}
```