`PrivateCards`: The function of `PrivateCards` is to initialize an object representing a pair of private cards in a poker game, along with their associated weight and calculated properties.

**Parameters**:\
`int card1`: The ID of the first card, represented as an integer. \
`int card2`: The ID of the second card, represented as an integer. \
`float weight`: The weight or probability associated with this pair of cards.

**Code Description**: The `PrivateCards` constructor initializes the private cards with the given card IDs and weight. It sets the `card1` and `card2` attributes to the provided values and initializes the `weight` attribute. The `relative_prob` attribute is set to 0. The `card_vec` attribute is initialized as a vector containing `card1` and `card2`. The `hash_code` attribute is calculated based on the card IDs, ensuring a unique identifier for the card pair. If `card1` is greater than `card2`, the hash code is computed as `card1 * 52 + card2`; otherwise, it is `card2 * 52 + card1`. Finally, the `board_long` attribute is set by converting the `card_vec` to a long integer using the `Card::boardInts2long` method.\\
## Code: 
```
PrivateCards::PrivateCards(int card1, int card2, float weight) {
    this->card1 = card1;
    this->card2 = card2;
    this->weight = weight;
    this->relative_prob = 0;
    this->card_vec = vector<int>{this->card1,this->card2};
    if (card1 > card2){
        this->hash_code = card1 * 52 + card2;
    }else{
        this->hash_code = card2 * 52 + card1;
    }
    this->board_long = Card::boardInts2long(this->card_vec);
}
```