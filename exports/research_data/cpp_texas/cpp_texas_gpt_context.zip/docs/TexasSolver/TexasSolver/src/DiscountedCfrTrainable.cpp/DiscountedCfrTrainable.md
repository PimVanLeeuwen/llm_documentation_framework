`DiscountedCfrTrainable`: The function of `DiscountedCfrTrainable` is to initialize an instance of the `DiscountedCfrTrainable` class, setting up the necessary data structures for training using Discounted Counterfactual Regret Minimization (CFR).

**Parameters**:\
`vector<PrivateCards> *privateCards`: A pointer to a vector containing `PrivateCards` objects, representing the private cards held by players. \
`ActionNode &actionNode`: A reference to an `ActionNode` object, representing the current node in the game tree where actions are being considered.

**Code Description**: The constructor initializes the `DiscountedCfrTrainable` object by setting up various vectors to store expected values (evs), immediate regrets (r_plus), cumulative regrets (cum_r_plus), and their sums. It uses the size of the action node's children and the number of private cards to determine the dimensions of these vectors. The `action_node` is assigned from the passed reference, and the sizes of the vectors are calculated based on the number of actions and private cards.\\
## Code: 
```
DiscountedCfrTrainable::DiscountedCfrTrainable(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();

    this->evs = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus_sum = vector<float>(this->card_number,0.0);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number,0.0);
    //this->cum_r_plus_sum = vector<float>(this->card_number);
}
```