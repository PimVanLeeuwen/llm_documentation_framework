`printNodeHistory`: The function of `printNodeHistory` is to print the history of actions leading to the current game tree node in a poker game.

**Parameters**:\
`GameTreeNode* node`: A pointer to the current node in the game tree whose history is to be printed.

**Code Description**: The `printNodeHistory` method is designed to trace back from the given node to the root of the game tree, printing the sequence of actions or events that led to the current node. The method uses a while loop to traverse the parent nodes until it reaches the root (where the parent is `nullptr`). Depending on the type of the parent node (either `ActionNode` or `ChanceNode`), it prints the corresponding action or dealt card that led to the current node. If the parent node is neither an `ActionNode` nor a `ChanceNode`, it prints the node's string representation. The method is currently commented out and contains some syntax errors and incomplete parts, such as missing the actual class definitions and the correct syntax for type checking and casting in C++.\\
## Code: 
```
void GameTreeNode::printNodeHistory(GameTreeNode* node) {
    /*
    while(node != nullptr) {
        shared_ptr<GameTreeNode>parent_node = node->parent;
        if (parent_node == nullptr) break;
        if(parent_node instanceof ActionNode){
            ActionNode action_node = (ActionNode)parent_node;
            for(int i = 0;i < action_node.getActions().size();i ++){
                if(action_node.getChildrens().get(i) == node){
                    System.out.print(String.format("<- (player %s %s)",
                                                   action_node.getPlayer(),
                                                   action_node.getActions().get(i).toString()
                    ));
                }
            }
        }else if(parent_node instanceof ChanceNode) {
            ChanceNode chance_node = (ChanceNode)parent_node;
            for(int i = 0;i < chance_node.getChildrens().size();i ++){
                if(chance_node.getChildrens().get(i) == node){
                    System.out.print(String.format("<- (deal card %s)",
                                                   chance_node.getCards().get(i).toString()
                    ));
                }
            }

        }else{
            System.out.print(String.format("<- (%s)",node.toString()));
        }
        node = parent_node;
    }
    System.out.println()
    }
     */
}
```