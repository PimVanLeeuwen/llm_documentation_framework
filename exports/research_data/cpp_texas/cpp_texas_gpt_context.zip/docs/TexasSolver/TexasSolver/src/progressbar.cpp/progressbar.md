`progressbar`: The function of `progressbar` is to initialize a progress bar object with a specified number of cycles and an option to display the progress bar.

**Parameters**:\
`int n`: The total number of cycles or steps the progress bar will represent.\
`bool showbar`: A boolean flag indicating whether the progress bar should be displayed.

**Code Description**: The constructor `progressbar::progressbar` initializes a progress bar object with the following attributes:
- `progress` is set to 0, representing the initial progress.
- `n_cycles` is set to the value of `n`, representing the total number of cycles or steps.
- `last_perc` is set to 0, representing the last percentage of progress displayed.
- `do_show_bar` is set to the value of `showbar`, determining whether the progress bar should be shown.
- `update_is_called` is set to false, indicating that the update method has not been called yet.
- `done_char` is set to "#", representing the character used to display completed progress.
- `todo_char` is set to " ", representing the character used to display remaining progress.
- `opening_bracket_char` is set to "[", representing the opening bracket of the progress bar.
- `closing_bracket_char` is set to "]", representing the closing bracket of the progress bar.\\
## Code: 
```
progressbar::progressbar(int n, bool showbar) :
        progress(0),
        n_cycles(n),
        last_perc(0),
        do_show_bar(showbar),
        update_is_called(false),
        done_char("#"),
        todo_char(" "),
        opening_bracket_char("["),
        closing_bracket_char("]") {}
```