`load`: The function of `load` is to read and load data from a binary file into two maps, `flush_map` and `other_map`.

**Parameters**:\
`const char* file_path`: The path to the binary file that contains the data to be loaded.

**Code Description**: The `load` method attempts to open a binary file specified by `file_path`. If the file cannot be opened, it throws a runtime error. It then clears the existing data in `flush_map` and `other_map`. The method reads the number of entries (lines) from the file and populates `flush_map` with key-value pairs, where the key is a `uint64_t` and the value is an `int`. It asserts that the size of `flush_map` matches the number of entries read. The method repeats the process for `other_map`, ensuring that its size also matches the number of entries read. Finally, the file is closed, and the method returns `true` to indicate successful loading.\\
## Code: 
```
bool FiveCardsStrength::load(const char* file_path) {
    //ifstream file(file_path, ios::binary);
    /*if (!file) {
        file.close();
        return false;
    }*/

    QFile file(QString::fromStdString(file_path));
    if (!file.open(QIODevice::ReadOnly)){
        throw runtime_error("unable to load compairer file");
    }
    flush_map.clear(); other_map.clear();
    int size_key = sizeof(uint64_t), size_int = sizeof(int), val, cnt = 0;
    uint64_t key = 0;
    char* p_key = (char*)&key, * p_val = (char*)&val, * p_cnt = (char*)&cnt;
    file.read(p_cnt, size_int);// 读取行数
    for (int i = 0; i < cnt; i++) {
        file.read(p_key, size_key);
        file.read(p_val, size_int);
        flush_map[key] = val;
    }
    assert(flush_map.size() == cnt);
    file.read(p_cnt, size_int);// 读取行数
    for (int i = 0; i < cnt; i++) {
        file.read(p_key, size_key);
        file.read(p_val, size_int);
        other_map[key] = val;
    }
    assert(other_map.size() == cnt);
    file.close();
    return true;
}
```