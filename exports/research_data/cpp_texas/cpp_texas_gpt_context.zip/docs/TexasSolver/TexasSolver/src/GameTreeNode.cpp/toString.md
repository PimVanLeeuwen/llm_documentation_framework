`toString`: The function of `toString` is to generate a string representation of the `GameTreeNode` object, detailing its relationship with its parent node.

**Code Description**: The `toString` method is intended to create a string that describes the current `GameTreeNode` object in the context of its parent node. If the parent node is `nullptr`, it returns a string indicating the beginning of a round. If the parent node is of type `ACTION`, it iterates through the actions of the parent node to find the current node and formats a string indicating the player's action. If the parent node is of type `CHANCE`, it iterates through the children of the parent node to find the current node and formats a string indicating the dealt card. However, the current implementation is incomplete and returns an empty string.\\
## Code: 
```
string GameTreeNode::toString(){
    /*
    shared_ptr<GameTreeNode>parent_node = node->parent;
    string round;
    if (parent_node == nullptr) return tfm::format("%s begin",round);
    if(parent_node->getType() == GameTreeNodeType::ACTION){
        ActionNode action_node = (ActionNode)parent_node;
        for(int i = 0;i < action_node.getActions().size();i ++){
            if(action_node.getChildrens().get(i) == node){
                System.out.print(String.format("<- (player %s %s)",
                           action_node.getPlayer(),
                           action_node.getActions().get(i).toString()
                    ));
        }
        }
    }else if(parent_node->getType() == GameTreeNodeType::CHANCE){
        ChanceNode chance_node = (ChanceNode)parent_node;
        for(int i = 0;i < chance_node.getChildrens().size();i ++){
            if(chance_node.getChildrens().get(i) == node){
                System.out.print(String.format("<- (deal card %s)",
                       chance_node.getCards().get(i).toString()
            ));
        }
    }
    */
    return "";
}
```