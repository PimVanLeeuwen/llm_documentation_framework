`getRangeText`: The function of `getRangeText` is to generate a formatted string representing the non-zero values in a 2D grid along with their corresponding string labels.

**Code Description**: The `getRangeText` method iterates through a 2D grid (`grids_float`) and its corresponding string labels (`grids_string`). For each non-zero value in the grid, it creates a formatted string in the format "label:value" where `label` is the string from `grids_string` and `value` is the float from `grids_float` formatted to three decimal places. These formatted strings are concatenated into a single string, separated by commas. The resulting string is returned. If the grid is empty or contains only zeros, an empty string is returned.\\
## Code: 
```
QString RangeSelectorTableModel::getRangeText(){
    QString retval = "";
    for(int i = 0;i < this->ranklist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            if(this->grids_float[i][j] == 0)continue;
            QString one_range_str = QString("%1:%2").arg(this->grids_string[i][j],QString::number(this->grids_float[i][j],'f',3));
            if(retval == ""){
                retval = one_range_str;
            }else{
                retval = retval + "," + one_range_str;
            }
        }
    }
    return retval;
}
```