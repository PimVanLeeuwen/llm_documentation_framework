`rowCount`: The function of `rowCount` is to return the number of rows in the model.

**Parameters**:\
`const QModelIndex &parent`: This parameter is a reference to a QModelIndex object representing the parent index. It is not used in this method.

**Code Description**: This method returns the size of the `ranklist` vector, which represents the number of rows in the table model. The `rowCount` method is a standard method in Qt's model/view framework, used to inform views about the number of rows available in the model.\\
## Code: 
```
int RangeSelectorTableModel::rowCount(const QModelIndex &parent) const {
    return this->ranklist.size();
}
```