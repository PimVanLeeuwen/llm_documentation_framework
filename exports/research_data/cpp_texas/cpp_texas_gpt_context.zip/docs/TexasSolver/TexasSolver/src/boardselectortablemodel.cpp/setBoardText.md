`setBoardText`: The function of `setBoardText` is to update the board state based on the input string representing board positions.

**Parameters**:\
`QString input_board`: A string containing board positions separated by commas.

**Code Description**: The `setBoardText` method first clears the current board state by calling the `clear_board` method. It then splits the `input_board` string by commas to get individual board positions. For each position, it checks if the position is valid (not empty or consisting only of spaces). If the position is valid and exists in the `string2ij` map, it retrieves the corresponding coordinates and sets the value at those coordinates in the `grids_float` 2D array to 1.0. If the position is invalid, it logs a debug message indicating the format error and skips the position.\\
## Code: 
```
void BoardSelectorTableModel::setBoardText(QString input_board){
    this->clear_board();
    for(QString one_board:input_board.split(",")){
        float board_float = 1.0;


        if(one_board.count(" ") == one_board.length() || one_board == "")continue;
        if(!this->string2ij.count(one_board)){
            qDebug().noquote() << QString(tr("skipping board %1, format error")).arg(one_board);
            continue;
        }
        pair<int,int> cord = this->string2ij[one_board];
        this->grids_float[cord.first][cord.second] = board_float;
    }
}
```