`GameActions`: The function of `GameActions` is to initialize a game action with a specified type and amount, ensuring the validity of the amount based on the action type.
**Parameters**:\
`GameTreeNode::PokerActions action`: The type of poker action to be performed (e.g., RAISE, BET, CHECK, FOLD, CALL). \
`double amount`: The amount associated with the action. For RAISE and BET actions, this should be a positive value. For CHECK, FOLD, and CALL actions, this should be -1.

**Code Description**: The `GameActions` constructor initializes the `action` and `amount` attributes of the object. It checks the validity of the `amount` parameter based on the `action` type. If the action is RAISE or BET, the amount must not be -1; otherwise, an exception is thrown. If the action is CHECK, FOLD, or CALL, the amount must be -1; otherwise, an exception is thrown.\\
## Code: 
```
GameActions::GameActions(GameTreeNode::PokerActions action, double amount) {
    this->action = action;
    if (action == GameTreeNode::PokerActions::RAISE || action == GameTreeNode::PokerActions::BET ) {
        if (amount == -1) throw runtime_error(tfm::format("raise/bet amount should not be -1, find %s",amount));
    } else {
        if (amount != -1) throw runtime_error(tfm::format("check/fold/call amount should be -1, find %s",amount));
    }
    this->amount = amount;
}
```