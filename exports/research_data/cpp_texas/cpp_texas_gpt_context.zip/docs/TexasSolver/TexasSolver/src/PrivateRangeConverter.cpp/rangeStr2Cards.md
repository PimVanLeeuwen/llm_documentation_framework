`rangeStr2Cards`: The function of `rangeStr2Cards` is to convert a string representation of a range of private poker hands into a vector of `PrivateCards` objects, considering the initial board cards to avoid duplicates.

**Parameters**:\
`string range_str`: A string representing a range of private poker hands, where each hand is separated by a comma and may include a weight after a colon. \
`vector<int> initial_boards`: A vector of integers representing the initial board cards to ensure no overlap with the generated private hands.

**Code Description**: 
1. The function starts by splitting the input `range_str` into individual hand ranges using the `string_split` method.
2. It initializes an empty vector to store the resulting `PrivateCards` objects.
3. For each hand range in the list:
   - It splits the hand range by the colon character to separate the hand description from its weight.
   - If the weight is provided, it converts it to a float; otherwise, it defaults to 1.
   - If the weight is less than or equal to 0.005, the hand is skipped.
   - Depending on the length of the hand description, it processes the hand as either a suited, offsuit, or pair hand.
   - For suited hands, it generates all possible combinations of the two ranks with the same suit.
   - For offsuit hands, it generates all possible combinations of the two ranks with different suits.
   - For pairs, it generates all possible combinations of the two ranks with any suits.
   - It ensures that the generated hands do not overlap with the initial board cards.
4. After generating the hands, it checks for duplicates and throws an error if any are found.
5. Finally, it returns the vector of `PrivateCards` objects.\\
## Code: 
```
vector<PrivateCards> PrivateRangeConverter::rangeStr2Cards(string range_str, vector<int> initial_boards) {
    vector<string> range_list = string_split(range_str,',');
    vector<PrivateCards> private_cards;

    for(string one_range:range_list){
        PrivateCards this_card;
        vector<string> cardstr_arr = string_split(one_range,':');
        if (cardstr_arr.size() > 2 || cardstr_arr.empty()){
            throw runtime_error("':' number exceeded 2");
        }
        float weight = 1;

        one_range = cardstr_arr[0];
        if(cardstr_arr.size() == 2){
            weight = atof(cardstr_arr[1].c_str());
        }
        if(weight <= 0.005){
            continue;
        }

        int range_len = one_range.length();
        // TODO finish here , convert str to a PrivateRanges[]
        if(range_len == 3){
            if(one_range.at(2) == 's'){
                char rank1 = one_range.at(0);
                char rank2 = one_range.at(1);
                if(rank1 == rank2) throw runtime_error(tfm::format("%s%ss is not a valid card desc",rank1,rank2));
                for(const string& one_suit :Card::getSuits()){
                    int card1 = Card::strCard2int(rank1 + one_suit);
                    int card2 = Card::strCard2int(rank2 + one_suit);
                    this_card = PrivateCards(card1,card2,weight);
                    private_cards.push_back(this_card);
                }

            }else if(one_range.at(2) == 'o'){
                char rank1 = one_range.at(0);
                char rank2 = one_range.at(1);

                vector<string> suits = Card::getSuits();
                for(std::size_t i = 0;i < suits.size();i++){
                    string one_suit = suits[i];
                    int begin_index = rank1 == rank2 ? i:0;
                    for(std::size_t j = begin_index;j < suits.size();j++){
                        string another_suit = suits[j];
                        if(one_suit == another_suit){
                            continue;
                        }
                        int card1 = Card::strCard2int(rank1 + one_suit);
                        int card2 = Card::strCard2int(rank2 + another_suit);
                        if(Card::boardsHasIntercept(
                                Card::boardInts2long(vector<int>{card1,card2}),
                                Card::boardInts2long(initial_boards)
                        )){
                            continue;
                        }
                        this_card = PrivateCards(card1, card2, weight);
                        private_cards.push_back(this_card);
                    }
                }
            }else{
                throw runtime_error("format not recognize");
            }
        }else if(range_len == 2){
            char rank1 = one_range.at(0);
            char rank2 = one_range.at(1);
            vector<string> suits = Card::getSuits();
            for(std::size_t i = 0;i < suits.size();i++){
                string one_suit = suits[i];
                int begin_index = rank1 == rank2 ? i:0;
                for(std::size_t j = begin_index;j < suits.size();j++){
                    string another_suit = suits[j];
                    if(one_suit == another_suit && rank1 == rank2){
                        continue;
                    }
                    int card1 = Card::strCard2int(rank1 + one_suit);
                    int card2 = Card::strCard2int(rank2 + another_suit);
                    if(Card::boardsHasIntercept(
                            Card::boardInts2long(vector<int>{card1,card2}),
                            Card::boardInts2long(initial_boards)
                    )){
                        continue;
                    }
                    this_card = PrivateCards(card1, card2, weight);
                    private_cards.push_back(this_card);
                }
            }

        }else throw runtime_error(tfm::format(" range str %s len not valid ",one_range));
    }

    // 排除初试range中重复的情况
    for(std::size_t i = 0;i < private_cards.size();i ++){
        for(std::size_t j = i + 1;j < private_cards.size();j ++) {
            PrivateCards one_cards = private_cards[i];
            PrivateCards another_cards = private_cards[j];
            if (one_cards.card1 == another_cards.card1 && one_cards.card2 == another_cards.card2){
                throw runtime_error(tfm::format("card %s %s duplicate"
                        , Card::intCard2Str(one_cards.card1)
                        , Card::intCard2Str(one_cards.card2)
                ));
            }
            if(one_cards.card1 == another_cards.card2 && one_cards.card2 == another_cards.card1) {
                throw runtime_error(tfm::format("card %s %s duplicate"
                        , Card::intCard2Str(one_cards.card1)
                        , Card::intCard2Str(one_cards.card2)
                ));
            }
        }
    }

    vector<PrivateCards> private_cards_list(private_cards.size());
    for(std::size_t i = 0;i < private_cards.size();i ++){
        private_cards_list[i] = private_cards[i];
        //System.out.print(String.format("[%s-%s]",Card.intCard2Str(private_cards_list[i].card1),Card.intCard2Str(private_cards_list[i].card2)));
    }
    /*
        output all private combos

    System.out.println("private range number:");
    System.out.println(private_cards.size());
    System.out.println();
     */
    return private_cards_list;

}
```