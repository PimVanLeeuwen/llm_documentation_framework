`parent`: The function of `parent` is to return the parent index of a given child index in a tree structure.

**Parameters**:\
`const QModelIndex &index`: The index of the child item for which the parent index is to be found.

**Code Description**: This method first checks if the provided `index` is valid. If it is not valid, it returns an invalid `QModelIndex`. If the index is valid, it retrieves the `TreeItem` associated with the given index using `index.internalPointer()`. It then gets the parent item of this child item. If the parent item is the root item, it returns an invalid `QModelIndex` because the root item has no parent. Otherwise, it creates and returns a `QModelIndex` for the parent item using the `createIndex` method, specifying the parent's row and column (0 in this case).\\
## Code: 
```
QModelIndex TreeModel::parent(const QModelIndex &index) const
{
    if (!index.isValid())
        return QModelIndex();

    TreeItem *childItem = static_cast<TreeItem*>(index.internalPointer());
    TreeItem *parentItem = childItem->parentItem();

    if (parentItem == rootItem)
        return QModelIndex();

    return createIndex(parentItem->row(), 0, parentItem);
}
```