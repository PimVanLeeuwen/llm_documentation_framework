`getReachProbs`: The function of `getReachProbs` is to calculate and return the reach probabilities for each player in the game.

**Code Description**: This method initializes a 2D vector `retval` to store the reach probabilities for each player. It iterates over each player, retrieves their private card range using the `playerHands` method, and initializes a vector `reach_prob` to store the reach probabilities for each card. The reach probability for each card is set to the card's weight. Finally, the method returns the 2D vector containing the reach probabilities for all players.\\
## Code: 
```
vector<vector<float>> PCfrSolver::getReachProbs() {
    vector<vector<float>> retval(this->player_number);
    for(int player = 0;player < this->player_number;player ++){
        vector<PrivateCards> player_cards = this->playerHands(player);
        vector<float> reach_prob(player_cards.size());
        for(std::size_t i = 0;i < player_cards.size();i ++){
            reach_prob[i] = player_cards[i].weight;
        }
        retval[player] = reach_prob;
    }
    return retval;
}
```