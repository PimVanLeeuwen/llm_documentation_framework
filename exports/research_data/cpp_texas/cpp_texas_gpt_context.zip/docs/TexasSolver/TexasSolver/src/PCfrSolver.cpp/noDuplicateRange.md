`noDuplicateRange`: The function of `noDuplicateRange` is to filter out duplicate and invalid private card ranges from a given list based on a specified board state.

**Parameters**:\
`const vector<PrivateCards> &private_range`: A constant reference to a vector of `PrivateCards` objects representing the range of private hands to be filtered. \
`uint64_t board_long`: A 64-bit integer representing the current board state, where each bit corresponds to the presence of a specific card.

**Code Description**: This method iterates through the provided `private_range` vector to filter out any duplicate or invalid private card ranges. It uses an unordered map to track the hash codes of the private card ranges to detect duplicates. If a duplicate is found, a runtime error is thrown. For each unique private card range, it converts the private hand to a 64-bit integer and checks if there is any overlap with the board state using the `boardsHasIntercept` method. If there is no overlap, the private card range is added to the result vector. The method returns a vector of `PrivateCards` objects that are unique and valid based on the given board state.\\
## Code: 
```
vector<PrivateCards>
PCfrSolver::noDuplicateRange(const vector<PrivateCards> &private_range, uint64_t board_long) {
    vector<PrivateCards> range_array;
    unordered_map<int,bool> rangekv;
    for(PrivateCards one_range:private_range){
        if(rangekv.find(one_range.hashCode()) != rangekv.end())
            throw runtime_error(tfm::format("duplicated key %s",one_range.toString()));
        rangekv[one_range.hashCode()] = true;
        uint64_t hand_long = Card::boardInts2long(one_range.get_hands());
        if(!Card::boardsHasIntercept(hand_long,board_long)){
            range_array.push_back(one_range);
        }
    }
    return range_array;

}
```