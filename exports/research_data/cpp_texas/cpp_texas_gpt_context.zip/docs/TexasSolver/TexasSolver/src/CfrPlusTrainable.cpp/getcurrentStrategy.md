`getcurrentStrategy`: The function of `getcurrentStrategy` is to compute and return the current strategy for the CFR+ (Counterfactual Regret Minimization Plus) algorithm based on the accumulated regrets.

**Code Description**: This method calculates the current strategy for each action and private card combination. If the `r_plus_sum` vector is empty, it initializes the strategy to be uniform across all actions. Otherwise, it computes the strategy by normalizing the positive regrets (`r_plus`) by the sum of positive regrets (`r_plus_sum`) for each private card. If the sum of positive regrets for a private card is zero, it assigns a uniform probability for each action. The method also includes a check to ensure that no NaN values are present in the computed strategy, throwing a runtime error if any are found. The final strategy is stored in the `retval` vector and returned.\\
## Code: 
```
const vector<float> CfrPlusTrainable::getcurrentStrategy() {
    if(this->r_plus_sum.empty()){
        fill(retval.begin(),retval.end(),1.0 / this->action_number);
    }else {
        for (int action_id = 0; action_id < action_number; action_id++) {
            for (int private_id = 0; private_id < this->card_number; private_id++) {
                int index = action_id * this->card_number + private_id;
                if(this->r_plus_sum[private_id] != 0) {
                    retval[index] = this->r_plus[index] / this->r_plus_sum[private_id];
                }else{
                    retval[index] = 1.0 / this->action_number;
                }
                if(this->r_plus[index] != this->r_plus[index]) throw runtime_error("nan found");
                /*
                if(this.r_plus_sum[private_id] == 0)
                {
                    System.out.println("Exception regret status, r_plus_sum == 0:");
                    System.out.println(String.format("r plus length %s , card num %s",r_plus.length,this.card_number));
                    for(int i = index % this.card_number;i < this.r_plus.length;i += this.card_number){
                        System.out.print(String.format("%s:%s ",i,this.r_plus[i]));
                        if(i == index){
                            System.out.print("[current]");
                        }
                    }
                    System.out.println();
                    System.out.println();
                    throw new RuntimeException();
                }
                 */
            }
        }
    }
    return retval;
}
```