`getInitialReachProb`: The function of `getInitialReachProb` is to calculate the initial reach probabilities for a player's private cards, considering the given initial board configuration.

**Parameters**:\
`int player`: The index of the player whose private cards are being evaluated. \
`uint64_t initialboard`: A 64-bit integer representing the initial board configuration, where each bit corresponds to the presence of a specific card.

**Code Description**: This method calculates the initial reach probabilities for a player's private cards based on the given initial board configuration. It iterates through the player's private cards and checks if any of the cards intersect with the initial board using the `Card::boardsHasIntercept` method. If there is an intersection, the probability for that card is set to 0. Otherwise, the probability is set to the weight of the private card. The method returns a vector of probabilities corresponding to each private card.\\
## Code: 
```
vector<float> PrivateCardsManager::getInitialReachProb(int player, uint64_t initialboard) {
    int cards_len =  this->private_cards[player].size();
    vector<float> probs = vector<float>(cards_len);
    for(int i = 0;i < cards_len;i ++){
        PrivateCards pc = this->private_cards[player][i];
        if(Card::boardsHasIntercept(initialboard,Card::boardInts2long(pc.get_hands()))) {
            probs[i] = 0;
        }else{
            probs[i] = this->private_cards[player][i].weight;
        }
    }
    return probs;
}
```