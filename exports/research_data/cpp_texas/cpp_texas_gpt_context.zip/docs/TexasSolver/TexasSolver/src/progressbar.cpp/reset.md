`reset`: The function of `reset` is to reinitialize the progress bar's state.

**Code Description**: The `reset` method in the `progressbar` class sets the `progress` attribute to 0, indicating that no progress has been made. It also sets the `update_is_called` attribute to `false`, indicating that the update method has not been called since the reset. Additionally, it sets the `last_perc` attribute to 0, which likely represents the last recorded percentage of progress. This method ensures that the progress bar is in its initial state, ready to start tracking progress from the beginning.\\
## Code: 
```
void progressbar::reset() {
    progress = 0,
            update_is_called = false;
    last_perc = 0;
    return;
}
```