`paint`: The function of `paint` is to render a custom item delegate in a view, using HTML formatting for the text.

**Parameters**:\
`QPainter *painter`: A pointer to the QPainter object used for drawing the item.\
`const QStyleOptionViewItem &option`: A constant reference to the style options for the item, which contains information such as the item's state, display area, and widget.\
`const QModelIndex &index`: A constant reference to the model index, which provides information about the item's position in the model.

**Code Description**: The `paint` method customizes the rendering of an item in a view. It first initializes the style options for the item using `initStyleOption`. Then, it saves the current state of the painter. A `QTextDocument` is created to handle HTML text rendering, and the item's text is set as HTML in the document. The text in the options is cleared to avoid default text rendering. The item's style is drawn using the widget's style. The painter is then translated to the top-left corner of the item's rectangle, and the HTML content is drawn within the specified clipping rectangle. Finally, the painter's state is restored to its previous state.\\
## Code: 
```
void WordItemDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);

    painter->save();

    QTextDocument doc;
    doc.setHtml(options.text);

    options.text = "";
    options.widget->style()->drawControl(QStyle::CE_ItemViewItem, &option, painter);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);

    painter->restore();
}
```