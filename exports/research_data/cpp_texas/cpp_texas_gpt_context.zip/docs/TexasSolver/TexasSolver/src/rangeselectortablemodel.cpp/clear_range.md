`clear_range`: The function of `clear_range` is to reset all elements in the `grids_float` 2D array to zero.

**Code Description**: The `clear_range` method iterates through each element of the `grids_float` 2D array, which is presumably a member of the `RangeSelectorTableModel` class. It uses two nested loops to access each element in the array, setting each one to zero. The size of the loops is determined by the size of the `ranklist` member, suggesting that `grids_float` is a square matrix with dimensions equal to the length of `ranklist`.\\
## Code: 
```
void RangeSelectorTableModel::clear_range(){
    for(int i = 0;i < this->ranklist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_float[i][j] = 0;
        }
    }
}
```