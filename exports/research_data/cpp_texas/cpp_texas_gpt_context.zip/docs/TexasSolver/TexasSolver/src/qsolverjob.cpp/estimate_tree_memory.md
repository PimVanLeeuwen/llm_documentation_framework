`estimate_tree_memory`: The function of `estimate_tree_memory` is to estimate the memory required to build a game tree for a given set of poker ranges and board configuration.

**Parameters**:\
`QString range1`: The hand range for the first player. \
`QString range2`: The hand range for the second player. \
`QString board`: The current board configuration in the poker game.

**Code Description**: This method estimates the memory required to construct a game tree based on the provided hand ranges and board configuration. It first logs a debug message indicating that the memory estimation process has started. The method then checks the mode of the solver (either HOLDEM or SHORTDECK) and calls the appropriate memory estimation function from the corresponding solver instance (`ps_holdem` or `ps_shortdeck`). If the mode does not match either HOLDEM or SHORTDECK, the method returns 0.\\
## Code: 
```
long long QSolverJob::estimate_tree_memory(QString range1,QString range2,QString board){
    qDebug().noquote() << tr("Estimating tree memory..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        return ps_holdem.estimate_tree_memory(range1,range2,board);
    }else if(this->mode == Mode::SHORTDECK){
        return ps_shortdeck.estimate_tree_memory(range1,range2,board);
    }
    return 0;
}
```