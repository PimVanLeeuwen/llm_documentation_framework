`playerHands`: The function of `playerHands` is to return the private card range for a specified player.
**Parameters**:\
`int player`: The index of the player (0 or 1).

**Code Description**: The `playerHands` method takes an integer parameter `player` and returns a reference to a vector of `PrivateCards` corresponding to the specified player. If the `player` parameter is 0, it returns `range1`. If the `player` parameter is 1, it returns `range2`. If the `player` parameter is neither 0 nor 1, it throws a runtime error indicating that the player was not found.\\
## Code: 
```
const vector<PrivateCards> &PCfrSolver::playerHands(int player) {
    if(player == 0){
        return range1;
    }else if (player == 1){
        return range2;
    }else{
        throw runtime_error("player not found");
    }
}
```