`reGenerateTreeItem`: The function of `reGenerateTreeItem` is to recursively regenerate the tree structure of `TreeItem` nodes based on the game round and the type of `GameTreeNode` (either `ACTION` or `CHANCE`).

**Parameters**:\
`GameTreeNode::GameRound round`: The game round to match when regenerating the tree items. \
`TreeItem* node_to_process`: The current `TreeItem` node that needs to be processed and potentially have its children regenerated.

**Code Description**: 
The `reGenerateTreeItem` method starts by locking the weak pointer `m_treedata` of the `node_to_process` to get a shared pointer to the associated `GameTreeNode`. It then checks the type of the `GameTreeNode`. If the type is `ACTION`, it dynamically casts the `GameTreeNode` to an `ActionNode` and retrieves its children. For each child, it creates a new `TreeItem` and inserts it as a child of the current `TreeItem`. If the child's game round matches the specified round, the method recursively calls itself to process the child node. If the type is `CHANCE`, it dynamically casts the `GameTreeNode` to a `ChanceNode`, creates a new `TreeItem` for its single child, inserts it, and recursively processes the child node. This process continues until all relevant nodes are processed and the tree structure is regenerated accordingly.\\
## Code: 
```
void TreeModel::reGenerateTreeItem(GameTreeNode::GameRound round,TreeItem* node_to_process){
    const shared_ptr<GameTreeNode> gameTreeNode = node_to_process->m_treedata.lock();
    if(gameTreeNode->getType() == GameTreeNode::GameTreeNodeType::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(gameTreeNode);
        vector<shared_ptr<GameTreeNode>>& childrens = actionNode->getChildrens();
        for(shared_ptr<GameTreeNode> one_child:childrens){
            TreeItem * child_node = new TreeItem(one_child,node_to_process);
            node_to_process->insertChild(child_node);
            if(one_child->getRound() != round){
                continue;
            }
            this->reGenerateTreeItem(round,child_node);
        }
    }
    else if(gameTreeNode->getType() == GameTreeNode::GameTreeNodeType::CHANCE){
        shared_ptr<ChanceNode> chanceNode = dynamic_pointer_cast<ChanceNode>(gameTreeNode);
        TreeItem * child_node = new TreeItem(chanceNode->getChildren(),node_to_process);
        node_to_process->insertChild(child_node);
        this->reGenerateTreeItem(round,child_node);
    }
}
```