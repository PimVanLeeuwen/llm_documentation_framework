`ActionNode`: The function of `ActionNode` is to initialize an action node in the game tree with specified actions, child nodes, player information, game round, pot value, and parent node.

**Parameters**:\
`vector<GameActions> actions`: A list of game actions associated with this node. \
`vector<shared_ptr<GameTreeNode>> childrens`: A list of child nodes that represent possible future states of the game from this node. \
`int player`: The identifier of the player associated with this node. \
`GameTreeNode::GameRound round`: The current round of the game at this node. \
`double pot`: The current value of the pot at this node. \
`shared_ptr<GameTreeNode> parent`: A pointer to the parent node in the game tree.

**Code Description**: The constructor `ActionNode` initializes an instance of the `ActionNode` class by setting its actions, player, child nodes, game round, pot value, and parent node. It calls the constructor of the base class `GameTreeNode` with the game round, pot value, and parent node. The actions and child nodes are moved into the instance to optimize performance by avoiding unnecessary copies.\\
## Code: 
```
ActionNode::ActionNode(vector<GameActions> actions, vector<shared_ptr<GameTreeNode>> childrens, int player,
                       GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent) :GameTreeNode(round,pot,std::move(parent)){
    this->actions = std::move(actions);
    this->player = player;
    this->childrens = std::move(childrens);
    //cout << "ActionNode created" << endl;
}
```