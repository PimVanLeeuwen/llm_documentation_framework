`GameTreeBuildingSettings`: The function of `GameTreeBuildingSettings` is to initialize an object with specific settings for different stages of a poker game for both in-position (IP) and out-of-position (OOP) players.

**Parameters**:\
`StreetSetting flop_ip`: Settings for the flop stage when the player is in position.\
`StreetSetting turn_ip`: Settings for the turn stage when the player is in position.\
`StreetSetting river_ip`: Settings for the river stage when the player is in position.\
`StreetSetting flop_oop`: Settings for the flop stage when the player is out of position.\
`StreetSetting turn_oop`: Settings for the turn stage when the player is out of position.\
`StreetSetting river_oop`: Settings for the river stage when the player is out of position.\

**Code Description**: The constructor `GameTreeBuildingSettings` initializes an instance of the `GameTreeBuildingSettings` class by assigning the provided `StreetSetting` parameters to the corresponding member variables. This setup allows the configuration of game tree building settings for different stages (flop, turn, river) and player positions (in-position, out-of-position).\\
## Code: 
```
GameTreeBuildingSettings::GameTreeBuildingSettings(
        StreetSetting flop_ip,
        StreetSetting turn_ip,
        StreetSetting river_ip,
        StreetSetting flop_oop,
        StreetSetting turn_oop,
        StreetSetting river_oop):flop_ip(flop_ip),turn_ip(turn_ip),river_ip(river_ip),flop_oop(flop_oop),turn_oop(turn_oop),river_oop(river_oop) {
}
```