`rowCount`: The function of `rowCount` is to return the number of rows in the table model.

**Parameters**:\
`const QModelIndex &parent`: This parameter is not used in the function but is typically provided to indicate the parent index in hierarchical models.

**Code Description**: This method returns the number of rows in the table model by accessing the `qSolverJob` object, retrieving the associated `PokerSolver` instance, and then getting the size of the deck's ranks. The size of the ranks in the deck determines the number of rows in the table model.\\
## Code: 
```
int TableStrategyModel::rowCount(const QModelIndex &parent) const
{
    return this->qSolverJob->get_solver()->get_deck()->getRanks().size();
}
```