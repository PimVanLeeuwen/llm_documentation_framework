`Solver`: The function of `Solver` is to initialize an instance of the `Solver` class with a given game tree.

**Parameters**:\
`shared_ptr<GameTree> tree`: A shared pointer to a `GameTree` object that represents the game tree to be used by the solver.

**Code Description**: This constructor method initializes the `Solver` class by assigning the provided `GameTree` shared pointer to the class's `tree` member variable. This allows the `Solver` instance to use the game tree for its operations.\\
## Code: 
```
Solver::Solver(shared_ptr<GameTree> tree) {
    this->tree = tree;
}
```