`paint_evs_only`: The function of `paint_evs_only` is to render the expected values (EVs) and corresponding card combinations in a grid cell within a detailed view, using color coding to represent the normalized EVs.

**Parameters**:\
`QPainter *painter`: A pointer to the QPainter object used for drawing the content.\
`const QStyleOptionViewItem &option`: Provides style options for the item being painted, such as its rectangle, state, and font.\
`const QModelIndex &index`: Represents the index of the item in the model, providing access to the data and metadata of the item.

**Code Description**: 
1. The method initializes the style options for the item using `initStyleOption`.
2. It retrieves the `DetailViewerModel` from the model associated with the `index`.
3. It checks if the current tree item is of type `ACTION`.
4. If the grid indices are valid, it retrieves the strategy number and the EVs for the specified grid cell.
5. It calculates the index within the EVs vector based on the row and column of the `index`.
6. If the index is within bounds, it retrieves the EV and normalizes it using the `normalization_tanh` function.
7. It determines the card combination for the current index and calculates the color based on the normalized EV.
8. It fills the background of the item with the calculated color.
9. It formats the card combination and EV as HTML text.
10. It uses a `QTextDocument` to render the HTML text within the item's rectangle.

This method effectively visualizes the EVs and card combinations in a detailed and color-coded manner, enhancing the user's ability to interpret the strategy data.\\
## Code: 
```
void DetailItemDelegate::paint_evs_only(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);

    const DetailViewerModel * detailViewerModel = qobject_cast<const DetailViewerModel*>(index.model());
    //vector<pair<GameActions,float>> strategy = detailViewerModel->tableStrategyModel->get_strategy(this->detailWindowSetting->grid_i,this->detailWindowSetting->grid_j);
    options.text = "";

    if(detailViewerModel->tableStrategyModel->treeItem != NULL &&
            detailViewerModel->tableStrategyModel->treeItem->m_treedata.lock()->getType() == GameTreeNode::GameTreeNode::ACTION){

        shared_ptr<GameTreeNode> node = detailViewerModel->tableStrategyModel->treeItem->m_treedata.lock();
        int strategy_number = 0;
        if(this->detailWindowSetting->grid_i >= 0 && this->detailWindowSetting->grid_j >= 0){
           strategy_number = detailViewerModel->tableStrategyModel->ui_strategy_table[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j].size();
        }

        vector<float> evs = detailViewerModel->tableStrategyModel->get_ev_grid(this->detailWindowSetting->grid_i,this->detailWindowSetting->grid_j);
        std::size_t ind = index.row() * detailViewerModel->columns + index.column();

        if(ind < evs.size() and ind < strategy_number)
        {
            float one_ev = evs[ind];
            float normalized_ev = normalization_tanh(detailViewerModel->tableStrategyModel->get_solver()->stack,one_ev);
            //options.text += QString("</br>%1").arg(QString::number(normalized_ev));

            pair<int,int> strategy_ui_table = detailViewerModel->tableStrategyModel->ui_strategy_table[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j][ind];
            int card1 = strategy_ui_table.first;
            int card2 = strategy_ui_table.second;

            int red = max((int)(255 - normalized_ev * 255),0);
            int green = min((int)(normalized_ev * 255),255);
            int blue = min(red, green);
            QBrush brush = QBrush(QColor(red,green,blue));

            // draw background for flod
            QRect rect(option.rect.left(), option.rect.top(),
             option.rect.width(), option.rect.height());
            painter->fillRect(rect, brush);

            options.text = "";
            options.text += detailViewerModel->tableStrategyModel->cardint2card[card1].toFormattedHtml();
            options.text += detailViewerModel->tableStrategyModel->cardint2card[card2].toFormattedHtml();
            options.text = "<h2>" + options.text + "<\/h2>";

            options.text +=  QString(" <h2>%1<\/h2>").arg(QString::number(one_ev,'f',3));
        }
    }

    QTextDocument doc;
    doc.setHtml(options.text);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```