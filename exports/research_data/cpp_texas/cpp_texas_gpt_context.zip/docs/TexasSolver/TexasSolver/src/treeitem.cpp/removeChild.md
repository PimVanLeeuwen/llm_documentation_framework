`removeChild`: The function of `removeChild` is to remove a child item from the list of child items at a specified row index.

**Parameters**:\
`int row`: The index of the child item to be removed from the list of child items.

**Code Description**: The `removeChild` method removes the child item at the specified row index from the `m_childItems` list and returns `true` to indicate the operation was successful.\\
## Code: 
```
bool TreeItem::removeChild(int row)
{
    m_childItems.removeAt(row);
    return true;
}
```