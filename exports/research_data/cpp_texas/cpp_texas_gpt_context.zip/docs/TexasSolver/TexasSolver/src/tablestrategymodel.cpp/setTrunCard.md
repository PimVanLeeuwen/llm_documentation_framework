`setTrunCard`: The function of `setTrunCard` is to set the turn card in the `TableStrategyModel` object.

**Parameters**:\
`Card turn_card`: The card to be set as the turn card.

**Code Description**: This method assigns the provided `turn_card` to the `turn_card` member variable of the `TableStrategyModel` object. This allows the model to update its state with the new turn card.\\
## Code: 
```
void TableStrategyModel::setTrunCard(Card turn_card){
    this->turn_card = turn_card;
}
```