`setupModelData`: The function of `setupModelData` is to initialize and set up the data structures required for the strategy model in a poker solver application.

**Code Description**: 
The `setupModelData` method initializes several data structures used to represent the strategy model for a poker solver. It performs the following steps:

1. **Card Initialization**:
   - Retrieves the deck of cards and their ranks from the solver.
   - Maps each card's integer representation to the corresponding `Card` object and stores this mapping in `cardint2card`.

2. **Strategy Table Initialization**:
   - Initializes `ui_strategy_table` as a 3D vector to store strategy data, with dimensions based on the number of card ranks.

3. **Player Ranges Initialization**:
   - Initializes `p1_range` and `p2_range` as 2D vectors of size 52x52, setting all values to 0. These vectors represent the range of possible hands for two players.

4. **UI Ranges Initialization**:
   - Initializes `ui_p1_range` and `ui_p2_range` as 3D vectors to store UI-specific range data, with dimensions based on the number of card ranks.

5. **Player 1 Range Population**:
   - Iterates through the private cards in player 1's range.
   - For each pair of private cards, calculates their ranks and suits.
   - Determines the appropriate indices for the UI representation and populates `ui_p1_range` accordingly.

6. **Player 2 Range Population**:
   - Similar to player 1, iterates through the private cards in player 2's range.
   - Calculates ranks and suits, determines UI indices, and populates `ui_p2_range`.

7. **Total Strategy Initialization**:
   - Initializes `total_strategy` as an empty vector to store the overall strategy data.

This method sets up the necessary data structures to facilitate the strategy modeling and analysis in the poker solver application.\\
## Code: 
```
void TableStrategyModel::setupModelData()
{
    vector<Card> cards = this->qSolverJob->get_solver()->get_deck()->getCards();
    vector<string> ranks = this->qSolverJob->get_solver()->get_deck()->getRanks();
    for(auto one_card: cards){
        this->cardint2card.insert(std::pair<int, Card>(one_card.getCardInt(), one_card));
    }

    this->ui_strategy_table = vector<vector<vector<pair<int,int>>>>(ranks.size());
    for(std::size_t i = 0;i < ranks.size();i ++){
        this->ui_strategy_table[i] = vector<vector<pair<int,int>>>(ranks.size());
        for(std::size_t j = 0;j < ranks.size();j ++){
            this->ui_strategy_table[i][j] = vector<pair<int,int>>();
        }
    }

    this->p1_range = vector<vector<float>>(52);
    for(std::size_t i = 0;i < 52;i ++){
        this->p1_range[i] = vector<float>(52);
        for(std::size_t j = 0;j < 52;j ++){
            this->p1_range[i][j] = 0;
        }
    }

    this->p2_range = vector<vector<float>>(52);
    for(std::size_t i = 0;i < 52;i ++){
        this->p2_range[i] = vector<float>(52);
        for(std::size_t j = 0;j < 52;j ++){
            this->p2_range[i][j] = 0;
        }
    }

    this->ui_p1_range = vector<vector<vector<pair<int,int>>>>(ranks.size());
    for(std::size_t i = 0;i < ranks.size();i ++){
        this->ui_p1_range[i] = vector<vector<pair<int,int>>>(ranks.size());
        for(std::size_t j = 0;j < ranks.size();j ++){
            this->ui_p1_range[i][j] = vector<pair<int,int>>();
        }
    }

    this->ui_p2_range = vector<vector<vector<pair<int,int>>>>(ranks.size());
    for(std::size_t i = 0;i < ranks.size();i ++){
        this->ui_p2_range[i] = vector<vector<pair<int,int>>>(ranks.size());
        for(std::size_t j = 0;j < ranks.size();j ++){
            this->ui_p2_range[i][j] = vector<pair<int,int>>();
        }
    }

    vector<PrivateCards>& p1range = this->qSolverJob->get_solver()->player1Range;
    vector<PrivateCards>& p2range = this->qSolverJob->get_solver()->player2Range;

    for(PrivateCards one_private: p1range){
        Card card1 = this->cardint2card[one_private.card1];
        Card card2 = this->cardint2card[one_private.card2];

        int rank1 = card1.getCardInt() / 4;
        int suit1 = card1.getCardInt() - (rank1)*4;
        int index1 = 12 - rank1; // this index is the index of the actal ui, so AKQ would be the lower index and 234 would be high

        int rank2 = card2.getCardInt() / 4;
        int suit2 = card2.getCardInt() - (rank2)*4;
        int index2 = 12 - rank2;

        if(index1 == index2){
            this->ui_p1_range[index1][index2].push_back(std::pair<int,int>(one_private.card1,one_private.card2));
        }
        else if(suit1 == suit2){
            this->ui_p1_range[min(index1,index2)][max(index1,index2)].push_back(std::pair<int,int>(one_private.card1,one_private.card2));
        }else{
            this->ui_p1_range[max(index1,index2)][min(index1,index2)].push_back(std::pair<int,int>(one_private.card1,one_private.card2));
        }
    }
    for(PrivateCards one_private: p2range){
        Card card1 = this->cardint2card[one_private.card1];
        Card card2 = this->cardint2card[one_private.card2];

        int rank1 = card1.getCardInt() / 4;
        int suit1 = card1.getCardInt() - (rank1)*4;
        int index1 = 12 - rank1; // this index is the index of the actal ui, so AKQ would be the lower index and 234 would be high

        int rank2 = card2.getCardInt() / 4;
        int suit2 = card2.getCardInt() - (rank2)*4;
        int index2 = 12 - rank2;

        if(index1 == index2){
            this->ui_p2_range[index1][index2].push_back(std::pair<int,int>(one_private.card1,one_private.card2));
        }
        else if(suit1 == suit2){
            this->ui_p2_range[min(index1,index2)][max(index1,index2)].push_back(std::pair<int,int>(one_private.card1,one_private.card2));
        }else{
            this->ui_p2_range[max(index1,index2)][min(index1,index2)].push_back(std::pair<int,int>(one_private.card1,one_private.card2));
        }
    }
    this->total_strategy = vector<pair<GameActions,pair<float,float>>>();
}
```