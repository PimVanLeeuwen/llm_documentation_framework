`StreetSetting`: The function of `StreetSetting` is to initialize an object with specific betting, raising, and donk sizes, and an all-in option.
**Parameters**:\
`vector<float> bet_sizes`: A vector containing the sizes of bets. \
`vector<float> raise_sizes`: A vector containing the sizes of raises. \
`vector<float> donk_sizes`: A vector containing the sizes of donk bets. \
`bool allin`: A boolean indicating whether the all-in option is available.

**Code Description**: This constructor method initializes the `StreetSetting` object by assigning the provided vectors of bet sizes, raise sizes, and donk sizes to the object's corresponding attributes. It also sets the `allin` attribute to the provided boolean value.\\
## Code: 
```
StreetSetting::StreetSetting(vector<float> bet_sizes, vector<float> raise_sizes, vector<float> donk_sizes,
                             bool allin) {
    this->bet_sizes = bet_sizes;
    this->raise_sizes = raise_sizes;
    this->donk_sizes = donk_sizes;
    this->allin = allin;
}
```