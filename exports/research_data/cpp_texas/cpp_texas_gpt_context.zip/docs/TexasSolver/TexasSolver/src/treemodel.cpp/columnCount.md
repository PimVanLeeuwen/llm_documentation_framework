`columnCount`: The function of `columnCount` is to return the number of columns for a given parent index in a tree model.

**Parameters**:\
`const QModelIndex &parent`: The parent index for which the column count is being queried. If the parent index is valid, the column count of the corresponding tree item is returned. If the parent index is invalid, the column count of the root item is returned.

**Code Description**: This method checks if the provided `parent` index is valid. If it is, it retrieves the internal pointer of the parent index, casts it to a `TreeItem` pointer, and returns the column count of that tree item. If the parent index is not valid, it returns the column count of the root item of the tree model.\\
## Code: 
```
int TreeModel::columnCount(const QModelIndex &parent) const
{
    if (parent.isValid())
        return static_cast<TreeItem*>(parent.internalPointer())->columnCount();
    return rootItem->columnCount();
}
```