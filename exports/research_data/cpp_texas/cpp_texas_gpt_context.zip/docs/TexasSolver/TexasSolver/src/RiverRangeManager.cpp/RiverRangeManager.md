`RiverRangeManager`: The function of `RiverRangeManager` is to initialize an instance of the `RiverRangeManager` class with a given hand evaluator and a mutex for thread safety.
**Parameters**:\
`shared_ptr<Compairer> handEvaluator`: A shared pointer to a `Compairer` object that is used to evaluate hands in the context of the river stage in a poker game.

**Code Description**: The constructor `RiverRangeManager` takes a shared pointer to a `Compairer` object as an argument. It assigns this shared pointer to the member variable `handEvaluator` of the `RiverRangeManager` instance, using `std::move` to transfer ownership. Additionally, it initializes the member variable `maplock` with a new shared pointer to a `std::mutex` object, which will be used to ensure thread safety when accessing shared resources.\\
## Code: 
```
RiverRangeManager::RiverRangeManager(shared_ptr<Compairer> handEvaluator) {
    this->handEvaluator = std::move(handEvaluator);
    this->maplock = std::make_shared<std::mutex>();
}
```