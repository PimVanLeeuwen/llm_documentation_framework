`setRangeText`: The function of `setRangeText` is to parse a given range string and update the `grids_float` 2D array with the specified range values.

**Parameters**:\
`QString input_range`: A comma-separated string where each range is defined by a key and an optional float value separated by a colon (e.g., "key1:1.0,key2:0.5").

**Code Description**: The `setRangeText` method begins by clearing the current range values in the `grids_float` array using the `clear_range` method. It then splits the `input_range` string by commas to process each range individually. For each range, it trims any whitespace and splits the range into key and value parts using a colon as the delimiter. If the format is incorrect (i.e., more than one colon or no key), it logs an error message and skips the range.

For valid ranges, it determines the keys to be used (adding "o" and "s" suffixes if necessary) and checks if the keys exist in the `string2ij` map. If a key is valid, it retrieves the corresponding coordinates and updates the `grids_float` array with the specified float value (defaulting to 1.0 if no value is provided). If the key is invalid, it logs an error message and skips the range.\\
## Code: 
```
void RangeSelectorTableModel::setRangeText(QString input_range){
    this->clear_range();
    for(QString one_range:input_range.split(",")){
        if(one_range.trimmed() == "")continue;
        QStringList one_range_list = one_range.split(":");

        if(one_range_list.size() > 2 || one_range_list.size() < 1){
            qDebug().noquote() << QString(tr("skipping range %1, format error, range list should contain two part seperate by ':'")).arg(one_range);
        }

        float range_float = 1.0;
        QString key_range = one_range_list[0];
        QStringList keys;
        if(this->string2ij.count(one_range_list[0])){
            keys.append(key_range);
        }else{
            keys.append(key_range + "o");
            keys.append(key_range + "s");
        }

        for(QString one_key: keys){
            if(one_key.count(" ") == one_key.length() || one_key == "")continue;
            if(!this->string2ij.count(one_key)){
                qDebug().noquote() << QString(tr("skipping range %1, format error")).arg(one_range);
                continue;
            }
            pair<int,int> cord = this->string2ij[one_key];
            if(one_range_list.size() > 1)range_float = one_range_list[1].toFloat();
            this->grids_float[cord.first][cord.second] = range_float;
        }
    }
}
```