`isDonk`: The function of `isDonk` is to check if the current `ChanceNode` object is marked as a "donk".

**Code Description**: This method, `isDonk`, is a member of the `ChanceNode` class. It returns a boolean value indicating the state of the `donk` attribute of the `ChanceNode` object. If the `donk` attribute is `true`, the method returns `true`; otherwise, it returns `false`. This method is used to determine whether the `ChanceNode` has been flagged as a "donk".\\
## Code: 
```
bool ChanceNode::isDonk(){
    return this->donk;
}
```