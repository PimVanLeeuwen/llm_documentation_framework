`getActions`: The function of `getActions` is to return a reference to the `actions` member variable of the `ActionNode` class.

**Code Description**: This method, `getActions`, is a member of the `ActionNode` class. It returns a reference to the `actions` vector, which is a member variable of the same class. The returned reference allows access to the `actions` vector, enabling the caller to view or modify the list of `GameActions` stored within the `ActionNode` instance.\\
## Code: 
```
vector<GameActions>& ActionNode::getActions() {
    return this->actions;
}
```