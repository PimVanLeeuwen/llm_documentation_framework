`convert`: The function of `convert` is to process a map of card strengths and categorize them into flush and non-flush hands.

**Parameters**:\
`unordered_map<uint64_t`: A map where the keys are card hashes representing different poker hands.\
`int>& strength_map`: The values in the map represent the strength of the corresponding poker hands.

**Code Description**: The `convert` method processes the `strength_map` to separate poker hands into flush and non-flush categories. It clears the existing `flush_map` and `other_map`, then iterates through each entry in `strength_map`. For each entry, it calculates a `cards_hash` and a `hash` representing the ranks of the cards. If the hand is a flush (determined by the `is_flush` method), it adds the entry to `flush_map`. Otherwise, it adds the entry to `other_map` using the rank-based `hash` as the key. This categorization helps in efficiently managing and comparing poker hand strengths based on whether they are flushes or not.\\
## Code: 
```
void FiveCardsStrength::convert(unordered_map<uint64_t, int>& strength_map) {
    flush_map.clear(); other_map.clear();
    auto it = strength_map.begin(), it_end = strength_map.end();
    for (; it != it_end; it++) {
        uint64_t cards_hash = it->first;
        uint64_t hash = ranks_hash(cards_hash);
        if (is_flush(cards_hash)) flush_map[cards_hash] = it->second;
        else {
            /*if (other_map.count(hash) && other_map[hash] != it->second) {
                printf("%zx,%zx:%d != %d\n", cards_hash, hash, it->second, other_map[hash]);
            }*/
            other_map[hash] = it->second;
        }
    }
}
```