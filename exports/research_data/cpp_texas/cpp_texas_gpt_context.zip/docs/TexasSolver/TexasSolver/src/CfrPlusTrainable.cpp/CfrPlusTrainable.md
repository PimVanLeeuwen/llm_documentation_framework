`CfrPlusTrainable`: The function of `CfrPlusTrainable` is to initialize an instance of the `CfrPlusTrainable` class with the given action node and private cards, setting up various vectors for storing regret values and cumulative regret values.

**Parameters**:\
`shared_ptr<ActionNode> action_node`: A shared pointer to an `ActionNode` object, representing the current node in the game tree from which actions can be taken. \
`vector<PrivateCards> privateCards`: A vector of `PrivateCards` objects, representing the private cards held by the player.

**Code Description**: The `CfrPlusTrainable` constructor initializes the `CfrPlusTrainable` object by setting the `action_node` and `privateCards` attributes. It calculates the number of possible actions (`action_number`) from the size of the children of the `action_node` and the number of private cards (`card_number`). It then initializes several vectors (`r_plus`, `r_plus_sum`, `cum_r_plus`, `cum_r_plus_sum`, and `retval`) to store regret values and cumulative regret values, with sizes based on the number of actions and private cards.\\
## Code: 
```
CfrPlusTrainable::CfrPlusTrainable(shared_ptr<ActionNode> action_node, vector<PrivateCards> privateCards) {
    this->action_node = action_node;
    this->privateCards = privateCards;
    this->action_number = action_node->getChildrens().size();
    this->card_number = privateCards.size();

    this->r_plus = vector<float>(this->action_number * this->card_number);
    this->r_plus_sum = vector<float>(this->card_number);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number);
    this->cum_r_plus_sum = vector<float>(this->card_number);
    this->retval = vector<float>(this->action_number * this->card_number);
}
```