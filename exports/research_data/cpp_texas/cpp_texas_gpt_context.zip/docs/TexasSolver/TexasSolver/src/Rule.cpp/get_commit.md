`get_commit`: The function of `get_commit` is to return the commitment value of a specified player.

**Parameters**:\
`int player`: An integer representing the player. It should be `0` for the in-position player and `1` for the out-of-position player.

**Code Description**: The `get_commit` method checks the value of the `player` parameter. If the player is `0`, it returns the commitment value for the in-position player (`ip_commit`). If the player is `1`, it returns the commitment value for the out-of-position player (`oop_commit`). If the player value is neither `0` nor `1`, it throws a runtime error indicating an unknown player.\\
## Code: 
```
float Rule::get_commit(int player) {
    if (player == 0) return this->ip_commit;
    else if(player == 1) return this->oop_commit;
    else throw runtime_error("unknown player");
}
```