`compair`: The function of `compair` is to compare the ranks of two poker hands, considering a shared community board.

**Parameters**:
- `vector<int> private_former`: A vector representing the first player's private hand.
- `vector<int> private_latter`: A vector representing the second player's private hand.
- `vector<int> public_board`: A vector representing the shared community board.

**Code Description**: The function `compair` takes three vectors as input: two private hands and one public board. It first checks if the sizes of the input vectors are correct, throwing an exception if they are not. Then it combines each private hand with the public board to form a set of 5 cards, calculates their ranks using the `getRank` method, and finally compares these ranks using the `compairRanks` method to determine which hand is stronger.\\
## Code: 
```
Compairer::CompairResult
Dic5Compairer::compair(vector<int> private_former, vector<int> private_latter, vector<int> public_board) {
    if(private_former.size() != 2)
        throw runtime_error(
                tfm::format("private former size incorrect,excepted 2, actually %s",private_former.size())
        );
    if(private_latter.size() != 2)
        throw runtime_error(
                tfm::format("private latter size incorrect,excepted 2, actually %s",private_latter.size())
        );
    if(public_board.size() != 5)
        throw runtime_error(
                tfm::format("public board size incorrect,excepted 2, actually %s",public_board.size())
        );

    vector<int> former_cards(private_former);
    former_cards.insert(former_cards.end(),public_board.begin(),public_board.end());
    int rank_former = this->getRank(former_cards);

    vector<int> latter_cards(private_latter);
    latter_cards.insert(latter_cards.end(),public_board.begin(),public_board.end());
    int rank_latter = this->getRank(latter_cards);

    return this->compairRanks(rank_former,rank_latter);
}
```