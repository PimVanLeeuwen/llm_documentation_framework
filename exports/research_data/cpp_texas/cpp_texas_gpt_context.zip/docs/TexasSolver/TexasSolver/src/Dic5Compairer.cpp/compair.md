`compair`: The function of `compair` is to compare two poker hands, each consisting of two private cards and a shared public board of five cards, and determine which hand is stronger.

**Parameters**:\
`vector<int> private_former`: A vector containing the two private cards of the first player. \
`vector<int> private_latter`: A vector containing the two private cards of the second player. \
`vector<int> public_board`: A vector containing the five public cards shared by both players.

**Code Description**: The `compair` method first checks if the sizes of the input vectors are correct: `private_former` and `private_latter` should each contain exactly 2 cards, and `public_board` should contain exactly 5 cards. If any of these conditions are not met, it throws a runtime error with a descriptive message.

Next, it combines the private cards of the first player (`private_former`) with the public board cards to form a complete hand and calculates its rank using the `getRank` method. Similarly, it combines the private cards of the second player (`private_latter`) with the public board cards to form another complete hand and calculates its rank.

Finally, it compares the two calculated ranks using the `compairRanks` method and returns the result, indicating whether the first player's hand is stronger, weaker, or equal to the second player's hand.\\
## Code: 
```
Compairer::CompairResult
Dic5Compairer::compair(vector<int> private_former, vector<int> private_latter, vector<int> public_board) {
    if(private_former.size() != 2)
        throw runtime_error(
                tfm::format("private former size incorrect,excepted 2, actually %s",private_former.size())
        );
    if(private_latter.size() != 2)
        throw runtime_error(
                tfm::format("private latter size incorrect,excepted 2, actually %s",private_latter.size())
        );
    if(public_board.size() != 5)
        throw runtime_error(
                tfm::format("public board size incorrect,excepted 2, actually %s",public_board.size())
        );

    vector<int> former_cards(private_former);
    former_cards.insert(former_cards.end(),public_board.begin(),public_board.end());
    int rank_former = this->getRank(former_cards);

    vector<int> latter_cards(private_latter);
    latter_cards.insert(latter_cards.end(),public_board.begin(),public_board.end());
    int rank_latter = this->getRank(latter_cards);

    return this->compairRanks(rank_former,rank_latter);
}
```