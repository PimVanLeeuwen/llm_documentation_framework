`getAction`: The function of `getAction` is to retrieve the current poker action stored in the `GameActions` object.

**Code Description**: This method, `getAction`, is a member of the `GameActions` class. It returns the value of the `action` attribute, which is of type `GameTreeNode::PokerActions`. This method provides a way to access the current poker action that has been set within the `GameActions` instance.\\
## Code: 
```
GameTreeNode::PokerActions GameActions::getAction() {
    return this->action;
}
```