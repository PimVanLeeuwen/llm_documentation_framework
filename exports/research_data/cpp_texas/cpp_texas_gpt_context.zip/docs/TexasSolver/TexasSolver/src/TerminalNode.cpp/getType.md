`getType`: The function of `getType` is to return the type of the node.

**Code Description**: The `getType` method in the `TerminalNode` class returns the type of the node, which is defined as `TERMINAL`. This method overrides the `getType` method from the `GameTreeNode` class and specifies that the node is a terminal node in the game tree.\\
## Code: 
```
GameTreeNode::GameTreeNodeType TerminalNode::getType() {
    return TERMINAL;
}
```