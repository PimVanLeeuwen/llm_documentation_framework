`update`: The function of `update` is to update the progress bar display based on the current progress.

**Code Description**: 
- The `update` method in the `progressbar` class is designed to visually update a progress bar in the console.
- Initially, it checks if the number of cycles (`n_cycles`) is set. If not, it throws a runtime error.
- If the `update` method is called for the first time, it initializes the progress bar display. If `do_show_bar` is true, it prints the opening bracket and fills the bar with `todo_char` characters, followed by "0%". If `do_show_bar` is false, it simply prints "0%".
- The method calculates the current percentage of progress (`perc`) based on the `progress` and `n_cycles`.
- If the percentage has not changed since the last update, the method returns without making any changes.
- If the percentage has increased by one unit, it updates the percentage display by erasing the previous percentage and printing the new one.
- If `do_show_bar` is true and the percentage is a multiple of 2, it updates the progress bar by erasing the appropriate number of `todo_char` characters and replacing them with `done_char` characters, then reprinting the percentage.
- The method updates the `last_perc` to the current percentage and increments the `progress`.
- Finally, it flushes the output to ensure the display is updated in the console.\\
## Code: 
```
void progressbar::update() {
    return;
    if (n_cycles == 0) throw std::runtime_error(
                "progressbar::update: number of cycles not set");

    if (!update_is_called) {
        if (do_show_bar == true) {
            std::cout << opening_bracket_char;
            for (int _ = 0; _ < 50; _++) std::cout << todo_char;
            std::cout << closing_bracket_char << " 0%";
        }
        else std::cout << "0%";
    }
    update_is_called = true;

    int perc = 0;

    // compute percentage, if did not change, do nothing and return
    perc = progress*100./(n_cycles-1);
    if (perc < last_perc) return;

    // update percentage each unit
    if (perc == last_perc + 1) {
        // erase the correct  number of characters
        if      (perc <= 10)                std::cout << "\b\b"   << perc << '%';
        else if (perc  > 10 && perc < 100) std::cout << "\b\b\b" << perc << '%';
        else if (perc == 100)               std::cout << "\b\b\b" << perc << '%';
    }
    if (do_show_bar == true) {
        // update bar every ten units
        if (perc % 2 == 0) {
            // erase closing bracket
            std::cout << std::string(closing_bracket_char.size(), '\b');
            // erase trailing percentage characters
            if      (perc  < 10)               std::cout << "\b\b\b";
            else if (perc >= 10 && perc < 100) std::cout << "\b\b\b\b";
            else if (perc == 100)              std::cout << "\b\b\b\b\b";

            // erase 'todo_char'
            for (int j = 0; j < 50-(perc-1)/2; ++j) {
                std::cout << std::string(todo_char.size(), '\b');
            }

            // add one additional 'done_char'
            if (perc == 0) std::cout << todo_char;
            else           std::cout << done_char;

            // refill with 'todo_char'
            for (int j = 0; j < 50-(perc-1)/2-1; ++j) std::cout << todo_char;

            // readd trailing percentage characters
            std::cout << closing_bracket_char << ' ' << perc << '%';
        }
    }
    last_perc = perc;
    ++progress;
    std::cout << std::flush;

    return;
}
```