`clear_board`: The function of `clear_board` is to reset all elements in the `grids_float` 2D array to zero.

**Code Description**: The `clear_board` method iterates through each element in the `grids_float` 2D array, which is indexed by `suitlist` and `ranklist`. For each element, it sets the value to zero, effectively clearing or resetting the board. This method ensures that all positions in the `grids_float` array are initialized to zero.\\
## Code: 
```
void BoardSelectorTableModel::clear_board(){
    for(int i = 0;i < this->suitlist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_float[i][j] = 0;
        }
    }
}
```