`isAllZeros`: The function of `isAllZeros` is to check if all elements in a given vector of floats are zero.

**Parameters**:\
`const vector<float>& input_array`: A constant reference to a vector of floats that needs to be checked for all zero values.

**Code Description**: The `isAllZeros` method iterates through each element in the `input_array` vector. For each element, it checks if the element is not equal to zero. If any element is found to be non-zero, the function immediately returns `false`. If the loop completes without finding any non-zero elements, the function returns `true`, indicating that all elements in the vector are zero.\\
## Code: 
```
bool DiscountedCfrTrainableSF::isAllZeros(const vector<float>& input_array) {
    for(float i:input_array){
        if (i != 0)return false;
    }
    return true;
}
```