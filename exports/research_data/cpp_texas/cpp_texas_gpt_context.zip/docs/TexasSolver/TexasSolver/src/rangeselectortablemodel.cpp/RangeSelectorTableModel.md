`RangeSelectorTableModel`: The function of `RangeSelectorTableModel` is to create a table model for selecting ranges based on rank lists and initial board settings.

**Parameters**:
`QStringList ranks`: A list of ranks used in the range selector.
`QString initial_board`: The initial board setting for the range selector.
`QObject *parent`: The parent object of the table model.
`bool thumbnail`: A flag indicating whether to display a thumbnail or not.

**Code Description**: 
The `RangeSelectorTableModel` class initializes its internal data structures based on the provided parameters. It creates a 2D grid of strings (`grids_string`) and floats (`grids_float`) with dimensions equal to the number of ranks in the list. The `get_ij_text` method is used to generate string representations of index pairs, which are stored in the grid along with their corresponding float values. The `setRangeText` method parses an input string into individual ranges and updates the grid accordingly.\\
## Code: 
```
RangeSelectorTableModel::RangeSelectorTableModel(QStringList ranks,QString initial_board,QObject *parent,bool thumbnail):QAbstractItemModel(parent){
    this->ranklist = ranks;
    this->thumbnail = thumbnail;

    this->grids_string = vector<vector<QString>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_string[i] = vector<QString>(this->ranklist.size());
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_string[i][j] = this->get_ij_text(i,j);
            this->string2ij[this->get_ij_text(i,j)] = pair<int,int>(i,j);
        }
    }

    this->grids_float = vector<vector<float>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_float[i] = vector<float>(this->ranklist.size(),0.0);
    }
    this->setRangeText(initial_board);
}
```