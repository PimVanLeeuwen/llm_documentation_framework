`RangeSelectorTableModel`: The function of `RangeSelectorTableModel` is to initialize a table model for selecting poker hand ranges, setting up the necessary data structures and initial values.

**Parameters**:\
`QStringList ranks`: A list of card ranks used to label the rows and columns of the table.\
`QString initial_board`: A string representing the initial state of the board, used to set up the initial values in the table.\
`QObject *parent`: The parent object, typically used for memory management within the Qt framework.\
`bool thumbnail`: A boolean flag indicating whether the model should be used in a thumbnail view.

**Code Description**: The `RangeSelectorTableModel` constructor initializes the table model by setting up the rank list and thumbnail flag. It creates a 2D vector `grids_string` to store string representations of poker hands and another 2D vector `grids_float` to store float values representing the range data. The constructor populates `grids_string` with hand representations using the `get_ij_text` method and maps these strings to their corresponding indices. It then initializes `grids_float` with zeros and calls the `setRangeText` method to set the initial values based on the `initial_board` string.\\
## Code: 
```
RangeSelectorTableModel::RangeSelectorTableModel(QStringList ranks,QString initial_board,QObject *parent,bool thumbnail):QAbstractItemModel(parent){
    this->ranklist = ranks;
    this->thumbnail = thumbnail;

    this->grids_string = vector<vector<QString>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_string[i] = vector<QString>(this->ranklist.size());
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_string[i][j] = this->get_ij_text(i,j);
            this->string2ij[this->get_ij_text(i,j)] = pair<int,int>(i,j);
        }
    }

    this->grids_float = vector<vector<float>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_float[i] = vector<float>(this->ranklist.size(),0.0);
    }
    this->setRangeText(initial_board);
}
```