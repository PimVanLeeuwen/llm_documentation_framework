`loading`: The function of `loading` is to initialize the `PokerSolver` objects for both holdem and shortdeck poker variants by loading the necessary comparison files and setting up the card ranks and suits.

**Code Description**: 
The `loading` method initializes the `PokerSolver` objects for two poker variants: holdem and shortdeck. It sets the directory for resource files and specifies the card suits. For holdem, it defines the card ranks from "2" to "A", and loads the corresponding comparison files (`card5_dic_sorted.txt` and `card5_dic_zipped.bin`). It then initializes the `PokerSolver` object for holdem with these parameters. Similarly, for shortdeck, it defines the card ranks from "6" to "A", loads the respective comparison files (`card5_dic_sorted_shortdeck.txt` and `card5_dic_zipped_shortdeck.bin`), and initializes the `PokerSolver` object for shortdeck. The method uses debug messages to indicate the progress of loading these files.\\
## Code: 
```
void QSolverJob::loading(){
    string suits = "c,d,h,s";
    string ranks;
    this->resource_dir =  ":/resources";
    string compairer_file, compairer_file_bin;
    int lines;
    qDebug().noquote() << tr("Loading holdem compairing file");//.toStdString() << endl;
    //if(mode == "holdem"){
    ranks = "2,3,4,5,6,7,8,9,T,J,Q,K,A";
    compairer_file = this->resource_dir + "/compairer/card5_dic_sorted.txt";
    compairer_file_bin = this->resource_dir + "/compairer/card5_dic_zipped.bin";
    //qDebug().noquote() << compairer_file_bin.c_str();
    lines = 2598961;
    this->ps_holdem = PokerSolver(ranks,suits,compairer_file,lines,compairer_file_bin);

    qDebug().noquote() << tr("Loading shortdeck compairing file");//.toStdString() << endl;
    //}else if(mode == "shortdeck"){
    ranks = "6,7,8,9,T,J,Q,K,A";
    compairer_file = this->resource_dir + "/compairer/card5_dic_sorted_shortdeck.txt";
    compairer_file_bin = this->resource_dir + "/compairer/card5_dic_zipped_shortdeck.bin";
    lines = 376993;
    this->ps_shortdeck = PokerSolver(ranks,suits,compairer_file,lines,compairer_file_bin);
    qDebug().noquote() << tr("Loading finished. Good to go.");//.toStdString() << endl;
}
```