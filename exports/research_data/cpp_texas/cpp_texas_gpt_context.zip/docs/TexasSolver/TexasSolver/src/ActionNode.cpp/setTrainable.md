`setTrainable`: The function of `setTrainable` is to set the `trainables` and `player_privates` attributes of the `ActionNode` object.

**Parameters**:\
`vector<shared_ptr<Trainable>> trainables`: A vector containing shared pointers to `Trainable` objects. These represent the trainable entities that the `ActionNode` will manage or interact with.\
`vector<PrivateCards>* player_privates`: A pointer to a vector of `PrivateCards` objects. These represent the private cards held by the players.

**Code Description**: The `setTrainable` method assigns the provided `trainables` vector to the `trainables` attribute and the provided `player_privates` pointer to the `player_privates` attribute of the `ActionNode` object. This allows the `ActionNode` to manage and access the specified trainable entities and player private cards.\\
## Code: 
```
void ActionNode::setTrainable(vector<shared_ptr<Trainable>> trainables,vector<PrivateCards>* player_privates) {
    this->trainables = trainables;
    this->player_privates = player_privates;
}
```