`getChildrens`: The function of `getChildrens` is to return a reference to the vector of child nodes of the current `ActionNode` object.

**Code Description**: This method, `getChildrens`, is a member of the `ActionNode` class. It returns a reference to the `childrens` member variable, which is a vector containing shared pointers to `GameTreeNode` objects. This allows access to the child nodes of the current `ActionNode` instance.\\
## Code: 
```
vector<shared_ptr<GameTreeNode>>& ActionNode::getChildrens() {
    return this->childrens;
}
```