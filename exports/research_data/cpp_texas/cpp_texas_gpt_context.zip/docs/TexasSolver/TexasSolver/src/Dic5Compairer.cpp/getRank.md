`getRank`: The function of `getRank` is to calculate the rank of a given set of cards by converting them to their integer representations and then determining their rank.

**Parameters**:\
`vector<Card> cards`: A vector of `Card` objects representing the cards whose rank needs to be determined.

**Code Description**: This method takes a vector of `Card` objects as input and converts each `Card` to its integer representation using the `getCardInt` method. It then calls another `getRank` method that operates on a vector of integers to calculate and return the rank of the given set of cards.\\
## Code: 
```
int Dic5Compairer::getRank(vector<Card> cards) {
    vector<int> cards_int(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_int[i] = cards[i].getCardInt();
    }
    return this->getRank(cards_int);
}
```