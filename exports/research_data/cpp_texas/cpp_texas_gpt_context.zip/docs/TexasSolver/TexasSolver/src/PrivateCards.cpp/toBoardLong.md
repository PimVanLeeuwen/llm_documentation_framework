`toBoardLong`: The function of `toBoardLong` is to return the value of the `board_long` member variable of the `PrivateCards` object.

**Code Description**: This method, `toBoardLong`, is a member function of the `PrivateCards` class. When called, it returns the value stored in the `board_long` attribute of the `PrivateCards` instance. The method does not take any parameters and simply provides access to the `board_long` data. The commented-out line suggests an alternative implementation that converts a vector of cards (`card_vec`) to a long integer representation using a function `boardInts2long` from the `Card` class, but this line is not active in the current implementation.\\
## Code: 
```
uint64_t PrivateCards::toBoardLong() {
    return this->board_long;
    //return Card::boardInts2long(this->card_vec);
}
```