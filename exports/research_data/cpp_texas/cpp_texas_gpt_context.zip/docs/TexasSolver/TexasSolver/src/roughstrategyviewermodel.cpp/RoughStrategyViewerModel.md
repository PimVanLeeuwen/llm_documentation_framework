`RoughStrategyViewerModel`: The function of `RoughStrategyViewerModel` is to initialize an instance of the `RoughStrategyViewerModel` class, setting up its parent and associating it with a `TableStrategyModel`.

**Parameters**:\
`TableStrategyModel* tableStrategyModel`: A pointer to a `TableStrategyModel` object that this model will use to retrieve strategy data. \
`QObject *parent`: A pointer to the parent `QObject`, which is passed to the base class constructor to establish the parent-child relationship in the Qt object hierarchy.

**Code Description**: The constructor of the `RoughStrategyViewerModel` class initializes the model by calling the base class `QAbstractItemModel` constructor with the provided `parent` parameter. It also assigns the provided `tableStrategyModel` to the class member variable `this->tableStrategyModel`, allowing the model to interact with the strategy data contained in the `TableStrategyModel` object.\\
## Code: 
```
RoughStrategyViewerModel::RoughStrategyViewerModel(TableStrategyModel* tableStrategyModel, QObject *parent):QAbstractItemModel(parent){
    this->tableStrategyModel = tableStrategyModel;
}
```