`index`: The function of `index` is to return a `QModelIndex` representing the item in the model specified by the given row and column.

**Parameters**:\
`int row`: The row number of the item in the model.\
`int column`: The column number of the item in the model.\
`const QModelIndex &parent`: The parent index of the item. This parameter is not used in this method.

**Code Description**: This method first checks if the specified row and column are valid within the context of the model using the `hasIndex` method. If the indices are valid, it creates and returns a `QModelIndex` for the specified row and column using the `createIndex` method. If the indices are not valid, it returns an invalid `QModelIndex`.\\
## Code: 
```
QModelIndex RangeSelectorTableModel::index(int row, int column,
          const QModelIndex &parent) const  {
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    return createIndex(row, column, nullptr);
}
```