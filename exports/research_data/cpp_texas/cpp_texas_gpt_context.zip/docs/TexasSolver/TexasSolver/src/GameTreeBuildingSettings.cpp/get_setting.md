`get_setting`: The function of `get_setting` is to return the appropriate `StreetSetting` object based on the player type and the round of the game.

**Parameters**:\
`string player`: Specifies the player type, either "ip" (in position) or "oop" (out of position). \
`string round`: Specifies the round of the game, either "flop", "turn", or "river".

**Code Description**: The `get_setting` method in the `GameTreeBuildingSettings` class takes two string parameters, `player` and `round`. It returns a reference to the corresponding `StreetSetting` object based on the combination of these parameters. If the `player` is "ip" and the `round` is "flop", it returns `flop_ip`. If the `player` is "ip" and the `round` is "turn", it returns `turn_ip`. If the `player` is "ip" and the `round` is "river", it returns `river_ip`. Similarly, if the `player` is "oop" and the `round` is "flop", it returns `flop_oop`. If the `player` is "oop" and the `round` is "turn", it returns `turn_oop`. If the `player` is "oop" and the `round` is "river", it returns `river_oop`. If the combination of `player` and `round` does not match any of these cases, the method throws a runtime error indicating that the provided settings are not valid.\\
## Code: 
```
StreetSetting& GameTreeBuildingSettings::get_setting(string player,string round){
    if(player == "ip" && round == "flop") return flop_ip;
    else if(player == "ip" && round == "turn") return turn_ip;
    else if(player == "ip" && round == "river") return river_ip;
    else if(player == "oop" && round == "flop") return flop_oop;
    else if(player == "oop" && round == "turn") return turn_oop;
    else if(player == "oop" && round == "river") return river_oop;
    else throw runtime_error("get_setting not valid");
}
```