`get_solver`: The function of `get_solver` is to return a pointer to the appropriate `PokerSolver` instance based on the current mode of the `QSolverJob` object.

**Code Description**: The `get_solver` method checks the `mode` attribute of the `QSolverJob` object. If the mode is `Mode::HOLDEM`, it returns a pointer to the `ps_holdem` solver. If the mode is `Mode::SHORTDECK`, it returns a pointer to the `ps_shortdeck` solver. If the mode is neither of these, it throws a runtime error indicating an unknown mode.\\
## Code: 
```
PokerSolver* QSolverJob::get_solver(){
    if(this->mode == Mode::HOLDEM){
        return &this->ps_holdem;
    }else if(this->mode == Mode::SHORTDECK){
        return &this->ps_shortdeck;
    }else throw runtime_error("unknown mode in get_solver");
}
```