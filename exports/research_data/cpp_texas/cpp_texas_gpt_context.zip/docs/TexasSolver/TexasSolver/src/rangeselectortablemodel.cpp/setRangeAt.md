`setRangeAt`: The function of `setRangeAt` is to set a specific value in a 2D grid at the specified row and column indices.

**Parameters**:\
`int i`: The row index in the 2D grid where the value should be set.\
`int j`: The column index in the 2D grid where the value should be set.\
`float value`: The value to be set at the specified row and column indices.

**Code Description**: The `setRangeAt` method first checks if the provided row index `i` is within the valid range of the `ranklist` size. If `i` is out of bounds, it logs an error message indicating that the index `i` is not valid. Similarly, it checks if the provided column index `j` is within the valid range of the `ranklist` size. If `j` is out of bounds, it logs an error message indicating that the index `j` is not valid. If both indices are valid, it sets the value at the specified position in the `grids_float` 2D array.\\
## Code: 
```
void RangeSelectorTableModel::setRangeAt(int i, int j,float value){
    if(i < 0 || i >= this->ranklist.size()){
        qDebug().noquote() << "RangeSelectorTableModel::setRangeAt i not valid: " << i;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "RangeSelectorTableModel::setRangeAt j not valid: " << j;
    }
    else{
        this->grids_float[i][j] = value;
    }
}
```