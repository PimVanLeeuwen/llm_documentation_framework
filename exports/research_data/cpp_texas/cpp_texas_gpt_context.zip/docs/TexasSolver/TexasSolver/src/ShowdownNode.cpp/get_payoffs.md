`get_payoffs`: The function of `get_payoffs` is to return the payoffs for the players based on the result of the showdown and the winner.

**Parameters**:\
`ShowdownNode::ShowDownResult result`: An enumeration value indicating whether the showdown resulted in a tie or not. \
`int winner`: An integer representing the index of the winning player, or -1 if there is no winner (in case of a tie).

**Code Description**: The `get_payoffs` method first checks if the showdown result is not a tie (`ShowDownResult::NOTTIE`). If it is not a tie and the winner is -1, it throws a runtime error indicating an invalid state. If the winner is valid, it returns the payoffs for the winning player from the `player_payoffs` vector. If the showdown is a tie, it checks that the winner is -1 (as there should be no winner in a tie) and returns the `tie_payoffs` vector.\\
## Code: 
```
vector<double> ShowdownNode::get_payoffs(ShowdownNode::ShowDownResult result, int winner) {
    if(result == ShowDownResult::NOTTIE){
        if(winner == -1) throw runtime_error("winner == -1 in tie");
        vector<double> retval = player_payoffs[winner];
        return retval;
    }else{
        // if the showdown is a tie
        if(winner != -1) throw runtime_error("winner != -1 in not tie");
        return this->tie_payoffs;
    }
}
```