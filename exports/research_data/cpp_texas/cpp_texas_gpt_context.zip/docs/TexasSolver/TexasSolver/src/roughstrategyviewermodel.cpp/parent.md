`parent`: The function of `parent` is to return the parent index of a given child index in the model. 
**Parameters**:\
`const QModelIndex &child`: The index of the child item for which the parent index is to be determined. \

**Code Description**: This implementation of the `parent` method always returns an invalid `QModelIndex`, indicating that the model does not have a hierarchical structure or that all items are top-level items without parents.\\
## Code: 
```
QModelIndex RoughStrategyViewerModel::parent(const QModelIndex &child) const{
    return QModelIndex();
}
```