`copyStrategy`: The function of `copyStrategy` is to copy the strategy-related data from another `DiscountedCfrTrainableHF` object to the current object.

**Parameters**:\
`shared_ptr<Trainable> other_trainable`: A shared pointer to another `Trainable` object from which the strategy data will be copied. This object is expected to be of type `DiscountedCfrTrainableHF`.

**Code Description**: The `copyStrategy` method first attempts to cast the provided `other_trainable` object to a `shared_ptr<DiscountedCfrTrainableHF>`. If the cast is successful, it copies the `r_plus` and `cum_r_plus` vectors from the `other_trainable` object to the current object. This ensures that the current object has the same strategy-related data as the `other_trainable` object.\\
## Code: 
```
void DiscountedCfrTrainableHF::copyStrategy(shared_ptr<Trainable> other_trainable){
    shared_ptr<DiscountedCfrTrainableHF> trainable = dynamic_pointer_cast<DiscountedCfrTrainableHF>(other_trainable);
    this->r_plus.assign(trainable->r_plus.begin(),trainable->r_plus.end());
    this->cum_r_plus.assign(trainable->cum_r_plus.begin(),trainable->cum_r_plus.end());
}
```