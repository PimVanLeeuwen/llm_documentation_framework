`stop`: The function of `stop` is to halt the operation of the solver if it is currently running.

**Code Description**: The `stop` method in the `PokerSolver` class checks if the `solver` object is not a null pointer. If the `solver` object exists, it calls the `stop` method on the `solver` object to stop its operation. This ensures that any ongoing processes managed by the `solver` are properly terminated.\\
## Code: 
```
void PokerSolver::stop(){
    if(this->solver != nullptr){
        this->solver->stop();
    }
}
```