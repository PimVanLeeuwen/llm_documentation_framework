`load_game_tree`: The function of `load_game_tree` is to load and initialize a game tree for a poker game from a specified file.

**Parameters**:\
`string game_tree_file`: The path to the file containing the game tree data.

**Code Description**: The `load_game_tree` method creates a shared pointer to a `GameTree` object, initializing it with the provided game tree file and the current deck. It then assigns this newly created `GameTree` object to the `game_tree` member variable of the `PokerSolver` class.\\
## Code: 
```
void PokerSolver::load_game_tree(string game_tree_file) {
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(game_tree_file,this->deck);
    this->game_tree = game_tree;
}
```