`stop`: The function of `stop` is to halt the solver process based on the current mode of the solver.

**Code Description**: The `stop` method in the `QSolverJob` class attempts to stop the solver by first logging a message indicating the attempt. It then checks the current mode of the solver. If the mode is `HOLDEM`, it calls the `stop` method on the `ps_holdem` object. If the mode is `SHORTDECK`, it calls the `stop` method on the `ps_shortdeck` object.\\
## Code: 
```
void QSolverJob::stop(){
    qDebug().noquote() << tr("Trying to stop solver.");
    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.stop();
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.stop();
    }
}
```