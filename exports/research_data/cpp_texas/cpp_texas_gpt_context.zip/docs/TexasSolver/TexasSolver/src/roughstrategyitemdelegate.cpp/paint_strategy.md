`paint_strategy`: The function of `paint_strategy` is to render the visual representation of a poker strategy item in a table view, using different colors and text based on the type of poker action and its associated data.

**Parameters**:\
`QPainter *painter`: A pointer to the `QPainter` object used for drawing the item. \
`const QStyleOptionViewItem &option`: A reference to the style options for the item, which includes information such as the item's state, rectangle, and palette. \
`const QModelIndex &index`: A reference to the model index that identifies the item to be painted.

**Code Description**: 
1. The method starts by initializing the style options for the item using `initStyleOption`.
2. It retrieves the `RoughStrategyViewerModel` from the model associated with the `index`.
3. It clears the text in the options and checks if the current tree item is of type `ACTION`.
4. If the column index is within the bounds of the strategy data, it proceeds to determine the appropriate brush color based on the poker actions (FOLD, CHECK, CALL, BET, RAISE).
5. It fills the item's rectangle with the determined brush color.
6. It constructs an HTML string representing the poker action, its percentage, and the number of combos, and sets this string as the text in the options.
7. A `QTextDocument` is used to render the HTML text.
8. The painter translates to the item's top-left corner and draws the HTML content within the item's rectangle.\\
## Code: 
```
void RoughStrategyItemDelegate::paint_strategy(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);

    const RoughStrategyViewerModel * roughStrategyViewerModel = qobject_cast<const RoughStrategyViewerModel*>(index.model());

    options.text = "";
    if(roughStrategyViewerModel->tableStrategyModel->treeItem != NULL &&
            roughStrategyViewerModel->tableStrategyModel->treeItem->m_treedata.lock()->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<GameTreeNode> node = roughStrategyViewerModel->tableStrategyModel->treeItem->m_treedata.lock();
        if(index.column() >= roughStrategyViewerModel->tableStrategyModel->total_strategy.size()) return;

        pair<GameActions,pair<float,float>> one_strategy = roughStrategyViewerModel->tableStrategyModel->total_strategy[index.column()];

        QBrush brush(Qt::gray);
        int bet_raise_num = 0;
        for(int i = 0;i <= index.column();i ++){
            GameActions one_action = roughStrategyViewerModel->tableStrategyModel->total_strategy[i].first;
            if(one_action.getAction() == GameTreeNode::PokerActions::FOLD){
                brush = QBrush(QColor	(0,191,255));
            }
            else if(one_action.getAction() == GameTreeNode::PokerActions::CHECK
            || one_action.getAction() == GameTreeNode::PokerActions::CALL){
                brush = QBrush(Qt::green);
            }
            else if(one_action.getAction() == GameTreeNode::PokerActions::BET
            || one_action.getAction() == GameTreeNode::PokerActions::RAISE){
                int color_base = max(128 - 32 * bet_raise_num - 1,0);
                brush = QBrush(QColor(255,color_base,color_base));
                bet_raise_num += 1;
            }else{
                brush = QBrush(Qt::blue);
            }
        }
        QRect rect(option.rect.left(), option.rect.top(),\
             option.rect.width(), option.rect.height());
        painter->fillRect(rect, brush);

        options.text = "";
        GameActions one_action = one_strategy.first;
        float one_strategy_float = one_strategy.second.second * 100;
        float one_combo = one_strategy.second.first;
        if(one_action.getAction() ==  GameTreeNode::PokerActions::FOLD){
            options.text +=  QString(" <h3> %1 <\/h3> <h4>%2\%<\/h4> <h4>%3 %4<\/h4>").arg(tr("FOLD"),QString::number(one_strategy_float,'f',1),QString::number(one_combo,'f',1),tr("combos"));
        }
        else if(one_action.getAction() ==  GameTreeNode::PokerActions::CALL){
            options.text +=  QString(" <h3> %1 <\/h3> <h4>%2\%<\/h4> <h4>%3 %4<\/h4>").arg(tr("CALL"),QString::number(one_strategy_float,'f',1),QString::number(one_combo,'f',1),tr("combos"));

        }
        else if(one_action.getAction() ==  GameTreeNode::PokerActions::CHECK){
            options.text +=  QString(" <h3> %1 <\/h3> <h4>%2\%<\/h4> <h4>%3 %4<\/h4>").arg(tr("CHECK"),QString::number(one_strategy_float,'f',1),QString::number(one_combo,'f',1),tr("combos"));
        }
        else if(one_action.getAction() ==  GameTreeNode::PokerActions::BET){
            options.text +=  QString(" <h3> %1 %2 <\/h3> <h4>%3\%<\/h4> <h4>%4 %5<\/h4>").arg(tr("BET"),QString::number(one_action.getAmount(),'f',1),QString::number(one_strategy_float,'f',1),QString::number(one_combo,'f',1),tr("combos"));
        }
        else if(one_action.getAction() ==  GameTreeNode::PokerActions::RAISE){
            options.text +=  QString(" <h3> %1 %2 <\/h3> <h4>%3\%<\/h4> <h4>%4 %5<\/h4>").arg(tr("RAISE"),QString::number(one_action.getAmount(),'f',1),QString::number(one_strategy_float,'f',1),QString::number(one_combo,'f',1),tr("combos"));
        }

    }
    QTextDocument doc;
    doc.setHtml(options.text);

    options.text = "";
    //options.widget->style()->drawControl(QStyle::CE_ItemViewItem, &option, painter);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```