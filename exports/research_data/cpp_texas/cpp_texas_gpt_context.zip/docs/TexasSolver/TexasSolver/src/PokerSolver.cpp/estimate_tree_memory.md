`estimate_tree_memory`: The function of `estimate_tree_memory` is to estimate the memory required for the game tree based on the given ranges of private hands for two players and the current board state.

**Parameters**:\
`QString range1`: A string representing the range of private hands for player 1. \
`QString range2`: A string representing the range of private hands for player 2. \
`QString board`: A string representing the current board state, with cards separated by commas.

**Code Description**: 
The `estimate_tree_memory` method first checks if the game tree has been built. If not, it logs a message and returns 0. If the game tree exists, it converts the input ranges and board state from `QString` to standard strings. It then splits the board string into individual card strings and converts these to integer representations. Using these integers, it converts the private hand ranges for both players into vectors of `PrivateCards` objects. Finally, it calls the `estimate_tree_memory` method of the game tree object, passing the number of remaining cards in the deck and the sizes of the two private hand ranges, and returns the estimated memory usage.\\
## Code: 
```
long long PokerSolver::estimate_tree_memory(QString range1,QString range2,QString board){
    if(this->game_tree == nullptr){
        qDebug().noquote() << QObject::tr("Please buld tree first.");
        return 0;
    }
    else{
        string player1RangeStr = range1.toStdString();
        string player2RangeStr = range2.toStdString();

        vector<string> board_str_arr = string_split(board.toStdString(),',');
        vector<int> initialBoard;
        for(string one_board_str:board_str_arr){
            initialBoard.push_back(Card::strCard2int(one_board_str));
        }

        vector<PrivateCards> range1 = PrivateRangeConverter::rangeStr2Cards(player1RangeStr,initialBoard);
        vector<PrivateCards> range2 = PrivateRangeConverter::rangeStr2Cards(player2RangeStr,initialBoard);
        return this->game_tree->estimate_tree_memory(this->deck.getCards().size() - initialBoard.size(),range1.size(),range2.size());
    }
}
```