`headerData`: The function of `headerData` is to retrieve the header data for a specified section in a tree model, based on the orientation and role.

**Parameters**:\
`int section`: The section of the header (column or row) for which the data is requested.\
`Qt::Orientation orientation`: The orientation of the header, either horizontal or vertical.\
`int role`: The role for which the data is requested, typically used to specify the type of data (e.g., display, decoration).

**Code Description**: This method checks if the orientation is horizontal and the role is `Qt::DisplayRole`. If both conditions are met, it returns the data of the root item of the tree model. If the conditions are not met, it returns an invalid `QVariant`.\\
## Code: 
```
QVariant TreeModel::headerData(int section, Qt::Orientation orientation,
                               int role) const
{
    if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
        return rootItem->data();

    return QVariant();
}
```