`rowCount`: The function of `rowCount` is to return the number of rows in the model.

**Parameters**:\
`const QModelIndex &parent`: This parameter is a reference to a QModelIndex object, which represents the parent index in the model. It is not used in this implementation.

**Code Description**: This method always returns the integer value `1`, indicating that the model contains exactly one row, regardless of the input parameter.\\
## Code: 
```
int RoughStrategyViewerModel::rowCount(const QModelIndex &parent) const
{
    return 1;
}
```