`DetailWindowSetting`: The function of `DetailWindowSetting` is to initialize an instance of the `DetailWindowSetting` class with a default mode.

**Code Description**: The constructor `DetailWindowSetting` sets the `mode` attribute of the class instance to `DetailWindowMode::STRATEGY` by default. This ensures that any new instance of `DetailWindowSetting` starts with the `STRATEGY` mode.\\
## Code: 
```
DetailWindowSetting::DetailWindowSetting(){
    this->mode = DetailWindowMode::STRATEGY;
}
```