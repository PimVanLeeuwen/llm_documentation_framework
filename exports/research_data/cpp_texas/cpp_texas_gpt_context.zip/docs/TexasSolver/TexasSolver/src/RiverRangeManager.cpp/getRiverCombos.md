`getRiverCombos`: The function of `getRiverCombos` is to retrieve or compute the possible river combinations for a given player based on their preflop combinations and the current board state.

**Parameters**:\
`int player`: The player identifier (0 or 1) for whom the river combinations are being retrieved or computed. \
`const vector<PrivateCards> &preflopCombos`: A vector containing the preflop card combinations for the player. \
`uint64_t board_long`: A 64-bit integer representing the current board state.

**Code Description**: 
The `getRiverCombos` method first determines which player's river ranges to use based on the `player` parameter. It then locks a mutex to ensure thread safety while accessing the shared `riverRanges` map. If the river combinations for the given board state (`board_long`) are already computed and stored in the map, it retrieves and returns them.

If the river combinations are not already computed, the method calculates the number of valid river combinations by iterating through the `preflopCombos` and checking if they do not intersect with the current board state. It then creates a vector of `RiverCombs` objects, each representing a valid river combination, and sorts them by their rank in descending order.

Finally, the method stores the computed river combinations in the `riverRanges` map, unlocks the mutex, and returns the newly computed river combinations.\\
## Code: 
```
const vector<RiverCombs> &
RiverRangeManager::getRiverCombos(int player, const vector<PrivateCards> &preflopCombos, uint64_t board_long) {
    unordered_map<uint64_t , vector<RiverCombs>>* riverRanges;

    if (player == 0)
        riverRanges = &p1RiverRanges;
    else if (player == 1)
        riverRanges = &p2RiverRanges;
    else
        throw runtime_error(tfm::format("player %s not found",player));

    uint64_t key = board_long;

    this->maplock->lock();
    if (riverRanges->find(key) != riverRanges->end()) {
        const vector<RiverCombs> &retval = (*riverRanges)[key];
        this->maplock->unlock();
        return retval;
    }
    this->maplock->unlock();

    int count = 0;

    for (auto one_hand : preflopCombos) {
        if (!Card::boardsHasIntercept(
                one_hand.toBoardLong(), board_long
        ))
            count++;
    }

    int index = 0;
    vector<RiverCombs> riverCombos = vector<RiverCombs>(count);

    for (std::size_t hand = 0; hand < preflopCombos.size(); hand++)
    {
        PrivateCards preflopCombo = preflopCombos[hand];


        if (Card::boardsHasIntercept(
                preflopCombo.toBoardLong(), board_long
        )){
            continue;
        }

        int rank = this->handEvaluator->get_rank(preflopCombo.toBoardLong(),board_long);
        RiverCombs riverCombo = RiverCombs(Card::long2board(board_long),preflopCombo,rank, hand);
        riverCombos[index++] = riverCombo;
    }

    std::sort(riverCombos.begin(),riverCombos.end(),[ ]( const RiverCombs& lhs, const RiverCombs& rhs )
    {
        return lhs.rank > rhs.rank;
    });

    this->maplock->lock();
    (*riverRanges)[key] =  std::move(riverCombos);
    this->maplock->unlock();

    return (*riverRanges)[key];
}
```