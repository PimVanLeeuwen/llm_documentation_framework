`columnCount`: The function of `columnCount` is to return the number of columns in the table model.

**Parameters**:\
`const QModelIndex &parent`: This parameter is a reference to a QModelIndex object, which represents the parent index in the model. It is not used in this method.

**Code Description**: This method returns the size of the `ranklist` vector, which represents the number of columns in the table model. The `ranklist` vector is a member of the `RangeSelectorTableModel` class.\\
## Code: 
```
int RangeSelectorTableModel::columnCount(const QModelIndex &parent) const {
    return this->ranklist.size();
}
```