`~RoughStrategyViewerModel`: The function of `~RoughStrategyViewerModel` is to serve as the destructor for the `RoughStrategyViewerModel` class.

**Code Description**: This destructor method is defined for the `RoughStrategyViewerModel` class. It is currently empty, meaning it does not perform any specific actions when an instance of `RoughStrategyViewerModel` is destroyed. Destructors are typically used to release resources or perform clean-up tasks, but in this case, no such tasks are defined.\\
## Code: 
```
RoughStrategyViewerModel::~RoughStrategyViewerModel()
{
}
```