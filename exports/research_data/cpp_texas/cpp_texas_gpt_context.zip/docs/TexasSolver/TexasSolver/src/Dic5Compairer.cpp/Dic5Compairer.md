`Dic5Compairer`: The function of `Dic5Compairer` is to initialize a comparer object that loads and processes a dictionary of poker hand rankings from a text file or a binary file.

**Parameters**:\
`string dic_dir`: The directory path to the text file containing the dictionary of poker hand rankings. \
`int lines`: The number of lines in the text file. \
`string dic_dir_bin`: The directory path to the binary file for the dictionary of poker hand rankings.

**Code Description**: 
- The constructor `Dic5Compairer` initializes the comparer object by calling the base class constructor `Compairer` with the provided `dic_dir` and `lines`.
- It attempts to load the dictionary from the binary file specified by `dic_dir_bin`. If successful, it returns immediately.
- If loading from the binary file fails, it opens the text file specified by `dic_dir` for reading.
- It reads the text file line by line, splitting each line into a poker hand string and its corresponding rank.
- Each poker hand string is further split into individual cards, and the cards are converted into a unique long integer representation using `Card::boardCards2long`.
- The rank is then stored in the `cardslong2rank` map with the long integer representation of the cards as the key.
- After processing all lines, the `cardslong2rank` map is converted into two separate maps for flush and non-flush hands using the `convert` method.
- The consistency of the converted maps is checked using the `check` method. If the check fails, a runtime error is thrown.
- Finally, the `cardslong2rank` map is cleared to free up memory.\\
## Code: 
```
Dic5Compairer::Dic5Compairer(string dic_dir,int lines,string dic_dir_bin):Compairer(std::move(dic_dir),lines){
    if(fcs.load(dic_dir_bin.c_str())) return;
    QFile infile(QString::fromStdString(this->dic_dir));
    if (!infile.open(QIODevice::ReadOnly)){
        throw runtime_error("unable to load compairer file");
    }
    QTextStream in(&infile);
    //progressbar bar(lines / 1000);
    int i = 0;
    //while (std::getline(infile, line))
    while (!in.atEnd())
    {
        string line = in.readLine().toStdString();
        vector<string> linesp = string_split(line,',');
        if(linesp.size() != 2){
           throw runtime_error(tfm::format("linesp not correct: %s",line));
        }
        string cards_str = linesp[0];
        int rank = stoi(linesp[1]);
        vector<string> cards = string_split(cards_str,'-');

        if(cards.size() != 5)
            throw runtime_error(
                    tfm::format(
                            "cards not correct: %s length %s",cards_str,cards.size()));

        //set<string> cards_set;
        //for(string one_card:cards) cards_set.insert(one_card);
        //this->card2rank[cards_set] = rank;

        if(this->cardslong2rank.find(Card::boardCards2long(cards)) != this->cardslong2rank.end()){
            throw runtime_error(
                    tfm::format("key repeated: %s",cards_str)
                    );
        }

        this->cardslong2rank[Card::boardCards2long(cards)] = rank;

        i ++;
        if(i % 1000 == 0) {
            //bar.update();
        }
    }
    //cout << endl;
    fcs.convert(this->cardslong2rank);
    if(!fcs.check(this->cardslong2rank)){
        //fcs.save(dic_dir_bin.c_str());
        throw runtime_error("check consistency failed");
    }
    this->cardslong2rank.clear();
}
```