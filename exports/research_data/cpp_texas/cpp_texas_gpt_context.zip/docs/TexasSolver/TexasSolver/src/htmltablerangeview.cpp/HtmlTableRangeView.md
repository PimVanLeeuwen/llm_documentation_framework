`HtmlTableRangeView`: The function of `HtmlTableRangeView` is to initialize an instance of the `HtmlTableRangeView` class, which is a specialized view for displaying HTML tables with range selection capabilities.

**Parameters**:\
`QWidget *parent`: A pointer to the parent widget, which is passed to the constructor of the base class `HtmlTableView`.

**Code Description**: The constructor `HtmlTableRangeView` initializes the object by calling the constructor of its base class `HtmlTableView` with the provided parent widget. It then installs an event filter on the viewport to handle custom events. Mouse tracking is enabled to capture mouse movements, and the `mouseTracker` object is initialized with default values, setting `tracking` to `false` and `pressed_i` and `pressed_j` to `-1`, indicating no mouse button is pressed initially.\\
## Code: 
```
HtmlTableRangeView::HtmlTableRangeView(QWidget *parent):
HtmlTableView(parent)
{
    viewport()->installEventFilter(this);
    setMouseTracking(true);
    mouseTracker.tracking = false;
    mouseTracker.pressed_i = -1;
    mouseTracker.pressed_j = -1;
}
```