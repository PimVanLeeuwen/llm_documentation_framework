`noDuplicateRange`: The function of `noDuplicateRange` is to filter out duplicate and conflicting private card ranges from a given set of private cards, ensuring no overlap with the specified board cards.

**Parameters**:\
`const vector<PrivateCards> &private_range`: A constant reference to a vector of `PrivateCards` objects representing the range of private hands to be filtered. \
`uint64_t board_long`: A 64-bit integer representing the board cards, where each bit corresponds to the presence of a specific card.

**Code Description**: This method iterates through a vector of `PrivateCards` objects (`private_range`). For each `PrivateCards` object, it checks if its hash code already exists in an unordered map (`rangekv`). If a duplicate is found, it throws a runtime error. Otherwise, it adds the hash code to the map. It then converts the private hand cards to a 64-bit integer (`hand_long`) and checks for any overlap with the board cards (`board_long`). If there is no overlap, the `PrivateCards` object is added to the result vector (`range_array`). Finally, the method returns the filtered vector of `PrivateCards` objects.\\
## Code: 
```
vector<PrivateCards> noDuplicateRange(const vector<PrivateCards> &private_range, uint64_t board_long) {
    vector<PrivateCards> range_array;
    unordered_map<int,bool> rangekv;
    for(PrivateCards one_range:private_range){
        if(rangekv.find(one_range.hashCode()) != rangekv.end())
            throw runtime_error(tfm::format("duplicated key %s",one_range.toString()));
        rangekv[one_range.hashCode()] = true;
        uint64_t hand_long = Card::boardInts2long(one_range.get_hands());
        if(!Card::boardsHasIntercept(hand_long,board_long)){
            range_array.push_back(one_range);
        }
    }
    return range_array;
}
```