`DiscountedCfrTrainableHF`: The function of `DiscountedCfrTrainableHF` is to initialize an instance of the `DiscountedCfrTrainableHF` class with given private cards and an action node, setting up necessary data structures for further computations.

**Parameters**:\
`vector<PrivateCards> *privateCards`: A pointer to a vector containing `PrivateCards` objects, representing the private cards in the game.\
`ActionNode &actionNode`: A reference to an `ActionNode` object, representing the current node in the game tree where actions are being considered.

**Code Description**: The constructor `DiscountedCfrTrainableHF` initializes the class with the provided private cards and action node. It sets the `privateCards` member variable to the provided pointer and initializes the `action_node` member variable with the given `actionNode` reference. The constructor then determines the number of actions (`action_number`) by getting the size of the children of the `actionNode`. It also calculates the number of private cards (`card_number`). It initializes three vectors: `evs`, `r_plus`, and `cum_r_plus`, each sized to the product of `action_number` and `card_number`, and fills them with initial values of 0.0. These vectors are used to store expected values, R+ values, and cumulative R+ values, respectively, for further computations in the algorithm.\\
## Code: 
```
DiscountedCfrTrainableHF::DiscountedCfrTrainableHF(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();
    this->evs = vector<EvsStorage>(this->action_number * this->card_number, (EvsStorage) 0.0);
    this->r_plus = vector<RplusStorage>(this->action_number * this->card_number, (RplusStorage) 0.0);
    this->cum_r_plus = vector<CumRplusStorage>(this->action_number * this->card_number, (CumRplusStorage) 0.0);
}
```