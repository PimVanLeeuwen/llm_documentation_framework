`saving`: The function of `saving` is to save the current strategy to a JSON file based on the mode and settings.

**Code Description**: 
The `saving` method in the `QSolverJob` class performs the following actions:
1. Logs a message indicating the start of the saving process.
2. Reads the "dump_round" setting from the application's settings under the "solver" group.
3. Logs the value of the "dump_round" setting.
4. If the "dump_round" value is 3, logs a warning about potential performance issues.
5. Depending on the mode (HOLDEM or SHORTDECK), it calls the appropriate `dump_strategy` method to save the strategy to the specified file.
6. Logs a message indicating the completion of the saving process.\\
## Code: 
```
void QSolverJob::saving(){
    qDebug().noquote() << tr("Saving json file..");//.toStdString() << std::endl;

    QSettings setting("TexasSolver", "Setting");
    setting.beginGroup("solver");
    this->dump_rounds = setting.value("dump_round").toInt();

    qDebug().noquote() << tr("Dump round: ") << this->dump_rounds;
    if(this->dump_rounds == 3){
        qDebug().noquote() << tr("This could be slow, or even blow your RAM, dump to river is not well optimized :(");
    }
    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.dump_strategy(this->savefile,this->dump_rounds);
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.dump_strategy(this->savefile,this->dump_rounds);
    }
    qDebug().noquote() << tr("Saving done.");//.toStdString() << std::endl;
}
```