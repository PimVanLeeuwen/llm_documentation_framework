`run`: The function of `run` is to execute a specific mission based on the current mission type of the `QSolverJob` object.

**Code Description**: The `run` method in the `QSolverJob` class determines the current mission type and executes the corresponding method. It handles four mission types: `SOLVING`, `LOADING`, `BUILDTREE`, and `SAVING`. If the mission type is `SOLVING`, it calls the `solving` method; if `LOADING`, it calls the `loading` method; if `BUILDTREE`, it calls the `build_tree` method; and if `SAVING`, it calls the `saving` method. If the mission type is unsupported, it throws a runtime error. The method also includes error handling to catch and log any runtime errors that occur during execution.\\
## Code: 
```
void QSolverJob::run()
{
    //QDebugStream qout(qDebug().noquote(), this->textEdit);
    try{
        if(this->current_mission == MissionType::SOLVING){
            this->solving();
        }else if(this->current_mission == MissionType::LOADING){
            this->loading();
        }else if(this->current_mission == MissionType::BUILDTREE){
            this->build_tree();
        }else if(this->current_mission == MissionType::SAVING){
            this->saving();
        }else{
            throw runtime_error("unsupported mission type");
        }
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```