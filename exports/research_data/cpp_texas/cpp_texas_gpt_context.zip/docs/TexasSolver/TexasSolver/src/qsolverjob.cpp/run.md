`run`: The function of `run` is to execute a specific mission type based on the current_mission attribute of the QSolverJob object, handling solving, loading, building tree, and saving operations.

**Code Description**: 
The run method in the QSolverJob class serves as an entry point for executing various poker-related tasks. It takes into account the current_mission attribute to determine which operation to perform: solving, loading, building a game tree, or saving data. The method attempts to execute the corresponding function (solving, loading, build_tree, or saving) based on the mission type. If an unsupported mission type is encountered, it throws a runtime_error with an error message. In case of any errors during execution, it catches and logs the exception using qDebug().\\
## Code: 
```
void QSolverJob::run()
{
    //QDebugStream qout(qDebug().noquote(), this->textEdit);
    try{
        if(this->current_mission == MissionType::SOLVING){
            this->solving();
        }else if(this->current_mission == MissionType::LOADING){
            this->loading();
        }else if(this->current_mission == MissionType::BUILDTREE){
            this->build_tree();
        }else if(this->current_mission == MissionType::SAVING){
            this->saving();
        }else{
            throw runtime_error("unsupported mission type");
        }
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```