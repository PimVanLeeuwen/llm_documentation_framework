`getAmount`: The function of `getAmount` is to return the value of the `amount` attribute of the `GameActions` object.

**Code Description**: This method, `getAmount`, is a member of the `GameActions` class. When called, it returns the value stored in the `amount` attribute of the instance on which it is invoked. The return type of this method is `double`.\\
## Code: 
```
double GameActions::getAmount() {
    return this->amount;
}
```