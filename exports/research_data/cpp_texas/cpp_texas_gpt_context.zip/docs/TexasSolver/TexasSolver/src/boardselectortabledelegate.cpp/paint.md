`paint`: The function of `paint` is to render the visual representation of a cell in a table, including background color and formatted text, based on the data from the model.

**Parameters**:\
`QPainter *painter`: A pointer to the `QPainter` object used for drawing the cell.\
`const QStyleOptionViewItem &option`: A reference to the style options for the item, providing information such as the item's rectangle, state, and palette.\
`const QModelIndex &index`: A reference to the model index, indicating the cell's position in the table.

**Code Description**: The `paint` method starts by saving the current state of the `QPainter` object. It initializes the style options for the item using `initStyleOption`. It then defines a rectangle for the cell and fills it with a gray background. The method retrieves a float value from the model using `getBoardAt`, which represents some probability. It calculates the height for a yellow overlay based on this probability and fills the corresponding part of the cell with yellow. Finally, it creates a `QTextDocument` to render the cell's text as HTML, translates the painter to the cell's position, and draws the formatted text within the cell's rectangle. The painter's state is restored at the end.\\
## Code: 
```
void BoardSelectorTableDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const{

    painter->save();
    auto options = option;
    initStyleOption(&options, index);

    QRect rect(option.rect.left(), option.rect.top(),\
             option.rect.width(), option.rect.height());
    QBrush brush(Qt::gray);
    painter->fillRect(rect, brush);

    float board_float = this->boardSelectorTableModel->getBoardAt(index.row(),index.column());

    float fold_prob = 1 - board_float;
    int disable_height = (int)(fold_prob * option.rect.height());
    int remain_height = option.rect.height() - disable_height;

    rect = QRect(option.rect.left(), option.rect.top() + disable_height,\
     option.rect.width(), remain_height);
    brush = QBrush(Qt::yellow);
    painter->fillRect(rect, brush);

    QTextDocument doc;
    doc.setHtml(Card(options.text.toStdString()).toFormattedHtml());

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
    painter->restore();
}
```