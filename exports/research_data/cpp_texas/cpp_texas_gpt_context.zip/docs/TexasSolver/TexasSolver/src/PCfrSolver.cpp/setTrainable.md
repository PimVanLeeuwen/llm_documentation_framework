`setTrainable`: The function of `setTrainable` is to recursively set the training method for each node in the game tree starting from the given root node.

**Parameters**:\
`shared_ptr<GameTreeNode> root`: A shared pointer to the root node of the game tree from which the training method should be set.

**Code Description**: 
The `setTrainable` method configures the training method for nodes in a game tree based on the type of node and the specified trainer. It starts from the provided root node and processes each node recursively. 

1. If the node is of type `ACTION`, it casts the node to an `ActionNode` and determines the player associated with the node. Depending on the trainer type (`cfr_plus` or `discounted_cfr`), it either throws a runtime error (for `cfr_plus`) or calculates the number of trainable objects needed based on the gap between the current round and the root round (for `discounted_cfr`). It then sets the trainable objects for the action node and recursively processes its children.

2. If the node is of type `CHANCE`, it casts the node to a `ChanceNode`, retrieves its child node, and recursively processes the child.

3. If the node is of type `TERMINAL` or `SHOWDOWN`, the method does nothing as these nodes do not require training.

The method ensures that all relevant nodes in the game tree are configured with the appropriate training method based on the specified trainer.\\
## Code: 
```
void PCfrSolver::setTrainable(shared_ptr<GameTreeNode> root) {
    if(root->getType() == GameTreeNode::ACTION){
        shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(root);

        int player = action_node->getPlayer();

        if(this->trainer == "cfr_plus"){
            //vector<PrivateCards> player_privates = this->ranges[player];
            //action_node->setTrainable(make_shared<CfrPlusTrainable>(action_node,player_privates));
            throw runtime_error(tfm::format("trainer %s not supported",this->trainer));
        }else if(this->trainer == "discounted_cfr"){
            vector<PrivateCards>* player_privates = &this->ranges[player];
            //action_node->setTrainable(make_shared<DiscountedCfrTrainable>(action_node,player_privates));
            int num;
            GameTreeNode::GameRound gr = this->tree->getRoot()->getRound();
            int root_round = GameTreeNode::gameRound2int(gr);
            int current_round = GameTreeNode::gameRound2int(root->getRound());
            int gap = current_round - root_round;

            if(gap == 2) {
                num = this->deck.getCards().size() * this->deck.getCards().size() +
                          this->deck.getCards().size() + 1;
            }else if(gap == 1) {
                num = this->deck.getCards().size() + 1;
            }else if(gap == 0) {
                num =  1;
            }else{
                throw runtime_error("gap not understand");
            }
            action_node->setTrainable(vector<shared_ptr<Trainable>>(num),player_privates);
        }else{
            throw runtime_error(tfm::format("trainer %s not found",this->trainer));
        }

        vector<shared_ptr<GameTreeNode>> childrens =  action_node->getChildrens();
        for(shared_ptr<GameTreeNode> one_child:childrens) setTrainable(one_child);
    }else if(root->getType() == GameTreeNode::CHANCE) {
        shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(root);
        shared_ptr<GameTreeNode> children = chance_node->getChildren();
        setTrainable(children);
    }
    else if(root->getType() == GameTreeNode::TERMINAL){

    }else if(root->getType() == GameTreeNode::SHOWDOWN){

    }
}
```