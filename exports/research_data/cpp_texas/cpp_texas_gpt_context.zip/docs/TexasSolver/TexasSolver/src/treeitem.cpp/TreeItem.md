`TreeItem`: The function of `TreeItem` is to initialize a `TreeItem` object with a given game tree node and its parent item.
**Parameters**:\
`weak_ptr<GameTreeNode> data`: A weak pointer to a `GameTreeNode` object representing the data associated with this tree item. \
`TreeItem *parentItem`: A pointer to the parent `TreeItem` object in the tree structure.

**Code Description**: The constructor of the `TreeItem` class initializes the `TreeItem` object by setting its parent item and storing the provided game tree node data. The `m_parentItem` member is set to the provided `parentItem`, and the `m_treedata` member is set to the provided `data`. This setup allows the `TreeItem` to be part of a hierarchical tree structure representing the game state.\\
## Code: 
```
TreeItem::TreeItem(weak_ptr<GameTreeNode> data,TreeItem *parentItem) :
    m_parentItem(parentItem)
{
    this->m_treedata = data;
}
```