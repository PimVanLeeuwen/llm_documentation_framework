`getBoardAt`: The function of `getBoardAt` is to retrieve the value from a 2D grid at the specified row and column indices, `i` and `j`, while ensuring the indices are within valid bounds.

**Parameters**:\
`int i`: The row index to access in the 2D grid.\
`int j`: The column index to access in the 2D grid.

**Code Description**: The `getBoardAt` method first checks if the provided row index `i` is within the valid range (0 to the size of `ranklist` - 1). If `i` is out of bounds, it logs an error message and returns 0. Similarly, it checks if the column index `j` is within the valid range. If `j` is out of bounds, it logs an error message and returns 0. If both indices are valid, it returns the value at the specified position in the `grids_float` 2D array.\\
## Code: 
```
float BoardSelectorTableModel::getBoardAt(int i, int j){
    if(i < 0 || i >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::getBoardAt i not valid: " << i;
        return 0;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::getBoardAt j not valid: " << j;
        return 0;
    }
    else{
        return this->grids_float[i][j];
    }
}
```