`get_ij_text`: The function of `get_ij_text` is to generate a formatted string based on the ranks of two given indices, `i` and `j`, from the `ranklist`.

**Parameters**:\
`int i`: The row index. \
`int j`: The column index. \

**Code Description**: The method `get_ij_text` takes two integer parameters, `i` and `j`, representing row and column indices, respectively. It determines the larger and smaller values between `i` and `j` to fetch corresponding rank strings from the `ranklist`. It then concatenates these rank strings. If the row index is greater than the column index, it appends "o" to the result string. If the row index is less than the column index, it appends "s". If both indices are equal, it appends an empty string. The final formatted string is returned.\\
## Code: 
```
QString RangeSelectorTableModel::get_ij_text(int i,int j){
    int row = i;
    int col = j;
    int larger = row > col?row:col;
    int smaller = row > col?col:row;
    QString  retval = QString("%1%2%3")\
            .arg(QString(this->ranklist[smaller]))\
            .arg(QString(this->ranklist[larger]));
    if(row > col){
        retval = retval.arg("o");
    }else if(row < col){
        retval = retval.arg("s");
    }else{
        retval = retval.arg("");
    }
    return retval;
}
```