`columnCount`: The function of `columnCount` is to return the number of columns in the strategy table model.
**Parameters**:\
`const QModelIndex &parent`: This parameter is not used in the function but is typically provided to indicate the parent index in a model-view architecture.

**Code Description**: This method returns the number of columns in the strategy table model by accessing the `total_strategy` vector's size from the `tableStrategyModel` object. The `total_strategy` vector presumably holds the strategy data, and its size indicates the number of columns to be displayed in the view.\\
## Code: 
```
int RoughStrategyViewerModel::columnCount(const QModelIndex &parent) const
{
    return this->tableStrategyModel->total_strategy.size();
}
```