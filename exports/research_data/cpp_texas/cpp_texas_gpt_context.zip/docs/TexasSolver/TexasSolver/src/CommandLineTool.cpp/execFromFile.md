`execFromFile`: The function of `execFromFile` is to read commands from a specified input file and process each command line by line.

**Parameters**:\
`string input_file`: The path to the input file containing commands to be processed.

**Code Description**: The `execFromFile` method opens the specified input file using an `ifstream` object. It then reads the file line by line in a loop. For each line read, it calls the `processCommand` method to handle the command contained in that line. This method continues until all lines in the file have been processed.\\
## Code: 
```
void CommandLineTool::execFromFile(string input_file){
    std::ifstream infile(input_file);
    std::string input_line;
    while (std::getline(infile, input_line))
    {
        this->processCommand(input_line);
    }

}
```