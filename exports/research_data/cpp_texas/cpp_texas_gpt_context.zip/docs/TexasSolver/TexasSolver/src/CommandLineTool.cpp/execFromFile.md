`execFromFile`: The function of `execFromFile` is to execute a series of commands from a file.

**Parameters**: 
`string input_file`: This parameter specifies the path to the file containing the commands to be executed.

**Code Description**: 
The `execFromFile` method opens the specified file and reads it line by line. Each line is then processed using the `processCommand` method, which updates various settings of the solver based on the command type.\\
## Code: 
```
void CommandLineTool::execFromFile(string input_file){
    std::ifstream infile(input_file);
    std::string input_line;
    while (std::getline(infile, input_line))
    {
        this->processCommand(input_line);
    }

}
```