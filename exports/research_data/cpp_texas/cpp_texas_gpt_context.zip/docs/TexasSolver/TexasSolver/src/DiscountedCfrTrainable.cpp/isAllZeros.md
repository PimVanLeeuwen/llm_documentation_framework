`isAllZeros`: The function of `isAllZeros` is to check if all elements in the input array are zeros.

**Parameters**:\
`const vector<float>& input_array`: A constant reference to a vector of floats that needs to be checked for all zero values.

**Code Description**: The `isAllZeros` method iterates through each element in the `input_array`. If it encounters any element that is not zero, it immediately returns `false`. If all elements are zero, it returns `true` after completing the iteration. This method ensures efficient checking by stopping early if a non-zero element is found.\\
## Code: 
```
bool DiscountedCfrTrainable::isAllZeros(const vector<float>& input_array) {
    for(float i:input_array){
        if (i != 0)return false;
    }
    return true;
}
```