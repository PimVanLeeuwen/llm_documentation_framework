`paint`: The function of `paint` is to customize the painting of items in a table view based on the current mode of the `DetailWindowSetting`.

**Parameters**:\
`QPainter *painter`: A pointer to the `QPainter` object used for drawing the item.\
`const QStyleOptionViewItem &option`: A reference to the style options for the item, providing information such as the item's rectangle and state.\
`const QModelIndex &index`: A reference to the model index of the item being painted, providing information about its position in the model.

**Code Description**: The `paint` method begins by saving the current state of the `QPainter` object. It then defines a rectangle based on the item's dimensions and fills it with a gray or dark gray brush, depending on whether the item's row and column are the same. The method then checks the current mode of the `DetailWindowSetting` and calls the appropriate painting method (`paint_strategy`, `paint_range`, `paint_evs`) to customize the item's appearance based on the mode. Finally, the method restores the `QPainter` object's state.\\
## Code: 
```
void StrategyItemDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {

    painter->save();

    QRect rect(option.rect.left(), option.rect.top(),\
             option.rect.width(), option.rect.height());
    QBrush brush(Qt::gray);
    if(index.column() == index.row())brush = QBrush(Qt::darkGray);
    painter->fillRect(rect, brush);

    if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::STRATEGY){
        this->paint_strategy(painter,option,index);
    }
    else if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP ||
            this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_OOP ){
        this->paint_range(painter,option,index);
    }
    else if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::EV){
        this->paint_strategy(painter,option,index,true);
    }
    else if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::EV_ONLY){
        this->paint_evs(painter,option,index);
    }

    painter->restore();
}
```