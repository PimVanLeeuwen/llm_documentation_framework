`get_ev_grid`: The function of `get_ev_grid` is to calculate and return a vector of expected values (EVs) for a given strategy at the specified indices in the strategy table.

**Parameters**:\
`int i`: The row index in the strategy table. \
`int j`: The column index in the strategy table.

**Code Description**: This method first checks if the `treeItem` is `NULL` or if `current_evs` is empty, returning an empty vector if either condition is true. It then retrieves the number of strategies at the specified indices in the `ui_strategy_table`. The method locks the `treeItem` to get a shared pointer to the `GameTreeNode`. If the node type is `ACTION`, it casts the node to an `ActionNode` and retrieves the game actions. For each strategy at the specified indices, it retrieves the corresponding strategy and EV vectors. If the sizes of these vectors do not match, it returns an empty vector. It then calculates the EV for each strategy by multiplying the strategy values with the corresponding EV values and summing the results. These calculated EVs are added to the `ret_evs` vector, which is returned at the end. If the node type is not `ACTION`, it returns an empty vector.\\
## Code: 
```
const vector<float> TableStrategyModel::get_ev_grid(int i,int j)const{
    vector<float> ret_evs;
    if(this->treeItem == NULL || this->current_evs.empty())return ret_evs;

    int strategy_number = this->ui_strategy_table[i][j].size();

    shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();

    if(node->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);

        vector<GameActions>& gameActions = actionNode->getActions();

//        vector<float> strategies;

//        if(this->ui_strategy_table[i][j].size() > 0){
//            strategies = vector<float>(gameActions.size());
//            std::fill(strategies.begin(), strategies.end(), 0.);
//        }
        for(std::pair<int,int> index:this->ui_strategy_table[i][j]){
            int index1 = index.first;
            int index2 = index.second;
            const vector<float>& one_strategy = this->current_strategy[index1][index2];
            const vector<float>& one_ev = this->current_evs[index1][index2];
            if(one_ev.size() != one_strategy.size()) return vector<float>();

            if(gameActions.size() != one_strategy.size()){
                cout << "index: " << index1 << " " << index2 << endl;
                cout << "i,j: " << i << " " << j << endl;
                cout << "size not match between gameAction and stragegy: " << gameActions.size() << " " << one_strategy.size() << endl;
                throw runtime_error("size not match between gameAction and stragegy");
            }
            float one_ev_float = 0;
            for(std::size_t indi = 0;indi < one_strategy.size();indi ++){
                one_ev_float += one_strategy[indi] * one_ev[indi];
            }
            ret_evs.push_back(one_ev_float);
        }

        return ret_evs;
    }else{
        return ret_evs;
    }
}
```