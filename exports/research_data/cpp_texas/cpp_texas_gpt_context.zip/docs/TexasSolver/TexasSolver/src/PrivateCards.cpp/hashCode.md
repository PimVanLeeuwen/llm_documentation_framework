`hashCode`: The function of `hashCode` is to return the hash code of the `PrivateCards` object.

**Code Description**: This method, `hashCode`, is a member of the `PrivateCards` class. It returns the value of the `hash_code` attribute of the `PrivateCards` instance. This value is used to uniquely identify the object, typically for purposes such as storing the object in a hash-based collection.\\
## Code: 
```
int PrivateCards::hashCode() {
    return this->hash_code;
}
```