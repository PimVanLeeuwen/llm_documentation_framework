`DiscountedCfrTrainableSF`: The function of `DiscountedCfrTrainableSF` is to initialize an instance of the `DiscountedCfrTrainableSF` class, setting up the necessary data structures for training using Discounted Counterfactual Regret Minimization (CFR).

**Parameters**:\
`vector<PrivateCards> *privateCards`: A pointer to a vector containing `PrivateCards` objects, representing the private cards held by players. \
`ActionNode &actionNode`: A reference to an `ActionNode` object, representing the current node in the game tree where actions are being considered.

**Code Description**: This constructor initializes the `DiscountedCfrTrainableSF` object by setting the `action_node` member to the provided `actionNode` reference. It then assigns the `privateCards` pointer to the corresponding member variable. The constructor calculates the number of actions (`action_number`) from the size of the children of the `actionNode` and the number of private cards (`card_number`) from the size of the `privateCards` vector. It initializes three vectors: `evs`, `r_plus`, and `cum_r_plus`, each sized to the product of `action_number` and `card_number`, and fills them with initial values of `0.0`. These vectors are used to store expected values, positive regrets, and cumulative positive regrets, respectively, for the CFR algorithm.\\
## Code: 
```
DiscountedCfrTrainableSF::DiscountedCfrTrainableSF(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();
    this->evs = vector<EvsStorage>(this->action_number * this->card_number, (EvsStorage) 0.0);
    this->r_plus = vector<RplusStorage>(this->action_number * this->card_number, (RplusStorage) 0.0);
    this->cum_r_plus = vector<CumRplusStorage>(this->action_number * this->card_number, (CumRplusStorage) 0.0);
}
```