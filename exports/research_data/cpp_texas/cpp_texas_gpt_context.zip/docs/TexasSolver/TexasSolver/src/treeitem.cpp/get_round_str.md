`get_round_str`: The function of `get_round_str` is to return a string representation of a given game round in a poker game.

**Parameters**:\
`GameTreeNode::GameRound round`: An enumeration value representing the current round of the poker game. It can be one of the following: `FLOP`, `TURN`, or `RIVER`.

**Code Description**: This method takes a `GameTreeNode::GameRound` enumeration value as input and returns a corresponding string. If the input is `FLOP`, it returns the string "FLOP". If the input is `TURN`, it returns the string "TURN". If the input is `RIVER`, it returns the string "RIVER". If the input does not match any of these values, it throws a runtime error indicating that the round is not recognized. The method uses `QObject::tr` for translation, which allows the returned strings to be internationalized.\\
## Code: 
```
QString TreeItem::get_round_str(GameTreeNode::GameRound round) const{
    if(round == GameTreeNode::GameRound::FLOP){
        return QObject::tr("FLOP");
    }
    else if(round == GameTreeNode::GameRound::TURN){
        return QObject::tr("TURN");
    }
    else if(round == GameTreeNode::GameRound::RIVER){
        return QObject::tr("RIVER");
    }
    else throw runtime_error("round not recognized, must be in flop,turn,river");
}
```