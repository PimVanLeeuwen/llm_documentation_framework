`setActions`: The function of `setActions` is to set the `actions` member variable of the `ActionNode` class to the provided vector of `GameActions`.
**Parameters**:\
`const vector<GameActions> &actions`: A constant reference to a vector of `GameActions` objects that will be assigned to the `actions` member variable of the `ActionNode` class.

**Code Description**: This method assigns the provided vector of `GameActions` to the `actions` member variable of the `ActionNode` class. It takes a constant reference to a vector of `GameActions` as its parameter to avoid unnecessary copying and ensures that the `actions` member variable is updated with the new set of actions.\\
## Code: 
```
void ActionNode::setActions(const vector<GameActions> &actions) {
    ActionNode::actions = actions;
}
```