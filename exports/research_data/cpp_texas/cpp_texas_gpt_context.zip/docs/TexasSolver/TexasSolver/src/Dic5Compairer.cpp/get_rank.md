`get_rank`: The function of `get_rank` is to determine the rank of a poker hand given a private hand and a public board.

**Parameters**:\
`uint64_t private_hand`: A 64-bit integer representing the private hand of the player. Each bit corresponds to a specific card. \
`uint64_t public_board`: A 64-bit integer representing the public board cards. Each bit corresponds to a specific card.

**Code Description**: The `get_rank` method converts the 64-bit integer representations of the private hand and public board into vectors of card indices using the `Card::long2board` method. It then calls another `get_rank` method with these vectors to determine the rank of the combined hand. The rank is returned as an integer.\\
## Code: 
```
int Dic5Compairer::get_rank(uint64_t private_hand, uint64_t public_board) {
    return this->get_rank(Card::long2board(private_hand),Card::long2board(public_board));
}
```