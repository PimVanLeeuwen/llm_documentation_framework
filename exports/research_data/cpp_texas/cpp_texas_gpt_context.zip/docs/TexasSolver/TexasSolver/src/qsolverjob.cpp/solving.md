`solving`: The function of `solving` is to train a poker game solver using the provided inputs and algorithmic parameters.

**Code Description**: This code snippet appears to be part of a class called `QSolverJob`, which has a method called `solving`. The `solving` method checks if the current mode is either HOLDEM or SHORTDECK, and then calls the `train` method on either `ps_holdem` or `ps_shortdeck` (depending on the mode) to perform the actual training process. The `train` method initializes a PCfrSolver object with the given inputs and calls its own `train` method to perform the training process.\\
## Code: 
```
void QSolverJob::solving(){
    // TODO  为什么ui上多次求解会积累memory？哪里leak了？
    // TODO  为什么有时候会莫名闪退？
    qDebug().noquote() << tr("Start Solving..");//.toStdString() << std::endl;

    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }
    qDebug().noquote() << tr("Solving done.");//.toStdString() << std::endl;
}
```