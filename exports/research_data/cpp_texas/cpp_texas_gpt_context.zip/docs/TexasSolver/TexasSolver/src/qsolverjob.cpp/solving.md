`solving`: The function of `solving` is to initiate and manage the training process of a poker solver based on the specified game mode (either HOLDEM or SHORTDECK).

**Code Description**: 
The `solving` method begins by logging the start of the solving process. It then checks the game mode specified in the `mode` attribute. If the mode is `HOLDEM`, it calls the `train` method of the `ps_holdem` object with various parameters such as player ranges, board state, maximum iterations, print interval, algorithm type, accuracy, and threading options. If the mode is `SHORTDECK`, it similarly calls the `train` method of the `ps_shortdeck` object with the same set of parameters. After the training process is initiated, it logs the completion of the solving process. The method is designed to handle different poker game modes and configure the solver accordingly.\\
## Code: 
```
void QSolverJob::solving(){
    // TODO  为什么ui上多次求解会积累memory？哪里leak了？
    // TODO  为什么有时候会莫名闪退？
    qDebug().noquote() << tr("Start Solving..");//.toStdString() << std::endl;

    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }
    qDebug().noquote() << tr("Solving done.");//.toStdString() << std::endl;
}
```