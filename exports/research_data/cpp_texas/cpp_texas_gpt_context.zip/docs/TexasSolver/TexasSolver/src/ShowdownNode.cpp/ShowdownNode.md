`ShowdownNode`: The function of `ShowdownNode` is to initialize a node in the game tree representing a showdown in a poker game, where the final payoffs to players are determined.

**Parameters**:\
`vector<double> tie_payoffs`: A vector containing the payoffs for each player in the event of a tie. \
`vector<vector<double>> player_payoffs`: A 2D vector where each sub-vector contains the payoffs for a specific player based on different outcomes. \
`GameTreeNode::GameRound round`: An enumeration value representing the current round of the game. \
`double pot`: The total amount of money in the pot at the showdown. \
`shared_ptr<GameTreeNode>parent`: A shared pointer to the parent node in the game tree.

**Code Description**: The constructor `ShowdownNode` initializes a `ShowdownNode` object by setting the tie payoffs and player payoffs, and calling the base class `GameTreeNode` constructor with the current round, pot, and parent node. The `tie_payoffs` and `player_payoffs` vectors are moved into the class members to optimize performance by avoiding unnecessary copies.\\
## Code: 
```
ShowdownNode::ShowdownNode(vector<double> tie_payoffs, vector<vector<double>> player_payoffs,
                           GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode>parent):
                           GameTreeNode(round,pot,std::move(parent)) {
    this->tie_payoffs = std::move(tie_payoffs);
    this->player_payoffs = std::move(player_payoffs);
}
```