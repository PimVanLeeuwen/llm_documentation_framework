`getCards`: The function of `getCards` is to return a reference to the vector of `Card` objects stored in the `ChanceNode` instance.

**Code Description**: This method, `getCards`, is a member of the `ChanceNode` class. It returns a constant reference to the `cards` vector, which is a private member of the `ChanceNode` class. This allows users to access the `cards` without copying the vector, ensuring efficient access to the data.\\
## Code: 
```
const vector<Card>& ChanceNode::getCards() {
    return this->cards;
}
```