`toString`: The function of `toString` is to return a string representation of the two private cards in a specific order.

**Code Description**: The `toString` method in the `PrivateCards` class compares two card integers, `card1` and `card2`. It converts these integers to their string representations using the `Card::intCard2Str` method. If `card1` is greater than `card2`, it concatenates the string representation of `card1` followed by `card2`. Otherwise, it concatenates the string representation of `card2` followed by `card1`. This ensures that the cards are always represented in a consistent order.\\
## Code: 
```
string PrivateCards::toString() {
    if (card1 > card2) {
        return Card::intCard2Str(card1) + Card::intCard2Str(card2);
    }else{
        return Card::intCard2Str(card2) + Card::intCard2Str(card1);
    }
}
```