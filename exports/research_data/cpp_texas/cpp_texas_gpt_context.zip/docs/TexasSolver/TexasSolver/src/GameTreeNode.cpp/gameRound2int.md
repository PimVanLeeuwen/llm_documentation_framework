`gameRound2int`: The function of `gameRound2int` is to convert a `GameRound` enum value to its corresponding integer representation.

**Parameters**:\
`GameTreeNode::GameRound gameRound`: An enumeration value representing the current round of the game. The possible values are `PREFLOP`, `FLOP`, `TURN`, and `RIVER`.

**Code Description**: The `gameRound2int` method takes a `GameRound` enum value as input and returns an integer corresponding to the game round. Specifically, it returns `0` for `PREFLOP`, `1` for `FLOP`, `2` for `TURN`, and `3` for `RIVER`. If the input does not match any of these values, the method throws a runtime error indicating that the round was not found.\\
## Code: 
```
int GameTreeNode::gameRound2int(GameTreeNode::GameRound gameRound) {
    if(gameRound == GameRound::PREFLOP) {
        return 0;
    }else if(gameRound == GameRound::FLOP){
        return 1;
    } else if(gameRound == GameRound::TURN) {
        return 2;
    } else if(gameRound == GameRound::RIVER) {
        return 3;
    }
    throw runtime_error("round not found");
}
```