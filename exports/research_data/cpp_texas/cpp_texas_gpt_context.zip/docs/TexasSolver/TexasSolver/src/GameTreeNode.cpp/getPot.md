`getPot`: The function of `getPot` is to return the current value of the pot in the game.

**Code Description**: This method, `getPot`, is a member of the `GameTreeNode` class. It returns the value of the private member variable `pot`, which represents the current amount of money or chips in the pot for the game. The method does not take any parameters and simply returns the value stored in `this->pot`.\\
## Code: 
```
double GameTreeNode::getPot() {
    return this->pot;
}
```