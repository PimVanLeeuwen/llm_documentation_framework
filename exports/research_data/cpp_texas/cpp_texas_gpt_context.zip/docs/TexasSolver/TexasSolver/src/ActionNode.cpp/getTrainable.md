`getTrainable`: The function of `getTrainable` is to retrieve or create a `Trainable` object at a specified index within the `trainables` vector of the `ActionNode` object.

**Parameters**:\
`int i`: The index in the `trainables` vector from which to retrieve or create the `Trainable` object. \
`bool create_on_site`: A flag indicating whether to create a new `Trainable` object at the specified index if it does not already exist. \
`int use_halffloats`: An integer flag used to determine the type of `Trainable` object to create when the current game round is the river.

**Code Description**: The `getTrainable` method first checks if the provided index `i` is within the bounds of the `trainables` vector. If the index is out of bounds, it throws a runtime error. If the `trainables` vector at index `i` is `nullptr` and `create_on_site` is true, it creates a new `Trainable` object based on the current game round and the `use_halffloats` flag. If the game round is the river, it uses the `use_halffloats` flag to determine which specific `Trainable` subclass to instantiate (`DiscountedCfrTrainable`, `DiscountedCfrTrainableSF`, or `DiscountedCfrTrainableHF`). Finally, it returns the `Trainable` object at the specified index.\\
## Code: 
```
shared_ptr<Trainable> ActionNode::getTrainable(int i,bool create_on_site, int use_halffloats) {
    if(i > this->trainables.size()){
        throw runtime_error(tfm::format("size unacceptable %s > %s ",i,this->trainables.size()));
    }
    if(this->trainables[i] == nullptr && create_on_site){
        switch ((this->getRound() == GameTreeNode::RIVER) ? use_halffloats : 0 ){
        case 0:
            this->trainables[i] = make_shared<DiscountedCfrTrainable>(player_privates,*this);
            break;
        case 1:
            this->trainables[i] = make_shared<DiscountedCfrTrainableSF>(player_privates,*this);
            break;
        case 2:
            this->trainables[i] = make_shared<DiscountedCfrTrainableHF>(player_privates,*this);
            break;
        }
    }
    return this->trainables[i];
}
```