`set_niter`: The function of `set_niter` is to set the number of iterations for the progress bar.

**Parameters**:\
`int niter`: The number of iterations to be set for the progress bar. It must be a positive integer.

**Code Description**: The `set_niter` method in the `progressbar` class sets the total number of iterations (`n_cycles`) for the progress bar. If the provided `niter` value is less than or equal to zero, the method throws an `std::invalid_argument` exception with an appropriate error message. If the value is valid, it assigns `niter` to the `n_cycles` member variable.\\
## Code: 
```
void progressbar::set_niter(int niter) {
    if (niter <= 0) throw std::invalid_argument(
                "progressbar::set_niter: number of iterations null or negative");
    n_cycles = niter;
    return;
}
```