`PrivateCardsManager`: The function of `PrivateCardsManager` is to manage and initialize the private cards for a specified number of players, considering their interactions with the initial board state.

**Parameters**:
`vector<vector<PrivateCards>> private_cards`: A 2D vector containing the private cards for each player.
`int player_number`: The total number of players in the game.
`uint64_t initialboard`: The initial state of the board, represented as a 64-bit unsigned integer.

**Code Description**: 
The `PrivateCardsManager` constructor initializes the object's attributes and sets up the relative probabilities for private cards. It takes three parameters: `private_cards`, `player_number`, and `initialboard`. The code first assigns the input values to the corresponding instance variables. Then, it creates a 2D vector `card_player_index` with dimensions 52x52 (representing the possible card combinations) and initializes its elements with -1. This is followed by a loop that iterates through each player's private cards and updates the `card_player_index` accordingly. The `hashCode` method from the `PrivateCards` class is used to identify unique card combinations. Finally, the `setRelativeProbs` method is called to calculate and set the relative probabilities for the private cards.\\
## Code: 
```
PrivateCardsManager::PrivateCardsManager(vector<vector<PrivateCards>> private_cards, int player_number,
                                         uint64_t initialboard) {
    this->private_cards = private_cards;
    this->player_number = player_number;
    this->card_player_index = vector<vector<int>>(52 * 52);
    for(int i = 0;i < 52 * 52;i ++){
        this->card_player_index[i] = vector<int>(this->player_number,-1);
    }

    // 用一个二维数组记录每个Private Combo的对应index,方便从一方的手牌找对方的同名卡牌的index
    for(int player_id = 0;player_id < player_number;player_id ++){
        vector<PrivateCards> privateCombos = private_cards[player_id];
        for(std::size_t i = 0;i < privateCombos.size();i ++){
            PrivateCards one_private_combo = privateCombos[i];
            this->card_player_index[one_private_combo.hashCode()][player_id] = i;
        }
    }

    this->initialboard = initialboard;
    this->setRelativeProbs();
}
```