`PrivateCardsManager`: The function of `PrivateCardsManager` is to initialize and manage the private card combinations for each player in a Texas Hold'em game, setting up the necessary data structures for tracking and calculating probabilities.

**Parameters**:\
`vector<vector<PrivateCards>> private_cards`: A 2D vector where each element represents the private card combinations for a specific player. Each player's private card combinations are stored in a vector of `PrivateCards` objects.\
`int player_number`: The total number of players in the game.\
`uint64_t initialboard`: The initial state of the board, represented as a 64-bit unsigned integer.

**Code Description**: The `PrivateCardsManager` constructor initializes the private card combinations for each player and sets up the data structures needed to manage these combinations. It stores the private card combinations in the `private_cards` member variable and initializes the `card_player_index` 2D vector to track the index of each player's private card combination based on a hash code. The constructor iterates through each player's private card combinations, storing the index of each combination in the `card_player_index` vector using the hash code of the private cards. Finally, it sets the initial board state and calls the `setRelativeProbs` method to calculate and set the relative probabilities of the private card combinations for each player.\\
## Code: 
```
PrivateCardsManager::PrivateCardsManager(vector<vector<PrivateCards>> private_cards, int player_number,
                                         uint64_t initialboard) {
    this->private_cards = private_cards;
    this->player_number = player_number;
    this->card_player_index = vector<vector<int>>(52 * 52);
    for(int i = 0;i < 52 * 52;i ++){
        this->card_player_index[i] = vector<int>(this->player_number,-1);
    }

    // 用一个二维数组记录每个Private Combo的对应index,方便从一方的手牌找对方的同名卡牌的index
    for(int player_id = 0;player_id < player_number;player_id ++){
        vector<PrivateCards> privateCombos = private_cards[player_id];
        for(std::size_t i = 0;i < privateCombos.size();i ++){
            PrivateCards one_private_combo = privateCombos[i];
            this->card_player_index[one_private_combo.hashCode()][player_id] = i;
        }
    }

    this->initialboard = initialboard;
    this->setRelativeProbs();
}
```