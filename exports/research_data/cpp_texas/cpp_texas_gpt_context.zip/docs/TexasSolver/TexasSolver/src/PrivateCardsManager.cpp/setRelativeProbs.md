`setRelativeProbs`: The function of `setRelativeProbs` is to calculate and set the relative probabilities of each player's private cards based on the possible hands of their opponent.

**Code Description**: 
- The method `setRelativeProbs` iterates through each player and their private cards to compute the relative probabilities.
- It first determines the number of players from the size of the `private_cards` vector.
- For each player, it identifies the opponent and initializes a sum for the player's probabilities.
- It then iterates through each private card of the player, converting the card hands to a 64-bit integer representation using `Card::boardInts2long`.
- If the player's card intersects with the initial board, it skips further calculations for that card.
- For each opponent's card, it also converts the hands to a 64-bit integer and checks for intersections with the initial board and the player's card.
- If no intersections are found, it sums the weights of the opponent's cards.
- The player's card's relative probability is then calculated as the product of the opponent's probability sum and the player's card weight.
- After summing all relative probabilities for the player, it normalizes each card's relative probability by dividing it by the total sum of the player's relative probabilities.
- This process ensures that the relative probabilities of the private cards are adjusted based on the potential hands of the opponent, considering the initial board state.\\
## Code: 
```
void PrivateCardsManager::setRelativeProbs() {
    int players = this->private_cards.size();
    for(int player_id = 0; player_id < players;player_id ++){
        // TODO 这里只考虑了两个玩家的情况
        int oppo = 1 - player_id;
        float player_prob_sum = 0;

        for(std::size_t i = 0;i < this->private_cards[player_id].size();i ++) {
            float oppo_prob_sum = 0;
            PrivateCards* player_card = &this->private_cards[player_id][i];
            uint64_t player_long = Card::boardInts2long(player_card->get_hands());

            //
            if (Card::boardsHasIntercept(player_long,this->initialboard)){
                continue;
            }

            for (auto oppo_card : this->private_cards[oppo]) {
                uint64_t oppo_long = Card::boardInts2long(oppo_card.get_hands());
                if (Card::boardsHasIntercept(oppo_long,this->initialboard)
                    || Card::boardsHasIntercept(oppo_long,player_long)
                        ){
                    continue;
                }
                oppo_prob_sum += oppo_card.weight;

            }
            player_card->relative_prob = oppo_prob_sum * player_card->weight;
            player_prob_sum += player_card->relative_prob;
        }
        for(std::size_t i = 0;i < this->private_cards[player_id].size();i ++) {
            this->private_cards[player_id][i].relative_prob = this->private_cards[player_id][i].relative_prob / player_prob_sum;
            //player_card.relative_prob = player_card.relative_prob / player_prob_sum;
        }

    }
}
```