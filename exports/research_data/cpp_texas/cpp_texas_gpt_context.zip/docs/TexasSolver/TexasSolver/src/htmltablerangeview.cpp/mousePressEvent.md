`mousePressEvent`: The function of `mousePressEvent` is to handle mouse press events on the `HtmlTableRangeView` and emit a signal with the row and column of the clicked item.

**Parameters**:\
`QMouseEvent *event`: This parameter represents the mouse event that contains information about the position and state of the mouse when the press event occurred.

**Code Description**: This method first calls the base class `HtmlTableView`'s `mousePressEvent` method to ensure any default behavior is executed. It then determines the index of the item at the position where the mouse was clicked using the `indexAt` method. Finally, it emits a signal `view_item_pressed` with the row and column of the clicked item, allowing other parts of the application to respond to the mouse press event.\\
## Code: 
```
void HtmlTableRangeView::mousePressEvent(QMouseEvent *event) {
    HtmlTableView::mousePressEvent(event);
    QModelIndex index = indexAt(event->pos());
    emit view_item_pressed(index.row(),index.column());
}
```