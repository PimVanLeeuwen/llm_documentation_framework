`get_game_action_str`: The function of `get_game_action_str` is to convert a poker action and its associated amount into a human-readable string representation.

**Parameters**:\
`GameTreeNode::PokerActions action`: The poker action to be converted, which can be one of the following: CHECK, BET, RAISE, FOLD, or CALL. \
`float amount`: The amount associated with the BET or RAISE action. This parameter is ignored for other actions.

**Code Description**: The method `get_game_action_str` takes a poker action and an optional amount as input and returns a localized string that describes the action. It uses a series of conditional statements to check the type of action:
- If the action is `CHECK`, it returns the string "CHECK".
- If the action is `BET`, it returns the string "BET " followed by the amount.
- If the action is `RAISE`, it returns the string "RAISE " followed by the amount.
- If the action is `FOLD`, it returns the string "FOLD ".
- If the action is `CALL`, it returns the string "CALL".
- If the action does not match any of the known types, it throws a runtime error indicating an unknown action.\\
## Code: 
```
QString TreeItem::get_game_action_str(GameTreeNode::PokerActions action,float amount) const{
    if(action == GameTreeNode::PokerActions::CHECK){
        return QObject::tr("CHECK");
    }
    else if(action == GameTreeNode::PokerActions::BET){
        return QObject::tr("BET ") + QString::number(amount);
    }
    else if(action == GameTreeNode::PokerActions::RAISE){
        return QObject::tr("RAISE ") + QString::number(amount);
    }
    else if(action == GameTreeNode::PokerActions::FOLD){
        return QObject::tr("FOLD ");
    }
    else if(action == GameTreeNode::PokerActions::CALL){
        return QObject::tr("CALL");
    }else{
        throw runtime_error("unknown action when converting in get_game_action_str");
    }

}
```