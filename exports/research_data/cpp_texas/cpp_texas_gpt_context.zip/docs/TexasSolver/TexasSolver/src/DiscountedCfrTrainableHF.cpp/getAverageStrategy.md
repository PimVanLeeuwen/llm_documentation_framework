`getAverageStrategy`: The function of `getAverageStrategy` is to compute and return the average strategy for a given set of actions and private information cards.

**Code Description**: This method initializes a vector `average_strategy` with a size equal to the product of `action_number` and `card_number`. It iterates over each private information card and calculates the cumulative sum of positive regrets (`cum_r_plus`) for each action. If the cumulative sum is non-zero, it normalizes the strategy by dividing each action's cumulative regret by the total sum. If the cumulative sum is zero, it assigns an equal probability to each action. The resulting `average_strategy` vector is then returned.\\
## Code: 
```
const vector<float> DiscountedCfrTrainableHF::getAverageStrategy() {
    vector<float> average_strategy;
    average_strategy = vector<float>(this->action_number * this->card_number);
    for (int private_id = 0; private_id < this->card_number; private_id++) {
        float r_plus_sum = 0;
        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            average_strategy[index] = this->cum_r_plus[index];
            r_plus_sum += average_strategy[index];
        }

        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            if(r_plus_sum) {
                // we stored this->cum_r_plus[index] in average_strategy[index] above
                // this is to avoid converting from half float twice
                average_strategy[index] = average_strategy[index] / r_plus_sum;
            }else{
                average_strategy[index] = 1.0 / this->action_number;
            }
        }
    }
    return average_strategy;
}
```