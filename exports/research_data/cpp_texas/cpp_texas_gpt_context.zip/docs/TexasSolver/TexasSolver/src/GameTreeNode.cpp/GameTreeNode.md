`GameTreeNode`: The function of `GameTreeNode` is to initialize a new instance of the `GameTreeNode` class with the specified game round, pot value, and parent node.

**Parameters**:\
`GameTreeNode::GameRound round`: The current round of the game being represented by this node. \
`double pot`: The current amount of money in the pot for this game round. \
`shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node of this game tree node, representing the previous state in the game tree.

**Code Description**: This constructor initializes a `GameTreeNode` object by setting its `round` to the provided game round, its `pot` to the provided pot value, and its `parent` to the provided parent node. The `parent` pointer is moved to ensure efficient memory management and ownership transfer.\\
## Code: 
```
GameTreeNode::GameTreeNode(GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent) {
    this->round = round;
    this->pot = pot;
    this->parent = std::move(parent);
}
```