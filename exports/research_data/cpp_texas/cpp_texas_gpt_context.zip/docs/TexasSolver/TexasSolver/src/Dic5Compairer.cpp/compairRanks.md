`compairRanks`: The function of `compairRanks` is to compare two poker hand ranks and determine their relative order.

**Parameters**:\
`int rank_former`: The rank of the first poker hand to be compared. \
`int rank_latter`: The rank of the second poker hand to be compared.

**Code Description**: The `compairRanks` method compares two integer values representing poker hand ranks. If `rank_former` is less than `rank_latter`, it returns `CompairResult::LARGER`, indicating that the first hand is stronger. If `rank_former` is greater than `rank_latter`, it returns `CompairResult::SMALLER`, indicating that the second hand is stronger. If both ranks are equal, it returns `CompairResult::EQUAL`, indicating that both hands are of equal strength.\\
## Code: 
```
Compairer::CompairResult Dic5Compairer::compairRanks(int rank_former, int rank_latter) {
    if (rank_former < rank_latter) {
        // rank更小的牌更大，0是同花顺
        return CompairResult::LARGER;
    } else if (rank_former > rank_latter) {
        return CompairResult::SMALLER;
    } else {
        // rank_former == rank_latter
        return CompairResult::EQUAL;
    }
}
```