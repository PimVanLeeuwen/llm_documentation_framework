`getRangeAt`: The function of `getRangeAt` is to retrieve a floating-point value from a 2D grid at the specified row and column indices.

**Parameters**:\
`int i`: The row index in the 2D grid.\
`int j`: The column index in the 2D grid.

**Code Description**: The method `getRangeAt` first checks if the provided row index `i` is within the valid range of the `ranklist` size. If `i` is out of bounds, it logs an error message and returns 0. Similarly, it checks if the column index `j` is within the valid range of the `ranklist` size. If `j` is out of bounds, it logs an error message and returns 0. If both indices are valid, it returns the value at the specified position in the `grids_float` 2D array.\\
## Code: 
```
float RangeSelectorTableModel::getRangeAt(int i, int j){
    if(i < 0 || i >= this->ranklist.size()){
        qDebug().noquote() << "RangeSelectorTableModel::getRangeAt i not valid: " << i;
        return 0;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "RangeSelectorTableModel::getRangeAt j not valid: " << j;
        return 0;
    }
    else{
        return this->grids_float[i][j];
    }
}
```