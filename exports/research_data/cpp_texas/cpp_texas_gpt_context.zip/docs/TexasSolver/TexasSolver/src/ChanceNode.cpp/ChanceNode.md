`ChanceNode`: The function of `ChanceNode` is to initialize a new instance of the `ChanceNode` class, which represents a node in the game tree where chance events (like dealing cards) occur.

**Parameters**:\
`const shared_ptr<GameTreeNode> children`: A shared pointer to the child nodes of this `ChanceNode`.\
`GameTreeNode::GameRound round`: The current round of the game (e.g., pre-flop, flop, turn, river).\
`double pot`: The current size of the pot in the game.\
`shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node of this `ChanceNode`.\
`const vector<Card>& cards`: A vector of `Card` objects representing the cards involved in this chance event.\
`bool donk`: A boolean flag indicating whether a "donk" bet (a bet made by a player who was not the aggressor in the previous betting round) is involved.

**Code Description**: The `ChanceNode` constructor initializes a new `ChanceNode` object by setting its round, pot, and parent properties using the `GameTreeNode` constructor. It also initializes the `children` and `donk` properties with the provided arguments and assigns the `cards` vector to the `cards` member variable. This sets up the node to represent a point in the game where a chance event occurs, with references to its parent and children nodes, the current game state, and the cards involved.\\
## Code: 
```
ChanceNode::ChanceNode(const shared_ptr<GameTreeNode> children, GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent,
                       const vector<Card>& cards,bool donk): GameTreeNode(round,pot,std::move(parent)),cards(cards) {
    this->children = children;
    this->donk = donk;
}
```