`PCfrSolver`: The function of `PCfrSolver` is to initialize a PCFR solver object with the given parameters and set up its internal data structures.

**Parameters**:
- `shared_ptr<GameTree> tree`: A shared pointer to a GameTree object, which represents the game tree structure.
- `vector<PrivateCards> range1`: A vector of PrivateCards objects representing the first player's private card ranges.
- `vector<PrivateCards> range2`: A vector of PrivateCards objects representing the second player's private card ranges.
- `vector<int> initial_board`: A vector of integers representing the initial board state.
- `shared_ptr<Compairer> compairer`: A shared pointer to a Compairer object, which is used for comparing and evaluating hands.
- `Deck deck`: A Deck object representing the deck of cards.
- `int iteration_number`: The number of iterations for the PCFR solver.
- `bool debug`: A boolean flag indicating whether the solver should run in debug mode.
- `int print_interval`: The interval at which to print progress updates.
- `string logfile`: The path to a log file where the solver's output will be written.
- `string trainer`: The name of the trainer used for training the PCFR solver.
- `Solver::MonteCarolAlg monteCarolAlg`: An enumeration value representing the Monte Carlo algorithm to use.
- `int warmup`: The number of warm-up iterations for the PCFR solver.
- `float accuracy`: The desired accuracy level for the PCFR solver.
- `bool use_isomorphism`: A boolean flag indicating whether to use isomorphism in the PCFR solver.
- `int use_halffloats`: An integer value representing the use of half-floats in the PCFR solver.
- `int num_threads`: The number of threads to use for parallelizing the PCFR solver.

**Code Description**: This code initializes a PCFR solver object with the given parameters and sets up its internal data structures, including the game tree, private card ranges, initial board state, and other relevant information. It also sets up the solver's configuration options, such as the number of iterations, debug mode, print interval, log file path, trainer name, Monte Carlo algorithm, warm-up iterations, accuracy level, use of isomorphism, use of half-floats, and number of threads to use for parallelization.\\
## Code: 
```
PCfrSolver::PCfrSolver(shared_ptr<GameTree> tree, vector<PrivateCards> range1, vector<PrivateCards> range2,
                     vector<int> initial_board, shared_ptr<Compairer> compairer, Deck deck, int iteration_number, bool debug,
                     int print_interval, string logfile, string trainer, Solver::MonteCarolAlg monteCarolAlg,int warmup,float accuracy,bool use_isomorphism,int use_halffloats,int num_threads) :Solver(tree){
    this->initial_board = initial_board;
    this->initial_board_long = Card::boardInts2long(initial_board);
    this->logfile = logfile;
    this->trainer = trainer;
    this->warmup = warmup;

    range1 = this->noDuplicateRange(range1,initial_board_long);
    range2 = this->noDuplicateRange(range2,initial_board_long);

    this->range1 = range1;
    this->range2 = range2;
    this->player_number = 2;
    this->ranges = vector<vector<PrivateCards>>(this->player_number);
    this->ranges[0] = range1;
    this->ranges[1] = range2;

    this->compairer = compairer;

    this->deck = deck;
    this->use_isomorphism = use_isomorphism;
    this->use_halffloats = use_halffloats;

    this->rrm = RiverRangeManager(compairer);
    this->iteration_number = iteration_number;

    vector<vector<PrivateCards>> private_cards(this->player_number);
    private_cards[0] = range1;
    private_cards[1] = range2;
    pcm = PrivateCardsManager(private_cards,this->player_number,Card::boardInts2long(this->initial_board));
    this->debug = debug;
    this->print_interval = print_interval;
    this->monteCarolAlg = monteCarolAlg;
    this->accuracy = accuracy;
    if(num_threads == -1){
        num_threads = omp_get_num_procs();
    }
    qDebug().noquote() << QString::fromStdString(tfm::format(QObject::tr("Using %s threads").toStdString().c_str(),num_threads));
    this->num_threads = num_threads;
    this->distributing_task = false;
    omp_set_num_threads(this->num_threads);
    setTrainable(this->tree->getRoot());
    this->root_round = this->tree->getRoot()->getRound();
    if(this->root_round == GameTreeNode::GameRound::PREFLOP){
        this->split_round = GameTreeNode::GameRound::FLOP;
    }else if(this->root_round == GameTreeNode::GameRound::FLOP){
        this->split_round = GameTreeNode::GameRound::TURN;
    }else if(this->root_round == GameTreeNode::GameRound::TURN){
        this->split_round = GameTreeNode::GameRound::RIVER;
    }else{
        // do not use multithread in river, really not necessary
        this->split_round = GameTreeNode::GameRound::PREFLOP;
    }
}
```