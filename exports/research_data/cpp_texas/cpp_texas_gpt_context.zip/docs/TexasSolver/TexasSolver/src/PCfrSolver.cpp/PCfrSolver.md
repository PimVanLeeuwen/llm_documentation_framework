`PCfrSolver`: The function of `PCfrSolver` is to initialize and configure a solver for the game of Texas Hold'em poker using the Monte Carlo algorithm. It sets up the game tree, player ranges, board state, and other parameters necessary for running the solver.

**Parameters**:\
`shared_ptr<GameTree> tree`: A shared pointer to the game tree structure representing the possible states and actions in the game. \
`vector<PrivateCards> range1`: A vector of private card combinations for player 1. \
`vector<PrivateCards> range2`: A vector of private card combinations for player 2. \
`vector<int> initial_board`: A vector of integers representing the initial board cards. \
`shared_ptr<Compairer> compairer`: A shared pointer to a `Compairer` object used for comparing hands. \
`Deck deck`: The deck of cards used in the game. \
`int iteration_number`: The number of iterations the solver will run. \
`bool debug`: A flag indicating whether to run the solver in debug mode. \
`int print_interval`: The interval at which to print debug information. \
`string logfile`: The path to the logfile where output will be written. \
`string trainer`: The type of trainer to use for the solver. \
`Solver::MonteCarolAlg monteCarolAlg`: The Monte Carlo algorithm to use for the solver. \
`int warmup`: The number of warmup iterations before the main iterations. \
`float accuracy`: The desired accuracy for the solver's calculations. \
`bool use_isomorphism`: A flag indicating whether to use isomorphism to reduce the number of unique game states. \
`int use_halffloats`: A flag indicating whether to use half-precision floating-point numbers. \
`int num_threads`: The number of threads to use for parallel processing.

**Code Description**: The `PCfrSolver` constructor initializes the solver with the provided game tree, player ranges, initial board state, and other parameters. It filters out duplicate private card ranges, sets up the `RiverRangeManager` and `PrivateCardsManager`, and configures multi-threading based on the number of available processors. The constructor also determines the game round and sets the appropriate split round for multi-threading. Debug information is printed if enabled, and the solver is prepared for training based on the game tree's root node.\\
## Code: 
```
PCfrSolver::PCfrSolver(shared_ptr<GameTree> tree, vector<PrivateCards> range1, vector<PrivateCards> range2,
                     vector<int> initial_board, shared_ptr<Compairer> compairer, Deck deck, int iteration_number, bool debug,
                     int print_interval, string logfile, string trainer, Solver::MonteCarolAlg monteCarolAlg,int warmup,float accuracy,bool use_isomorphism,int use_halffloats,int num_threads) :Solver(tree){
    this->initial_board = initial_board;
    this->initial_board_long = Card::boardInts2long(initial_board);
    this->logfile = logfile;
    this->trainer = trainer;
    this->warmup = warmup;

    range1 = this->noDuplicateRange(range1,initial_board_long);
    range2 = this->noDuplicateRange(range2,initial_board_long);

    this->range1 = range1;
    this->range2 = range2;
    this->player_number = 2;
    this->ranges = vector<vector<PrivateCards>>(this->player_number);
    this->ranges[0] = range1;
    this->ranges[1] = range2;

    this->compairer = compairer;

    this->deck = deck;
    this->use_isomorphism = use_isomorphism;
    this->use_halffloats = use_halffloats;

    this->rrm = RiverRangeManager(compairer);
    this->iteration_number = iteration_number;

    vector<vector<PrivateCards>> private_cards(this->player_number);
    private_cards[0] = range1;
    private_cards[1] = range2;
    pcm = PrivateCardsManager(private_cards,this->player_number,Card::boardInts2long(this->initial_board));
    this->debug = debug;
    this->print_interval = print_interval;
    this->monteCarolAlg = monteCarolAlg;
    this->accuracy = accuracy;
    if(num_threads == -1){
        num_threads = omp_get_num_procs();
    }
    qDebug().noquote() << QString::fromStdString(tfm::format(QObject::tr("Using %s threads").toStdString().c_str(),num_threads));
    this->num_threads = num_threads;
    this->distributing_task = false;
    omp_set_num_threads(this->num_threads);
    setTrainable(this->tree->getRoot());
    this->root_round = this->tree->getRoot()->getRound();
    if(this->root_round == GameTreeNode::GameRound::PREFLOP){
        this->split_round = GameTreeNode::GameRound::FLOP;
    }else if(this->root_round == GameTreeNode::GameRound::FLOP){
        this->split_round = GameTreeNode::GameRound::TURN;
    }else if(this->root_round == GameTreeNode::GameRound::TURN){
        this->split_round = GameTreeNode::GameRound::RIVER;
    }else{
        // do not use multithread in river, really not necessary
        this->split_round = GameTreeNode::GameRound::PREFLOP;
    }
}
```