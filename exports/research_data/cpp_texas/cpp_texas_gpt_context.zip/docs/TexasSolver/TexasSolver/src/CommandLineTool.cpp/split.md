`split`: The function of `split` is to divide a string `s` into substrings based on a delimiter character `c` and store the resulting substrings in a vector `v`.

**Parameters**:\
`const string& s`: The input string to be split.\
`char c`: The delimiter character used to split the string.\
`vector<string>& v`: The vector where the resulting substrings will be stored.

**Code Description**: The function initializes two indices, `i` and `j`, to track the start and end positions of substrings within the input string `s`. It uses a loop to find each occurrence of the delimiter character `c` in the string. For each occurrence, it extracts the substring from the current start position `i` to the position `j` of the delimiter and adds it to the vector `v`. The start position `i` is then updated to the character following the delimiter. This process repeats until no more delimiters are found. If the loop ends and there are remaining characters in the string, the final substring is added to the vector.\\
## Code: 
```
void split(const string& s, char c,
           vector<string>& v) {
    string::size_type i = 0;
    string::size_type j = s.find(c);

    while (j != string::npos) {
        v.push_back(s.substr(i, j-i));
        i = ++j;
        j = s.find(c, j);

        if (j == string::npos)
            v.push_back(s.substr(i, s.length()));
    }
}
```