`PokerSolver`: The function of `PokerSolver` is to initialize a poker solver object with a deck of cards and a hand ranking comparer.

**Parameters**:\
`string ranks`: A comma-separated string representing the ranks of the cards (e.g., "2,3,4,5,6,7,8,9,T,J,Q,K,A").\
`string suits`: A comma-separated string representing the suits of the cards (e.g., "H,D,C,S" for hearts, diamonds, clubs, and spades).\
`string compairer_file`: The file path to a text file containing poker hand rankings.\
`int compairer_file_lines`: The number of lines in the `compairer_file`.\
`string compairer_file_bin`: The file path to a binary file containing poker hand rankings.

**Code Description**: The `PokerSolver` constructor initializes the poker solver by performing the following steps:
1. Splits the `ranks` string into a vector of individual rank strings using the `string_split` method.
2. Splits the `suits` string into a vector of individual suit strings using the `string_split` method.
3. Initializes a `Deck` object with the vectors of ranks and suits, generating all possible card combinations.
4. Initializes a `Dic5Compairer` object using the provided `compairer_file`, `compairer_file_lines`, and `compairer_file_bin` to load and verify poker hand rankings.\\
## Code: 
```
PokerSolver::PokerSolver(string ranks, string suits, string compairer_file,int compairer_file_lines, string compairer_file_bin) {
    vector<string> ranks_vector = string_split(ranks,',');
    vector<string> suits_vector = string_split(suits,',');
    this->deck = Deck(ranks_vector,suits_vector);
    this->compairer = make_shared<Dic5Compairer>(compairer_file,compairer_file_lines,compairer_file_bin);
}
```