`Rule`: The function of `Rule` is to initialize the game rules and settings for a Texas Hold'em poker game simulation.

**Parameters**:\
`Deck deck`: The deck of cards used in the game.\
`float oop_commit`: The amount of chips committed by the out-of-position player.\
`float ip_commit`: The amount of chips committed by the in-position player.\
`int current_round`: The current betting round in the game.\
`int raise_limit`: The maximum number of raises allowed in the current round.\
`float small_blind`: The amount of the small blind bet.\
`float big_blind`: The amount of the big blind bet.\
`float stack`: The total amount of chips each player starts with.\
`GameTreeBuildingSettings build_settings`: The settings used for building the game tree for decision making.\
`float allin_threshold`: The threshold at which a player is considered to be all-in.

**Code Description**: The `Rule` constructor initializes the game settings and parameters for a Texas Hold'em poker game. It assigns the provided values to the corresponding member variables. It also checks if the committed chips by the out-of-position player and the in-position player are equal, throwing a runtime error if they are not. Finally, it sets the initial effective stack to the provided stack value.\\
## Code: 
```
Rule::Rule(Deck deck, float oop_commit, float ip_commit, int current_round, int raise_limit, float small_blind,
           float big_blind, float stack, GameTreeBuildingSettings build_settings,float allin_threshold):
           deck(deck),oop_commit(oop_commit),ip_commit(ip_commit),current_round(current_round),raise_limit(raise_limit),
           small_blind(small_blind),big_blind(big_blind),stack(stack),build_settings(build_settings),allin_threshold(allin_threshold){
    if(oop_commit != ip_commit) throw runtime_error("ip commit should equal with oop commit");
    this->initial_effective_stack = stack;
}
```