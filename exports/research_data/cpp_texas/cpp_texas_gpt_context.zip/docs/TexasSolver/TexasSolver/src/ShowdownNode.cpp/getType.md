`getType`: The function of `getType` is to return the type of the game tree node.

**Code Description**: This method, `getType`, is a member of the `ShowdownNode` class. It returns a value of the enumeration type `GameTreeNode::GameTreeNodeType`, specifically the constant `SHOWDOWN`. This indicates that the node is of the type "showdown" within the game tree structure.\\
## Code: 
```
GameTreeNode::GameTreeNodeType ShowdownNode::getType() {
    return SHOWDOWN;
}
```