`getAverageStrategy`: The function of `getAverageStrategy` is to retrieve the average strategy for the CFR+ (Counterfactual Regret Minimization) algorithm.

**Code Description**: This method, `getAverageStrategy`, is designed to return the average strategy used in the CFR+ algorithm. The current implementation simply calls and returns the result of the `getcurrentStrategy` method. The commented-out code suggests an alternative approach where the average strategy is calculated based on cumulative positive regrets (`cum_r_plus`) and their sums (`cum_r_plus_sum`). If the cumulative regrets are all zeros, it defaults to a uniform strategy.\\
## Code: 
```
const vector<float> CfrPlusTrainable::getAverageStrategy() {
    /*
    vector<float> retval(this->action_number * this->card_number);
    if(this->cum_r_plus_sum.empty() || this->isAllZeros(this->cum_r_plus_sum)){
        fill(retval.begin(),retval.end(),1.0 / this->action_number);
    }else {
        for (int action_id = 0; action_id < action_number; action_id++) {
            for (int private_id = 0; private_id < this->card_number; private_id++) {
                int index = action_id * this->card_number + private_id;
                if(this->cum_r_plus_sum[private_id] != 0) {
                    retval[index] = this->cum_r_plus[index] / this->cum_r_plus_sum[private_id];
                }else{
                    retval[index] = 1.0 / this->action_number;
                }
            }
        }
    }
    */
    return this->getcurrentStrategy();
}
```