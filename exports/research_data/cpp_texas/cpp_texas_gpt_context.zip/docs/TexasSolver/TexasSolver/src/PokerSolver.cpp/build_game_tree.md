`build_game_tree`: The function of `build_game_tree` is to initialize and construct a game tree for a poker game using the provided parameters.

**Parameters**:\
`float oop_commit`: The amount of chips committed by the out-of-position player.\
`float ip_commit`: The amount of chips committed by the in-position player.\
`int current_round`: The current round of the poker game (e.g., pre-flop, flop, turn, river).\
`int raise_limit`: The maximum number of raises allowed in the current round.\
`float small_blind`: The value of the small blind in the game.\
`float big_blind`: The value of the big blind in the game.\
`float stack`: The total stack size for each player.\
`GameTreeBuildingSettings buildingSettings`: Configuration settings for building the game tree.\
`float allin_threshold`: The threshold at which a player is considered to be all-in.

**Code Description**: The `build_game_tree` method creates a new `GameTree` object using the provided parameters, which include player commitments, game settings, and blinds. It then assigns this newly created game tree to the `game_tree` member variable of the `PokerSolver` class. This method is essential for setting up the game tree structure that will be used for solving the poker game.\\
## Code: 
```
void PokerSolver::build_game_tree(
        float oop_commit,
        float ip_commit,
        int current_round,
        int raise_limit,
        float small_blind,
        float big_blind,
        float stack,
        GameTreeBuildingSettings buildingSettings,
        float allin_threshold
){
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(
            this->deck,
            oop_commit,
            ip_commit,
            current_round,
            raise_limit,
            small_blind,
            big_blind,
            stack,
            buildingSettings,
            allin_threshold
    );
    this->game_tree = game_tree;
}
```