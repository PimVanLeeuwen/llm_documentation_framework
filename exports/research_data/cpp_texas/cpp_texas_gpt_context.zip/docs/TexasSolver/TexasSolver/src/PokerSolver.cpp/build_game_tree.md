`build_game_tree`: The function of `build_game_tree` is to build a game tree for the Texas Hold'em poker game.

**Parameters**:
`float oop_commit`: The out-of-position commitment, representing the amount committed by an opponent.
`float ip_commit`: The in-position commitment, representing the amount committed by the player themselves.
`int current_round`: The current round number of the game.
`int raise_limit`: The maximum number of raises allowed in the game.
`float small_blind`: The size of the small blind bet.
`float big_blind`: The size of the big blind bet.
`float stack`: The total amount of chips available to each player.
`GameTreeBuildingSettings buildingSettings`: A set of settings for building the game tree, including parameters such as depth and breadth.
`float allin_threshold`: The threshold at which a player is considered "all-in" and cannot raise further.

**Code Description**: This function creates a new `GameTree` object using the provided parameters and assigns it to the `game_tree` member variable of the `PokerSolver` class. The `GameTree` constructor initializes its member variables from the input parameters and builds the game tree recursively, calling other methods as necessary to perform specific tasks such as building the game tree and initializing action nodes.\\
## Code: 
```
void PokerSolver::build_game_tree(
        float oop_commit,
        float ip_commit,
        int current_round,
        int raise_limit,
        float small_blind,
        float big_blind,
        float stack,
        GameTreeBuildingSettings buildingSettings,
        float allin_threshold
){
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(
            this->deck,
            oop_commit,
            ip_commit,
            current_round,
            raise_limit,
            small_blind,
            big_blind,
            stack,
            buildingSettings,
            allin_threshold
    );
    this->game_tree = game_tree;
}
```