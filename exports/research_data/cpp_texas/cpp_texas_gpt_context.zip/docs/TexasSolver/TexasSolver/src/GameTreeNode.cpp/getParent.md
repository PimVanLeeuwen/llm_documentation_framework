`getParent`: The function of `getParent` is to retrieve the parent node of the current `GameTreeNode` instance.

**Code Description**: This method returns a `shared_ptr` to the parent node of the current `GameTreeNode` instance by accessing the `parent` member variable, which is a `weak_ptr`. The `lock()` function is used to convert the `weak_ptr` to a `shared_ptr`, allowing access to the parent node if it still exists. If the parent node has been destroyed, the `lock()` function will return a `nullptr`.\\
## Code: 
```
shared_ptr<GameTreeNode>GameTreeNode::getParent() {
    return this->parent.lock();
}
```