`toString`: The function of `toString` is to convert the current game action and its associated amount (if any) into a string representation.

**Code Description**: The `toString` method in the `GameActions` class checks if the `amount` attribute is `-1`. If it is, the method returns the string representation of the `action` attribute by calling the `pokerActionToString` method. If the `amount` is not `-1`, it returns the string representation of the `action` followed by the `amount` value, separated by a space.\\
## Code: 
```
string GameActions::toString() {
    if(this->amount == -1) {
        return this->pokerActionToString(this->action);
    }else{
        return this->pokerActionToString(this->action) + " " + to_string(amount);
    }
}
```