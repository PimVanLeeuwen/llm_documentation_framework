`paint_evs`: The function of `paint_evs` is to render the expected values (EVs) for a specific cell in a strategy table, using color gradients to visually represent the normalized EVs.

**Parameters**:\
`QPainter *painter`: A pointer to the QPainter object used for drawing the cell content.\
`const QStyleOptionViewItem &option`: A reference to the style options for the item, which includes information such as the item's rectangle, state, and palette.\
`const QModelIndex &index`: A reference to the model index that identifies the cell in the strategy table.

**Code Description**: The `paint_evs` method customizes the painting of a cell in a strategy table by visualizing the expected values (EVs) with color gradients. It starts by initializing the style options for the cell and retrieving the EVs for the specified cell from the `TableStrategyModel`. The EVs are sorted, and each EV is normalized using the `normalization_tanh` function. The method then calculates the color for each EV based on its normalized value, creating a gradient from red to green. Each segment of the gradient is drawn as a filled rectangle within the cell. Finally, the method renders any additional text content using a `QTextDocument`.\\
## Code: 
```
void StrategyItemDelegate::paint_evs(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);
    const TableStrategyModel * tableStrategyModel = qobject_cast<const TableStrategyModel*>(index.model());
    vector<float> evs = tableStrategyModel->get_ev_grid(index.row(),index.column());
    sort(evs.begin(), evs.end());

    int last_left = 0;
    for(std::size_t i = 0;i < evs.size();i ++ ){
        float one_ev = evs[evs.size() - i - 1];
        float normalized_ev = normalization_tanh(this->qSolverJob->stack,one_ev);
        //options.text += QString("</br>%1").arg(QString::number(normalized_ev));

        int red = max((int)(255 - normalized_ev * 255),0);
        int green = min((int)(normalized_ev * 255),255);
        int blue = min(red, green);

        QBrush brush = QBrush(QColor(red,green,blue));

        int this_width = (int)((float(i + 1) / evs.size()) * options.rect.width()) - last_left;

        QRect rect(option.rect.left() + last_left, option.rect.top(),\
             this_width , (int) (options.rect.height()));
        painter->fillRect(rect, brush);
        last_left += this_width;
    }
    QTextDocument doc;
    doc.setHtml(options.text);
    options.text = "";
    //options.widget->style()->drawControl(QStyle::CE_ItemViewItem, &option, painter);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```