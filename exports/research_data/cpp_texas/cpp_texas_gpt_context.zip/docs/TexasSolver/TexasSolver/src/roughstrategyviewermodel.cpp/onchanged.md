`onchanged`: The function of `onchanged` is to notify the view that the header data has changed.

**Code Description**: The `onchanged` method in the `RoughStrategyViewerModel` class emits a signal `headerDataChanged` to inform any connected views that the horizontal header data has been updated. It specifies the range of columns affected by passing `0` as the starting column and the result of the `columnCount()` method as the ending column. This ensures that the view can refresh or update the display of the header accordingly.\\
## Code: 
```
void RoughStrategyViewerModel::onchanged(){
    emit headerDataChanged(Qt::Horizontal, 0 , columnCount());
}
```