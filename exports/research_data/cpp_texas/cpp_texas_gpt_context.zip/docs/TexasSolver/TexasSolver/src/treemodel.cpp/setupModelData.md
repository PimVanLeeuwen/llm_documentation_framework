`setupModelData`: The function of `setupModelData` is to initialize the tree model data structure based on the current poker game mode and regenerate the tree items accordingly.

**Code Description**: 
The `setupModelData` method initializes the tree model data structure for a poker solver application. It first determines the appropriate `PokerSolver` instance to use based on the current game mode (either HOLDEM or SHORTDECK). If the game mode is invalid, it throws a runtime error. The method then checks if the game tree and its root node are valid. If they are, it retrieves the game round from the root node and initializes the root item of the tree model with the root node of the game tree. It then creates a new `TreeItem` for the root node, inserts it as a child of the root item, and calls `reGenerateTreeItem` to recursively regenerate the tree structure starting from the given node based on the game round.\\
## Code: 
```
void TreeModel::setupModelData()
{
    PokerSolver * solver;
    if(this->qSolverJob->mode == QSolverJob::Mode::HOLDEM){
        solver = &(this->qSolverJob->ps_holdem);
    }else if(this->qSolverJob->mode == QSolverJob::Mode::SHORTDECK){
        solver = &(this->qSolverJob->ps_shortdeck);
    }else{
        throw runtime_error("holdem mode incorrect");
    }

    if(solver->get_game_tree() == nullptr || solver->get_game_tree()->getRoot() == nullptr){
        return;
    }

    GameTreeNode::GameRound round =	solver->get_game_tree()->getRoot()->getRound();

    this->rootItem = new TreeItem(solver->get_game_tree()->getRoot());
    TreeItem* ti = new TreeItem(solver->get_game_tree()->getRoot(),this->rootItem);
    rootItem->insertChild(ti);
    this->reGenerateTreeItem(round,ti);
}
```