`setupModelData`: The function of `setupModelData` is to set up the model data for a tree structure, specifically in the context of poker game trees.

**Code Description**: This function appears to be part of a larger system that generates and displays a visual representation of a poker game tree. It takes into account the current mode (Hold'em or ShortDeck) and retrieves the corresponding solver object. If the game tree is valid (i.e., it has a root node), it creates a new TreeItem for the root node and recursively regenerates the tree structure by calling `reGenerateTreeItem`. The function also inserts child items into the tree as necessary, using the `insertChild` method of the TreeItem class.\\
## Code: 
```
void TreeModel::setupModelData()
{
    PokerSolver * solver;
    if(this->qSolverJob->mode == QSolverJob::Mode::HOLDEM){
        solver = &(this->qSolverJob->ps_holdem);
    }else if(this->qSolverJob->mode == QSolverJob::Mode::SHORTDECK){
        solver = &(this->qSolverJob->ps_shortdeck);
    }else{
        throw runtime_error("holdem mode incorrect");
    }

    if(solver->get_game_tree() == nullptr || solver->get_game_tree()->getRoot() == nullptr){
        return;
    }

    GameTreeNode::GameRound round =	solver->get_game_tree()->getRoot()->getRound();

    this->rootItem = new TreeItem(solver->get_game_tree()->getRoot());
    TreeItem* ti = new TreeItem(solver->get_game_tree()->getRoot(),this->rootItem);
    rootItem->insertChild(ti);
    this->reGenerateTreeItem(round,ti);
}
```