`copyStrategy`: The function of `copyStrategy` is to copy the strategy-related data from another `DiscountedCfrTrainable` object to the current object.
**Parameters**:\
`shared_ptr<Trainable> other_trainable`: A shared pointer to another `Trainable` object from which the strategy data will be copied.

**Code Description**: The `copyStrategy` method first attempts to cast the provided `other_trainable` object to a `shared_ptr<DiscountedCfrTrainable>`. If the cast is successful, it copies the `r_plus` and `cum_r_plus` vectors from the `other_trainable` object to the current object, ensuring that the current object has the same strategy data as the `other_trainable` object.\\
## Code: 
```
void DiscountedCfrTrainable::copyStrategy(shared_ptr<Trainable> other_trainable){
    shared_ptr<DiscountedCfrTrainable> trainable = dynamic_pointer_cast<DiscountedCfrTrainable>(other_trainable);
    this->r_plus.assign(trainable->r_plus.begin(),trainable->r_plus.end());
    this->cum_r_plus.assign(trainable->cum_r_plus.begin(),trainable->cum_r_plus.end());
}
```