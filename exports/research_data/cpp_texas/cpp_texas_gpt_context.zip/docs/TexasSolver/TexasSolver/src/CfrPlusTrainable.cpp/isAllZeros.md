`isAllZeros`: The function of `isAllZeros` is to check if all elements in the input array are zeros.

**Parameters**:\
`vector<float> input_array`: A vector of floating-point numbers to be checked.

**Code Description**: This method iterates through each element in the `input_array`. If it finds any element that is not zero, it immediately returns `false`. If all elements are zero, it returns `true`.\\
## Code: 
```
bool CfrPlusTrainable::isAllZeros(vector<float> input_array) {
    for(float i:input_array){
        if (i != 0)return false;
    }
    return true;
}
```