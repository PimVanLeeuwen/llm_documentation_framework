`getBoardText`: The function of `getBoardText` is to generate a comma-separated string representation of the board based on the non-zero values in the `grids_float` matrix.

**Code Description**: The `getBoardText` method iterates through the `suitlist` and `ranklist` to check each element in the `grids_float` matrix. If an element is non-zero, it retrieves the corresponding string from the `grids_string` matrix and appends it to the result string `retval`. The strings are concatenated with commas. The method returns the final comma-separated string of board elements.\\
## Code: 
```
QString BoardSelectorTableModel::getBoardText(){
    QString retval = "";
    for(int i = 0;i < this->suitlist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            if(this->grids_float[i][j] == 0)continue;
            QString one_board_str = QString("%1").arg(this->grids_string[i][j]);
            if(retval == ""){
                retval = one_board_str;
            }else{
                retval = retval + "," + one_board_str;
            }
        }
    }
    return retval;
}
```