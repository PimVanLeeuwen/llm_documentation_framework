`setRiverCard`: The function of `setRiverCard` is to set the river card in the `TableStrategyModel` object.

**Parameters**:\
`Card river_card`: The card to be set as the river card.

**Code Description**: This method assigns the provided `river_card` to the `river_card` member variable of the `TableStrategyModel` class. This allows the model to update its state with the new river card.\\
## Code: 
```
void TableStrategyModel::setRiverCard(Card river_card){
    this->river_card = river_card;
}
```