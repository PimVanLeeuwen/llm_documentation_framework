`intToGameRound`: The function of `intToGameRound` is to convert an integer representing a round of a poker game into its corresponding `GameRound` enumeration value.

**Parameters**:\
`int round`: An integer representing the round of the poker game. The valid values are 0 for PREFLOP, 1 for FLOP, 2 for TURN, and 3 for RIVER.

**Code Description**: The method `intToGameRound` takes an integer input `round` and uses a switch statement to map this integer to the corresponding `GameRound` enumeration value. If the input integer is 0, it returns `GameRound::PREFLOP`; if 1, it returns `GameRound::FLOP`; if 2, it returns `GameRound::TURN`; and if 3, it returns `GameRound::RIVER`. If the input integer does not match any of these cases, the method throws a runtime error indicating that the round is not found.\\
## Code: 
```
GameTreeNode::GameRound GameTreeNode::intToGameRound(int round){
    GameTreeNode::GameRound game_round;
    switch(round){
        case 0:{
            game_round = GameTreeNode::GameRound::PREFLOP;
            break;
        }
        case 1:{
            game_round = GameTreeNode::GameRound::FLOP;
            break;
        }
        case 2:{
            game_round = GameTreeNode::GameRound::TURN;
            break;
        }
        case 3:{
            game_round = GameTreeNode::GameRound::RIVER;
            break;
        }
        default:{
            throw runtime_error(tfm::format("round %s not found",round));
        }
    }
    return game_round;
}
```