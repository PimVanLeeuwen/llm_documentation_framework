`updateRegrets`: The function of `updateRegrets` is to update the regret values and cumulative regret values for each action and private card combination based on the current iteration number.

**Parameters**:\
`const vector<float>& regrets`: A vector containing the regret values for each action and private card combination. \
`int iteration_number`: The current iteration number of the training process. \
`const vector<float>& reach_probs`: A vector containing the reach probabilities for each private card.

**Code Description**: The method first assigns the input `regrets` vector to the class member `regrets`. It then checks if the size of the `regrets` vector matches the expected size, which is the product of the number of actions and the number of private cards. If the sizes do not match, it throws a runtime error.

Next, the method initializes the `r_plus_sum` and `cum_r_plus_sum` vectors to zero. It then iterates over each action and private card combination, updating the `r_plus` values by adding the current regret value to the existing `r_plus` value, ensuring that the result is non-negative. The `r_plus_sum` for each private card is updated accordingly.

Finally, the method updates the cumulative regret values (`cum_r_plus`) by adding the product of the `r_plus` value and the iteration number. The `cum_r_plus_sum` for each private card is also updated accordingly.\\
## Code: 
```
void CfrPlusTrainable::updateRegrets(const vector<float>& regrets, int iteration_number, const vector<float>& reach_probs) {
    this->regrets = regrets;
    if(regrets.size() != this->action_number * this->card_number) throw runtime_error("length not match");

    //Arrays.fill(this.r_plus_sum,0);
    fill(r_plus_sum.begin(),r_plus_sum.end(),0);
    fill(cum_r_plus_sum.begin(),cum_r_plus_sum.end(),0);
    for (int action_id = 0;action_id < action_number;action_id ++) {
        for(int private_id = 0;private_id < this->card_number;private_id ++){
            int index = action_id * this->card_number + private_id;
            float one_reg = regrets[index];

            // 更新 R+
            this->r_plus[index] = max((float)0.0,one_reg + this->r_plus[index]);
            this->r_plus_sum[private_id] += this->r_plus[index];

            // 更新累计策略
            this->cum_r_plus[index] += this->r_plus[index] * iteration_number;
            this->cum_r_plus_sum[private_id] += this->cum_r_plus[index];
        }
    }
}
```