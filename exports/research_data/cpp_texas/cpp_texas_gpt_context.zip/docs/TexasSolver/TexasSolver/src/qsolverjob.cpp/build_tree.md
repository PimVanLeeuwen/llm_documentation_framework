`build_tree`: The function of `build_tree` is to construct a game tree for a poker game based on the current mode (HOLDEM or SHORTDECK) and various game parameters.

**Code Description**: 
- The method starts by logging a message indicating the beginning of the tree-building process.
- It checks the current mode of the game (`HOLDEM` or `SHORTDECK`).
- Depending on the mode, it calls the appropriate `build_game_tree` method from either `ps_holdem` or `ps_shortdeck`.
- The `build_game_tree` method is provided with several parameters including player commitments (`oop_commit`, `ip_commit`), the current round, raise limits, blinds (`small_blind`, `big_blind`), stack size, a game tree builder object (`gtbs`), and an all-in threshold.
- After constructing the game tree, it logs a message indicating the completion of the tree-building process.\\
## Code: 
```
void QSolverJob::build_tree(){
    qDebug().noquote() << tr("building tree..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        ps_holdem.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }else if(this->mode == Mode::SHORTDECK){
        ps_shortdeck.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }
    qDebug().noquote() << tr("build tree finished");//.toStdString() << endl;
}
```