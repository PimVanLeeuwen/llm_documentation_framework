`build_tree`: The function of `build_tree` is to build a game tree for the poker game based on the specified mode and parameters.

**Code Description**: This code snippet defines a method called `build_tree` within the `QSolverJob` class. It takes no arguments and performs two different operations depending on the value of the `mode` member variable. If the mode is HOLDEM, it calls the `build_game_tree` method on an instance of `PokerSolver` (specifically, `ps_holdem`). Similarly, if the mode is SHORTDECK, it calls the same method on another instance of `PokerSolver` (specifically, `ps_shortdeck`). The `build_game_tree` method initializes a new GameTree object with given parameters such as deck, commitments, round, raise limit, blinds, stack, building settings, and all-in threshold.\\
## Code: 
```
void QSolverJob::build_tree(){
    qDebug().noquote() << tr("building tree..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        ps_holdem.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }else if(this->mode == Mode::SHORTDECK){
        ps_shortdeck.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }
    qDebug().noquote() << tr("build tree finished");//.toStdString() << endl;
}
```