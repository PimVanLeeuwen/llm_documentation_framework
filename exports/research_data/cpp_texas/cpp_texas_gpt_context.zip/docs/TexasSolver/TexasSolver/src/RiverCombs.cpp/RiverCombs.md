`RiverCombs`: The function of `RiverCombs` is to initialize an instance of the `RiverCombs` class with the given parameters.

**Parameters**:\
`vector<int> board`: A vector of integers representing the community cards on the board. \
`PrivateCards private_cards`: An object representing the private cards held by a player. \
`int rank`: An integer representing the rank of the hand. \
`int reach_prob_index`: An integer representing the index for reach probability.

**Code Description**: This constructor method initializes the `RiverCombs` object by setting its `board`, `rank`, `private_cards`, and `reach_prob_index` attributes to the values provided as arguments.\\
## Code: 
```
RiverCombs::RiverCombs(vector<int> board, PrivateCards private_cards, int rank, int reach_prob_index) {
    this->board = board;
    this->rank = rank;
    this->private_cards = private_cards;
    this->reach_prob_index = reach_prob_index;
}
```