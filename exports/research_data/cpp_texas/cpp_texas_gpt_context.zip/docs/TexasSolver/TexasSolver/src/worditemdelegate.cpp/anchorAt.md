`anchorAt`: The function of `anchorAt` is to find and return the anchor (hyperlink) at a specific point within an HTML document.

**Parameters**:\
`QString html`: The HTML content in which to search for the anchor.\
`const QPoint &point`: The point within the document where the anchor is to be searched for.

**Code Description**: This method takes an HTML string and a point as input. It creates a `QTextDocument` object and sets its HTML content to the provided string. It then retrieves the document's layout and asserts that the layout is not null. Finally, it returns the anchor (if any) located at the specified point within the document.\\
## Code: 
```
QString WordItemDelegate::anchorAt(QString html, const QPoint &point) const {
    QTextDocument doc;
    doc.setHtml(html);

    auto textLayout = doc.documentLayout();
    Q_ASSERT(textLayout != 0);
    return textLayout->anchorAt(point);
}
```