`TerminalNode`: The function of `TerminalNode` is to initialize a terminal node in a game tree with specific payoffs, winner information, game round, pot value, and a parent node.

**Parameters**:\
`vector<double> payoffs`: A vector containing the payoff amounts for each player at the terminal node. \
`int winner`: An integer representing the index or identifier of the winning player. \
`GameTreeNode::GameRound round`: An enumeration value representing the current round of the game. \
`double pot`: The total amount of money or chips in the pot at the terminal node. \
`shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node in the game tree.

**Code Description**: The `TerminalNode` constructor initializes a terminal node by setting the payoffs for each player, identifying the winner, and storing the current game round and pot value. It also establishes a link to the parent node in the game tree by calling the constructor of the base class `GameTreeNode` with the round, pot, and parent parameters. The `payoffs` and `winner` are then assigned to the corresponding member variables of the `TerminalNode` class.\\
## Code: 
```
TerminalNode::TerminalNode(vector<double> payoffs, int winner, GameTreeNode::GameRound round, double pot,
                           shared_ptr<GameTreeNode> parent):GameTreeNode(round,pot,parent){
    this->payoffs = payoffs;
    this->winner = winner;
}
```