`setBoardAt`: The function of `setBoardAt` is to set a specific value in a 2D grid at the given row and column indices, provided the indices are within valid bounds.

**Parameters**:\
`int i`: The row index in the 2D grid. \
`int j`: The column index in the 2D grid. \
`float value`: The value to be set at the specified position in the grid.

**Code Description**: The `setBoardAt` method first checks if the provided row index `i` is within the valid range of the `suitlist` size. If `i` is out of bounds, it logs an error message indicating that `i` is not valid. Next, it checks if the provided column index `j` is within the valid range of the `ranklist` size. If `j` is out of bounds, it logs an error message indicating that `j` is not valid. If both indices are valid, it sets the value at the specified position `[i][j]` in the `grids_float` 2D array to the provided `value`.\\
## Code: 
```
void BoardSelectorTableModel::setBoardAt(int i, int j,float value){
    if(i < 0 || i >= this->suitlist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::setBoardAt i not valid: " << i;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::setBoardAt j not valid: " << j;
    }
    else{
        this->grids_float[i][j] = value;
    }
}
```