`is_flush`: The function of `is_flush` is to determine if a given hand of cards (represented by a hash value) is a flush (all cards of the same suit).

**Parameters**:\
`uint64_t hash`: A 64-bit integer representing the hash value of a hand of cards, where specific bits are used to indicate the presence of cards of different suits.

**Code Description**: The function `is_flush` checks if all cards in the given hand belong to the same suit. It does this by using bitwise operations to count the number of different suits present in the hand. The function uses predefined masks (`SUIT_0_MASK`, `SUIT_1_MASK`, `SUIT_2_MASK`, `SUIT_3_MASK`) to isolate the bits corresponding to each suit. If more than one suit is present, the function returns `false`; otherwise, it returns `true`.\\
## Code: 
```
bool is_flush(uint64_t hash) {
    int cnt = (hash & SUIT_0_MASK) != 0;
    cnt += (hash & SUIT_1_MASK) != 0;
    if (cnt > 1) return false;
    cnt += (hash & SUIT_2_MASK) != 0;
    if (cnt > 1) return false;
    cnt += (hash & SUIT_3_MASK) != 0;
    return cnt > 1 ? false : true;
}
```