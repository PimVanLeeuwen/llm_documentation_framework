`index`: The function of `index` is to return a QModelIndex corresponding to the given row and column under the specified parent index in a tree structure.

**Parameters**:\
`int row`: The row number of the child item within the parent item. \
`int column`: The column number of the child item within the parent item. \
`const QModelIndex &parent`: The parent index under which to look for the child item.

**Code Description**: This method first checks if the specified row and column are valid indices under the given parent. If not, it returns an invalid QModelIndex. If the parent index is invalid, it uses the root item as the parent. Otherwise, it retrieves the parent item using the internal pointer of the parent index. It then attempts to retrieve the child item at the specified row from the parent item. If the child item exists, it creates and returns a QModelIndex for the child item. If the child item does not exist, it returns an invalid QModelIndex.\\
## Code: 
```
QModelIndex TreeModel::index(int row, int column, const QModelIndex &parent) const
{
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    TreeItem *parentItem;

    if (!parent.isValid())
        parentItem = rootItem;
    else
        parentItem = static_cast<TreeItem*>(parent.internalPointer());

    TreeItem *childItem = parentItem->child(row);
    if (childItem)
        return createIndex(row, column, childItem);
    return QModelIndex();
}
```