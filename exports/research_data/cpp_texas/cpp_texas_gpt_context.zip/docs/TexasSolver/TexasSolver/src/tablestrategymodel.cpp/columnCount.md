`columnCount`: The function of `columnCount` is to return the number of columns in the table model, which corresponds to the number of ranks in the deck used by the solver.

**Parameters**:\
`const QModelIndex &parent`: This parameter is a reference to a QModelIndex object, which represents the parent index in the model. It is not used in this method.

**Code Description**: This method retrieves the number of ranks in the deck from the solver associated with the `qSolverJob` object and returns this value as the number of columns in the table model. It does this by calling `get_solver()` on the `qSolverJob` object to get the solver instance, then calling `get_deck()` on the solver to get the deck, and finally calling `getRanks().size()` on the deck to get the number of ranks.\\
## Code: 
```
int TableStrategyModel::columnCount(const QModelIndex &parent) const
{
    return this->qSolverJob->get_solver()->get_deck()->getRanks().size();
}
```