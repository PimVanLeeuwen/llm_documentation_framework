`setGameTreeNode`: The function of `setGameTreeNode` is to set the `treeItem` member variable of the `TableStrategyModel` class to the provided `treeNode` parameter.\
**Parameters**:\
`TreeItem* treeNode`: A pointer to a `TreeItem` object that represents a node in the game tree. This parameter is used to update the `treeItem` member variable of the `TableStrategyModel` class.

**Code Description**: This method assigns the provided `treeNode` parameter to the `treeItem` member variable of the `TableStrategyModel` class. This effectively updates the internal state of the `TableStrategyModel` instance to reference the new game tree node.\\
## Code: 
```
void TableStrategyModel::setGameTreeNode(TreeItem* treeNode){
    this->treeItem = treeNode;
}
```