`get_total_strategy`: The function of `get_total_strategy` is to compute and return the total strategy for the current game state, including the combination probabilities and average strategy for each game action.

**Code Description**: 
- The method `get_total_strategy` returns a vector of pairs, where each pair consists of a `GameActions` object and another pair containing two floats (combos and average strategy).
- It first checks if `treeItem` is `NULL`. If it is, it returns an empty vector.
- It locks the weak pointer `m_treedata` of `treeItem` to get a shared pointer to a `GameTreeNode`.
- If the node type is `ACTION`, it casts the node to an `ActionNode` and retrieves the game actions and the current player.
- It initializes vectors for storing combination probabilities (`combos`) and average strategy (`avg_strategy`), and a float for the sum of strategies (`sum_strategy`).
- It iterates over the `current_strategy` matrix, and for each strategy, it calculates the combination probabilities and average strategy based on the player's range.
- It checks for size mismatches between game actions and strategies, throwing a runtime error if they do not match.
- Finally, it normalizes the average strategy and constructs the return vector with the calculated values for each game action.
- If the node type is not `ACTION`, it returns an empty vector.\\
## Code: 
```
const vector<pair<GameActions,pair<float,float>>> TableStrategyModel::get_total_strategy() const{
    vector<pair<GameActions,pair<float,float>>> ret_strategy;
    if(this->treeItem == NULL)return ret_strategy;


    shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();

    if(node->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);
        vector<GameActions>& gameActions = actionNode->getActions();
        int current_player = actionNode->getPlayer();

        vector<float> combos(gameActions.size(),0.0);
        vector<float> avg_strategy(gameActions.size(),0.0);
        float sum_strategy = 0;

        for(std::size_t index1 = 0;index1 < this->current_strategy.size() ;index1 ++){
            for(std::size_t index2 = 0;index2 < this->current_strategy.size() ;index2 ++){
                const vector<float>& one_strategy = this->current_strategy[index1][index2];
                if(one_strategy.empty())continue;

                const vector<vector<float>>& range = current_player == 0? this->p1_range:this->p2_range;
                if(range.size() <= index1 || range[index1].size() < index2) throw runtime_error(" index error when get range in tablestrategymodel");
                const float one_range = range[index1][index2];

                for(std::size_t i = 0;i < one_strategy.size(); i ++ ){
                    float one_prob = one_strategy[i];
                    combos[i] += one_prob * one_range;
                    avg_strategy[i] += one_prob * one_range;
                    sum_strategy += one_prob * one_range;
                }

                if(gameActions.size() != one_strategy.size()){
                    cout << "index: " << index1 << " " << index2 << endl;
                    cout << "size not match between gameAction and stragegy: " << gameActions.size() << " " << one_strategy.size() << endl;
                    throw runtime_error("size not match between gameAction and stragegy");
                }
            }
        }

        for(std::size_t i = 0;i < gameActions.size(); i ++ ){
            avg_strategy[i] = avg_strategy[i] / sum_strategy;
            pair<float,float> statics = pair<float,float>(combos[i],avg_strategy[i]);
            pair<GameActions,pair<float,float>> one_ret = pair<GameActions,pair<float,float>>(gameActions[i],statics);
            ret_strategy.push_back(one_ret);
        }
        return ret_strategy;
    }else{
        return ret_strategy;
    }


}
```