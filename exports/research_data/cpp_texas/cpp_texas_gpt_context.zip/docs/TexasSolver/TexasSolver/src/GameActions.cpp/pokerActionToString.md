`pokerActionToString`: The function of `pokerActionToString` is to convert a `PokerActions` enum value to its corresponding string representation.

**Parameters**:\
`GameTreeNode::PokerActions pokerActions`: An enum value representing a specific poker action.

**Code Description**: This method takes an enum value of type `GameTreeNode::PokerActions` and returns a string that describes the poker action. It uses a switch statement to match the enum value to its corresponding string. If the enum value does not match any of the predefined cases, it throws a runtime error indicating that the poker action was not found. The possible poker actions include "BEGIN", "ROUNDBEGIN", "BET", "RAISE", "CHECK", "FOLD", and "CALL".\\
## Code: 
```
string GameActions::pokerActionToString(GameTreeNode::PokerActions pokerActions) {
    switch (pokerActions)
    {
        case GameTreeNode::PokerActions::BEGIN :   return "BEGIN";
        case GameTreeNode::PokerActions::ROUNDBEGIN :   return "ROUNDBEGIN";
        case GameTreeNode::PokerActions::BET :   return "BET";
        case GameTreeNode::PokerActions::RAISE :   return "RAISE";
        case GameTreeNode::PokerActions::CHECK :   return "CHECK";
        case GameTreeNode::PokerActions::FOLD :   return "FOLD";
        case GameTreeNode::PokerActions::CALL :   return "CALL";
        default:{
            throw runtime_error("PokerActions not found");
        }
    }
}
```