`data`: The function of `data` is to retrieve data from the model for a given index and role.

**Parameters**:\
`const QModelIndex &index`: Represents the index of the item in the model. It contains information about the row and column of the item. \
`int role`: Specifies the role for which the data is being requested. This can determine the type of data to return (e.g., display data, edit data).

**Code Description**: This method retrieves data from the `RoughStrategyViewerModel` based on the provided `index` and `role`. It first determines the column of the given index. If the column is within the bounds of the `total_strategy` vector in `tableStrategyModel`, it retrieves the strategy data at that column and returns the second float value as a string. If the column is out of bounds, it returns the string "Rough Strategy".\\
## Code: 
```
QVariant RoughStrategyViewerModel::data(const QModelIndex &index, int role) const
{
    std::size_t col = index.column();
    if(col < this->tableStrategyModel->total_strategy.size()){
        pair<GameActions,pair<float,float>> one_strategy = this->tableStrategyModel->total_strategy[col];
        return QString::number(one_strategy.second.second);
    }else{
        return "Rough Strategy";
    }
}
```