`RoughStrategyItemDelegate`: The function of `RoughStrategyItemDelegate` is to initialize an instance of the `RoughStrategyItemDelegate` class, setting up its parent and detail window settings.
**Parameters**:\
`DetailWindowSetting* detailWindowSetting`: A pointer to a `DetailWindowSetting` object that contains settings for the detail window. \
`QObject *parent`: A pointer to the parent `QObject`, which is passed to the base class constructor.

**Code Description**: The constructor `RoughStrategyItemDelegate` initializes the `RoughStrategyItemDelegate` object by calling the constructor of its base class `WordItemDelegate` with the `parent` parameter. It then assigns the provided `detailWindowSetting` to the member variable `this->detailWindowSetting`.\\
## Code: 
```
RoughStrategyItemDelegate::RoughStrategyItemDelegate(DetailWindowSetting* detailWindowSetting,QObject *parent) :
    WordItemDelegate(parent)
{
    this->detailWindowSetting = detailWindowSetting;
}
```