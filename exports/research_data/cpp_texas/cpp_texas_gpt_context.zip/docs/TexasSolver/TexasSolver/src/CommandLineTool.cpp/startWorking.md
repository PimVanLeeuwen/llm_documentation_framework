`startWorking`: The function of `startWorking` is to continuously read user input commands from the console and process them using the `processCommand` method.

**Code Description**: This code defines a loop in the `CommandLineTool::startWorking` method that reads input lines from the console until it reaches the end. Each line is then processed by calling the `processCommand` method, which updates the solver's settings based on user input commands.\\
## Code: 
```
void CommandLineTool::startWorking() {
    string input_line;
    while(cin) {
        getline(cin, input_line);
        this->processCommand(input_line);
    };
}
```