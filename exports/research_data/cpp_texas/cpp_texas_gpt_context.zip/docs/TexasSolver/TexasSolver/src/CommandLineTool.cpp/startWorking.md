`startWorking`: The function of `startWorking` is to continuously read input from the standard input stream and process each line using the `processCommand` method.

**Code Description**: The `startWorking` method is part of the `CommandLineTool` class. It enters an infinite loop where it reads lines of input from the standard input stream (`cin`). For each line read, it calls the `processCommand` method to handle the input. This loop continues until the end of the input stream is reached. The `processCommand` method is responsible for interpreting and executing the commands related to poker game operations.\\
## Code: 
```
void CommandLineTool::startWorking() {
    string input_line;
    while(cin) {
        getline(cin, input_line);
        this->processCommand(input_line);
    };
}
```