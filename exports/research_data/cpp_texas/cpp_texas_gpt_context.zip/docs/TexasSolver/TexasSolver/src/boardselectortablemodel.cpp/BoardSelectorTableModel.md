`BoardSelectorTableModel`: The function of `BoardSelectorTableModel` is to initialize a table model for selecting a board in a Texas Hold'em game, setting up the ranks, suits, and initial board state.

**Parameters**:\
`QStringList ranks`: A list of rank strings representing the ranks of cards (e.g., "2", "3", "4", ..., "A").\
`QString initial_board`: A string representing the initial state of the board, which will be parsed and set in the model.\
`QObject *parent`: A pointer to the parent object, typically used for memory management within the Qt framework.

**Code Description**: The `BoardSelectorTableModel` constructor initializes the table model by setting up the ranks and suits of the cards. It creates a 2D vector `grids_string` to store the string representation of each card combination and a 2D vector `grids_float` to store float values for each card combination, initializing them to 0.0. The constructor also maps each card string to its corresponding position in the grid. Finally, it sets the initial board state using the `setBoardText` method.\\
## Code: 
```
BoardSelectorTableModel::BoardSelectorTableModel(QStringList ranks,QString initial_board,QObject *parent):QAbstractItemModel(parent){
    this->ranklist = ranks;
    this->suitlist = QString("c,d,h,s").split(",");

    this->grids_string = vector<vector<QString>>(this->suitlist.size());
    for(int i = 0;i < this->suitlist.size();i ++){
        this->grids_string[i] = vector<QString>(this->ranklist.size());
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_string[i][j] = this->get_ij_text(i,j);
            this->string2ij[this->get_ij_text(i,j)] = pair<int,int>(i,j);
        }
    }

    this->grids_float = vector<vector<float>>(this->suitlist.size());
    for(int i = 0;i < this->suitlist.size();i ++){
        this->grids_float[i] = vector<float>(this->ranklist.size(),0.0);
    }
    this->setBoardText(initial_board);
}
```