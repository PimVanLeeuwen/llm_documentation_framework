`indPlayer2Player`: The function of `indPlayer2Player` is to map the index of a private card from one player to the corresponding index for another player.

**Parameters**:\
`int from_player`: The index of the player from whom the private card index is being mapped. \
`int to_player`: The index of the player to whom the private card index is being mapped. \
`int index`: The index of the private card in the `from_player`'s hand.

**Code Description**: This method first checks if the provided `index` is within the valid range of the `from_player`'s private cards. If the index is out of range, it throws a runtime error. It then retrieves the hash code of the private card at the specified index for the `from_player` and uses this hash code to find the corresponding index for the `to_player` from the `card_player_index` map. If the corresponding index for the `to_player` is not found (i.e., it is -1), the method returns -1. Otherwise, it returns the found index.\\
## Code: 
```
int PrivateCardsManager::indPlayer2Player(int from_player, int to_player, int index) {
    if(index < 0 || index >= this->getPreflopCards(from_player).size()) throw runtime_error("index out of range");
    //PrivateCards player_combo = this->getPreflopCards(from_player)[index];
    int to_player_index = this->card_player_index[this->private_cards[from_player][index].hashCode()][to_player];
    if(to_player_index == -1){
        return -1;
    }else {
        return to_player_index;
    }
}
```