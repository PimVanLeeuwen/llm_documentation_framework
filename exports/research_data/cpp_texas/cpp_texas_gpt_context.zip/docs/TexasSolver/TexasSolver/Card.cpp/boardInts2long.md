`boardInts2long`: The function of `boardInts2long` is to convert a vector of integers representing card IDs into a single 64-bit unsigned integer where each bit represents the presence of a card.

**Parameters**:\
`const vector<int>& board`: A vector of integers where each integer represents a card ID. The card IDs must be within the range of 0 to 51, inclusive.

**Code Description**: The function first checks if the size of the input vector `board` is between 1 and 7, inclusive. If not, it throws a runtime error indicating an incorrect card length. It then initializes a 64-bit unsigned integer `board_long` to 0. For each card ID in the vector, it checks if the card ID is within the valid range (0 to 51). If any card ID is out of range, it throws a runtime error indicating the card ID is not found. For each valid card ID, it sets the corresponding bit in `board_long` by shifting 1 to the left by the card ID value and adding it to `board_long`. Finally, it returns the resulting 64-bit unsigned integer.\\
## Code: 
```
uint64_t Card::boardInts2long(const vector<int>& board){
    if(board.size() < 1 || board.size() > 7){
        throw runtime_error(tfm::format("Card length incorrect: %s",board.size()));
    }
    uint64_t board_long = 0;
    for(int one_card: board){
        // 这里hard code了一副扑克牌是52张
        if(one_card < 0 || one_card >= 52){
            throw runtime_error(tfm::format("Card with id %s not found",one_card));
        }
        // uint64_7 的range 在0 ~ + 2^ 64之间,所以不用太担心溢出问题
        board_long += ((uint64_t)(1) << one_card);
    }
    return board_long;
}
```