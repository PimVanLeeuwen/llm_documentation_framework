`Card`: The function of `Card` is to initialize a card object with a string representation of a card, convert it to an integer representation, and set its position in the deck to an initial value.

**Parameters**:\
`string card`: A two-character string representing a card, where the first character denotes the rank and the second character denotes the suit.

**Code Description**: The `Card` constructor initializes a card object by setting its `card` attribute to the provided string representation. It then calls the `strCard2int` method to convert this string into an integer representation, which is stored in the `card_int` attribute. Finally, it initializes the `card_number_in_deck` attribute to -1, indicating that the card's position in the deck is not yet set.\\
## Code: 
```
Card::Card(string card){
    this->card = card;
    this->card_int = Card::strCard2int(this->card);
    this->card_number_in_deck = -1;
}
```