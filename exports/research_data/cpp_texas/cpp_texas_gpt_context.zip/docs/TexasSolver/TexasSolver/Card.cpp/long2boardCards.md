`long2boardCards`: The function of `long2boardCards` is to convert a 64-bit integer representation of a card board into a vector of `Card` objects.

**Parameters**:\
`uint64_t board_long`: A 64-bit integer representing the card board, where each bit corresponds to a specific card.

**Code Description**: The `long2boardCards` method first converts the 64-bit integer `board_long` into a vector of card indices using the `long2board` method. It then initializes a vector of `Card` objects, `board_cards`, by converting each card index to its string representation using the `intCard2Str` method and creating a `Card` object with that string. The method checks if the number of cards is between 1 and 7, throwing a runtime error if not. Finally, it copies the `board_cards` vector to a new vector `retval` and returns it.\\
## Code: 
```
vector<Card> Card::long2boardCards(uint64_t board_long){
        vector<int> board = long2board(board_long);
        vector<Card> board_cards(board.size());
        for(std::size_t i = 0;i < board.size();i ++){
            int one_board = board[i];
            board_cards[i] = Card(intCard2Str(one_board));
        }
        if (board_cards.size() < 1 || board_cards.size() > 7){
            throw runtime_error(tfm::format("board length not correct, board length %s",board_cards.size()));
        }
        vector<Card> retval(board_cards.size());
        for(std::size_t i = 0;i < board_cards.size();i ++){
            retval[i] = board_cards[i];
        }
        return retval;
}
```