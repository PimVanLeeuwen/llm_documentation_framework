`long2board`: The function of `long2board` is to convert a 64-bit integer representation of a card board into a vector of integers representing the indices of the cards.

**Parameters**:\
`uint64_t board_long`: A 64-bit integer where each bit represents the presence (1) or absence (0) of a card in a deck of 52 cards.

**Code Description**: The `long2board` method iterates through each of the 52 possible card positions in the 64-bit integer `board_long`. For each position, it checks if the least significant bit is set to 1, indicating the presence of a card at that position. If so, it adds the position index to the `board` vector. The method then right-shifts `board_long` by one bit to check the next position. After processing all 52 positions, it verifies that the number of cards in the `board` vector is between 1 and 7. If not, it throws a runtime error. Finally, it returns the `board` vector containing the indices of the cards.\\
## Code: 
```
vector<int> Card::long2board(uint64_t board_long) {
    vector<int> board;
    board.reserve(7);
    for(int i = 0;i < 52;i ++){
        // 看二进制最后一位是否为1
        if((board_long & 1) == 1){
            board.push_back(i);
        }
        board_long = board_long >> 1;
    }
    if (board.size() < 1 || board.size() > 7){
        throw runtime_error(tfm::format("board length not correct, board length %s",board.size()));
    }
    return board;
}
```