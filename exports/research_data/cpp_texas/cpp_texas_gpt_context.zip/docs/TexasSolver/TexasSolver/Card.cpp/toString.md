`toString`: The function of `toString` is to return the string representation of the card.

**Code Description**: The `toString` method in the `Card` class returns the value of the `card` attribute, which is a string representing the card. This method provides a way to obtain the string format of the card object for display or other purposes.\\
## Code: 
```
string Card::toString() {
    return this->card;
}
```