`card2int`: The function of `card2int` is to convert a `Card` object into its corresponding integer representation.

**Parameters**:\
`Card card`: The `Card` object that needs to be converted to an integer.

**Code Description**: The `card2int` method takes a `Card` object as input and converts it to an integer by first retrieving the card's string representation using the `getCard` method and then converting this string to an integer using the `strCard2int` method. The integer value represents the card based on its rank and suit.\\
## Code: 
```
int Card::card2int(Card card) {
    return strCard2int(card.getCard());
}
```