`getSuits`: The function of `getSuits` is to return a list of strings representing the four suits in a standard deck of playing cards.

**Code Description**: The `getSuits` method in the `Card` class returns a `vector` containing four strings: "c", "d", "h", and "s". These strings represent the suits of clubs, diamonds, hearts, and spades, respectively.\\
## Code: 
```
vector<string> Card::getSuits(){
    return {"c","d","h","s"};
}
```