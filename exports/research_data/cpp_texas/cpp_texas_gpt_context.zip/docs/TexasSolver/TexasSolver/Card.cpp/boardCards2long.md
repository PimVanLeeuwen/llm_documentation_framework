`boardCards2long`: The function of `boardCards2long` is to convert a vector of card string representations into a single 64-bit integer.

**Parameters**:\
`vector<string> cards`: A vector containing string representations of cards.

**Code Description**: This method takes a vector of card strings, converts each string into a `Card` object, and then calls another `boardCards2long` method that operates on a vector of `Card` objects to produce a 64-bit integer representation of the board cards.\\
## Code: 
```
uint64_t Card::boardCards2long(vector<string> cards) {
    vector<Card> cards_objs(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_objs[i] = Card(cards[i]);
    }
    return Card::boardCards2long(cards_objs);
}
```