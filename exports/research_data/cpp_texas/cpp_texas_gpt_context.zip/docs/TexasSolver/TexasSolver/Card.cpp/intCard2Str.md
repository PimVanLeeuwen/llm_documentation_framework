`intCard2Str`: The function of `intCard2Str` is to convert an integer representation of a card into its string representation.

**Parameters**:\
`int card`: An integer representing a card, where the value encodes both the rank and suit of the card.

**Code Description**: The `intCard2Str` method takes an integer `card` as input, which represents a playing card. It calculates the rank of the card by dividing the integer by 4 and adding 2. The suit is determined by subtracting the product of `(rank-2)` and 4 from the original integer. The method then converts the rank and suit to their respective string representations using the `rankToString` and `suitToString` methods, and concatenates these strings to form the final card representation. The resulting string is returned.\\
## Code: 
```
string Card::intCard2Str(int card){
    int rank = card / 4 + 2;
    int suit = card - (rank-2)*4;
    return Card::rankToString(rank) + Card::suitToString(suit);
}
```