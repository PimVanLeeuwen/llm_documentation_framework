`getNumberInDeckInt`: The function of `getNumberInDeckInt` is to retrieve the card's number in the deck.

**Code Description**: This method returns the integer value representing the card's position or number in the deck. If the card's number in the deck is set to -1, it throws a runtime error indicating that the card number in the deck cannot be -1. This ensures that the card has a valid position or number before it is accessed.\\
## Code: 
```
int Card::getNumberInDeckInt(){
    if(this->card_number_in_deck == -1)throw runtime_error("card number in deck cannot be -1");
    return this->card_number_in_deck;
}
```