`boardInt2long`: The function of `boardInt2long` is to convert a given card index into a 64-bit integer representation where the bit at the position corresponding to the card index is set to 1.

**Parameters**:\
`int board`: The index of the card in the deck, which must be between 0 and 51 inclusive.

**Code Description**: This method first checks if the provided card index (`board`) is within the valid range of 0 to 51. If the index is out of this range, it throws a runtime error indicating that the card with the given id is not found. If the index is valid, it returns a 64-bit integer where only the bit at the position corresponding to the card index is set to 1. This is achieved by left-shifting the number 1 by the value of `board`.\\
## Code: 
```
uint64_t Card::boardInt2long(int board){
    // 这里hard code了一副扑克牌是52张
    if(board < 0 || board >= 52){
        throw runtime_error(tfm::format("Card with id %s not found",board));
    }
    // uint64_7 的range 在0 ~ + 2^ 64之间,所以不用太担心溢出问题
    return ((uint64_t)(1) << board);
}
```