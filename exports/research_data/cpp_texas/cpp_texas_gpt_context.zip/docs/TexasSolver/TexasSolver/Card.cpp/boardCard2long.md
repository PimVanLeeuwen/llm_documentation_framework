`boardCard2long`: The function of `boardCard2long` is to convert a `Card` object into a 64-bit integer representation by utilizing the card's integer value.

**Parameters**:\
`Card& card`: A reference to a `Card` object whose integer value will be converted to a 64-bit integer.

**Code Description**: The `boardCard2long` method takes a `Card` object as input and converts it into a 64-bit integer. It does this by first calling the `getCardInt` method on the `Card` object to retrieve its integer value. This integer value is then passed to the `boardInt2long` method, which converts the integer into a 64-bit integer where only the bit at the position corresponding to the card's index is set. This 64-bit integer is then returned as the result.\\
## Code: 
```
uint64_t Card::boardCard2long(Card& card){
    return Card::boardInt2long(card.getCardInt());
}
```