`toFormattedString`: The function of `toFormattedString` is to convert the card's string representation into a formatted string with suit symbols.

**Code Description**: The `toFormattedString` method in the `Card` class converts the card's string representation (which uses 'c', 'd', 'h', 's' for clubs, diamonds, hearts, and spades respectively) into a formatted string with the corresponding Unicode suit symbols (♣️, ♦️, ♥️, ♠️). It uses the `QString` class to perform the string replacements and then converts the `QString` back to a standard string for the final output.\\
## Code: 
```
string Card::toFormattedString() {
    QString qString = QString::fromStdString(this->card);
    qString = qString.replace("c", "♣️");
    qString = qString.replace("d", "♦️");
    qString = qString.replace("h", "♥️");
    qString = qString.replace("s", "♠️");
    return qString.toStdString();
}
```