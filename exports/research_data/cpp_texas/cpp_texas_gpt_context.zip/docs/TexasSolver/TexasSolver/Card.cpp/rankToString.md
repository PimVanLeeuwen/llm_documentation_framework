`rankToString`: The function of `rankToString` is to convert a numerical card rank into its corresponding string representation.

**Parameters**:\
`int rank`: The numerical rank of the card, where 2-10 represent the cards 2 through 10, 11 represents Jack, 12 represents Queen, 13 represents King, and 14 represents Ace.

**Code Description**: The `rankToString` method takes an integer `rank` as input and uses a switch statement to return the corresponding string representation of the card rank. If the rank is between 2 and 14, it returns the appropriate string ("2" to "9", "T" for 10, "J" for Jack, "Q" for Queen, "K" for King, and "A" for Ace). If the rank does not match any of these cases, it defaults to returning "2".\\
## Code: 
```
string Card::rankToString(int rank)
{
    switch(rank)
    {
        case 2: return "2";
        case 3: return "3";
        case 4: return "4";
        case 5: return "5";
        case 6: return "6";
        case 7: return "7";
        case 8: return "8";
        case 9: return "9";
        case 10: return "T";
        case 11: return "J";
        case 12: return "Q";
        case 13: return "K";
        case 14: return "A";
        default: return "2";
    }
}
```