`rankToInt`: The function of `rankToInt` is to convert a card rank represented by a character into its corresponding integer value.

**Parameters**:\
`char rank`: A character representing the rank of a card. Valid inputs are '2', '3', '4', '5', '6', '7', '8', '9', 'T' (10), 'J' (Jack), 'Q' (Queen), 'K' (King), and 'A' (Ace).

**Code Description**: The `rankToInt` method uses a switch statement to map each valid card rank character to its corresponding integer value. If the input character does not match any of the valid ranks, the function defaults to returning 2.\\
## Code: 
```
int Card::rankToInt(char rank)
{
    switch(rank)
    {
        case '2': return 2;
        case '3': return 3;
        case '4': return 4;
        case '5': return 5;
        case '6': return 6;
        case '7': return 7;
        case '8': return 8;
        case '9': return 9;
        case 'T': return 10;
        case 'J': return 11;
        case 'Q': return 12;
        case 'K': return 13;
        case 'A': return 14;
        default: return 2;
    }
}
```