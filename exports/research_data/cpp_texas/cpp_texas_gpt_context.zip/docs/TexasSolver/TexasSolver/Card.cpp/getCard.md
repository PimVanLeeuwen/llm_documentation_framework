`getCard`: The function of `getCard` is to return the value of the `card` attribute of the `Card` object.

**Code Description**: This method, `getCard`, is a member of the `Card` class. When called, it returns the value stored in the `card` attribute of the `Card` instance. The return type of this method is a `string`.\\
## Code: 
```
string Card::getCard() {
    return this->card;
}
```