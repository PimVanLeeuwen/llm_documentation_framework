`boardCards2html`: The function of `boardCards2html` is to convert a vector of `Card` objects into a single HTML formatted string representation.

**Parameters**:\
`vector<Card>& cards`: A reference to a vector containing `Card` objects that need to be converted to HTML format.

**Code Description**: The `boardCards2html` method iterates through each `Card` object in the provided vector. For each card, it checks if the card is not empty using the `empty` method. If the card is not empty, it converts the card to an HTML formatted string using the `toFormattedHtml` method and appends this string to the `ret_html` string. Finally, the method returns the concatenated HTML string representing all the cards.\\
## Code: 
```
QString Card::boardCards2html(vector<Card>& cards){
    QString ret_html = "";
    for(auto one_card:cards){
        if(one_card.empty())continue;
        ret_html += one_card.toFormattedHtml();
    }
    return ret_html;
}
```