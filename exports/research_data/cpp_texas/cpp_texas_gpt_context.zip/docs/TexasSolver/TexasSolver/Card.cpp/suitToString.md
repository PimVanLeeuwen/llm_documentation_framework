`suitToString`: The function of `suitToString` is to convert an integer representing a card suit into its corresponding string representation.

**Parameters**:\
`int suit`: An integer value representing the suit of a card, where 0 corresponds to clubs, 1 to diamonds, 2 to hearts, and 3 to spades.

**Code Description**: The `suitToString` method takes an integer input `suit` and uses a switch statement to return the corresponding string representation of the card suit. If the input is 0, it returns "c" for clubs; if 1, it returns "d" for diamonds; if 2, it returns "h" for hearts; and if 3, it returns "s" for spades. If the input does not match any of these cases, it defaults to returning "c".\\
## Code: 
```
string Card::suitToString(int suit)
{
    switch(suit)
    {
        case 0: return "c";
        case 1: return "d";
        case 2: return "h";
        case 3: return "s";
        default: return "c";
    }
}
```