`suitToInt`: The function of `suitToInt` is to convert a card suit character to its corresponding integer value.

**Parameters**:\
`char suit`: A character representing the suit of a card. Valid inputs are 'c' for clubs, 'd' for diamonds, 'h' for hearts, and 's' for spades.

**Code Description**: The `suitToInt` method takes a single character representing a card suit and returns an integer corresponding to that suit. The mapping is as follows: 'c' (clubs) to 0, 'd' (diamonds) to 1, 'h' (hearts) to 2, and 's' (spades) to 3. If the input character does not match any of these suits, the function defaults to returning 0.\\
## Code: 
```
int Card::suitToInt(char suit)
{
    switch(suit)
    {
        case 'c': return 0; // 梅花
        case 'd': return 1; // 方块
        case 'h': return 2; // 红桃
        case 's': return 3; // 黑桃
        default: return 0;
    }
}
```