`strCard2int`: The function of `strCard2int` is to convert a string representation of a card into its corresponding integer value.

**Parameters**:\
`string card`: A string representing a card, where the first character is the rank and the second character is the suit.

**Code Description**: The `strCard2int` method takes a string input representing a card (e.g., "As" for Ace of spades). It first extracts the rank and suit characters from the string. If the string length is not exactly 2, it throws a runtime error indicating that the card is not found. It then converts the rank and suit characters to their respective integer values using the `rankToInt` and `suitToInt` methods. Finally, it calculates and returns the integer representation of the card by combining the rank and suit values in a specific formula: `(rankToInt(rank) - 2) * 4 + suitToInt(suit)`.\\
## Code: 
```
int Card::strCard2int(string card) {
    char rank = card.at(0);
    char suit = card.at(1);
    if(card.length() != 2){
        throw runtime_error( tfm::format("card %s not found",card));
    }
    return (rankToInt(rank) - 2) * 4 + suitToInt(suit);
}
```