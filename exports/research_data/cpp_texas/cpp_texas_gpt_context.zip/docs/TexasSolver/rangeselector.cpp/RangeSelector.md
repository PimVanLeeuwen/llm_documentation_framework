`RangeSelector`: The function of `RangeSelector` is to initialize and configure a dialog for selecting poker hand ranges based on the specified game mode (HOLDEM or SHORTDECK).

**Parameters**:\
`QTextEdit* rangeEdit`: A pointer to a `QTextEdit` widget that contains the initial range text. \
`QWidget *parent`: A pointer to the parent widget, which is passed to the `QDialog` constructor. \
`QSolverJob::Mode mode`: An enumeration value that specifies the game mode (HOLDEM or SHORTDECK), determining the set of ranks to be used.

**Code Description**: The `RangeSelector` constructor initializes the dialog for selecting poker hand ranges. It sets up the user interface, determines the set of ranks based on the specified game mode, and initializes the table model and delegate for displaying and editing the ranges. The constructor also connects various signals to their corresponding slots to handle user interactions with the range table view. Additionally, it configures the file system model to filter and display text files from the "ranges" directory.\\
## Code: 
```
RangeSelector::RangeSelector(QTextEdit* rangeEdit,QWidget *parent,QSolverJob::Mode mode) :
    QDialog(parent),
    ui(new Ui::RangeSelector)
{

    QString ranks;
    if(mode == QSolverJob::Mode::HOLDEM){
        ranks = "A,K,Q,J,T,9,8,7,6,5,4,3,2";
    }else if(mode == QSolverJob::Mode::SHORTDECK){
        ranks = "A,K,Q,J,T,9,8,7,6";
    }else{
        throw runtime_error("mode not found in range selector");
    }
    this->rank_list = ranks.split(",");
    this->rangeSelectorTableModel = new RangeSelectorTableModel(this->rank_list,rangeEdit->toPlainText(),this);
    this->rangeSelectorTableDelegate = new RangeSelectorTableDelegate(this->rank_list,this->rangeSelectorTableModel,this);
    ui->setupUi(this);
    this->ui->rangeTableView->setModel(this->rangeSelectorTableModel);
    this->ui->rangeTableView->setItemDelegate(this->rangeSelectorTableDelegate);
    this->rangeEdit = rangeEdit;
    this->ui->textEdit->setText(this->rangeEdit->toPlainText());
    this->ui->rangeNumberSlider->setMaximum(this->max_val);
    this->ui->rangeNumberSlider->setValue(this->max_val);
    this->setWindowTitle(tr("RangeSelector"));
    connect(this->ui->rangeTableView,SIGNAL(view_item_pressed(int,int)),this,SLOT(grid_pressed(int,int)));
    connect(this->ui->rangeTableView,SIGNAL(view_item_area(int,int,int,int)),this,SLOT(grid_area(int,int,int,int)));
    connect(this->ui->rangeTableView,SIGNAL(item_release(int,int)),this,SLOT(grid_release(int,int)));

    QStringList filters;
    filters << "*.txt";
    qFileSystemModel = new QFileSystemModel(this);
    QDir filedir = QDir::current().filePath("ranges");
    qFileSystemModel->setRootPath(filedir.path());
#ifdef Q_OS_MAC
```