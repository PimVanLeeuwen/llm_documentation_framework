`on_languageBox_currentIndexChanged`: The function of `on_languageBox_currentIndexChanged` is to display a message prompting the user to restart the program to apply the new language selection when the language selection index is changed.

**Parameters**:\
`int index`: The index of the newly selected language in the language selection box.

**Code Description**: This method first checks if the initialization flag (`initized`) is set to `true`. If not, the method returns immediately without performing any actions. If the initialization flag is set, it creates a message string indicating that the user needs to restart the program for the language change to take effect. This message is then logged to the debug output without additional formatting. A message box is created, the message is set as its text, and the message box is displayed to the user.\\
## Code: 
```
void SettingEditor::on_languageBox_currentIndexChanged(int index)
{
    if(!initized)return;
    QString message = tr("Restart program to make language selection effective.");
    qDebug().noquote() << message;
    QMessageBox msgBox;
    msgBox.setText(message);
    msgBox.exec();
}
```