`on_confirmBox_accepted`: The function of `on_confirmBox_accepted` is to save the user's selected language and round settings to a configuration file.

**Code Description**: The `on_confirmBox_accepted` method is part of the `SettingEditor` class. When called, it creates a `QSettings` object to manage application settings for "TexasSolver". It begins by accessing the "solver" group within the settings. The method retrieves the currently selected language from the `languageBox` UI element and converts it to a corresponding language code ("EN" for English, "CN" for Chinese). If the language is not recognized, it logs an error message. The language code is then saved to the settings. Additionally, the method retrieves the selected round number from the `roundBox` UI element, converts it to an integer, and saves it to the settings under the key "dump_round".\\
## Code: 
```
void SettingEditor::on_confirmBox_accepted()
{
    QSettings setting("TexasSolver", "Setting");
    setting.beginGroup("solver");
    QString lang = this->ui->languageBox->currentText();
    QString language_str;
    if(lang == "English"){
        language_str = "EN";
    }else if(lang == "Chinese"){
        language_str = "CN";
    }else{
        qDebug().noquote() << tr("Unknown language: ") << lang << tr("Setting fail");
    }
    setting.setValue("language",language_str);

    int round = this->ui->roundBox->currentText().toInt();
    setting.setValue("dump_round",round);
}
```