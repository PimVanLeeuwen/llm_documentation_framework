`mouseMoveEvent`: The function of `mouseMoveEvent` is to handle mouse movement events within the `HtmlTableView` and update the cursor and link hover state accordingly.
**Parameters**:\
`QMouseEvent *event`: This parameter represents the mouse event that contains information about the position and state of the mouse.

**Code Description**: This method first determines the anchor (link) at the current mouse position using the `anchorAt` method. If the anchor under the mouse has changed since the last mouse press, it clears the `_mousePressAnchor`. It then checks if the anchor under the mouse has changed since the last hover event. If it has, it updates `_lastHoveredAnchor` and changes the cursor to a pointing hand if the new anchor is not empty, emitting the `linkHovered` signal. If the new anchor is empty, it restores the default cursor and emits the `linkUnhovered` signal.\\
## Code: 
```
void HtmlTableView::mouseMoveEvent(QMouseEvent *event) {
    auto anchor = anchorAt(event->pos());

    if (_mousePressAnchor != anchor) {
        _mousePressAnchor.clear();
    }

    if (_lastHoveredAnchor != anchor) {
        _lastHoveredAnchor = anchor;
        if (!_lastHoveredAnchor.isEmpty()) {
            QApplication::setOverrideCursor(QCursor(Qt::PointingHandCursor));
            emit linkHovered(_lastHoveredAnchor);
        } else {
            QApplication::restoreOverrideCursor();
            emit linkUnhovered();
        }
    }
}
```