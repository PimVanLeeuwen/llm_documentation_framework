`triger_resize`: The function of `triger_resize` is to programmatically trigger a resize event for the `HtmlTableView` object.

**Code Description**: The `triger_resize` method creates a new `QResizeEvent` object with the current size of the `HtmlTableView` object. It then calls the `resizeEvent` method with this event to handle the resizing logic. After the event is processed, the method deletes the `QResizeEvent` object to free up memory. This method ensures that the table view adjusts its layout as if it had been manually resized.\\
## Code: 
```
void HtmlTableView::triger_resize(){
    QResizeEvent* ev = new QResizeEvent(this->size(),this->size());
    this->resizeEvent(ev);
    //this->resize(this->parentWidget()->size());
    delete ev;
}
```