`eventFilter`: The function of `eventFilter` is to handle specific events (mouse movement and leave events) occurring on the viewport of the `HtmlTableView` and emit a signal when the mouse moves over a different table cell.

**Parameters**:\
`QObject *watched`: The object that is being watched for events. In this context, it is the viewport of the `HtmlTableView`.\
`QEvent *event`: The event that occurred, which could be a mouse movement or leave event.

**Code Description**: The `eventFilter` method first checks if the event is occurring on the viewport of the `HtmlTableView`. If the event is a mouse movement (`QEvent::MouseMove`), it casts the event to a `QMouseEvent` and determines the table cell (row and column) at the mouse position. If the mouse is over a different cell than the last recorded cell, it updates the last recorded cell position and emits the `itemMouseChange` signal with the new row and column indices. If the event is a leave event (`QEvent::Leave`), it does not perform any specific action. Finally, it calls the base class's `eventFilter` method to ensure standard event processing.\\
## Code: 
```
bool HtmlTableView::eventFilter(QObject *watched, QEvent *event){
    if(viewport() == watched){
        if(event->type() == QEvent::MouseMove){
        QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
        QModelIndex index = indexAt(mouseEvent->pos());
        if(index.isValid()){
            int i = index.row();
            int j = index.column();
            if(i != this->last_bearing_i || j != last_bearing_j){
                this->last_bearing_i = i;
                this->last_bearing_j = j;
                emit itemMouseChange(i,j);
            }
        }
        else{
        }
        }
        else if(event->type() == QEvent::Leave){
        }
    }
    return QTableView::eventFilter(watched, event);
}
```