`HtmlTableView`: The function of `HtmlTableView` is to create a custom table view widget that inherits from `QTableView` and installs an event filter on its viewport to handle specific events.

**Parameters**:\
`QWidget *parent`: This parameter is a pointer to the parent widget, which is passed to the `QTableView` constructor to set the parent-child relationship for the widget.

**Code Description**: The `HtmlTableView` constructor initializes the custom table view by calling the `QTableView` constructor with the provided parent widget. It then installs an event filter on the viewport of the table view to intercept and handle events before they reach the viewport. Additionally, it enables mouse tracking for the widget, allowing it to receive mouse move events even when no buttons are pressed.\\
## Code: 
```
HtmlTableView::HtmlTableView(QWidget *parent):
    QTableView(parent)
{
    viewport()->installEventFilter(this);
    setMouseTracking(true);
}
```