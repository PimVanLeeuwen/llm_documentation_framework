`mouseReleaseEvent`: The function of `mouseReleaseEvent` is to handle the event when the mouse button is released within the `HtmlTableView` widget.
**Parameters**:\
`QMouseEvent *event`: This parameter represents the mouse event that contains information about the position and state of the mouse when the button is released.

**Code Description**: This method first checks if `_mousePressAnchor` is not empty, indicating that a mouse press event was previously recorded. It then retrieves the anchor at the current mouse position using the `anchorAt` method. If the anchor at the release position matches the one recorded during the press event, it emits the `linkActivated` signal with the anchor as its argument. Finally, it clears the `_mousePressAnchor` and calls the base class `QTableView`'s `mouseReleaseEvent` method to ensure any default handling is also performed.\\
## Code: 
```
void HtmlTableView::mouseReleaseEvent(QMouseEvent *event) {
    if (!_mousePressAnchor.isEmpty()) {
        auto anchor = anchorAt(event->pos());

        if (anchor == _mousePressAnchor) {
            emit linkActivated(_mousePressAnchor);
        }

        _mousePressAnchor.clear();
    }

    QTableView::mouseReleaseEvent(event);
}
```