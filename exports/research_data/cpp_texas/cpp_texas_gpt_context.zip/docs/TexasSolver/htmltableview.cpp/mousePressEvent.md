`mousePressEvent`: The function of `mousePressEvent` is to handle mouse press events within the `HtmlTableView` class.
**Parameters**:\
`QMouseEvent *event`: This parameter represents the mouse event that contains details about the mouse action, such as position, button pressed, etc.

**Code Description**: This method first calls the base class (`QTableView`) implementation of `mousePressEvent` to ensure that any default behavior is executed. It then retrieves the anchor (a specific point or element) at the position of the mouse event using the `anchorAt` method and stores this anchor in the `_mousePressAnchor` member variable for later use.\\
## Code: 
```
void HtmlTableView::mousePressEvent(QMouseEvent *event) {
    QTableView::mousePressEvent(event);

    auto anchor = anchorAt(event->pos());
    _mousePressAnchor = anchor;
}
```