`boardselector`: The function of `boardselector` is to initialize and set up the board selector dialog for a poker game, configuring it based on the game mode (HOLDEM or SHORTDECK).

**Parameters**:\
`QTextEdit* boardEdit`: A pointer to a QTextEdit widget that contains the current board text. \
`QSolverJob::Mode mode`: An enumeration value that specifies the game mode (HOLDEM or SHORTDECK). \
`QWidget *parent`: A pointer to the parent widget, which is passed to the QDialog constructor.

**Code Description**: The `boardselector` constructor initializes the board selector dialog by setting up the user interface, configuring the window title, and initializing the board text and game mode. It determines the appropriate rank list based on the game mode and splits the ranks into a list. The constructor then creates and sets up the `BoardSelectorTableModel` and `BoardSelectorTableDelegate` with the rank list and the current board text. Finally, it sets the text of the `boardEdit` widget to the current board text.\\
## Code: 
```
boardselector::boardselector(QTextEdit* boardEdit,QSolverJob::Mode mode,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::boardselector)
{
    ui->setupUi(this);
    this->setWindowTitle(tr("BoardSelector"));
    this->boardEdit = boardEdit;
    this->mode = mode;

    QString ranks;
    if(mode == QSolverJob::Mode::HOLDEM){
        ranks = "A,K,Q,J,T,9,8,7,6,5,4,3,2";
    }else if(mode == QSolverJob::Mode::SHORTDECK){
        ranks = "A,K,Q,J,T,9,8,7,6";
    }else{
        throw runtime_error("mode not found in range selector");
    }
    this->rank_list = ranks.split(",");

    this->boardSelectorTableModel = new BoardSelectorTableModel(this->rank_list,boardEdit->toPlainText(),this);
    this->ui->boardSelectorTable->setModel(boardSelectorTableModel);
    this->boardSelectorTableDelegate = new BoardSelectorTableDelegate(this->rank_list,this->boardSelectorTableModel,this);
    this->ui->boardSelectorTable->setItemDelegate(this->boardSelectorTableDelegate);
    this->ui->boardEdit->setText(boardEdit->toPlainText());
}
```