`on_cancelButton_clicked`: The function of `on_cancelButton_clicked` is to close the current window when the cancel button is clicked.

**Code Description**: This method is a slot connected to the cancel button's click signal in the `boardselector` class. When the cancel button is clicked, the `on_cancelButton_clicked` method is invoked, which calls the `close()` method on the current instance of the `boardselector` class, effectively closing the window.\\
## Code: 
```
void boardselector::on_cancelButton_clicked()
{
    this->close();
}
```