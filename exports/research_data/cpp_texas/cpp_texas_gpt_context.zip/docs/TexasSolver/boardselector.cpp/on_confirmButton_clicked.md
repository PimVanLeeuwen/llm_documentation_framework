`on_confirmButton_clicked`: The function of `on_confirmButton_clicked` is to update the text of the `boardEdit` widget and then close the current window.

**Code Description**: When the `confirmButton` is clicked, the method `on_confirmButton_clicked` is triggered. This method sets the text of the `boardEdit` widget to the current text in the `boardEdit` input field, ensuring any changes made by the user are saved. After updating the text, the method closes the window.\\
## Code: 
```
void boardselector::on_confirmButton_clicked()
{
    this->boardEdit->setText(this->ui->boardEdit->text());
    this->close();
}
```