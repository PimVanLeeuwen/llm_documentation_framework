`MainWindow`: The function of `MainWindow` is to initialize the main window of the TexasSolver application, set up the user interface, connect UI actions to their respective slots, and start a solver job.

**Parameters**:\
`QWidget *parent`: The parent widget of the main window, which can be `nullptr` if the main window has no parent.

**Code Description**: The `MainWindow` constructor initializes the main window by setting up the user interface using `setupUi`. It assigns the log window to a static member `s_textEdit` and connects various UI actions (such as `actionjson`, `actionSettings`, `actionimport`, `actionexport`, and `actionclear_all`) to their respective slot functions. It creates and starts a `QSolverJob` object, setting its context to the log area and its initial mission to `LOADING`. The window title is set to "TexasSolver". Additionally, it sets up a file system model to display parameters files with a `.txt` extension in a tree view.\\
## Code: 
```
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    MainWindow::s_textEdit = this->get_logwindow();
    connect(this->ui->actionjson, &QAction::triggered, this, &MainWindow::on_actionjson_triggered);
    connect(this->ui->actionSettings, &QAction::triggered, this, &MainWindow::on_actionSettings_triggered);
    connect(this->ui->actionimport, &QAction::triggered, this, &MainWindow::on_actionimport_triggered);
    connect(this->ui->actionexport, &QAction::triggered, this, &MainWindow::on_actionexport_triggered);
    connect(this->ui->actionclear_all, &QAction::triggered, this, &MainWindow::on_actionclear_all_triggered);
    qSolverJob = new QSolverJob;
    qSolverJob->setContext(this->getLogArea());
    qSolverJob->current_mission = QSolverJob::MissionType::LOADING;
    qSolverJob->start();
    this->setWindowTitle(tr("TexasSolver"));

    // parameters tree view
    QStringList filters;
    filters << "*.txt";
    qFileSystemModel = new QFileSystemModel(this);
    QDir filedir = QDir::current().filePath("parameters");
    qFileSystemModel->setRootPath(filedir.path());
#ifdef Q_OS_MAC
```