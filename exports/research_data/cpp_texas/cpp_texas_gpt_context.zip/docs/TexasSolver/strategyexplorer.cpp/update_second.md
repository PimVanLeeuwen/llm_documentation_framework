`update_second`: The function of `update_second` is to update various components of the user interface and process the poker board when there are cards in the hand.

**Code Description**: When called, `update_second` first checks if there are any cards in the hand. If so, it updates the table strategy model by calling its `updateStrategyData` method, which likely performs calculations and aggregations based on the game tree. It then calls the `onchanged` method of the rough strategy viewer model to update the header data of a table when its contents change. Additionally, it updates the viewport of several UI components, including the rough strategy view, strategy table view, and detail view. Finally, if there are cards in the hand, it processes the poker board by calling the `process_board` method with the current round number from the game tree node. This likely involves constructing Card objects for each card on the board and any additional table strategy cards, formatting them into an HTML string representation using the `boardCards2html` method, and displaying the resulting card list in HTML format on a user interface label.\\
## Code: 
```
void StrategyExplorer::update_second(){
    if(this->cards.size() > 0){
        this->tableStrategyModel->updateStrategyData();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```