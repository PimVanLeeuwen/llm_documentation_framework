`update_second`: The function of `update_second` is to refresh and update the strategy and UI components based on the current game state.

**Code Description**: 
The `update_second` method in the `StrategyExplorer` class performs several actions to ensure the strategy and UI components are up-to-date. If there are any cards in the current game state (`this->cards.size() > 0`), it updates the strategy data using `tableStrategyModel->updateStrategyData()`, signals that the rough strategy viewer model has changed with `roughStrategyViewerModel->onchanged()`, and refreshes the rough strategy view UI component. It then processes the current game board using `process_board(this->tableStrategyModel->treeItem)`. Finally, it updates the viewports of the strategy table view and detail view UI components to reflect any changes.\\
## Code: 
```
void StrategyExplorer::update_second(){
    if(this->cards.size() > 0){
        this->tableStrategyModel->updateStrategyData();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```