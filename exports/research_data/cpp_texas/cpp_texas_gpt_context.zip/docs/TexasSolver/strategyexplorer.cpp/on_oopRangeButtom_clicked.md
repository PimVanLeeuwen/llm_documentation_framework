`on_oopRangeButtom_clicked`: The function of `on_oopRangeButtom_clicked` is to update the user interface and internal state to reflect the "Out of Position" (OOP) range mode in the strategy explorer.

**Code Description**: This method sets the `mode` of `detailWindowSetting` to `RANGE_OOP`, indicating that the detail window should display the OOP range. It then updates the viewports of `strategyTableView`, `detailView`, and `roughStrategyView` to reflect this change. Additionally, it calls the `onchanged` method of `roughStrategyViewerModel` to signal that the strategy data has been modified, prompting a refresh of the displayed strategy.\\
## Code: 
```
void StrategyExplorer::on_oopRangeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::RANGE_OOP;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```