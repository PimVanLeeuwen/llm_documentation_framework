`process_board`: The function of `process_board` is to process the current state of a poker game board.

**Parameters**: 
`TreeItem* treeitem`: This parameter represents a pointer to a TreeItem object, which likely contains data about the current state of the game, including the round number and other relevant information.

**Code Description**: The function `process_board` takes a `TreeItem*` as input and performs several tasks:
- It splits the string representation of the board into individual card strings using the `string_split` method.
- It creates a vector of `Card` objects from the split card strings.
- If the input `treeitem` is not null, it checks the current round number and adds relevant cards to the vector based on the round number. Specifically:
  - If the round number is TURN and there are cards in the table strategy model's turn card list, it adds those cards to the vector.
  - If the round number is RIVER and there are cards in both the table strategy model's turn card list and river card list, it adds those cards to the vector.
- Finally, it updates a UI label with an HTML string representation of the processed board using the `Card::boardCards2html` method.\\
## Code: 
```
void StrategyExplorer::process_board(TreeItem* treeitem){
    vector<string> board_str_arr = string_split(this->qSolverJob->board,',');
    vector<Card> cards;
    for(string one_board_str:board_str_arr){
        cards.push_back(Card(one_board_str));
    }
    if(treeitem != NULL){
        if(treeitem->m_treedata.lock()->getRound() == GameTreeNode::GameRound::TURN && !this->tableStrategyModel->getTrunCard().empty()){
            cards.push_back(Card(this->tableStrategyModel->getTrunCard()));
        }
        else if(treeitem->m_treedata.lock()->getRound() == GameTreeNode::GameRound::RIVER){
            if(!this->tableStrategyModel->getTrunCard().empty())
                cards.push_back(Card(this->tableStrategyModel->getTrunCard()));
            if(!this->tableStrategyModel->getRiverCard().empty())
                cards.push_back(Card(this->tableStrategyModel->getRiverCard()));
        }
    }
    this->ui->boardLabel->setText(QString("<b>%1: </b>").arg(tr("board")) + Card::boardCards2html(cards));
}
```