`process_board`: The function of `process_board` is to process the current board state in a poker game and update the UI with the board cards in HTML format.

**Parameters**:\
`TreeItem* treeitem`: A pointer to a `TreeItem` object that contains data about the current state of the game tree. It can be `NULL`.

**Code Description**: The `process_board` method begins by splitting the board string from the `qSolverJob` object into individual card strings using the `string_split` method. These card strings are then converted into `Card` objects and stored in a vector. If the `treeitem` parameter is not `NULL`, the method checks the current game round using the `getRound` method of the `GameTreeNode` class. Depending on the round (TURN or RIVER), it adds the turn and/or river cards from the `tableStrategyModel` to the vector of cards if they are not empty. Finally, the method updates the `boardLabel` in the UI with the HTML representation of the board cards using the `boardCards2html` method.\\
## Code: 
```
void StrategyExplorer::process_board(TreeItem* treeitem){
    vector<string> board_str_arr = string_split(this->qSolverJob->board,',');
    vector<Card> cards;
    for(string one_board_str:board_str_arr){
        cards.push_back(Card(one_board_str));
    }
    if(treeitem != NULL){
        if(treeitem->m_treedata.lock()->getRound() == GameTreeNode::GameRound::TURN && !this->tableStrategyModel->getTrunCard().empty()){
            cards.push_back(Card(this->tableStrategyModel->getTrunCard()));
        }
        else if(treeitem->m_treedata.lock()->getRound() == GameTreeNode::GameRound::RIVER){
            if(!this->tableStrategyModel->getTrunCard().empty())
                cards.push_back(Card(this->tableStrategyModel->getTrunCard()));
            if(!this->tableStrategyModel->getRiverCard().empty())
                cards.push_back(Card(this->tableStrategyModel->getRiverCard()));
        }
    }
    this->ui->boardLabel->setText(QString("<b>%1: </b>").arg(tr("board")) + Card::boardCards2html(cards));
}
```