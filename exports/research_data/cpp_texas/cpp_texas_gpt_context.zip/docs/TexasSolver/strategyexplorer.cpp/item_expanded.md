`item_expanded`: The function of `item_expanded` is to handle the event when a tree item in the UI is expanded, ensuring that all child items are properly generated if they are not already.

**Parameters**:\
`const QModelIndex& index`: The index of the tree item that has been expanded in the UI.

**Code Description**: This method is triggered when a tree item in the UI is expanded. It first retrieves the `TreeItem` object associated with the given `index`. It then iterates through all child items of this `TreeItem`. For each child item, if the child item does not have any children of its own, the method calls `reGenerateTreeItem` to generate the necessary child items based on the current game round. This ensures that the tree structure is dynamically updated and populated as needed when items are expanded.\\
## Code: 
```
void StrategyExplorer::item_expanded(const QModelIndex& index){
    TreeItem *item = static_cast<TreeItem*>(index.internalPointer());
    int num_child = item->childCount();
    for (int i = 0;i < num_child;i ++){
        TreeItem* one_child = item->child(i);
        if(one_child->childCount() != 0)continue;
        this->ui->gameTreeView->tree_model->reGenerateTreeItem(one_child->m_treedata.lock()->getRound(),one_child);
    }
}
```