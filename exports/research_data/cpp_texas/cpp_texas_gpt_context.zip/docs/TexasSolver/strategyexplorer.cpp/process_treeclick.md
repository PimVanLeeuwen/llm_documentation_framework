`process_treeclick`: The function of `process_treeclick` is to update the UI label with the type of node that was clicked in the game tree.

**Parameters**:\
`TreeItem* treeitem`: A pointer to the `TreeItem` that was clicked, which contains data about the corresponding node in the game tree.

**Code Description**: The `process_treeclick` method is part of the `StrategyExplorer` class. It takes a `TreeItem` pointer as an argument, which represents the item clicked in the tree view. The method retrieves the associated `GameTreeNode` from the `TreeItem`. Depending on the type of the `GameTreeNode` (ACTION, CHANCE, TERMINAL, or SHOWDOWN), it updates the `nodeDisplayLabel` in the UI with a formatted string indicating the type of node. If the node is an ACTION node, it also specifies whether the player is IP (in position) or OOP (out of position).\\
## Code: 
```
void StrategyExplorer::process_treeclick(TreeItem* treeitem){
    shared_ptr<GameTreeNode> treenode = treeitem->m_treedata.lock();
    if(treenode->getType() == GameTreeNode::GameTreeNodeType::ACTION){
        shared_ptr<ActionNode> actionnode = static_pointer_cast<ActionNode>(treenode);
        QString action_str = QString("<b>%1 %2</b>").arg(actionnode->getPlayer() == 0?tr("IP"):tr("OOP"),tr(" decision node"));
        this->ui->nodeDisplayLabel->setText(action_str);
    }
    else if(treenode->getType() == GameTreeNode::GameTreeNodeType::CHANCE){
        QString chance_str = tr("<b>Chance node</b>");
        this->ui->nodeDisplayLabel->setText(chance_str);
    }
    else if(treenode->getType() == GameTreeNode::GameTreeNodeType::TERMINAL){
        QString terminal_str = tr("<b>Terminal node</b>");
        this->ui->nodeDisplayLabel->setText(terminal_str);
    }
    else if(treenode->getType() == GameTreeNode::GameTreeNodeType::SHOWDOWN){
        QString showdown_str = tr("<b>Showdown node</b>");
        this->ui->nodeDisplayLabel->setText(showdown_str);
    }
}
```