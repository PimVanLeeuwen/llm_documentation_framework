`on_riverCardBox_currentIndexChanged`: The function of `on_riverCardBox_currentIndexChanged` is to update the strategy model and UI elements when the selected river card changes in the river card dropdown box.
**Parameters**:\
`int index`: The index of the newly selected river card in the dropdown box.

**Code Description**: This method first checks if there are any cards available and if the provided index is within the valid range. If both conditions are met, it sets the river card in the `tableStrategyModel` to the card at the specified index and updates the strategy data. It then processes the board based on the updated strategy model. Finally, it updates the viewports of the strategy table and detail view to reflect the changes.\\
## Code: 
```
void StrategyExplorer::on_riverCardBox_currentIndexChanged(int index)
{
    if(this->cards.size() > 0  && index < this->cards.size()){
        this->tableStrategyModel->setRiverCard(this->cards[index]);
        this->tableStrategyModel->updateStrategyData();
        //this->roughStrategyViewerModel->onchanged();
        //this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```