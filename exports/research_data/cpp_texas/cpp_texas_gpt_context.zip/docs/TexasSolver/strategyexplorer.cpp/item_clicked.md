`item_clicked`: The function of `item_clicked` is to handle the event when an item in the strategy explorer tree is clicked, updating various UI components and models accordingly.

**Parameters**:\
`const QModelIndex& index`: The index of the clicked item in the tree view, which provides access to the underlying data through an internal pointer.

**Code Description**: The `item_clicked` method is triggered when a tree item in the strategy explorer is clicked. It performs the following actions:
1. Retrieves the `TreeItem` associated with the clicked index.
2. Calls `process_treeclick` to update the UI label with the type of the game tree node.
3. Calls `process_board` to update the UI with the current game board state.
4. Sets the clicked tree node in the `tableStrategyModel` using `setGameTreeNode`.
5. Updates the strategy data in the `tableStrategyModel` by calling `updateStrategyData`.
6. Refreshes the strategy table view UI component.
7. Notifies the `roughStrategyViewerModel` of changes by calling `onchanged`.
8. Triggers a resize event for the rough strategy view and updates its viewport.

If any runtime errors occur during these operations, they are caught and logged using `qDebug`.\\
## Code: 
```
void StrategyExplorer::item_clicked(const QModelIndex& index){
    try{
        TreeItem * treeNode = static_cast<TreeItem*>(index.internalPointer());
        this->process_treeclick(treeNode);
        this->process_board(treeNode);
        this->tableStrategyModel->setGameTreeNode(treeNode);
        this->tableStrategyModel->updateStrategyData();
        this->ui->strategyTableView->viewport()->update();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->triger_resize();
        this->ui->roughStrategyView->viewport()->update();
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```