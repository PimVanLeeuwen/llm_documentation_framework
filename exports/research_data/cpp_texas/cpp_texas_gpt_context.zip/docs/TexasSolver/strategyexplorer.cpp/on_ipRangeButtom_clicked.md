`on_ipRangeButtom_clicked`: The function of `on_ipRangeButtom_clicked` is to handle the event when the IP Range button is clicked.

**Code Description**: This method sets the mode of the `detailWindowSetting` to `RANGE_IP`, indicating that the detail window should display information related to IP ranges. It then updates the viewports of `strategyTableView`, `detailView`, and `roughStrategyView` to reflect any changes. Additionally, it calls the `onchanged` method of the `roughStrategyViewerModel` to signal that the header data has changed, ensuring that the displayed strategy information is refreshed.\\
## Code: 
```
void StrategyExplorer::on_ipRangeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::RANGE_IP;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```