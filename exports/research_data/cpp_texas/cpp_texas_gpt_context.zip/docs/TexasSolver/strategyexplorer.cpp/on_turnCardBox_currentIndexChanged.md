`on_turnCardBox_currentIndexChanged`: The function of `on_turnCardBox_currentIndexChanged` is to update the strategy model and UI elements based on the selected turn card index in the turn card box.
**Parameters**:\
`int index`: The index of the selected turn card in the turn card box.

**Code Description**: This method is triggered when the current index of the turn card box changes. It first checks if there are any cards available and if the provided index is within the valid range. If both conditions are met, it sets the turn card in the `tableStrategyModel` to the card at the specified index and updates the strategy data. It then processes the board using the `process_board` method. Finally, it updates the viewports of the `strategyTableView` and `detailView` UI elements to reflect the changes. Note that some lines of code are commented out due to causing bugs or crashes.\\
## Code: 
```
void StrategyExplorer::on_turnCardBox_currentIndexChanged(int index)
{
    if(this->cards.size() > 0 && index < this->cards.size()){
        this->tableStrategyModel->setTrunCard(this->cards[index]);
        this->tableStrategyModel->updateStrategyData();
        // TODO this somehow cause bugs, crashes, why?
        //this->roughStrategyViewerModel->onchanged();
        //this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```