`on_strategyModeButtom_clicked`: The function of `on_strategyModeButtom_clicked` is to switch the detail window to strategy mode and update the relevant UI components.

**Code Description**: The `on_strategyModeButtom_clicked` method sets the `mode` of `detailWindowSetting` to `DetailWindowMode::STRATEGY`. It then updates the viewports of `strategyTableView`, `detailView`, and `roughStrategyView` to reflect this change. Additionally, it calls the `onchanged` method of `roughStrategyViewerModel` to signal that the strategy data has been modified, ensuring that the UI components display the latest strategy information.\\
## Code: 
```
void StrategyExplorer::on_strategyModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::STRATEGY;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```