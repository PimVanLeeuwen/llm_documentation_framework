`on_evModeButtom_clicked`: The function of `on_evModeButtom_clicked` is to switch the detail window mode to EV (Expected Value) and refresh the display of several UI components.

**Code Description**: The `on_evModeButtom_clicked` method is part of the `StrategyExplorer` class. When this method is triggered, it sets the `mode` attribute of the `detailWindowSetting` object to `DetailWindowSetting::DetailWindowMode::EV`. This indicates that the detail window should now operate in EV mode. Following this, the method calls the `update` function on the `viewport` of three UI components: `strategyTableView`, `detailView`, and `roughStrategyView`. These calls ensure that the visual representation of these components is refreshed to reflect the change in mode.\\
## Code: 
```
void StrategyExplorer::on_evModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::EV;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->ui->roughStrategyView->viewport()->update();
}
```