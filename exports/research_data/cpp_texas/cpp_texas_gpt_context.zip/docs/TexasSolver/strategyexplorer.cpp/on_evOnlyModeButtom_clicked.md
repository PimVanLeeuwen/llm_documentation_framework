`on_evOnlyModeButtom_clicked`: The function of `on_evOnlyModeButtom_clicked` is to switch the detail window mode to "EV_ONLY" and update the relevant UI components to reflect this change.

**Code Description**: 
- The method sets the `mode` attribute of `detailWindowSetting` to `DetailWindowSetting::DetailWindowMode::EV_ONLY`.
- It then updates the viewports of `strategyTableView` and `detailView` to reflect the new mode.
- The `onchanged` method of `roughStrategyViewerModel` is called to signal that the strategy data has changed.
- Finally, the viewport of `roughStrategyView` is updated to display the latest strategy information.\\
## Code: 
```
void StrategyExplorer::on_evOnlyModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::EV_ONLY;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```