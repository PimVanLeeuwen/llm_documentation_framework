# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/Card.cpp` \
**Type:** `Method` \
**Method Name:** `boardCards2long` \
**Code Content:** \
`uint64_t Card::boardCards2long(vector<string> cards) {
    vector<Card> cards_objs(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_objs[i] = Card(cards[i]);
    }
    return Card::boardCards2long(cards_objs);
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/Card.cpp.boardCards2long 
 - Explanation:  _This method converts a vector of `Card` objects into a single 64-bit integer by first converting each `Card` to its corresponding integer value and then combining these integers. It utilizes the `card2int` and `boardInts2long` methods for these conversions._ 
### TexasSolver/TexasSolver/Card.cpp.Card 
 - Explanation:  _The `Card` constructor initializes a card object with a string representation of a card, converts it to an integer, and sets the card's position in the deck to -1. It uses the `strCard2int` method to perform the string-to-integer conversion._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`boardCards2long`: The function of `boardCards2long` is *FILL IN* 
**Parameters**:\
`vector<string> cards`: *FILL IN* \

**Code Description**: *FILL IN*
