# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/Card.cpp` \
**Type:** `Method` \
**Method Name:** `boardCard2long` \
**Code Content:** \
`uint64_t Card::boardCard2long(Card& card){
    return Card::boardInt2long(card.getCardInt());
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/Card.cpp.getCardInt 
 - Explanation:  _This method `getCardInt` returns the integer value of the card stored in the `card_int` member variable of the `Card` class. It is a simple accessor method used to retrieve the card's integer representation._ 
### TexasSolver/TexasSolver/Card.cpp.boardInt2long 
 - Explanation:  _The `boardInt2long` method converts a card index (0-51) into a 64-bit integer where only the bit at the position corresponding to the card index is set. If the card index is out of range, it throws a runtime error._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`boardCard2long`: The function of `boardCard2long` is *FILL IN* 
**Parameters**:\
`Card& card`: *FILL IN* \

**Code Description**: *FILL IN*
