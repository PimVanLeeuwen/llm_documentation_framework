# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/tablestrategymodel.cpp` \
**Type:** `Method` \
**Method Name:** `get_ev_grid` \
**Code Content:** \
`const vector<float> TableStrategyModel::get_ev_grid(int i,int j)const{
    vector<float> ret_evs;
    if(this->treeItem == NULL || this->current_evs.empty())return ret_evs;

    int strategy_number = this->ui_strategy_table[i][j].size();

    shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();

    if(node->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);

        vector<GameActions>& gameActions = actionNode->getActions();

//        vector<float> strategies;

//        if(this->ui_strategy_table[i][j].size() > 0){
//            strategies = vector<float>(gameActions.size());
//            std::fill(strategies.begin(), strategies.end(), 0.);
//        }
        for(std::pair<int,int> index:this->ui_strategy_table[i][j]){
            int index1 = index.first;
            int index2 = index.second;
            const vector<float>& one_strategy = this->current_strategy[index1][index2];
            const vector<float>& one_ev = this->current_evs[index1][index2];
            if(one_ev.size() != one_strategy.size()) return vector<float>();

            if(gameActions.size() != one_strategy.size()){
                cout << "index: " << index1 << " " << index2 << endl;
                cout << "i,j: " << i << " " << j << endl;
                cout << "size not match between gameAction and stragegy: " << gameActions.size() << " " << one_strategy.size() << endl;
                throw runtime_error("size not match between gameAction and stragegy");
            }
            float one_ev_float = 0;
            for(std::size_t indi = 0;indi < one_strategy.size();indi ++){
                one_ev_float += one_strategy[indi] * one_ev[indi];
            }
            ret_evs.push_back(one_ev_float);
        }

        return ret_evs;
    }else{
        return ret_evs;
    }
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/tablestrategymodel.cpp.index 
 - Explanation:  _This code defines a method `index` in the `TableStrategyModel` class, which returns a QModelIndex based on given row and column indices and a parent index. The method calls another method to check if the given index is valid before returning an index._ 
### TexasSolver/TexasSolver/src/ActionNode.cpp.ActionNode 
 - Explanation:  _This code defines a constructor for the `ActionNode` class, which initializes its member variables from input parameters. The constructor takes several inputs and assigns them to corresponding member variables in the object being constructed._ 
### TexasSolver/TexasSolver/src/ActionNode.cpp.getActions 
 - Explanation:  _This code retrieves a vector of game actions from an ActionNode object. The retrieved vector is a reference to the internal data member 'actions' of the same object._ 
### TexasSolver/TexasSolver/Card.cpp.empty 
 - Explanation:  _This code defines a method `empty` in the `Card` class that checks if a card is empty or not based on its value. The method returns true if the card is empty and false otherwise._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`get_ev_grid`: The function of `get_ev_grid` is *FILL IN* 
**Parameters**:\
`int i`: *FILL IN* \
`int j`: *FILL IN* \

**Code Description**: *FILL IN*
