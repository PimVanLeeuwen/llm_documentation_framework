# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/RiverRangeManager.cpp` \
**Type:** `Method` \
**Method Name:** `getRiverCombos` \
**Code Content:** \
`const vector<RiverCombs> &
RiverRangeManager::getRiverCombos(int player, const vector<PrivateCards> &preflopCombos, uint64_t board_long) {
    unordered_map<uint64_t , vector<RiverCombs>>* riverRanges;

    if (player == 0)
        riverRanges = &p1RiverRanges;
    else if (player == 1)
        riverRanges = &p2RiverRanges;
    else
        throw runtime_error(tfm::format("player %s not found",player));

    uint64_t key = board_long;

    this->maplock->lock();
    if (riverRanges->find(key) != riverRanges->end()) {
        const vector<RiverCombs> &retval = (*riverRanges)[key];
        this->maplock->unlock();
        return retval;
    }
    this->maplock->unlock();

    int count = 0;

    for (auto one_hand : preflopCombos) {
        if (!Card::boardsHasIntercept(
                one_hand.toBoardLong(), board_long
        ))
            count++;
    }

    int index = 0;
    vector<RiverCombs> riverCombos = vector<RiverCombs>(count);

    for (std::size_t hand = 0; hand < preflopCombos.size(); hand++)
    {
        PrivateCards preflopCombo = preflopCombos[hand];


        if (Card::boardsHasIntercept(
                preflopCombo.toBoardLong(), board_long
        )){
            continue;
        }

        int rank = this->handEvaluator->get_rank(preflopCombo.toBoardLong(),board_long);
        RiverCombs riverCombo = RiverCombs(Card::long2board(board_long),preflopCombo,rank, hand);
        riverCombos[index++] = riverCombo;
    }

    std::sort(riverCombos.begin(),riverCombos.end(),[ ]( const RiverCombs& lhs, const RiverCombs& rhs )
    {
        return lhs.rank > rhs.rank;
    });

    this->maplock->lock();
    (*riverRanges)[key] =  std::move(riverCombos);
    this->maplock->unlock();

    return (*riverRanges)[key];
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/Dic5Compairer.cpp.get_rank 
### TexasSolver/TexasSolver/Card.cpp.long2board 
 - Explanation:  _The `long2board` method converts a 64-bit integer representation of a card board into a vector of card indices. It iterates through each bit of the integer, adding the index to the vector if the bit is set to 1, and ensures the resulting vector has between 1 and 7 elements._ 
### TexasSolver/TexasSolver/src/PrivateCards.cpp.toBoardLong 
 - Explanation:  _This method returns the value of the `board_long` member variable of the `PrivateCards` class. The commented-out line suggests an alternative way to compute this value using a function `boardInts2long` from the `Card` class._ 
### TexasSolver/TexasSolver/src/RiverCombs.cpp.RiverCombs 
 - Explanation:  _This code defines a constructor for the `RiverCombs` class that initializes its member variables with the provided parameters: `board`, `private_cards`, `rank`, and `reach_prob_index`. The constructor assigns these parameters to the class's corresponding member variables._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`getRiverCombos`: The function of `getRiverCombos` is *FILL IN* 
**Parameters**:\
`int player`: *FILL IN* \
`const vector<PrivateCards> &preflopCombos`: *FILL IN* \
`uint64_t board_long`: *FILL IN* \

**Code Description**: *FILL IN*
