# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/tablestrategymodel.cpp` \
**Type:** `Method` \
**Method Name:** `get_strategy` \
**Code Content:** \
`const vector<pair<GameActions,float>> TableStrategyModel::get_strategy(int i,int j) const{
    vector<pair<GameActions,float>> ret_strategy;
    if(this->treeItem == NULL) return ret_strategy;

    int strategy_number = this->ui_strategy_table[i][j].size();

    shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();

    if(node->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);

        vector<GameActions>& gameActions = actionNode->getActions();

        vector<float> strategies;

        // get range data - initally copied from paint_range - could probably be integrated in loops below for efficiancy
        vector<pair<int,int>> card_cords;
        const vector<vector<float>> *current_range;
        card_cords = ui_strategy_table[i][j];
        current_range = (0 == current_player ) ? & p1_range : & p2_range;

        if(p1_range.empty() || p2_range.empty()){
            return ret_strategy;
        }

        float range_number = 0;
        if(!card_cords.empty()){
            for(std::size_t indi = 0;indi < card_cords.size();indi ++){
                    range_number += (*current_range)[card_cords[indi].first][card_cords[indi].second];
            }
            range_number = range_number / card_cords.size();

            if(range_number < 0 || range_number > 1) throw runtime_error("range number incorrect in strategyitemdeletage");
        }
        else
            return ret_strategy;
        // got range data

        if(this->ui_strategy_table[i][j].size() > 0){
            strategies = vector<float>(gameActions.size());
            std::fill(strategies.begin(), strategies.end(), 0.);
        }
        for(std::pair<int,int> index:this->ui_strategy_table[i][j]){
            int index1 = index.first;
            int index2 = index.second;
            const vector<float>& one_strategy = this->current_strategy[index1][index2];
            if(gameActions.size() != one_strategy.size()){
                cout << "index: " << index1 << " " << index2 << endl;
                cout << "i,j: " << i << " " << j << endl;
                cout << "size not match between gameAction and stragegy: " << gameActions.size() << " " << one_strategy.size() << endl;
                throw runtime_error("size not match between gameAction and stragegy");
            }

            if ( range_number > 0)
                for(std::size_t indi = 0;indi < one_strategy.size();indi ++){
                    strategies[indi] += (one_strategy[indi] * (*current_range)[index1][index2] / range_number / strategy_number);
                }
        }

        for(std::size_t indi = 0;indi < strategies.size();indi ++){
            ret_strategy.push_back(std::pair<GameActions,float>(actionNode->getActions()[indi],
                                                                strategies[indi]));
        }

        return ret_strategy;
    }else{
        return ret_strategy;
    }

}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/tablestrategymodel.cpp.index 
 - Explanation:  _This code defines a method `index` in the `TableStrategyModel` class, which returns a QModelIndex based on given row and column indices and a parent index. The method calls another method to check if the given index is valid before returning an index._ 
### TexasSolver/TexasSolver/src/ActionNode.cpp.ActionNode 
 - Explanation:  _This code defines a constructor for the `ActionNode` class, which initializes its member variables from input parameters. The constructor takes several inputs and assigns them to corresponding member variables in the object being constructed._ 
### TexasSolver/TexasSolver/src/ActionNode.cpp.getActions 
 - Explanation:  _This code retrieves a vector of game actions from an ActionNode object. The retrieved vector is a reference to the internal data member 'actions' of the same object._ 
### TexasSolver/TexasSolver/Card.cpp.empty 
 - Explanation:  _This code defines a method `empty` in the `Card` class that checks if a card is empty or not based on its value. The method returns true if the card is empty and false otherwise._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`get_strategy`: The function of `get_strategy` is *FILL IN* 
**Parameters**:\
`int i`: *FILL IN* \
`int j`: *FILL IN* \

**Code Description**: *FILL IN*
