# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/PrivateCardsManager.cpp` \
**Type:** `Method` \
**Method Name:** `getInitialReachProb` \
**Code Content:** \
`vector<float> PrivateCardsManager::getInitialReachProb(int player, uint64_t initialboard) {
    int cards_len =  this->private_cards[player].size();
    vector<float> probs = vector<float>(cards_len);
    for(int i = 0;i < cards_len;i ++){
        PrivateCards pc = this->private_cards[player][i];
        if(Card::boardsHasIntercept(initialboard,Card::boardInts2long(pc.get_hands()))) {
            probs[i] = 0;
        }else{
            probs[i] = this->private_cards[player][i].weight;
        }
    }
    return probs;
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/Card.cpp.boardInts2long 
 - Explanation:  _This method converts a vector of integers representing card IDs into a single 64-bit integer, where each bit corresponds to a card's presence. It validates the input to ensure the card IDs are within the valid range (0-51) and the vector size is between 1 and 7._ 
### TexasSolver/TexasSolver/src/PrivateCards.cpp.get_hands 
 - Explanation:  _This method `get_hands` returns a constant reference to the `card_vec` member variable of the `PrivateCards` class. It allows access to the vector of integers representing private cards without modifying the original vector._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`getInitialReachProb`: The function of `getInitialReachProb` is *FILL IN* 
**Parameters**:\
`int player`: *FILL IN* \
`uint64_t initialboard`: *FILL IN* \

**Code Description**: *FILL IN*
