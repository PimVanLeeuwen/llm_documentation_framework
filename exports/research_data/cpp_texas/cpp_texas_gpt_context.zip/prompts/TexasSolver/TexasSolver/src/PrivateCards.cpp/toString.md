# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/PrivateCards.cpp` \
**Type:** `Method` \
**Method Name:** `toString` \
**Code Content:** \
`string PrivateCards::toString() {
    if (card1 > card2) {
        return Card::intCard2Str(card1) + Card::intCard2Str(card2);
    }else{
        return Card::intCard2Str(card2) + Card::intCard2Str(card1);
    }
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/Card.cpp.intCard2Str 
 - Explanation:  _The `intCard2Str` method converts an integer representation of a card into its string representation by determining the card's rank and suit. It uses the `rankToString` and `suitToString` methods to get the respective string values for the rank and suit._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`toString`: The function of `toString` is *FILL IN* 

**Code Description**: *FILL IN*
