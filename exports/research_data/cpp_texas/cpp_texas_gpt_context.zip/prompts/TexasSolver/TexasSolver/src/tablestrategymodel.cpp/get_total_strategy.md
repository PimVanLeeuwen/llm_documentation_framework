# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/tablestrategymodel.cpp` \
**Type:** `Method` \
**Method Name:** `get_total_strategy` \
**Code Content:** \
`const vector<pair<GameActions,pair<float,float>>> TableStrategyModel::get_total_strategy() const{
    vector<pair<GameActions,pair<float,float>>> ret_strategy;
    if(this->treeItem == NULL)return ret_strategy;


    shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();

    if(node->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);
        vector<GameActions>& gameActions = actionNode->getActions();
        int current_player = actionNode->getPlayer();

        vector<float> combos(gameActions.size(),0.0);
        vector<float> avg_strategy(gameActions.size(),0.0);
        float sum_strategy = 0;

        for(std::size_t index1 = 0;index1 < this->current_strategy.size() ;index1 ++){
            for(std::size_t index2 = 0;index2 < this->current_strategy.size() ;index2 ++){
                const vector<float>& one_strategy = this->current_strategy[index1][index2];
                if(one_strategy.empty())continue;

                const vector<vector<float>>& range = current_player == 0? this->p1_range:this->p2_range;
                if(range.size() <= index1 || range[index1].size() < index2) throw runtime_error(" index error when get range in tablestrategymodel");
                const float one_range = range[index1][index2];

                for(std::size_t i = 0;i < one_strategy.size(); i ++ ){
                    float one_prob = one_strategy[i];
                    combos[i] += one_prob * one_range;
                    avg_strategy[i] += one_prob * one_range;
                    sum_strategy += one_prob * one_range;
                }

                if(gameActions.size() != one_strategy.size()){
                    cout << "index: " << index1 << " " << index2 << endl;
                    cout << "size not match between gameAction and stragegy: " << gameActions.size() << " " << one_strategy.size() << endl;
                    throw runtime_error("size not match between gameAction and stragegy");
                }
            }
        }

        for(std::size_t i = 0;i < gameActions.size(); i ++ ){
            avg_strategy[i] = avg_strategy[i] / sum_strategy;
            pair<float,float> statics = pair<float,float>(combos[i],avg_strategy[i]);
            pair<GameActions,pair<float,float>> one_ret = pair<GameActions,pair<float,float>>(gameActions[i],statics);
            ret_strategy.push_back(one_ret);
        }
        return ret_strategy;
    }else{
        return ret_strategy;
    }


}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/ActionNode.cpp.ActionNode 
 - Explanation:  _This code defines a constructor for the `ActionNode` class, which initializes its member variables from input parameters. The constructor takes several inputs and assigns them to corresponding member variables in the object being constructed._ 
### TexasSolver/TexasSolver/src/ActionNode.cpp.getActions 
 - Explanation:  _This code retrieves a vector of game actions from an ActionNode object. The retrieved vector is a reference to the internal data member 'actions' of the same object._ 
### TexasSolver/TexasSolver/Card.cpp.empty 
 - Explanation:  _This code defines a method `empty` in the `Card` class that checks if a card is empty or not based on its value. The method returns true if the card is empty and false otherwise._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`get_total_strategy`: The function of `get_total_strategy` is *FILL IN* 

**Code Description**: *FILL IN*
