# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/PokerSolver.cpp` \
**Type:** `Method` \
**Method Name:** `estimate_tree_memory` \
**Code Content:** \
`long long PokerSolver::estimate_tree_memory(QString range1,QString range2,QString board){
    if(this->game_tree == nullptr){
        qDebug().noquote() << QObject::tr("Please buld tree first.");
        return 0;
    }
    else{
        string player1RangeStr = range1.toStdString();
        string player2RangeStr = range2.toStdString();

        vector<string> board_str_arr = string_split(board.toStdString(),',');
        vector<int> initialBoard;
        for(string one_board_str:board_str_arr){
            initialBoard.push_back(Card::strCard2int(one_board_str));
        }

        vector<PrivateCards> range1 = PrivateRangeConverter::rangeStr2Cards(player1RangeStr,initialBoard);
        vector<PrivateCards> range2 = PrivateRangeConverter::rangeStr2Cards(player2RangeStr,initialBoard);
        return this->game_tree->estimate_tree_memory(this->deck.getCards().size() - initialBoard.size(),range1.size(),range2.size());
    }
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/library.cpp.string_split 
 - Explanation:  _This method splits a given string `strin` into substrings based on a delimiter character `split` and returns a vector of these substrings. It uses a stringstream to tokenize the input string and stores each token in the result vector._ 
### TexasSolver/TexasSolver/Card.cpp.strCard2int 
 - Explanation:  _The `strCard2int` method converts a two-character string representation of a card into an integer value based on its rank and suit. It throws a runtime error if the input string does not have exactly two characters._ 
### TexasSolver/TexasSolver/src/PokerSolver.cpp.estimate_tree_memory 
### TexasSolver/TexasSolver/src/PrivateRangeConverter.cpp.rangeStr2Cards 
 - Explanation:  _The `rangeStr2Cards` method converts a string representation of a range of private poker hands into a vector of `PrivateCards` objects, considering the initial board cards and handling different formats and weights. It ensures no duplicate hands are included and validates the input format and card combinations._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`estimate_tree_memory`: The function of `estimate_tree_memory` is *FILL IN* 
**Parameters**:\
`QString range1`: *FILL IN* \
`QString range2`: *FILL IN* \
`QString board`: *FILL IN* \

**Code Description**: *FILL IN*
