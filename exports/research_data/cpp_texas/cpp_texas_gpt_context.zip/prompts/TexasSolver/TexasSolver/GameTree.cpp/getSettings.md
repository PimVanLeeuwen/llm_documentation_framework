# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/GameTree.cpp` \
**Type:** `Method` \
**Method Name:** `getSettings` \
**Code Content:** \
`StreetSetting GameTree::getSettings(int int_round, int player,GameTreeBuildingSettings& gameTreeBuildingSettings){
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(int_round);
    if(!(player == 0 || player == 1)) throw runtime_error(tfm::format("player %s not known",player));
    if(round == GameTreeNode::GameRound::RIVER && player == 0) return gameTreeBuildingSettings.river_ip;
    else if(round == GameTreeNode::GameRound::TURN && player == 0) return gameTreeBuildingSettings.turn_ip;
    else if(round == GameTreeNode::GameRound::FLOP && player == 0) return gameTreeBuildingSettings.flop_ip;
    else if(round == GameTreeNode::GameRound::RIVER && player == 1) return gameTreeBuildingSettings.river_oop;
    else if(round == GameTreeNode::GameRound::TURN && player == 1) return gameTreeBuildingSettings.turn_oop;
    else if(round == GameTreeNode::GameRound::FLOP && player == 1) return gameTreeBuildingSettings.flop_oop;
    else throw new runtime_error(tfm::format("player %s and round not known",player));
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.intToGameRound 
 - Explanation:  _The `intToGameRound` method converts an integer representing a game round into its corresponding `GameRound` enum value. If the integer does not match any valid game round, it throws a runtime error._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`getSettings`: The function of `getSettings` is *FILL IN* 
**Parameters**:\
`int int_round`: *FILL IN* \
`int player`: *FILL IN* \
`GameTreeBuildingSettings& gameTreeBuildingSettings`: *FILL IN* \

**Code Description**: *FILL IN*
