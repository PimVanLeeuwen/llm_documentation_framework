# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/GameTree.cpp` \
**Type:** `Method` \
**Method Name:** `re_estimate_tree_memory` \
**Code Content:** \
`long long GameTree::re_estimate_tree_memory(const shared_ptr<GameTreeNode>& node,int deck_num,int p1range_num,int p2range_num,int num_current_deal){
    if(node->getType() == GameTreeNode::ACTION){
        shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
        vector<shared_ptr<GameTreeNode>> childrens = action_node->getChildrens();
        vector<GameActions> actions = action_node->getActions();

        long long retnum = 0;
        for(std::size_t i = 0;i < childrens.size();i++){
            shared_ptr<GameTreeNode> one_child = childrens[i];
            retnum += re_estimate_tree_memory(one_child,deck_num, p1range_num, p2range_num, num_current_deal);
        }
        if(action_node->getPlayer() == 0){
            retnum += num_current_deal * p1range_num * (childrens.size() + 1) * 3;
        }else{
            retnum += num_current_deal * p2range_num * (childrens.size() + 1) * 3;
        }
        return retnum;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
        shared_ptr<GameTreeNode> children = chance_node->getChildren();
        return re_estimate_tree_memory(children,deck_num, p1range_num, p2range_num, num_current_deal * (deck_num));
    }
    return 0;
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/ActionNode.cpp.ActionNode 
 - Explanation:  _The `ActionNode` constructor initializes an `ActionNode` object with specified game actions, child nodes, player, game round, pot, and parent node, inheriting from `GameTreeNode`. It assigns the provided values to the respective member variables and moves the ownership of the vectors._ 
### TexasSolver/TexasSolver/src/ActionNode.cpp.getChildrens 
 - Explanation:  _This method `getChildrens` returns a reference to a vector of shared pointers to `GameTreeNode` objects. It allows access to the child nodes of an `ActionNode` instance._ 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.ChanceNode 
 - Explanation:  _The `ChanceNode` constructor initializes a `ChanceNode` object with specified game round, pot, parent node, cards, and donk status, and sets its children. It inherits from the `GameTreeNode` class and uses member initializer lists for initialization._ 
### TexasSolver/TexasSolver/src/ActionNode.cpp.getActions 
 - Explanation:  _This method `getActions` returns a reference to the `actions` vector member of the `ActionNode` class. It allows access to the list of game actions stored in the `ActionNode` object._ 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.getChildren 
 - Explanation:  _This method `getChildren` returns the `children` member of the `ChanceNode` object. It returns a `shared_ptr` to a `GameTreeNode`._ 
### TexasSolver/TexasSolver/GameTree.cpp.re_estimate_tree_memory 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`re_estimate_tree_memory`: The function of `re_estimate_tree_memory` is *FILL IN* 
**Parameters**:\
`const shared_ptr<GameTreeNode>& node`: *FILL IN* \
`int deck_num`: *FILL IN* \
`int p1range_num`: *FILL IN* \
`int p2range_num`: *FILL IN* \
`int num_current_deal`: *FILL IN* \

**Code Description**: *FILL IN*
