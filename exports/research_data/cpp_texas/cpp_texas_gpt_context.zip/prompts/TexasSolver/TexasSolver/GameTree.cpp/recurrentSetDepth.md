# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/GameTree.cpp` \
**Type:** `Method` \
**Method Name:** `recurrentSetDepth` \
**Code Content:** \
`int GameTree::recurrentSetDepth(shared_ptr<GameTreeNode> node, int depth) {
    node->depth = depth;
    if(node->getType() == GameTreeNode::ACTION) {
        shared_ptr<ActionNode> actionNode = std::dynamic_pointer_cast<ActionNode>(node);
        int subtree_size = 1;
        for(shared_ptr<GameTreeNode> one_child:actionNode->getChildrens()){
            subtree_size += this->recurrentSetDepth(one_child,depth + 1);
        }
        node->subtree_size = subtree_size;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chanceNode = std::dynamic_pointer_cast<ChanceNode>(node);
        int subtree_size = 1;
        subtree_size += this->recurrentSetDepth(chanceNode->getChildren(),depth + 1) * chanceNode->getCards().size();
        node->subtree_size = subtree_size;
    }else{
        node->subtree_size = 1;
    }
    return node->subtree_size;
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/ActionNode.cpp.ActionNode 
 - Explanation:  _The `ActionNode` constructor initializes an `ActionNode` object with specified game actions, child nodes, player, game round, pot, and parent node, inheriting from `GameTreeNode`. It assigns the provided values to the respective member variables and moves the ownership of the vectors._ 
### TexasSolver/TexasSolver/GameTree.cpp.recurrentSetDepth 
### TexasSolver/TexasSolver/src/ActionNode.cpp.getChildrens 
 - Explanation:  _This method `getChildrens` returns a reference to a vector of shared pointers to `GameTreeNode` objects. It allows access to the child nodes of an `ActionNode` instance._ 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.ChanceNode 
 - Explanation:  _The `ChanceNode` constructor initializes a `ChanceNode` object with specified game round, pot, parent node, cards, and donk status, and sets its children. It inherits from the `GameTreeNode` class and uses member initializer lists for initialization._ 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.getChildren 
 - Explanation:  _This method `getChildren` returns the `children` member of the `ChanceNode` object. It returns a `shared_ptr` to a `GameTreeNode`._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`recurrentSetDepth`: The function of `recurrentSetDepth` is *FILL IN* 
**Parameters**:\
`shared_ptr<GameTreeNode> node`: *FILL IN* \
`int depth`: *FILL IN* \

**Code Description**: *FILL IN*
