# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/GameTree.cpp` \
**Type:** `Method` \
**Method Name:** `buildChance` \
**Code Content:** \
`void GameTree::buildChance(shared_ptr<ChanceNode> root,Rule rule){
    //节点上的下注额度
    double pot = (double)rule.get_pot();
    Rule nextrule = Rule(rule);
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));

    shared_ptr<GameTreeNode> one_node;
    if(rule.oop_commit == rule.ip_commit && rule.oop_commit == rule.stack) {
        if(rule.current_round >= 3){ // 3 is river
            double p1_commit = rule.ip_commit;
            double p2_commit = rule.oop_commit;
            double peace_getback = (p1_commit + p2_commit) / 2;


            vector<vector<double>> payoffs(2);
            payoffs[0] = {p2_commit, -p2_commit};
            payoffs[1] = {-p1_commit, p1_commit};
            vector<double> peace_getback_vec = {peace_getback - p1_commit, peace_getback - p2_commit};
            one_node = make_shared<ShowdownNode>(peace_getback_vec, payoffs, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
        }else {
            nextrule.current_round += 1;
            if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
            one_node = make_shared<ChanceNode>(nullptr, GameTreeNode::intToGameRound(rule.current_round + 1), (double) rule.get_pot(), root, this->deck.getCards());
        }
    }else {
        one_node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(), 1, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
    }
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
    this->__build(one_node,nextrule,"begin",0,0);
    root->setChildren(one_node);
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/ActionNode.cpp.ActionNode 
 - Explanation:  _The `ActionNode` constructor initializes an `ActionNode` object with specified game actions, child nodes, player, game round, pot, and parent node, inheriting from `GameTreeNode`. It assigns the provided values to the respective member variables and moves the ownership of the vectors._ 
### TexasSolver/TexasSolver/GameTree.cpp.__build 
 - Explanation:  _The `__build` method constructs different types of game tree nodes (`ActionNode`, `ChanceNode`, etc.) based on the node type, using the appropriate build methods. It throws a runtime error if the node type is unknown._ 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.setChildren 
 - Explanation:  _Sets the `children` member variable of the `ChanceNode` object to the provided `shared_ptr<GameTreeNode>` value. This method updates the child node reference for the current `ChanceNode`._ 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.ChanceNode 
 - Explanation:  _The `ChanceNode` constructor initializes a `ChanceNode` object with specified game round, pot, parent node, cards, and donk status, and sets its children. It inherits from the `GameTreeNode` class and uses member initializer lists for initialization._ 
### TexasSolver/TexasSolver/src/ShowdownNode.cpp.ShowdownNode 
 - Explanation:  _The `ShowdownNode` constructor initializes a `ShowdownNode` object with tie payoffs, player payoffs, game round, pot, and parent node. It inherits from the `GameTreeNode` class and moves the provided vectors into the object's attributes._ 
### TexasSolver/TexasSolver/src/Rule.cpp.get_pot 
 - Explanation:  _This method `get_pot` returns the sum of the `oop_commit` and `ip_commit` attributes of the `Rule` object. It calculates the total pot value in a poker game scenario._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.intToGameRound 
 - Explanation:  _The `intToGameRound` method converts an integer representing a game round into its corresponding `GameRound` enum value. If the integer does not match any valid game round, it throws a runtime error._ 
### TexasSolver/TexasSolver/src/Rule.cpp.Rule 
 - Explanation:  _This code defines a constructor for the `Rule` class, initializing various game parameters and ensuring that the out-of-position and in-position commitments are equal. If the commitments are not equal, it throws a runtime error._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`buildChance`: The function of `buildChance` is *FILL IN* 
**Parameters**:\
`shared_ptr<ChanceNode> root`: *FILL IN* \
`Rule rule`: *FILL IN* \

**Code Description**: *FILL IN*
