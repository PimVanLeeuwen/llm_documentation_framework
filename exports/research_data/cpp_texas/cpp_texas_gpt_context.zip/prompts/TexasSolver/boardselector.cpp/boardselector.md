# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/boardselector.cpp` \
**Type:** `Method` \
**Method Name:** `boardselector` \
**Code Content:** \
`boardselector::boardselector(QTextEdit* boardEdit,QSolverJob::Mode mode,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::boardselector)
{
    ui->setupUi(this);
    this->setWindowTitle(tr("BoardSelector"));
    this->boardEdit = boardEdit;
    this->mode = mode;

    QString ranks;
    if(mode == QSolverJob::Mode::HOLDEM){
        ranks = "A,K,Q,J,T,9,8,7,6,5,4,3,2";
    }else if(mode == QSolverJob::Mode::SHORTDECK){
        ranks = "A,K,Q,J,T,9,8,7,6";
    }else{
        throw runtime_error("mode not found in range selector");
    }
    this->rank_list = ranks.split(",");

    this->boardSelectorTableModel = new BoardSelectorTableModel(this->rank_list,boardEdit->toPlainText(),this);
    this->ui->boardSelectorTable->setModel(boardSelectorTableModel);
    this->boardSelectorTableDelegate = new BoardSelectorTableDelegate(this->rank_list,this->boardSelectorTableModel,this);
    this->ui->boardSelectorTable->setItemDelegate(this->boardSelectorTableDelegate);
    this->ui->boardEdit->setText(boardEdit->toPlainText());
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/CommandLineTool.cpp.split 
 - Explanation:  _This method splits a given string `s` into substrings based on a delimiter character `c` and stores the substrings in the vector `v`. It iterates through the string, finding each occurrence of the delimiter and extracting the substrings between them._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`boardselector`: The function of `boardselector` is *FILL IN* 
**Parameters**:\
`QTextEdit* boardEdit`: *FILL IN* \
`QSolverJob::Mode mode`: *FILL IN* \
`QWidget *parent`: *FILL IN* \

**Code Description**: *FILL IN*
