`update_second`: The function of `update_second` is to update the strategy data, notify the strategy viewer model of changes, and update the corresponding UI elements.

**Code Description**: The `update_second` function is part of the `StrategyExplorer` class. It performs the following actions:

1. Checks if the `cards` collection has any elements. If there are cards, it proceeds with the following steps.
2. Calls the `updateStrategyData` method of the `tableStrategyModel` object to update the strategy data.
3. Calls the `onchanged` method of the `roughStrategyViewerModel` object to notify it of changes.
4. Updates the viewport of the `roughStrategyView` UI element.
5. Calls the `process_board` method of the `StrategyExplorer` class, passing the `treeItem` from the `tableStrategyModel` object.
6. Updates the viewports of the `strategyTableView` and `detailView` UI elements.

The purpose of this function is to ensure that the strategy data, the strategy viewer model, and the corresponding UI elements are updated in response to changes in the `cards` collection. This is likely part of a larger system that deals with strategy exploration and visualization.\\
## Code: 
```
void StrategyExplorer::update_second(){
    if(this->cards.size() > 0){
        this->tableStrategyModel->updateStrategyData();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```