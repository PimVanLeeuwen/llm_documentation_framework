`on_strategyModeButtom_clicked`: The function of `on_strategyModeButtom_clicked` is to update the user interface and trigger related model changes when the "Strategy" mode button is clicked.

**Code Description**: The `on_strategyModeButtom_clicked` function is responsible for handling the user's interaction with the "Strategy" mode button in the application. When the button is clicked, the function performs the following actions:

1. It sets the `mode` property of the `detailWindowSetting` object to `DetailWindowSetting::DetailWindowMode::STRATEGY`, indicating that the application should switch to the "Strategy" mode.

2. It updates the viewport of the `strategyTableView` and `detailView` widgets, which are likely used to display strategy-related information.

3. It calls the `onchanged()` method of the `roughStrategyViewerModel` object, which suggests that this model is responsible for managing the data and behavior related to the "Strategy" mode.

4. It updates the viewport of the `roughStrategyView` widget, which is likely used to display the "Strategy" view.

These actions ensure that the user interface is properly updated to reflect the "Strategy" mode, and that the underlying models and data are also updated accordingly. This allows the user to interact with the application's "Strategy" functionality effectively.\\
## Code: 
```
void StrategyExplorer::on_strategyModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::STRATEGY;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```