`on_turnCardBox_currentIndexChanged`: The function of `on_turnCardBox_currentIndexChanged` is to update the strategy data and process the board when the current index of the `turnCardBox` changes.

**Code Description**: The `on_turnCardBox_currentIndexChanged` function is triggered when the current index of the `turnCardBox` changes. It performs the following actions:

1. Checks if the `cards` vector has at least one element and the new index is within the bounds of the `cards` vector.
2. If the conditions in step 1 are met, it sets the `trunCard` property of the `tableStrategyModel` to the card at the new index in the `cards` vector.
3. It then calls the `updateStrategyData()` method of the `tableStrategyModel` to update the strategy data.
4. It calls the `process_board()` method of the current object, passing the `treeItem` property of the `tableStrategyModel` as an argument.
5. It updates the viewport of the `strategyTableView` and `detailView` widgets to reflect the changes.

The commented-out code at the end of the function suggests that there were attempts to call the `onchanged()` method of the `roughStrategyViewerModel` and update the viewport of the `roughStrategyView` widget. However, these lines are commented out, likely due to some issues or bugs that were encountered.\\
## Code: 
```
void StrategyExplorer::on_turnCardBox_currentIndexChanged(int index)
{
    if(this->cards.size() > 0 && index < this->cards.size()){
        this->tableStrategyModel->setTrunCard(this->cards[index]);
        this->tableStrategyModel->updateStrategyData();
        // TODO this somehow cause bugs, crashes, why?
        //this->roughStrategyViewerModel->onchanged();
        //this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```