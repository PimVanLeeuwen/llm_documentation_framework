`on_ipRangeButtom_clicked`: The function of `on_ipRangeButtom_clicked` is to update the user interface and trigger related model changes when the IP range button is clicked.

**Code Description**: The `on_ipRangeButtom_clicked` function is part of the `StrategyExplorer` class. When the IP range button is clicked, this function performs the following actions:

1. Sets the `mode` property of the `detailWindowSetting` object to `DetailWindowSetting::DetailWindowMode::RANGE_IP`, indicating that the detail view should display the IP range.

2. Updates the viewport of the `strategyTableView` and `detailView` widgets, which are likely used to display strategy-related information.

3. Calls the `onchanged` method of the `roughStrategyViewerModel` object, which suggests that this model is responsible for managing the display of strategy-related data.

4. Updates the viewport of the `roughStrategyView` widget, which is likely used to display the strategy information.

These actions collectively update the user interface to reflect the change in the selected mode (IP range) and trigger any necessary updates to the underlying data models. This allows the user to view and interact with the strategy information in the IP range mode.\\
## Code: 
```
void StrategyExplorer::on_ipRangeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::RANGE_IP;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```