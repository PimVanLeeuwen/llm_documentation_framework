`on_oopRangeButtom_clicked`: The function of `on_oopRangeButtom_clicked` is to update the user interface and trigger a change in the strategy viewer model when the "OOP Range" button is clicked.

**Code Description**: The `on_oopRangeButtom_clicked` function is part of the `StrategyExplorer` class. When the "OOP Range" button is clicked, this function performs the following actions:

1. It sets the `mode` property of the `detailWindowSetting` object to `DetailWindowSetting::DetailWindowMode::RANGE_OOP`, which indicates that the detail view should display the "OOP Range" mode.

2. It updates the viewport of the `strategyTableView` and `detailView` widgets, which are likely used to display strategy-related information.

3. It calls the `onchanged()` method of the `roughStrategyViewerModel` object, which suggests that this function is responsible for updating the model that powers the "Rough Strategy View" in the user interface.

4. Finally, it updates the viewport of the `roughStrategyView` widget, which is likely used to display the "Rough Strategy View" in the user interface.

The purpose of this function is to update the user interface and the underlying data models when the "OOP Range" button is clicked, ensuring that the appropriate information is displayed to the user.\\
## Code: 
```
void StrategyExplorer::on_oopRangeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::RANGE_OOP;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```