`onMouseMoveEvent`: The function of `onMouseMoveEvent` is to update the grid coordinates and trigger a viewport update for the detail view and strategy table view.

**Code Description**: The `onMouseMoveEvent` function is part of the `StrategyExplorer` class. It is called when a mouse move event occurs. The function performs the following tasks:

1. It updates the `grid_i` and `grid_j` properties of the `detailWindowSetting` object with the new mouse coordinates `i` and `j`.
2. It triggers a viewport update for the `detailView` and `strategyTableView` widgets by calling the `update()` method on their respective viewports.

The purpose of this function is to ensure that the detail view and strategy table view are updated to reflect the new mouse position within the grid. This is likely part of a larger application that displays strategy-related information, and the `onMouseMoveEvent` function is responsible for updating the UI to provide more detailed information about the grid cell the user is currently hovering over.\\
## Code: 
```
void StrategyExplorer::onMouseMoveEvent(int i,int j){
    this->detailWindowSetting.grid_i = i;
    this->detailWindowSetting.grid_j = j;
    this->ui->detailView->viewport()->update();
    this->ui->strategyTableView->viewport()->update();
}
```