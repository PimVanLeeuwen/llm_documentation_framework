`item_expanded`: The function of `item_expanded` is to expand the children of a selected item in a tree view.

**Code Description**: The `item_expanded` function is part of the `StrategyExplorer` class and is called when an item in the tree view is expanded. The function takes a `QModelIndex` object as an argument, which represents the index of the expanded item in the tree model.

The function first casts the `QModelIndex` object to a `TreeItem` pointer, which represents the expanded item. It then retrieves the number of child items the expanded item has using the `childCount()` method.

The function then iterates through each child item of the expanded item. For each child item, it checks if the child item has any children of its own. If the child item has no children, the function calls the `reGenerateTreeItem()` method of the tree model, passing in the round data of the child item and the child item itself as arguments.

The purpose of the `reGenerateTreeItem()` method is likely to generate new tree items for the child item, which may represent additional data or information related to the child item. This ensures that the tree view is updated with the latest information when an item is expanded.

Overall, the `item_expanded` function is responsible for ensuring that the tree view is properly updated when an item is expanded, by generating new tree items for any child items that do not have any children of their own.\\
## Code: 
```
void StrategyExplorer::item_expanded(const QModelIndex& index){
    TreeItem *item = static_cast<TreeItem*>(index.internalPointer());
    int num_child = item->childCount();
    for (int i = 0;i < num_child;i ++){
        TreeItem* one_child = item->child(i);
        if(one_child->childCount() != 0)continue;
        this->ui->gameTreeView->tree_model->reGenerateTreeItem(one_child->m_treedata.lock()->getRound(),one_child);
    }
}
```