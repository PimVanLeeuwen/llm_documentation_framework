`on_evOnlyModeButtom_clicked`: The function of `on_evOnlyModeButtom_clicked` is to update the detail window setting to the "EV_ONLY" mode and refresh the relevant UI elements.

**Code Description**: The `on_evOnlyModeButtom_clicked` function is part of the `StrategyExplorer` class. When the "EV Only" button is clicked, this function is called to perform the following actions:

1. It sets the `mode` property of the `detailWindowSetting` object to `DetailWindowSetting::DetailWindowMode::EV_ONLY`. This indicates that the detail window should be displayed in the "EV Only" mode.

2. It calls the `update()` method on the viewports of the `strategyTableView` and `detailView` widgets. This ensures that these UI elements are refreshed to reflect the updated detail window setting.

3. It calls the `onchanged()` method of the `roughStrategyViewerModel` object. This likely triggers an update or refresh of the "rough strategy" view, which is another UI element related to the strategy exploration functionality.

4. Finally, it calls the `update()` method on the viewport of the `roughStrategyView` widget. This ensures that the "rough strategy" view is also refreshed to reflect any changes.

The purpose of this function is to update the detail window mode to the "EV Only" mode and ensure that the relevant UI elements are refreshed to reflect this change. This is likely part of a larger strategy exploration feature within the application, where the user can switch between different modes of displaying and analyzing strategy-related information.\\
## Code: 
```
void StrategyExplorer::on_evOnlyModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::EV_ONLY;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```