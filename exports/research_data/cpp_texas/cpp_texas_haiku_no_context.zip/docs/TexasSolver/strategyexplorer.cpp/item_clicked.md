`item_clicked`: The function of `item_clicked` is to handle the event when a user clicks on an item in a tree view.

**Code Description**: The `item_clicked` function is part of the `StrategyExplorer` class and is responsible for processing the user's click on an item in a tree view. Here's a breakdown of what the function does:

1. It tries to cast the internal pointer of the clicked item to a `TreeItem` object, which represents a node in the tree view.
2. It then calls the `process_treeclick` and `process_board` functions, passing the `TreeItem` object as an argument. These functions likely perform some processing or update the state of the application based on the clicked item.
3. It sets the `TreeItem` object as the current game tree node in the `tableStrategyModel`, which is likely a model used to display strategy-related data in a table view.
4. It then calls the `updateStrategyData` function on the `tableStrategyModel` to update the displayed strategy data.
5. It triggers a viewport update on the `strategyTableView` to ensure the table view is properly refreshed.
6. It calls the `onchanged` function on the `roughStrategyViewerModel`, which is likely another model used to display a rough strategy view.
7. It triggers a resize on the `roughStrategyView` and updates its viewport to ensure the rough strategy view is properly updated.

If any errors occur during the execution of the function, it catches a `runtime_error` exception and logs the error message to the debug output.

Overall, the `item_clicked` function is responsible for processing a user's click on an item in a tree view, updating the state of the application, and refreshing the relevant views to reflect the changes.\\
## Code: 
```
void StrategyExplorer::item_clicked(const QModelIndex& index){
    try{
        TreeItem * treeNode = static_cast<TreeItem*>(index.internalPointer());
        this->process_treeclick(treeNode);
        this->process_board(treeNode);
        this->tableStrategyModel->setGameTreeNode(treeNode);
        this->tableStrategyModel->updateStrategyData();
        this->ui->strategyTableView->viewport()->update();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->triger_resize();
        this->ui->roughStrategyView->viewport()->update();
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```