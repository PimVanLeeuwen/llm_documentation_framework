`process_board`: The function of `process_board` is to process the board cards and display them in the user interface.

**Code Description**: The `process_board` function takes a `TreeItem` pointer as an argument and performs the following tasks:

1. It splits the `board` string from the `qSolverJob` object into a vector of strings, where each string represents a card.
2. It creates a vector of `Card` objects, where each `Card` object is created from one of the strings in the `board_str_arr` vector.
3. If the `treeitem` argument is not `NULL`, it checks the game round:
   - If the round is `TURN` and the `tableStrategyModel` has a non-empty `trunCard`, it adds the `trunCard` to the `cards` vector.
   - If the round is `RIVER`, it adds the `trunCard` and `riverCard` from the `tableStrategyModel` to the `cards` vector.
4. Finally, it sets the text of the `boardLabel` in the user interface to display the board cards in HTML format using the `Card::boardCards2html` function.

The purpose of this function is to process the board cards and update the user interface to display the current state of the game board. It retrieves the board cards from the `qSolverJob` object and the `tableStrategyModel`, and then formats them for display in the user interface.\\
## Code: 
```
void StrategyExplorer::process_board(TreeItem* treeitem){
    vector<string> board_str_arr = string_split(this->qSolverJob->board,',');
    vector<Card> cards;
    for(string one_board_str:board_str_arr){
        cards.push_back(Card(one_board_str));
    }
    if(treeitem != NULL){
        if(treeitem->m_treedata.lock()->getRound() == GameTreeNode::GameRound::TURN && !this->tableStrategyModel->getTrunCard().empty()){
            cards.push_back(Card(this->tableStrategyModel->getTrunCard()));
        }
        else if(treeitem->m_treedata.lock()->getRound() == GameTreeNode::GameRound::RIVER){
            if(!this->tableStrategyModel->getTrunCard().empty())
                cards.push_back(Card(this->tableStrategyModel->getTrunCard()));
            if(!this->tableStrategyModel->getRiverCard().empty())
                cards.push_back(Card(this->tableStrategyModel->getRiverCard()));
        }
    }
    this->ui->boardLabel->setText(QString("<b>%1: </b>").arg(tr("board")) + Card::boardCards2html(cards));
}
```