`on_evModeButtom_clicked`: The function of `on_evModeButtom_clicked` is to update the display of the strategy explorer interface when the "EV Mode" button is clicked.

**Code Description**: The `on_evModeButtom_clicked` function is a member function of the `StrategyExplorer` class. When the "EV Mode" button is clicked, this function is called to update the display of the strategy explorer interface.

The function performs the following actions:

1. It sets the `mode` property of the `detailWindowSetting` object to `DetailWindowSetting::DetailWindowMode::EV`, which indicates that the "EV Mode" should be displayed.

2. It calls the `update()` method on the `viewport()` of the following UI elements:
   - `strategyTableView`: This updates the display of the strategy table view.
   - `detailView`: This updates the display of the detail view.
   - `roughStrategyView`: This updates the display of the rough strategy view.

These updates ensure that the user interface is refreshed to reflect the new "EV Mode" setting.

The purpose of this function is to provide a way for the user to switch the display of the strategy explorer interface to the "EV Mode", which likely provides a different view or set of information related to the strategy being explored.\\
## Code: 
```
void StrategyExplorer::on_evModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::EV;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->ui->roughStrategyView->viewport()->update();
}
```