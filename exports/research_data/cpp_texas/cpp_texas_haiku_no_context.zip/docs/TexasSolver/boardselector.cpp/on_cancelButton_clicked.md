`on_cancelButton_clicked`: The function of `on_cancelButton_clicked` is to close the current window or dialog.

**Code Description**: The `on_cancelButton_clicked()` function is a member function of the `boardselector` class. When the "Cancel" button is clicked, this function is called, and it simply closes the current window or dialog by calling the `close()` method. This allows the user to exit the application or dialog without making any changes or selections.\\
## Code: 
```
void boardselector::on_cancelButton_clicked()
{
    this->close();
}
```