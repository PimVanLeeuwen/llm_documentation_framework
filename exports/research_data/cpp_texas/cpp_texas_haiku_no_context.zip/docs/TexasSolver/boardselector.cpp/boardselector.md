`boardselector`: The function of `boardselector` is to create a dialog window that allows the user to select a board for a poker game.

**Code Description**:

1. The `boardselector` class is a `QDialog` that takes in a `QTextEdit` pointer for the board edit, a `QSolverJob::Mode` for the game mode, and a `QWidget` pointer for the parent widget.

2. The constructor sets up the UI using the `Ui::boardselector` class, sets the window title, and stores the `boardEdit` and `mode` parameters.

3. The constructor then determines the list of ranks to be used based on the game mode. For "HOLDEM" mode, the ranks are "A,K,Q,J,T,9,8,7,6,5,4,3,2", and for "SHORTDECK" mode, the ranks are "A,K,Q,J,T,9,8,7,6".

4. A `BoardSelectorTableModel` is created using the rank list and the current text in the `boardEdit` widget. This model is then set as the model for the `boardSelectorTable` in the UI.

5. A `BoardSelectorTableDelegate` is also created and set as the item delegate for the `boardSelectorTable`. This delegate is responsible for rendering the table cells and handling user interactions.

6. Finally, the text from the `boardEdit` widget is copied to the `ui->boardEdit` widget in the dialog.

Overall, the `boardselector` class provides a user interface for selecting a board for a poker game, with the ability to customize the available ranks based on the game mode. The selected board can then be used in the game logic.\\
## Code: 
```
boardselector::boardselector(QTextEdit* boardEdit,QSolverJob::Mode mode,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::boardselector)
{
    ui->setupUi(this);
    this->setWindowTitle(tr("BoardSelector"));
    this->boardEdit = boardEdit;
    this->mode = mode;

    QString ranks;
    if(mode == QSolverJob::Mode::HOLDEM){
        ranks = "A,K,Q,J,T,9,8,7,6,5,4,3,2";
    }else if(mode == QSolverJob::Mode::SHORTDECK){
        ranks = "A,K,Q,J,T,9,8,7,6";
    }else{
        throw runtime_error("mode not found in range selector");
    }
    this->rank_list = ranks.split(",");

    this->boardSelectorTableModel = new BoardSelectorTableModel(this->rank_list,boardEdit->toPlainText(),this);
    this->ui->boardSelectorTable->setModel(boardSelectorTableModel);
    this->boardSelectorTableDelegate = new BoardSelectorTableDelegate(this->rank_list,this->boardSelectorTableModel,this);
    this->ui->boardSelectorTable->setItemDelegate(this->boardSelectorTableDelegate);
    this->ui->boardEdit->setText(boardEdit->toPlainText());
}
```