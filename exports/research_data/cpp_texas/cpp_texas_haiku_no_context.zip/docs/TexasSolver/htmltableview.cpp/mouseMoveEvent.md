`mouseMoveEvent`: The function of `mouseMoveEvent` is to handle mouse movement events within the HtmlTableView.

**Code Description**: The `mouseMoveEvent` function is responsible for managing the behavior of the HtmlTableView when the user moves the mouse over the table. Here's a breakdown of the code:

1. The function takes a `QMouseEvent *event` parameter, which represents the mouse movement event.
2. It retrieves the anchor (a hyperlink or other interactive element) at the current mouse position using the `anchorAt(event->pos())` function.
3. If the current anchor is different from the anchor where the mouse was previously pressed (`_mousePressAnchor`), the `_mousePressAnchor` is cleared.
4. If the current anchor (`_lastHoveredAnchor`) is different from the previous anchor, the following actions are performed:
   - The `_lastHoveredAnchor` is updated with the new anchor.
   - If the new anchor is not empty (i.e., a valid anchor), the cursor is changed to a pointing hand cursor (`Qt::PointingHandCursor`) using `QApplication::setOverrideCursor()`, and a `linkHovered` signal is emitted to notify other parts of the application that the user is hovering over a link.
   - If the new anchor is empty (i.e., no valid anchor), the cursor is restored to the default cursor using `QApplication::restoreOverrideCursor()`, and a `linkUnhovered` signal is emitted to notify other parts of the application that the user is no longer hovering over a link.

The purpose of this code is to provide a consistent and intuitive user experience when the user moves the mouse over the HtmlTableView. By detecting and responding to changes in the hovered anchor, the code can update the cursor and emit signals to allow other parts of the application to react to the user's actions.\\
## Code: 
```
void HtmlTableView::mouseMoveEvent(QMouseEvent *event) {
    auto anchor = anchorAt(event->pos());

    if (_mousePressAnchor != anchor) {
        _mousePressAnchor.clear();
    }

    if (_lastHoveredAnchor != anchor) {
        _lastHoveredAnchor = anchor;
        if (!_lastHoveredAnchor.isEmpty()) {
            QApplication::setOverrideCursor(QCursor(Qt::PointingHandCursor));
            emit linkHovered(_lastHoveredAnchor);
        } else {
            QApplication::restoreOverrideCursor();
            emit linkUnhovered();
        }
    }
}
```