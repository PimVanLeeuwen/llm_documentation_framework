`triger_resize`: The function of `triger_resize` is to trigger a resize event for the `HtmlTableView` object.

**Code Description**: The `triger_resize` function is responsible for triggering a resize event for the `HtmlTableView` object. It does this by creating a new `QResizeEvent` object with the current size of the `HtmlTableView` object, and then calling the `resizeEvent` function on the `HtmlTableView` object, passing the newly created `QResizeEvent` object as an argument. This effectively simulates a resize event, which can be useful for updating the layout or appearance of the `HtmlTableView` object in response to changes in its size.

The commented-out line `this->resize(this->parentWidget()->size());` suggests that an alternative approach to triggering the resize event would be to directly set the size of the `HtmlTableView` object to match the size of its parent widget. However, this approach is not used in the provided code, and the function instead relies on the `resizeEvent` function to handle the resize event.

Finally, the `delete ev;` statement at the end of the function ensures that the `QResizeEvent` object created at the beginning of the function is properly cleaned up and removed from memory.\\
## Code: 
```
void HtmlTableView::triger_resize(){
    QResizeEvent* ev = new QResizeEvent(this->size(),this->size());
    this->resizeEvent(ev);
    //this->resize(this->parentWidget()->size());
    delete ev;
}
```