`mousePressEvent`: The function of `mousePressEvent` is to handle mouse press events on the HTML table view.

**Code Description**: The `mousePressEvent` function is overridden from the base `QTableView` class. It first calls the base class's `mousePressEvent` function to handle the default behavior. Then, it retrieves the anchor (a hyperlink or other interactive element) at the position of the mouse press event using the `anchorAt` function. The retrieved anchor is stored in the `_mousePressAnchor` member variable.

This code is part of an implementation of an HTML table view, which likely displays tabular data with interactive elements such as hyperlinks. The `mousePressEvent` function is responsible for capturing and processing mouse press events on the table view, which can be used to handle user interactions with the displayed content.\\
## Code: 
```
void HtmlTableView::mousePressEvent(QMouseEvent *event) {
    QTableView::mousePressEvent(event);

    auto anchor = anchorAt(event->pos());
    _mousePressAnchor = anchor;
}
```