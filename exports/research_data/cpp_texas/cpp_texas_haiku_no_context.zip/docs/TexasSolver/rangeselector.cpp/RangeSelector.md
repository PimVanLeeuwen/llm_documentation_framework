`RangeSelector`: The function of `RangeSelector` is to create a dialog window that allows the user to select a range of cards for a specific game mode (Hold'em or Short Deck).

**Code Description**:

1. The constructor `RangeSelector(QTextEdit* rangeEdit, QWidget *parent, QSolverJob::Mode mode)` takes three parameters:
   - `rangeEdit`: a pointer to a `QTextEdit` widget that will display the selected range.
   - `parent`: a pointer to the parent widget of the `RangeSelector` dialog.
   - `mode`: the game mode, which can be either `QSolverJob::Mode::HOLDEM` or `QSolverJob::Mode::SHORTDECK`.

2. Based on the game mode, the constructor sets up the list of card ranks to be used in the range selector. For Hold'em, the ranks are "A,K,Q,J,T,9,8,7,6,5,4,3,2", and for Short Deck, the ranks are "A,K,Q,J,T,9,8,7,6".

3. The constructor then creates a `RangeSelectorTableModel` and a `RangeSelectorTableDelegate`, which are used to display and interact with the range selection grid in the `ui->rangeTableView` widget.

4. The constructor also sets up the initial state of the dialog, including:
   - Initializing the `ui->textEdit` widget with the current range text from the `rangeEdit` widget.
   - Setting the maximum value of the `ui->rangeNumberSlider` to the maximum possible value (`this->max_val`).
   - Setting the window title to "RangeSelector".

5. The constructor also sets up several signal-slot connections to handle user interactions with the range selection grid:
   - `view_item_pressed(int, int)`: Triggered when a cell in the grid is pressed.
   - `view_item_area(int, int, int, int)`: Triggered when the mouse pointer moves over a range of cells in the grid.
   - `item_release(int, int)`: Triggered when a cell in the gri\\
## Code: 
```
RangeSelector::RangeSelector(QTextEdit* rangeEdit,QWidget *parent,QSolverJob::Mode mode) :
    QDialog(parent),
    ui(new Ui::RangeSelector)
{

    QString ranks;
    if(mode == QSolverJob::Mode::HOLDEM){
        ranks = "A,K,Q,J,T,9,8,7,6,5,4,3,2";
    }else if(mode == QSolverJob::Mode::SHORTDECK){
        ranks = "A,K,Q,J,T,9,8,7,6";
    }else{
        throw runtime_error("mode not found in range selector");
    }
    this->rank_list = ranks.split(",");
    this->rangeSelectorTableModel = new RangeSelectorTableModel(this->rank_list,rangeEdit->toPlainText(),this);
    this->rangeSelectorTableDelegate = new RangeSelectorTableDelegate(this->rank_list,this->rangeSelectorTableModel,this);
    ui->setupUi(this);
    this->ui->rangeTableView->setModel(this->rangeSelectorTableModel);
    this->ui->rangeTableView->setItemDelegate(this->rangeSelectorTableDelegate);
    this->rangeEdit = rangeEdit;
    this->ui->textEdit->setText(this->rangeEdit->toPlainText());
    this->ui->rangeNumberSlider->setMaximum(this->max_val);
    this->ui->rangeNumberSlider->setValue(this->max_val);
    this->setWindowTitle(tr("RangeSelector"));
    connect(this->ui->rangeTableView,SIGNAL(view_item_pressed(int,int)),this,SLOT(grid_pressed(int,int)));
    connect(this->ui->rangeTableView,SIGNAL(view_item_area(int,int,int,int)),this,SLOT(grid_area(int,int,int,int)));
    connect(this->ui->rangeTableView,SIGNAL(item_release(int,int)),this,SLOT(grid_release(int,int)));

    QStringList filters;
    filters << "*.txt";
    qFileSystemModel = new QFileSystemModel(this);
    QDir filedir = QDir::current().filePath("ranges");
    qFileSystemModel->setRootPath(filedir.path());
#ifdef Q_OS_MAC
```