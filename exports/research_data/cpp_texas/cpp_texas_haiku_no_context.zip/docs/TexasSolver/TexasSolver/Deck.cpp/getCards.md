`getCards`: The function of `getCards` is to return a reference to the `cards` vector member of the `Deck` class.

**Code Description**: The `getCards` function is a member function of the `Deck` class. It takes no parameters and returns a reference to the `cards` vector member of the `Deck` class. This allows other parts of the code to access and manipulate the cards in the deck directly, without having to go through additional getter or setter functions.\\
## Code: 
```
vector<Card>& Deck::getCards() {
    return this->cards;
}
```