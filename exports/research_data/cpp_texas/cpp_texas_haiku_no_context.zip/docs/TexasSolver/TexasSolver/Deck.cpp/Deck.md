`Deck`: The function of `Deck` is to create a deck of playing cards.

**Code Description**: The `Deck` class constructor takes two vectors of strings, `ranks` and `suits`, as input parameters. These vectors represent the different ranks (e.g., "Ace", "King", "Queen", "Jack", "10", "9", etc.) and suits (e.g., "Hearts", "Diamonds", "Clubs", "Spades") of the playing cards, respectively.

The constructor initializes the `ranks` and `suits` member variables with the provided vectors. It then iterates through the `ranks` and `suits` vectors, creating a string representation of each card by concatenating the rank and suit. These card strings are stored in the `cards_str` vector.

Simultaneously, the constructor creates a vector of `Card` objects, where each `Card` object represents a single playing card. The `Card` objects are created by passing the card string and a unique card number (starting from 0) to the `Card` constructor. These `Card` objects are stored in the `cards` vector.

The purpose of this code is to set up a standard 52-card deck, where each card is represented by a unique string (e.g., "AceHearts", "KingDiamonds", "JackClubs", etc.) and a unique numerical identifier (0 to 51). This data structure allows for easy manipulation and access to the individual cards in the deck, which can be useful for various card game implementations or other applications that require a standard deck of playing cards.\\
## Code: 
```
Deck::Deck(const vector<string>& ranks, const vector<string>& suits) {
    this->ranks = ranks;
    this->suits = suits;
    int card_num = 0;
    for(const string& one_rank : ranks){
        for(const string& one_suit: suits){
            string one_card = one_rank + one_suit;
            cards_str.push_back(one_card);
            cards.emplace_back(one_card,card_num);
            card_num += 1;
        }
    }
}
```