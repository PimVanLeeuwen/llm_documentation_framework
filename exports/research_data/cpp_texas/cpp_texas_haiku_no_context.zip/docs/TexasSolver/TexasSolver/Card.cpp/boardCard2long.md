`boardCard2long`: The function of `boardCard2long` is to convert a `Card` object to a `uint64_t` value.

**Code Description**: The `boardCard2long` function takes a `Card` object as input and calls the `boardInt2long` function, passing the result of the `getCardInt()` method of the `Card` object. The `boardInt2long` function is likely a helper function that converts an integer representation of a card to a `uint64_t` value. This conversion is useful for efficiently storing and manipulating card data in a compact format.\\
## Code: 
```
uint64_t Card::boardCard2long(Card& card){
    return Card::boardInt2long(card.getCardInt());
}
```