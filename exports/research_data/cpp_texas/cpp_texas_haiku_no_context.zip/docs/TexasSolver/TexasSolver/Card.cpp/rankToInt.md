`rankToInt`: The function of `rankToInt` is to convert a character representing a playing card rank to its corresponding integer value.

**Code Description**: The `rankToInt` function takes a single character `rank` as input and returns an integer value representing the corresponding rank of a playing card. The function uses a `switch` statement to map the input character to its corresponding integer value.

The function handles the following card ranks:
- '2' to '9' are mapped to their respective integer values (2 to 9)
- 'T' is mapped to 10
- 'J' is mapped to 11
- 'Q' is mapped to 12
- 'K' is mapped to 13
- 'A' is mapped to 14

If the input character does not match any of the recognized card ranks, the function returns the default value of 2, which corresponds to the '2' card rank.

This function is likely used in a larger context, such as a card game or a card-related application, where the integer representation of the card rank is required for various operations or calculations.\\
## Code: 
```
int Card::rankToInt(char rank)
{
    switch(rank)
    {
        case '2': return 2;
        case '3': return 3;
        case '4': return 4;
        case '5': return 5;
        case '6': return 6;
        case '7': return 7;
        case '8': return 8;
        case '9': return 9;
        case 'T': return 10;
        case 'J': return 11;
        case 'Q': return 12;
        case 'K': return 13;
        case 'A': return 14;
        default: return 2;
    }
}
```