`getSuits`: The function of `getSuits` is to return a vector of strings representing the four standard suits in a deck of playing cards: clubs ("c"), diamonds ("d"), hearts ("h"), and spades ("s").

**Code Description**: The `getSuits` function is a member function of the `Card` class. It takes no parameters and returns a vector of four string literals, each representing one of the four standard playing card suits. The function simply returns this pre-defined vector of suit strings, which can be used by other parts of the code that work with playing cards.\\
## Code: 
```
vector<string> Card::getSuits(){
    return {"c","d","h","s"};
}
```