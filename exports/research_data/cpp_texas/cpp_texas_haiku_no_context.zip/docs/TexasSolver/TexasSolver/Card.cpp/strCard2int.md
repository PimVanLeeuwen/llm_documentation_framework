`strCard2int`: The function of `strCard2int` is to convert a string representation of a playing card into an integer value.

**Code Description**: The `strCard2int` function takes a string `card` as input, which represents a playing card. The function first extracts the rank (the first character of the string) and the suit (the second character of the string) of the card. It then checks if the input string has exactly two characters, as a valid card representation should have. If the input string does not have exactly two characters, the function throws a `runtime_error` with a formatted error message.

If the input string is valid, the function calculates the integer value of the card by first converting the rank to an integer value using the `rankToInt` function (which is not shown in the provided code), and then subtracting 2 from the result. This is because the rank values are typically represented as 2-14, where 2 corresponds to the Ace and 14 corresponds to the King. The function then multiplies the result by 4 and adds the integer value of the suit, which is obtained using the `suitToInt` function (also not shown in the provided code). This calculation results in an integer value that uniquely represents the card, with the rank encoded in the most significant bits and the suit encoded in the least significant bits.

The purpose of this function is likely to provide a compact and efficient way to represent playing cards in a program, which can be useful in various card-based games or applications.\\
## Code: 
```
int Card::strCard2int(string card) {
    char rank = card.at(0);
    char suit = card.at(1);
    if(card.length() != 2){
        throw runtime_error( tfm::format("card %s not found",card));
    }
    return (rankToInt(rank) - 2) * 4 + suitToInt(suit);
}
```