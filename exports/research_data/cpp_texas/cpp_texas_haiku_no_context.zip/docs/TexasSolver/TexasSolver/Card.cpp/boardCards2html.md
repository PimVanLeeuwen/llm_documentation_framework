`boardCards2html`: The function of `boardCards2html` is to generate an HTML-formatted string representation of a vector of `Card` objects.

**Code Description**: The `boardCards2html` function takes a reference to a vector of `Card` objects as its input parameter. It initializes an empty `QString` variable called `ret_html` to store the resulting HTML-formatted string.

The function then iterates over each `Card` object in the input vector using a range-based `for` loop. For each `Card` object, it checks if the card is not empty (using the `empty()` member function) and, if so, appends the HTML-formatted representation of the card (obtained by calling the `toFormattedHtml()` member function) to the `ret_html` string.

Finally, the function returns the `ret_html` string, which contains the HTML-formatted representation of all the non-empty `Card` objects in the input vector.\\
## Code: 
```
QString Card::boardCards2html(vector<Card>& cards){
    QString ret_html = "";
    for(auto one_card:cards){
        if(one_card.empty())continue;
        ret_html += one_card.toFormattedHtml();
    }
    return ret_html;
}
```