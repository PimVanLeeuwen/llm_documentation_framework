`boardCards2long`: The function of `boardCards2long` is to convert a vector of string representations of playing cards into a single 64-bit unsigned integer representation of the board cards.

**Code Description**: The `boardCards2long` function takes a vector of string representations of playing cards as input and returns a 64-bit unsigned integer representation of the board cards.

The function first creates a vector of `Card` objects, where each `Card` object is initialized with a string representation of a playing card from the input vector. This is done using a loop that iterates over the input vector of strings and creates a corresponding `Card` object for each string.

Once the vector of `Card` objects is created, the function calls another `boardCards2long` function, which takes the vector of `Card` objects as input and returns the 64-bit unsigned integer representation of the board cards.

The purpose of this function is to provide a convenient way to convert a vector of string representations of playing cards into a compact, 64-bit integer representation that can be used for efficient storage and manipulation of the board cards in a game or application.\\
## Code: 
```
uint64_t Card::boardCards2long(vector<string> cards) {
    vector<Card> cards_objs(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_objs[i] = Card(cards[i]);
    }
    return Card::boardCards2long(cards_objs);
}
```