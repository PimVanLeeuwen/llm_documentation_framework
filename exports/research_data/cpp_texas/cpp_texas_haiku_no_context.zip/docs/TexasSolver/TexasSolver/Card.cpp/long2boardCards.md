`long2boardCards`: The function of `long2boardCards` is to convert a 64-bit integer representation of a poker board into a vector of `Card` objects.

**Code Description**:
The `long2boardCards` function takes a 64-bit integer `board_long` as input, which represents the cards on the board in a compact format. The function first calls the `long2board` function to convert the 64-bit integer into a vector of integers, where each integer represents a card on the board.

The function then creates a vector of `Card` objects `board_cards` with the same size as the `board` vector. It iterates through the `board` vector and creates a `Card` object for each card on the board using the `intCard2Str` function to convert the integer representation to a string representation.

If the size of the `board_cards` vector is less than 1 or greater than 7, the function throws a `runtime_error` with a message indicating that the board length is not correct.

Finally, the function creates a new vector `retval` and copies the `Card` objects from the `board_cards` vector into it. The `retval` vector is then returned as the output of the function.

The purpose of this function is to provide a convenient way to convert the compact 64-bit integer representation of a poker board into a more easily manipulable vector of `Card` objects, which can be used in other parts of the code.\\
## Code: 
```
vector<Card> Card::long2boardCards(uint64_t board_long){
        vector<int> board = long2board(board_long);
        vector<Card> board_cards(board.size());
        for(std::size_t i = 0;i < board.size();i ++){
            int one_board = board[i];
            board_cards[i] = Card(intCard2Str(one_board));
        }
        if (board_cards.size() < 1 || board_cards.size() > 7){
            throw runtime_error(tfm::format("board length not correct, board length %s",board_cards.size()));
        }
        vector<Card> retval(board_cards.size());
        for(std::size_t i = 0;i < board_cards.size();i ++){
            retval[i] = board_cards[i];
        }
        return retval;
}
```