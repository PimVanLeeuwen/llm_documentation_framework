`boardInt2long`: The function of `boardInt2long` is to convert an integer representation of a card on a board to a 64-bit unsigned integer (uint64_t) representation.

**Code Description**:
The `boardInt2long` function takes an integer `board` as input, which represents the index of a card on a board. The function first checks if the input `board` is within the valid range of 0 to 51 (assuming a standard deck of 52 cards). If the input is out of range, the function throws a `runtime_error` with a formatted error message.

If the input `board` is within the valid range, the function uses the bitwise left shift operator (`<<`) to set the bit at the position corresponding to the `board` index in a 64-bit unsigned integer. This effectively creates a 64-bit number with a single bit set, where the position of the set bit corresponds to the input `board` value.

The function returns the resulting 64-bit unsigned integer, which can be used to represent the card on the board in a compact and efficient manner. This 64-bit representation can be useful for various card game or board game implementations, where efficient bit manipulation is required to track and manipulate the state of the game board.\\
## Code: 
```
uint64_t Card::boardInt2long(int board){
    // 这里hard code了一副扑克牌是52张
    if(board < 0 || board >= 52){
        throw runtime_error(tfm::format("Card with id %s not found",board));
    }
    // uint64_7 的range 在0 ~ + 2^ 64之间,所以不用太担心溢出问题
    return ((uint64_t)(1) << board);
}
```