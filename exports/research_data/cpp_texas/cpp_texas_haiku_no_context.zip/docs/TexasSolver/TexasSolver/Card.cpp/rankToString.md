`rankToString`: The function of `rankToString` is to convert an integer representing a playing card rank to its corresponding string representation.

**Code Description**: The `rankToString` function takes an integer `rank` as input and returns a string representing the card rank. The function uses a `switch` statement to map the integer values to their corresponding string representations.

The function handles the following card ranks:
- 2 through 9 are returned as their respective string values (e.g., "2", "3", "4", etc.)
- 10 is returned as "T" (for "Ten")
- 11 is returned as "J" (for "Jack")
- 12 is returned as "Q" (for "Queen")
- 13 is returned as "K" (for "King")
- 14 is returned as "A" (for "Ace")

If the input `rank` is not one of the valid values (2 through 14), the function returns the default value of "2".

This function is likely used in a larger context, such as a card game or a card-related application, where the string representation of a card's rank is needed for display or other purposes.\\
## Code: 
```
string Card::rankToString(int rank)
{
    switch(rank)
    {
        case 2: return "2";
        case 3: return "3";
        case 4: return "4";
        case 5: return "5";
        case 6: return "6";
        case 7: return "7";
        case 8: return "8";
        case 9: return "9";
        case 10: return "T";
        case 11: return "J";
        case 12: return "Q";
        case 13: return "K";
        case 14: return "A";
        default: return "2";
    }
}
```