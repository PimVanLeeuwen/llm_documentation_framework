`boardInts2long`: The function of `boardInts2long` is to convert a vector of integer card IDs representing a board state into a single 64-bit unsigned integer representation.

**Code Description**:
The `boardInts2long` function takes a vector of integers representing card IDs on a game board and converts them into a single 64-bit unsigned integer (`uint64_t`). This representation is useful for efficiently storing and manipulating the board state in memory.

The function first checks that the input vector has a valid length (between 1 and 7 elements). If the length is invalid, it throws a `runtime_error` with a message indicating the incorrect length.

Next, the function initializes a 64-bit unsigned integer `board_long` to 0. It then iterates through the input vector of card IDs, checking that each ID is within the valid range of a standard 52-card deck (0 to 51). If any card ID is out of range, the function throws a `runtime_error` with a message indicating the invalid card ID.

For each valid card ID, the function sets the corresponding bit in the `board_long` integer by shifting a 1 bit to the position of the card ID and adding it to the `board_long` value. This effectively encodes the presence of each card on the board into a single 64-bit value.

Finally, the function returns the `board_long` value, which represents the complete board state as a 64-bit unsigned integer.

This compact representation of the board state can be useful in various game-related applications, such as efficient storage, comparison, and manipulation of board positions.\\
## Code: 
```
uint64_t Card::boardInts2long(const vector<int>& board){
    if(board.size() < 1 || board.size() > 7){
        throw runtime_error(tfm::format("Card length incorrect: %s",board.size()));
    }
    uint64_t board_long = 0;
    for(int one_card: board){
        // 这里hard code了一副扑克牌是52张
        if(one_card < 0 || one_card >= 52){
            throw runtime_error(tfm::format("Card with id %s not found",one_card));
        }
        // uint64_7 的range 在0 ~ + 2^ 64之间,所以不用太担心溢出问题
        board_long += ((uint64_t)(1) << one_card);
    }
    return board_long;
}
```