`long2board`: The function of `long2board` is to convert a 64-bit integer representation of a board state into a vector of integers representing the positions of the set bits in the board.

**Code Description**:
The `long2board` function takes a single parameter, `board_long`, which is a 64-bit unsigned integer representing the state of a game board. The function then creates a vector of integers called `board` and reserves space for up to 7 elements.

The function then iterates over the 52 bits of the `board_long` integer, starting from the least significant bit. For each bit, the function checks if the bit is set (i.e., has a value of 1). If the bit is set, the function adds the current index (which represents the position of the set bit) to the `board` vector.

After iterating over all 52 bits, the function checks the size of the `board` vector. If the size is less than 1 or greater than 7, the function throws a `runtime_error` with a message indicating that the board length is not correct.

Finally, the function returns the `board` vector, which contains the positions of the set bits in the original `board_long` integer.\\
## Code: 
```
vector<int> Card::long2board(uint64_t board_long) {
    vector<int> board;
    board.reserve(7);
    for(int i = 0;i < 52;i ++){
        // 看二进制最后一位是否为1
        if((board_long & 1) == 1){
            board.push_back(i);
        }
        board_long = board_long >> 1;
    }
    if (board.size() < 1 || board.size() > 7){
        throw runtime_error(tfm::format("board length not correct, board length %s",board.size()));
    }
    return board;
}
```