`suitToString`: The function of `suitToString` is to convert an integer representation of a playing card suit to its corresponding string representation.

**Code Description**: The `suitToString` function takes an integer `suit` as input and returns a string representing the suit of a playing card. The function uses a `switch` statement to map the integer values `0`, `1`, `2`, and `3` to the string representations `"c"`, `"d"`, `"h"`, and `"s"`, respectively. These string representations correspond to the suits of clubs, diamonds, hearts, and spades, respectively.

If the input `suit` value is not one of the expected values (0, 1, 2, or 3), the function returns the default string `"c"`, which represents the club suit.

This function is likely used in a larger context, such as a playing card or deck of cards implementation, where the integer representation of a suit needs to be converted to a more human-readable string format.\\
## Code: 
```
string Card::suitToString(int suit)
{
    switch(suit)
    {
        case 0: return "c";
        case 1: return "d";
        case 2: return "h";
        case 3: return "s";
        default: return "c";
    }
}
```