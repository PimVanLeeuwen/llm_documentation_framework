`toFormattedString`: The function of `toFormattedString` is to convert a string representation of a playing card into a formatted string with the corresponding suit symbols.

**Code Description**:
The `toFormattedString` function takes a string `this->card` that represents a playing card and converts it into a formatted string with the appropriate suit symbols. The function uses the following steps:

1. It creates a `QString` object `qString` from the input string `this->card` using `QString::fromStdString`.
2. It then replaces the following characters in the `qString` with their corresponding suit symbols:
   - "c" is replaced with "♣️" (club)
   - "d" is replaced with "♦️" (diamond)
   - "h" is replaced with "♥️" (heart)
   - "s" is replaced with "♠️" (spade)
3. Finally, it converts the modified `qString` back to a `std::string` and returns it.

This function is likely used to display the playing cards in a user interface or other application that requires the cards to be represented with their corresponding suit symbols.\\
## Code: 
```
string Card::toFormattedString() {
    QString qString = QString::fromStdString(this->card);
    qString = qString.replace("c", "♣️");
    qString = qString.replace("d", "♦️");
    qString = qString.replace("h", "♥️");
    qString = qString.replace("s", "♠️");
    return qString.toStdString();
}
```