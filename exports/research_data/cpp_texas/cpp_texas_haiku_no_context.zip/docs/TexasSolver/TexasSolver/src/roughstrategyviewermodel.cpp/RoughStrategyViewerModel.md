`RoughStrategyViewerModel`: The function of `RoughStrategyViewerModel` is to create an instance of the `RoughStrategyViewerModel` class, which is a subclass of `QAbstractItemModel`.

**Code Description**: The `RoughStrategyViewerModel` class is a constructor that takes two parameters: `TableStrategyModel* tableStrategyModel` and `QObject *parent`. The `tableStrategyModel` parameter is a pointer to a `TableStrategyModel` object, which is likely used to provide data for the `RoughStrategyViewerModel`. The `parent` parameter is a pointer to a `QObject` object, which is used to set the parent of the `RoughStrategyViewerModel` object.

The constructor initializes the `tableStrategyModel` member variable with the provided `tableStrategyModel` pointer, and calls the constructor of the `QAbstractItemModel` class, passing the `parent` parameter.

This code is likely part of a larger application that deals with table-based strategies, and the `RoughStrategyViewerModel` class is responsible for providing a model for displaying and interacting with the strategy data.\\
## Code: 
```
RoughStrategyViewerModel::RoughStrategyViewerModel(TableStrategyModel* tableStrategyModel, QObject *parent):QAbstractItemModel(parent){
    this->tableStrategyModel = tableStrategyModel;
}
```