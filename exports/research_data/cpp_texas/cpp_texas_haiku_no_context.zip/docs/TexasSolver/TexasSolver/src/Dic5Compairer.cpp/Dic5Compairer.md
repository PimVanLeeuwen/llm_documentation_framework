`Dic5Compairer`: The function of `Dic5Compairer` is to load and process a dictionary file containing information about 5-card poker hands and their corresponding ranks.

**Code Description**:

1. The `Dic5Compairer` class inherits from the `Compairer` class and takes three parameters in its constructor: `dic_dir` (the directory of the dictionary file), `lines` (the number of lines in the dictionary file), and `dic_dir_bin` (the directory of the binary file).

2. The constructor first attempts to load the binary file specified by `dic_dir_bin`. If the load is successful, the function returns.

3. If the binary file cannot be loaded, the constructor opens the dictionary file specified by `dic_dir` in read-only mode. If the file cannot be opened, it throws a `runtime_error` exception.

4. The constructor then reads the contents of the dictionary file line by line, splitting each line by commas to extract the 5-card hand and its corresponding rank.

5. For each 5-card hand, the constructor checks that the hand has exactly 5 cards and that the rank is a valid integer. If either of these conditions is not met, the constructor throws a `runtime_error` exception.

6. The constructor then stores the 5-card hand (represented as a long integer using the `Card::boardCards2long` function) and its corresponding rank in the `cardslong2rank` map.

7. If the constructor encounters a 5-card hand that is already present in the `cardslong2rank` map, it throws a `runtime_error` exception.

8. After processing all the lines in the dictionary file, the constructor converts the `cardslong2rank` map to a binary format using the `fcs.convert` function.

9. Finally, the constructor checks the consistency of the `cardslong2rank` map using the `fcs.check` function. If the check fails, the constructor throws a `runtime_error` exception.

10. The `cardslong2rank` map is then cleared, as it is no longer needed after the binary file has been generated.

Overall, the `Dic5Compairer` class is responsible for loading and processing a dictionary file\\
## Code: 
```
Dic5Compairer::Dic5Compairer(string dic_dir,int lines,string dic_dir_bin):Compairer(std::move(dic_dir),lines){
    if(fcs.load(dic_dir_bin.c_str())) return;
    QFile infile(QString::fromStdString(this->dic_dir));
    if (!infile.open(QIODevice::ReadOnly)){
        throw runtime_error("unable to load compairer file");
    }
    QTextStream in(&infile);
    //progressbar bar(lines / 1000);
    int i = 0;
    //while (std::getline(infile, line))
    while (!in.atEnd())
    {
        string line = in.readLine().toStdString();
        vector<string> linesp = string_split(line,',');
        if(linesp.size() != 2){
           throw runtime_error(tfm::format("linesp not correct: %s",line));
        }
        string cards_str = linesp[0];
        int rank = stoi(linesp[1]);
        vector<string> cards = string_split(cards_str,'-');

        if(cards.size() != 5)
            throw runtime_error(
                    tfm::format(
                            "cards not correct: %s length %s",cards_str,cards.size()));

        //set<string> cards_set;
        //for(string one_card:cards) cards_set.insert(one_card);
        //this->card2rank[cards_set] = rank;

        if(this->cardslong2rank.find(Card::boardCards2long(cards)) != this->cardslong2rank.end()){
            throw runtime_error(
                    tfm::format("key repeated: %s",cards_str)
                    );
        }

        this->cardslong2rank[Card::boardCards2long(cards)] = rank;

        i ++;
        if(i % 1000 == 0) {
            //bar.update();
        }
    }
    //cout << endl;
    fcs.convert(this->cardslong2rank);
    if(!fcs.check(this->cardslong2rank)){
        //fcs.save(dic_dir_bin.c_str());
        throw runtime_error("check consistency failed");
    }
    this->cardslong2rank.clear();
}
```