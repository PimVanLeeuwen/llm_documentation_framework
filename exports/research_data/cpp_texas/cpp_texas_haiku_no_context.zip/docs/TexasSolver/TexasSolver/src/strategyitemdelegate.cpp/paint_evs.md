`paint_evs`: The function of `paint_evs` is to paint a visual representation of a set of expected values (EVs) on a view item.

**Code Description**:
The `paint_evs` function is responsible for rendering a visual representation of a set of expected values (EVs) within a view item. It takes a `QPainter` object, a `QStyleOptionViewItem` object, and a `QModelIndex` object as input parameters.

The function first initializes the `options` variable by calling the `initStyleOption` function, which sets the default style options for the view item. It then casts the `index.model()` to a `TableStrategyModel` object, which is used to retrieve the EV grid for the current row and column of the view item.

The function then sorts the EV values in ascending order and iterates through them. For each EV value, it normalizes the value using the `normalization_tanh` function, which maps the value to a range between 0 and 1. It then calculates the RGB color values based on the normalized EV value, where lower values are represented by a red color and higher values are represented by a green color.

The function then creates a `QBrush` object with the calculated color and uses it to fill a rectangular area within the view item. The width of the rectangle is proportional to the position of the EV value within the sorted list of EV values.

Finally, the function creates a `QTextDocument` object and uses it to draw the text content of the view item on top of the EV visualization. The `drawContents` function is used to render the text within the clipping rectangle defined by the view item's dimensions.

Overall, the `paint_evs` function is responsible for creating a visual representation of a set of EV values within a view item, where the color and width of the rectangles are used to convey information about the relative magnitudes of the EV values.\\
## Code: 
```
void StrategyItemDelegate::paint_evs(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);
    const TableStrategyModel * tableStrategyModel = qobject_cast<const TableStrategyModel*>(index.model());
    vector<float> evs = tableStrategyModel->get_ev_grid(index.row(),index.column());
    sort(evs.begin(), evs.end());

    int last_left = 0;
    for(std::size_t i = 0;i < evs.size();i ++ ){
        float one_ev = evs[evs.size() - i - 1];
        float normalized_ev = normalization_tanh(this->qSolverJob->stack,one_ev);
        //options.text += QString("</br>%1").arg(QString::number(normalized_ev));

        int red = max((int)(255 - normalized_ev * 255),0);
        int green = min((int)(normalized_ev * 255),255);
        int blue = min(red, green);

        QBrush brush = QBrush(QColor(red,green,blue));

        int this_width = (int)((float(i + 1) / evs.size()) * options.rect.width()) - last_left;

        QRect rect(option.rect.left() + last_left, option.rect.top(),\
             this_width , (int) (options.rect.height()));
        painter->fillRect(rect, brush);
        last_left += this_width;
    }
    QTextDocument doc;
    doc.setHtml(options.text);
    options.text = "";
    //options.widget->style()->drawControl(QStyle::CE_ItemViewItem, &option, painter);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```