`run`: The function of `run` is to execute the current mission of the `QSolverJob` object.

**Code Description**: The `run()` function is the main entry point for the `QSolverJob` class. It is responsible for executing the current mission of the object, which can be one of four types: `SOLVING`, `LOADING`, `BUILDTREE`, or `SAVING`.

The function first checks the value of the `current_mission` member variable to determine which type of mission is currently active. Based on the mission type, it calls the corresponding member function (`solving()`, `loading()`, `build_tree()`, or `saving()`).

If the `current_mission` is not one of the supported types, the function throws a `runtime_error` exception with the message "unsupported mission type".

The function also includes a `try-catch` block to handle any exceptions that may be thrown during the execution of the current mission. If an exception is caught, the function logs the error message using the `qDebug()` function.

Overall, the `run()` function is responsible for coordinating the execution of the various tasks that the `QSolverJob` object can perform, and for handling any errors that may occur during those tasks.\\
## Code: 
```
void QSolverJob::run()
{
    //QDebugStream qout(qDebug().noquote(), this->textEdit);
    try{
        if(this->current_mission == MissionType::SOLVING){
            this->solving();
        }else if(this->current_mission == MissionType::LOADING){
            this->loading();
        }else if(this->current_mission == MissionType::BUILDTREE){
            this->build_tree();
        }else if(this->current_mission == MissionType::SAVING){
            this->saving();
        }else{
            throw runtime_error("unsupported mission type");
        }
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```