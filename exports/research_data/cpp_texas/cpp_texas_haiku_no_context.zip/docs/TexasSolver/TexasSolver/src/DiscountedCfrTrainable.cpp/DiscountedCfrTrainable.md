`DiscountedCfrTrainable`: The function of `DiscountedCfrTrainable` is to initialize and store various data structures required for the implementation of a discounted counterfactual regret minimization (DCFR) algorithm.

**Code Description**:
1. The constructor takes two parameters:
   - `privateCards`: a pointer to a vector of `PrivateCards` objects, which likely represent the private cards for each player in a game.
   - `actionNode`: a reference to an `ActionNode` object, which likely represents a node in the game's decision tree.
2. The constructor initializes the following member variables:
   - `privateCards`: a pointer to the `privateCards` vector passed as a parameter.
   - `action_number`: the number of child nodes of the `actionNode` passed as a parameter.
   - `card_number`: the size of the `privateCards` vector passed as a parameter.
3. The constructor then initializes the following vectors:
   - `evs`: a vector of `float` values with a size equal to the product of `action_number` and `card_number`, all initialized to 0.0. This vector likely stores the expected values for each combination of action and private card.
   - `r_plus`: a vector of `float` values with a size equal to the product of `action_number` and `card_number`, all initialized to 0.0. This vector likely stores the positive regrets for each combination of action and private card.
   - `r_plus_sum`: a vector of `float` values with a size equal to `card_number`, all initialized to 0.0. This vector likely stores the sum of the positive regrets for each private card.
   - `cum_r_plus`: a vector of `float` values with a size equal to the product of `action_number` and `card_number`, all initialized to 0.0. This vector likely stores the cumulative positive regrets for each combination of action and private card.
4. The constructor does not initialize the `cum_r_plus_sum` vector, which is commented out. This vector was likely intended to store the cumulative sum of the positive regrets for each private card, but it is not being used in the current implementation\\
## Code: 
```
DiscountedCfrTrainable::DiscountedCfrTrainable(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();

    this->evs = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus_sum = vector<float>(this->card_number,0.0);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number,0.0);
    //this->cum_r_plus_sum = vector<float>(this->card_number);
}
```