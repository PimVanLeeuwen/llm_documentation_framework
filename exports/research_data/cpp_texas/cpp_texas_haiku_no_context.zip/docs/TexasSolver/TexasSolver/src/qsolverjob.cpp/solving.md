`solving`: The function of `solving` is to perform a training process for a poker solver, either in the Holdem or Shortdeck mode, based on the provided parameters.

**Code Description**: The `solving` function is responsible for training a poker solver, which is used to analyze and solve poker game situations. The function first checks the mode of the solver, which can be either Holdem or Shortdeck, and then calls the appropriate training function (`train`) on the corresponding solver object (`ps_holdem` or `ps_shortdeck`).

The training process is configured using several parameters, including:
- `range_ip`: the range of hole cards for the in-position player
- `range_oop`: the range of hole cards for the out-of-position player
- `board`: the community cards on the board
- `max_iteration`: the maximum number of iterations for the training process
- `print_interval`: the interval at which to print progress updates
- `accuracy`: the desired accuracy level for the solver
- `use_isomorphism`: a flag indicating whether to use isomorphism optimization
- `use_halffloats`: a flag indicating whether to use half-precision floating-point numbers
- `thread_number`: the number of threads to use for the training process

The training process is performed using the "discounted_cfr" algorithm, which is a variant of the Counterfactual Regret Minimization (CFR) algorithm, a popular technique for solving extensive-form games like poker.

After the training process is complete, the function prints a message indicating that the solving is done.\\
## Code: 
```
void QSolverJob::solving(){
    // TODO  为什么ui上多次求解会积累memory？哪里leak了？
    // TODO  为什么有时候会莫名闪退？
    qDebug().noquote() << tr("Start Solving..");//.toStdString() << std::endl;

    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }
    qDebug().noquote() << tr("Solving done.");//.toStdString() << std::endl;
}
```