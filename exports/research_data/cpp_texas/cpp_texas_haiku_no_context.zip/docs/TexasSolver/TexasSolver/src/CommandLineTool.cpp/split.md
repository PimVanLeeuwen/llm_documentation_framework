`split`: The function of `split` is to split a given string `s` into a vector of strings `v` using a specified delimiter character `c`.

**Code Description**:

The `split` function takes three parameters:
1. `const string& s`: The input string to be split.
2. `char c`: The delimiter character to be used for splitting the string.
3. `vector<string>& v`: A reference to the vector of strings where the split substrings will be stored.

The function works as follows:

1. It initializes two variables `i` and `j` to keep track of the start and end positions of each substring.
2. It uses a `while` loop to repeatedly find the next occurrence of the delimiter character `c` in the input string `s`.
3. For each occurrence of the delimiter:
   - It extracts the substring from the start position `i` to the current position `j-i` and adds it to the `v` vector.
   - It updates the start position `i` to be one position after the current delimiter `j`.
   - It updates the position `j` to be the next occurrence of the delimiter `c`, starting from the current position `j`.
4. After the loop, if there is any remaining substring (i.e., the last substring after the final delimiter), it extracts and adds that substring to the `v` vector.

The function effectively splits the input string `s` into a vector of substrings `v` using the specified delimiter character `c`. The resulting vector `v` will contain all the substrings, with the delimiter characters removed.\\
## Code: 
```
void split(const string& s, char c,
           vector<string>& v) {
    string::size_type i = 0;
    string::size_type j = s.find(c);

    while (j != string::npos) {
        v.push_back(s.substr(i, j-i));
        i = ++j;
        j = s.find(c, j);

        if (j == string::npos)
            v.push_back(s.substr(i, s.length()));
    }
}
```