`toString`: The function of `toString` is to return a string representation of the two private cards in a specific order.

**Code Description**: The `toString()` method is a member function of the `PrivateCards` class. Its purpose is to convert the two private card values (`card1` and `card2`) into a string representation.

The method first checks if the value of `card1` is greater than the value of `card2`. If so, it calls the `intCard2Str()` function (likely a static method of the `Card` class) to convert `card1` and `card2` to their string representations, and then concatenates them in that order.

If `card1` is not greater than `card2`, the method calls the `intCard2Str()` function to convert `card2` and `card1` to their string representations, and then concatenates them in that order.

The purpose of this logic is to ensure that the string representation of the private cards is always in a consistent order, regardless of the actual values of the cards. This can be useful for various purposes, such as displaying the cards in a user interface or comparing the cards between different instances of the `PrivateCards` class.\\
## Code: 
```
string PrivateCards::toString() {
    if (card1 > card2) {
        return Card::intCard2Str(card1) + Card::intCard2Str(card2);
    }else{
        return Card::intCard2Str(card2) + Card::intCard2Str(card1);
    }
}
```