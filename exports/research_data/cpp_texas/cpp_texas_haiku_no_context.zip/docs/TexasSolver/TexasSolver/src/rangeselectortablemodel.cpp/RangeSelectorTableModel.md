`RangeSelectorTableModel`: The function of `RangeSelectorTableModel` is to create a table model that represents a range selector, which is commonly used in user interfaces to allow users to select a range of values.

**Code Description**:

1. The constructor takes in three parameters:
   - `QStringList ranks`: A list of strings representing the ranks or labels for the rows and columns of the table.
   - `QString initial_board`: A string representing the initial state of the range selector.
   - `QObject *parent`: The parent object of the `RangeSelectorTableModel`.
   - `bool thumbnail`: A boolean flag indicating whether the table model is being used for a thumbnail view.

2. The constructor initializes the following member variables:
   - `ranklist`: Stores the list of ranks or labels for the rows and columns.
   - `thumbnail`: Stores the boolean flag indicating whether the table model is being used for a thumbnail view.
   - `grids_string`: A 2D vector of `QString` values, where each element represents the text to be displayed in the corresponding cell of the table.
   - `string2ij`: A map that maps the text in each cell to the corresponding row and column indices.
   - `grids_float`: A 2D vector of `float` values, where each element represents a numerical value associated with the corresponding cell in the table.

3. The constructor populates the `grids_string` and `string2ij` members by iterating through the `ranklist` and generating the text and index mapping for each cell.

4. The constructor also initializes the `grids_float` member, setting all values to 0.0.

5. Finally, the constructor calls the `setRangeText()` function, which is not shown in the provided code, to set the initial state of the range selector.

The `RangeSelectorTableModel` class is likely used as the underlying data model for a range selector UI component, providing the necessary data and functionality to display and interact with the range selector.\\
## Code: 
```
RangeSelectorTableModel::RangeSelectorTableModel(QStringList ranks,QString initial_board,QObject *parent,bool thumbnail):QAbstractItemModel(parent){
    this->ranklist = ranks;
    this->thumbnail = thumbnail;

    this->grids_string = vector<vector<QString>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_string[i] = vector<QString>(this->ranklist.size());
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_string[i][j] = this->get_ij_text(i,j);
            this->string2ij[this->get_ij_text(i,j)] = pair<int,int>(i,j);
        }
    }

    this->grids_float = vector<vector<float>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_float[i] = vector<float>(this->ranklist.size(),0.0);
    }
    this->setRangeText(initial_board);
}
```