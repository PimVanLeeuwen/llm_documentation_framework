`mousePressEvent`: The function of `mousePressEvent` is to handle mouse press events on the HTML table view.

**Code Description**: The `mousePressEvent` function is overridden from the base class `HtmlTableView`. It performs the following actions:

1. It first calls the `mousePressEvent` function of the base class `HtmlTableView` to handle the default mouse press event behavior.

2. It then retrieves the model index of the table cell at the position where the mouse press event occurred using the `indexAt` function, which takes the event's position as an argument.

3. Finally, it emits a signal called `view_item_pressed`, passing the row and column indices of the pressed table cell as arguments. This signal can be used by other parts of the application to respond to the user's mouse press event on the table view.

The purpose of this code is to provide a custom implementation of the mouse press event handling for the HTML table view, allowing the application to react to user interactions with the table cells. By emitting the `view_item_pressed` signal, other components of the application can be notified of the user's actions and perform additional logic as needed.\\
## Code: 
```
void HtmlTableRangeView::mousePressEvent(QMouseEvent *event) {
    HtmlTableView::mousePressEvent(event);
    QModelIndex index = indexAt(event->pos());
    emit view_item_pressed(index.row(),index.column());
}
```