`getActions`: The function of `getActions` is to return a reference to the `actions` vector stored within the `ActionNode` object.

**Code Description**: The `getActions` function is a member function of the `ActionNode` class. It takes no parameters and returns a reference to the `actions` vector, which is a member variable of the `ActionNode` class. This allows other parts of the code to access and manipulate the `actions` vector associated with the `ActionNode` object.\\
## Code: 
```
vector<GameActions>& ActionNode::getActions() {
    return this->actions;
}
```