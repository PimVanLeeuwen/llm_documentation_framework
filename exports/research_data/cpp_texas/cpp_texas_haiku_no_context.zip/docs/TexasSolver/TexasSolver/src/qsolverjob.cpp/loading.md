`loading`: The function of `loading` is to initialize and load the necessary resources for the PokerSolver class, which is used to compare and evaluate poker hands.

**Code Description**:

1. The function starts by defining the string variables `suits` and `ranks` that represent the suits and ranks of playing cards, respectively.

2. It then sets the `resource_dir` variable to the path where the required resource files are located.

3. The function checks the game mode, which can be either "holdem" or "shortdeck", and loads the appropriate resource files:
   - For "holdem" mode, it sets the `compairer_file` and `compairer_file_bin` variables to the paths of the "card5_dic_sorted.txt" and "card5_dic_zipped.bin" files, respectively, and the `lines` variable to 2,598,961.
   - For "shortdeck" mode, it sets the `compairer_file` and `compairer_file_bin` variables to the paths of the "card5_dic_sorted_shortdeck.txt" and "card5_dic_zipped_shortdeck.bin" files, respectively, and the `lines` variable to 376,993.

4. The function then creates an instance of the `PokerSolver` class, passing the `ranks`, `suits`, `compairer_file`, `lines`, and `compairer_file_bin` variables as arguments. This instance is stored in the `ps_holdem` or `ps_shortdeck` member variable, depending on the game mode.

5. Finally, the function prints a message to the console indicating that the loading process is complete and the system is ready to go.

The purpose of this function is to ensure that the necessary resources for the PokerSolver class are properly loaded and initialized before the class is used to compare and evaluate poker hands. The specific files and parameters loaded depend on the game mode, which can be either "holdem" or "shortdeck".\\
## Code: 
```
void QSolverJob::loading(){
    string suits = "c,d,h,s";
    string ranks;
    this->resource_dir =  ":/resources";
    string compairer_file, compairer_file_bin;
    int lines;
    qDebug().noquote() << tr("Loading holdem compairing file");//.toStdString() << endl;
    //if(mode == "holdem"){
    ranks = "2,3,4,5,6,7,8,9,T,J,Q,K,A";
    compairer_file = this->resource_dir + "/compairer/card5_dic_sorted.txt";
    compairer_file_bin = this->resource_dir + "/compairer/card5_dic_zipped.bin";
    //qDebug().noquote() << compairer_file_bin.c_str();
    lines = 2598961;
    this->ps_holdem = PokerSolver(ranks,suits,compairer_file,lines,compairer_file_bin);

    qDebug().noquote() << tr("Loading shortdeck compairing file");//.toStdString() << endl;
    //}else if(mode == "shortdeck"){
    ranks = "6,7,8,9,T,J,Q,K,A";
    compairer_file = this->resource_dir + "/compairer/card5_dic_sorted_shortdeck.txt";
    compairer_file_bin = this->resource_dir + "/compairer/card5_dic_zipped_shortdeck.bin";
    lines = 376993;
    this->ps_shortdeck = PokerSolver(ranks,suits,compairer_file,lines,compairer_file_bin);
    qDebug().noquote() << tr("Loading finished. Good to go.");//.toStdString() << endl;
}
```