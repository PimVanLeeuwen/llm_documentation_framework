`intToGameRound`: The function of `intToGameRound` is to convert an integer value representing a game round to the corresponding `GameTreeNode::GameRound` enumeration value.

**Code Description**: The `intToGameRound` function takes an integer `round` as input and returns the corresponding `GameTreeNode::GameRound` enumeration value. It uses a `switch` statement to map the integer values to the appropriate `GameRound` enum values:

- If `round` is 0, it sets `game_round` to `GameTreeNode::GameRound::PREFLOP`.
- If `round` is 1, it sets `game_round` to `GameTreeNode::GameRound::FLOP`.
- If `round` is 2, it sets `game_round` to `GameTreeNode::GameRound::TURN`.
- If `round` is 3, it sets `game_round` to `GameTreeNode::GameRound::RIVER`.
- If `round` is any other value, it throws a `runtime_error` with a formatted error message indicating that the `round` value is not found.

The function then returns the `game_round` value, which is the corresponding `GameTreeNode::GameRound` enumeration value for the input `round`.

This function is likely used in a larger context, where an integer value representing a game round needs to be converted to the appropriate `GameRound` enum value for further processing or decision-making.\\
## Code: 
```
GameTreeNode::GameRound GameTreeNode::intToGameRound(int round){
    GameTreeNode::GameRound game_round;
    switch(round){
        case 0:{
            game_round = GameTreeNode::GameRound::PREFLOP;
            break;
        }
        case 1:{
            game_round = GameTreeNode::GameRound::FLOP;
            break;
        }
        case 2:{
            game_round = GameTreeNode::GameRound::TURN;
            break;
        }
        case 3:{
            game_round = GameTreeNode::GameRound::RIVER;
            break;
        }
        default:{
            throw runtime_error(tfm::format("round %s not found",round));
        }
    }
    return game_round;
}
```