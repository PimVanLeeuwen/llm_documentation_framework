`copyStrategy`: The function of `copyStrategy` is to copy the strategy of another `DiscountedCfrTrainable` object to the current object.

**Code Description**: The `copyStrategy` function takes a shared pointer to a `Trainable` object as input and casts it to a shared pointer to a `DiscountedCfrTrainable` object. It then copies the values of the `r_plus` and `cum_r_plus` vectors from the input `DiscountedCfrTrainable` object to the corresponding vectors in the current object.

The `r_plus` vector likely represents the positive rewards obtained during the training process, and the `cum_r_plus` vector likely represents the cumulative positive rewards. By copying these values from the input `DiscountedCfrTrainable` object, the function effectively transfers the strategy or learned parameters from the input object to the current object.

This function is useful when you want to copy the learned strategy or parameters from one `DiscountedCfrTrainable` object to another, for example, when you want to initialize a new `DiscountedCfrTrainable` object with the same strategy as an existing one.\\
## Code: 
```
void DiscountedCfrTrainable::copyStrategy(shared_ptr<Trainable> other_trainable){
    shared_ptr<DiscountedCfrTrainable> trainable = dynamic_pointer_cast<DiscountedCfrTrainable>(other_trainable);
    this->r_plus.assign(trainable->r_plus.begin(),trainable->r_plus.end());
    this->cum_r_plus.assign(trainable->cum_r_plus.begin(),trainable->cum_r_plus.end());
}
```