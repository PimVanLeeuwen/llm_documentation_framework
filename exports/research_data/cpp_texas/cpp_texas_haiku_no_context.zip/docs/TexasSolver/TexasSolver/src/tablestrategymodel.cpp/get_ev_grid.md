`get_ev_grid`: The function of `get_ev_grid` is to retrieve the expected value (EV) grid for a given set of strategies in a game tree.

**Code Description**:

The `get_ev_grid` function takes two integer parameters, `i` and `j`, and returns a vector of floats representing the expected values for the strategies associated with the given indices.

The function first checks if the `treeItem` is not null and the `current_evs` vector is not empty. If either of these conditions is not met, the function returns an empty vector.

Next, the function determines the number of strategies associated with the given indices `i` and `j` by checking the size of the `ui_strategy_table[i][j]` vector.

The function then retrieves the `GameTreeNode` associated with the current state of the game tree. If the node is an `ActionNode`, the function iterates over the strategies associated with the given indices and calculates the expected value for each strategy. The expected value is calculated by taking the dot product of the strategy vector and the corresponding expected value vector.

The calculated expected values are then added to the `ret_evs` vector, which is returned by the function.

If the `GameTreeNode` is not an `ActionNode`, the function simply returns the empty `ret_evs` vector.

Overall, the `get_ev_grid` function is responsible for retrieving the expected values for a set of strategies in a game tree, which is likely used in a larger game-playing or decision-making system.\\
## Code: 
```
const vector<float> TableStrategyModel::get_ev_grid(int i,int j)const{
    vector<float> ret_evs;
    if(this->treeItem == NULL || this->current_evs.empty())return ret_evs;

    int strategy_number = this->ui_strategy_table[i][j].size();

    shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();

    if(node->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);

        vector<GameActions>& gameActions = actionNode->getActions();

//        vector<float> strategies;

//        if(this->ui_strategy_table[i][j].size() > 0){
//            strategies = vector<float>(gameActions.size());
//            std::fill(strategies.begin(), strategies.end(), 0.);
//        }
        for(std::pair<int,int> index:this->ui_strategy_table[i][j]){
            int index1 = index.first;
            int index2 = index.second;
            const vector<float>& one_strategy = this->current_strategy[index1][index2];
            const vector<float>& one_ev = this->current_evs[index1][index2];
            if(one_ev.size() != one_strategy.size()) return vector<float>();

            if(gameActions.size() != one_strategy.size()){
                cout << "index: " << index1 << " " << index2 << endl;
                cout << "i,j: " << i << " " << j << endl;
                cout << "size not match between gameAction and stragegy: " << gameActions.size() << " " << one_strategy.size() << endl;
                throw runtime_error("size not match between gameAction and stragegy");
            }
            float one_ev_float = 0;
            for(std::size_t indi = 0;indi < one_strategy.size();indi ++){
                one_ev_float += one_strategy[indi] * one_ev[indi];
            }
            ret_evs.push_back(one_ev_float);
        }

        return ret_evs;
    }else{
        return ret_evs;
    }
}
```