`RiverRangeManager`: The function of `RiverRangeManager` is to manage the range of a river.

**Code Description**: The `RiverRangeManager` class is a C++ class that is responsible for managing the range of a river. The class has two member variables:

1. `handEvaluator`: This is a shared pointer to a `Compairer` object, which is likely used to evaluate the hands of players or entities in the game or application.

2. `maplock`: This is a shared pointer to a `std::mutex` object, which is likely used to provide thread-safe access to shared resources in the application.

The constructor of the `RiverRangeManager` class takes a shared pointer to a `Compairer` object as a parameter and initializes the `handEvaluator` member variable with it. The `std::move` function is used to move the ownership of the `Compairer` object to the `RiverRangeManager` object, rather than copying it.

The constructor also creates a new `std::mutex` object and assigns it to the `maplock` member variable using `std::make_shared`.

Overall, the `RiverRangeManager` class is likely part of a larger application or game that involves managing the range of a river, and it uses a `Compairer` object to evaluate hands or entities, and a `std::mutex` object to provide thread-safe access to shared resources.\\
## Code: 
```
RiverRangeManager::RiverRangeManager(shared_ptr<Compairer> handEvaluator) {
    this->handEvaluator = std::move(handEvaluator);
    this->maplock = std::make_shared<std::mutex>();
}
```