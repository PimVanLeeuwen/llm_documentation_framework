`get_payoffs`: The function of `get_payoffs` is to return the payoffs for the players based on the result of a showdown.

**Code Description**: The `get_payoffs` function takes two parameters: `ShowdownNode::ShowDownResult result` and `int winner`. It checks the value of `result` to determine the appropriate payoffs to return.

If `result` is `ShowDownResult::NOTTIE`, it means the showdown was not a tie. In this case, the function checks the value of `winner`. If `winner` is `-1`, it throws a `runtime_error` because a winner should not be `-1` in a non-tie scenario. Otherwise, it returns the payoffs for the player who won the showdown, which are stored in the `player_payoffs` vector.

If `result` is not `ShowDownResult::NOTTIE`, it means the showdown was a tie. In this case, the function checks the value of `winner`. If `winner` is not `-1`, it throws a `runtime_error` because a winner should be `-1` in a tie scenario. Otherwise, it returns the `tie_payoffs` vector, which contains the payoffs for a tied showdown.

The function is designed to handle two possible scenarios: a non-tie showdown with a valid winner, and a tie showdown. It ensures that the input parameters are consistent with the expected values for each scenario, and it returns the appropriate payoffs accordingly.\\
## Code: 
```
vector<double> ShowdownNode::get_payoffs(ShowdownNode::ShowDownResult result, int winner) {
    if(result == ShowDownResult::NOTTIE){
        if(winner == -1) throw runtime_error("winner == -1 in tie");
        vector<double> retval = player_payoffs[winner];
        return retval;
    }else{
        // if the showdown is a tie
        if(winner != -1) throw runtime_error("winner != -1 in not tie");
        return this->tie_payoffs;
    }
}
```