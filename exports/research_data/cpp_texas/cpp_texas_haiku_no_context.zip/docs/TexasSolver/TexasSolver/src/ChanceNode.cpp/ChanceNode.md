`ChanceNode`: The function of `ChanceNode` is to represent a node in a game tree where a chance event occurs, such as the dealing of cards.

**Code Description**: The `ChanceNode` class is a derived class of the `GameTreeNode` class. It represents a node in a game tree where a chance event occurs, such as the dealing of cards. The constructor takes the following parameters:

1. `children`: a `shared_ptr` to a `GameTreeNode` object representing the children of the current node.
2. `round`: a `GameTreeNode::GameRound` object representing the current round of the game.
3. `pot`: a `double` representing the current pot size.
4. `parent`: a `shared_ptr` to a `GameTreeNode` object representing the parent of the current node.
5. `cards`: a `vector` of `Card` objects representing the cards dealt in the current node.
6. `donk`: a `bool` indicating whether the current node represents a "donk" bet.

The constructor initializes the `GameTreeNode` base class with the `round`, `pot`, and `parent` parameters, and then sets the `children` and `cards` member variables. The `donk` member variable is also set to the value passed in the constructor.

The purpose of the `ChanceNode` class is to represent a node in the game tree where a chance event occurs, such as the dealing of cards. This allows the game tree to model the different possible outcomes of these chance events and the resulting game states. The `cards` member variable stores the cards dealt in the current node, which can be used to determine the game state and the possible actions that can be taken.

The `donk` member variable is a boolean flag that indicates whether the current node represents a "donk" bet, which is a type of bet made in poker where a player bets out of position. This information can be used to determine the appropriate strategy for the current game state.

Overall, the `ChanceNode` class is an important component of the game tree data structure, as it allows the game to model the different possible outcomes of chance events and the resulting game states.\\
## Code: 
```
ChanceNode::ChanceNode(const shared_ptr<GameTreeNode> children, GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent,
                       const vector<Card>& cards,bool donk): GameTreeNode(round,pot,std::move(parent)),cards(cards) {
    this->children = children;
    this->donk = donk;
}
```