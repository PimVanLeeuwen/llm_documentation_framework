`compair`: The function of `compair` is to compare the ranks of two hands of cards and return the result of the comparison.

**Code Description**: The `compair` function takes three parameters: `private_former`, `private_latter`, and `public_board`. These are all vectors of integers representing the cards in the hands of two players and the community cards on the board.

The function first checks that the sizes of the `private_former`, `private_latter`, and `public_board` vectors are correct (2, 2, and 5, respectively). If any of the sizes are incorrect, it throws a `runtime_error` with a message indicating the expected and actual sizes.

Next, the function creates two new vectors, `former_cards` and `latter_cards`, by combining the `private_former` and `public_board` vectors, and the `private_latter` and `public_board` vectors, respectively. It then calls the `getRank` function (which is not shown in the provided code) to determine the rank of each hand.

Finally, the function calls the `compairRanks` function (which is also not shown in the provided code) to compare the ranks of the two hands and returns the result of the comparison.

The purpose of this code is to determine the winner of a hand of poker or a similar card game, where each player has two private cards and there are five community cards on the board. The `compair` function is responsible for evaluating the strength of each player's hand and returning the result of the comparison.\\
## Code: 
```
Compairer::CompairResult
Dic5Compairer::compair(vector<int> private_former, vector<int> private_latter, vector<int> public_board) {
    if(private_former.size() != 2)
        throw runtime_error(
                tfm::format("private former size incorrect,excepted 2, actually %s",private_former.size())
        );
    if(private_latter.size() != 2)
        throw runtime_error(
                tfm::format("private latter size incorrect,excepted 2, actually %s",private_latter.size())
        );
    if(public_board.size() != 5)
        throw runtime_error(
                tfm::format("public board size incorrect,excepted 2, actually %s",public_board.size())
        );

    vector<int> former_cards(private_former);
    former_cards.insert(former_cards.end(),public_board.begin(),public_board.end());
    int rank_former = this->getRank(former_cards);

    vector<int> latter_cards(private_latter);
    latter_cards.insert(latter_cards.end(),public_board.begin(),public_board.end());
    int rank_latter = this->getRank(latter_cards);

    return this->compairRanks(rank_former,rank_latter);
}
```