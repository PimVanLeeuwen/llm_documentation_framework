`setBoardText`: The function of `setBoardText` is to update the board text displayed in the application.

**Code Description**: The `setBoardText` function takes a QString `input_board` as a parameter, which represents the new board text to be displayed. The function performs the following steps:

1. It first calls the `clear_board()` function to reset the board, effectively clearing any previous board text.

2. It then splits the `input_board` string by commas, creating a list of individual board entries.

3. For each board entry in the list, the function performs the following checks:
   - If the board entry consists entirely of spaces or is an empty string, it is skipped.
   - If the board entry is not found in the `string2ij` map, which maps board entries to their corresponding grid coordinates, a debug message is printed, and the entry is skipped.
   - If the board entry is valid, the function retrieves the corresponding grid coordinates from the `string2ij` map and sets the `grids_float` value at those coordinates to `1.0`.

The purpose of this function is to update the board display in the application based on the provided input string. It clears the previous board, processes each individual board entry, and updates the corresponding grid values in the `grids_float` array. This allows the application to display the new board configuration based on the provided input.\\
## Code: 
```
void BoardSelectorTableModel::setBoardText(QString input_board){
    this->clear_board();
    for(QString one_board:input_board.split(",")){
        float board_float = 1.0;


        if(one_board.count(" ") == one_board.length() || one_board == "")continue;
        if(!this->string2ij.count(one_board)){
            qDebug().noquote() << QString(tr("skipping board %1, format error")).arg(one_board);
            continue;
        }
        pair<int,int> cord = this->string2ij[one_board];
        this->grids_float[cord.first][cord.second] = board_float;
    }
}
```