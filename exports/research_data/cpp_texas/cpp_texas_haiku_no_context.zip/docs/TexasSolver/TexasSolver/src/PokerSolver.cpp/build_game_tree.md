`build_game_tree`: The function of `build_game_tree` is to create a new `GameTree` object and assign it to the `game_tree` member variable of the `PokerSolver` class.

**Code Description**: The `build_game_tree` function takes several parameters that define the characteristics of the poker game being solved:

1. `oop_commit`: The amount of money committed by the out-of-position player.
2. `ip_commit`: The amount of money committed by the in-position player.
3. `current_round`: The current round of the game (e.g., preflop, flop, turn, river).
4. `raise_limit`: The maximum number of raises allowed in the current round.
5. `small_blind`: The amount of the small blind.
6. `big_blind`: The amount of the big blind.
7. `stack`: The amount of money each player has in their stack.
8. `buildingSettings`: A set of settings that control the behavior of the `GameTree` object being created.
9. `allin_threshold`: The threshold at which a player is considered to be all-in.

The function then creates a new `GameTree` object using the provided parameters and assigns it to the `game_tree` member variable of the `PokerSolver` class. The `GameTree` object represents the game tree for the current state of the poker game, which can be used to analyze and solve the game.

The `make_shared` function is used to create a shared pointer to the new `GameTree` object, which ensures that the object is properly managed and can be shared across multiple parts of the code.

Overall, the `build_game_tree` function is an important part of the `PokerSolver` class, as it sets up the game tree that will be used to analyze and solve the poker game.\\
## Code: 
```
void PokerSolver::build_game_tree(
        float oop_commit,
        float ip_commit,
        int current_round,
        int raise_limit,
        float small_blind,
        float big_blind,
        float stack,
        GameTreeBuildingSettings buildingSettings,
        float allin_threshold
){
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(
            this->deck,
            oop_commit,
            ip_commit,
            current_round,
            raise_limit,
            small_blind,
            big_blind,
            stack,
            buildingSettings,
            allin_threshold
    );
    this->game_tree = game_tree;
}
```