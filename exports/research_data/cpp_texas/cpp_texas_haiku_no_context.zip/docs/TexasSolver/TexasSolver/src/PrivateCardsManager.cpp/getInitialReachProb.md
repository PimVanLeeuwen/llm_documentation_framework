`getInitialReachProb`: The function of `getInitialReachProb` is to calculate the initial reach probability for each private card of a given player based on the initial game board.

**Code Description**:
The `getInitialReachProb` function takes two parameters: `player` (an integer representing the player) and `initialboard` (a 64-bit unsigned integer representing the initial game board). The function returns a vector of float values, where each value represents the initial reach probability for a private card of the given player.

The function first determines the number of private cards for the given player by accessing the `private_cards` vector. It then initializes a vector of float values `probs` with the same length as the number of private cards.

For each private card, the function checks if the card's hands (represented as a 64-bit unsigned integer) have an intercept with the initial game board. If there is an intercept, the reach probability for that card is set to 0, as the card cannot be part of the initial game board. If there is no intercept, the reach probability for that card is set to the `weight` property of the `PrivateCards` object.

Finally, the function returns the vector of initial reach probabilities for the given player's private cards.

This function is likely used in a game engine or simulation to determine the initial probabilities of each player's private cards based on the initial game state. This information can be used for various purposes, such as decision-making, strategy analysis, or probability calculations.\\
## Code: 
```
vector<float> PrivateCardsManager::getInitialReachProb(int player, uint64_t initialboard) {
    int cards_len =  this->private_cards[player].size();
    vector<float> probs = vector<float>(cards_len);
    for(int i = 0;i < cards_len;i ++){
        PrivateCards pc = this->private_cards[player][i];
        if(Card::boardsHasIntercept(initialboard,Card::boardInts2long(pc.get_hands()))) {
            probs[i] = 0;
        }else{
            probs[i] = this->private_cards[player][i].weight;
        }
    }
    return probs;
}
```