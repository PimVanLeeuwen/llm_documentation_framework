`getBoardText`: The function of `getBoardText` is to generate a comma-separated string of all the non-zero board values in the `grids_string` array.

**Code Description**: The `getBoardText` function is a member function of the `BoardSelectorTableModel` class. It iterates through the `suitlist` and `ranklist` arrays, and for each non-zero value in the `grids_float` array, it appends the corresponding value from the `grids_string` array to the `retval` string, separated by commas. If the `retval` string is initially empty, the first value is simply assigned to it. Otherwise, the new value is appended with a comma. Finally, the function returns the `retval` string, which contains the comma-separated list of all non-zero board values.\\
## Code: 
```
QString BoardSelectorTableModel::getBoardText(){
    QString retval = "";
    for(int i = 0;i < this->suitlist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            if(this->grids_float[i][j] == 0)continue;
            QString one_board_str = QString("%1").arg(this->grids_string[i][j]);
            if(retval == ""){
                retval = one_board_str;
            }else{
                retval = retval + "," + one_board_str;
            }
        }
    }
    return retval;
}
```