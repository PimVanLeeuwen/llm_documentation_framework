`GameTreeBuildingSettings`: The function of `GameTreeBuildingSettings` is to initialize and store various settings related to the game tree building process.

**Code Description**: The `GameTreeBuildingSettings` class is a constructor that takes six parameters:
1. `flop_ip`: A `StreetSetting` object representing the settings for the flop street when the player is in the "in-position" (IP) situation.
2. `turn_ip`: A `StreetSetting` object representing the settings for the turn street when the player is in the IP situation.
3. `river_ip`: A `StreetSetting` object representing the settings for the river street when the player is in the IP situation.
4. `flop_oop`: A `StreetSetting` object representing the settings for the flop street when the player is in the "out-of-position" (OOP) situation.
5. `turn_oop`: A `StreetSetting` object representing the settings for the turn street when the player is in the OOP situation.
6. `river_oop`: A `StreetSetting` object representing the settings for the river street when the player is in the OOP situation.

The constructor initializes the member variables of the `GameTreeBuildingSettings` class with the provided `StreetSetting` objects. These settings are likely used in the game tree building process, where the game tree represents the possible sequences of actions and outcomes in a game.

The purpose of this class is to provide a centralized way to manage and store the various settings related to the game tree building process, making it easier to configure and maintain these settings across different parts of the application.\\
## Code: 
```
GameTreeBuildingSettings::GameTreeBuildingSettings(
        StreetSetting flop_ip,
        StreetSetting turn_ip,
        StreetSetting river_ip,
        StreetSetting flop_oop,
        StreetSetting turn_oop,
        StreetSetting river_oop):flop_ip(flop_ip),turn_ip(turn_ip),river_ip(river_ip),flop_oop(flop_oop),turn_oop(turn_oop),river_oop(river_oop) {
}
```