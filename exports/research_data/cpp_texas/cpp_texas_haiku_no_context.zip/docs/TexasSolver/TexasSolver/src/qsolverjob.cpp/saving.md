`saving`: The function of `saving` is to save the current state of the QSolverJob object to a JSON file.

**Code Description**: The `saving()` function is responsible for saving the current state of the QSolverJob object to a JSON file. It performs the following steps:

1. Prints a debug message indicating that the JSON file is being saved.
2. Retrieves the "dump_round" setting from the application's settings using the QSettings class. This setting determines the number of rounds to be dumped to the file.
3. Prints a debug message displaying the current value of the "dump_round" setting.
4. Checks if the "dump_round" setting is set to 3, which could potentially be slow or cause high memory usage due to the optimization of the "dump to river" feature.
5. Depending on the current mode of the QSolverJob object (either HOLDEM or SHORTDECK), it calls the `dump_strategy()` function of the corresponding `ps_holdem` or `ps_shortdeck` object, passing the `savefile` and `dump_rounds` parameters.
6. Prints a debug message indicating that the saving process is complete.

The purpose of this function is to save the current state of the QSolverJob object, including the strategy information, to a JSON file for later use or analysis. The function uses the QSettings class to retrieve the "dump_round" setting, which determines the level of detail to be included in the saved file. It also provides some debug messages to help with troubleshooting and monitoring the saving process.\\
## Code: 
```
void QSolverJob::saving(){
    qDebug().noquote() << tr("Saving json file..");//.toStdString() << std::endl;

    QSettings setting("TexasSolver", "Setting");
    setting.beginGroup("solver");
    this->dump_rounds = setting.value("dump_round").toInt();

    qDebug().noquote() << tr("Dump round: ") << this->dump_rounds;
    if(this->dump_rounds == 3){
        qDebug().noquote() << tr("This could be slow, or even blow your RAM, dump to river is not well optimized :(");
    }
    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.dump_strategy(this->savefile,this->dump_rounds);
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.dump_strategy(this->savefile,this->dump_rounds);
    }
    qDebug().noquote() << tr("Saving done.");//.toStdString() << std::endl;
}
```