`rangeStr2Cards`: The function of `rangeStr2Cards` is to convert a string representation of a range of private cards into a vector of `PrivateCards` objects.

**Code Description**:

The `rangeStr2Cards` function takes two parameters: a string `range_str` representing the range of private cards, and a vector of integers `initial_boards` representing the initial board cards. The function then performs the following steps:

1. It splits the `range_str` into a vector of individual ranges using the `string_split` function.
2. It iterates through each individual range in the vector and processes it as follows:
   - It creates a new `PrivateCards` object to store the current range.
   - It splits the individual range string into two parts using the `:` character. The first part represents the card range, and the second part (if present) represents the weight of the range.
   - It checks if the range string is valid (i.e., has no more than two parts separated by `:`).
   - It sets the weight of the `PrivateCards` object to 1.0 by default, or to the value specified in the second part of the range string if present.
   - It skips the current range if the weight is less than or equal to 0.005.
   - It processes the card range based on its length and format:
     - If the range string is 3 characters long and the last character is `s`, it assumes the range represents a suited range and generates all possible suited combinations of the two ranks.
     - If the range string is 3 characters long and the last character is `o`, it assumes the range represents an offsuit range and generates all possible offsuit combinations of the two ranks, excluding any combinations that intersect with the `initial_boards`.
     - If the range string is 2 characters long, it generates all possible combinations of the two ranks, excluding any combinations that intersect with the `initial_boards`.
   - It adds the generated `PrivateCards` object to the `private_cards` vector.
3. After processing all the individual ranges, it checks for any duplicate `PrivateCards` objects in the `private_cards` vector and throws an error if any are found.
4. It creates\\
## Code: 
```
vector<PrivateCards> PrivateRangeConverter::rangeStr2Cards(string range_str, vector<int> initial_boards) {
    vector<string> range_list = string_split(range_str,',');
    vector<PrivateCards> private_cards;

    for(string one_range:range_list){
        PrivateCards this_card;
        vector<string> cardstr_arr = string_split(one_range,':');
        if (cardstr_arr.size() > 2 || cardstr_arr.empty()){
            throw runtime_error("':' number exceeded 2");
        }
        float weight = 1;

        one_range = cardstr_arr[0];
        if(cardstr_arr.size() == 2){
            weight = atof(cardstr_arr[1].c_str());
        }
        if(weight <= 0.005){
            continue;
        }

        int range_len = one_range.length();
        // TODO finish here , convert str to a PrivateRanges[]
        if(range_len == 3){
            if(one_range.at(2) == 's'){
                char rank1 = one_range.at(0);
                char rank2 = one_range.at(1);
                if(rank1 == rank2) throw runtime_error(tfm::format("%s%ss is not a valid card desc",rank1,rank2));
                for(const string& one_suit :Card::getSuits()){
                    int card1 = Card::strCard2int(rank1 + one_suit);
                    int card2 = Card::strCard2int(rank2 + one_suit);
                    this_card = PrivateCards(card1,card2,weight);
                    private_cards.push_back(this_card);
                }

            }else if(one_range.at(2) == 'o'){
                char rank1 = one_range.at(0);
                char rank2 = one_range.at(1);

                vector<string> suits = Card::getSuits();
                for(std::size_t i = 0;i < suits.size();i++){
                    string one_suit = suits[i];
                    int begin_index = rank1 == rank2 ? i:0;
                    for(std::size_t j = begin_index;j < suits.size();j++){
                        string another_suit = suits[j];
                        if(one_suit == another_suit){
                            continue;
                        }
                        int card1 = Card::strCard2int(rank1 + one_suit);
                        int card2 = Card::strCard2int(rank2 + another_suit);
                        if(Card::boardsHasIntercept(
                                Card::boardInts2long(vector<int>{card1,card2}),
                                Card::boardInts2long(initial_boards)
                        )){
                            continue;
                        }
                        this_card = PrivateCards(card1, card2, weight);
                        private_cards.push_back(this_card);
                    }
                }
            }else{
                throw runtime_error("format not recognize");
            }
        }else if(range_len == 2){
            char rank1 = one_range.at(0);
            char rank2 = one_range.at(1);
            vector<string> suits = Card::getSuits();
            for(std::size_t i = 0;i < suits.size();i++){
                string one_suit = suits[i];
                int begin_index = rank1 == rank2 ? i:0;
                for(std::size_t j = begin_index;j < suits.size();j++){
                    string another_suit = suits[j];
                    if(one_suit == another_suit && rank1 == rank2){
                        continue;
                    }
                    int card1 = Card::strCard2int(rank1 + one_suit);
                    int card2 = Card::strCard2int(rank2 + another_suit);
                    if(Card::boardsHasIntercept(
                            Card::boardInts2long(vector<int>{card1,card2}),
                            Card::boardInts2long(initial_boards)
                    )){
                        continue;
                    }
                    this_card = PrivateCards(card1, card2, weight);
                    private_cards.push_back(this_card);
                }
            }

        }else throw runtime_error(tfm::format(" range str %s len not valid ",one_range));
    }

    // 排除初试range中重复的情况
    for(std::size_t i = 0;i < private_cards.size();i ++){
        for(std::size_t j = i + 1;j < private_cards.size();j ++) {
            PrivateCards one_cards = private_cards[i];
            PrivateCards another_cards = private_cards[j];
            if (one_cards.card1 == another_cards.card1 && one_cards.card2 == another_cards.card2){
                throw runtime_error(tfm::format("card %s %s duplicate"
                        , Card::intCard2Str(one_cards.card1)
                        , Card::intCard2Str(one_cards.card2)
                ));
            }
            if(one_cards.card1 == another_cards.card2 && one_cards.card2 == another_cards.card1) {
                throw runtime_error(tfm::format("card %s %s duplicate"
                        , Card::intCard2Str(one_cards.card1)
                        , Card::intCard2Str(one_cards.card2)
                ));
            }
        }
    }

    vector<PrivateCards> private_cards_list(private_cards.size());
    for(std::size_t i = 0;i < private_cards.size();i ++){
        private_cards_list[i] = private_cards[i];
        //System.out.print(String.format("[%s-%s]",Card.intCard2Str(private_cards_list[i].card1),Card.intCard2Str(private_cards_list[i].card2)));
    }
    /*
        output all private combos

    System.out.println("private range number:");
    System.out.println(private_cards.size());
    System.out.println();
     */
    return private_cards_list;

}
```