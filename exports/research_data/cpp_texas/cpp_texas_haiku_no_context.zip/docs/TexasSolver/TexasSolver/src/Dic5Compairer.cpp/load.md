`load`: The function of `load` is to load data from a file specified by the `file_path` parameter and store it in two separate maps, `flush_map` and `other_map`.

**Code Description**:

1. The function first attempts to open the file specified by the `file_path` parameter using the `QFile` class. If the file cannot be opened, it throws a `runtime_error` exception with the message "unable to load compairer file".

2. After successfully opening the file, the function clears the `flush_map` and `other_map` maps.

3. The function then reads the first integer value from the file, which represents the number of entries in the first map (`flush_map`). It then reads each entry, which consists of a 64-bit unsigned integer key and an integer value, and stores them in the `flush_map`.

4. After reading all the entries for the `flush_map`, the function reads the number of entries for the second map (`other_map`) and then reads and stores each entry in the `other_map`.

5. Finally, the function asserts that the number of entries read for each map matches the expected count, and then closes the file.

6. The function returns `true` if the file was successfully loaded, indicating that the operation was successful.

Overall, this function is used to load data from a file into two separate maps, which can be used for further processing or analysis by the application.\\
## Code: 
```
bool FiveCardsStrength::load(const char* file_path) {
    //ifstream file(file_path, ios::binary);
    /*if (!file) {
        file.close();
        return false;
    }*/

    QFile file(QString::fromStdString(file_path));
    if (!file.open(QIODevice::ReadOnly)){
        throw runtime_error("unable to load compairer file");
    }
    flush_map.clear(); other_map.clear();
    int size_key = sizeof(uint64_t), size_int = sizeof(int), val, cnt = 0;
    uint64_t key = 0;
    char* p_key = (char*)&key, * p_val = (char*)&val, * p_cnt = (char*)&cnt;
    file.read(p_cnt, size_int);// 读取行数
    for (int i = 0; i < cnt; i++) {
        file.read(p_key, size_key);
        file.read(p_val, size_int);
        flush_map[key] = val;
    }
    assert(flush_map.size() == cnt);
    file.read(p_cnt, size_int);// 读取行数
    for (int i = 0; i < cnt; i++) {
        file.read(p_key, size_key);
        file.read(p_val, size_int);
        other_map[key] = val;
    }
    assert(other_map.size() == cnt);
    file.close();
    return true;
}
```