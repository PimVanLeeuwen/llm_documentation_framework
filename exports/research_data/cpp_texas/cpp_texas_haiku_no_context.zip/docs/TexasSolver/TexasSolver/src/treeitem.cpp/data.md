`data`: The function of `data` is to retrieve the data associated with the current `TreeItem` object.

**Code Description**: The `data()` function of the `TreeItem` class is responsible for providing the data representation of the current `TreeItem` object. It performs the following tasks:

1. Retrieves the parent `GameTreeNode` of the current `TreeItem` using the `getParent()` method of the `m_treedata` object.
2. Retrieves the current `GameTreeNode` associated with the `TreeItem` using the `lock()` method of the `m_treedata` object.
3. Checks if the parent `GameTreeNode` is `nullptr`, which indicates that the current `TreeItem` represents the beginning of a game round. In this case, it returns a string that includes the round information.
4. If the parent `GameTreeNode` is of type `ACTION`, it retrieves the actions and child nodes associated with the parent `ActionNode`. It then finds the index of the current `GameTreeNode` among the child nodes and constructs a string that includes the player's position (IP or OOP) and the game action performed.
5. If the parent `GameTreeNode` is of type `CHANCE`, it checks the game round and returns a corresponding string indicating the dealing of a flop, turn, or river card.
6. If the parent `GameTreeNode` is not recognized, it returns the string "NodeError".

The `data()` function is an important part of the `TreeItem` class, as it provides the necessary information to represent the current state of the game tree in a user-friendly format.\\
## Code: 
```
QVariant TreeItem::data() const
{
    shared_ptr<GameTreeNode> parentNode = this->m_treedata.lock()->getParent();
    shared_ptr<GameTreeNode> currentNode = this->m_treedata.lock();
    if(parentNode == nullptr){
        return TreeItem::get_round_str(currentNode->getRound()) + QObject::tr(" begin");
    }
    if(parentNode->getType() == GameTreeNode::GameTreeNodeType::ACTION){
        shared_ptr<ActionNode> parentActionNode = dynamic_pointer_cast<ActionNode>(parentNode);
        vector<GameActions>& actions = parentActionNode->getActions();
        vector<shared_ptr<GameTreeNode>>& childrens = parentActionNode->getChildrens();
        for(std::size_t i = 0;i < childrens.size();i ++){
            if(childrens[i] == currentNode){
                float amount = childrens[i]->getPot() - parentNode->getPot();
                return (parentActionNode->getPlayer() == 0 ? QObject::tr("IP "):QObject::tr("OOP ")) + \
                       TreeItem::get_game_action_str(actions[i].getAction(),actions[i].getAmount());
            }
        }
    }if(parentNode->getType() == GameTreeNode::GameTreeNodeType::CHANCE){
        shared_ptr<ChanceNode> chanceNode = dynamic_pointer_cast<ChanceNode>(parentNode);
        if(chanceNode->getRound() == GameTreeNode::GameRound::FLOP){
            return QObject::tr("DEAL FLOP CARD");
        }
        else if(chanceNode->getRound() == GameTreeNode::GameRound::TURN){
            return QObject::tr("DEAL TURN CARD");
        }
        else if(chanceNode->getRound() == GameTreeNode::GameRound::RIVER){
            return QObject::tr("DEAL RIVER CARD");
        }else throw runtime_error("round not recognized");
    }
    return "NodeError";
}
```