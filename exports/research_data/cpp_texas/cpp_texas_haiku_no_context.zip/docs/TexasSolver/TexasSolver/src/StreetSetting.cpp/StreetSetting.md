`StreetSetting`: The function of `StreetSetting` is to initialize and store various betting-related parameters for a specific street in a poker game.

**Code Description**:
The `StreetSetting` class is a constructor that takes in four parameters:
1. `bet_sizes`: a vector of float values representing the possible bet sizes for the current street.
2. `raise_sizes`: a vector of float values representing the possible raise sizes for the current street.
3. `donk_sizes`: a vector of float values representing the possible donk bet sizes for the current street.
4. `allin`: a boolean value indicating whether an all-in bet is allowed for the current street.

The constructor initializes the class member variables `bet_sizes`, `raise_sizes`, `donk_sizes`, and `allin` with the values passed in as arguments. This allows the class to store and manage the various betting-related parameters for a specific street in a poker game.

The purpose of this class is to encapsulate and provide access to the different betting options and configurations for a particular street, which can be useful in the context of a poker game engine or simulation.\\
## Code: 
```
StreetSetting::StreetSetting(vector<float> bet_sizes, vector<float> raise_sizes, vector<float> donk_sizes,
                             bool allin) {
    this->bet_sizes = bet_sizes;
    this->raise_sizes = raise_sizes;
    this->donk_sizes = donk_sizes;
    this->allin = allin;
}
```