`getAverageStrategy`: The function of `getAverageStrategy` is to calculate the average strategy for a given set of actions and cards.

**Code Description**: The `getAverageStrategy` function is responsible for calculating the average strategy for a set of actions and cards. It does this by iterating through each card and calculating the sum of the cumulative rewards (represented by `cum_r_plus`) for each action. It then divides the cumulative reward for each action by the total sum of rewards to get the average strategy for that action and card. If the total sum of rewards is 0, it assigns an equal probability of 1/action_number to each action. The final result is a vector of float values representing the average strategy, which is returned by the function.

The function first initializes an empty vector `average_strategy` with a size equal to the product of `action_number` and `card_number`. It then iterates through each card, calculating the sum of the cumulative rewards for all actions for that card. It then iterates through each action for that card, calculating the average strategy for that action and card and storing it in the `average_strategy` vector. Finally, it returns the `average_strategy` vector.\\
## Code: 
```
const vector<float> DiscountedCfrTrainableSF::getAverageStrategy() {
    vector<float> average_strategy;
    average_strategy = vector<float>(this->action_number * this->card_number);
    for (int private_id = 0; private_id < this->card_number; private_id++) {
        float r_plus_sum = 0;
        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            r_plus_sum += this->cum_r_plus[index];
        }

        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            if(r_plus_sum) {
                average_strategy[index] = this->cum_r_plus[index] / r_plus_sum;
            }else{
                average_strategy[index] = 1.0 / this->action_number;
            }
        }
    }
    return average_strategy;
}
```