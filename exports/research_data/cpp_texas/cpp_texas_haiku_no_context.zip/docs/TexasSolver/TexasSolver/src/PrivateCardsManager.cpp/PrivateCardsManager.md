`PrivateCardsManager`: The function of `PrivateCardsManager` is to manage and store information about private cards in a multi-player game.

**Code Description**:
1. The constructor takes in three parameters:
   - `private_cards`: a 2D vector of `PrivateCards` objects, representing the private cards for each player.
   - `player_number`: an integer representing the number of players in the game.
   - `initialboard`: a 64-bit unsigned integer representing the initial game board state.

2. The constructor initializes the following member variables:
   - `private_cards`: stores the 2D vector of `PrivateCards` objects.
   - `player_number`: stores the number of players in the game.
   - `card_player_index`: a 2D vector that stores the index of each `PrivateCards` object for each player. This is used to quickly look up the index of a specific card for a specific player.

3. The constructor then iterates through the `private_cards` vector and populates the `card_player_index` vector with the appropriate indices for each `PrivateCards` object.

4. The constructor also stores the `initialboard` value, which likely represents the initial state of the game board.

5. Finally, the constructor calls the `setRelativeProbs()` function, which is not shown in the provided code snippet. This function is likely responsible for setting up the relative probabilities of different game states or outcomes based on the initial board state and the private cards.

Overall, the `PrivateCardsManager` class is responsible for managing and storing information about the private cards in a multi-player game. It provides a way to quickly look up the index of a specific card for a specific player, which can be useful for various game mechanics and calculations.\\
## Code: 
```
PrivateCardsManager::PrivateCardsManager(vector<vector<PrivateCards>> private_cards, int player_number,
                                         uint64_t initialboard) {
    this->private_cards = private_cards;
    this->player_number = player_number;
    this->card_player_index = vector<vector<int>>(52 * 52);
    for(int i = 0;i < 52 * 52;i ++){
        this->card_player_index[i] = vector<int>(this->player_number,-1);
    }

    // 用一个二维数组记录每个Private Combo的对应index,方便从一方的手牌找对方的同名卡牌的index
    for(int player_id = 0;player_id < player_number;player_id ++){
        vector<PrivateCards> privateCombos = private_cards[player_id];
        for(std::size_t i = 0;i < privateCombos.size();i ++){
            PrivateCards one_private_combo = privateCombos[i];
            this->card_player_index[one_private_combo.hashCode()][player_id] = i;
        }
    }

    this->initialboard = initialboard;
    this->setRelativeProbs();
}
```