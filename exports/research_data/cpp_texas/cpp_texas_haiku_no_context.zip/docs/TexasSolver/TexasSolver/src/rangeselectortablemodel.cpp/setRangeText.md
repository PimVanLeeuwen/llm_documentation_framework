`setRangeText`: The function of `setRangeText` is to set the range text in a table model.

**Code Description**:
The `setRangeText` function takes a QString `input_range` as input and sets the range text in the table model. Here's a breakdown of the function:

1. The function starts by clearing the existing range using the `clear_range()` function.
2. It then splits the `input_range` string by commas to get individual ranges.
3. For each individual range, the function performs the following steps:
   - If the range is empty, it skips to the next range.
   - It splits the range string by a colon to get the key range and the optional range value.
   - If the range list has more than two parts or less than one part, it logs a debug message and skips the range.
   - It initializes a `range_float` variable to 1.0.
   - It gets the key range and creates a list of keys by appending "o" and "s" to the key range if the `string2ij` map doesn't contain the original key range.
   - For each key in the list of keys, it performs the following steps:
     - If the key is empty or contains only spaces, it skips to the next key.
     - If the `string2ij` map doesn't contain the key, it logs a debug message and skips the key.
     - It gets the row and column coordinates (cord) from the `string2ij` map for the key.
     - If the range list has more than one part, it sets the `range_float` variable to the second part of the range list converted to a float.
     - It sets the `grids_float` value at the row and column coordinates to the `range_float` value.

The purpose of this function is to parse the input range string, extract the individual ranges, and set the corresponding values in the `grids_float` map of the table model. The function handles various edge cases, such as empty ranges, ranges with incorrect formats, and missing keys in the `string2ij` map.\\
## Code: 
```
void RangeSelectorTableModel::setRangeText(QString input_range){
    this->clear_range();
    for(QString one_range:input_range.split(",")){
        if(one_range.trimmed() == "")continue;
        QStringList one_range_list = one_range.split(":");

        if(one_range_list.size() > 2 || one_range_list.size() < 1){
            qDebug().noquote() << QString(tr("skipping range %1, format error, range list should contain two part seperate by ':'")).arg(one_range);
        }

        float range_float = 1.0;
        QString key_range = one_range_list[0];
        QStringList keys;
        if(this->string2ij.count(one_range_list[0])){
            keys.append(key_range);
        }else{
            keys.append(key_range + "o");
            keys.append(key_range + "s");
        }

        for(QString one_key: keys){
            if(one_key.count(" ") == one_key.length() || one_key == "")continue;
            if(!this->string2ij.count(one_key)){
                qDebug().noquote() << QString(tr("skipping range %1, format error")).arg(one_range);
                continue;
            }
            pair<int,int> cord = this->string2ij[one_key];
            if(one_range_list.size() > 1)range_float = one_range_list[1].toFloat();
            this->grids_float[cord.first][cord.second] = range_float;
        }
    }
}
```