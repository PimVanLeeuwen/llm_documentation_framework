`setupModelData`: The function of `setupModelData` is to set up the data model for a tree-based representation of a game.

**Code Description**:

1. The function first checks the mode of the `qSolverJob` object, which can be either `HOLDEM` (Texas Hold'em) or `SHORTDECK` (Short Deck Poker). Based on the mode, it assigns the appropriate `PokerSolver` object to the `solver` variable.

2. If the `solver` object's `get_game_tree()` method returns `nullptr` or the root of the game tree is `nullptr`, the function simply returns without doing anything further.

3. If the game tree is available, the function retrieves the current game round from the root of the game tree.

4. It then creates a new `TreeItem` object as the root of the tree model and adds it to the `rootItem` member variable.

5. Next, it creates a new `TreeItem` object as a child of the root item and assigns it to the `ti` variable.

6. The function then calls the `reGenerateTreeItem()` method, passing in the current game round and the `ti` object. This method is likely responsible for populating the tree model with the game tree data.

7. Overall, the `setupModelData()` function sets up the initial structure of the tree model, including the root item and a child item, and prepares the data for further processing by the `reGenerateTreeItem()` method.\\
## Code: 
```
void TreeModel::setupModelData()
{
    PokerSolver * solver;
    if(this->qSolverJob->mode == QSolverJob::Mode::HOLDEM){
        solver = &(this->qSolverJob->ps_holdem);
    }else if(this->qSolverJob->mode == QSolverJob::Mode::SHORTDECK){
        solver = &(this->qSolverJob->ps_shortdeck);
    }else{
        throw runtime_error("holdem mode incorrect");
    }

    if(solver->get_game_tree() == nullptr || solver->get_game_tree()->getRoot() == nullptr){
        return;
    }

    GameTreeNode::GameRound round =	solver->get_game_tree()->getRoot()->getRound();

    this->rootItem = new TreeItem(solver->get_game_tree()->getRoot());
    TreeItem* ti = new TreeItem(solver->get_game_tree()->getRoot(),this->rootItem);
    rootItem->insertChild(ti);
    this->reGenerateTreeItem(round,ti);
}
```