`DiscountedCfrTrainableHF`: The function of `DiscountedCfrTrainableHF` is to initialize and store various data structures required for the implementation of a Discounted Counterfactual Regret Minimization (DCFR) algorithm.

**Code Description**:
1. The constructor takes two parameters:
   - `privateCards`: A pointer to a vector of `PrivateCards` objects, which likely represent the private cards for each player in a game.
   - `actionNode`: A reference to an `ActionNode` object, which represents a node in the game tree.
2. The constructor initializes the following member variables:
   - `privateCards`: Stores the pointer to the `privateCards` vector passed as a parameter.
   - `action_number`: Stores the number of children of the `actionNode` passed as a parameter.
   - `card_number`: Stores the size of the `privateCards` vector.
   - `evs`: Initializes a vector of `EvsStorage` (likely a custom data type) with a size equal to the product of `action_number` and `card_number`, and sets all elements to 0.0.
   - `r_plus`: Initializes a vector of `RplusStorage` (likely a custom data type) with a size equal to the product of `action_number` and `card_number`, and sets all elements to 0.0.
   - `cum_r_plus`: Initializes a vector of `CumRplusStorage` (likely a custom data type) with a size equal to the product of `action_number` and `card_number`, and sets all elements to 0.0.

The purpose of this code is to set up the necessary data structures to store and manage the values required for the DCFR algorithm. The `evs`, `r_plus`, and `cum_r_plus` vectors are likely used to store the expected values, regret values, and cumulative regret values, respectively, for each possible action and private card combination in the game.

The DCFR algorithm is a technique used in reinforcement learning and game theory to find optimal strategies in sequential decision-making problems, such as in multi-player games. By initializing\\
## Code: 
```
DiscountedCfrTrainableHF::DiscountedCfrTrainableHF(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();
    this->evs = vector<EvsStorage>(this->action_number * this->card_number, (EvsStorage) 0.0);
    this->r_plus = vector<RplusStorage>(this->action_number * this->card_number, (RplusStorage) 0.0);
    this->cum_r_plus = vector<CumRplusStorage>(this->action_number * this->card_number, (CumRplusStorage) 0.0);
}
```