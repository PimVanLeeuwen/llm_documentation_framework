`paint_evs_only`: The function of `paint_evs_only` is to paint the expected value (EV) of each cell in a grid-based game strategy table, along with the corresponding card combinations, on a QPainter.

**Code Description**:

1. The function takes a QPainter, a QStyleOptionViewItem, and a QModelIndex as input parameters.
2. It initializes the QStyleOptionViewItem and casts the model to a DetailViewerModel.
3. If the treeItem in the DetailViewerModel's tableStrategyModel is not null and its type is GameTreeNode::ACTION, the function proceeds to process the data.
4. It retrieves the strategy number and the expected value (EV) grid for the current grid position (detailWindowSetting->grid_i, detailWindowSetting->grid_j).
5. For each cell in the grid, it calculates the normalized EV value using the `normalization_tanh` function and the solver's stack.
6. It then determines the corresponding card combination (card1 and card2) from the `ui_strategy_table`.
7. Based on the normalized EV value, it sets the background color of the cell using a gradient from red (low EV) to green (high EV).
8. The function then formats the card combination and the EV value as HTML text and sets it as the options.text.
9. Finally, it uses the QPainter to draw the formatted text within the cell's rectangle.

The purpose of this function is to provide a visual representation of the game strategy, where the expected value of each cell is displayed using a color-coded gradient, and the corresponding card combinations are shown. This can be useful for developers and players to understand the optimal strategy for the game.\\
## Code: 
```
void DetailItemDelegate::paint_evs_only(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);

    const DetailViewerModel * detailViewerModel = qobject_cast<const DetailViewerModel*>(index.model());
    //vector<pair<GameActions,float>> strategy = detailViewerModel->tableStrategyModel->get_strategy(this->detailWindowSetting->grid_i,this->detailWindowSetting->grid_j);
    options.text = "";

    if(detailViewerModel->tableStrategyModel->treeItem != NULL &&
            detailViewerModel->tableStrategyModel->treeItem->m_treedata.lock()->getType() == GameTreeNode::GameTreeNode::ACTION){

        shared_ptr<GameTreeNode> node = detailViewerModel->tableStrategyModel->treeItem->m_treedata.lock();
        int strategy_number = 0;
        if(this->detailWindowSetting->grid_i >= 0 && this->detailWindowSetting->grid_j >= 0){
           strategy_number = detailViewerModel->tableStrategyModel->ui_strategy_table[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j].size();
        }

        vector<float> evs = detailViewerModel->tableStrategyModel->get_ev_grid(this->detailWindowSetting->grid_i,this->detailWindowSetting->grid_j);
        std::size_t ind = index.row() * detailViewerModel->columns + index.column();

        if(ind < evs.size() and ind < strategy_number)
        {
            float one_ev = evs[ind];
            float normalized_ev = normalization_tanh(detailViewerModel->tableStrategyModel->get_solver()->stack,one_ev);
            //options.text += QString("</br>%1").arg(QString::number(normalized_ev));

            pair<int,int> strategy_ui_table = detailViewerModel->tableStrategyModel->ui_strategy_table[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j][ind];
            int card1 = strategy_ui_table.first;
            int card2 = strategy_ui_table.second;

            int red = max((int)(255 - normalized_ev * 255),0);
            int green = min((int)(normalized_ev * 255),255);
            int blue = min(red, green);
            QBrush brush = QBrush(QColor(red,green,blue));

            // draw background for flod
            QRect rect(option.rect.left(), option.rect.top(),
             option.rect.width(), option.rect.height());
            painter->fillRect(rect, brush);

            options.text = "";
            options.text += detailViewerModel->tableStrategyModel->cardint2card[card1].toFormattedHtml();
            options.text += detailViewerModel->tableStrategyModel->cardint2card[card2].toFormattedHtml();
            options.text = "<h2>" + options.text + "<\/h2>";

            options.text +=  QString(" <h2>%1<\/h2>").arg(QString::number(one_ev,'f',3));
        }
    }

    QTextDocument doc;
    doc.setHtml(options.text);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```