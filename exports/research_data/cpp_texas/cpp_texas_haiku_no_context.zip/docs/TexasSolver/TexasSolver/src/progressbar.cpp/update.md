`update`: The function of `update` is to update the progress of a progress bar.

**Code Description**: The `update()` function is responsible for updating the progress of a progress bar. It performs the following tasks:

1. Checks if the number of cycles has been set. If not, it throws a `std::runtime_error` exception.
2. Checks if the `update_is_called` flag is false. If so, it prints the opening bracket, 50 "todo" characters, and the closing bracket with the progress percentage (0%).
3. Sets the `update_is_called` flag to true.
4. Calculates the current percentage of progress based on the `progress` variable and the total number of cycles (`n_cycles`).
5. If the current percentage is less than the last displayed percentage (`last_perc`), the function returns without doing anything.
6. If the current percentage has increased by 1 unit, it updates the progress display by erasing the previous percentage and printing the new one.
7. If the `do_show_bar` flag is true, it updates the progress bar by:
   - Erasing the closing bracket and the trailing percentage characters.
   - Erasing the appropriate number of "todo" characters and replacing them with "done" characters.
   - Refilling the remaining "todo" characters.
   - Printing the closing bracket and the updated percentage.
8. Updates the `last_perc` variable with the current percentage.
9. Increments the `progress` variable.
10. Flushes the output stream.

The `update()` function is designed to provide a visual representation of the progress of a task or operation. It allows the user to see the current progress as a percentage and a graphical bar. The function is efficient in its updates, only updating the necessary parts of the display to minimize the amount of output and provide a smooth progress indication.\\
## Code: 
```
void progressbar::update() {
    return;
    if (n_cycles == 0) throw std::runtime_error(
                "progressbar::update: number of cycles not set");

    if (!update_is_called) {
        if (do_show_bar == true) {
            std::cout << opening_bracket_char;
            for (int _ = 0; _ < 50; _++) std::cout << todo_char;
            std::cout << closing_bracket_char << " 0%";
        }
        else std::cout << "0%";
    }
    update_is_called = true;

    int perc = 0;

    // compute percentage, if did not change, do nothing and return
    perc = progress*100./(n_cycles-1);
    if (perc < last_perc) return;

    // update percentage each unit
    if (perc == last_perc + 1) {
        // erase the correct  number of characters
        if      (perc <= 10)                std::cout << "\b\b"   << perc << '%';
        else if (perc  > 10 && perc < 100) std::cout << "\b\b\b" << perc << '%';
        else if (perc == 100)               std::cout << "\b\b\b" << perc << '%';
    }
    if (do_show_bar == true) {
        // update bar every ten units
        if (perc % 2 == 0) {
            // erase closing bracket
            std::cout << std::string(closing_bracket_char.size(), '\b');
            // erase trailing percentage characters
            if      (perc  < 10)               std::cout << "\b\b\b";
            else if (perc >= 10 && perc < 100) std::cout << "\b\b\b\b";
            else if (perc == 100)              std::cout << "\b\b\b\b\b";

            // erase 'todo_char'
            for (int j = 0; j < 50-(perc-1)/2; ++j) {
                std::cout << std::string(todo_char.size(), '\b');
            }

            // add one additional 'done_char'
            if (perc == 0) std::cout << todo_char;
            else           std::cout << done_char;

            // refill with 'todo_char'
            for (int j = 0; j < 50-(perc-1)/2-1; ++j) std::cout << todo_char;

            // readd trailing percentage characters
            std::cout << closing_bracket_char << ' ' << perc << '%';
        }
    }
    last_perc = perc;
    ++progress;
    std::cout << std::flush;

    return;
}
```