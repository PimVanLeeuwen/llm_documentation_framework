`reGenerateTreeItem`: The function of `reGenerateTreeItem` is to recursively regenerate the tree structure of a game tree node and its children.

**Code Description**: The `reGenerateTreeItem` function takes two parameters: `GameTreeNode::GameRound round` and `TreeItem* node_to_process`. It is responsible for processing a given `TreeItem` node and its children to update the game tree structure.

The function first retrieves the `GameTreeNode` associated with the `TreeItem` node using `node_to_process->m_treedata.lock()`. It then checks the type of the `GameTreeNode`:

1. If the node is of type `GameTreeNode::GameTreeNodeType::ACTION`, the function processes the children of the `ActionNode`. It creates a new `TreeItem` for each child node and inserts it as a child of the current `TreeItem` node. If the child node's round is not equal to the provided `round` parameter, the function skips that child and continues to the next one. For each child node, the function recursively calls `reGenerateTreeItem` to process its children as well.

2. If the node is of type `GameTreeNode::GameTreeNodeType::CHANCE`, the function processes the single child of the `ChanceNode`. It creates a new `TreeItem` for the child node and inserts it as a child of the current `TreeItem` node. The function then recursively calls `reGenerateTreeItem` to process the child node.

The purpose of this function is to update the tree structure of the game tree by creating new `TreeItem` nodes and their children based on the underlying `GameTreeNode` objects. This allows the game tree to be dynamically regenerated and updated as the game progresses.\\
## Code: 
```
void TreeModel::reGenerateTreeItem(GameTreeNode::GameRound round,TreeItem* node_to_process){
    const shared_ptr<GameTreeNode> gameTreeNode = node_to_process->m_treedata.lock();
    if(gameTreeNode->getType() == GameTreeNode::GameTreeNodeType::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(gameTreeNode);
        vector<shared_ptr<GameTreeNode>>& childrens = actionNode->getChildrens();
        for(shared_ptr<GameTreeNode> one_child:childrens){
            TreeItem * child_node = new TreeItem(one_child,node_to_process);
            node_to_process->insertChild(child_node);
            if(one_child->getRound() != round){
                continue;
            }
            this->reGenerateTreeItem(round,child_node);
        }
    }
    else if(gameTreeNode->getType() == GameTreeNode::GameTreeNodeType::CHANCE){
        shared_ptr<ChanceNode> chanceNode = dynamic_pointer_cast<ChanceNode>(gameTreeNode);
        TreeItem * child_node = new TreeItem(chanceNode->getChildren(),node_to_process);
        node_to_process->insertChild(child_node);
        this->reGenerateTreeItem(round,child_node);
    }
}
```