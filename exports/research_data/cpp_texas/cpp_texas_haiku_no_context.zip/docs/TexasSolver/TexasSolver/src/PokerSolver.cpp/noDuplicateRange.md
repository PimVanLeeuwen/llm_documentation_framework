`noDuplicateRange`: The function of `noDuplicateRange` is to remove duplicate `PrivateCards` from a given vector of `PrivateCards` and filter out the `PrivateCards` that have an intersection with the provided `board_long` value.

**Code Description**:
The `noDuplicateRange` function takes two parameters:
1. `const vector<PrivateCards> &private_range`: A reference to a vector of `PrivateCards` representing the input range.
2. `uint64_t board_long`: A 64-bit unsigned integer representing the board cards.

The function performs the following steps:
1. Initializes an empty vector `range_array` to store the filtered `PrivateCards`.
2. Initializes an `unordered_map<int,bool>` called `rangekv` to keep track of the unique `PrivateCards` in the input range.
3. Iterates through the `private_range` vector:
   - For each `PrivateCards` object `one_range`:
     - Checks if the `hashCode()` of `one_range` already exists in the `rangekv` map. If it does, it throws a `runtime_error` with a message indicating a duplicate key.
     - If the `hashCode()` is not found in `rangekv`, it adds the `hashCode()` as a key with a value of `true` in the `rangekv` map.
     - Converts the `get_hands()` of `one_range` to a 64-bit unsigned integer `hand_long` using the `Card::boardInts2long()` function.
     - Checks if the `hand_long` value does not have an intersection with the `board_long` value using the `Card::boardsHasIntercept()` function. If there is no intersection, it adds the `one_range` object to the `range_array` vector.
4. Finally, the function returns the `range_array` vector, which contains the unique `PrivateCards` that do not intersect with the provided `board_long` value.

The purpose of this function is to ensure that the input range of `\\
## Code: 
```
vector<PrivateCards> noDuplicateRange(const vector<PrivateCards> &private_range, uint64_t board_long) {
    vector<PrivateCards> range_array;
    unordered_map<int,bool> rangekv;
    for(PrivateCards one_range:private_range){
        if(rangekv.find(one_range.hashCode()) != rangekv.end())
            throw runtime_error(tfm::format("duplicated key %s",one_range.toString()));
        rangekv[one_range.hashCode()] = true;
        uint64_t hand_long = Card::boardInts2long(one_range.get_hands());
        if(!Card::boardsHasIntercept(hand_long,board_long)){
            range_array.push_back(one_range);
        }
    }
    return range_array;
}
```