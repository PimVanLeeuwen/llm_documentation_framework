`stop`: The function of `stop` is to stop the solver process.

**Code Description**: The `QSolverJob::stop()` function is responsible for stopping the solver process. It first prints a debug message indicating that it is trying to stop the solver. Then, it checks the current mode of the solver, which can be either `HOLDEM` (for Texas Hold'em poker) or `SHORTDECK` (for Short Deck poker). Depending on the mode, it calls the `stop()` function on the corresponding `ps_holdem` or `ps_shortdeck` object to stop the solver process.\\
## Code: 
```
void QSolverJob::stop(){
    qDebug().noquote() << tr("Trying to stop solver.");
    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.stop();
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.stop();
    }
}
```