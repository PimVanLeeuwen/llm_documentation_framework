`build_tree`: The function of `build_tree` is to build a game tree for either a Texas Hold'em or Short Deck poker game.

**Code Description**: The `build_tree` function is responsible for constructing the game tree for a poker game. It first prints a message to the console indicating that the tree is being built. Then, it checks the mode of the game, which can be either `HOLDEM` (Texas Hold'em) or `SHORTDECK` (Short Deck), and calls the appropriate function to build the game tree.

For Texas Hold'em, the function `ps_holdem.build_game_tree` is called, passing in various parameters such as the commitment of the out-of-position and in-position players, the current round, the raise limit, the small and big blinds, the stack sizes, a reference to the game tree builder, and the all-in threshold.

For Short Deck, the function `ps_shortdeck.build_game_tree` is called, with the same set of parameters as the Texas Hold'em case.

After the game tree has been built, the function prints a message to the console indicating that the build process has finished.

The `build_tree` function is an important part of the poker solver, as it sets up the game tree that will be used for the subsequent analysis and decision-making processes.\\
## Code: 
```
void QSolverJob::build_tree(){
    qDebug().noquote() << tr("building tree..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        ps_holdem.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }else if(this->mode == Mode::SHORTDECK){
        ps_shortdeck.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }
    qDebug().noquote() << tr("build tree finished");//.toStdString() << endl;
}
```