`CfrPlusTrainable`: The function of `CfrPlusTrainable` is to initialize and store various vectors and variables related to the Counterfactual Regret Minimization (CFR) algorithm for a given set of private cards and action nodes.

**Code Description**:
1. The constructor takes two parameters:
   - `shared_ptr<ActionNode> action_node`: A shared pointer to an `ActionNode` object, which represents a node in the game tree.
   - `vector<PrivateCards> privateCards`: A vector of `PrivateCards` objects, which represent the private cards for each player.

2. The constructor initializes the following member variables:
   - `action_node`: Stores the `ActionNode` object passed as a parameter.
   - `privateCards`: Stores the `PrivateCards` vector passed as a parameter.
   - `action_number`: Calculates the number of child nodes of the `ActionNode` object.
   - `card_number`: Stores the size of the `privateCards` vector.

3. The constructor then initializes the following vectors:
   - `r_plus`: A vector of `float` values with a size equal to the product of `action_number` and `card_number`. This vector is used to store the positive counterfactual regret values.
   - `r_plus_sum`: A vector of `float` values with a size equal to `card_number`. This vector is used to store the sum of the positive counterfactual regret values for each private card.
   - `cum_r_plus`: A vector of `float` values with a size equal to the product of `action_number` and `card_number`. This vector is used to store the cumulative positive counterfactual regret values.
   - `cum_r_plus_sum`: A vector of `float` values with a size equal to `card_number`. This vector is used to store the sum of the cumulative positive counterfactual regret values for each private card.
   - `retval`: A vector of `float` values with a size equal to the product of `action_number` and `card_number`. This vector is used to store the final return values.

The purpose of this\\
## Code: 
```
CfrPlusTrainable::CfrPlusTrainable(shared_ptr<ActionNode> action_node, vector<PrivateCards> privateCards) {
    this->action_node = action_node;
    this->privateCards = privateCards;
    this->action_number = action_node->getChildrens().size();
    this->card_number = privateCards.size();

    this->r_plus = vector<float>(this->action_number * this->card_number);
    this->r_plus_sum = vector<float>(this->card_number);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number);
    this->cum_r_plus_sum = vector<float>(this->card_number);
    this->retval = vector<float>(this->action_number * this->card_number);
}
```