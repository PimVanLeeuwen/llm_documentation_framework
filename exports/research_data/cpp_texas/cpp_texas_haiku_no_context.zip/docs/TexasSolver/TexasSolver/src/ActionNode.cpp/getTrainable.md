`getTrainable`: The function of `getTrainable` is to retrieve a shared pointer to a `Trainable` object, creating it on-site if it doesn't already exist.

**Code Description**: The `getTrainable` function takes three parameters:
1. `i`: an integer representing the index of the `Trainable` object to retrieve.
2. `create_on_site`: a boolean flag indicating whether to create the `Trainable` object if it doesn't already exist.
3. `use_halffloats`: an integer value that determines the type of `Trainable` object to create.

The function first checks if the requested index `i` is within the bounds of the `trainables` vector. If the index is out of bounds, it throws a `runtime_error` exception.

If the requested `Trainable` object doesn't exist (i.e., the corresponding element in the `trainables` vector is `nullptr`) and the `create_on_site` flag is set to `true`, the function creates a new `Trainable` object based on the value of `use_halffloats`:
- If `use_halffloats` is 0, it creates a `DiscountedCfrTrainable` object.
- If `use_halffloats` is 1, it creates a `DiscountedCfrTrainableSF` object.
- If `use_halffloats` is 2, it creates a `DiscountedCfrTrainableHF` object.

The newly created `Trainable` object is then stored in the `trainables` vector at the requested index.

Finally, the function returns a shared pointer to the `Trainable` object, either the one that already existed or the one that was just created.\\
## Code: 
```
shared_ptr<Trainable> ActionNode::getTrainable(int i,bool create_on_site, int use_halffloats) {
    if(i > this->trainables.size()){
        throw runtime_error(tfm::format("size unacceptable %s > %s ",i,this->trainables.size()));
    }
    if(this->trainables[i] == nullptr && create_on_site){
        switch ((this->getRound() == GameTreeNode::RIVER) ? use_halffloats : 0 ){
        case 0:
            this->trainables[i] = make_shared<DiscountedCfrTrainable>(player_privates,*this);
            break;
        case 1:
            this->trainables[i] = make_shared<DiscountedCfrTrainableSF>(player_privates,*this);
            break;
        case 2:
            this->trainables[i] = make_shared<DiscountedCfrTrainableHF>(player_privates,*this);
            break;
        }
    }
    return this->trainables[i];
}
```