`getBoardAt`: The function of `getBoardAt` is to retrieve the value of a specific cell in a 2D grid represented by the `grids_float` member variable.

**Code Description**: The `getBoardAt` function takes two integer parameters, `i` and `j`, which represent the row and column indices of the cell to be retrieved, respectively.

The function first checks if the provided row and column indices are within the valid range of the `ranklist` member variable. If either index is out of range, the function logs a debug message and returns 0.

If the indices are valid, the function simply returns the value stored in the `grids_float` 2D array at the specified row and column.

The purpose of this function is to provide a safe and controlled way to access the values in the `grids_float` array, ensuring that the function caller does not attempt to access cells outside the valid range of the array.\\
## Code: 
```
float BoardSelectorTableModel::getBoardAt(int i, int j){
    if(i < 0 || i >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::getBoardAt i not valid: " << i;
        return 0;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::getBoardAt j not valid: " << j;
        return 0;
    }
    else{
        return this->grids_float[i][j];
    }
}
```