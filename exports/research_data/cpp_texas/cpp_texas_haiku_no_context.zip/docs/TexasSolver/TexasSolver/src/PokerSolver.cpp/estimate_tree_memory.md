`estimate_tree_memory`: The function of `estimate_tree_memory` is to estimate the memory required for the game tree based on the given player ranges and the board cards.

**Code Description**:
The `estimate_tree_memory` function is a member function of the `PokerSolver` class. It takes three parameters: `range1`, `range2`, and `board`, which represent the ranges of the two players and the board cards, respectively.

The function first checks if the `game_tree` member of the `PokerSolver` class is not `nullptr`. If it is `nullptr`, the function prints a debug message and returns 0.

If the `game_tree` is not `nullptr`, the function proceeds to convert the input strings `range1`, `range2`, and `board` into the appropriate data structures. It first converts the `range1` and `range2` strings to `std::string` objects, and then splits the `board` string into a vector of individual card strings using the `string_split` function. The individual card strings are then converted to integers using the `Card::strCard2int` function and stored in the `initialBoard` vector.

Next, the function uses the `PrivateRangeConverter::rangeStr2Cards` function to convert the player range strings (`player1RangeStr` and `player2RangeStr`) into vectors of `PrivateCards` objects, using the `initialBoard` vector as a reference.

Finally, the function calls the `estimate_tree_memory` member function of the `game_tree` object, passing the size of the remaining cards in the deck (calculated as the total number of cards in the deck minus the number of cards in the `initialBoard` vector), the size of the `range1` vector, and the size of the `range2` vector. The result of this call is returned as the output of the `estimate_tree_memory` function.

The purpose of this function is to provide an estimate of the memory required to store the game tree, which is a data structure used to represent the possible game states and outcomes in a poker game. This information can be useful for optimizing the performance of the poker solver algorithm, as it can help determine the appropriate amount of memory to allocate for the game tree.\\
## Code: 
```
long long PokerSolver::estimate_tree_memory(QString range1,QString range2,QString board){
    if(this->game_tree == nullptr){
        qDebug().noquote() << QObject::tr("Please buld tree first.");
        return 0;
    }
    else{
        string player1RangeStr = range1.toStdString();
        string player2RangeStr = range2.toStdString();

        vector<string> board_str_arr = string_split(board.toStdString(),',');
        vector<int> initialBoard;
        for(string one_board_str:board_str_arr){
            initialBoard.push_back(Card::strCard2int(one_board_str));
        }

        vector<PrivateCards> range1 = PrivateRangeConverter::rangeStr2Cards(player1RangeStr,initialBoard);
        vector<PrivateCards> range2 = PrivateRangeConverter::rangeStr2Cards(player2RangeStr,initialBoard);
        return this->game_tree->estimate_tree_memory(this->deck.getCards().size() - initialBoard.size(),range1.size(),range2.size());
    }
}
```