`estimate_tree_memory`: The function of `estimate_tree_memory` is to estimate the memory required for the game tree based on the given poker game mode and player ranges.

**Code Description**: The `estimate_tree_memory` function is a member function of the `QSolverJob` class. It takes three parameters: `range1`, `range2`, and `board`, which are likely used to represent the player ranges and the board cards in a poker game.

The function first prints a debug message indicating that it is estimating the tree memory. Then, it checks the current mode of the `QSolverJob` object, which can be either `HOLDEM` (for Texas Hold'em) or `SHORTDECK` (for Short Deck Poker).

Depending on the mode, the function calls either `ps_holdem.estimate_tree_memory` or `ps_shortdeck.estimate_tree_memory` with the same input parameters (`range1`, `range2`, and `board`). These functions are likely defined elsewhere in the codebase and are responsible for the actual estimation of the tree memory.

Finally, the function returns the result of the memory estimation. If the mode is not recognized, the function returns 0.

The purpose of this function is to provide a way to estimate the memory requirements for the game tree, which is likely used in the context of a poker solver or analysis tool. This information can be useful for optimizing the performance of the application or for providing feedback to the user about the computational resources required for a particular game scenario.\\
## Code: 
```
long long QSolverJob::estimate_tree_memory(QString range1,QString range2,QString board){
    qDebug().noquote() << tr("Estimating tree memory..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        return ps_holdem.estimate_tree_memory(range1,range2,board);
    }else if(this->mode == Mode::SHORTDECK){
        return ps_shortdeck.estimate_tree_memory(range1,range2,board);
    }
    return 0;
}
```