`setTrainable`: The function of `setTrainable` is to set the trainable property of the game tree nodes in the given game tree.

**Code Description**: The `setTrainable` function is responsible for setting the trainable property of the game tree nodes in the given game tree. It takes a shared pointer to the root of the game tree as input.

The function first checks the type of the current node. If the node is an `ACTION` node, it casts the node to an `ActionNode` and checks the player associated with the action. Based on the trainer type, it sets the trainable property of the action node using either `CfrPlusTrainable` or `DiscountedCfrTrainable`. If the trainer type is not supported, it throws a runtime error.

If the node is a `CHANCE` node, the function recursively calls itself on the child node of the chance node.

If the node is a `TERMINAL` or `SHOWDOWN` node, the function does not perform any further actions.

The function also recursively calls itself on all the child nodes of the action node to set the trainable property for the entire game tree.

The code also includes some logic to determine the number of trainable objects to be created based on the gap between the current node's round and the root node's round. This is likely related to the specific implementation of the `DiscountedCfrTrainable` class.

Overall, the `setTrainable` function is responsible for setting the trainable property of the game tree nodes, which is an important step in the training process of the game tree.\\
## Code: 
```
void PCfrSolver::setTrainable(shared_ptr<GameTreeNode> root) {
    if(root->getType() == GameTreeNode::ACTION){
        shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(root);

        int player = action_node->getPlayer();

        if(this->trainer == "cfr_plus"){
            //vector<PrivateCards> player_privates = this->ranges[player];
            //action_node->setTrainable(make_shared<CfrPlusTrainable>(action_node,player_privates));
            throw runtime_error(tfm::format("trainer %s not supported",this->trainer));
        }else if(this->trainer == "discounted_cfr"){
            vector<PrivateCards>* player_privates = &this->ranges[player];
            //action_node->setTrainable(make_shared<DiscountedCfrTrainable>(action_node,player_privates));
            int num;
            GameTreeNode::GameRound gr = this->tree->getRoot()->getRound();
            int root_round = GameTreeNode::gameRound2int(gr);
            int current_round = GameTreeNode::gameRound2int(root->getRound());
            int gap = current_round - root_round;

            if(gap == 2) {
                num = this->deck.getCards().size() * this->deck.getCards().size() +
                          this->deck.getCards().size() + 1;
            }else if(gap == 1) {
                num = this->deck.getCards().size() + 1;
            }else if(gap == 0) {
                num =  1;
            }else{
                throw runtime_error("gap not understand");
            }
            action_node->setTrainable(vector<shared_ptr<Trainable>>(num),player_privates);
        }else{
            throw runtime_error(tfm::format("trainer %s not found",this->trainer));
        }

        vector<shared_ptr<GameTreeNode>> childrens =  action_node->getChildrens();
        for(shared_ptr<GameTreeNode> one_child:childrens) setTrainable(one_child);
    }else if(root->getType() == GameTreeNode::CHANCE) {
        shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(root);
        shared_ptr<GameTreeNode> children = chance_node->getChildren();
        setTrainable(children);
    }
    else if(root->getType() == GameTreeNode::TERMINAL){

    }else if(root->getType() == GameTreeNode::SHOWDOWN){

    }
}
```