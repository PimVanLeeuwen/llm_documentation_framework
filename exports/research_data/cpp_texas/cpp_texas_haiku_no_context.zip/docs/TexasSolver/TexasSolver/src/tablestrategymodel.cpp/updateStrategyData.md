`updateStrategyData`: The function of `updateStrategyData` is to update the strategy data for the table strategy model.

**Code Description**:

The `updateStrategyData` function is responsible for updating the strategy data for the table strategy model. It performs the following key tasks:

1. Checks if the `treeItem` is not null, and if so, retrieves the associated `GameTreeNode`.
2. Calls the `setupModelData` function to set up the model data.
3. If the retrieved `GameTreeNode` is an `ActionNode`, it proceeds to update the strategy data:
   - Determines the current player and the game round based on the `ActionNode`.
   - Constructs a vector of `Card` objects based on the current game round and the available cards (turn and river).
   - Retrieves the current strategy and expected values (EVs) from the solver and stores them in the `current_strategy` and `current_evs` variables, respectively.
   - Populates the `ui_strategy_table` with the strategy information, organizing it based on the card ranks and suits.
4. If the solver is available, it updates the player ranges (`p1_range` and `p2_range`) by iterating through the game tree and applying the strategy information.
5. Finally, it calculates the total strategy and stores it in the `total_strategy` variable.

The main purpose of this function is to ensure that the table strategy model is up-to-date with the latest strategy information, which is obtained from the solver. This data is then used to display the strategy information in the user interface or for further analysis.\\
## Code: 
```
void TableStrategyModel::updateStrategyData(){
    if(this->treeItem != NULL){
        shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();
        this->setupModelData();
        if(node != nullptr && node->getType() == GameTreeNode::GameTreeNode::ACTION){
            shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);
            //actionNode->getTrainable();
            // create a vector card and input it to solver and get the result
            vector<Card> deal_cards;
            GameTreeNode::GameRound root_round = this->qSolverJob->get_solver()->getGameTree()->getRoot()->getRound();
            GameTreeNode::GameRound current_round = actionNode->getRound();
            this->current_player = actionNode->getPlayer();
            if(root_round == GameTreeNode::GameRound::FLOP){
                if(current_round == GameTreeNode::GameRound::TURN){deal_cards.push_back(this->turn_card);}
                if(current_round == GameTreeNode::GameRound::RIVER){deal_cards.push_back(this->turn_card);deal_cards.push_back(this->river_card);}
            }
            else if(root_round == GameTreeNode::GameRound::TURN){
                if(current_round == GameTreeNode::GameRound::RIVER){deal_cards.push_back(this->river_card);}
            }
            if(this->qSolverJob->get_solver() != NULL && this->qSolverJob->get_solver()->get_solver() != NULL){
                vector<vector<vector<float>>> current_strategy = this->qSolverJob->get_solver()->get_solver()->get_strategy(actionNode,deal_cards);
                this->current_strategy = current_strategy;

                vector<vector<vector<float>>> current_evs = this->qSolverJob->get_solver()->get_solver()->get_evs(actionNode,deal_cards);
                this->current_evs = current_evs;

                for(int i = 0;i < 52;i ++){
                    for(int j = 0;j < 52;j ++){
                        const vector<float>& one_strategy = this->current_strategy[i][j];
                        if(one_strategy.empty())continue;
                        Card card1 = this->cardint2card[i];
                        Card card2 = this->cardint2card[j];

                        int rank1 = card1.getCardInt() / 4;
                        int suit1 = card1.getCardInt() - (rank1)*4;
                        int index1 = 12 - rank1; // this index is the index of the actal ui, so AKQ would be the lower index and 234 would be high

                        int rank2 = card2.getCardInt() / 4;
                        int suit2 = card2.getCardInt() - (rank2)*4;
                        int index2 = 12 - rank2;

                        if(index1 == index2){
                            this->ui_strategy_table[index1][index2].push_back(std::pair<int,int>(i,j));
                        }
                        else if(suit1 == suit2){
                            this->ui_strategy_table[min(index1,index2)][max(index1,index2)].push_back(std::pair<int,int>(i,j));
                        }else{
                            this->ui_strategy_table[max(index1,index2)][min(index1,index2)].push_back(std::pair<int,int>(i,j));
                        }
                    }
                }
            }
        }
        if(this->qSolverJob->get_solver() != NULL  && this->qSolverJob->get_solver()->get_solver() != NULL && node != nullptr){
            vector<PrivateCards>& p1range = this->qSolverJob->get_solver()->player1Range;
            vector<PrivateCards>& p2range = this->qSolverJob->get_solver()->player2Range;

            for(auto one_private:p1range)this->p1_range[one_private.card1][one_private.card2] = one_private.weight;
            for(auto one_private:p2range)this->p2_range[one_private.card1][one_private.card2] = one_private.weight;

            shared_ptr<GameTreeNode> iter_node = node->getParent();
            shared_ptr<GameTreeNode> last_node = node;
            while(iter_node != nullptr){
                if(iter_node->getType() == GameTreeNode::GameTreeNode::ACTION){
                    shared_ptr<ActionNode> iterActionNode = dynamic_pointer_cast<ActionNode>(iter_node);
                    vector<Card> deal_cards;
                    GameTreeNode::GameRound root_round = this->qSolverJob->get_solver()->getGameTree()->getRoot()->getRound();
                    GameTreeNode::GameRound current_round = iterActionNode->getRound();
                    if(root_round == GameTreeNode::GameRound::FLOP){
                        if(current_round == GameTreeNode::GameRound::TURN){deal_cards.push_back(this->turn_card);}
                        if(current_round == GameTreeNode::GameRound::RIVER){deal_cards.push_back(this->turn_card);deal_cards.push_back(this->river_card);}
                    }
                    else if(root_round == GameTreeNode::GameRound::TURN){
                        if(current_round == GameTreeNode::GameRound::RIVER){deal_cards.push_back(this->river_card);}
                    }

                    vector<vector<vector<float>>> current_strategy = this->qSolverJob->get_solver()->get_solver()->get_strategy(iterActionNode,deal_cards);

                    int child_chosen = -1;
                    for(std::size_t i = 0;i < iterActionNode->getChildrens().size();i ++){
                        if(iterActionNode->getChildrens()[i] == last_node){
                            child_chosen = i;
                            break;
                        }
                    }
                    if(child_chosen == -1)throw runtime_error("no child chosen");
                    for(std::size_t i = 0;i < 52;i ++){
                        for(std::size_t j = 0;j < 52;j ++){
                            if(current_strategy[i][j].size() == 0)continue;
                            if(iterActionNode->getPlayer() == 0){ // p1, IP
                                this->p1_range[i][j] *= current_strategy[i][j][child_chosen];
                            }
                            else if(iterActionNode->getPlayer() == 1){ // p2, OOP
                                this->p2_range[i][j] *= current_strategy[i][j][child_chosen];
                            }else throw runtime_error("player not exist in tablestrategymodel");
                        }
                    }
                }

                iter_node = iter_node->getParent();
                last_node = last_node->getParent();
            }
        }
        if(this->qSolverJob->get_solver() != NULL  && this->qSolverJob->get_solver()->get_solver() != NULL && node != nullptr){
            this->total_strategy = this->get_total_strategy();
        }
    }
}
```