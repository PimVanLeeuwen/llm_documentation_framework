`get_round_str`: The function of `get_round_str` is to return a QString (a Qt string type) representing the game round based on the provided `GameRound` enum value.

**Code Description**: The `get_round_str` function takes a `GameRound` enum value as input and returns a corresponding QString representing the game round. The function uses a series of `if-else` statements to check the input `GameRound` value and return the appropriate string:

- If the input `GameRound` is `FLOP`, the function returns the QString `"FLOP"`.
- If the input `GameRound` is `TURN`, the function returns the QString `"TURN"`.
- If the input `GameRound` is `RIVER`, the function returns the QString `"RIVER"`.
- If the input `GameRound` is not recognized as one of the above values, the function throws a `runtime_error` with the message `"round not recognized, must be in flop,turn,river"`.

The `QObject::tr()` function is used to translate the string values, which is a common practice in Qt applications to support internationalization.\\
## Code: 
```
QString TreeItem::get_round_str(GameTreeNode::GameRound round) const{
    if(round == GameTreeNode::GameRound::FLOP){
        return QObject::tr("FLOP");
    }
    else if(round == GameTreeNode::GameRound::TURN){
        return QObject::tr("TURN");
    }
    else if(round == GameTreeNode::GameRound::RIVER){
        return QObject::tr("RIVER");
    }
    else throw runtime_error("round not recognized, must be in flop,turn,river");
}
```