`toString`: The function of `toString` is to return a string representation of the `GameActions` object.

**Code Description**: The `toString()` method is a member function of the `GameActions` class. It is responsible for converting the internal state of the `GameActions` object into a human-readable string format.

The method first checks the value of the `amount` member variable. If `amount` is equal to `-1`, it calls the `pokerActionToString()` function and returns the result. This function likely converts the `action` member variable, which represents a poker action, into a string.

If `amount` is not equal to `-1`, the method concatenates the result of `pokerActionToString(action)` with a space and the string representation of the `amount` member variable, and returns the resulting string.

This function is useful for providing a textual representation of the `GameActions` object, which can be helpful for logging, debugging, or displaying the object's state to the user.\\
## Code: 
```
string GameActions::toString() {
    if(this->amount == -1) {
        return this->pokerActionToString(this->action);
    }else{
        return this->pokerActionToString(this->action) + " " + to_string(amount);
    }
}
```