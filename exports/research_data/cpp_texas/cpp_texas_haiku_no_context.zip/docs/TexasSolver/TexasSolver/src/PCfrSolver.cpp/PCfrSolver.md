`PCfrSolver`: The function of `PCfrSolver` is to solve a poker game tree using a Monte Carlo algorithm, taking into account player ranges, the initial board, and various configuration options.

**Code Description**:
1. The constructor initializes the `PCfrSolver` object with the following parameters:
   - `GameTree`: The game tree to be solved.
   - `range1` and `range2`: The player ranges for the two players.
   - `initial_board`: The initial board cards.
   - `Compairer`: The object used to compare hands.
   - `Deck`: The deck of cards.
   - `iteration_number`: The number of iterations to perform.
   - `debug`: A flag to enable debugging.
   - `print_interval`: The interval at which to print progress.
   - `logfile`: The file to log the results.
   - `trainer`: The trainer to use.
   - `monteCarolAlg`: The Monte Carlo algorithm to use.
   - `warmup`: The number of warmup iterations.
   - `accuracy`: The desired accuracy.
   - `use_isomorphism`: A flag to enable isomorphism.
   - `use_halffloats`: A flag to use half-floats.
   - `num_threads`: The number of threads to use.
2. The constructor removes any duplicate cards from the player ranges and stores them in the `range1` and `range2` variables.
3. It initializes the `PrivateCardsManager` and `RiverRangeManager` objects.
4. It sets the number of threads to use, either based on the provided value or the number of available processors.
5. It sets the `Trainable` flag on the game tree root node.
6. It determines the "split round" based on the root node's round, which is the round at which to switch from multi-threading to single-threading.

The `PCfrSolver` class is responsible for solving a poker game tree using a Monte Carlo algorithm, taking into account player ranges, the initial board, and various configuration options. It initializes the necessary objects and data structures, and sets up the multi-threading and split round logic to optimize the performance of the solver.\\
## Code: 
```
PCfrSolver::PCfrSolver(shared_ptr<GameTree> tree, vector<PrivateCards> range1, vector<PrivateCards> range2,
                     vector<int> initial_board, shared_ptr<Compairer> compairer, Deck deck, int iteration_number, bool debug,
                     int print_interval, string logfile, string trainer, Solver::MonteCarolAlg monteCarolAlg,int warmup,float accuracy,bool use_isomorphism,int use_halffloats,int num_threads) :Solver(tree){
    this->initial_board = initial_board;
    this->initial_board_long = Card::boardInts2long(initial_board);
    this->logfile = logfile;
    this->trainer = trainer;
    this->warmup = warmup;

    range1 = this->noDuplicateRange(range1,initial_board_long);
    range2 = this->noDuplicateRange(range2,initial_board_long);

    this->range1 = range1;
    this->range2 = range2;
    this->player_number = 2;
    this->ranges = vector<vector<PrivateCards>>(this->player_number);
    this->ranges[0] = range1;
    this->ranges[1] = range2;

    this->compairer = compairer;

    this->deck = deck;
    this->use_isomorphism = use_isomorphism;
    this->use_halffloats = use_halffloats;

    this->rrm = RiverRangeManager(compairer);
    this->iteration_number = iteration_number;

    vector<vector<PrivateCards>> private_cards(this->player_number);
    private_cards[0] = range1;
    private_cards[1] = range2;
    pcm = PrivateCardsManager(private_cards,this->player_number,Card::boardInts2long(this->initial_board));
    this->debug = debug;
    this->print_interval = print_interval;
    this->monteCarolAlg = monteCarolAlg;
    this->accuracy = accuracy;
    if(num_threads == -1){
        num_threads = omp_get_num_procs();
    }
    qDebug().noquote() << QString::fromStdString(tfm::format(QObject::tr("Using %s threads").toStdString().c_str(),num_threads));
    this->num_threads = num_threads;
    this->distributing_task = false;
    omp_set_num_threads(this->num_threads);
    setTrainable(this->tree->getRoot());
    this->root_round = this->tree->getRoot()->getRound();
    if(this->root_round == GameTreeNode::GameRound::PREFLOP){
        this->split_round = GameTreeNode::GameRound::FLOP;
    }else if(this->root_round == GameTreeNode::GameRound::FLOP){
        this->split_round = GameTreeNode::GameRound::TURN;
    }else if(this->root_round == GameTreeNode::GameRound::TURN){
        this->split_round = GameTreeNode::GameRound::RIVER;
    }else{
        // do not use multithread in river, really not necessary
        this->split_round = GameTreeNode::GameRound::PREFLOP;
    }
}
```