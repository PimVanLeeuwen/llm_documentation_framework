`get_solver`: The function of `get_solver` is to return a pointer to a `PokerSolver` object based on the current mode of the `QSolverJob` object.

**Code Description**: The `get_solver` function is a member function of the `QSolverJob` class. It checks the current mode of the `QSolverJob` object and returns a pointer to the appropriate `PokerSolver` object based on the mode.

If the mode is `Mode::HOLDEM`, the function returns a pointer to the `ps_holdem` member of the `QSolverJob` object.
If the mode is `Mode::SHORTDECK`, the function returns a pointer to the `ps_shortdeck` member of the `QSolverJob` object.
If the mode is neither `Mode::HOLDEM` nor `Mode::SHORTDECK`, the function throws a `runtime_error` with the message "unknown mode in get_solver".

This function is likely used to provide access to the appropriate `PokerSolver` object based on the current game mode, which is useful for solving poker-related problems or simulations.\\
## Code: 
```
PokerSolver* QSolverJob::get_solver(){
    if(this->mode == Mode::HOLDEM){
        return &this->ps_holdem;
    }else if(this->mode == Mode::SHORTDECK){
        return &this->ps_shortdeck;
    }else throw runtime_error("unknown mode in get_solver");
}
```