`getcurrentStrategy`: The function of `getcurrentStrategy` is to calculate and return the current strategy of the CfrPlusTrainable object.

**Code Description**: The `getcurrentStrategy` function is responsible for calculating and returning the current strategy of the CfrPlusTrainable object. The strategy is represented as a vector of float values, where each value corresponds to the probability of taking a particular action.

The function first checks if the `r_plus_sum` vector is empty. If it is, the function fills the `retval` vector with equal probabilities for each action (1.0 / `action_number`). This is the default strategy when no previous regret information is available.

If the `r_plus_sum` vector is not empty, the function iterates through each action and each private ID (card) to calculate the probability for each action-private ID combination. The probability is calculated as `r_plus[index] / r_plus_sum[private_id]`, where `index` is the index of the current action-private ID combination in the `r_plus` vector.

If the `r_plus_sum[private_id]` is zero, the function sets the probability for the corresponding action-private ID combination to `1.0 / action_number`, which is the default probability when no regret information is available for that private ID.

The function also checks if any of the `r_plus[index]` values are `NaN` (not a number), and if so, it throws a `runtime_error` exception.

Finally, the function returns the `retval` vector, which contains the calculated current strategy.\\
## Code: 
```
const vector<float> CfrPlusTrainable::getcurrentStrategy() {
    if(this->r_plus_sum.empty()){
        fill(retval.begin(),retval.end(),1.0 / this->action_number);
    }else {
        for (int action_id = 0; action_id < action_number; action_id++) {
            for (int private_id = 0; private_id < this->card_number; private_id++) {
                int index = action_id * this->card_number + private_id;
                if(this->r_plus_sum[private_id] != 0) {
                    retval[index] = this->r_plus[index] / this->r_plus_sum[private_id];
                }else{
                    retval[index] = 1.0 / this->action_number;
                }
                if(this->r_plus[index] != this->r_plus[index]) throw runtime_error("nan found");
                /*
                if(this.r_plus_sum[private_id] == 0)
                {
                    System.out.println("Exception regret status, r_plus_sum == 0:");
                    System.out.println(String.format("r plus length %s , card num %s",r_plus.length,this.card_number));
                    for(int i = index % this.card_number;i < this.r_plus.length;i += this.card_number){
                        System.out.print(String.format("%s:%s ",i,this.r_plus[i]));
                        if(i == index){
                            System.out.print("[current]");
                        }
                    }
                    System.out.println();
                    System.out.println();
                    throw new RuntimeException();
                }
                 */
            }
        }
    }
    return retval;
}
```