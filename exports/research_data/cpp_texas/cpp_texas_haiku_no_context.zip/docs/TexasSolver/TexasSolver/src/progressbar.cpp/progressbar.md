`progressbar`: The function of `progressbar` is to create a progress bar object that can be used to display the progress of a task or operation.

**Code Description**: The `progressbar` class is a C++ class that provides a simple way to display a progress bar in a console or terminal application. The class has the following member variables:

1. `progress`: An integer that represents the current progress of the task or operation.
2. `n_cycles`: An integer that represents the total number of cycles or steps in the task or operation.
3. `last_perc`: An integer that represents the last percentage of progress that was displayed.
4. `do_show_bar`: A boolean that determines whether the progress bar should be displayed or not.
5. `update_is_called`: A boolean that indicates whether the `update()` function has been called.
6. `done_char`: A character that represents the completed portion of the progress bar.
7. `todo_char`: A character that represents the remaining portion of the progress bar.
8. `opening_bracket_char`: A character that represents the opening bracket of the progress bar.
9. `closing_bracket_char`: A character that represents the closing bracket of the progress bar.

The constructor of the `progressbar` class takes two parameters:

1. `n`: An integer that represents the total number of cycles or steps in the task or operation.
2. `showbar`: A boolean that determines whether the progress bar should be displayed or not.

The constructor initializes the member variables with the provided values and sets the default values for the characters used to represent the progress bar.

This `progressbar` class can be used to display a progress bar in a console or terminal application, allowing users to see the progress of a task or operation in real-time.\\
## Code: 
```
progressbar::progressbar(int n, bool showbar) :
        progress(0),
        n_cycles(n),
        last_perc(0),
        do_show_bar(showbar),
        update_is_called(false),
        done_char("#"),
        todo_char(" "),
        opening_bracket_char("["),
        closing_bracket_char("]") {}
```