`gameRound2int`: The function of `gameRound2int` is to convert a `GameRound` enum value to an integer representation.

**Code Description**: The `gameRound2int` function takes a `GameRound` enum value as input and returns an integer representation of that value. The function handles the following cases:

1. If the input `gameRound` is `GameRound::PREFLOP`, the function returns `0`.
2. If the input `gameRound` is `GameRound::FLOP`, the function returns `1`.
3. If the input `gameRound` is `GameRound::TURN`, the function returns `2`.
4. If the input `gameRound` is `GameRound::RIVER`, the function returns `3`.
5. If the input `gameRound` is not one of the recognized values, the function throws a `runtime_error` with the message "round not found".

This function is likely used to convert the `GameRound` enum, which represents the different stages of a game, to a numerical representation that can be used for other purposes, such as indexing or comparison.\\
## Code: 
```
int GameTreeNode::gameRound2int(GameTreeNode::GameRound gameRound) {
    if(gameRound == GameRound::PREFLOP) {
        return 0;
    }else if(gameRound == GameRound::FLOP){
        return 1;
    } else if(gameRound == GameRound::TURN) {
        return 2;
    } else if(gameRound == GameRound::RIVER) {
        return 3;
    }
    throw runtime_error("round not found");
}
```