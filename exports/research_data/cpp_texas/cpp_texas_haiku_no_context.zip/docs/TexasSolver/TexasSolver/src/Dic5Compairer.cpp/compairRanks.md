`compairRanks`: The function of `compairRanks` is to compare the ranks of two cards and return the result of the comparison.

**Code Description**: The `compairRanks` function takes two integer parameters, `rank_former` and `rank_latter`, which represent the ranks of two cards. The function then compares the ranks and returns a `CompairResult` enum value indicating whether the first card has a larger, smaller, or equal rank compared to the second card.

If `rank_former` is less than `rank_latter`, the function returns `CompairResult::LARGER`, indicating that the first card has a larger rank than the second card. This is because in the context of the code, a smaller rank value represents a larger card (e.g., a card with rank 0 is the highest, while a card with rank 13 is the lowest).

If `rank_former` is greater than `rank_latter`, the function returns `CompairResult::SMALLER`, indicating that the first card has a smaller rank than the second card.

If `rank_former` is equal to `rank_latter`, the function returns `CompairResult::EQUAL`, indicating that the two cards have the same rank.

The purpose of this function is likely to be used in a card game or a similar application where the relative ranks of cards need to be compared to determine the outcome of a game or a hand.\\
## Code: 
```
Compairer::CompairResult Dic5Compairer::compairRanks(int rank_former, int rank_latter) {
    if (rank_former < rank_latter) {
        // rank更小的牌更大，0是同花顺
        return CompairResult::LARGER;
    } else if (rank_former > rank_latter) {
        return CompairResult::SMALLER;
    } else {
        // rank_former == rank_latter
        return CompairResult::EQUAL;
    }
}
```