`GameTreeNode`: The function of `GameTreeNode` is to create a node in a game tree data structure, representing a specific state of a game.

**Code Description**: The `GameTreeNode` constructor takes three parameters:
1. `GameRound round`: This parameter represents the current round of the game.
2. `double pot`: This parameter represents the current pot size in the game.
3. `shared_ptr<GameTreeNode> parent`: This parameter represents a shared pointer to the parent node of the current node in the game tree.

The constructor initializes the following member variables of the `GameTreeNode` object:
- `round`: This variable is set to the `round` parameter passed to the constructor.
- `pot`: This variable is set to the `pot` parameter passed to the constructor.
- `parent`: This variable is set to the `parent` parameter passed to the constructor, using the `std::move` function to transfer ownership of the shared pointer.

The purpose of this constructor is to create a new node in the game tree, with the specified game round, pot size, and parent node. This allows the game tree to be built up incrementally, with each node representing a different state of the game.\\
## Code: 
```
GameTreeNode::GameTreeNode(GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent) {
    this->round = round;
    this->pot = pot;
    this->parent = std::move(parent);
}
```