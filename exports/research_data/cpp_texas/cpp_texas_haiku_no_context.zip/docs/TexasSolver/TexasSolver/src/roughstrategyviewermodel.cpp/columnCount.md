`columnCount`: The function of `columnCount` is to return the number of columns in the table strategy model.

**Code Description**: The `columnCount` function is a member function of the `RoughStrategyViewerModel` class. It takes a `QModelIndex` object as a parameter, which represents the parent index of the model. However, in this case, the parent index is not used, and the function simply returns the size of the `total_strategy` vector from the `tableStrategyModel` object. This means that the number of columns in the table is determined by the number of elements in the `total_strategy` vector.\\
## Code: 
```
int RoughStrategyViewerModel::columnCount(const QModelIndex &parent) const
{
    return this->tableStrategyModel->total_strategy.size();
}
```