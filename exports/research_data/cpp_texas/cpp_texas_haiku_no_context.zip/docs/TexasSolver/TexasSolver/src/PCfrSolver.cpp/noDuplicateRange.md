`noDuplicateRange`: The function of `noDuplicateRange` is to remove any duplicate `PrivateCards` objects from the input `private_range` vector and return a new vector containing only the unique `PrivateCards` objects.

**Code Description**: The `noDuplicateRange` function takes two parameters: a `vector<PrivateCards>` called `private_range` and a `uint64_t` called `board_long`. The function's purpose is to create a new vector of `PrivateCards` objects that are unique and do not intersect with the given `board_long` value.

The function first creates an empty `vector<PrivateCards>` called `range_array` and an `unordered_map<int,bool>` called `rangekv`. It then iterates through the `private_range` vector, checking each `PrivateCards` object for the following:

1. If the `PrivateCards` object's `hashCode()` is already present in the `rangekv` map, it means the object is a duplicate, and the function throws a `runtime_error` with a message indicating the duplicate key.
2. If the `PrivateCards` object's `hashCode()` is not in the `rangekv` map, the function adds it to the map with a value of `true`.
3. The function then converts the `PrivateCards` object's `get_hands()` value to a `uint64_t` using the `Card::boardInts2long()` function.
4. If the `uint64_t` value does not intersect with the `board_long` value (using the `Card::boardsHasIntercept()` function), the `PrivateCards` object is added to the `range_array` vector.

Finally, the function returns the `range_array` vector, which contains the unique `PrivateCards` objects that do not intersect with the given `board_long` value.\\
## Code: 
```
vector<PrivateCards>
PCfrSolver::noDuplicateRange(const vector<PrivateCards> &private_range, uint64_t board_long) {
    vector<PrivateCards> range_array;
    unordered_map<int,bool> rangekv;
    for(PrivateCards one_range:private_range){
        if(rangekv.find(one_range.hashCode()) != rangekv.end())
            throw runtime_error(tfm::format("duplicated key %s",one_range.toString()));
        rangekv[one_range.hashCode()] = true;
        uint64_t hand_long = Card::boardInts2long(one_range.get_hands());
        if(!Card::boardsHasIntercept(hand_long,board_long)){
            range_array.push_back(one_range);
        }
    }
    return range_array;

}
```