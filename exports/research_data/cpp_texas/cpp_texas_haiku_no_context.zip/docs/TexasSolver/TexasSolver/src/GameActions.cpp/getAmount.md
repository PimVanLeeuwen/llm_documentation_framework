`getAmount`: The function of `getAmount` is to return the value of the `amount` member variable of the `GameActions` class.

**Code Description**: The `getAmount()` function is a member function of the `GameActions` class. It simply returns the value of the `amount` member variable of the class. This function does not take any parameters and does not modify the state of the object. It is a simple getter function that allows other parts of the code to access the `amount` value of the `GameActions` object.\\
## Code: 
```
double GameActions::getAmount() {
    return this->amount;
}
```