`setRiverCard`: The function of `setRiverCard` is to set the river card in the TableStrategyModel object.

**Code Description**: The `setRiverCard` function takes a `Card` object as a parameter and assigns it to the `river_card` member variable of the `TableStrategyModel` class. This function allows the caller to update the river card in the model, which is likely used for various calculations or decision-making processes within the game logic.\\
## Code: 
```
void TableStrategyModel::setRiverCard(Card river_card){
    this->river_card = river_card;
}
```