`TerminalNode`: The function of `TerminalNode` is to represent the final state of a game tree, where the game has reached its conclusion and the payoffs for each player can be determined.

**Code Description**: The `TerminalNode` class is a subclass of the `GameTreeNode` class, and it is used to represent the final state of a game tree. The constructor of the `TerminalNode` class takes the following parameters:

1. `payoffs`: a vector of double values representing the payoffs for each player in the game.
2. `winner`: an integer value representing the index of the player who won the game.
3. `round`: a `GameRound` object representing the current round of the game.
4. `pot`: a double value representing the current pot size in the game.
5. `parent`: a shared pointer to the parent `GameTreeNode` object.

The constructor initializes the `payoffs`, `winner`, and `parent` member variables of the `TerminalNode` object using the provided values. The `GameTreeNode` constructor is also called with the `round` and `pot` parameters to initialize the base class.

The `TerminalNode` class represents the final state of a game tree, where the game has reached its conclusion and the payoffs for each player can be determined. This class is likely used in a game-playing algorithm, such as a game tree search algorithm, to represent the final outcomes of the game.\\
## Code: 
```
TerminalNode::TerminalNode(vector<double> payoffs, int winner, GameTreeNode::GameRound round, double pot,
                           shared_ptr<GameTreeNode> parent):GameTreeNode(round,pot,parent){
    this->payoffs = payoffs;
    this->winner = winner;
}
```