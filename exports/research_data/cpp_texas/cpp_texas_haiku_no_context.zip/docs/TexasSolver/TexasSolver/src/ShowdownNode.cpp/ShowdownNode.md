`ShowdownNode`: The function of `ShowdownNode` is to represent a node in a game tree where a showdown occurs, where players reveal their hands and the winner is determined based on the provided payoffs.

**Code Description**: The `ShowdownNode` class is a derived class of the `GameTreeNode` class, which represents a node in a game tree. The `ShowdownNode` class has the following member variables:

1. `tie_payoffs`: a vector of double values representing the payoffs for each player in the case of a tie.
2. `player_payoffs`: a 2D vector of double values representing the payoffs for each player based on the outcome of the showdown.

The constructor of the `ShowdownNode` class takes the following parameters:

1. `tie_payoffs`: a vector of double values representing the payoffs for each player in the case of a tie.
2. `player_payoffs`: a 2D vector of double values representing the payoffs for each player based on the outcome of the showdown.
3. `round`: a `GameRound` object representing the current round of the game.
4. `pot`: a double value representing the current pot size.
5. `parent`: a shared pointer to the parent `GameTreeNode` object.

The constructor initializes the `tie_payoffs` and `player_payoffs` member variables by moving the input vectors into them. It then calls the constructor of the parent `GameTreeNode` class, passing the `round`, `pot`, and `parent` parameters.

The purpose of the `ShowdownNode` class is to represent a node in the game tree where a showdown occurs, and the winner is determined based on the provided payoffs. This information can be used by the game engine to determine the outcome of the game and update the game state accordingly.\\
## Code: 
```
ShowdownNode::ShowdownNode(vector<double> tie_payoffs, vector<vector<double>> player_payoffs,
                           GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode>parent):
                           GameTreeNode(round,pot,std::move(parent)) {
    this->tie_payoffs = std::move(tie_payoffs);
    this->player_payoffs = std::move(player_payoffs);
}
```