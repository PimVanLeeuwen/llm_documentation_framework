`PokerSolver`: The function of `PokerSolver` is to initialize a `PokerSolver` object with the necessary data to perform poker hand comparisons.

**Code Description**:
The `PokerSolver` constructor takes the following parameters:
- `ranks`: a string containing a comma-separated list of card ranks (e.g., "2,3,4,5,6,7,8,9,T,J,Q,K,A")
- `suits`: a string containing a comma-separated list of card suits (e.g., "c,d,h,s")
- `compairer_file`: a file path to a file containing data for a `Dic5Compairer` object
- `compairer_file_lines`: the number of lines in the `compairer_file`
- `compairer_file_bin`: a file path to a binary file containing data for a `Dic5Compairer` object

The constructor performs the following tasks:
1. Splits the `ranks` and `suits` strings into vectors of strings using the `string_split` function.
2. Creates a `Deck` object using the `ranks_vector` and `suits_vector`.
3. Creates a `shared_ptr` to a `Dic5Compairer` object using the provided `compairer_file`, `compairer_file_lines`, and `compairer_file_bin` parameters.

The `Dic5Compairer` object is likely used for comparing poker hands and determining their relative strength. The `PokerSolver` class provides a way to initialize this comparison functionality with the necessary data, such as the available card ranks and suits, as well as the pre-computed data for the hand comparisons.\\
## Code: 
```
PokerSolver::PokerSolver(string ranks, string suits, string compairer_file,int compairer_file_lines, string compairer_file_bin) {
    vector<string> ranks_vector = string_split(ranks,',');
    vector<string> suits_vector = string_split(suits,',');
    this->deck = Deck(ranks_vector,suits_vector);
    this->compairer = make_shared<Dic5Compairer>(compairer_file,compairer_file_lines,compairer_file_bin);
}
```