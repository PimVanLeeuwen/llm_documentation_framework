`set_niter`: The function of `set_niter` is to set the number of iterations for a progress bar.

**Code Description**: The `set_niter` function takes an integer `niter` as an argument, which represents the number of iterations for the progress bar. The function first checks if the `niter` value is less than or equal to 0. If it is, the function throws a `std::invalid_argument` exception with the message "progressbar::set_niter: number of iterations null or negative". This ensures that the number of iterations is a positive, non-zero value.

If the `niter` value is valid, the function sets the `n_cycles` variable to the provided `niter` value and then returns.

The purpose of this function is to allow the user to set the number of iterations for the progress bar, which is likely used to track the progress of some operation or task. By setting the number of iterations, the progress bar can accurately display the current progress and the overall completion status.\\
## Code: 
```
void progressbar::set_niter(int niter) {
    if (niter <= 0) throw std::invalid_argument(
                "progressbar::set_niter: number of iterations null or negative");
    n_cycles = niter;
    return;
}
```