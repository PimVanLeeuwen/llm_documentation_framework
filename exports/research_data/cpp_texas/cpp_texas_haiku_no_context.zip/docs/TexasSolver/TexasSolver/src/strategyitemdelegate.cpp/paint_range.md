`paint_range`: The function of `paint_range` is to paint the range of a strategy item in a table view.

**Code Description**: The `paint_range` function is responsible for rendering the range of a strategy item in a table view. It takes a `QPainter` object, a `QStyleOptionViewItem` object, and a `QModelIndex` object as input parameters.

The function first initializes the `QStyleOptionViewItem` object and casts the `QAbstractItemModel` associated with the `QModelIndex` to a `TableStrategyModel` object. It then checks if the `TableStrategyModel` object is valid and if the row and column indices are within the bounds of the `ui_p1_range` and `ui_p2_range` vectors.

If the `DetailWindowSetting` mode is set to `RANGE_IP`, the function retrieves the card coordinates from the `ui_p1_range` vector, otherwise, it retrieves them from the `ui_p2_range` vector.

The function then calculates the average range value for the card coordinates and checks if it is within the valid range of 0 to 1. If the range value is valid, the function calculates the fold probability and the remaining height for the range display. It then draws a yellow background for the remaining height, representing the range.

Finally, the function creates a `QTextDocument` object, sets its HTML content to the `options.text`, and draws the content within the clipped rectangle of the `options.rect`.

The purpose of this function is to provide a visual representation of the strategy item's range in the table view, allowing users to easily understand the probability distribution of the strategy.\\
## Code: 
```
void StrategyItemDelegate::paint_range(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);
    const TableStrategyModel * tableStrategyModel = qobject_cast<const TableStrategyModel*>(index.model());

    vector<pair<int,int>> card_cords;
    if(tableStrategyModel == NULL
            || tableStrategyModel->ui_p1_range.size() <= index.row()
            || tableStrategyModel->ui_p1_range.size() <= index.column()
            || tableStrategyModel->ui_p2_range.size() <= index.row()
            || tableStrategyModel->ui_p2_range.size() <= index.column()
            ){
        return;
    }
    if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP){
        card_cords = tableStrategyModel->ui_p1_range[index.row()][index.column()];
    }else{
        card_cords = tableStrategyModel->ui_p2_range[index.row()][index.column()];
    }

    if(tableStrategyModel->p1_range.empty() || tableStrategyModel->p2_range.empty()){
        return;
    }

    if(!card_cords.empty()){
        float range_number = 0;
        for(auto one_cord:card_cords){
            if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP){
                range_number += tableStrategyModel->p1_range[one_cord.first][one_cord.second];
            }else{
                // when it's oop, which is p1
                range_number += tableStrategyModel->p2_range[one_cord.first][one_cord.second];
            }
        }
        range_number = range_number / card_cords.size();

        if(range_number < 0 || range_number > 1) throw runtime_error("range number incorrect in strategyitemdeletage");

        float fold_prob = 1 - range_number;
        int disable_height = (int)(fold_prob * option.rect.height());
        int remain_height = option.rect.height() - disable_height;

        // draw background for flod
        QRect rect(option.rect.left(), option.rect.top() + disable_height,\
         option.rect.width(), remain_height);
        QBrush brush(Qt::yellow);
        painter->fillRect(rect, brush);
    }
    QTextDocument doc;
    doc.setHtml(options.text);

    options.text = "";
    //options.widget->style()->drawControl(QStyle::CE_ItemViewItem, &option, painter);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```