`BoardSelectorTableModel`: The function of `BoardSelectorTableModel` is to create a table model that represents a board selector, which is likely used in a user interface to allow the selection of a board.

**Code Description**:

1. The constructor takes three parameters:
   - `QStringList ranks`: A list of ranks (e.g., "A", "2", "3", ...) that will be used to represent the columns of the table.
   - `QString initial_board`: The initial board text that will be used to set the initial state of the table.
   - `QObject *parent`: The parent object for the table model.

2. The constructor initializes the following member variables:
   - `ranklist`: Stores the list of ranks passed as a parameter.
   - `suitlist`: Stores a list of suits (clubs, diamonds, hearts, spades) split from a comma-separated string.
   - `grids_string`: A 2D vector that stores the text representation of each cell in the table, generated using the `get_ij_text()` function.
   - `string2ij`: A map that stores the mapping between the cell text and its corresponding row and column indices.
   - `grids_float`: A 2D vector that stores the float values for each cell in the table, initially set to 0.0.

3. The constructor then calls the `setBoardText()` function (not shown in the provided code) to set the initial board text.

The purpose of this class is to provide a data model for a table-like representation of a board, where each cell can have a text and a float value associated with it. The table is organized by ranks (columns) and suits (rows), and the initial state of the table can be set using the `initial_board` parameter. This table model can be used in a user interface to allow the selection and manipulation of a board.\\
## Code: 
```
BoardSelectorTableModel::BoardSelectorTableModel(QStringList ranks,QString initial_board,QObject *parent):QAbstractItemModel(parent){
    this->ranklist = ranks;
    this->suitlist = QString("c,d,h,s").split(",");

    this->grids_string = vector<vector<QString>>(this->suitlist.size());
    for(int i = 0;i < this->suitlist.size();i ++){
        this->grids_string[i] = vector<QString>(this->ranklist.size());
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_string[i][j] = this->get_ij_text(i,j);
            this->string2ij[this->get_ij_text(i,j)] = pair<int,int>(i,j);
        }
    }

    this->grids_float = vector<vector<float>>(this->suitlist.size());
    for(int i = 0;i < this->suitlist.size();i ++){
        this->grids_float[i] = vector<float>(this->ranklist.size(),0.0);
    }
    this->setBoardText(initial_board);
}
```