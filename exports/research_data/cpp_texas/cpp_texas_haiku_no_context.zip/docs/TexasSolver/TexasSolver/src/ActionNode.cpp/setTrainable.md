`setTrainable`: The function of `setTrainable` is to set the `trainables` and `player_privates` member variables of the `ActionNode` class.

**Code Description**: The `setTrainable` function takes two parameters:
1. `trainables`: a vector of shared pointers to `Trainable` objects
2. `player_privates`: a pointer to a vector of `PrivateCards` objects

The function then assigns the `trainables` vector to the `trainables` member variable of the `ActionNode` class, and the `player_privates` pointer to the `player_privates` member variable of the `ActionNode` class.

This function is likely used to initialize or update the `trainables` and `player_privates` data members of the `ActionNode` class, which are likely used in other parts of the code to perform some kind of training or processing related to the game or application.\\
## Code: 
```
void ActionNode::setTrainable(vector<shared_ptr<Trainable>> trainables,vector<PrivateCards>* player_privates) {
    this->trainables = trainables;
    this->player_privates = player_privates;
}
```