`getAverageStrategy`: The function of `getAverageStrategy` is to calculate the average strategy for a given set of actions and cards.

**Code Description**: The `getAverageStrategy` function is part of the `DiscountedCfrTrainable` class. It calculates the average strategy for a set of actions and cards by following these steps:

1. It initializes a vector `average_strategy` with a size equal to the product of the number of actions (`action_number`) and the number of cards (`card_number`).
2. It iterates through each card (`private_id`) and calculates the sum of the cumulative rewards (`cum_r_plus`) for all actions.
3. For each action (`action_id`) and card (`private_id`), it calculates the average strategy by dividing the cumulative reward for that action and card by the total sum of cumulative rewards for that card. If the total sum of cumulative rewards is 0, it sets the average strategy to 1/`action_number` (i.e., a uniform distribution).
4. Finally, it returns the `average_strategy` vector.

The purpose of this function is to provide the average strategy for the given set of actions and cards, which can be useful in various decision-making or optimization algorithms in the context of the `DiscountedCfrTrainable` class.\\
## Code: 
```
const vector<float> DiscountedCfrTrainable::getAverageStrategy() {
    vector<float> average_strategy;
    average_strategy = vector<float>(this->action_number * this->card_number);
    for (int private_id = 0; private_id < this->card_number; private_id++) {
        float r_plus_sum = 0;
        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            r_plus_sum += this->cum_r_plus[index];
        }

        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            if(r_plus_sum) {
                average_strategy[index] = this->cum_r_plus[index] / r_plus_sum;
            }else{
                average_strategy[index] = 1.0 / this->action_number;
            }
        }
    }
    return average_strategy;
}
```