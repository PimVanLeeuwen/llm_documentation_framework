`updateRegrets`: The function of `updateRegrets` is to update the regrets, R+ (positive regrets), and cumulative R+ values based on the provided regrets, iteration number, and reach probabilities.

**Code Description**:
1. The function takes three parameters:
   - `regrets`: a vector of float values representing the regrets for each action and private card combination.
   - `iteration_number`: an integer representing the current iteration number.
   - `reach_probs`: a vector of float values representing the reach probabilities for each private card.

2. The function first assigns the `regrets` vector to the object's `regrets` member variable. It then checks if the length of the `regrets` vector matches the expected length (action_number * card_number). If not, it throws a `runtime_error`.

3. The function then initializes the `r_plus_sum` and `cum_r_plus_sum` vectors to 0. These vectors will store the sum of the positive regrets and the cumulative sum of the positive regrets, respectively, for each private card.

4. The function then iterates through each action and private card combination. For each combination:
   - It calculates the index into the `regrets` vector.
   - It updates the `r_plus` (positive regrets) value by taking the maximum of 0 and the sum of the current regret and the previous `r_plus` value.
   - It adds the current `r_plus` value to the `r_plus_sum` for the current private card.
   - It updates the `cum_r_plus` (cumulative positive regrets) value by adding the current `r_plus` value multiplied by the `iteration_number`.
   - It adds the current `cum_r_plus` value to the `cum_r_plus_sum` for the current private card.

In summary, the `updateRegrets` function updates the regrets, positive regrets, and cumulative positive regrets based on the provided inputs. This information is used in the implementation of the CFR+ (Counterfactual Regret Minimization Plus) algorithm, which is a technique for learning optimal strategies in multi-agent games.\\
## Code: 
```
void CfrPlusTrainable::updateRegrets(const vector<float>& regrets, int iteration_number, const vector<float>& reach_probs) {
    this->regrets = regrets;
    if(regrets.size() != this->action_number * this->card_number) throw runtime_error("length not match");

    //Arrays.fill(this.r_plus_sum,0);
    fill(r_plus_sum.begin(),r_plus_sum.end(),0);
    fill(cum_r_plus_sum.begin(),cum_r_plus_sum.end(),0);
    for (int action_id = 0;action_id < action_number;action_id ++) {
        for(int private_id = 0;private_id < this->card_number;private_id ++){
            int index = action_id * this->card_number + private_id;
            float one_reg = regrets[index];

            // 更新 R+
            this->r_plus[index] = max((float)0.0,one_reg + this->r_plus[index]);
            this->r_plus_sum[private_id] += this->r_plus[index];

            // 更新累计策略
            this->cum_r_plus[index] += this->r_plus[index] * iteration_number;
            this->cum_r_plus_sum[private_id] += this->cum_r_plus[index];
        }
    }
}
```