`get_game_action_str`: The function of `get_game_action_str` is to return a QString (a Qt string) that represents the given `GameTreeNode::PokerActions` action and the associated amount (if applicable).

**Code Description**: The `get_game_action_str` function takes two parameters: `GameTreeNode::PokerActions action` and `float amount`. It then uses a series of `if-else` statements to determine the appropriate string representation of the given action:

1. If the `action` is `GameTreeNode::PokerActions::CHECK`, the function returns the string "CHECK".
2. If the `action` is `GameTreeNode::PokerActions::BET`, the function returns the string "BET " followed by the value of the `amount` parameter.
3. If the `action` is `GameTreeNode::PokerActions::RAISE`, the function returns the string "RAISE " followed by the value of the `amount` parameter.
4. If the `action` is `GameTreeNode::PokerActions::FOLD`, the function returns the string "FOLD ".
5. If the `action` is `GameTreeNode::PokerActions::CALL`, the function returns the string "CALL".
6. If the `action` is none of the above, the function throws a `runtime_error` with the message "unknown action when converting in get_game_action_str".

The function uses the `QObject::tr()` function to provide translation support for the strings it returns. This allows the strings to be easily translated into different languages if needed.

Overall, this function is a utility function that helps convert the `GameTreeNode::PokerActions` enum values into user-friendly string representations, which can be useful for displaying the current game state or actions to the user.\\
## Code: 
```
QString TreeItem::get_game_action_str(GameTreeNode::PokerActions action,float amount) const{
    if(action == GameTreeNode::PokerActions::CHECK){
        return QObject::tr("CHECK");
    }
    else if(action == GameTreeNode::PokerActions::BET){
        return QObject::tr("BET ") + QString::number(amount);
    }
    else if(action == GameTreeNode::PokerActions::RAISE){
        return QObject::tr("RAISE ") + QString::number(amount);
    }
    else if(action == GameTreeNode::PokerActions::FOLD){
        return QObject::tr("FOLD ");
    }
    else if(action == GameTreeNode::PokerActions::CALL){
        return QObject::tr("CALL");
    }else{
        throw runtime_error("unknown action when converting in get_game_action_str");
    }

}
```