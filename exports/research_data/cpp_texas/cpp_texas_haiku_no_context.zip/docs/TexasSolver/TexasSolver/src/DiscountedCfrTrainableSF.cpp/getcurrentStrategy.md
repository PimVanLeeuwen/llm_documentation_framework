`getcurrentStrategy`: The function of `getcurrentStrategy` is to return the current strategy of the `DiscountedCfrTrainableSF` object.

**Code Description**: The `getcurrentStrategy` function is a member function of the `DiscountedCfrTrainableSF` class. It simply calls the `getcurrentStrategyNoCache` function and returns its result, which is a `vector<float>` representing the current strategy. The `getcurrentStrategyNoCache` function is likely responsible for calculating or retrieving the current strategy, and `getcurrentStrategy` provides a convenient way to access this information without having to call `getcurrentStrategyNoCache` directly.\\
## Code: 
```
const vector<float> DiscountedCfrTrainableSF::getcurrentStrategy() {
    return this->getcurrentStrategyNoCache();
}
```