`PrivateCards`: The function of `PrivateCards` is to create an object that represents a pair of private cards in a card game.

**Code Description**:
The `PrivateCards` class has a constructor that takes three parameters: `card1`, `card2`, and `weight`. The constructor initializes the following member variables:

1. `card1` and `card2`: These variables store the values of the two private cards.
2. `weight`: This variable stores the weight or importance of the private card pair.
3. `relative_prob`: This variable is initialized to 0 and is likely used to store the relative probability of the private card pair.
4. `card_vec`: This is a vector that stores the values of `card1` and `card2`.
5. `hash_code`: This variable is used to generate a unique identifier for the private card pair. If `card1` is greater than `card2`, the hash code is calculated as `card1 * 52 + card2`. Otherwise, it is calculated as `card2 * 52 + card1`.
6. `board_long`: This variable is calculated by calling the `Card::boardInts2long()` function, which likely converts the `card_vec` into a long integer representation of the board.

The purpose of this class is to encapsulate the information about a pair of private cards, including their values, weight, and a unique identifier. This information can be used in a card game or similar application to represent and manipulate the private cards.\\
## Code: 
```
PrivateCards::PrivateCards(int card1, int card2, float weight) {
    this->card1 = card1;
    this->card2 = card2;
    this->weight = weight;
    this->relative_prob = 0;
    this->card_vec = vector<int>{this->card1,this->card2};
    if (card1 > card2){
        this->hash_code = card1 * 52 + card2;
    }else{
        this->hash_code = card2 * 52 + card1;
    }
    this->board_long = Card::boardInts2long(this->card_vec);
}
```