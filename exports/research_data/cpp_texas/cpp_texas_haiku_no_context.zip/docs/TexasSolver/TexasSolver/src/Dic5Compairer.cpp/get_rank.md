`get_rank`: The function of `get_rank` is to calculate the rank of a poker hand based on the given private hand and public board.

**Code Description**: The `get_rank` function is a member function of the `Dic5Compairer` class. It takes two 64-bit unsigned integers, `private_hand` and `public_board`, as input parameters. These integers represent the player's private cards and the public board cards, respectively.

The function first calls another member function, `Card::long2board`, to convert the 64-bit integers into arrays of `Card` objects representing the private hand and public board. This conversion is likely necessary for the internal logic of the `Dic5Compairer` class.

Finally, the function calls another overloaded version of the `get_rank` function, passing the converted `Card` arrays as arguments. This overloaded version of `get_rank` is responsible for the actual calculation of the poker hand rank, which is then returned as the result of the function.

The purpose of this `get_rank` function is to provide a way to determine the rank of a poker hand based on the player's private cards and the public board cards. This information can be useful in various poker-related applications, such as evaluating the strength of a hand or determining the winner of a hand.\\
## Code: 
```
int Dic5Compairer::get_rank(uint64_t private_hand, uint64_t public_board) {
    return this->get_rank(Card::long2board(private_hand),Card::long2board(public_board));
}
```