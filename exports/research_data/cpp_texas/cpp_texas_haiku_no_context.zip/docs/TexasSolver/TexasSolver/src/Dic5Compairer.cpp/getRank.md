`getRank`: The function of `getRank` is to determine the rank or hand type of a given set of playing cards.

**Code Description**:
The `getRank` function takes a vector of `Card` objects as input and returns an integer representing the rank or hand type of the cards. The function first creates a new vector `cards_int` of the same size as the input `cards` vector. It then iterates through the `cards` vector, extracting the integer value of each card using the `getCardInt()` method and storing it in the `cards_int` vector.

Finally, the function calls another `getRank` function, passing the `cards_int` vector as an argument, and returns the result. This suggests that the actual implementation of the rank determination logic is contained in the other `getRank` function, which is not shown in the provided code snippet.

The purpose of this function is to provide a convenient way to convert a vector of `Card` objects into a vector of integer values, which can then be used as input to the main `getRank` function that performs the actual rank determination.\\
## Code: 
```
int Dic5Compairer::getRank(vector<Card> cards) {
    vector<int> cards_int(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_int[i] = cards[i].getCardInt();
    }
    return this->getRank(cards_int);
}
```