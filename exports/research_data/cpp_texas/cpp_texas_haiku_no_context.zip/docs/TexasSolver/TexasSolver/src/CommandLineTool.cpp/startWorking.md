`startWorking`: The function of `startWorking` is to continuously read input lines from the standard input (cin) and process each command.

**Code Description**: The `startWorking` function is part of the `CommandLineTool` class. It enters a loop that continues as long as the standard input (cin) is valid. Inside the loop, the function uses the `getline` function to read a line of input from the standard input and store it in the `input_line` variable. Then, it calls the `processCommand` function, passing the `input_line` as an argument, to process the command.

The loop continues until the standard input (cin) becomes invalid, which could happen if the user closes the input stream or an error occurs.\\
## Code: 
```
void CommandLineTool::startWorking() {
    string input_line;
    while(cin) {
        getline(cin, input_line);
        this->processCommand(input_line);
    };
}
```