`setTrunCard`: The function of `setTrunCard` is to set the `turn_card` member variable of the `TableStrategyModel` class to the provided `turn_card` argument.

**Code Description**: The `setTrunCard` function is a member function of the `TableStrategyModel` class. It takes a single argument, `turn_card`, which is of type `Card`. The function then assigns the value of `turn_card` to the `turn_card` member variable of the `TableStrategyModel` class. This allows the `TableStrategyModel` class to store and manage the current turn card in the game.\\
## Code: 
```
void TableStrategyModel::setTrunCard(Card turn_card){
    this->turn_card = turn_card;
}
```