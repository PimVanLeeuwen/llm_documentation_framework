`DiscountedCfrTrainableSF`: The function of `DiscountedCfrTrainableSF` is to initialize and store various data structures required for the implementation of a Discounted Counterfactual Regret Minimization (DCFR) algorithm.

**Code Description**:
1. The constructor takes two parameters:
   - `privateCards`: A pointer to a vector of `PrivateCards` objects, which likely represent the private cards for each player in a game.
   - `actionNode`: A reference to an `ActionNode` object, which represents a node in the game's decision tree.
2. The constructor initializes the following member variables:
   - `privateCards`: A pointer to the `privateCards` vector passed as a parameter.
   - `action_number`: The number of child nodes (actions) of the `actionNode` passed as a parameter.
   - `card_number`: The size of the `privateCards` vector.
   - `evs`: A vector of `EvsStorage` (likely a custom data type) with a size equal to the product of `action_number` and `card_number`. This vector is used to store the expected values for each action and private card combination.
   - `r_plus`: A vector of `RplusStorage` (likely a custom data type) with a size equal to the product of `action_number` and `card_number`. This vector is used to store the positive regret values for each action and private card combination.
   - `cum_r_plus`: A vector of `CumRplusStorage` (likely a custom data type) with a size equal to the product of `action_number` and `card_number`. This vector is used to store the cumulative positive regret values for each action and private card combination.

The purpose of this class is to provide a data structure that can efficiently store and manage the information required for the DCFR algorithm. The `evs`, `r_plus`, and `cum_r_plus` vectors are used to keep track of the expected values, positive regret, and cumulative positive regret for each possible action and private card combination. This information is crucial for the DCFR algorithm to update the strategy and converge to an optimal solution.\\
## Code: 
```
DiscountedCfrTrainableSF::DiscountedCfrTrainableSF(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();
    this->evs = vector<EvsStorage>(this->action_number * this->card_number, (EvsStorage) 0.0);
    this->r_plus = vector<RplusStorage>(this->action_number * this->card_number, (RplusStorage) 0.0);
    this->cum_r_plus = vector<CumRplusStorage>(this->action_number * this->card_number, (CumRplusStorage) 0.0);
}
```