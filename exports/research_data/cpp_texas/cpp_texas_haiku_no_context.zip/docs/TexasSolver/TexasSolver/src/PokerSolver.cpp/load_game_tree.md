`load_game_tree`: The function of `load_game_tree` is to load a game tree from a file and store it in the `game_tree` member of the `PokerSolver` class.

**Code Description**: The `load_game_tree` function takes a string parameter `game_tree_file`, which represents the file path of the game tree to be loaded. It then creates a new `GameTree` object using the `make_shared` function, passing the `game_tree_file` and the `deck` member of the `PokerSolver` class as arguments. The newly created `GameTree` object is then stored in the `game_tree` member of the `PokerSolver` class.

The purpose of this function is to allow the `PokerSolver` class to access and use a pre-computed game tree, which is likely a data structure that represents the possible game states and actions in a poker game. By loading the game tree from a file, the `PokerSolver` class can avoid the need to compute the game tree from scratch, which can be a computationally expensive operation.\\
## Code: 
```
void PokerSolver::load_game_tree(string game_tree_file) {
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(game_tree_file,this->deck);
    this->game_tree = game_tree;
}
```