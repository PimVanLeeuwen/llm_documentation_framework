`getRiverCombos`: The function of `getRiverCombos` is to retrieve a reference to a vector of `RiverCombs` based on the given player, a vector of `PrivateCards`, and a vector of integers representing the board cards.

**Code Description**: The `getRiverCombos` function takes three parameters:
1. `int player`: The player whose river combinations are being retrieved.
2. `const vector<PrivateCards> &riverCombos`: A reference to a vector of `PrivateCards` representing the river combinations.
3. `const vector<int> &board`: A reference to a vector of integers representing the board cards.

The function first converts the `board` vector of integers into a single `uint64_t` value using the `Card::boardInts2long` function. This is likely done to optimize the subsequent processing of the board cards.

The function then calls another `getRiverCombos` function, passing the `player`, `riverCombos`, and the `board_long` value as arguments. This suggests that the actual implementation of the logic to retrieve the river combinations is handled by the other `getRiverCombos` function.

The purpose of this function is to provide a convenient wrapper around the other `getRiverCombos` function, allowing the caller to pass in a vector of integers representing the board cards, which is then converted to a more efficient `uint64_t` representation before being passed to the underlying function.\\
## Code: 
```
const vector<RiverCombs> &
RiverRangeManager::getRiverCombos(int player, const vector<PrivateCards> &riverCombos, const vector<int> &board) {
    uint64_t board_long = Card::boardInts2long(board);
    return this->getRiverCombos(player,riverCombos,board_long);
}
```