`toBoardLong`: The function of `toBoardLong` is to return the value of the `board_long` member variable of the `PrivateCards` object.

**Code Description**: The `toBoardLong` function is a member function of the `PrivateCards` class. It simply returns the value of the `board_long` member variable, which is likely a 64-bit unsigned integer (`uint64_t`) representing some data related to the game board. The commented-out line `return Card::boardInts2long(this->card_vec);` suggests that there may be an alternative implementation that converts a vector of card objects (`this->card_vec`) into a 64-bit long value, but the current implementation simply returns the `board_long` value directly.\\
## Code: 
```
uint64_t PrivateCards::toBoardLong() {
    return this->board_long;
    //return Card::boardInts2long(this->card_vec);
}
```