`operator[]`: The function of `operator[]` is to retrieve the strength value associated with a given hash value in the `FiveCardsStrength` class.

**Code Description**: The `operator[]` function takes a `uint64_t` hash value as input and returns the corresponding strength value. It first checks if the hash value is present in the `flush_map` unordered map. If the hash value is found, it returns the associated strength value. If the hash value is not found in the `flush_map`, it calculates a new hash value using the `ranks_hash` function and then retrieves the strength value from the `other_map` unordered map. The function uses the `at` method to access the value in the `other_map`, which will throw an exception if the hash value is not found in the map.\\
## Code: 
```
int FiveCardsStrength::operator[](uint64_t hash) {
    auto it = flush_map.find(hash);
    if (it != flush_map.end()) return it->second;
    hash = ranks_hash(hash);
    return other_map.at(hash);
}
```