`getReachProbs`: The function of `getReachProbs` is to calculate the reach probabilities for each player's private cards in a game.

**Code Description**: The `getReachProbs` function is a member function of the `PCfrSolver` class. It returns a 2D vector of float values, where each inner vector represents the reach probabilities for a single player's private cards.

The function first initializes a 2D vector `retval` with a size equal to the number of players in the game. It then iterates through each player, retrieving their private cards using the `playerHands` function. For each player, it creates a vector `reach_prob` and populates it with the weight values of the player's private cards. Finally, it assigns this `reach_prob` vector to the corresponding element in the `retval` vector and returns the entire `retval` vector.

The purpose of this function is to provide the reach probabilities for each player's private cards, which can be useful in various game-related calculations or analyses.\\
## Code: 
```
vector<vector<float>> PCfrSolver::getReachProbs() {
    vector<vector<float>> retval(this->player_number);
    for(int player = 0;player < this->player_number;player ++){
        vector<PrivateCards> player_cards = this->playerHands(player);
        vector<float> reach_prob(player_cards.size());
        for(std::size_t i = 0;i < player_cards.size();i ++){
            reach_prob[i] = player_cards[i].weight;
        }
        retval[player] = reach_prob;
    }
    return retval;
}
```