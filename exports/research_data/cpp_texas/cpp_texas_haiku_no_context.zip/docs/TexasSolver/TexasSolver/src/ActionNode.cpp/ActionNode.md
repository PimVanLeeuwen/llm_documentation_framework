`ActionNode`: The function of `ActionNode` is to represent a node in a game tree that corresponds to a player taking one or more actions.

**Code Description**: The `ActionNode` class is a derived class of the `GameTreeNode` class. It represents a node in a game tree where a player takes one or more actions. The constructor of the `ActionNode` class takes the following parameters:

1. `vector<GameActions> actions`: A vector of game actions that the player can take at this node.
2. `vector<shared_ptr<GameTreeNode>> childrens`: A vector of shared pointers to the child nodes of this node, representing the possible outcomes of the player's actions.
3. `int player`: The player who is taking the actions at this node.
4. `GameTreeNode::GameRound round`: The current round of the game.
5. `double pot`: The current size of the pot in the game.
6. `shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node of this node in the game tree.

The constructor initializes the member variables of the `ActionNode` class using the provided parameters. The `actions` and `childrens` vectors are moved into the class using `std::move()` to avoid unnecessary copying. The `player`, `round`, `pot`, and `parent` variables are also initialized using the provided parameters.

The purpose of the `ActionNode` class is to represent a node in a game tree where a player takes one or more actions. The `actions` vector represents the possible actions the player can take at this node, and the `childrens` vector represents the possible outcomes of those actions, which are represented by other `GameTreeNode` objects. The `player` variable keeps track of which player is taking the actions at this node, and the `round`, `pot`, and `parent` variables provide context about the current state of the game.\\
## Code: 
```
ActionNode::ActionNode(vector<GameActions> actions, vector<shared_ptr<GameTreeNode>> childrens, int player,
                       GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent) :GameTreeNode(round,pot,std::move(parent)){
    this->actions = std::move(actions);
    this->player = player;
    this->childrens = std::move(childrens);
    //cout << "ActionNode created" << endl;
}
```