`anchorAt`: The function of `anchorAt` is to retrieve the anchor (hyperlink) at a given point within an HTML-formatted text.

**Code Description**: The `anchorAt` function takes two parameters: `html`, which is a QString (a Qt string type) containing the HTML-formatted text, and `point`, which is a QPoint (a Qt point type) representing a position within the text.

The function first creates a QTextDocument object and sets its HTML content to the provided `html` string. The QTextDocument class is a Qt class that represents a rich-text document, which can be used to display and manipulate HTML-formatted text.

Next, the function retrieves the document layout of the QTextDocument object using the `documentLayout()` method. The document layout is responsible for laying out the text within the document.

The function then calls the `anchorAt()` method of the document layout, passing the `point` parameter. This method returns the anchor (hyperlink) at the specified point within the text, if any.

Finally, the function returns the result of the `anchorAt()` call, which is a QString representing the anchor text or an empty string if no anchor is found at the specified point.

This function can be useful in applications that need to handle user interactions with HTML-formatted text, such as detecting and handling clicks on hyperlinks within the text.\\
## Code: 
```
QString WordItemDelegate::anchorAt(QString html, const QPoint &point) const {
    QTextDocument doc;
    doc.setHtml(html);

    auto textLayout = doc.documentLayout();
    Q_ASSERT(textLayout != 0);
    return textLayout->anchorAt(point);
}
```