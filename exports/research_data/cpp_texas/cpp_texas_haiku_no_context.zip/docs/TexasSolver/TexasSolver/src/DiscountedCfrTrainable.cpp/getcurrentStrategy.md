`getcurrentStrategy`: The function of `getcurrentStrategy` is to return the current strategy of the `DiscountedCfrTrainable` object.

**Code Description**: The `getcurrentStrategy` function is a member function of the `DiscountedCfrTrainable` class. It simply calls the `getcurrentStrategyNoCache` function and returns its result, which is a `vector<float>` representing the current strategy of the object. The `getcurrentStrategyNoCache` function is likely responsible for calculating or retrieving the current strategy, and the `getcurrentStrategy` function provides a convenient way to access this information without having to call the `getcurrentStrategyNoCache` function directly.\\
## Code: 
```
const vector<float> DiscountedCfrTrainable::getcurrentStrategy() {
    return this->getcurrentStrategyNoCache();
}
```