`paint`: The function of `paint` is to draw the contents of a table cell in a board selector table.

**Code Description**:

The `paint` function is a member function of the `BoardSelectorTableDelegate` class, which is likely responsible for rendering the cells in a table view. The function takes three parameters:

1. `QPainter *painter`: A pointer to the QPainter object that will be used to draw the cell contents.
2. `const QStyleOptionViewItem &option`: A reference to a QStyleOptionViewItem object that contains information about the current cell, such as its size, state, and other styling options.
3. `const QModelIndex &index`: A reference to a QModelIndex object that represents the current cell's position in the table model.

The function performs the following tasks:

1. Saves the current painter state using `painter->save()`.
2. Initializes a new QStyleOptionViewItem object called `options` and sets its properties based on the `option` parameter using `initStyleOption(&options, index)`.
3. Calculates the rectangle that represents the cell's area using the `option.rect` properties.
4. Fills the entire cell rectangle with a gray background using `painter->fillRect()`.
5. Retrieves the board value for the current cell from the `boardSelectorTableModel` using `getBoardAt(index.row(), index.column())`.
6. Calculates the height of the disabled (gray) portion of the cell based on the fold probability (1 - board value) and the height of the remaining (yellow) portion.
7. Fills the remaining portion of the cell with a yellow background using `painter->fillRect()`.
8. Creates a QTextDocument object and sets its HTML content using the `Card` class (which is not shown in the provided code).
9. Translates the painter to the top-left corner of the cell's rectangle using `painter->translate()`.
10. Draws the contents of the QTextDocument object within the cell's rectangle using `doc.drawContents()`.
11. Restores the painter's state using `painter->restore()`.

The overall purpose of this code is to provide a custom rendering of the table cells in a board selector table, where the cell's appearance is determined by\\
## Code: 
```
void BoardSelectorTableDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const{

    painter->save();
    auto options = option;
    initStyleOption(&options, index);

    QRect rect(option.rect.left(), option.rect.top(),\
             option.rect.width(), option.rect.height());
    QBrush brush(Qt::gray);
    painter->fillRect(rect, brush);

    float board_float = this->boardSelectorTableModel->getBoardAt(index.row(),index.column());

    float fold_prob = 1 - board_float;
    int disable_height = (int)(fold_prob * option.rect.height());
    int remain_height = option.rect.height() - disable_height;

    rect = QRect(option.rect.left(), option.rect.top() + disable_height,\
     option.rect.width(), remain_height);
    brush = QBrush(Qt::yellow);
    painter->fillRect(rect, brush);

    QTextDocument doc;
    doc.setHtml(Card(options.text.toStdString()).toFormattedHtml());

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
    painter->restore();
}
```