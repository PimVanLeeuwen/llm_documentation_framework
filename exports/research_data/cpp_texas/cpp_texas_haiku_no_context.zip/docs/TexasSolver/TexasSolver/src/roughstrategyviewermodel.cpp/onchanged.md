`onchanged`: The function of `onchanged` is to emit a signal indicating that the header data has changed.

**Code Description**: The `onchanged()` function is a member function of the `RoughStrategyViewerModel` class. When this function is called, it emits the `headerDataChanged` signal, which is a signal provided by the Qt framework. The `headerDataChanged` signal is used to notify the view that the header data has changed, so that the view can update its display accordingly.

The `headerDataChanged` signal is emitted with the following arguments:

1. `Qt::Horizontal`: This indicates that the header data has changed in the horizontal direction (i.e., the column headers).
2. `0`: This is the first column index.
3. `columnCount()`: This is the last column index, which is obtained by calling the `columnCount()` function of the model.

By emitting this signal, the `RoughStrategyViewerModel` class is informing any connected views that the header data has changed, so that the views can update their display to reflect the new header data.\\
## Code: 
```
void RoughStrategyViewerModel::onchanged(){
    emit headerDataChanged(Qt::Horizontal, 0 , columnCount());
}
```