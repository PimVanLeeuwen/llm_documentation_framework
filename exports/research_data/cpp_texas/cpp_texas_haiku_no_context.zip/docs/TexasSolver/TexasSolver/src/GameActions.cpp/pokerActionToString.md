`pokerActionToString`: The function of `pokerActionToString` is to convert a `GameTreeNode::PokerActions` enum value to a corresponding string representation.

**Code Description**: The `pokerActionToString` function takes a `GameTreeNode::PokerActions` enum value as input and returns a string representation of that value. The function uses a `switch` statement to map each enum value to a corresponding string.

The possible enum values and their corresponding string representations are:
- `GameTreeNode::PokerActions::BEGIN`: "BEGIN"
- `GameTreeNode::PokerActions::ROUNDBEGIN`: "ROUNDBEGIN"
- `GameTreeNode::PokerActions::BET`: "BET"
- `GameTreeNode::PokerActions::RAISE`: "RAISE"
- `GameTreeNode::PokerActions::CHECK`: "CHECK"
- `GameTreeNode::PokerActions::FOLD`: "FOLD"
- `GameTreeNode::PokerActions::CALL`: "CALL"

If the input `pokerActions` value is not one of the recognized enum values, the function throws a `runtime_error` with the message "PokerActions not found".

This function is likely used in a larger context, such as a poker game simulation or analysis, where the string representations of the poker actions are needed for logging, display, or other purposes.\\
## Code: 
```
string GameActions::pokerActionToString(GameTreeNode::PokerActions pokerActions) {
    switch (pokerActions)
    {
        case GameTreeNode::PokerActions::BEGIN :   return "BEGIN";
        case GameTreeNode::PokerActions::ROUNDBEGIN :   return "ROUNDBEGIN";
        case GameTreeNode::PokerActions::BET :   return "BET";
        case GameTreeNode::PokerActions::RAISE :   return "RAISE";
        case GameTreeNode::PokerActions::CHECK :   return "CHECK";
        case GameTreeNode::PokerActions::FOLD :   return "FOLD";
        case GameTreeNode::PokerActions::CALL :   return "CALL";
        default:{
            throw runtime_error("PokerActions not found");
        }
    }
}
```