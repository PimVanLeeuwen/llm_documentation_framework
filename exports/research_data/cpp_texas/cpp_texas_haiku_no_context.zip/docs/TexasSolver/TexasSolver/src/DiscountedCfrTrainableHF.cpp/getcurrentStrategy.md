`getcurrentStrategy`: The function of `getcurrentStrategy` is to return the current strategy of the `DiscountedCfrTrainableHF` object.

**Code Description**: The `getcurrentStrategy` function is a member function of the `DiscountedCfrTrainableHF` class. It simply calls the `getcurrentStrategyNoCache` function and returns its result, which is a `vector<float>` representing the current strategy of the object. The function does not perform any additional processing or caching of the strategy, it simply delegates the work to the `getcurrentStrategyNoCache` function.\\
## Code: 
```
const vector<float> DiscountedCfrTrainableHF::getcurrentStrategy() {
    return this->getcurrentStrategyNoCache();
}
```