`cfr`: The function of `cfr` is to recursively compute the counterfactual regret minimization (CFR) values for a given game tree node, based on the player, reach probabilities, iteration, current board state, and deal.

**Code Description**:

The `cfr` function is a part of the `PCfrSolver` class and is responsible for computing the CFR values for different types of game tree nodes. It takes several parameters:

1. `player`: The player whose perspective the CFR values are being computed for.
2. `node`: A shared pointer to the current game tree node being processed.
3. `reach_probs`: A vector of float values representing the reach probabilities for the current player.
4. `iter`: The current iteration of the CFR algorithm.
5. `current_board`: The current board state represented as a 64-bit integer.
6. `deal`: The current deal (e.g., community cards) in the game.

The function uses a switch statement to handle different types of game tree nodes:

1. `ACTION`: If the current node is an `ActionNode`, the function calls the `actionUtility` function to compute the CFR values for the action node.
2. `SHOWDOWN`: If the current node is a `ShowdownNode`, the function calls the `showdownUtility` function to compute the CFR values for the showdown node.
3. `TERMINAL`: If the current node is a `TerminalNode`, the function calls the `terminalUtility` function to compute the CFR values for the terminal node.
4. `CHANCE`: If the current node is a `ChanceNode`, the function calls the `chanceUtility` function to compute the CFR values for the chance node.

The specific implementation of the `actionUtility`, `showdownUtility`, `terminalUtility`, and `chanceUtility` functions is not provided in the given code snippet, but they are likely responsible for the actual computation of the CFR values for the respective node types.

The `cfr` function is a key component of the Counterfactual Regret Minimization (CFR) algorithm, which is a popular technique for solving extensive-form games, such as poker. The CFR algorithm aims to find an approximate Nash\\
## Code: 
```
vector<float> PCfrSolver::cfr(int player, shared_ptr<GameTreeNode> node, const vector<float> &reach_probs, int iter,
                                    uint64_t current_board,int deal) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
            return actionUtility(player, action_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::SHOWDOWN: {
            shared_ptr<ShowdownNode> showdown_node = std::dynamic_pointer_cast<ShowdownNode>(node);
            return showdownUtility(player, showdown_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::TERMINAL: {
            shared_ptr<TerminalNode> terminal_node = std::dynamic_pointer_cast<TerminalNode>(node);
            return terminalUtility(player, terminal_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::CHANCE: {
            shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
            return chanceUtility(player, chance_node, reach_probs, iter, current_board,deal);
        }default:
            throw runtime_error("node type unknown");
    }
}
```