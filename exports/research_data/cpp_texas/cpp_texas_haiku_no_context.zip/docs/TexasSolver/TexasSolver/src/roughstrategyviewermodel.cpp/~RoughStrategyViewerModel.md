`~RoughStrategyViewerModel`: The function of `~RoughStrategyViewerModel` is to serve as the destructor for the `RoughStrategyViewerModel` class.

**Code Description**: The provided code snippet represents the implementation of the destructor for the `RoughStrategyViewerModel` class. The destructor is a special member function that is automatically called when an object of the `RoughStrategyViewerModel` class is about to be destroyed, either explicitly or implicitly. In this case, the destructor is empty, meaning that it does not perform any specific cleanup or resource release operations. This suggests that the `RoughStrategyViewerModel` class may not have any dynamically allocated resources or other cleanup tasks that need to be handled in the destructor.\\
## Code: 
```
RoughStrategyViewerModel::~RoughStrategyViewerModel()
{
}
```