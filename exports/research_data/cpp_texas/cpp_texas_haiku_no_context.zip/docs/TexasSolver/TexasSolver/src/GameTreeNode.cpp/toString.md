`toString`: The function of `toString` is to generate a string representation of the current `GameTreeNode` object.

**Code Description**: The `toString` function is a method of the `GameTreeNode` class. It is responsible for generating a string representation of the current `GameTreeNode` object, which can be useful for debugging or logging purposes.

The function first checks if the current `GameTreeNode` has a parent node. If the parent node is `nullptr`, it returns a string in the format `"%s begin"`, where `%s` is replaced with the value of the `round` variable.

If the parent node is not `nullptr`, the function checks the type of the parent node. If the parent node is an `ActionNode`, the function iterates through the actions associated with the parent node and checks if the current `GameTreeNode` is one of the children of the parent node. If so, it prints a string in the format `"<- (player %s %s)"`, where `%s` is replaced with the player associated with the action and the string representation of the action.

If the parent node is a `ChanceNode`, the function iterates through the child nodes of the parent node and checks if the current `GameTreeNode` is one of the children. If so, it prints a string in the format `"<- (deal card %s)"`, where `%s` is replaced with the string representation of the card dealt.

Finally, the function returns an empty string.

Overall, the `toString` function is used to generate a string representation of the current `GameTreeNode` object, which can be useful for debugging or logging purposes. It does this by examining the parent node of the current `GameTreeNode` and generating a string based on the type of the parent node and the relationship between the current `GameTreeNode` and its parent.\\
## Code: 
```
string GameTreeNode::toString(){
    /*
    shared_ptr<GameTreeNode>parent_node = node->parent;
    string round;
    if (parent_node == nullptr) return tfm::format("%s begin",round);
    if(parent_node->getType() == GameTreeNodeType::ACTION){
        ActionNode action_node = (ActionNode)parent_node;
        for(int i = 0;i < action_node.getActions().size();i ++){
            if(action_node.getChildrens().get(i) == node){
                System.out.print(String.format("<- (player %s %s)",
                           action_node.getPlayer(),
                           action_node.getActions().get(i).toString()
                    ));
        }
        }
    }else if(parent_node->getType() == GameTreeNodeType::CHANCE){
        ChanceNode chance_node = (ChanceNode)parent_node;
        for(int i = 0;i < chance_node.getChildrens().size();i ++){
            if(chance_node.getChildrens().get(i) == node){
                System.out.print(String.format("<- (deal card %s)",
                       chance_node.getCards().get(i).toString()
            ));
        }
    }
    */
    return "";
}
```