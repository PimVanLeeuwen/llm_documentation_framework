`get_setting`: The function of `get_setting` is to retrieve a `StreetSetting` object based on the provided `player` and `round` parameters.

**Code Description**: The `get_setting` function is a member function of the `GameTreeBuildingSettings` class. It takes two string parameters: `player` and `round`. The function checks the values of these parameters and returns the corresponding `StreetSetting` object.

The function uses a series of `if-else` statements to determine which `StreetSetting` object to return:

1. If the `player` is "ip" (in-position) and the `round` is "flop", the function returns the `flop_ip` `StreetSetting` object.
2. If the `player` is "ip" and the `round` is "turn", the function returns the `turn_ip` `StreetSetting` object.
3. If the `player` is "ip" and the `round` is "river", the function returns the `river_ip` `StreetSetting` object.
4. If the `player` is "oop" (out-of-position) and the `round` is "flop", the function returns the `flop_oop` `StreetSetting` object.
5. If the `player` is "oop" and the `round` is "turn", the function returns the `turn_oop` `StreetSetting` object.
6. If the `player` is "oop" and the `round` is "river", the function returns the `river_oop` `StreetSetting` object.
7. If the provided `player` and `round` parameters do not match any of the above conditions, the function throws a `runtime_error` with the message "get_setting not valid".

The purpose of this function is to provide a convenient way to retrieve the appropriate `StreetSetting` object based on the player's position and the current round of the game. This information is likely used elsewhere in the `GameTreeBuildingSettings` class or the larger application to configure or adjust the game settings.\\
## Code: 
```
StreetSetting& GameTreeBuildingSettings::get_setting(string player,string round){
    if(player == "ip" && round == "flop") return flop_ip;
    else if(player == "ip" && round == "turn") return turn_ip;
    else if(player == "ip" && round == "river") return river_ip;
    else if(player == "oop" && round == "flop") return flop_oop;
    else if(player == "oop" && round == "turn") return turn_oop;
    else if(player == "oop" && round == "river") return river_oop;
    else throw runtime_error("get_setting not valid");
}
```