`setRelativeProbs`: The function of `setRelativeProbs` is to calculate the relative probabilities of the private cards held by each player in a multi-player game.

**Code Description**:
The `setRelativeProbs` function is responsible for calculating the relative probabilities of the private cards held by each player in a multi-player game. The function performs the following steps:

1. It first determines the number of players by getting the size of the `private_cards` vector.
2. For each player, it calculates the relative probability of each of their private cards by considering the possible combinations of the opponent's private cards.
3. The function first iterates through the player's private cards and checks if the current card's board representation has any intercepts with the initial board. If it does, the card is skipped as it is not a valid combination.
4. For each valid card of the current player, the function then iterates through the opponent's private cards and checks if the opponent's card's board representation has any intercepts with the initial board or the current player's card. If there are no intercepts, the weight of the opponent's card is added to the `oppo_prob_sum` variable.
5. The relative probability of the current player's card is then calculated as the product of the opponent's probability sum and the weight of the current player's card. This value is stored in the `relative_prob` field of the current player's card.
6. The function then normalizes the relative probabilities of all the current player's cards by dividing each card's `relative_prob` by the sum of all the current player's cards' `relative_prob` values.
7. This process is repeated for each player in the game.

The purpose of this function is to provide a way to estimate the relative probabilities of the private cards held by each player, which can be useful for decision-making and strategy in the game.\\
## Code: 
```
void PrivateCardsManager::setRelativeProbs() {
    int players = this->private_cards.size();
    for(int player_id = 0; player_id < players;player_id ++){
        // TODO 这里只考虑了两个玩家的情况
        int oppo = 1 - player_id;
        float player_prob_sum = 0;

        for(std::size_t i = 0;i < this->private_cards[player_id].size();i ++) {
            float oppo_prob_sum = 0;
            PrivateCards* player_card = &this->private_cards[player_id][i];
            uint64_t player_long = Card::boardInts2long(player_card->get_hands());

            //
            if (Card::boardsHasIntercept(player_long,this->initialboard)){
                continue;
            }

            for (auto oppo_card : this->private_cards[oppo]) {
                uint64_t oppo_long = Card::boardInts2long(oppo_card.get_hands());
                if (Card::boardsHasIntercept(oppo_long,this->initialboard)
                    || Card::boardsHasIntercept(oppo_long,player_long)
                        ){
                    continue;
                }
                oppo_prob_sum += oppo_card.weight;

            }
            player_card->relative_prob = oppo_prob_sum * player_card->weight;
            player_prob_sum += player_card->relative_prob;
        }
        for(std::size_t i = 0;i < this->private_cards[player_id].size();i ++) {
            this->private_cards[player_id][i].relative_prob = this->private_cards[player_id][i].relative_prob / player_prob_sum;
            //player_card.relative_prob = player_card.relative_prob / player_prob_sum;
        }

    }
}
```