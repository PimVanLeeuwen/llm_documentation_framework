`paint_range`: The function of `paint_range` is to paint the range information for a specific cell in a table view.

**Code Description**:
The `paint_range` function is responsible for rendering the range information for a specific cell in a table view. It takes three parameters: a `QPainter` object, a `QStyleOptionViewItem` object, and a `QModelIndex` object.

The function first initializes the `options` variable by calling the `initStyleOption` function, which sets the default style options for the view item. It then casts the `index.model()` to a `DetailViewerModel` object, which is likely a custom model class used in the application.

The function then checks if the `tableStrategyModel` of the `DetailViewerModel` has a non-null `treeItem`. If so, it retrieves the card coordinates for the current cell based on the `detailWindowSetting->mode` (either `RANGE_IP` or not). It then calculates the index of the current cell within the card coordinates vector.

If the index is within the bounds of the card coordinates vector, the function retrieves the corresponding card coordinates and the range number for the current cell. It then calculates the height of the "fold" area based on the range number and draws a yellow background for the remaining area.

Finally, the function sets the text of the `options` object to display the card names and the range number, and uses the `QTextDocument` class to render the text within the cell's rectangle.

Overall, the `paint_range` function is responsible for rendering the range information for a specific cell in a table view, including the card names and the range number, with a visual indication of the "fold" area based on the range number.\\
## Code: 
```
void DetailItemDelegate::paint_range(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);

    const DetailViewerModel * detailViewerModel = qobject_cast<const DetailViewerModel*>(index.model());
    //vector<pair<GameActions,float>> strategy = detailViewerModel->tableStrategyModel->get_strategy(this->detailWindowSetting->grid_i,this->detailWindowSetting->grid_j);
    options.text = "";

    if(detailViewerModel->tableStrategyModel->treeItem != NULL){
        vector<pair<int,int>> card_cords;
        if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP){
            card_cords = detailViewerModel->tableStrategyModel->ui_p1_range[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j];
        }else{
            card_cords = detailViewerModel->tableStrategyModel->ui_p2_range[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j];
        }

        int ind = index.row() * detailViewerModel->columns + index.column();
        if(ind < card_cords.size()){
            pair<int,int> cord = card_cords[ind];
            float range_number;
            if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP){
                range_number = detailViewerModel->tableStrategyModel->p1_range[cord.first][cord.second];
            }else{
                range_number = detailViewerModel->tableStrategyModel->p2_range[cord.first][cord.second];
            }

            if(range_number < 0 || range_number > 1) throw runtime_error("range number incorrect in strategyitemdeletage");

            float fold_prob = 1 - range_number;
            int disable_height = (int)(fold_prob * option.rect.height());
            int remain_height = option.rect.height() - disable_height;

            // draw background for flod
            QRect rect(option.rect.left(), option.rect.top() + disable_height,\
             option.rect.width(), remain_height);
            QBrush brush(Qt::yellow);
            painter->fillRect(rect, brush);

            options.text = "";
            options.text += detailViewerModel->tableStrategyModel->cardint2card[cord.first].toFormattedHtml();
            options.text += detailViewerModel->tableStrategyModel->cardint2card[cord.second].toFormattedHtml();
            options.text = "<h2>" + options.text + "<\/h2>";

            options.text +=  QString(" <h2>%1<\/h2>").arg(QString::number(range_number,'f',3));
        }
    }

    QTextDocument doc;
    doc.setHtml(options.text);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```