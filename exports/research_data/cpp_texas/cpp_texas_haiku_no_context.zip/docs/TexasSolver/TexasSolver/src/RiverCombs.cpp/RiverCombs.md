`RiverCombs`: The function of `RiverCombs` is to create an instance of the `RiverCombs` class, which is likely used to represent a player's hand in a poker game.

**Code Description**:
The `RiverCombs` class has a constructor that takes four parameters:
1. `vector<int> board`: This parameter represents the community cards (the "board") in a poker game.
2. `PrivateCards private_cards`: This parameter represents the player's private cards.
3. `int rank`: This parameter represents the rank or strength of the player's hand.
4. `int reach_prob_index`: This parameter likely represents the probability of the player reaching the river (the final round of betting) in the game.

The constructor initializes the member variables of the `RiverCombs` class with the values passed in through the parameters. This allows the class to store and manage the relevant information about a player's hand and the game state at the river stage of the poker game.\\
## Code: 
```
RiverCombs::RiverCombs(vector<int> board, PrivateCards private_cards, int rank, int reach_prob_index) {
    this->board = board;
    this->rank = rank;
    this->private_cards = private_cards;
    this->reach_prob_index = reach_prob_index;
}
```