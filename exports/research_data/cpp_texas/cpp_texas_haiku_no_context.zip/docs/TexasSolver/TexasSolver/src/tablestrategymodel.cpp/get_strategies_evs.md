`get_strategies_evs`: The function of `get_strategies_evs` is to calculate the expected values (EVs) of different strategies for a given player in a game tree node.

**Code Description**:

1. The function takes two integer parameters `i` and `j`, which are used to index into the `ui_strategy_table` and retrieve the corresponding strategy information.

2. The function first checks if the `treeItem` is `NULL` or the `current_evs` vector is empty. If either of these conditions is true, it returns an empty `vector<float>`.

3. The function then determines the current player's range (`p1_range` or `p2_range`) based on the value of `current_player`.

4. If either `p1_range` or `p2_range` is empty, the function returns an empty `vector<float>`.

5. The function then retrieves the `GameTreeNode` associated with the `treeItem` and checks if it is an `ActionNode`.

6. If the node is an `ActionNode`, the function iterates through the `ui_strategy_table[i][j]` indices and calculates the expected values for each action in the `ActionNode`.

7. For each index in `ui_strategy_table[i][j]`, the function retrieves the corresponding strategy and expected value vectors, as well as the range value. It then calculates the weighted sum of the expected values, using the strategy probabilities and the range value.

8. After calculating the weighted sum, the function normalizes the expected values by dividing them by the sum of the strategy probabilities.

9. Finally, the function returns the calculated expected values as a `vector<float>`.

The purpose of this function is to provide the expected values for different strategies in a game tree node, which can be used to inform decision-making in the game.\\
## Code: 
```
const vector<float> TableStrategyModel::get_strategies_evs(int i,int j)const{
    vector<float> ret_evs;
    if(this->treeItem == NULL || this->current_evs.empty())return ret_evs;

    const vector<vector<float>> *current_range;
    current_range = (0 == current_player ) ? & p1_range : & p2_range;
    if(p1_range.empty() || p2_range.empty()){
        return ret_evs;
    }

    shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();

    if(node->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);
        vector<GameActions>& gameActions = actionNode->getActions();

        vector<float> strategy_p;
        if(this->ui_strategy_table[i][j].size() > 0){
            ret_evs = vector<float>(gameActions.size());
            std::fill(ret_evs.begin(), ret_evs.end(), 0.);
            strategy_p = vector<float>(gameActions.size());
            std::fill(strategy_p.begin(), strategy_p.end(), 0.);
        }
        float range = 0;
        for(std::pair<int,int> index:this->ui_strategy_table[i][j]){
            int index1 = index.first;
            int index2 = index.second;
            const vector<float>& one_strategy = this->current_strategy[index1][index2];
            const vector<float>& one_ev = this->current_evs[index1][index2];
            const float one_range = (*current_range)[index1][index2];
            if(gameActions.size() != one_strategy.size() || one_ev.size() != one_strategy.size()){
                cout << "index: " << index1 << " " << index2 << endl;
                cout << "i,j: " << i << " " << j << endl;
                cout << "size not match between one_ev, gameAction and one_stragegy: "
                     << one_ev.size() << " " << gameActions.size() << " " << one_strategy.size() << endl;
                throw runtime_error("size not match between one_ev, gameAction and one_stragegy");
            }
            for(std::size_t indi = 0;indi < ret_evs.size();indi ++){
                ret_evs[indi] += one_strategy[indi] * one_ev[indi] * one_range;
                strategy_p[indi] += one_strategy[indi] * one_range;
            }
            range += one_range;
        }
        for(std::size_t indi = 0;indi < ret_evs.size();indi ++){
            if (strategy_p[indi] > 0. && range > 0.) {
                ret_evs[indi] = ret_evs[indi] / strategy_p[indi];
            }
        }
        return ret_evs;
    }else{
        return ret_evs;
    }
}
```