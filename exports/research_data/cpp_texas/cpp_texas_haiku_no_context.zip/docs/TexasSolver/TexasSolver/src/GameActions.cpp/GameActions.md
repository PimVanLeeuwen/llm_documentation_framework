`GameActions`: The function of `GameActions` is to create an object that represents a player's action in a poker game.

**Code Description**:

The `GameActions` class is responsible for creating an object that represents a player's action in a poker game. The class takes two parameters in its constructor: `GameTreeNode::PokerActions action` and `double amount`.

The `action` parameter represents the type of action the player is taking, such as raising, betting, checking, folding, or calling. The `amount` parameter represents the amount of money the player is putting into the pot.

The constructor first sets the `action` member variable to the value of the `action` parameter. Then, it checks the type of action and validates the `amount` parameter accordingly:

1. If the `action` is `RAISE` or `BET`, the constructor checks if the `amount` parameter is not equal to -1. If it is -1, the constructor throws a `runtime_error` with a message indicating that the raise/bet amount should not be -1.
2. If the `action` is not `RAISE` or `BET` (i.e., it's `CHECK`, `FOLD`, or `CALL`), the constructor checks if the `amount` parameter is equal to -1. If it's not -1, the constructor throws a `runtime_error` with a message indicating that the check/fold/call amount should be -1.

Finally, the constructor sets the `amount` member variable to the value of the `amount` parameter.

This class is likely used in a larger poker game implementation to represent the different actions a player can take during the game, and to ensure that the actions and their associated amounts are valid.\\
## Code: 
```
GameActions::GameActions(GameTreeNode::PokerActions action, double amount) {
    this->action = action;
    if (action == GameTreeNode::PokerActions::RAISE || action == GameTreeNode::PokerActions::BET ) {
        if (amount == -1) throw runtime_error(tfm::format("raise/bet amount should not be -1, find %s",amount));
    } else {
        if (amount != -1) throw runtime_error(tfm::format("check/fold/call amount should be -1, find %s",amount));
    }
    this->amount = amount;
}
```