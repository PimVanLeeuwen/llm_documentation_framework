`get_strategy`: The function of `get_strategy` is to retrieve the strategy for a given game state, represented by the indices `i` and `j`.

**Code Description**:

1. The function first checks if the `treeItem` is `NULL`. If it is, it returns an empty vector of `pair<GameActions, float>`.

2. It then retrieves the number of strategies for the given indices `i` and `j` from the `ui_strategy_table`.

3. It gets the `GameTreeNode` associated with the current game state and checks if it is an `ActionNode`.

4. If it is an `ActionNode`, the function retrieves the available `GameActions` and initializes a vector of `float` values called `strategies`.

5. It then calculates the average range value for the current game state by iterating over the card coordinates stored in `ui_strategy_table[i][j]` and summing the corresponding range values from `p1_range` or `p2_range`. If the range number is outside the valid range of [0, 1], it throws a `runtime_error`.

6. If the `ui_strategy_table[i][j]` is not empty, the function initializes the `strategies` vector with zeros.

7. It then iterates over the indices stored in `ui_strategy_table[i][j]` and retrieves the corresponding strategy from `current_strategy`. If the size of the `gameActions` and the strategy do not match, it throws a `runtime_error`.

8. For each strategy, the function updates the `strategies` vector by adding the product of the individual strategy value, the corresponding range value, and the inverse of the number of strategies.

9. Finally, the function creates a vector of `pair<GameActions, float>` by pairing the `gameActions` with their corresponding `strategies` values and returns it.

The main purpose of this function is to calculate the strategy for a given game state, taking into account the available actions and the current range of the players. It does this by retrieving the relevant information from the game tree and the strategy tables, and then combining them to produce the final strategy.\\
## Code: 
```
const vector<pair<GameActions,float>> TableStrategyModel::get_strategy(int i,int j) const{
    vector<pair<GameActions,float>> ret_strategy;
    if(this->treeItem == NULL) return ret_strategy;

    int strategy_number = this->ui_strategy_table[i][j].size();

    shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();

    if(node->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);

        vector<GameActions>& gameActions = actionNode->getActions();

        vector<float> strategies;

        // get range data - initally copied from paint_range - could probably be integrated in loops below for efficiancy
        vector<pair<int,int>> card_cords;
        const vector<vector<float>> *current_range;
        card_cords = ui_strategy_table[i][j];
        current_range = (0 == current_player ) ? & p1_range : & p2_range;

        if(p1_range.empty() || p2_range.empty()){
            return ret_strategy;
        }

        float range_number = 0;
        if(!card_cords.empty()){
            for(std::size_t indi = 0;indi < card_cords.size();indi ++){
                    range_number += (*current_range)[card_cords[indi].first][card_cords[indi].second];
            }
            range_number = range_number / card_cords.size();

            if(range_number < 0 || range_number > 1) throw runtime_error("range number incorrect in strategyitemdeletage");
        }
        else
            return ret_strategy;
        // got range data

        if(this->ui_strategy_table[i][j].size() > 0){
            strategies = vector<float>(gameActions.size());
            std::fill(strategies.begin(), strategies.end(), 0.);
        }
        for(std::pair<int,int> index:this->ui_strategy_table[i][j]){
            int index1 = index.first;
            int index2 = index.second;
            const vector<float>& one_strategy = this->current_strategy[index1][index2];
            if(gameActions.size() != one_strategy.size()){
                cout << "index: " << index1 << " " << index2 << endl;
                cout << "i,j: " << i << " " << j << endl;
                cout << "size not match between gameAction and stragegy: " << gameActions.size() << " " << one_strategy.size() << endl;
                throw runtime_error("size not match between gameAction and stragegy");
            }

            if ( range_number > 0)
                for(std::size_t indi = 0;indi < one_strategy.size();indi ++){
                    strategies[indi] += (one_strategy[indi] * (*current_range)[index1][index2] / range_number / strategy_number);
                }
        }

        for(std::size_t indi = 0;indi < strategies.size();indi ++){
            ret_strategy.push_back(std::pair<GameActions,float>(actionNode->getActions()[indi],
                                                                strategies[indi]));
        }

        return ret_strategy;
    }else{
        return ret_strategy;
    }

}
```