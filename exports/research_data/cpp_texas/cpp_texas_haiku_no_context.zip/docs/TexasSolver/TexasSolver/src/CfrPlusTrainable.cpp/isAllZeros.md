`isAllZeros`: The function of `isAllZeros` is to check if all the elements in the input array are zero.

**Code Description**: The `isAllZeros` function takes a `vector<float>` as input and returns a `bool` value. The function iterates through the input array using a `for` loop, and for each element, it checks if the element is not equal to zero. If any element is found to be non-zero, the function immediately returns `false`. If the loop completes without finding any non-zero element, the function returns `true`, indicating that all the elements in the input array are zero.\\
## Code: 
```
bool CfrPlusTrainable::isAllZeros(vector<float> input_array) {
    for(float i:input_array){
        if (i != 0)return false;
    }
    return true;
}
```