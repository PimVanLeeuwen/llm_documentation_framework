`reset`: The function of `reset` is to reset the progress of a progress bar to its initial state.

**Code Description**: The `reset()` function is part of a `progressbar` class or module. It is responsible for resetting the progress of a progress bar to its initial state. 

The function performs the following actions:

1. Sets the `progress` variable to `0`, which represents the current progress of the progress bar.
2. Sets the `update_is_called` flag to `false`, indicating that the progress bar has not been updated since the last reset.
3. Sets the `last_perc` variable to `0`, which likely represents the last percentage of progress displayed.
4. The function then returns, completing the reset operation.

This function is useful for resetting the progress bar to its starting point, for example, when a new task or process is about to begin. By resetting the progress, the progress bar can be used to track the progress of a new operation.\\
## Code: 
```
void progressbar::reset() {
    progress = 0,
            update_is_called = false;
    last_perc = 0;
    return;
}
```