`printNodeHistory`: The function of `printNodeHistory` is to print the history of a game tree node, including the actions taken by players and the cards dealt in the game.

**Code Description**: The `printNodeHistory` function takes a `GameTreeNode` object as input and recursively traverses the game tree from the given node to the root, printing the history of the game. 

The function first checks if the given node has a parent node. If the parent node is not null, it checks the type of the parent node. If the parent node is an `ActionNode`, it iterates through the actions associated with the parent node and prints the player and the action taken that led to the current node. If the parent node is a `ChanceNode`, it iterates through the child nodes of the parent node and prints the card that was dealt that led to the current node. If the parent node is neither an `ActionNode` nor a `ChanceNode`, it simply prints the string representation of the parent node.

The function then recursively calls itself with the parent node as the new input, continuing the traversal up the game tree until it reaches the root node. Finally, it prints a newline character to separate the output for different game tree nodes.

The commented-out code in the function suggests that the function was originally implemented using a `while` loop instead of recursion, but the functionality remains the same.\\
## Code: 
```
void GameTreeNode::printNodeHistory(GameTreeNode* node) {
    /*
    while(node != nullptr) {
        shared_ptr<GameTreeNode>parent_node = node->parent;
        if (parent_node == nullptr) break;
        if(parent_node instanceof ActionNode){
            ActionNode action_node = (ActionNode)parent_node;
            for(int i = 0;i < action_node.getActions().size();i ++){
                if(action_node.getChildrens().get(i) == node){
                    System.out.print(String.format("<- (player %s %s)",
                                                   action_node.getPlayer(),
                                                   action_node.getActions().get(i).toString()
                    ));
                }
            }
        }else if(parent_node instanceof ChanceNode) {
            ChanceNode chance_node = (ChanceNode)parent_node;
            for(int i = 0;i < chance_node.getChildrens().size();i ++){
                if(chance_node.getChildrens().get(i) == node){
                    System.out.print(String.format("<- (deal card %s)",
                                                   chance_node.getCards().get(i).toString()
                    ));
                }
            }

        }else{
            System.out.print(String.format("<- (%s)",node.toString()));
        }
        node = parent_node;
    }
    System.out.println()
    }
     */
}
```