`timeSinceEpochMillisec`: The function of `timeSinceEpochMillisec` is to return the current time in milliseconds since the Unix epoch (January 1, 1970, 00:00:00 UTC).

**Code Description**: The `timeSinceEpochMillisec` function uses the C++ standard library's `std::chrono` namespace to obtain the current time since the Unix epoch. It does this by:

1. Calling `system_clock::now()` to get the current time as a `system_clock::time_point` object.
2. Using `time_since_epoch()` to get the duration since the Unix epoch as a `system_clock::duration` object.
3. Casting the duration to `milliseconds` using `duration_cast<milliseconds>()`.
4. Calling `count()` on the resulting `milliseconds` object to get the number of milliseconds since the Unix epoch as a `uint64_t` value.

This function provides a simple and efficient way to get the current time in milliseconds since the Unix epoch, which is a common requirement in many applications that need to work with timestamps or measure elapsed time.\\
## Code: 
```
uint64_t timeSinceEpochMillisec() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
}
```