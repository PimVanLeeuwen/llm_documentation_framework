`string_split`: The function of `string_split` is to split a given string into a vector of substrings based on a specified delimiter character.

**Code Description**:
The `string_split` function takes two parameters:
1. `string strin`: The input string to be split.
2. `char split`: The delimiter character used to split the input string.

The function performs the following steps:
1. It creates an empty `vector<string>` called `retval` to store the resulting substrings.
2. It creates a `stringstream` object `ss` and initializes it with the input string `strin`.
3. It uses a `while` loop to repeatedly call the `getline` function to extract substrings from the `stringstream` object `ss`. The `getline` function reads characters from the `stringstream` until it encounters the specified delimiter character `split`, and then stores the extracted substring in the `token` variable.
4. For each extracted substring `token`, the function pushes it into the `retval` vector.
5. Finally, the function returns the `retval` vector containing all the substrings.

The `string_split` function is useful for splitting a string into multiple parts based on a specific delimiter character, such as a comma, space, or newline. This can be helpful in various scenarios, such as parsing CSV data, processing command-line arguments, or splitting text into individual words.\\
## Code: 
```
vector<string> string_split(string strin,char split){
    vector<string> retval;
    stringstream ss(strin);
    string token;
    while (getline(ss,token, split))
    {
        retval.push_back(token);
    }
    return retval;
}
```