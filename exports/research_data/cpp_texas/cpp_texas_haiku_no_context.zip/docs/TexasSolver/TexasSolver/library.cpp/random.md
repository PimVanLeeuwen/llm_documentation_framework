`random`: The function of `random` is to generate a random integer within a specified range.

**Code Description**: The `random` function takes two integer parameters, `min` and `max`, and returns a random integer value between `min` (inclusive) and `max` (exclusive). The function uses the `rand()` function, which is a standard C library function that generates a pseudo-random number, and the modulo operator `%` to ensure the result is within the desired range.

The formula `min + rand() % ((max) - min)` works as follows:

1. `rand() % ((max) - min)` generates a random number between 0 and `(max - min - 1)`, inclusive.
2. Adding `min` to the result shifts the range to the desired interval `[min, max)`.

This function is useful when you need to generate random numbers within a specific range, such as for game development, simulations, or any other application that requires random values.\\
## Code: 
```
int random(int min, int max) //range : [min, max)
{
    return min + rand() % (( max ) - min);
}
```