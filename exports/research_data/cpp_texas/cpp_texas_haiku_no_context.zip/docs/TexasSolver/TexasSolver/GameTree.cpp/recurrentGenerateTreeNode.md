`recurrentGenerateTreeNode`: The function of `recurrentGenerateTreeNode` is to recursively generate a game tree node based on the provided JSON data.

**Code Description**:

The `recurrentGenerateTreeNode` function takes two parameters: `node_json` (a JSON object representing a game tree node) and `parent` (a shared pointer to the parent game tree node). The function is responsible for parsing the JSON data and creating the appropriate type of game tree node based on the information provided.

The function first extracts the "round" and "node_type" values from the JSON data. It checks that the "round" value is one of the valid options ("preflop", "flop", "turn", or "river") and that the "node_type" value is one of the valid options ("Terminal", "Showdown", "Action", or "Chance"). If either of these checks fails, the function throws a runtime error.

If the "node_type" is "Action", the function generates an "Action" node by calling the `generateActionNode` method. This method takes the metadata from the JSON data, as well as the lists of child actions and child nodes, and creates a new "Action" node.

If the "node_type" is "Showdown", the function generates a "Showdown" node by calling the `generateShowdownNode` method. This method takes the metadata from the JSON data and the "round" value and creates a new "Showdown" node.

If the "node_type" is "Terminal", the function generates a "Terminal" node by calling the `generateTerminalNode` method. This method takes the metadata from the JSON data and the "round" value and creates a new "Terminal" node.

If the "node_type" is "Chance", the function generates a "Chance" node by calling the `generateChanceNode` method. This method takes the metadata from the JSON data, the single child node, and the "round" value and creates a new "Chance" node.

The function then returns the newly created game tree node as a shared pointer.

Overall, the `recurrentGenerateTreeNode` function is responsible for parsing the JSON data and creating the appropriate type of game tree node based on the information provided. It uses a series of helper methods to create the different types of\\
## Code: 
```
shared_ptr<GameTreeNode> GameTree::recurrentGenerateTreeNode(json node_json, const shared_ptr<GameTreeNode>& parent) {
    json meta = node_json["meta"];
    string round = meta["round"];
    if(round.empty()){
        throw runtime_error("node json get round null pointer");
    }

    if(! (round == "preflop"
          || round == "flop"
          || round == "turn"
          || round == "river"
          )
            ){
        throw runtime_error(tfm::format("round %s not found",round));
    }

    string node_type = meta["node_type"];
    if(node_type.empty()){
        throw runtime_error("node json get round null pointer");
    }
    if (! (   node_type == "Terminal"
           || node_type == "Showdown"
           || node_type ==  "Action"
           || node_type ==  "Chance"
    )
            ){
        throw runtime_error(tfm::format("node type %s not found",node_type));
    }

    if(node_type == "Action") {
        // 孩子节点的动作，存在list里
        auto childrens_actions = node_json["children_actions"].get<std::vector<string>>();
        // 孩子节点本身，同样存在list里,和上面的children_actions 一一对应,事实上两者的长度一致
        vector<json> childrens = node_json["children"].get<std::vector<json>>();
        if (childrens.size() != childrens_actions.size()) {
            throw runtime_error("action node child length mismatch");
        }
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateActionNode(meta, childrens_actions, childrens, round,parent));
    }
    else if(node_type == "Showdown") {
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateShowdownNode(meta, round,parent));
    }
    else if(node_type == "Terminal") {
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateTerminalNode(meta, round,parent));
    }
    else if(node_type == "Chance") {
        auto childrens = node_json["children"].get<std::vector<json>>();
        if(childrens.size() != 1) throw runtime_error("Chance node should have only one child");
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateChanceNode(meta, childrens[0], round,parent));
    }
    else{
        throw runtime_error(tfm::format("node type %s not found",node_type));
    }
}
```