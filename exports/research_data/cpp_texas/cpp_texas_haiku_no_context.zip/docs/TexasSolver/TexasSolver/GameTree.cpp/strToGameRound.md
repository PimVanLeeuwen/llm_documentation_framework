`strToGameRound`: The function of `strToGameRound` is to convert a string representation of a game round to the corresponding `GameTreeNode::GameRound` enum value.

**Code Description**: The `strToGameRound` function takes a string `round` as input and returns the corresponding `GameTreeNode::GameRound` enum value. It does this by checking the value of the input string and assigning the appropriate enum value to the `game_round` variable.

If the input string is "preflop", the function sets `game_round` to `GameTreeNode::GameRound::PREFLOP`. If the input string is "flop", the function sets `game_round` to `GameTreeNode::GameRound::FLOP`. If the input string is "turn", the function sets `game_round` to `GameTreeNode::GameRound::TURN`. If the input string is "river", the function sets `game_round` to `GameTreeNode::GameRound::RIVER`.

If the input string does not match any of the expected values, the function throws a `runtime_error` with a message indicating that the game round was not found.

Finally, the function returns the `game_round` value, which represents the corresponding game round.\\
## Code: 
```
GameTreeNode::GameRound GameTree::strToGameRound(const string& round) {
    GameTreeNode::GameRound game_round;
    if(round == "preflop"){
        game_round = GameTreeNode::GameRound::PREFLOP;
    }
    else if (round == "flop"){
        game_round = GameTreeNode::GameRound::FLOP;
    }
    else if(round == "turn"){
        game_round = GameTreeNode::GameRound::TURN;
    }
    else if(round == "river"){
        game_round = GameTreeNode::GameRound::RIVER;
    }
    else{
        throw runtime_error(tfm::format("game round not found: %s",round));
    }
    return game_round;
}
```