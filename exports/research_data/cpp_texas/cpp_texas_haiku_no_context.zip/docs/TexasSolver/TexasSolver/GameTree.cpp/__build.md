`__build`: The function of `__build` is to recursively build and update the nodes of a game tree based on the given rule, last action, and other parameters.

**Code Description**:

The `__build` function is a part of the `GameTree` class and is responsible for building and updating the nodes of a game tree. It takes the following parameters:

1. `shared_ptr<GameTreeNode> node`: A shared pointer to the current game tree node being processed.
2. `Rule rule`: The current game rule.
3. `string last_action`: The last action performed in the game.
4. `int check_times`: The number of times the "check" action has been performed.
5. `int raise_times`: The number of times the "raise" action has been performed.

The function uses a `switch` statement to handle different types of game tree nodes:

1. `GameTreeNode::ACTION`: In this case, the function calls the `buildAction` method, passing the current node (cast to `ActionNode`), the rule, the last action, the check times, and the raise times.
2. `GameTreeNode::SHOWDOWN`: This case is empty, indicating that no further processing is required for a showdown node.
3. `GameTreeNode::TERMINAL`: This case is also empty, indicating that no further processing is required for a terminal node.
4. `GameTreeNode::CHANCE`: In this case, the function calls the `buildChance` method, passing the current node (cast to `ChanceNode`) and the rule.

If the node type is not one of the above, the function throws a `runtime_error` with the message "node type unknown".

Finally, the function returns the updated `node` pointer.

The purpose of this function is to recursively build and update the game tree by processing different types of nodes. It is likely part of a larger game engine or simulation system, where the game tree represents the possible states and actions in a game.\\
## Code: 
```
shared_ptr<GameTreeNode> GameTree::__build(shared_ptr<GameTreeNode> node, Rule rule, string last_action,
                                           int check_times, int raise_times) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            this->buildAction(std::dynamic_pointer_cast<ActionNode>(node),rule,last_action,check_times,raise_times);
            break;
        }case GameTreeNode::SHOWDOWN: {
            break;
        }case GameTreeNode::TERMINAL: {
            break;
        }case GameTreeNode::CHANCE: {
            this->buildChance(std::dynamic_pointer_cast<ChanceNode>(node),rule);
            break;
        }default:
            throw runtime_error("node type unknown");
    }
    return node;
}
```