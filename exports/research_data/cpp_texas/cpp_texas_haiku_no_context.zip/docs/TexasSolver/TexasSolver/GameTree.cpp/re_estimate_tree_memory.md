`re_estimate_tree_memory`: The function of `re_estimate_tree_memory` is to recursively estimate the memory usage of a game tree data structure.

**Code Description**: The `re_estimate_tree_memory` function takes a shared pointer to a `GameTreeNode` object, along with several integer parameters representing the number of decks, player ranges, and the current deal. The function then recursively calculates the estimated memory usage of the game tree based on the type of the node.

If the node is an `ACTION` node, the function iterates through the child nodes and adds up their estimated memory usage. It then adds an additional amount of memory based on the player's range and the number of child nodes.

If the node is a `CHANCE` node, the function recursively calls itself on the child node, but with the number of current deals multiplied by the number of decks.

The function returns the total estimated memory usage of the game tree.\\
## Code: 
```
long long GameTree::re_estimate_tree_memory(const shared_ptr<GameTreeNode>& node,int deck_num,int p1range_num,int p2range_num,int num_current_deal){
    if(node->getType() == GameTreeNode::ACTION){
        shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
        vector<shared_ptr<GameTreeNode>> childrens = action_node->getChildrens();
        vector<GameActions> actions = action_node->getActions();

        long long retnum = 0;
        for(std::size_t i = 0;i < childrens.size();i++){
            shared_ptr<GameTreeNode> one_child = childrens[i];
            retnum += re_estimate_tree_memory(one_child,deck_num, p1range_num, p2range_num, num_current_deal);
        }
        if(action_node->getPlayer() == 0){
            retnum += num_current_deal * p1range_num * (childrens.size() + 1) * 3;
        }else{
            retnum += num_current_deal * p2range_num * (childrens.size() + 1) * 3;
        }
        return retnum;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
        shared_ptr<GameTreeNode> children = chance_node->getChildren();
        return re_estimate_tree_memory(children,deck_num, p1range_num, p2range_num, num_current_deal * (deck_num));
    }
    return 0;
}
```