`buildChance`: The function of `buildChance` is to build a game tree node representing a chance event in a poker game.

**Code Description**: The `buildChance` function takes two parameters: a shared pointer to a `ChanceNode` object (`root`) and a `Rule` object (`rule`). The function is responsible for creating a new game tree node based on the current state of the game, as defined by the `Rule` object.

The function first checks the current round of the game. If the current round is greater than 3 (which should be the river round), it throws a `runtime_error` exception. This suggests that the function is designed to handle only the first three rounds of the game (preflop, flop, and turn).

Next, the function creates a new `GameTreeNode` object (`one_node`) based on the current state of the game. If the player's committed amounts (`oop_commit` and `ip_commit`) are equal and both equal to the player's stack sizes, the function checks the current round:

1. If the current round is 3 (river), the function creates a `ShowdownNode` object, which represents the final showdown of the game. It calculates the amount each player will get back if they split the pot and sets the payoffs accordingly.
2. If the current round is less than 3, the function creates a new `ChanceNode` object, which represents a chance event (e.g., dealing the next card). It increments the current round and sets the new `ChanceNode` as the child of the `root` node.

If the player's committed amounts are not equal, the function creates an `ActionNode` object, which represents a player action (e.g., bet, call, fold).

Finally, the function calls the `__build` method (which is not shown in the provided code) with the newly created `one_node` object, the updated `Rule` object, the string `"begin"`, and two zeros as arguments. It then sets the `one_node` object as the child of the `root` node.

The overall purpose of the `buildChance` function is to construct a game tree node that represents the current state of the poker game, taking into account the players' committed amounts, the current round, and the potential for a showdown\\
## Code: 
```
void GameTree::buildChance(shared_ptr<ChanceNode> root,Rule rule){
    //节点上的下注额度
    double pot = (double)rule.get_pot();
    Rule nextrule = Rule(rule);
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));

    shared_ptr<GameTreeNode> one_node;
    if(rule.oop_commit == rule.ip_commit && rule.oop_commit == rule.stack) {
        if(rule.current_round >= 3){ // 3 is river
            double p1_commit = rule.ip_commit;
            double p2_commit = rule.oop_commit;
            double peace_getback = (p1_commit + p2_commit) / 2;


            vector<vector<double>> payoffs(2);
            payoffs[0] = {p2_commit, -p2_commit};
            payoffs[1] = {-p1_commit, p1_commit};
            vector<double> peace_getback_vec = {peace_getback - p1_commit, peace_getback - p2_commit};
            one_node = make_shared<ShowdownNode>(peace_getback_vec, payoffs, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
        }else {
            nextrule.current_round += 1;
            if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
            one_node = make_shared<ChanceNode>(nullptr, GameTreeNode::intToGameRound(rule.current_round + 1), (double) rule.get_pot(), root, this->deck.getCards());
        }
    }else {
        one_node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(), 1, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
    }
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
    this->__build(one_node,nextrule,"begin",0,0);
    root->setChildren(one_node);
}
```