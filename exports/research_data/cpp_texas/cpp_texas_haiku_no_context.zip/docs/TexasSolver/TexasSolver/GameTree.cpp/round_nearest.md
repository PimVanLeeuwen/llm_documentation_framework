`round_nearest`: The function of `round_nearest` is to round a given number to the nearest multiple of a specified rounding number.

**Code Description**: The `round_nearest` function takes two parameters: `number` (the number to be rounded) and `round_num` (the rounding number). The function first calculates the reciprocal of the `round_num` by setting `round_num = 1 / round_num`. This is done to simplify the rounding calculation.

Next, the function uses the `round()` function to round the product of `number` and `round_num` to the nearest integer. The result is then divided by `round_num` to obtain the final rounded value.

For example, if `number` is 3.14 and `round_num` is 0.5, the function will first calculate `round_num = 1 / 0.5 = 2`. Then, it will round `3.14 * 2 = 6.28` to the nearest integer, which is 6. Finally, it will divide 6 by 2 to get the final result of 3, which is the nearest multiple of 0.5 to 3.14.\\
## Code: 
```
double GameTree::round_nearest(double number, double round_num) {
    round_num = 1 / round_num;
    return round((number * round_num)) / round_num;

}
```