`recurrentPrintTree`: The function of `recurrentPrintTree` is to recursively print the game tree represented by the given `GameTreeNode` object, with each node's information displayed in a formatted manner.

**Code Description**:

The `recurrentPrintTree` function takes three parameters:
1. `const shared_ptr<GameTreeNode>& node`: A shared pointer to the current `GameTreeNode` being processed.
2. `int depth`: The current depth of the game tree being printed.
3. `int depth_limit`: The maximum depth to which the tree should be printed (or -1 to print the entire tree).

The function first checks if the `depth_limit` is set and if the current `depth` has reached or exceeded that limit. If so, it returns without further processing.

Next, the function checks the type of the current `GameTreeNode`:

1. If the node is an `ACTION` node, it casts the node to an `ActionNode` and retrieves its children nodes and the corresponding actions. It then prints the action for each child node, along with the player's name, and recursively calls `recurrentPrintTree` on each child node with an incremented depth.

2. If the node is a `SHOWDOWN` node, it casts the node to a `ShowdownNode` and prints the pot value. It then prints the payoff information for each player, including the payoff if the showdown results in a tie.

3. If the node is a `TERMINAL` node, it casts the node to a `TerminalNode` and prints the pot value. It then prints the terminal payoff for each player.

4. If the node is a `CHANCE` node, it casts the node to a `ChanceNode` and recursively calls `recurrentPrintTree` on the child node with an incremented depth.

The function uses the `tfm::format` function from the `tinyformat` library to format the output strings, which include indentation based on the current depth and the relevant information for each node type.

Overall, the `recurrentPrintTree` function provides a way to visualize the game tree represented by the `GameTreeNode` objects, which can be useful for debugging and understanding the game's decision-making process.\\
## Code: 
```
void GameTree::recurrentPrintTree(const shared_ptr<GameTreeNode>& node, int depth, int depth_limit) {
    if(depth_limit != -1 && depth >= depth_limit){
        return;
    }

    if(node->getType() == GameTreeNode::ACTION){
        shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
        vector<shared_ptr<GameTreeNode>> childrens = action_node->getChildrens();
        vector<GameActions> actions = action_node->getActions();

        for(std::size_t i = 0;i < childrens.size();i++){
            shared_ptr<GameTreeNode> one_child = childrens[i];
            GameActions one_action = actions[i];

            string prefix;
            for(int j = 0;j < depth;j++) prefix += "\t";
            cout << (tfm::format(
                    "%sp%s: %s",prefix,action_node->getPlayer(),one_action.toString()
            )) << endl;
            recurrentPrintTree(one_child,depth + 1,depth_limit);
        }
    }else if(node->getType() == GameTreeNode::SHOWDOWN){
        shared_ptr<ShowdownNode> showdown_node = std::dynamic_pointer_cast<ShowdownNode>(node);
        string prefix;
        for(int j = 0;j < depth;j++) prefix += "\t";
        cout << (tfm::format(
                "%s SHOWDOWN pot %s ",prefix,showdown_node->getPot()
        )) << endl;

        prefix += "\t";
        for(std::size_t i = 0;i < showdown_node->get_payoffs(ShowdownNode::ShowDownResult::TIE,-1).size();i++) {
            cout << (tfm::format("%sif player %s wins, payoff :", prefix,i));
            vector<double> payoffs = showdown_node->get_payoffs(ShowdownNode::ShowDownResult::NOTTIE, i);

            for (std::size_t player_id = 0; player_id < payoffs.size(); player_id++) {
                cout << (
                        tfm::format(" p%s %s ", player_id, payoffs[player_id])
                );
            }
            cout << endl;
        }
        cout << (tfm::format("%sif Tie, payoff :", prefix));
        vector<double> payoffs = showdown_node->get_payoffs(ShowdownNode::ShowDownResult::TIE, -1);

        for (std::size_t player_id = 0; player_id < payoffs.size(); player_id++) {
            cout << (
                    tfm::format(" p%s %s ", player_id, payoffs[player_id])
            );
        }
        cout << endl;
    }else if(node->getType() == GameTreeNode::TERMINAL){
        shared_ptr<TerminalNode> terminal_node = std::dynamic_pointer_cast<TerminalNode>(node);
        string prefix;
        for(int j = 0;j < depth;j++) prefix += "\t";
        cout << (tfm::format(
                "%s TERMINAL pot %s ",prefix,terminal_node->getPot()
        )) << endl;

        prefix += "\t";
        cout << (tfm::format("%sTerminal payoff :", prefix));
        vector<double> payoffs = terminal_node->get_payoffs();

        for (std::size_t player_id = 0; player_id < payoffs.size(); player_id++) {
            cout <<(
                    tfm::format("p%s %s ", player_id, payoffs[player_id])
            );
        }
        cout << endl;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
        shared_ptr<GameTreeNode> children = chance_node->getChildren();

        string prefix;
        for(int j = 0;j < depth;j++) prefix += "\t";
        cout << (tfm::format(
                "%s%s",prefix,"CHANCE"
        )) << endl;
        recurrentPrintTree(children,depth + 1,depth_limit);
    }
}
```