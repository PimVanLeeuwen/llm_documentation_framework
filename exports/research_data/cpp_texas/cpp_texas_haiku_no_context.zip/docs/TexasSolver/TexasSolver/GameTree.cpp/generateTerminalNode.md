`generateTerminalNode`: The function of `generateTerminalNode` is to create a new `TerminalNode` object with the given input parameters.

**Code Description**:
The `generateTerminalNode` function takes three parameters:
1. `json meta`: This is a JSON object that contains information about the game, including the player payoffs, the pot size, and the player index.
2. `string round`: This is a string that represents the current round of the game.
3. `shared_ptr<GameTreeNode> parent`: This is a shared pointer to the parent `GameTreeNode` object.

The function first extracts the player payoff information from the `meta` object and stores it in a `vector<double>` called `player_payoff`. It then extracts the pot size from the `meta` object and stores it in a `double` variable called `pot`.

Next, the function converts the `round` string to a `GameTreeNode::GameRound` enum value using the `strToGameRound` function. It then extracts the player index from the `meta` object and stores it in an `int` variable called `player`.

Finally, the function creates a new `TerminalNode` object using the `make_shared` function, passing in the `player_payoff`, `player`, `game_round`, `pot`, and `parent` parameters. This `TerminalNode` object is then returned by the function.

The purpose of this function is to create a new `TerminalNode` object that represents the final state of the game, with the player payoffs, pot size, and other relevant information. This `TerminalNode` object can then be used by other parts of the game logic to determine the outcome of the game.\\
## Code: 
```
shared_ptr<TerminalNode> GameTree::generateTerminalNode(json meta, string round, shared_ptr<GameTreeNode> parent) {
    vector<double> player_payoff_list = meta["payoff"];
    vector<double> player_payoff(player_payoff_list.size());
    for(std::size_t one_player = 0;one_player < player_payoff_list.size();one_player ++){

        double tmp_payoff = player_payoff_list[one_player];
        player_payoff[one_player] = tmp_payoff;
    }

    //节点上的下注额度
    double pot = meta["pot"];

    GameTreeNode::GameRound game_round = this->strToGameRound(std::move(round));
    // 多人游戏的时候winner就不等于当前节点的玩家了，这里要注意
    int player = meta["player"];

    return make_shared<TerminalNode>(player_payoff,player,game_round,pot,parent);
}
```