`getSettings`: The function of `getSettings` is to retrieve the appropriate `StreetSetting` based on the provided `int_round` and `player` parameters, and the `gameTreeBuildingSettings` object.

**Code Description**:
The `getSettings` function takes three parameters:
1. `int_round`: an integer representing the game round (e.g., flop, turn, river).
2. `player`: an integer representing the player (0 for in-position, 1 for out-of-position).
3. `gameTreeBuildingSettings`: a reference to a `GameTreeBuildingSettings` object, which likely contains the various `StreetSetting` configurations for the different game rounds and player positions.

The function first converts the `int_round` parameter to a `GameTreeNode::GameRound` enum value using the `intToGameRound` function.

It then checks the following conditions:
1. If the `player` parameter is not 0 or 1, it throws a `runtime_error` with a message indicating the invalid player value.
2. If the `round` is `RIVER` and the `player` is 0, it returns the `river_ip` `StreetSetting` from the `gameTreeBuildingSettings` object.
3. If the `round` is `TURN` and the `player` is 0, it returns the `turn_ip` `StreetSetting` from the `gameTreeBuildingSettings` object.
4. If the `round` is `FLOP` and the `player` is 0, it returns the `flop_ip` `StreetSetting` from the `gameTreeBuildingSettings` object.
5. If the `round` is `RIVER` and the `player` is 1, it returns the `river_oop` `StreetSetting` from the `gameTreeBuildingSettings` object.
6. If the `round` is `TURN` and the `player` is 1, it returns the `turn_oop` `StreetSetting` from the `gameTreeBuildingSettings` object.
7. If the `round` is `FLOP` an\\
## Code: 
```
StreetSetting GameTree::getSettings(int int_round, int player,GameTreeBuildingSettings& gameTreeBuildingSettings){
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(int_round);
    if(!(player == 0 || player == 1)) throw runtime_error(tfm::format("player %s not known",player));
    if(round == GameTreeNode::GameRound::RIVER && player == 0) return gameTreeBuildingSettings.river_ip;
    else if(round == GameTreeNode::GameRound::TURN && player == 0) return gameTreeBuildingSettings.turn_ip;
    else if(round == GameTreeNode::GameRound::FLOP && player == 0) return gameTreeBuildingSettings.flop_ip;
    else if(round == GameTreeNode::GameRound::RIVER && player == 1) return gameTreeBuildingSettings.river_oop;
    else if(round == GameTreeNode::GameRound::TURN && player == 1) return gameTreeBuildingSettings.turn_oop;
    else if(round == GameTreeNode::GameRound::FLOP && player == 1) return gameTreeBuildingSettings.flop_oop;
    else throw new runtime_error(tfm::format("player %s and round not known",player));
}
```