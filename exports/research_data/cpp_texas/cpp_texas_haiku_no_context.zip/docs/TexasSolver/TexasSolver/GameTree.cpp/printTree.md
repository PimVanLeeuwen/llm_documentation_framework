`printTree`: The function of `printTree` is to print the game tree, starting from the root node, up to a specified depth.

**Code Description**:

1. The function first checks if the `depth` parameter is valid. It throws a `runtime_error` exception if `depth` is less than -1 or equal to 0, as the function only accepts -1 or positive values for the depth.

2. The function initializes an empty vector called `prefix` to store the prefix strings for each node in the tree.

3. The function then calls the `recurrentPrintTree` function, passing the root node of the game tree, the initial depth of 0, and the specified `depth` parameter.

4. The `recurrentPrintTree` function is a recursive function that traverses the game tree and prints the nodes at the specified depth. It takes the following parameters:
   - `node`: the current node being processed
   - `currentDepth`: the current depth in the tree
   - `maxDepth`: the maximum depth to print

5. Inside the `recurrentPrintTree` function, the following steps are performed:
   - If the `currentDepth` is equal to the `maxDepth`, the function prints the current node's value using the `prefix` vector.
   - If the `currentDepth` is less than the `maxDepth`, the function recursively calls itself for each child node of the current node, incrementing the `currentDepth` by 1 and updating the `prefix` vector accordingly.

6. The `printTree` function is responsible for initiating the recursive traversal of the game tree and printing the nodes up to the specified depth.

In summary, the `printTree` function allows the user to print the game tree, starting from the root node, up to a specified depth. This can be useful for visualizing and understanding the structure of the game tree during the development or debugging process.\\
## Code: 
```
void GameTree::printTree(int depth) {
    if(depth < -1 || depth == 0){
        throw runtime_error("depth can only be -1 or positive");
    }
    vector<string> prefix;
    this->recurrentPrintTree(this->root,0,depth);
}
```