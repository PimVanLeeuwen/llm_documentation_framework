`generateShowdownNode`: The function of `generateShowdownNode` is to create a new `ShowdownNode` object based on the provided JSON metadata, round information, and parent node.

**Code Description**:
1. The function takes in three parameters: `meta` (a JSON object containing metadata about the game state), `round` (a string representing the current game round), and `parent` (a shared pointer to the parent `GameTreeNode` object).
2. It extracts the "payoffs" information from the `meta` object, which contains the payoff distributions for each player and the tie scenario.
3. It initializes two vectors: `tie_payoffs` to store the payoff distribution for a tie, and `player_payoffs` to store the payoff distributions for each player.
4. It iterates through the "payoffs" object, skipping the "tie" key, and extracts the payoff distribution for each player. It converts the player ID (which is a string) to an integer and stores the payoff distribution in the `player_payoffs` vector.
5. It converts the `round` string to a `GameRound` enum value using the `strToGameRound` function.
6. Finally, it creates a new `ShowdownNode` object using the extracted information and the `parent` node, and returns a shared pointer to the new node.

The purpose of this function is to create a new `ShowdownNode` object that represents the game state at a specific showdown (i.e., the final round of the game where the winner is determined). The `ShowdownNode` object contains information about the payoff distributions for each player and the tie scenario, as well as the current game round. This information is used by the game engine to determine the outcome of the game and update the game state accordingly.\\
## Code: 
```
shared_ptr<ShowdownNode> GameTree::generateShowdownNode(json meta, string round, shared_ptr<GameTreeNode> parent) {
    json meta_payoffs = meta["payoffs"];
    vector<double> tie_payoffs = meta_payoffs["tie"];

    // meta_payoffs 的key有 n个玩家+1个平局,代表某个玩家赢了的时候如何分配payoff
    vector<vector<double>> player_payoffs(2);
    double pot = meta["pot"];

    for(auto one_player_meta=meta_payoffs.begin(); one_player_meta!=meta_payoffs.end(); one_player_meta++){
        const string& one_player = one_player_meta.key();
        if(one_player == "tie"){
            continue;
        }
        // 获胜玩家id
        int player_id = atoi(one_player.c_str());
        if(player_id < 0 or player_id > 1) throw runtime_error("player id json convert fail");

        // 玩家在当前Showdown节点能获得的收益
        //List<Object> tmp_payoffs =  (List<Object>)meta_payoffs.get(one_player);
        vector<double> player_payoff = one_player_meta.value();

        player_payoffs[atoi(one_player.c_str())] = player_payoff;
    }
    GameTreeNode::GameRound game_round = strToGameRound(std::move(round));
    return make_shared<ShowdownNode>(tie_payoffs,player_payoffs,game_round,pot,parent);
}
```