`estimate_tree_memory`: The function of `estimate_tree_memory` is to estimate the memory required for the game tree.

**Code Description**: The `estimate_tree_memory` function is a member function of the `GameTree` class. It takes four parameters: `deck_num`, `p1range_num`, `p2range_num`, and `num_current_deal`. The function calls another member function, `re_estimate_tree_memory`, passing the `root` of the game tree and the four parameters. The `re_estimate_tree_memory` function is responsible for the actual estimation of the memory required for the game tree.\\
## Code: 
```
long long GameTree::estimate_tree_memory(int deck_num,int p1range_num,int p2range_num,int num_current_deal){
    return this->re_estimate_tree_memory(this->root,deck_num, p1range_num, p2range_num, num_current_deal);
}
```