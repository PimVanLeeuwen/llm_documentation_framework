`GameTree`: The function of `GameTree` is to create a game tree data structure that represents the possible game states and actions in a poker game.

**Code Description**:
The `GameTree` class is responsible for constructing the game tree, which is a hierarchical representation of the possible game states and actions that can occur during a poker game. The constructor of the `GameTree` class takes several parameters that define the initial game state, including the deck of cards, the commitment levels of the players, the current round of the game, the raise limit, the small and big blinds, the stack sizes, the game tree building settings, and the all-in threshold.

The constructor creates a `Rule` object, which encapsulates the game rules and settings, and then creates the root node of the game tree as an `ActionNode`. The `__build` method is then called to recursively build the rest of the game tree, starting from the root node.

The key steps in the `GameTree` constructor are:

1. Create a `Rule` object that encapsulates the game rules and settings.
2. Create the root node of the game tree as an `ActionNode`, which represents the initial game state.
3. Call the `__build` method to recursively build the rest of the game tree, starting from the root node.

The `__build` method is responsible for recursively building the game tree by generating all possible actions and their corresponding game states. This process continues until the game tree is fully constructed or a certain depth or termination condition is reached.

The `GameTree` class provides a way to represent the entire game state and the possible actions that can be taken at each stage of the game. This information can be used by AI agents or other decision-making algorithms to analyze the game and make informed decisions.\\
## Code: 
```
GameTree::GameTree(Deck deck,
                   float oop_commit,
                   float ip_commit,
                   int current_round,
                   int raise_limit,
                   float small_blind,
                   float big_blind,
                   float stack,
                   GameTreeBuildingSettings buildingSettings,
                   float allin_threshold
){
    Rule rule = Rule(deck,oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,buildingSettings,allin_threshold);
    int current_player = 1;
    this->deck = deck;
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(rule.current_round);
    shared_ptr<ActionNode> node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(),current_player, round, (double) rule.get_pot(),
                                 nullptr);
    this->__build(node,rule);
    this->root = node;
}
```