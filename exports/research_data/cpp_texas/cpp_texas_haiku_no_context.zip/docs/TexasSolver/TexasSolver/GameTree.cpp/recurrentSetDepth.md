`recurrentSetDepth`: The function of `recurrentSetDepth` is to recursively set the depth and subtree size of each node in a game tree.

**Code Description**:
The `recurrentSetDepth` function is a recursive function that takes a `shared_ptr<GameTreeNode>` and an integer `depth` as input parameters. It performs the following tasks:

1. Sets the `depth` of the input `node` to the provided `depth` value.
2. Checks the type of the `node`:
   - If the node is an `ACTION` node, it casts the `node` to a `shared_ptr<ActionNode>` and iterates through its children. For each child, it recursively calls `recurrentSetDepth` with the child node and the current `depth + 1`. It then calculates the total subtree size by adding 1 (for the current node) and the subtree sizes of all the children.
   - If the node is a `CHANCE` node, it casts the `node` to a `shared_ptr<ChanceNode>` and recursively calls `recurrentSetDepth` with the children of the `ChanceNode` and the current `depth + 1`. It then calculates the total subtree size by adding 1 (for the current node) and the subtree sizes of all the children multiplied by the number of cards in the `ChanceNode`.
   - If the node is neither an `ACTION` nor a `CHANCE` node, it sets the subtree size of the `node` to 1.
3. Finally, the function returns the subtree size of the input `node`.

The purpose of this function is to recursively traverse the game tree, setting the depth and subtree size of each node. This information is likely used in other parts of the game tree implementation to facilitate game-related calculations or decision-making processes.\\
## Code: 
```
int GameTree::recurrentSetDepth(shared_ptr<GameTreeNode> node, int depth) {
    node->depth = depth;
    if(node->getType() == GameTreeNode::ACTION) {
        shared_ptr<ActionNode> actionNode = std::dynamic_pointer_cast<ActionNode>(node);
        int subtree_size = 1;
        for(shared_ptr<GameTreeNode> one_child:actionNode->getChildrens()){
            subtree_size += this->recurrentSetDepth(one_child,depth + 1);
        }
        node->subtree_size = subtree_size;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chanceNode = std::dynamic_pointer_cast<ChanceNode>(node);
        int subtree_size = 1;
        subtree_size += this->recurrentSetDepth(chanceNode->getChildren(),depth + 1) * chanceNode->getCards().size();
        node->subtree_size = subtree_size;
    }else{
        node->subtree_size = 1;
    }
    return node->subtree_size;
}
```