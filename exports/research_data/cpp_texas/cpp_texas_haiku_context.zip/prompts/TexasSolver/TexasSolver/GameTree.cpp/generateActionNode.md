# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/GameTree.cpp` \
**Type:** `Method` \
**Method Name:** `generateActionNode` \
**Code Content:** \
`shared_ptr<ActionNode>
GameTree::generateActionNode(json meta, vector<string> childrens_actions, vector<json> childrens_nodes, const string& round,
                             shared_ptr<GameTreeNode> parent) {
    if(childrens_actions.size() != childrens_nodes.size()){
        throw runtime_error(
                tfm::format(
                        "mismatch when generate ActionNode, childrens_action length %s children_nodes length %s",
                        childrens_actions.size(),
                        childrens_nodes.size()
                ));
    }

    if(! (   round == "preflop"
          || round == "flop"
          || round == "turn"
          || round == "river"
          )
            ){
        throw runtime_error(tfm::format("round %s not found",round));
    }

    vector<GameActions> actions;
    vector<shared_ptr<GameTreeNode>> childrens;

    // 遍历所有children actions 来生成GameAction 的list，用于初始化ActionNode
    for(std::size_t i = 0;i < childrens_actions.size();i++){
        string one_action = childrens_actions[i];
        json one_children_map = childrens_nodes[i];
        if(one_action.empty()) throw runtime_error("action is null");

        GameTreeNode::PokerActions action;
        double amount = -1;
        if(one_action == "check"){
            action = GameTreeNode::PokerActions::CHECK;
        }
        else if(one_action == "fold"){
            action = GameTreeNode::PokerActions::FOLD;
        }
        else if(one_action == "call"){
            action = GameTreeNode::PokerActions::CALL;
        }
        else{
            if(one_action.find("bet")  != string::npos){
                vector<string> action_sp = string_split(one_action,'_');
                if(action_sp.size() != 2)
                    throw runtime_error(tfm::format("bet action sp length %s",action_sp.size()));
                string action_str = action_sp[0];
                action = GameTreeNode::PokerActions::BET;
                if(!(action_str == "bet")) throw runtime_error(tfm::format("Action %s not found",action_str));
                amount = stod(action_sp[1]);

            }else if (one_action.find("raise") != string::npos){
                vector<string> action_sp = string_split(one_action,'_');
                if(action_sp.size() != 2)
                    throw runtime_error(tfm::format("raise action sp length %s",action_sp.size()));
                string action_str = action_sp[0];
                action = GameTreeNode::PokerActions::RAISE;
                if(!(action_str == "raise"))
                    throw runtime_error(tfm::format("Action %s not found",action_str));
                amount = stod(action_sp[1]);
            }else{
                throw runtime_error(tfm::format("%s action not found",one_action));
            }
        }
        shared_ptr<GameTreeNode> one_children_node = recurrentGenerateTreeNode(one_children_map,parent);
        childrens.push_back(one_children_node);

        GameActions game_action = GameActions(action,amount);
        actions.push_back(game_action);
    }
    int player = meta["player"];
    double pot = meta["pot"];
    if(childrens.size() != actions.size()){
        throw runtime_error(tfm::format("childrens length %s, actions length %s"
                ,childrens.size()
                ,actions.size()));
    }
    GameTreeNode::GameRound game_round = strToGameRound(round);
    shared_ptr<ActionNode> actionNode = make_shared<ActionNode>(actions,childrens,player,game_round,pot,parent);
    for(const shared_ptr<GameTreeNode>& one_node: childrens){
        one_node->setParent(std::dynamic_pointer_cast<GameTreeNode>(actionNode));
    }
    return actionNode;

}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/Card.cpp.empty 
 - Explanation:  _The `empty()` method checks if the `card` member variable of the `Card` class is equal to the string `"empty"`. If it is, the method returns `true`, otherwise it returns `false`._ 
### TexasSolver/TexasSolver/GameTree.cpp.recurrentGenerateTreeNode 
 - Explanation:  _This code is a method called `recurrentGenerateTreeNode` that is part of the `GameTree` class. It is responsible for generating different types of game tree nodes (Action, Showdown, Terminal, and Chance) based on the input JSON data._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.GameTreeNode 
 - Explanation:  _The provided code is a constructor for the `GameTreeNode` class. It initializes the `round`, `pot`, and `parent` member variables of the class._ 
### TexasSolver/TexasSolver/src/GameActions.cpp.GameActions 
 - Explanation:  _The provided code is a constructor for a `GameActions` class. It initializes the `action` and `amount` member variables based on the input parameters._ 
### TexasSolver/TexasSolver/library.cpp.string_split 
 - Explanation:  _The provided code defines a function `string_split` that takes a string and a character as input, and returns a vector of strings. The function splits the input string into substrings using the provided character as the delimiter._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.setParent 
 - Explanation:  _The `setParent` method sets the parent of the current `GameTreeNode` object to the provided `parent` parameter, which is a shared pointer to another `GameTreeNode` object._ 
### TexasSolver/TexasSolver/GameTree.cpp.strToGameRound 
 - Explanation:  _This code defines a function `strToGameRound` that takes a string `round` and returns the corresponding `GameTreeNode::GameRound` enum value. If the input string does not match any of the expected values, it throws a runtime error._ 
### TexasSolver/TexasSolver/src/ActionNode.cpp.ActionNode 
 - Explanation:  _The provided code is a constructor for the `ActionNode` class, which is a subclass of `GameTreeNode`. The constructor initializes the `actions`, `player`, `childrens`, `round`, and `pot` member variables of the `ActionNode` object._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`generateActionNode`: The function of `generateActionNode` is *FILL IN* 
**Parameters**:\
`json meta`: *FILL IN* \
`vector<string> childrens_actions`: *FILL IN* \
`vector<json> childrens_nodes`: *FILL IN* \
`const string& round`: *FILL IN* \
`shared_ptr<GameTreeNode> parent`: *FILL IN* \

**Code Description**: *FILL IN*
