# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/GameTree.cpp` \
**Type:** `Method` \
**Method Name:** `recurrentGenerateTreeNode` \
**Code Content:** \
`shared_ptr<GameTreeNode> GameTree::recurrentGenerateTreeNode(json node_json, const shared_ptr<GameTreeNode>& parent) {
    json meta = node_json["meta"];
    string round = meta["round"];
    if(round.empty()){
        throw runtime_error("node json get round null pointer");
    }

    if(! (round == "preflop"
          || round == "flop"
          || round == "turn"
          || round == "river"
          )
            ){
        throw runtime_error(tfm::format("round %s not found",round));
    }

    string node_type = meta["node_type"];
    if(node_type.empty()){
        throw runtime_error("node json get round null pointer");
    }
    if (! (   node_type == "Terminal"
           || node_type == "Showdown"
           || node_type ==  "Action"
           || node_type ==  "Chance"
    )
            ){
        throw runtime_error(tfm::format("node type %s not found",node_type));
    }

    if(node_type == "Action") {
        // 孩子节点的动作，存在list里
        auto childrens_actions = node_json["children_actions"].get<std::vector<string>>();
        // 孩子节点本身，同样存在list里,和上面的children_actions 一一对应,事实上两者的长度一致
        vector<json> childrens = node_json["children"].get<std::vector<json>>();
        if (childrens.size() != childrens_actions.size()) {
            throw runtime_error("action node child length mismatch");
        }
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateActionNode(meta, childrens_actions, childrens, round,parent));
    }
    else if(node_type == "Showdown") {
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateShowdownNode(meta, round,parent));
    }
    else if(node_type == "Terminal") {
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateTerminalNode(meta, round,parent));
    }
    else if(node_type == "Chance") {
        auto childrens = node_json["children"].get<std::vector<json>>();
        if(childrens.size() != 1) throw runtime_error("Chance node should have only one child");
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateChanceNode(meta, childrens[0], round,parent));
    }
    else{
        throw runtime_error(tfm::format("node type %s not found",node_type));
    }
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/Card.cpp.empty 
 - Explanation:  _The `empty()` method checks if the `card` member variable of the `Card` class is equal to the string `"empty"`. If it is, the method returns `true`, otherwise it returns `false`._ 
### TexasSolver/TexasSolver/GameTree.cpp.generateActionNode 
### TexasSolver/TexasSolver/GameTree.cpp.generateChanceNode 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.GameTreeNode 
 - Explanation:  _The provided code is a constructor for the `GameTreeNode` class. It initializes the `round`, `pot`, and `parent` member variables of the class._ 
### TexasSolver/TexasSolver/GameTree.cpp.generateTerminalNode 
 - Explanation:  _This code defines a method `generateTerminalNode` that creates a `TerminalNode` object with the given metadata, including player payoffs, the winning player, the game round, and the pot size. The method uses other functions within the `TexasSolver` project to convert the input data into the appropriate format for the `TerminalNode` constructor._ 
### TexasSolver/TexasSolver/GameTree.cpp.generateShowdownNode 
 - Explanation:  _This code defines a method `generateShowdownNode` in the `GameTree` class. The method creates a new `ShowdownNode` object based on the provided JSON metadata, including the payoff information for each player and the pot size._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`recurrentGenerateTreeNode`: The function of `recurrentGenerateTreeNode` is *FILL IN* 
**Parameters**:\
`json node_json`: *FILL IN* \
`const shared_ptr<GameTreeNode>& parent`: *FILL IN* \

**Code Description**: *FILL IN*
