# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/GameTree.cpp` \
**Type:** `Method` \
**Method Name:** `recurrentPrintTree` \
**Code Content:** \
`void GameTree::recurrentPrintTree(const shared_ptr<GameTreeNode>& node, int depth, int depth_limit) {
    if(depth_limit != -1 && depth >= depth_limit){
        return;
    }

    if(node->getType() == GameTreeNode::ACTION){
        shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
        vector<shared_ptr<GameTreeNode>> childrens = action_node->getChildrens();
        vector<GameActions> actions = action_node->getActions();

        for(std::size_t i = 0;i < childrens.size();i++){
            shared_ptr<GameTreeNode> one_child = childrens[i];
            GameActions one_action = actions[i];

            string prefix;
            for(int j = 0;j < depth;j++) prefix += "\t";
            cout << (tfm::format(
                    "%sp%s: %s",prefix,action_node->getPlayer(),one_action.toString()
            )) << endl;
            recurrentPrintTree(one_child,depth + 1,depth_limit);
        }
    }else if(node->getType() == GameTreeNode::SHOWDOWN){
        shared_ptr<ShowdownNode> showdown_node = std::dynamic_pointer_cast<ShowdownNode>(node);
        string prefix;
        for(int j = 0;j < depth;j++) prefix += "\t";
        cout << (tfm::format(
                "%s SHOWDOWN pot %s ",prefix,showdown_node->getPot()
        )) << endl;

        prefix += "\t";
        for(std::size_t i = 0;i < showdown_node->get_payoffs(ShowdownNode::ShowDownResult::TIE,-1).size();i++) {
            cout << (tfm::format("%sif player %s wins, payoff :", prefix,i));
            vector<double> payoffs = showdown_node->get_payoffs(ShowdownNode::ShowDownResult::NOTTIE, i);

            for (std::size_t player_id = 0; player_id < payoffs.size(); player_id++) {
                cout << (
                        tfm::format(" p%s %s ", player_id, payoffs[player_id])
                );
            }
            cout << endl;
        }
        cout << (tfm::format("%sif Tie, payoff :", prefix));
        vector<double> payoffs = showdown_node->get_payoffs(ShowdownNode::ShowDownResult::TIE, -1);

        for (std::size_t player_id = 0; player_id < payoffs.size(); player_id++) {
            cout << (
                    tfm::format(" p%s %s ", player_id, payoffs[player_id])
            );
        }
        cout << endl;
    }else if(node->getType() == GameTreeNode::TERMINAL){
        shared_ptr<TerminalNode> terminal_node = std::dynamic_pointer_cast<TerminalNode>(node);
        string prefix;
        for(int j = 0;j < depth;j++) prefix += "\t";
        cout << (tfm::format(
                "%s TERMINAL pot %s ",prefix,terminal_node->getPot()
        )) << endl;

        prefix += "\t";
        cout << (tfm::format("%sTerminal payoff :", prefix));
        vector<double> payoffs = terminal_node->get_payoffs();

        for (std::size_t player_id = 0; player_id < payoffs.size(); player_id++) {
            cout <<(
                    tfm::format("p%s %s ", player_id, payoffs[player_id])
            );
        }
        cout << endl;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
        shared_ptr<GameTreeNode> children = chance_node->getChildren();

        string prefix;
        for(int j = 0;j < depth;j++) prefix += "\t";
        cout << (tfm::format(
                "%s%s",prefix,"CHANCE"
        )) << endl;
        recurrentPrintTree(children,depth + 1,depth_limit);
    }
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.getChildren 
 - Explanation:  _This code returns the `children` member of the `ChanceNode` class, which is a `shared_ptr` to a `GameTreeNode`. The purpose of this method is to provide access to the children of the current `ChanceNode` instance._ 
### TexasSolver/TexasSolver/src/ShowdownNode.cpp.ShowdownNode 
 - Explanation:  _The provided code is a constructor for the `ShowdownNode` class, which is a subclass of `GameTreeNode`. The constructor initializes the `tie_payoffs`, `player_payoffs`, `round`, and `pot` member variables of the `ShowdownNode` object._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.getPot 
 - Explanation:  _The `getPot()` method returns the value of the `pot` member variable of the `GameTreeNode` class. This method provides a way to access the current pot value associated with the game tree node._ 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.ChanceNode 
 - Explanation:  _The provided code is a constructor for the `ChanceNode` class, which is a subclass of `GameTreeNode`. The constructor initializes the `ChanceNode` object with the given parameters, including a shared pointer to the children nodes, the current game round, the pot size, a shared pointer to the parent node, the player's cards, and a boolean flag indicating whether the action is a "donk" play._ 
### TexasSolver/TexasSolver/src/ActionNode.cpp.getActions 
 - Explanation:  _This code returns a reference to the `actions` vector stored within the `ActionNode` object. The `getActions()` method provides access to the list of `GameActions` associated with the `ActionNode`._ 
### TexasSolver/TexasSolver/src/ActionNode.cpp.getChildrens 
 - Explanation:  _This code returns a reference to the `childrens` vector of `shared_ptr<GameTreeNode>` objects associated with the `ActionNode` instance. The `getChildrens` method provides access to the child nodes of the current `ActionNode`._ 
### TexasSolver/TexasSolver/src/TerminalNode.cpp.TerminalNode 
 - Explanation:  _The provided code is a constructor for the `TerminalNode` class, which is a subclass of `GameTreeNode`. The constructor initializes the `payoffs`, `winner`, `round`, and `pot` member variables of the `TerminalNode` object._ 
### TexasSolver/TexasSolver/src/ActionNode.cpp.ActionNode 
 - Explanation:  _The provided code is a constructor for the `ActionNode` class, which is a subclass of `GameTreeNode`. The constructor initializes the `actions`, `player`, `childrens`, `round`, and `pot` member variables of the `ActionNode` object._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`recurrentPrintTree`: The function of `recurrentPrintTree` is *FILL IN* 
**Parameters**:\
`const shared_ptr<GameTreeNode>& node`: *FILL IN* \
`int depth`: *FILL IN* \
`int depth_limit`: *FILL IN* \

**Code Description**: *FILL IN*
