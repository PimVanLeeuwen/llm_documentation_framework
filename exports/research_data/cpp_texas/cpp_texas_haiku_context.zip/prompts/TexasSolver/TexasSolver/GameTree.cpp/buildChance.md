# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/GameTree.cpp` \
**Type:** `Method` \
**Method Name:** `buildChance` \
**Code Content:** \
`void GameTree::buildChance(shared_ptr<ChanceNode> root,Rule rule){
    //节点上的下注额度
    double pot = (double)rule.get_pot();
    Rule nextrule = Rule(rule);
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));

    shared_ptr<GameTreeNode> one_node;
    if(rule.oop_commit == rule.ip_commit && rule.oop_commit == rule.stack) {
        if(rule.current_round >= 3){ // 3 is river
            double p1_commit = rule.ip_commit;
            double p2_commit = rule.oop_commit;
            double peace_getback = (p1_commit + p2_commit) / 2;


            vector<vector<double>> payoffs(2);
            payoffs[0] = {p2_commit, -p2_commit};
            payoffs[1] = {-p1_commit, p1_commit};
            vector<double> peace_getback_vec = {peace_getback - p1_commit, peace_getback - p2_commit};
            one_node = make_shared<ShowdownNode>(peace_getback_vec, payoffs, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
        }else {
            nextrule.current_round += 1;
            if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
            one_node = make_shared<ChanceNode>(nullptr, GameTreeNode::intToGameRound(rule.current_round + 1), (double) rule.get_pot(), root, this->deck.getCards());
        }
    }else {
        one_node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(), 1, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
    }
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
    this->__build(one_node,nextrule,"begin",0,0);
    root->setChildren(one_node);
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/Rule.cpp.Rule 
 - Explanation:  _This code defines a constructor for the `Rule` class, which takes in various parameters related to a poker game, such as the deck, player commitments, current round, raise limit, blinds, stack size, and game tree building settings. The constructor ensures that the out-of-position and in-position player commitments are equal._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.intToGameRound 
 - Explanation:  _This code defines a method `intToGameRound` that takes an integer `round` as input and returns the corresponding `GameRound` enum value. It uses a switch statement to map the integer values 0, 1, 2, and 3 to the `GameRound` enum values `PREFLOP`, `FLOP`, `TURN`, and `RIVER`, respectively, and throws a runtime error for any other input value._ 
### TexasSolver/TexasSolver/src/ShowdownNode.cpp.ShowdownNode 
 - Explanation:  _The provided code is a constructor for the `ShowdownNode` class, which is a subclass of `GameTreeNode`. The constructor initializes the `tie_payoffs`, `player_payoffs`, `round`, and `pot` member variables of the `ShowdownNode` object._ 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.ChanceNode 
 - Explanation:  _The provided code is a constructor for the `ChanceNode` class, which is a subclass of `GameTreeNode`. The constructor initializes the `ChanceNode` object with the given parameters, including a shared pointer to the children nodes, the current game round, the pot size, a shared pointer to the parent node, the player's cards, and a boolean flag indicating whether the action is a "donk" play._ 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.setChildren 
 - Explanation:  _This code sets the `children` member variable of the `ChanceNode` class to the provided `GameTreeNode` object. It is a simple setter method that allows the children of the `ChanceNode` to be updated._ 
### TexasSolver/TexasSolver/GameTree.cpp.__build 
 - Explanation:  _This code is a method named `__build` that is part of the `GameTree` class. It takes a `GameTreeNode` object and updates it based on its type, calling other methods like `buildAction` and `buildChance` to handle different node types._ 
### TexasSolver/TexasSolver/src/Rule.cpp.get_pot 
 - Explanation:  _The `get_pot()` method returns the sum of the `oop_commit` and `ip_commit` properties of the `Rule` object._ 
### TexasSolver/TexasSolver/src/ActionNode.cpp.ActionNode 
 - Explanation:  _The provided code is a constructor for the `ActionNode` class, which is a subclass of `GameTreeNode`. The constructor initializes the `actions`, `player`, `childrens`, `round`, and `pot` member variables of the `ActionNode` object._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`buildChance`: The function of `buildChance` is *FILL IN* 
**Parameters**:\
`shared_ptr<ChanceNode> root`: *FILL IN* \
`Rule rule`: *FILL IN* \

**Code Description**: *FILL IN*
