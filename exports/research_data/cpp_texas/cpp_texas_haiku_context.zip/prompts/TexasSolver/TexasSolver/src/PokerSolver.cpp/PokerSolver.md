# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/PokerSolver.cpp` \
**Type:** `Method` \
**Method Name:** `PokerSolver` \
**Code Content:** \
`PokerSolver::PokerSolver(string ranks, string suits, string compairer_file,int compairer_file_lines, string compairer_file_bin) {
    vector<string> ranks_vector = string_split(ranks,',');
    vector<string> suits_vector = string_split(suits,',');
    this->deck = Deck(ranks_vector,suits_vector);
    this->compairer = make_shared<Dic5Compairer>(compairer_file,compairer_file_lines,compairer_file_bin);
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/library.cpp.string_split 
 - Explanation:  _The provided code defines a function `string_split` that takes a string and a character as input, and returns a vector of strings. The function splits the input string into substrings using the provided character as the delimiter._ 
### TexasSolver/TexasSolver/Deck.cpp.Deck 
 - Explanation:  _This code is a constructor for a `Deck` class. It initializes the `ranks` and `suits` vectors, and then creates a deck of cards by iterating through the ranks and suits, creating a string representation of each card, and storing it in the `cards_str` and `cards` vectors._ 
### TexasSolver/TexasSolver/src/Dic5Compairer.cpp.Dic5Compairer 
 - Explanation:  _This code is a part of the `TexasSolver` project and defines a `Dic5Compairer` class. The class is responsible for loading and processing a dictionary of 5-card poker hands and their corresponding ranks._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`PokerSolver`: The function of `PokerSolver` is *FILL IN* 
**Parameters**:\
`string ranks`: *FILL IN* \
`string suits`: *FILL IN* \
`string compairer_file`: *FILL IN* \
`int compairer_file_lines`: *FILL IN* \
`string compairer_file_bin`: *FILL IN* \

**Code Description**: *FILL IN*
