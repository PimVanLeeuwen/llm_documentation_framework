# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/PCfrSolver.cpp` \
**Type:** `Method` \
**Method Name:** `PCfrSolver` \
**Code Content:** \
`PCfrSolver::PCfrSolver(shared_ptr<GameTree> tree, vector<PrivateCards> range1, vector<PrivateCards> range2,
                     vector<int> initial_board, shared_ptr<Compairer> compairer, Deck deck, int iteration_number, bool debug,
                     int print_interval, string logfile, string trainer, Solver::MonteCarolAlg monteCarolAlg,int warmup,float accuracy,bool use_isomorphism,int use_halffloats,int num_threads) :Solver(tree){
    this->initial_board = initial_board;
    this->initial_board_long = Card::boardInts2long(initial_board);
    this->logfile = logfile;
    this->trainer = trainer;
    this->warmup = warmup;

    range1 = this->noDuplicateRange(range1,initial_board_long);
    range2 = this->noDuplicateRange(range2,initial_board_long);

    this->range1 = range1;
    this->range2 = range2;
    this->player_number = 2;
    this->ranges = vector<vector<PrivateCards>>(this->player_number);
    this->ranges[0] = range1;
    this->ranges[1] = range2;

    this->compairer = compairer;

    this->deck = deck;
    this->use_isomorphism = use_isomorphism;
    this->use_halffloats = use_halffloats;

    this->rrm = RiverRangeManager(compairer);
    this->iteration_number = iteration_number;

    vector<vector<PrivateCards>> private_cards(this->player_number);
    private_cards[0] = range1;
    private_cards[1] = range2;
    pcm = PrivateCardsManager(private_cards,this->player_number,Card::boardInts2long(this->initial_board));
    this->debug = debug;
    this->print_interval = print_interval;
    this->monteCarolAlg = monteCarolAlg;
    this->accuracy = accuracy;
    if(num_threads == -1){
        num_threads = omp_get_num_procs();
    }
    qDebug().noquote() << QString::fromStdString(tfm::format(QObject::tr("Using %s threads").toStdString().c_str(),num_threads));
    this->num_threads = num_threads;
    this->distributing_task = false;
    omp_set_num_threads(this->num_threads);
    setTrainable(this->tree->getRoot());
    this->root_round = this->tree->getRoot()->getRound();
    if(this->root_round == GameTreeNode::GameRound::PREFLOP){
        this->split_round = GameTreeNode::GameRound::FLOP;
    }else if(this->root_round == GameTreeNode::GameRound::FLOP){
        this->split_round = GameTreeNode::GameRound::TURN;
    }else if(this->root_round == GameTreeNode::GameRound::TURN){
        this->split_round = GameTreeNode::GameRound::RIVER;
    }else{
        // do not use multithread in river, really not necessary
        this->split_round = GameTreeNode::GameRound::PREFLOP;
    }
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/PrivateCards.cpp.PrivateCards 
 - Explanation:  _The provided code is a constructor for the `PrivateCards` class. It initializes the class properties, such as the two card IDs, weight, relative probability, and a hash code based on the card IDs._ 
### TexasSolver/TexasSolver/src/PrivateCardsManager.cpp.PrivateCardsManager 
 - Explanation:  _The provided code is the implementation of the `PrivateCardsManager` class constructor. It initializes the private cards data structure and calculates the index of each player's private cards based on their hash codes._ 
### TexasSolver/TexasSolver/Card.cpp.boardInts2long 
 - Explanation:  _This code converts a vector of integer card IDs representing a poker board into a single 64-bit unsigned integer representation. It performs error checking to ensure the input vector is within the valid range of card IDs._ 
### TexasSolver/TexasSolver/src/PCfrSolver.cpp.noDuplicateRange 
 - Explanation:  _This code implements a method `noDuplicateRange` that takes a vector of `PrivateCards` and a 64-bit board representation, and returns a new vector containing only the `PrivateCards` that do not have a duplicate hash code and do not intersect with the given board._ 
### TexasSolver/TexasSolver/GameTree.cpp.getRoot 
 - Explanation:  _The `getRoot()` method returns the root node of the `GameTree` object. It provides access to the root node of the game tree._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.getRound 
 - Explanation:  _This code is a method named `getRound()` that returns the `GameRound` value stored in the `round` member variable of the `GameTreeNode` class._ 
### TexasSolver/TexasSolver/src/RiverRangeManager.cpp.RiverRangeManager 
 - Explanation:  _The code defines a constructor for the `RiverRangeManager` class, which takes a `shared_ptr` to a `Compairer` object and initializes the `handEvaluator` member variable with it. It also creates a `shared_ptr` to a `std::mutex` object and assigns it to the `maplock` member variable._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`PCfrSolver`: The function of `PCfrSolver` is *FILL IN* 
**Parameters**:\
`shared_ptr<GameTree> tree`: *FILL IN* \
`vector<PrivateCards> range1`: *FILL IN* \
`vector<PrivateCards> range2`: *FILL IN* \
`vector<int> initial_board`: *FILL IN* \
`shared_ptr<Compairer> compairer`: *FILL IN* \
`Deck deck`: *FILL IN* \
`int iteration_number`: *FILL IN* \
`bool debug`: *FILL IN* \
`int print_interval`: *FILL IN* \
`string logfile`: *FILL IN* \
`string trainer`: *FILL IN* \
`Solver::MonteCarolAlg monteCarolAlg`: *FILL IN* \
`int warmup`: *FILL IN* \
`float accuracy`: *FILL IN* \
`bool use_isomorphism`: *FILL IN* \
`int use_halffloats`: *FILL IN* \
`int num_threads`: *FILL IN* \

**Code Description**: *FILL IN*
