# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/DiscountedCfrTrainableSF.cpp` \
**Type:** `Method` \
**Method Name:** `DiscountedCfrTrainableSF` \
**Code Content:** \
`DiscountedCfrTrainableSF::DiscountedCfrTrainableSF(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();
    this->evs = vector<EvsStorage>(this->action_number * this->card_number, (EvsStorage) 0.0);
    this->r_plus = vector<RplusStorage>(this->action_number * this->card_number, (RplusStorage) 0.0);
    this->cum_r_plus = vector<CumRplusStorage>(this->action_number * this->card_number, (CumRplusStorage) 0.0);
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/ActionNode.cpp.getChildrens 
 - Explanation:  _This code returns a reference to the `childrens` vector of `shared_ptr<GameTreeNode>` objects associated with the `ActionNode` instance. The `getChildrens` method provides access to the child nodes of the current `ActionNode`._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`DiscountedCfrTrainableSF`: The function of `DiscountedCfrTrainableSF` is *FILL IN* 
**Parameters**:\
`vector<PrivateCards> *privateCards`: *FILL IN* \
`ActionNode &actionNode`: *FILL IN* \

**Code Description**: *FILL IN*
