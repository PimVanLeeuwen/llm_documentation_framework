# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/PokerSolver.cpp` \
**Type:** `Method` \
**Method Name:** `load_game_tree` \
**Code Content:** \
`void PokerSolver::load_game_tree(string game_tree_file) {
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(game_tree_file,this->deck);
    this->game_tree = game_tree;
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/GameTree.cpp.GameTree 
 - Explanation:  _This code defines a constructor for the `GameTree` class, which initializes a `Rule` object and creates an `ActionNode` as the root of the game tree. The `__build` method is then called to build the game tree._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`load_game_tree`: The function of `load_game_tree` is *FILL IN* 
**Parameters**:\
`string game_tree_file`: *FILL IN* \

**Code Description**: *FILL IN*
