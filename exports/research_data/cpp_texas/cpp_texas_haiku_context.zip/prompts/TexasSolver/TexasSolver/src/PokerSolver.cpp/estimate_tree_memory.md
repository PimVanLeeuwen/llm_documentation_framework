# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/PokerSolver.cpp` \
**Type:** `Method` \
**Method Name:** `estimate_tree_memory` \
**Code Content:** \
`long long PokerSolver::estimate_tree_memory(QString range1,QString range2,QString board){
    if(this->game_tree == nullptr){
        qDebug().noquote() << QObject::tr("Please buld tree first.");
        return 0;
    }
    else{
        string player1RangeStr = range1.toStdString();
        string player2RangeStr = range2.toStdString();

        vector<string> board_str_arr = string_split(board.toStdString(),',');
        vector<int> initialBoard;
        for(string one_board_str:board_str_arr){
            initialBoard.push_back(Card::strCard2int(one_board_str));
        }

        vector<PrivateCards> range1 = PrivateRangeConverter::rangeStr2Cards(player1RangeStr,initialBoard);
        vector<PrivateCards> range2 = PrivateRangeConverter::rangeStr2Cards(player2RangeStr,initialBoard);
        return this->game_tree->estimate_tree_memory(this->deck.getCards().size() - initialBoard.size(),range1.size(),range2.size());
    }
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/library.cpp.string_split 
 - Explanation:  _The provided code defines a function `string_split` that takes a string and a character as input, and returns a vector of strings. The function splits the input string into substrings using the provided character as the delimiter._ 
### TexasSolver/TexasSolver/src/PokerSolver.cpp.estimate_tree_memory 
### TexasSolver/TexasSolver/src/PrivateRangeConverter.cpp.rangeStr2Cards 
 - Explanation:  _This code is a method called `rangeStr2Cards` that takes a string representation of a poker hand range and converts it into a vector of `PrivateCards` objects. The method handles various formats of the input range string and performs validation to ensure the resulting cards are unique and do not intersect with a given set of initial board cards._ 
### TexasSolver/TexasSolver/Card.cpp.strCard2int 
 - Explanation:  _This code defines a function `strCard2int` that takes a string representing a playing card and converts it to an integer value. The function extracts the rank and suit characters from the input string, converts them to integer values using helper functions, and then combines them to produce the final integer representation of the card._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`estimate_tree_memory`: The function of `estimate_tree_memory` is *FILL IN* 
**Parameters**:\
`QString range1`: *FILL IN* \
`QString range2`: *FILL IN* \
`QString board`: *FILL IN* \

**Code Description**: *FILL IN*
