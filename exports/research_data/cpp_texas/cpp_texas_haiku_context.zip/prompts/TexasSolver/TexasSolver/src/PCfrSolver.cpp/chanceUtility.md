# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/PCfrSolver.cpp` \
**Type:** `Method` \
**Method Name:** `chanceUtility` \
**Code Content:** \
`vector<float>
PCfrSolver::chanceUtility(int player, shared_ptr<ChanceNode> node, const vector<float> &reach_probs, int iter,
                         uint64_t current_board,int deal) {
    vector<Card>& cards = this->deck.getCards();
    //float[] cardWeights = getCardsWeights(player,reach_probs[1 - player],current_board);

    int card_num = node->getCards().size();
    if(card_num % 4 != 0) throw runtime_error("card num cannot round 4");
    // 可能的发牌情况,2代表每个人的holecard是两张
    int possible_deals = node->getCards().size() - Card::long2board(current_board).size() - 2;
    int oppo = 1 - player;

    //vector<float> chance_utility(reach_probs[player].size());
    vector<float> chance_utility = vector<float>(this->ranges[player].size());
    fill(chance_utility.begin(),chance_utility.end(),0);

    int random_deal = 0;
    if(this->monteCarolAlg==MonteCarolAlg::PUBLIC) {
        if (this->round_deal[GameTreeNode::gameRound2int(node->getRound())] == -1) {
            random_deal = random(1, possible_deals + 1 + 2);
            this->round_deal[GameTreeNode::gameRound2int(node->getRound())] = random_deal;
        } else {
            random_deal = this->round_deal[GameTreeNode::gameRound2int(node->getRound())];
        }
    }
    //vector<vector<vector<float>>> arr_new_reach_probs = vector<vector<vector<float>>>(node->getCards().size());

    vector<vector<float>> results(node->getCards().size());
    //fill(results.begin(),results.end(),nullptr);

    vector<float> multiplier;
    if(iter <= this->warmup){
        multiplier = vector<float>(card_num);
        fill(multiplier.begin(), multiplier.end(), 0);
        for (int card_base = 0; card_base < card_num / 4; card_base++) {
            int cardr = std::rand() % 4;
            int card_target = card_base * 4 + cardr;
            int multiplier_num = 0;
            for (int i = 0; i < 4; i++) {
                int i_card = card_base * 4 + i;
                if (i == cardr) {
                    Card *one_card = const_cast<Card *>(&(node->getCards()[i_card]));
                    uint64_t card_long = Card::boardInt2long(
                            one_card->getCardInt());
                    if (!Card::boardsHasIntercept(card_long, current_board)) {
                        multiplier_num += 1;
                    }
                } else {
                    Card *one_card = const_cast<Card *>(&(node->getCards()[i_card]));
                    uint64_t card_long = Card::boardInt2long(
                            one_card->getCardInt());
                    if (!Card::boardsHasIntercept(card_long, current_board)) {
                        multiplier_num += 1;
                    }
                }
            }
            multiplier[card_target] = multiplier_num;
        }
    }

    vector<int> valid_cards;
    valid_cards.reserve(node->getCards().size());

    for(std::size_t card = 0;card < node->getCards().size();card ++) {
        shared_ptr<GameTreeNode> one_child = node->getChildren();
        Card *one_card = const_cast<Card *>(&(node->getCards()[card]));
        uint64_t card_long = Card::boardInt2long(one_card->getCardInt());//Card::boardCards2long(new Card[]{one_card});
        if (Card::boardsHasIntercept(card_long, current_board)) continue;
        if (iter <= this->warmup && multiplier[card] == 0) continue;
        if (this->color_iso_offset[deal][one_card->getCardInt() % 4] < 0) continue;
        valid_cards.push_back(card);
    }

    #pragma omp parallel for schedule(static)
    for`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.getChildren 
 - Explanation:  _This code returns the `children` member of the `ChanceNode` class, which is a `shared_ptr` to a `GameTreeNode`. The purpose of this method is to provide access to the children of the current `ChanceNode` instance._ 
### TexasSolver/TexasSolver/Card.cpp.long2board 
 - Explanation:  _This code converts a 64-bit integer representation of a poker board into a vector of integers representing the card indices on the board. It checks that the resulting vector has between 1 and 7 elements, and throws an exception if the length is not correct._ 
### TexasSolver/TexasSolver/Card.cpp.boardInt2long 
 - Explanation:  _This code converts an integer representation of a card on a board to a 64-bit unsigned long integer representation. It ensures the input is within the valid range of a standard 52-card deck and returns the corresponding bit-shifted value._ 
### TexasSolver/TexasSolver/library.cpp.random 
 - Explanation:  _The provided code defines a function named `random` that generates a random integer within the specified range `[min, max)`. The function uses the `rand()` function to generate a random number and then applies the appropriate scaling to return a value within the desired range._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.gameRound2int 
 - Explanation:  _This code defines a function `gameRound2int` that takes a `GameRound` enum value and returns an integer representation of the game round. The function maps the `GameRound` enum values to corresponding integer values (0 for PREFLOP, 1 for FLOP, 2 for TURN, and 3 for RIVER), and throws a runtime error if an unknown `GameRound` value is provided._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.getRound 
 - Explanation:  _This code is a method named `getRound()` that returns the `GameRound` value stored in the `round` member variable of the `GameTreeNode` class._ 
### TexasSolver/TexasSolver/Card.cpp.getCardInt 
 - Explanation:  _The `getCardInt()` method returns the integer value of the `card_int` member variable of the `Card` class._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`chanceUtility`: The function of `chanceUtility` is *FILL IN* 
**Parameters**:\
`int player`: *FILL IN* \
`shared_ptr<ChanceNode> node`: *FILL IN* \
`const vector<float> &reach_probs`: *FILL IN* \
`int iter`: *FILL IN* \
`uint64_t current_board`: *FILL IN* \
`int deal`: *FILL IN* \

**Code Description**: *FILL IN*
