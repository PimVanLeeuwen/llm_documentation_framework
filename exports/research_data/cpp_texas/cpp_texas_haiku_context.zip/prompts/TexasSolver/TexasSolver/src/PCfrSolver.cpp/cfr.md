# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/PCfrSolver.cpp` \
**Type:** `Method` \
**Method Name:** `cfr` \
**Code Content:** \
`vector<float> PCfrSolver::cfr(int player, shared_ptr<GameTreeNode> node, const vector<float> &reach_probs, int iter,
                                    uint64_t current_board,int deal) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
            return actionUtility(player, action_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::SHOWDOWN: {
            shared_ptr<ShowdownNode> showdown_node = std::dynamic_pointer_cast<ShowdownNode>(node);
            return showdownUtility(player, showdown_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::TERMINAL: {
            shared_ptr<TerminalNode> terminal_node = std::dynamic_pointer_cast<TerminalNode>(node);
            return terminalUtility(player, terminal_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::CHANCE: {
            shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
            return chanceUtility(player, chance_node, reach_probs, iter, current_board,deal);
        }default:
            throw runtime_error("node type unknown");
    }
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/ShowdownNode.cpp.ShowdownNode 
 - Explanation:  _The provided code is a constructor for the `ShowdownNode` class, which is a subclass of `GameTreeNode`. The constructor initializes the `tie_payoffs`, `player_payoffs`, `round`, and `pot` member variables of the `ShowdownNode` object._ 
### TexasSolver/TexasSolver/src/PCfrSolver.cpp.chanceUtility 
 - Explanation:  _This code is a method named `chanceUtility` that calculates the chance utility for a given player in a Texas Hold'em poker game. It takes into account the current game state, player reach probabilities, and the available cards to determine the optimal strategy._ 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.ChanceNode 
 - Explanation:  _The provided code is a constructor for the `ChanceNode` class, which is a subclass of `GameTreeNode`. The constructor initializes the `ChanceNode` object with the given parameters, including a shared pointer to the children nodes, the current game round, the pot size, a shared pointer to the parent node, the player's cards, and a boolean flag indicating whether the action is a "donk" play._ 
### TexasSolver/TexasSolver/src/TerminalNode.cpp.TerminalNode 
 - Explanation:  _The provided code is a constructor for the `TerminalNode` class, which is a subclass of `GameTreeNode`. The constructor initializes the `payoffs`, `winner`, `round`, and `pot` member variables of the `TerminalNode` object._ 
### TexasSolver/TexasSolver/src/ActionNode.cpp.ActionNode 
 - Explanation:  _The provided code is a constructor for the `ActionNode` class, which is a subclass of `GameTreeNode`. The constructor initializes the `actions`, `player`, `childrens`, `round`, and `pot` member variables of the `ActionNode` object._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`cfr`: The function of `cfr` is *FILL IN* 
**Parameters**:\
`int player`: *FILL IN* \
`shared_ptr<GameTreeNode> node`: *FILL IN* \
`const vector<float> &reach_probs`: *FILL IN* \
`int iter`: *FILL IN* \
`uint64_t current_board`: *FILL IN* \
`int deal`: *FILL IN* \

**Code Description**: *FILL IN*
