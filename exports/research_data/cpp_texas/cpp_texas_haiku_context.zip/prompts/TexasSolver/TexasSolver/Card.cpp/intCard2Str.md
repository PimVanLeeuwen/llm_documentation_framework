# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/Card.cpp` \
**Type:** `Method` \
**Method Name:** `intCard2Str` \
**Code Content:** \
`string Card::intCard2Str(int card){
    int rank = card / 4 + 2;
    int suit = card - (rank-2)*4;
    return Card::rankToString(rank) + Card::suitToString(suit);
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/Card.cpp.rankToString 
 - Explanation:  _The `rankToString` method takes an integer `rank` as input and returns a string representation of the card rank. It uses a `switch` statement to map the integer rank values to their corresponding string representations._ 
### TexasSolver/TexasSolver/Card.cpp.suitToString 
 - Explanation:  _The `suitToString` method takes an integer `suit` value and returns a corresponding string representation of the suit. The method uses a `switch` statement to map the integer values `0`, `1`, `2`, and `3` to the string values `"c"`, `"d"`, `"h"`, and `"s"`, respectively._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`intCard2Str`: The function of `intCard2Str` is *FILL IN* 
**Parameters**:\
`int card`: *FILL IN* \

**Code Description**: *FILL IN*
