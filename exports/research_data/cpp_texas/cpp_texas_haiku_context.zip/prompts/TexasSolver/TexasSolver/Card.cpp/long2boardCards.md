# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/Card.cpp` \
**Type:** `Method` \
**Method Name:** `long2boardCards` \
**Code Content:** \
`vector<Card> Card::long2boardCards(uint64_t board_long){
        vector<int> board = long2board(board_long);
        vector<Card> board_cards(board.size());
        for(std::size_t i = 0;i < board.size();i ++){
            int one_board = board[i];
            board_cards[i] = Card(intCard2Str(one_board));
        }
        if (board_cards.size() < 1 || board_cards.size() > 7){
            throw runtime_error(tfm::format("board length not correct, board length %s",board_cards.size()));
        }
        vector<Card> retval(board_cards.size());
        for(std::size_t i = 0;i < board_cards.size();i ++){
            retval[i] = board_cards[i];
        }
        return retval;
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/Card.cpp.intCard2Str 
 - Explanation:  _The `intCard2Str` method takes an integer `card` value and converts it to a string representation of the card, including both the rank and suit. It does this by extracting the rank and suit from the integer value and using the `rankToString` and `suitToString` methods to get the corresponding string representations._ 
### TexasSolver/TexasSolver/Card.cpp.Card 
 - Explanation:  _This code defines a constructor for the `Card` class that takes a string representing a playing card, converts it to an integer value using the `strCard2int` function, and stores the card string and integer representation as member variables.

The constructor also initializes the `card_number_in_deck` member variable to -1._ 
### TexasSolver/TexasSolver/Card.cpp.long2board 
 - Explanation:  _This code converts a 64-bit integer representation of a poker board into a vector of integers representing the card indices on the board. It checks that the resulting vector has between 1 and 7 elements, and throws an exception if the length is not correct._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`long2boardCards`: The function of `long2boardCards` is *FILL IN* 
**Parameters**:\
`uint64_t board_long`: *FILL IN* \

**Code Description**: *FILL IN*
