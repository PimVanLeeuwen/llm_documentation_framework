# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/Card.cpp` \
**Type:** `Method` \
**Method Name:** `strCard2int` \
**Code Content:** \
`int Card::strCard2int(string card) {
    char rank = card.at(0);
    char suit = card.at(1);
    if(card.length() != 2){
        throw runtime_error( tfm::format("card %s not found",card));
    }
    return (rankToInt(rank) - 2) * 4 + suitToInt(suit);
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/Card.cpp.rankToInt 
 - Explanation:  _The `rankToInt` method takes a character representing a card rank and returns an integer value corresponding to that rank. If the input character is not a valid rank, it returns the default value of 2._ 
### TexasSolver/TexasSolver/Card.cpp.suitToInt 
 - Explanation:  _This code defines a function `suitToInt` that takes a character representing a playing card suit and returns an integer value corresponding to that suit. The function uses a switch statement to map the suit character to an integer value._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`strCard2int`: The function of `strCard2int` is *FILL IN* 
**Parameters**:\
`string card`: *FILL IN* \

**Code Description**: *FILL IN*
