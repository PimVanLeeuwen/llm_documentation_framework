`rankToString`: The function of `rankToString` is to convert an integer representing a card rank to its corresponding string representation.

**Parameters**:
`int rank`: The integer value representing the rank of a playing card, where 2 represents the 2 card, 3 represents the 3 card, and so on, up to 14 which represents the Ace.

**Code Description**:
The `rankToString` function uses a `switch` statement to map the integer `rank` value to its corresponding string representation. The function returns the appropriate string for each rank value, with the exception of the default case, which returns the string "2" for any invalid rank value.

The function is likely used in a larger context to represent playing cards, where the rank and suit of a card need to be displayed or manipulated in the program.\\
## Code: 
```
string Card::rankToString(int rank)
{
    switch(rank)
    {
        case 2: return "2";
        case 3: return "3";
        case 4: return "4";
        case 5: return "5";
        case 6: return "6";
        case 7: return "7";
        case 8: return "8";
        case 9: return "9";
        case 10: return "T";
        case 11: return "J";
        case 12: return "Q";
        case 13: return "K";
        case 14: return "A";
        default: return "2";
    }
}
```