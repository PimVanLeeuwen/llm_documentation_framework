`intCard2Str`: The function of `intCard2Str` is to convert an integer representation of a playing card to its corresponding string representation.

**Parameters**:
`int card`: The integer representation of the playing card, where the value ranges from 0 to 51, with 0 representing the 2 of clubs and 51 representing the Ace of spades.

**Code Description**:
The `intCard2Str` function takes an integer `card` as input and returns a string representation of the card. It does this by first calculating the rank of the card (2 through 14, where 11 represents Jack, 12 represents Queen, and 13 represents King) and the suit of the card (0 for clubs, 1 for diamonds, 2 for hearts, and 3 for spades).

The function does this by dividing the `card` value by 4 and adding 2 to get the rank, and then taking the remainder of the division by 4 to get the suit. It then calls the `rankToString` and `suitToString` functions to convert the calculated rank and suit values to their corresponding string representations, and concatenates the results to form the final string representation of the card.

For example, if the input `card` value is 13, the function would calculate the rank as 5 (13 / 4 + 2) and the suit as 1 (13 % 4), and then call `rankToString(5)` to get the string "5" and `suitToString(1)` to get the string "d", resulting in the final string representation "5d" for the 5 of diamonds.\\
## Code: 
```
string Card::intCard2Str(int card){
    int rank = card / 4 + 2;
    int suit = card - (rank-2)*4;
    return Card::rankToString(rank) + Card::suitToString(suit);
}
```