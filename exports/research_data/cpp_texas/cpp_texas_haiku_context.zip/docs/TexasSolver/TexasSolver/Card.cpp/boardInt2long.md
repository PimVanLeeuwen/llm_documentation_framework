`boardInt2long`: The function of `boardInt2long` is to convert an integer representation of a card on a board to a 64-bit unsigned integer representation.

**Parameters**:
`int board`: The integer representation of the card on the board, where 0 represents the first card and 51 represents the last card in a standard 52-card deck.

**Code Description**:
1. The function first checks if the `board` parameter is within the valid range of 0 to 51 (inclusive). If the value is outside this range, it throws a `runtime_error` with a formatted error message.
2. The function then uses the bitwise left shift operator (`<<`) to set the bit at the position corresponding to the `board` value to 1, while all other bits are set to 0. This effectively creates a 64-bit unsigned integer with a single bit set, representing the card on the board.

The purpose of this function is to provide a compact and efficient way to represent the state of a card on the board as a 64-bit integer. This representation can be useful in various card game algorithms and data structures, where it allows for efficient bitwise operations and comparisons.\\
## Code: 
```
uint64_t Card::boardInt2long(int board){
    // 这里hard code了一副扑克牌是52张
    if(board < 0 || board >= 52){
        throw runtime_error(tfm::format("Card with id %s not found",board));
    }
    // uint64_7 的range 在0 ~ + 2^ 64之间,所以不用太担心溢出问题
    return ((uint64_t)(1) << board);
}
```