`long2boardCards`: The function of `long2boardCards` is to convert a 64-bit integer representation of a poker board into a vector of `Card` objects representing the cards on the board.

**Parameters**:
`uint64_t board_long`: This parameter represents the 64-bit integer encoding of the poker board. Each bit in the 64-bit value corresponds to a card in the deck, with a 1 indicating the card is on the board and a 0 indicating the card is not on the board.

**Code Description**:
1. The function first calls the `long2board` function to convert the 64-bit `board_long` value into a vector of integer card indices.
2. It then creates a vector of `Card` objects, with each `Card` object representing one of the cards on the board. This is done by iterating over the vector of card indices and creating a `Card` object for each index using the `intCard2Str` function to convert the integer index to a string representation of the card.
3. The function checks that the resulting vector of `Card` objects has between 1 and 7 elements, as a valid poker board must have between 1 and 7 cards. If the length is not correct, the function throws a `runtime_error` exception.
4. Finally, the function creates a new vector of `Card` objects and copies the `Card` objects from the previous vector into it, returning the new vector.

The purpose of this function is to provide a convenient way to convert the 64-bit integer representation of a poker board into a vector of `Card` objects, which can be more easily manipulated and used in other parts of the code.\\
## Code: 
```
vector<Card> Card::long2boardCards(uint64_t board_long){
        vector<int> board = long2board(board_long);
        vector<Card> board_cards(board.size());
        for(std::size_t i = 0;i < board.size();i ++){
            int one_board = board[i];
            board_cards[i] = Card(intCard2Str(one_board));
        }
        if (board_cards.size() < 1 || board_cards.size() > 7){
            throw runtime_error(tfm::format("board length not correct, board length %s",board_cards.size()));
        }
        vector<Card> retval(board_cards.size());
        for(std::size_t i = 0;i < board_cards.size();i ++){
            retval[i] = board_cards[i];
        }
        return retval;
}
```