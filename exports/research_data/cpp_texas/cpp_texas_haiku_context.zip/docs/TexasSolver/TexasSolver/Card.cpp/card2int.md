`card2int`: The function of `card2int` is to convert a `Card` object to an integer representation.

**Parameters**:
`Card card`: This parameter represents a `Card` object that needs to be converted to an integer.

**Code Description**: The `card2int` function takes a `Card` object as input and calls the `strCard2int` function, passing the result of the `getCard()` method of the `Card` object. The `strCard2int` function is responsible for converting the string representation of the card to an integer value. The `card2int` function simply acts as a wrapper around the `strCard2int` function, providing a more convenient way to convert a `Card` object to an integer.\\
## Code: 
```
int Card::card2int(Card card) {
    return strCard2int(card.getCard());
}
```