`boardCards2html`: The function of `boardCards2html` is to generate an HTML-formatted string representing the cards in a given vector.

**Parameters**:
`vector<Card>& cards`: This parameter is a reference to a vector of `Card` objects, representing the cards on the game board.

**Code Description**:
The `boardCards2html` function takes a vector of `Card` objects as input and generates an HTML-formatted string representing those cards. It iterates through the vector of cards, and for each non-empty card, it calls the `toFormattedHtml()` method on the card to get its HTML representation. The resulting HTML strings are concatenated and returned as the final output.

The function first initializes an empty `QString` variable called `ret_html` to store the final HTML output. Then, it iterates through the `cards` vector using a range-based for loop. For each `one_card` in the vector, it checks if the card is empty using the `empty()` method. If the card is not empty, it calls the `toFormattedHtml()` method on the card and appends the resulting HTML string to the `ret_html` variable. Finally, the function returns the `ret_html` string, which contains the HTML representation of all the non-empty cards in the input vector.

The `toFormattedHtml()` method is responsible for converting the string representation of a playing card into an HTML-formatted string with the card suit displayed as a Unicode symbol. This method is not shown in the provided code, but it likely replaces specific characters in the input string with HTML span tags that apply color formatting to the suit symbols.

Overall, the `boardCards2html` function is a utility function that helps generate an HTML representation of the cards on the game board, which can be useful for displaying the game state in a web-based user interface.\\
## Code: 
```
QString Card::boardCards2html(vector<Card>& cards){
    QString ret_html = "";
    for(auto one_card:cards){
        if(one_card.empty())continue;
        ret_html += one_card.toFormattedHtml();
    }
    return ret_html;
}
```