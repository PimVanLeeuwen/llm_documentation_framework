`toString`: The function of `toString` is to return a string representation of the `Card` object.

**Code Description**: The `toString()` method is a member function of the `Card` class. It takes no parameters and returns a `string` value. The implementation of the method simply returns the value of the `card` member variable of the `Card` object. This allows the `Card` object to be easily converted to a string representation, which can be useful for displaying or logging information about the card.\\
## Code: 
```
string Card::toString() {
    return this->card;
}
```