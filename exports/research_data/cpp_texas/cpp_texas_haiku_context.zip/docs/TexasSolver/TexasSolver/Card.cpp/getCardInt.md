`getCardInt`: The function of `getCardInt` is to return the integer value of the card.

**Code Description**: The `getCardInt()` method is a simple accessor function that returns the `card_int` member variable of the `Card` class. This variable likely stores the numeric value of the card, such as 2 for a 2 of clubs, 10 for a jack, and so on. By providing this getter method, the `Card` class allows other parts of the code to easily access the integer representation of the card, which may be useful for various card game logic or calculations.\\
## Code: 
```
int Card::getCardInt() {
    return this->card_int;
}
```