`boardInts2long`: The function of `boardInts2long` is to convert a vector of integer card IDs representing a poker board into a single 64-bit unsigned integer representation.

**Parameters**:
`const vector<int>& board`: This parameter is a reference to a vector of integers, where each integer represents the ID of a card on the poker board. The board can contain between 1 and 7 cards.

**Code Description**:
1. The function first checks if the size of the `board` vector is between 1 and 7 cards. If the size is outside of this range, it throws a `runtime_error` with a message indicating the incorrect board length.
2. The function then initializes a 64-bit unsigned integer `board_long` to 0.
3. It then iterates through each card ID in the `board` vector and checks if the card ID is within the valid range of 0 to 51 (assuming a standard 52-card deck). If any card ID is outside of this range, it throws a `runtime_error` with a message indicating the invalid card ID.
4. For each valid card ID, the function sets the corresponding bit in the `board_long` integer by shifting a 1 bit to the position of the card ID and adding it to the `board_long` value. This effectively encodes the presence of each card on the board into a single 64-bit integer.
5. Finally, the function returns the `board_long` value, which represents the entire poker board in a compact 64-bit format.

The purpose of this function is to provide a efficient way to represent the poker board state as a single 64-bit value, which can be useful for various poker-related algorithms and data structures that need to work with the board state.\\
## Code: 
```
uint64_t Card::boardInts2long(const vector<int>& board){
    if(board.size() < 1 || board.size() > 7){
        throw runtime_error(tfm::format("Card length incorrect: %s",board.size()));
    }
    uint64_t board_long = 0;
    for(int one_card: board){
        // 这里hard code了一副扑克牌是52张
        if(one_card < 0 || one_card >= 52){
            throw runtime_error(tfm::format("Card with id %s not found",one_card));
        }
        // uint64_7 的range 在0 ~ + 2^ 64之间,所以不用太担心溢出问题
        board_long += ((uint64_t)(1) << one_card);
    }
    return board_long;
}
```