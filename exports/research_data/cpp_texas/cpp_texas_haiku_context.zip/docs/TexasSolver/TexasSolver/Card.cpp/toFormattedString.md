`toFormattedString`: The function of `toFormattedString` is to convert the string representation of a playing card into a formatted string with the corresponding suit symbol.

**Code Description**: The `toFormattedString` method is a member function of the `Card` class. It takes no parameters and returns a `std::string` object.

The function first creates a `QString` object `qString` from the `std::string` representation of the card, which is stored in the `card` member variable of the `Card` class.

Next, the function replaces the following characters in the `qString` object:
- `"c"` is replaced with `"♣️"` (the Unicode symbol for the club suit)
- `"d"` is replaced with `"♦️"` (the Unicode symbol for the diamond suit)
- `"h"` is replaced with `"♥️"` (the Unicode symbol for the heart suit)
- `"s"` is replaced with `"♠️"` (the Unicode symbol for the spade suit)

Finally, the function converts the modified `qString` object back to a `std::string` and returns it.

This function is likely used to display the playing card in a user interface or other output, where the suit symbols are more visually appealing than the single-character suit representations.\\
## Code: 
```
string Card::toFormattedString() {
    QString qString = QString::fromStdString(this->card);
    qString = qString.replace("c", "♣️");
    qString = qString.replace("d", "♦️");
    qString = qString.replace("h", "♥️");
    qString = qString.replace("s", "♠️");
    return qString.toStdString();
}
```