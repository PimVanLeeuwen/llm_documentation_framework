`Card`: The function of `Card` is to create a new `Card` object with the given card string and its corresponding integer representation.

**Parameters**:
`string card`: The string representation of the playing card, such as "AS" for the Ace of Spades or "2H" for the 2 of Hearts.

**Code Description**:
The `Card` constructor takes a `string` parameter `card` that represents a playing card. It performs the following tasks:

1. Stores the input `card` string in the `card` member variable of the `Card` object.
2. Calls the `strCard2int` function (defined elsewhere in the code) to convert the `card` string to an integer representation, and stores the result in the `card_int` member variable.
3. Initializes the `card_number_in_deck` member variable to `-1`, which likely indicates that the card's position in the deck is not yet known.

The purpose of this `Card` class is to provide a way to represent and work with individual playing cards in the context of the larger `TexasSolver` project. The `card_int` member variable stores the integer representation of the card, which can be useful for comparing and sorting cards, while the `card_number_in_deck` member variable can be used to track the card's position in the deck.\\
## Code: 
```
Card::Card(string card){
    this->card = card;
    this->card_int = Card::strCard2int(this->card);
    this->card_number_in_deck = -1;
}
```