`boardCards2long`: The function of `boardCards2long` is to convert a vector of `Card` objects representing a poker board into a single 64-bit unsigned integer representation.

**Parameters**:
`vector<string> cards`: This parameter is a vector of strings, where each string represents a playing card on the poker board.

**Code Description**: The `boardCards2long` function first creates a vector of `Card` objects by iterating through the `cards` vector and creating a new `Card` object for each card string. It then calls the `boardCards2long` function that takes a vector of `Card` objects and returns a 64-bit unsigned integer representation of the board.

The implementation of the `boardCards2long` function that takes a vector of `Card` objects is not provided in the given code snippet, but it likely performs the following steps:

1. Converts each `Card` object in the input vector to an integer representation using the `card2int` method.
2. Combines the integer representations of the cards into a single 64-bit unsigned integer using a bitwise operation, such as shifting and ORing the individual card values.

This 64-bit integer representation of the board can be used for efficient storage and comparison of poker boards, which is useful in various poker-related algorithms and applications.\\
## Code: 
```
uint64_t Card::boardCards2long(vector<string> cards) {
    vector<Card> cards_objs(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_objs[i] = Card(cards[i]);
    }
    return Card::boardCards2long(cards_objs);
}
```