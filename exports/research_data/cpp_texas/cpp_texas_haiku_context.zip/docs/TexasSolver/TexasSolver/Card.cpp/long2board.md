`long2board`: The function of `long2board` is to convert a 64-bit integer representation of a poker board into a vector of integers representing the card indices on the board.

**Parameters**:
`uint64_t board_long`: This is a 64-bit unsigned integer that represents the poker board. Each bit in the integer corresponds to a card in the deck, with a 1 indicating the card is on the board and a 0 indicating the card is not on the board.

**Code Description**:
The function first creates an empty vector `board` to store the card indices. It then iterates through the 52 bits of the `board_long` integer, checking if each bit is set to 1. If a bit is set to 1, the corresponding card index (0-51) is added to the `board` vector.

After iterating through all 52 bits, the function checks if the size of the `board` vector is less than 1 or greater than 7. This is because a valid poker board must have between 1 and 7 cards. If the size of the `board` vector is not within this range, the function throws a `runtime_error` with a message indicating the incorrect board length.

Finally, the function returns the `board` vector containing the card indices that were set in the `board_long` integer.\\
## Code: 
```
vector<int> Card::long2board(uint64_t board_long) {
    vector<int> board;
    board.reserve(7);
    for(int i = 0;i < 52;i ++){
        // 看二进制最后一位是否为1
        if((board_long & 1) == 1){
            board.push_back(i);
        }
        board_long = board_long >> 1;
    }
    if (board.size() < 1 || board.size() > 7){
        throw runtime_error(tfm::format("board length not correct, board length %s",board.size()));
    }
    return board;
}
```