`strCard2int`: The function of `strCard2int` is to convert a string representation of a playing card into an integer value.

**Parameters**:
`string card`: The string representation of a playing card, where the first character represents the rank (e.g., 'A', '2', '3', ..., 'T', 'J', 'Q', 'K') and the second character represents the suit (e.g., 'C', 'D', 'H', 'S').

**Code Description**:
The `strCard2int` function takes a string `card` as input and extracts the rank and suit characters from it. It first checks if the input string has a length of 2, as a valid card representation should have exactly two characters. If the length is not 2, the function throws a `runtime_error` with a formatted error message.

If the input string is valid, the function calls two helper functions, `rankToInt` and `suitToInt`, to convert the rank and suit characters to their corresponding integer values. The `rankToInt` function maps the rank character to an integer value, where 'A' is mapped to 14, 'K' is mapped to 13, and so on. The `suitToInt` function maps the suit character to an integer value, where 'C' is mapped to 0, 'D' is mapped to 1, 'H' is mapped to 2, and 'S' is mapped to 3.

The final integer value returned by `strCard2int` is calculated as follows:
1. The rank integer value is subtracted by 2 to get a range from 0 to 12 (since 'A' is mapped to 14).
2. The result is multiplied by 4 to get a range from 0 to 48 (since there are 4 suits).
3. The suit integer value is added to the result to get the final integer value representing the card, which ranges from 0 to 51 (since there are 52 cards in a standard deck).

This integer value can be used to represent a playing card in a more compact and efficient way, for example, in a data structure or algorithm that deals with card games.\\
## Code: 
```
int Card::strCard2int(string card) {
    char rank = card.at(0);
    char suit = card.at(1);
    if(card.length() != 2){
        throw runtime_error( tfm::format("card %s not found",card));
    }
    return (rankToInt(rank) - 2) * 4 + suitToInt(suit);
}
```