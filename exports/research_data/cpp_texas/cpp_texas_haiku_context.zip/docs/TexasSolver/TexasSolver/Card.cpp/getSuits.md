`getSuits`: The function of `getSuits` is to return a vector of strings representing the four standard suits in a deck of playing cards: clubs ("c"), diamonds ("d"), hearts ("h"), and spades ("s").

**Code Description**: The `getSuits` function is a member function of the `Card` class. It returns a vector of four string literals, each representing one of the four standard suits in a deck of playing cards. This function does not take any parameters and simply returns the hardcoded vector of suit strings. This function can be useful for any code that needs to work with the standard suits of a playing card deck, such as in card game or card-related applications.\\
## Code: 
```
vector<string> Card::getSuits(){
    return {"c","d","h","s"};
}
```