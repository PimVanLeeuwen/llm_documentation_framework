`toFormattedHtml`: The function of `toFormattedHtml` is to convert a string representation of a playing card into an HTML-formatted string with the card suit symbols displayed as HTML entities.

**Code Description**:
The `toFormattedHtml` method takes a string representation of a playing card, such as "c" for clubs, "d" for diamonds, "h" for hearts, and "s" for spades, and converts it into an HTML-formatted string.

The method first creates a `QString` object from the string representation of the card using `QString::fromStdString(this->card)`. It then checks the string for the presence of the suit characters ("c", "d", "h", or "s") and replaces them with the corresponding HTML entity for the card suit symbol.

- If the string contains "c", it is replaced with `<span style="color:black;">&#9827;</span>`, which displays the black club symbol.
- If the string contains "d", it is replaced with `<span style="color:red;">&#9830;</span>`, which displays the red diamond symbol.
- If the string contains "h", it is replaced with `<span style="color:red;">&#9829;</span>`, which displays the red heart symbol.
- If the string contains "s", it is replaced with `<span style="color:black;">&#9824;</span>`, which displays the black spade symbol.

The resulting HTML-formatted string is then returned by the method.

This function is likely used to display playing card information in an HTML-based user interface, such as a web application or a desktop application with an HTML-based rendering engine. By converting the string representation of the card into an HTML-formatted string with the appropriate suit symbols, the function allows the card to be displayed in a visually appealing and easily recognizable way.\\
## Code: 
```
QString Card::toFormattedHtml() {
    QString qString = QString::fromStdString(this->card);
    if(qString.contains("c"))
        qString = qString.replace("c", QString::fromLocal8Bit("<span style=\"color:black;\">&#9827;<\/span>"));
    else if(qString.contains("d"))
        qString = qString.replace("d", QString::fromLocal8Bit("<span style=\"color:red;\">&#9830;<\/span>"));
    else if(qString.contains("h"))
        qString = qString.replace("h", QString::fromLocal8Bit("<span style=\"color:red;\">&#9829;<\/span>"));
    else if(qString.contains("s"))
        qString = qString.replace("s", QString::fromLocal8Bit("<span style=\"color:black;\">&#9824;<\/span>"));
    return qString;
}
```