`suitToInt`: The function of `suitToInt` is to convert a character representing a playing card suit to an integer value.

**Parameters**:
`char suit`: The character representing the playing card suit, which can be one of the following: 'c' (clubs), 'd' (diamonds), 'h' (hearts), or 's' (spades).

**Code Description**:
The `suitToInt` function uses a `switch` statement to map the input `suit` character to an integer value. The mapping is as follows:
- If the `suit` is 'c', the function returns 0 (representing clubs).
- If the `suit` is 'd', the function returns 1 (representing diamonds).
- If the `suit` is 'h', the function returns 2 (representing hearts).
- If the `suit` is 's', the function returns 3 (representing spades).
- If the `suit` is none of the above, the function returns 0 (the default case).

This function is likely used in a larger context, such as a card game or a card-related application, where the integer representation of the suit is more convenient to work with than the character representation.\\
## Code: 
```
int Card::suitToInt(char suit)
{
    switch(suit)
    {
        case 'c': return 0; // 梅花
        case 'd': return 1; // 方块
        case 'h': return 2; // 红桃
        case 's': return 3; // 黑桃
        default: return 0;
    }
}
```