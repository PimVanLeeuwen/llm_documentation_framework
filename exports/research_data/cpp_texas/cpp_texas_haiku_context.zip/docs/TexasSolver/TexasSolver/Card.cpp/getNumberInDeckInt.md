`getNumberInDeckInt`: The function of `getNumberInDeckInt` is to return the card number in the deck.

**Code Description**: The `getNumberInDeckInt` function is a method of the `Card` class. It is responsible for returning the card number in the deck, which is stored in the `card_number_in_deck` member variable of the `Card` object.

The function first checks if the `card_number_in_deck` variable is set to -1. If it is, the function throws a `runtime_error` exception with the message "card number in deck cannot be -1". This is likely a safeguard to ensure that the card number is a valid value.

If the `card_number_in_deck` variable is not set to -1, the function simply returns the value of `card_number_in_deck`. This allows other parts of the code to access the card number in the deck for the specific `Card` object.

The purpose of this function is to provide a way to retrieve the card number in the deck for a given `Card` object, which can be useful in various card-related operations or calculations within the `TexasSolver` project.\\
## Code: 
```
int Card::getNumberInDeckInt(){
    if(this->card_number_in_deck == -1)throw runtime_error("card number in deck cannot be -1");
    return this->card_number_in_deck;
}
```