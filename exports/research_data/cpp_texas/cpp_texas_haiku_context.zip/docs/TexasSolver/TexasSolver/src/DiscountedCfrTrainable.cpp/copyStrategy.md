`copyStrategy`: The function of `copyStrategy` is to copy the strategy of another `DiscountedCfrTrainable` object.

**Parameters**:
`shared_ptr<Trainable> other_trainable`: This parameter is a shared pointer to a `Trainable` object, which is dynamically cast to a `shared_ptr<DiscountedCfrTrainable>`. This allows the function to access the specific data members of the `DiscountedCfrTrainable` class.

**Code Description**:
The `copyStrategy` function first casts the `other_trainable` shared pointer to a `shared_ptr<DiscountedCfrTrainable>`. This is done to ensure that the object being copied is of the correct type.

Next, the function copies the values of the `r_plus` and `cum_r_plus` vectors from the `other_trainable` object to the current `DiscountedCfrTrainable` object. The `assign` function is used to copy the contents of the vectors from the `other_trainable` object to the current object.

The `r_plus` vector likely represents the cumulative rewards obtained during the training process, and the `cum_r_plus` vector likely represents the cumulative sum of these rewards. By copying these vectors, the function ensures that the current `DiscountedCfrTrainable` object has the same strategy as the `other_trainable` object, which can be useful for tasks such as model initialization or parameter sharing.\\
## Code: 
```
void DiscountedCfrTrainable::copyStrategy(shared_ptr<Trainable> other_trainable){
    shared_ptr<DiscountedCfrTrainable> trainable = dynamic_pointer_cast<DiscountedCfrTrainable>(other_trainable);
    this->r_plus.assign(trainable->r_plus.begin(),trainable->r_plus.end());
    this->cum_r_plus.assign(trainable->cum_r_plus.begin(),trainable->cum_r_plus.end());
}
```