`intToGameRound`: The function of `intToGameRound` is to convert an integer value representing a game round to the corresponding `GameTreeNode::GameRound` enumeration value.

**Parameters**:
`int round`: The integer value representing the game round, where 0 corresponds to the preflop round, 1 to the flop round, 2 to the turn round, and 3 to the river round.

**Code Description**:
The `intToGameRound` function takes an integer `round` as input and returns the corresponding `GameTreeNode::GameRound` enumeration value. It uses a `switch` statement to map the integer values to the appropriate `GameRound` enum values. If the input `round` value is not one of the expected values (0, 1, 2, or 3), the function throws a `runtime_error` with a formatted error message indicating that the round value is not found.

The function is likely used in the context of a poker game simulation or analysis, where the game state needs to be represented and tracked throughout the different rounds of the game (preflop, flop, turn, and river).\\
## Code: 
```
GameTreeNode::GameRound GameTreeNode::intToGameRound(int round){
    GameTreeNode::GameRound game_round;
    switch(round){
        case 0:{
            game_round = GameTreeNode::GameRound::PREFLOP;
            break;
        }
        case 1:{
            game_round = GameTreeNode::GameRound::FLOP;
            break;
        }
        case 2:{
            game_round = GameTreeNode::GameRound::TURN;
            break;
        }
        case 3:{
            game_round = GameTreeNode::GameRound::RIVER;
            break;
        }
        default:{
            throw runtime_error(tfm::format("round %s not found",round));
        }
    }
    return game_round;
}
```