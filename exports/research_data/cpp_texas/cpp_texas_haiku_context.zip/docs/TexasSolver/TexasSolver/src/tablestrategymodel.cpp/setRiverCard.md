`setRiverCard`: The function of `setRiverCard` is to set the river card in the `TableStrategyModel` object.

**Parameters**:
`Card river_card`: This parameter represents the river card that will be set in the `TableStrategyModel` object.

**Code Description**: The `setRiverCard` function takes a `Card` object as a parameter and assigns it to the `river_card` member variable of the `TableStrategyModel` class. This allows the `TableStrategyModel` object to store the river card, which is an important piece of information in a Texas Hold'em poker game. The river card is the fifth and final community card dealt in the game, and it can have a significant impact on the outcome of the hand. By setting the river card in the `TableStrategyModel` object, other parts of the application can access and use this information as needed.\\
## Code: 
```
void TableStrategyModel::setRiverCard(Card river_card){
    this->river_card = river_card;
}
```