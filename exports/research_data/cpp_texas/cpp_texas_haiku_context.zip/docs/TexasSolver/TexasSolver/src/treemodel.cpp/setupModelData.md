`setupModelData`: The function of `setupModelData` is to set up the data model for a game tree in a poker solver application.

**Code Description**:

The `setupModelData` function is responsible for initializing the game tree model used in the poker solver application. It performs the following tasks:

1. Determines the mode of the poker solver, which can be either "HOLDEM" (Texas Hold'em) or "SHORTDECK" (Short Deck Poker). Based on the mode, it retrieves the corresponding `PokerSolver` instance from the `qSolverJob` object.

2. Checks if the `GameTree` object associated with the `PokerSolver` instance has a valid root node. If the root node is `nullptr`, the function simply returns without further processing.

3. Retrieves the `GameRound` value from the root node of the `GameTree`.

4. Creates a new `TreeItem` object as the root item of the model and adds it to the `rootItem` member variable.

5. Creates a new `TreeItem` object as a child of the root item and adds it to the root item's list of children.

6. Calls the `reGenerateTreeItem` function, passing the `GameRound` value and the newly created child `TreeItem` object. This function recursively processes the game tree and generates the corresponding `TreeItem` objects for the child nodes.

The `reGenerateTreeItem` function is responsible for creating the tree-like structure of the game tree model. It processes each node in the game tree and creates new `TreeItem` objects to represent the node and its children. The function recursively calls itself to handle the child nodes, ensuring that the entire game tree is represented in the model.

The `setupModelData` function sets up the initial structure of the game tree model, which can then be used to display and interact with the game tree in the application's user interface.\\
## Code: 
```
void TreeModel::setupModelData()
{
    PokerSolver * solver;
    if(this->qSolverJob->mode == QSolverJob::Mode::HOLDEM){
        solver = &(this->qSolverJob->ps_holdem);
    }else if(this->qSolverJob->mode == QSolverJob::Mode::SHORTDECK){
        solver = &(this->qSolverJob->ps_shortdeck);
    }else{
        throw runtime_error("holdem mode incorrect");
    }

    if(solver->get_game_tree() == nullptr || solver->get_game_tree()->getRoot() == nullptr){
        return;
    }

    GameTreeNode::GameRound round =	solver->get_game_tree()->getRoot()->getRound();

    this->rootItem = new TreeItem(solver->get_game_tree()->getRoot());
    TreeItem* ti = new TreeItem(solver->get_game_tree()->getRoot(),this->rootItem);
    rootItem->insertChild(ti);
    this->reGenerateTreeItem(round,ti);
}
```