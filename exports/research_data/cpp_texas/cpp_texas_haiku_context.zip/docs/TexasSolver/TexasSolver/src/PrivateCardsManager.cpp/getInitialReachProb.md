`getInitialReachProb`: The function of `getInitialReachProb` is to calculate the initial reach probability for each of the player's private cards given the initial board state.

**Parameters**:
`int player`: The index of the player whose private cards are being considered.
`uint64_t initialboard`: The initial board state represented as a 64-bit unsigned integer.

**Code Description**:
The function first retrieves the number of private cards for the given player by accessing the `private_cards` vector. It then creates a vector `probs` to store the initial reach probability for each of the player's private cards.

For each private card, the function checks if the card's hand representation (obtained using the `get_hands()` method) has any intersection with the initial board state (represented as a 64-bit unsigned integer using the `boardInts2long()` function). If there is an intersection, the initial reach probability for that card is set to 0, as the card cannot be part of the initial hand. Otherwise, the initial reach probability is set to the weight associated with the private card.

Finally, the function returns the vector of initial reach probabilities for the player's private cards.\\
## Code: 
```
vector<float> PrivateCardsManager::getInitialReachProb(int player, uint64_t initialboard) {
    int cards_len =  this->private_cards[player].size();
    vector<float> probs = vector<float>(cards_len);
    for(int i = 0;i < cards_len;i ++){
        PrivateCards pc = this->private_cards[player][i];
        if(Card::boardsHasIntercept(initialboard,Card::boardInts2long(pc.get_hands()))) {
            probs[i] = 0;
        }else{
            probs[i] = this->private_cards[player][i].weight;
        }
    }
    return probs;
}
```