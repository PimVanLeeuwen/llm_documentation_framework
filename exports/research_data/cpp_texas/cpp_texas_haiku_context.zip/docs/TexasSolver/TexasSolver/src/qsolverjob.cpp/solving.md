`solving`: The function of `solving` is to train a poker solver based on the specified mode (Texas Hold'em or Short Deck) and the provided input parameters.

**Code Description**:

The `solving` function is responsible for training a poker solver using the `PokerSolver.cpp.train` method. The function first checks the mode of the solver, which can be either Texas Hold'em (`Mode::HOLDEM`) or Short Deck (`Mode::SHORTDECK`). Depending on the mode, the function calls the `train` method of the corresponding `ps_holdem` or `ps_shortdeck` object.

The `train` method takes several parameters:
1. `range_ip`: The in-position player's range.
2. `range_oop`: The out-of-position player's range.
3. `board`: The community cards on the board.
4. `""`: An empty string, which is not used in this case.
5. `max_iteration`: The maximum number of iterations for the solver to run.
6. `print_interval`: The interval at which to print the solver's progress.
7. `"discounted_cfr"`: The solver algorithm to use, which is Discounted Counterfactual Regret Minimization.
8. `-1`: A parameter that is not used in this case.
9. `accuracy`: The desired accuracy for the solver's solution.
10. `use_isomorphism`: A flag to enable or disable the use of isomorphism in the solver.
11. `use_halffloats`: A flag to enable or disable the use of half-precision floating-point numbers in the solver.
12. `thread_number`: The number of threads to use for the solver.

After the `train` method is called, the function prints a message indicating that the solving process is complete.

The code also includes two TODO comments that suggest there may be some issues with the solver, such as memory leaks and unexpected crashes. However, the code itself does not provide any information about these issues, and the comments are left unresolved.

Overall, the `solving` function is responsible for training a poker solver based on the specified parameters and mode, and it serves as a central entry point for the solver's functionality within the larger `Tex\\
## Code: 
```
void QSolverJob::solving(){
    // TODO  为什么ui上多次求解会积累memory？哪里leak了？
    // TODO  为什么有时候会莫名闪退？
    qDebug().noquote() << tr("Start Solving..");//.toStdString() << std::endl;

    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }
    qDebug().noquote() << tr("Solving done.");//.toStdString() << std::endl;
}
```