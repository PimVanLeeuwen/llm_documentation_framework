`get_round_str`: The function of `get_round_str` is to return a QString (a Qt string type) representing the game round based on the input `GameTreeNode::GameRound` value.

**Parameters**:
`GameTreeNode::GameRound round`: This parameter represents the current game round, which can be one of three values: `FLOP`, `TURN`, or `RIVER`.

**Code Description**:
The `get_round_str` function takes a `GameTreeNode::GameRound` value as input and returns a corresponding QString representing the game round. 

The function uses a series of `if-else` statements to check the value of the `round` parameter and return the appropriate string:
- If `round` is `GameTreeNode::GameRound::FLOP`, the function returns the QString `"FLOP"`.
- If `round` is `GameTreeNode::GameRound::TURN`, the function returns the QString `"TURN"`.
- If `round` is `GameTreeNode::GameRound::RIVER`, the function returns the QString `"RIVER"`.
- If the `round` value is not recognized as one of the three valid options (`FLOP`, `TURN`, or `RIVER`), the function throws a `runtime_error` with the message `"round not recognized, must be in flop,turn,river"`.

The `QObject::tr()` function is used to translate the string values, which is a common practice in Qt applications to support multiple languages.

Overall, the `get_round_str` function provides a convenient way to convert the `GameTreeNode::GameRound` enum values into human-readable string representations, which can be useful for displaying the current game round in a user interface or logging purposes.\\
## Code: 
```
QString TreeItem::get_round_str(GameTreeNode::GameRound round) const{
    if(round == GameTreeNode::GameRound::FLOP){
        return QObject::tr("FLOP");
    }
    else if(round == GameTreeNode::GameRound::TURN){
        return QObject::tr("TURN");
    }
    else if(round == GameTreeNode::GameRound::RIVER){
        return QObject::tr("RIVER");
    }
    else throw runtime_error("round not recognized, must be in flop,turn,river");
}
```