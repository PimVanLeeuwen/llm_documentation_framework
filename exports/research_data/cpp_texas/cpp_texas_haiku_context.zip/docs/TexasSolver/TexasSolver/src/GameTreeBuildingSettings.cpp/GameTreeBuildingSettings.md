`GameTreeBuildingSettings`: The function of `GameTreeBuildingSettings` is to initialize and store the settings for building a game tree in a Texas Hold'em poker game.

**Parameters**:
`StreetSetting flop_ip`: This parameter represents the settings for the flop street when the player is in position (IP).
`StreetSetting turn_ip`: This parameter represents the settings for the turn street when the player is in position (IP).
`StreetSetting river_ip`: This parameter represents the settings for the river street when the player is in position (IP).
`StreetSetting flop_oop`: This parameter represents the settings for the flop street when the player is out of position (OOP).
`StreetSetting turn_oop`: This parameter represents the settings for the turn street when the player is out of position (OOP).
`StreetSetting river_oop`: This parameter represents the settings for the river street when the player is out of position (OOP).

**Code Description**:
The `GameTreeBuildingSettings` constructor initializes and stores the provided `StreetSetting` objects for each street (flop, turn, and river) and each position (in-position and out-of-position). These settings are likely used to configure the game tree building process, which is a crucial part of the Texas Hold'em solver algorithm implemented in the `TexasSolver` project.

The constructor takes six `StreetSetting` parameters and initializes the corresponding member variables of the `GameTreeBuildingSettings` class. This allows the class to encapsulate and manage the various settings required for building the game tree, which is a fundamental component of the Texas Hold'em solver.\\
## Code: 
```
GameTreeBuildingSettings::GameTreeBuildingSettings(
        StreetSetting flop_ip,
        StreetSetting turn_ip,
        StreetSetting river_ip,
        StreetSetting flop_oop,
        StreetSetting turn_oop,
        StreetSetting river_oop):flop_ip(flop_ip),turn_ip(turn_ip),river_ip(river_ip),flop_oop(flop_oop),turn_oop(turn_oop),river_oop(river_oop) {
}
```