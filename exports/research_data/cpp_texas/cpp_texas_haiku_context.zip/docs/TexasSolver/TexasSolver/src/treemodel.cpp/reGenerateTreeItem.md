`reGenerateTreeItem`: The function of `reGenerateTreeItem` is to recursively regenerate the tree structure of a game tree by processing each node and creating new child nodes as necessary.

**Parameters**:
`GameTreeNode::GameRound round`: This parameter represents the current game round for which the tree is being regenerated.
`TreeItem* node_to_process`: This parameter is a pointer to the `TreeItem` node that is currently being processed.

**Code Description**:
The `reGenerateTreeItem` function first retrieves the `GameTreeNode` associated with the `TreeItem` node being processed. It then checks the type of the `GameTreeNode` to determine the appropriate action to take.

If the `GameTreeNode` is of type `ACTION`, the function retrieves the child nodes of the `ActionNode` and creates new `TreeItem` objects for each child node. It then recursively calls `reGenerateTreeItem` on each child node, but only if the child node's game round matches the current round being processed.

If the `GameTreeNode` is of type `CHANCE`, the function creates a new `TreeItem` object for the `ChanceNode`'s children and recursively calls `reGenerateTreeItem` on the new `TreeItem` object.

The purpose of this function is to ensure that the tree structure accurately reflects the current game state and the available actions and chance events for the given game round.\\
## Code: 
```
void TreeModel::reGenerateTreeItem(GameTreeNode::GameRound round,TreeItem* node_to_process){
    const shared_ptr<GameTreeNode> gameTreeNode = node_to_process->m_treedata.lock();
    if(gameTreeNode->getType() == GameTreeNode::GameTreeNodeType::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(gameTreeNode);
        vector<shared_ptr<GameTreeNode>>& childrens = actionNode->getChildrens();
        for(shared_ptr<GameTreeNode> one_child:childrens){
            TreeItem * child_node = new TreeItem(one_child,node_to_process);
            node_to_process->insertChild(child_node);
            if(one_child->getRound() != round){
                continue;
            }
            this->reGenerateTreeItem(round,child_node);
        }
    }
    else if(gameTreeNode->getType() == GameTreeNode::GameTreeNodeType::CHANCE){
        shared_ptr<ChanceNode> chanceNode = dynamic_pointer_cast<ChanceNode>(gameTreeNode);
        TreeItem * child_node = new TreeItem(chanceNode->getChildren(),node_to_process);
        node_to_process->insertChild(child_node);
        this->reGenerateTreeItem(round,child_node);
    }
}
```