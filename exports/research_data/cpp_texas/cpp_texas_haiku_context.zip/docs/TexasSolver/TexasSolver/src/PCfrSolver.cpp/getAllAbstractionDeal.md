`getAllAbstractionDeal`: The function of `getAllAbstractionDeal` is to generate a vector of all possible card deals based on the given `deal` parameter.

**Parameters**:
`int deal`: The `deal` parameter represents the current deal or card combination being considered. It is used to determine the range of possible card deals to generate.

**Code Description**:
The function first checks the value of the `deal` parameter:
- If `deal` is 0, it means the function is being called for the first time, so it adds 0 to the `all_deal` vector and returns it.
- If `deal` is greater than 0 and less than or equal to the number of cards in the deck, it generates all possible deals where only one card is changed from the original deal.
- If `deal` is greater than the number of cards in the deck, it generates all possible deals where two cards are changed from the original deal.

The function then iterates through the possible card combinations and adds them to the `all_deal` vector, with the following checks:
- It calculates the "origin_deal" which is the starting index of the current deal.
- It then checks each of the 4 cards in the deal and adds them to the `all_deal` vector if the card does not intercept with the initial board.
- For the case where two cards are changed, it iterates through all possible combinations of the first and second card changes, adding them to the `all_deal` vector if they do not intercept with the initial board.

The function finally returns the `all_deal` vector containing all the possible card deals based on the given `deal` parameter.\\
## Code: 
```
vector<int> PCfrSolver::getAllAbstractionDeal(int deal){
    vector<int> all_deal;
    int card_num = this->deck.getCards().size();
    if(deal == 0){
        all_deal.push_back(deal);
    } else if (deal > 0 && deal <= card_num){
        int origin_deal = int((deal - 1) / 4) * 4;
        for(int i = 0;i < 4;i ++){
            int one_card = origin_deal + i + 1;

            Card *first_card = const_cast<Card *>(&(this->deck.getCards()[origin_deal + i]));
            uint64_t first_long = Card::boardInt2long(
                    first_card->getCardInt());
            if (Card::boardsHasIntercept(first_long, this->initial_board_long))continue;
            all_deal.push_back(one_card);
        }
    } else{
        //cout << "______________________" << endl;
        int c_deal = deal - (1 + card_num);
        int first_deal = int((c_deal / card_num) / 4) * 4;
        int second_deal = int((c_deal % card_num) / 4) * 4;

        for(int i = 0;i < 4;i ++) {
            for(int j = 0;j < 4;j ++) {
                if(first_deal == second_deal && i == j) continue;

                Card *first_card = const_cast<Card *>(&(this->deck.getCards()[first_deal + i]));
                uint64_t first_long = Card::boardInt2long(
                        first_card->getCardInt());
                if (Card::boardsHasIntercept(first_long, this->initial_board_long))continue;

                Card *second_card = const_cast<Card *>(&(this->deck.getCards()[second_deal + j]));
                uint64_t second_long = Card::boardInt2long(
                        second_card->getCardInt());
                if (Card::boardsHasIntercept(second_long, this->initial_board_long))continue;

                int one_card = card_num * (first_deal + i) + (second_deal + j) + 1 + card_num;
                //cout << ";" << this->deck.getCards()[first_deal + i].toString() << "," << this->deck.getCards()[second_deal + j].toString();
                all_deal.push_back(one_card);
            }
        }
        //cout << endl;
    }
    return all_deal;
}
```