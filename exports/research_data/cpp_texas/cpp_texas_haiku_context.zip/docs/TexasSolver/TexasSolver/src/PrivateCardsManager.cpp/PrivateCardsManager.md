`PrivateCardsManager`: The function of `PrivateCardsManager` is to manage the private cards of players in a Texas Hold'em poker game.

**Parameters**:
`vector<vector<PrivateCards>> private_cards`: This parameter represents the private cards of all players in the game. It is a 2D vector, where each inner vector represents the private cards of a single player.
`int player_number`: This parameter represents the number of players in the game.
`uint64_t initialboard`: This parameter represents the initial board state of the game.

**Code Description**:
The `PrivateCardsManager` constructor performs the following tasks:

1. Stores the `private_cards`, `player_number`, and `initialboard` parameters in the corresponding member variables of the class.
2. Initializes a 2D vector `card_player_index` of size `52 * 52`, where each inner vector has a size of `player_number`. This vector is used to store the index of each private card combination for each player.
3. Iterates through the `private_cards` vector and populates the `card_player_index` vector. For each private card combination, it stores the index of that combination for each player.
4. Calls the `setRelativeProbs()` method to calculate the relative probabilities of each player's private cards based on the initial board state and the opponent's private cards.

The purpose of the `PrivateCardsManager` class is to provide a way to efficiently manage and access the private cards of players in a Texas Hold'em poker game. The `card_player_index` vector allows for quick lookup of the index of a specific private card combination for a given player, which can be useful for various game logic and analysis tasks.

The `setRelativeProbs()` method, which is called in the constructor, is responsible for calculating the relative probabilities of each player's private cards based on the initial board state and the opponent's private cards. This information can be used to inform decision-making and strategy in the game.

Overall, the `PrivateCardsManager` class is a crucial component in the implementation of a Texas Hold'em poker game, as it provides a structured way to manage and access the private card information of players.\\
## Code: 
```
PrivateCardsManager::PrivateCardsManager(vector<vector<PrivateCards>> private_cards, int player_number,
                                         uint64_t initialboard) {
    this->private_cards = private_cards;
    this->player_number = player_number;
    this->card_player_index = vector<vector<int>>(52 * 52);
    for(int i = 0;i < 52 * 52;i ++){
        this->card_player_index[i] = vector<int>(this->player_number,-1);
    }

    // 用一个二维数组记录每个Private Combo的对应index,方便从一方的手牌找对方的同名卡牌的index
    for(int player_id = 0;player_id < player_number;player_id ++){
        vector<PrivateCards> privateCombos = private_cards[player_id];
        for(std::size_t i = 0;i < privateCombos.size();i ++){
            PrivateCards one_private_combo = privateCombos[i];
            this->card_player_index[one_private_combo.hashCode()][player_id] = i;
        }
    }

    this->initialboard = initialboard;
    this->setRelativeProbs();
}
```