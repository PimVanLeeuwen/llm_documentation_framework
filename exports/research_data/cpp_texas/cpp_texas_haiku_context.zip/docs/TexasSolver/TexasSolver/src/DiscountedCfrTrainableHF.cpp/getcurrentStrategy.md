`getcurrentStrategy`: The function of `getcurrentStrategy` is to return the current strategy of the `DiscountedCfrTrainableHF` object.

**Code Description**: The `getcurrentStrategy` function simply calls the `getcurrentStrategyNoCache` function and returns its result. The `getcurrentStrategyNoCache` function is responsible for calculating the current strategy for the `DiscountedCfrTrainableHF` object. It iterates through the available actions and private cards, computes the `r_plus_sum` and `r_plus` values, and then sets the current strategy based on these values. The `getcurrentStrategy` function provides a convenient way to access the current strategy without having to call the more complex `getcurrentStrategyNoCache` function directly.\\
## Code: 
```
const vector<float> DiscountedCfrTrainableHF::getcurrentStrategy() {
    return this->getcurrentStrategyNoCache();
}
```