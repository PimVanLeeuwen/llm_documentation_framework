`startWorking`: The function of `startWorking` is to continuously read input lines from the command line and process them using the `processCommand` method.

**Code Description**: The `startWorking` method is part of the `CommandLineTool` class, which is responsible for handling user input and processing various commands related to a poker solver. The method enters a loop that continues as long as the standard input stream (`cin`) is valid. Within the loop, it reads a line of input using `getline(cin, input_line)` and then passes the input line to the `processCommand` method for further processing.

The `processCommand` method is responsible for interpreting the user's commands and performing the appropriate actions, such as setting game parameters, building the game tree, or running the solver. The implementation of the `processCommand` method is not provided in the given code snippet, but it is likely that it contains the core logic of the `CommandLineTool` class.

By continuously reading input lines and processing them, the `startWorking` method allows the user to interact with the poker solver through the command line interface. This can be useful for tasks such as configuring the solver, running simulations, or analyzing the results.\\
## Code: 
```
void CommandLineTool::startWorking() {
    string input_line;
    while(cin) {
        getline(cin, input_line);
        this->processCommand(input_line);
    };
}
```