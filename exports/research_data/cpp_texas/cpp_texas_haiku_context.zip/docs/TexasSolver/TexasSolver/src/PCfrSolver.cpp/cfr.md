`cfr`: The function of `cfr` is to recursively calculate the counterfactual regret minimization (CFR) values for a given game tree node in a Texas Hold'em poker game.

**Parameters**:
`int player`: The player whose perspective the CFR values are being calculated for.
`shared_ptr<GameTreeNode> node`: A shared pointer to the current game tree node being evaluated.
`const vector<float> &reach_probs`: A reference to a vector of reach probabilities for the current player and their opponent.
`int iter`: The current iteration of the CFR algorithm.
`uint64_t current_board`: The current state of the game board, represented as a 64-bit unsigned integer.
`int deal`: The current deal of the game (e.g., preflop, flop, turn, river).

**Code Description**:
The `cfr` function is a switch statement that handles different types of game tree nodes:

1. `GameTreeNode::ACTION`: If the current node is an `ActionNode`, the function calls `actionUtility` to calculate the CFR values for the available actions.
2. `GameTreeNode::SHOWDOWN`: If the current node is a `ShowdownNode`, the function calls `showdownUtility` to calculate the CFR values for the showdown.
3. `GameTreeNode::TERMINAL`: If the current node is a `TerminalNode`, the function calls `terminalUtility` to calculate the CFR values for the terminal node.
4. `GameTreeNode::CHANCE`: If the current node is a `ChanceNode`, the function calls `chanceUtility` to calculate the CFR values for the chance node.

The `cfr` function recursively calls itself on the child nodes of the current node, passing the appropriate parameters to the corresponding utility functions. This allows the CFR algorithm to propagate the regret values up the game tree and calculate the optimal strategy for the given game state.

The specific implementation details of the utility functions (`actionUtility`, `showdownUtility`, `terminalUtility`, and `chanceUtility`) are not provided in the given code snippet, but they likely perform the necessary calculations to determine the CFR values for the respective node types.\\
## Code: 
```
vector<float> PCfrSolver::cfr(int player, shared_ptr<GameTreeNode> node, const vector<float> &reach_probs, int iter,
                                    uint64_t current_board,int deal) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
            return actionUtility(player, action_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::SHOWDOWN: {
            shared_ptr<ShowdownNode> showdown_node = std::dynamic_pointer_cast<ShowdownNode>(node);
            return showdownUtility(player, showdown_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::TERMINAL: {
            shared_ptr<TerminalNode> terminal_node = std::dynamic_pointer_cast<TerminalNode>(node);
            return terminalUtility(player, terminal_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::CHANCE: {
            shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
            return chanceUtility(player, chance_node, reach_probs, iter, current_board,deal);
        }default:
            throw runtime_error("node type unknown");
    }
}
```