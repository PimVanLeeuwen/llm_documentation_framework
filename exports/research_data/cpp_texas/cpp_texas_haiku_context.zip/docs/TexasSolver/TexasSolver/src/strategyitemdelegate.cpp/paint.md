`paint`: The function of `paint` is to render the visual representation of a cell in a table-based strategy display.

**Parameters**:
`QPainter *painter`: This parameter is a pointer to the QPainter object, which is used to draw the cell's contents.
`const QStyleOptionViewItem &option`: This parameter contains the style options for the current view item, such as the cell's size, position, and state.
`const QModelIndex &index`: This parameter represents the index of the current cell in the underlying data model.

**Code Description**: The `paint` function performs the following tasks:

1. Saves the current painter state to restore it later.
2. Calculates the rectangle representing the cell's dimensions.
3. Sets the background color of the cell based on the column and row indices:
   - If the column and row indices are equal, the background is set to a dark gray color.
   - Otherwise, the background is set to a light gray color.
4. Checks the current mode of the `DetailWindowSetting` object and calls the appropriate painting method:
   - If the mode is `STRATEGY`, it calls the `paint_strategy` method to render the strategy visualization.
   - If the mode is `RANGE_IP` or `RANGE_OOP`, it calls the `paint_range` method to render the player's range.
   - If the mode is `EV`, it calls the `paint_strategy` method with an additional parameter to render the expected value (EV) information.
   - If the mode is `EV_ONLY`, it calls the `paint_evs` method to render the EV grid.
5. Restores the painter state to its previous state.

The `paint` function is responsible for rendering the visual representation of a cell in the table-based strategy display, based on the current mode and the underlying data. It uses various helper methods (`paint_strategy`, `paint_range`, `paint_evs`) to handle the specific rendering requirements for different display modes.\\
## Code: 
```
void StrategyItemDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {

    painter->save();

    QRect rect(option.rect.left(), option.rect.top(),\
             option.rect.width(), option.rect.height());
    QBrush brush(Qt::gray);
    if(index.column() == index.row())brush = QBrush(Qt::darkGray);
    painter->fillRect(rect, brush);

    if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::STRATEGY){
        this->paint_strategy(painter,option,index);
    }
    else if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP ||
            this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_OOP ){
        this->paint_range(painter,option,index);
    }
    else if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::EV){
        this->paint_strategy(painter,option,index,true);
    }
    else if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::EV_ONLY){
        this->paint_evs(painter,option,index);
    }

    painter->restore();
}
```