`RiverRangeManager`: The function of `RiverRangeManager` is to initialize and manage the `Compairer` object and a `std::mutex` object.

**Parameters**:
`shared_ptr<Compairer> handEvaluator`: This parameter is a shared pointer to a `Compairer` object, which is used to evaluate poker hands. The `Compairer` object is moved into the `RiverRangeManager` object using `std::move()`.

**Code Description**:
The `RiverRangeManager` constructor takes a `shared_ptr<Compairer>` object as a parameter and initializes the `handEvaluator` member variable with the provided `Compairer` object. It also creates a new `std::mutex` object and stores a shared pointer to it in the `maplock` member variable.

The purpose of this code is to set up the necessary components for the `RiverRangeManager` class to function. The `Compairer` object is used to evaluate poker hands, and the `std::mutex` object is likely used to provide thread-safe access to shared resources within the `RiverRangeManager` class.\\
## Code: 
```
RiverRangeManager::RiverRangeManager(shared_ptr<Compairer> handEvaluator) {
    this->handEvaluator = std::move(handEvaluator);
    this->maplock = std::make_shared<std::mutex>();
}
```