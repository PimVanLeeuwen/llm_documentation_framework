`eventFilter`: The function of `eventFilter` is to handle various mouse events that occur on the `HtmlTableRangeView` widget.

**Parameters**:
`QObject *watched`: The object that triggered the event being filtered.
`QEvent *event`: The event object that contains information about the event that occurred.

**Code Description**:
The `eventFilter` function checks the type of the event that occurred and performs different actions based on the event type:

1. If the event is a `QEvent::MouseButtonPress`, it checks if the event occurred on the viewport of the `HtmlTableRangeView`. If so, it retrieves the model index of the cell where the mouse was clicked and updates the `mouseTracker` object with the row and column indices of the pressed cell.

2. If the event is a `QEvent::MouseMove`, it again checks if the event occurred on the viewport. If so, it retrieves the model index of the cell where the mouse is currently positioned and compares it with the last recorded position. If the position has changed, it emits a `view_item_area` signal, passing the row and column indices of the pressed cell and the current cell.

3. If the event is a `QEvent::MouseButtonRelease`, it checks if the event occurred on the viewport. If so, it retrieves the model index of the cell where the mouse was released and emits an `item_release` signal, passing the row and column indices of the released cell.

4. If the event is a `QEvent::Leave`, it sets the `tracking` flag of the `mouseTracker` object to `false`.

Finally, the function calls the `eventFilter` function of the base class (`QTableView`) to allow the parent class to handle any remaining events.

The purpose of this `eventFilter` function is to provide custom mouse event handling for the `HtmlTableRangeView` widget, allowing it to track mouse button presses, movements, and releases, and emit signals to notify other parts of the application about these events.\\
## Code: 
```
bool HtmlTableRangeView::eventFilter(QObject *watched, QEvent *event){
    if(viewport() == watched){
        if(event->type() == QEvent::MouseButtonPress){
            QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
            QModelIndex index = indexAt(mouseEvent->pos());
            if(index.isValid()){
                int i = index.row();
                int j = index.column();
                mouseTracker.tracking = true;
                mouseTracker.pressed_i = i;
                mouseTracker.pressed_j = j;
            }
        }
        else if(event->type() == QEvent::MouseMove){
            QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
            QModelIndex index = indexAt(mouseEvent->pos());
            if(index.isValid()){
                int i = index.row();
                int j = index.column();
                if(i != this->last_bearing_i || j != last_bearing_j){
                    this->last_bearing_i = i;
                    this->last_bearing_j = j;
                    if(mouseTracker.tracking == true){
                        emit view_item_area(mouseTracker.pressed_i,mouseTracker.pressed_j,i,j);
                    }
                }
            }
        }
        else if(event->type() == QEvent::MouseButtonRelease){
            QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
            QModelIndex index = indexAt(mouseEvent->pos());
            if(index.isValid()){
                int i = index.row();
                int j = index.column();
                mouseTracker.tracking = false;
                emit item_release(i,j);
            }
        }
        else if(event->type() == QEvent::Leave){
                mouseTracker.tracking = false;
        }else{

        }
    }
    return QTableView::eventFilter(watched, event);
}
```