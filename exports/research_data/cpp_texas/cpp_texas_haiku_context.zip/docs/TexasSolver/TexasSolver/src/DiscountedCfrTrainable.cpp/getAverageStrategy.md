`getAverageStrategy`: The function of `getAverageStrategy` is to calculate the average strategy for each action and private card combination in the game.

**Code Description**: The `getAverageStrategy` function is a method of the `DiscountedCfrTrainable` class. It calculates the average strategy for each action and private card combination by iterating through the `cum_r_plus` vector, which stores the cumulative rewards for each action and private card combination.

The function first initializes an empty `average_strategy` vector with a size equal to the product of the number of actions and the number of private cards. It then iterates through each private card, calculating the sum of the cumulative rewards for all actions for that private card (`r_plus_sum`). For each action and private card combination, it then calculates the average strategy by dividing the cumulative reward for that combination by the `r_plus_sum`. If the `r_plus_sum` is zero, it sets the average strategy to 1/action_number, which is the uniform distribution.

Finally, the function returns the `average_strategy` vector, which contains the calculated average strategy for each action and private card combination.\\
## Code: 
```
const vector<float> DiscountedCfrTrainable::getAverageStrategy() {
    vector<float> average_strategy;
    average_strategy = vector<float>(this->action_number * this->card_number);
    for (int private_id = 0; private_id < this->card_number; private_id++) {
        float r_plus_sum = 0;
        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            r_plus_sum += this->cum_r_plus[index];
        }

        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            if(r_plus_sum) {
                average_strategy[index] = this->cum_r_plus[index] / r_plus_sum;
            }else{
                average_strategy[index] = 1.0 / this->action_number;
            }
        }
    }
    return average_strategy;
}
```