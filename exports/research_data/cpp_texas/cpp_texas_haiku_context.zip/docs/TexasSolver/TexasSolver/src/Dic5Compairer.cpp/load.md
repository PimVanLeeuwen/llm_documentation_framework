`load`: The function of `load` is to load data from a file specified by the `file_path` parameter and store it in two separate maps, `flush_map` and `other_map`.

**Parameters**:
`const char* file_path`: This parameter specifies the file path of the file to be loaded.

**Code Description**:
The `load` function first attempts to open the file specified by the `file_path` parameter using the `QFile` class. If the file cannot be opened, it throws a `runtime_error` exception with the message "unable to load compairer file".

Once the file is successfully opened, the function clears the `flush_map` and `other_map` maps. It then reads the number of entries in the file, which is stored in the `cnt` variable. The function then reads the key-value pairs from the file and stores them in the respective maps.

The key for each entry is a 64-bit unsigned integer (`uint64_t`), and the value is a 32-bit integer (`int`). The function uses pointers to read the data directly from the file into the appropriate variables.

After reading all the entries, the function verifies that the number of entries read matches the expected count stored in the `cnt` variable. Finally, the function closes the file and returns `true` to indicate that the loading was successful.\\
## Code: 
```
bool FiveCardsStrength::load(const char* file_path) {
    //ifstream file(file_path, ios::binary);
    /*if (!file) {
        file.close();
        return false;
    }*/

    QFile file(QString::fromStdString(file_path));
    if (!file.open(QIODevice::ReadOnly)){
        throw runtime_error("unable to load compairer file");
    }
    flush_map.clear(); other_map.clear();
    int size_key = sizeof(uint64_t), size_int = sizeof(int), val, cnt = 0;
    uint64_t key = 0;
    char* p_key = (char*)&key, * p_val = (char*)&val, * p_cnt = (char*)&cnt;
    file.read(p_cnt, size_int);// 读取行数
    for (int i = 0; i < cnt; i++) {
        file.read(p_key, size_key);
        file.read(p_val, size_int);
        flush_map[key] = val;
    }
    assert(flush_map.size() == cnt);
    file.read(p_cnt, size_int);// 读取行数
    for (int i = 0; i < cnt; i++) {
        file.read(p_key, size_key);
        file.read(p_val, size_int);
        other_map[key] = val;
    }
    assert(other_map.size() == cnt);
    file.close();
    return true;
}
```