`toBoardLong`: The function of `toBoardLong` is to return the `board_long` member variable of the `PrivateCards` class.

**Code Description**: The `toBoardLong` function is a method of the `PrivateCards` class. It simply returns the value of the `board_long` member variable, which is likely a 64-bit integer representation of the player's board or hand. The commented-out line `return Card::boardInts2long(this->card_vec);` suggests that there may be an alternative implementation that converts a vector of card objects (`this->card_vec`) into a 64-bit long integer representation, but the current implementation just returns the `board_long` member variable directly.\\
## Code: 
```
uint64_t PrivateCards::toBoardLong() {
    return this->board_long;
    //return Card::boardInts2long(this->card_vec);
}
```