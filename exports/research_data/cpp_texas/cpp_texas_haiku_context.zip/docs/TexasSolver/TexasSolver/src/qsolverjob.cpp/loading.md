`loading`: The function of `loading` is to initialize the necessary data structures and resources required for the Texas Hold'em and Short Deck poker game solvers.

**Code Description**:

1. The function starts by defining the suit and rank strings for the standard 52-card deck and the Short Deck (9-high) variant.
2. It sets the `resource_dir` variable to the location of the resource files, which are assumed to be in the `:/resources` directory.
3. The function then proceeds to load the necessary files for the Texas Hold'em solver:
   - It sets the `compairer_file` and `compairer_file_bin` variables to the paths of the card comparison files for the 5-card hand comparisons.
   - It sets the `lines` variable to the number of lines in the card comparison file (2,598,961 for the Texas Hold'em variant).
   - It creates a `PokerSolver` object (`ps_holdem`) using the provided rank, suit, comparison file, and line count parameters.
4. Next, the function loads the necessary files for the Short Deck solver:
   - It sets the `compairer_file` and `compairer_file_bin` variables to the paths of the card comparison files for the 5-card hand comparisons in the Short Deck variant.
   - It sets the `lines` variable to the number of lines in the card comparison file (376,993 for the Short Deck variant).
   - It creates a `PokerSolver` object (`ps_shortdeck`) using the provided rank, suit, comparison file, and line count parameters.
5. Finally, the function prints a message to the console indicating that the loading process has finished and the system is ready to go.

The main purpose of this function is to set up the necessary data structures and resources required for the Texas Hold'em and Short Deck poker game solvers. It loads the card comparison files, which are used to efficiently compare and rank 5-card poker hands, and creates the `PokerSolver` objects that will be used throughout the application.\\
## Code: 
```
void QSolverJob::loading(){
    string suits = "c,d,h,s";
    string ranks;
    this->resource_dir =  ":/resources";
    string compairer_file, compairer_file_bin;
    int lines;
    qDebug().noquote() << tr("Loading holdem compairing file");//.toStdString() << endl;
    //if(mode == "holdem"){
    ranks = "2,3,4,5,6,7,8,9,T,J,Q,K,A";
    compairer_file = this->resource_dir + "/compairer/card5_dic_sorted.txt";
    compairer_file_bin = this->resource_dir + "/compairer/card5_dic_zipped.bin";
    //qDebug().noquote() << compairer_file_bin.c_str();
    lines = 2598961;
    this->ps_holdem = PokerSolver(ranks,suits,compairer_file,lines,compairer_file_bin);

    qDebug().noquote() << tr("Loading shortdeck compairing file");//.toStdString() << endl;
    //}else if(mode == "shortdeck"){
    ranks = "6,7,8,9,T,J,Q,K,A";
    compairer_file = this->resource_dir + "/compairer/card5_dic_sorted_shortdeck.txt";
    compairer_file_bin = this->resource_dir + "/compairer/card5_dic_zipped_shortdeck.bin";
    lines = 376993;
    this->ps_shortdeck = PokerSolver(ranks,suits,compairer_file,lines,compairer_file_bin);
    qDebug().noquote() << tr("Loading finished. Good to go.");//.toStdString() << endl;
}
```