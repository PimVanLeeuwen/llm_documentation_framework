`load_game_tree`: The function of `load_game_tree` is to load a game tree from a file and store it in the `PokerSolver` object.

**Parameters**:
`string game_tree_file`: This parameter specifies the file path of the game tree file to be loaded.

**Code Description**: The `load_game_tree` function creates a new `GameTree` object using the `game_tree_file` parameter and the `deck` member of the `PokerSolver` object. The `make_shared` function is used to create a shared pointer to the new `GameTree` object, which is then stored in the `game_tree` member of the `PokerSolver` object.

The `GameTree` class is responsible for loading and managing the game tree data structure, which represents the possible game states and actions in a poker game. The `GameTree` constructor likely reads the game tree data from the specified file and builds the game tree data structure.

By loading the game tree into the `PokerSolver` object, the `load_game_tree` function provides the `PokerSolver` with the necessary information to perform various poker-related calculations and analyses.\\
## Code: 
```
void PokerSolver::load_game_tree(string game_tree_file) {
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(game_tree_file,this->deck);
    this->game_tree = game_tree;
}
```