`PokerSolver`: The function of `PokerSolver` is to initialize a `PokerSolver` object with the necessary data to compare and evaluate poker hands.

**Parameters**:
`string ranks`: A comma-separated string of the valid ranks for the poker cards (e.g., "2,3,4,5,6,7,8,9,T,J,Q,K,A").
`string suits`: A comma-separated string of the valid suits for the poker cards (e.g., "c,d,h,s").
`string compairer_file`: The file path to a file containing a dictionary of 5-card poker hand rankings.
`int compairer_file_lines`: The number of lines in the `compairer_file`.
`string compairer_file_bin`: The file path to a binary file containing the pre-computed poker hand rankings.

**Code Description**:
The `PokerSolver` constructor performs the following tasks:
1. Splits the `ranks` and `suits` strings into separate vectors using the `string_split` function.
2. Creates a `Deck` object using the `ranks_vector` and `suits_vector` to represent the deck of cards.
3. Creates a `Dic5Compairer` object using the `compairer_file`, `compairer_file_lines`, and `compairer_file_bin` parameters. The `Dic5Compairer` class is responsible for loading and processing the dictionary of 5-card poker hand rankings.

The `PokerSolver` class is likely used to perform various poker-related operations, such as evaluating the strength of poker hands, comparing hands, or determining the winning hand in a game. The `Deck` and `Dic5Compairer` objects are used to facilitate these operations.\\
## Code: 
```
PokerSolver::PokerSolver(string ranks, string suits, string compairer_file,int compairer_file_lines, string compairer_file_bin) {
    vector<string> ranks_vector = string_split(ranks,',');
    vector<string> suits_vector = string_split(suits,',');
    this->deck = Deck(ranks_vector,suits_vector);
    this->compairer = make_shared<Dic5Compairer>(compairer_file,compairer_file_lines,compairer_file_bin);
}
```