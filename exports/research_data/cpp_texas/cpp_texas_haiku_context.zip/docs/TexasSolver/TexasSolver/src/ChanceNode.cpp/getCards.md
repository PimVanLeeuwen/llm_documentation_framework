`getCards`: The function of `getCards` is to return a reference to the `cards` vector stored within the `ChanceNode` object.

**Code Description**: The `getCards` method is a member function of the `ChanceNode` class. It returns a constant reference to the `cards` vector, which is a private member variable of the `ChanceNode` class. This allows other parts of the code to access the `cards` vector associated with the `ChanceNode` object without modifying it directly.\\
## Code: 
```
const vector<Card>& ChanceNode::getCards() {
    return this->cards;
}
```