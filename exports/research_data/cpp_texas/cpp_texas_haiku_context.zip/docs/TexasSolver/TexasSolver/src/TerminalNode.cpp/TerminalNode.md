`TerminalNode`: The function of `TerminalNode` is to represent a terminal node in a game tree, which is the final state of a game.

**Parameters**:
`vector<double> payoffs`: This parameter represents the payoffs for each player at the terminal node. It is a vector of double values, where each value corresponds to the payoff for a specific player.
`int winner`: This parameter represents the index of the player who won the game at the terminal node.
`GameTreeNode::GameRound round`: This parameter represents the current round of the game at the terminal node.
`double pot`: This parameter represents the current pot size at the terminal node.
`shared_ptr<GameTreeNode> parent`: This parameter represents a shared pointer to the parent node of the terminal node in the game tree.

**Code Description**: The `TerminalNode` class is a derived class of the `GameTreeNode` class, which represents a node in a game tree. The `TerminalNode` class is responsible for storing the final state of a game, including the payoffs for each player, the winner, the current round, the pot size, and a reference to the parent node.

The constructor of the `TerminalNode` class takes in these parameters and initializes the corresponding member variables. The `payoffs` vector stores the payoffs for each player, the `winner` variable stores the index of the player who won the game, the `round` variable stores the current round of the game, the `pot` variable stores the current pot size, and the `parent` variable stores a shared pointer to the parent node of the terminal node.

This `TerminalNode` class is likely used in a game-playing algorithm, such as a game tree search algorithm, to represent the final state of a game and to store the relevant information about the game's outcome.\\
## Code: 
```
TerminalNode::TerminalNode(vector<double> payoffs, int winner, GameTreeNode::GameRound round, double pot,
                           shared_ptr<GameTreeNode> parent):GameTreeNode(round,pot,parent){
    this->payoffs = payoffs;
    this->winner = winner;
}
```