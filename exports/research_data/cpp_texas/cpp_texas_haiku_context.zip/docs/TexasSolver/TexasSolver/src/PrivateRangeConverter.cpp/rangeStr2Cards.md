`rangeStr2Cards`: The function of `rangeStr2Cards` is to convert a string representation of a poker hand range into a vector of `PrivateCards` objects, which represent the possible private card combinations for that range.

**Parameters**:
`string range_str`: This parameter represents the string representation of the poker hand range. The range can be specified using a variety of formats, including suited and offsuit combinations, as well as individual card combinations.
`vector<int> initial_boards`: This parameter represents a vector of integer values representing the community cards on the board. The function uses this information to exclude any private card combinations that would be invalid given the current board.

**Code Description**:
The function first splits the `range_str` parameter into a vector of individual range strings, using the `string_split` function. It then iterates over each of these individual range strings and processes them to create `PrivateCards` objects.

The function supports several different formats for the range strings:
1. Three-character strings, where the first two characters represent the rank of the cards and the third character represents the suit relationship (either "s" for suited or "o" for offsuit).
2. Two-character strings, where the two characters represent the rank of the cards, and the function generates all possible suit combinations.

For each valid range string, the function creates a `PrivateCards` object with the appropriate card IDs and weight. It then checks if the generated private card combination would be invalid given the current board, and if so, skips it.

Finally, the function removes any duplicate private card combinations from the resulting vector and returns it.

The code also includes some error handling, such as throwing exceptions for invalid range string formats or duplicate card combinations.\\
## Code: 
```
vector<PrivateCards> PrivateRangeConverter::rangeStr2Cards(string range_str, vector<int> initial_boards) {
    vector<string> range_list = string_split(range_str,',');
    vector<PrivateCards> private_cards;

    for(string one_range:range_list){
        PrivateCards this_card;
        vector<string> cardstr_arr = string_split(one_range,':');
        if (cardstr_arr.size() > 2 || cardstr_arr.empty()){
            throw runtime_error("':' number exceeded 2");
        }
        float weight = 1;

        one_range = cardstr_arr[0];
        if(cardstr_arr.size() == 2){
            weight = atof(cardstr_arr[1].c_str());
        }
        if(weight <= 0.005){
            continue;
        }

        int range_len = one_range.length();
        // TODO finish here , convert str to a PrivateRanges[]
        if(range_len == 3){
            if(one_range.at(2) == 's'){
                char rank1 = one_range.at(0);
                char rank2 = one_range.at(1);
                if(rank1 == rank2) throw runtime_error(tfm::format("%s%ss is not a valid card desc",rank1,rank2));
                for(const string& one_suit :Card::getSuits()){
                    int card1 = Card::strCard2int(rank1 + one_suit);
                    int card2 = Card::strCard2int(rank2 + one_suit);
                    this_card = PrivateCards(card1,card2,weight);
                    private_cards.push_back(this_card);
                }

            }else if(one_range.at(2) == 'o'){
                char rank1 = one_range.at(0);
                char rank2 = one_range.at(1);

                vector<string> suits = Card::getSuits();
                for(std::size_t i = 0;i < suits.size();i++){
                    string one_suit = suits[i];
                    int begin_index = rank1 == rank2 ? i:0;
                    for(std::size_t j = begin_index;j < suits.size();j++){
                        string another_suit = suits[j];
                        if(one_suit == another_suit){
                            continue;
                        }
                        int card1 = Card::strCard2int(rank1 + one_suit);
                        int card2 = Card::strCard2int(rank2 + another_suit);
                        if(Card::boardsHasIntercept(
                                Card::boardInts2long(vector<int>{card1,card2}),
                                Card::boardInts2long(initial_boards)
                        )){
                            continue;
                        }
                        this_card = PrivateCards(card1, card2, weight);
                        private_cards.push_back(this_card);
                    }
                }
            }else{
                throw runtime_error("format not recognize");
            }
        }else if(range_len == 2){
            char rank1 = one_range.at(0);
            char rank2 = one_range.at(1);
            vector<string> suits = Card::getSuits();
            for(std::size_t i = 0;i < suits.size();i++){
                string one_suit = suits[i];
                int begin_index = rank1 == rank2 ? i:0;
                for(std::size_t j = begin_index;j < suits.size();j++){
                    string another_suit = suits[j];
                    if(one_suit == another_suit && rank1 == rank2){
                        continue;
                    }
                    int card1 = Card::strCard2int(rank1 + one_suit);
                    int card2 = Card::strCard2int(rank2 + another_suit);
                    if(Card::boardsHasIntercept(
                            Card::boardInts2long(vector<int>{card1,card2}),
                            Card::boardInts2long(initial_boards)
                    )){
                        continue;
                    }
                    this_card = PrivateCards(card1, card2, weight);
                    private_cards.push_back(this_card);
                }
            }

        }else throw runtime_error(tfm::format(" range str %s len not valid ",one_range));
    }

    // 排除初试range中重复的情况
    for(std::size_t i = 0;i < private_cards.size();i ++){
        for(std::size_t j = i + 1;j < private_cards.size();j ++) {
            PrivateCards one_cards = private_cards[i];
            PrivateCards another_cards = private_cards[j];
            if (one_cards.card1 == another_cards.card1 && one_cards.card2 == another_cards.card2){
                throw runtime_error(tfm::format("card %s %s duplicate"
                        , Card::intCard2Str(one_cards.card1)
                        , Card::intCard2Str(one_cards.card2)
                ));
            }
            if(one_cards.card1 == another_cards.card2 && one_cards.card2 == another_cards.card1) {
                throw runtime_error(tfm::format("card %s %s duplicate"
                        , Card::intCard2Str(one_cards.card1)
                        , Card::intCard2Str(one_cards.card2)
                ));
            }
        }
    }

    vector<PrivateCards> private_cards_list(private_cards.size());
    for(std::size_t i = 0;i < private_cards.size();i ++){
        private_cards_list[i] = private_cards[i];
        //System.out.print(String.format("[%s-%s]",Card.intCard2Str(private_cards_list[i].card1),Card.intCard2Str(private_cards_list[i].card2)));
    }
    /*
        output all private combos

    System.out.println("private range number:");
    System.out.println(private_cards.size());
    System.out.println();
     */
    return private_cards_list;

}
```