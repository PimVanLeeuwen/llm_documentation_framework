`get_ev_grid`: The function of `get_ev_grid` is to calculate the expected value (EV) grid for a given set of strategies in the `TableStrategyModel` class.

**Parameters**:
`int i`: The row index of the strategy table.
`int j`: The column index of the strategy table.

**Code Description**:
The `get_ev_grid` function first checks if the `treeItem` and `current_evs` member variables are not null and not empty, respectively. If either of these conditions is not met, the function returns an empty vector.

Next, the function retrieves the number of strategies for the given row and column indices from the `ui_strategy_table` member variable. It then gets the `GameTreeNode` object associated with the current state of the game tree.

If the `GameTreeNode` is of type `ACTION`, the function casts it to an `ActionNode` object and retrieves the list of `GameActions` associated with that node. It then iterates through the indices in the `ui_strategy_table` for the given row and column, and for each index, it calculates the expected value (EV) of the corresponding strategy.

The EV is calculated by iterating through the strategy vector and multiplying each strategy value with the corresponding EV value from the `current_evs` member variable. The resulting EV is then added to the `ret_evs` vector, which is returned by the function.

If the `GameTreeNode` is not of type `ACTION`, the function simply returns an empty `ret_evs` vector.

The `get_ev_grid` function is used to calculate the expected values for a set of strategies in the `TableStrategyModel` class, which is likely part of a larger poker or game-playing application. The function allows the application to evaluate the expected outcomes of different strategies and make informed decisions about the best course of action.\\
## Code: 
```
const vector<float> TableStrategyModel::get_ev_grid(int i,int j)const{
    vector<float> ret_evs;
    if(this->treeItem == NULL || this->current_evs.empty())return ret_evs;

    int strategy_number = this->ui_strategy_table[i][j].size();

    shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();

    if(node->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);

        vector<GameActions>& gameActions = actionNode->getActions();

//        vector<float> strategies;

//        if(this->ui_strategy_table[i][j].size() > 0){
//            strategies = vector<float>(gameActions.size());
//            std::fill(strategies.begin(), strategies.end(), 0.);
//        }
        for(std::pair<int,int> index:this->ui_strategy_table[i][j]){
            int index1 = index.first;
            int index2 = index.second;
            const vector<float>& one_strategy = this->current_strategy[index1][index2];
            const vector<float>& one_ev = this->current_evs[index1][index2];
            if(one_ev.size() != one_strategy.size()) return vector<float>();

            if(gameActions.size() != one_strategy.size()){
                cout << "index: " << index1 << " " << index2 << endl;
                cout << "i,j: " << i << " " << j << endl;
                cout << "size not match between gameAction and stragegy: " << gameActions.size() << " " << one_strategy.size() << endl;
                throw runtime_error("size not match between gameAction and stragegy");
            }
            float one_ev_float = 0;
            for(std::size_t indi = 0;indi < one_strategy.size();indi ++){
                one_ev_float += one_strategy[indi] * one_ev[indi];
            }
            ret_evs.push_back(one_ev_float);
        }

        return ret_evs;
    }else{
        return ret_evs;
    }
}
```