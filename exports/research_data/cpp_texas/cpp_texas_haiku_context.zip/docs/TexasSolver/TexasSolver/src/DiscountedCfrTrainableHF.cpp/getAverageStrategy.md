`getAverageStrategy`: The function of `getAverageStrategy` is to calculate the average strategy for a given set of actions and cards.

**Code Description**: The `getAverageStrategy` method is part of the `DiscountedCfrTrainableHF` class. It calculates the average strategy for a given set of actions and cards.

The method first initializes a vector `average_strategy` with a size equal to the product of the number of actions and the number of cards. It then iterates through each card and calculates the average strategy for each action-card pair.

For each card, the method first calculates the sum of the cumulative rewards (`cum_r_plus`) for all actions. It then divides the cumulative reward for each action-card pair by the sum of the cumulative rewards to get the average strategy for that action-card pair.

If the sum of the cumulative rewards is zero, the method assigns an equal probability (1/action_number) to each action-card pair.

Finally, the method returns the `average_strategy` vector, which contains the calculated average strategy for all action-card pairs.\\
## Code: 
```
const vector<float> DiscountedCfrTrainableHF::getAverageStrategy() {
    vector<float> average_strategy;
    average_strategy = vector<float>(this->action_number * this->card_number);
    for (int private_id = 0; private_id < this->card_number; private_id++) {
        float r_plus_sum = 0;
        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            average_strategy[index] = this->cum_r_plus[index];
            r_plus_sum += average_strategy[index];
        }

        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            if(r_plus_sum) {
                // we stored this->cum_r_plus[index] in average_strategy[index] above
                // this is to avoid converting from half float twice
                average_strategy[index] = average_strategy[index] / r_plus_sum;
            }else{
                average_strategy[index] = 1.0 / this->action_number;
            }
        }
    }
    return average_strategy;
}
```