`toString`: The function of `toString` is to generate a string representation of the current `GameTreeNode` object.

**Code Description**:
The `toString()` method is a member function of the `GameTreeNode` class. It is responsible for generating a string representation of the current `GameTreeNode` object, which can be useful for debugging or logging purposes.

The method first checks if the current node has a parent node. If the parent node is `nullptr`, it means the current node is the root node, and the method returns a string in the format `"%s begin"`, where `%s` is replaced with the value of the `round` variable (which is not defined in the provided code).

If the parent node is not `nullptr`, the method checks the type of the parent node. If the parent node is an `ActionNode`, the method iterates through the actions associated with the parent node and checks if the current node is one of the children of the parent node. If so, it prints a string in the format `"<- (player %s %s)"`, where `%s` is replaced with the player and the action associated with the current node.

If the parent node is a `ChanceNode`, the method iterates through the cards associated with the parent node and checks if the current node is one of the children of the parent node. If so, it prints a string in the format `"<- (deal card %s)"`, where `%s` is replaced with the card associated with the current node.

The method then returns an empty string `""`. It's worth noting that the commented-out code in the provided `toString()` method is not executed, and the method does not actually generate any meaningful string representation of the `GameTreeNode` object.\\
## Code: 
```
string GameTreeNode::toString(){
    /*
    shared_ptr<GameTreeNode>parent_node = node->parent;
    string round;
    if (parent_node == nullptr) return tfm::format("%s begin",round);
    if(parent_node->getType() == GameTreeNodeType::ACTION){
        ActionNode action_node = (ActionNode)parent_node;
        for(int i = 0;i < action_node.getActions().size();i ++){
            if(action_node.getChildrens().get(i) == node){
                System.out.print(String.format("<- (player %s %s)",
                           action_node.getPlayer(),
                           action_node.getActions().get(i).toString()
                    ));
        }
        }
    }else if(parent_node->getType() == GameTreeNodeType::CHANCE){
        ChanceNode chance_node = (ChanceNode)parent_node;
        for(int i = 0;i < chance_node.getChildrens().size();i ++){
            if(chance_node.getChildrens().get(i) == node){
                System.out.print(String.format("<- (deal card %s)",
                       chance_node.getCards().get(i).toString()
            ));
        }
    }
    */
    return "";
}
```