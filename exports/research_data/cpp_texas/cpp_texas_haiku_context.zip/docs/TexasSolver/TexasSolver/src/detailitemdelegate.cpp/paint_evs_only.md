`paint_evs_only`: The function of `paint_evs_only` is to paint the expected value (EV) of each strategy in a grid-based user interface (UI) for a Texas Hold'em poker game.

**Parameters**:
`QPainter *painter`: This parameter is a pointer to a QPainter object, which is used to draw the UI elements on the screen.
`const QStyleOptionViewItem &option`: This parameter contains the style options for the current view item, which are used to determine the appearance of the UI elements.
`const QModelIndex &index`: This parameter represents the index of the current cell in the UI grid, which is used to retrieve the corresponding strategy and EV information.

**Code Description**:
The function first initializes the style options for the current view item using the `initStyleOption` function. It then checks if the current tree item in the `TableStrategyModel` is an action node. If so, it retrieves the strategy number and the EV values for the current grid position.

For each cell in the grid, the function calculates a normalized EV value using the `normalization_tanh` function, which applies a hyperbolic tangent normalization to the EV value. It then uses this normalized EV value to determine the background color of the cell, with higher EV values being displayed in green and lower EV values being displayed in red.

The function then retrieves the card values corresponding to the current strategy and formats them as HTML-formatted strings using the `toFormattedHtml` function. It also adds the EV value as a formatted HTML string to the cell.

Finally, the function creates a QTextDocument object with the formatted HTML text and draws it on the painter using the `drawContents` function, clipping the content to the size of the current cell.

Overall, the `paint_evs_only` function is responsible for rendering the EV values and strategy information in a grid-based UI for a Texas Hold'em poker game, using a combination of custom formatting and color-coding to provide a clear and intuitive visualization of the game's strategy.\\
## Code: 
```
void DetailItemDelegate::paint_evs_only(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);

    const DetailViewerModel * detailViewerModel = qobject_cast<const DetailViewerModel*>(index.model());
    //vector<pair<GameActions,float>> strategy = detailViewerModel->tableStrategyModel->get_strategy(this->detailWindowSetting->grid_i,this->detailWindowSetting->grid_j);
    options.text = "";

    if(detailViewerModel->tableStrategyModel->treeItem != NULL &&
            detailViewerModel->tableStrategyModel->treeItem->m_treedata.lock()->getType() == GameTreeNode::GameTreeNode::ACTION){

        shared_ptr<GameTreeNode> node = detailViewerModel->tableStrategyModel->treeItem->m_treedata.lock();
        int strategy_number = 0;
        if(this->detailWindowSetting->grid_i >= 0 && this->detailWindowSetting->grid_j >= 0){
           strategy_number = detailViewerModel->tableStrategyModel->ui_strategy_table[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j].size();
        }

        vector<float> evs = detailViewerModel->tableStrategyModel->get_ev_grid(this->detailWindowSetting->grid_i,this->detailWindowSetting->grid_j);
        std::size_t ind = index.row() * detailViewerModel->columns + index.column();

        if(ind < evs.size() and ind < strategy_number)
        {
            float one_ev = evs[ind];
            float normalized_ev = normalization_tanh(detailViewerModel->tableStrategyModel->get_solver()->stack,one_ev);
            //options.text += QString("</br>%1").arg(QString::number(normalized_ev));

            pair<int,int> strategy_ui_table = detailViewerModel->tableStrategyModel->ui_strategy_table[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j][ind];
            int card1 = strategy_ui_table.first;
            int card2 = strategy_ui_table.second;

            int red = max((int)(255 - normalized_ev * 255),0);
            int green = min((int)(normalized_ev * 255),255);
            int blue = min(red, green);
            QBrush brush = QBrush(QColor(red,green,blue));

            // draw background for flod
            QRect rect(option.rect.left(), option.rect.top(),
             option.rect.width(), option.rect.height());
            painter->fillRect(rect, brush);

            options.text = "";
            options.text += detailViewerModel->tableStrategyModel->cardint2card[card1].toFormattedHtml();
            options.text += detailViewerModel->tableStrategyModel->cardint2card[card2].toFormattedHtml();
            options.text = "<h2>" + options.text + "<\/h2>";

            options.text +=  QString(" <h2>%1<\/h2>").arg(QString::number(one_ev,'f',3));
        }
    }

    QTextDocument doc;
    doc.setHtml(options.text);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```