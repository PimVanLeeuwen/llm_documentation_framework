`paint`: The function of `paint` is to draw the contents of a table cell in a table view.

**Parameters**:
`QPainter *painter`: This parameter is a pointer to a QPainter object, which is used to perform the actual drawing operations on the table cell.
`const QStyleOptionViewItem &option`: This parameter contains the style options for the table cell, such as the background color, font, and other visual properties.
`const QModelIndex &index`: This parameter represents the index of the table cell in the underlying data model.

**Code Description**:
The `paint` function performs the following tasks:
1. Saves the current painter state using `painter->save()`.
2. Initializes the `options` variable by copying the `option` parameter and calling `initStyleOption()` to set the default style options.
3. Creates a `QRect` object representing the full area of the table cell.
4. Fills the entire cell area with a gray background color using `painter->fillRect()`.
5. Retrieves the value of the current cell from the `boardSelectorTableModel` using the `getBoardAt()` method.
6. Calculates the height of the "disabled" portion of the cell based on the complement of the retrieved cell value (1 - cell value).
7. Creates a new `QRect` object representing the "enabled" portion of the cell, which is the remaining height after subtracting the "disabled" height.
8. Fills the "enabled" portion of the cell with a yellow background color using `painter->fillRect()`.
9. Creates a `QTextDocument` object and sets its HTML content using the `Card` class's `toFormattedHtml()` method.
10. Translates the painter to the top-left corner of the cell's rectangle.
11. Creates a clipping rectangle the size of the cell and draws the contents of the `QTextDocument` object using `doc.drawContents()`.
12. Restores the painter state using `painter->restore()`.

The overall purpose of this code is to provide a custom rendering of the table cells in a table view, where the cell's appearance is determined by the value retrieved from the `boardSelectorTableModel`. The cell is divided into two parts: a "disabled"\\
## Code: 
```
void BoardSelectorTableDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const{

    painter->save();
    auto options = option;
    initStyleOption(&options, index);

    QRect rect(option.rect.left(), option.rect.top(),\
             option.rect.width(), option.rect.height());
    QBrush brush(Qt::gray);
    painter->fillRect(rect, brush);

    float board_float = this->boardSelectorTableModel->getBoardAt(index.row(),index.column());

    float fold_prob = 1 - board_float;
    int disable_height = (int)(fold_prob * option.rect.height());
    int remain_height = option.rect.height() - disable_height;

    rect = QRect(option.rect.left(), option.rect.top() + disable_height,\
     option.rect.width(), remain_height);
    brush = QBrush(Qt::yellow);
    painter->fillRect(rect, brush);

    QTextDocument doc;
    doc.setHtml(Card(options.text.toStdString()).toFormattedHtml());

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
    painter->restore();
}
```