`get_strategy`: The function of `get_strategy` is to retrieve the strategy for a given game state, represented by the indices `i` and `j`.

**Parameters**:
`int i`: The row index of the game state in the `ui_strategy_table`.
`int j`: The column index of the game state in the `ui_strategy_table`.

**Code Description**:
The `get_strategy` function first checks if the `treeItem` member variable is `NULL`. If it is, the function returns an empty vector of `pair<GameActions, float>`.

If the `treeItem` is not `NULL`, the function retrieves the number of strategies for the given game state from the `ui_strategy_table`. It then gets the `GameTreeNode` associated with the current game state and checks if it is an `ActionNode`.

If the node is an `ActionNode`, the function retrieves the list of `GameActions` associated with the node. It then calculates the range of the current player's hand based on the card coordinates stored in the `ui_strategy_table`. If the range is empty, the function returns an empty vector.

The function then iterates through the strategies stored in the `current_strategy` member variable and calculates the weighted sum of the strategies based on the range of the current player's hand. The weighted sum is stored in the `strategies` vector.

Finally, the function creates a vector of `pair<GameActions, float>` by iterating through the `strategies` vector and the `GameActions` associated with the `ActionNode`. The function returns this vector as the result.

If the node is not an `ActionNode`, the function simply returns an empty vector.\\
## Code: 
```
const vector<pair<GameActions,float>> TableStrategyModel::get_strategy(int i,int j) const{
    vector<pair<GameActions,float>> ret_strategy;
    if(this->treeItem == NULL) return ret_strategy;

    int strategy_number = this->ui_strategy_table[i][j].size();

    shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();

    if(node->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);

        vector<GameActions>& gameActions = actionNode->getActions();

        vector<float> strategies;

        // get range data - initally copied from paint_range - could probably be integrated in loops below for efficiancy
        vector<pair<int,int>> card_cords;
        const vector<vector<float>> *current_range;
        card_cords = ui_strategy_table[i][j];
        current_range = (0 == current_player ) ? & p1_range : & p2_range;

        if(p1_range.empty() || p2_range.empty()){
            return ret_strategy;
        }

        float range_number = 0;
        if(!card_cords.empty()){
            for(std::size_t indi = 0;indi < card_cords.size();indi ++){
                    range_number += (*current_range)[card_cords[indi].first][card_cords[indi].second];
            }
            range_number = range_number / card_cords.size();

            if(range_number < 0 || range_number > 1) throw runtime_error("range number incorrect in strategyitemdeletage");
        }
        else
            return ret_strategy;
        // got range data

        if(this->ui_strategy_table[i][j].size() > 0){
            strategies = vector<float>(gameActions.size());
            std::fill(strategies.begin(), strategies.end(), 0.);
        }
        for(std::pair<int,int> index:this->ui_strategy_table[i][j]){
            int index1 = index.first;
            int index2 = index.second;
            const vector<float>& one_strategy = this->current_strategy[index1][index2];
            if(gameActions.size() != one_strategy.size()){
                cout << "index: " << index1 << " " << index2 << endl;
                cout << "i,j: " << i << " " << j << endl;
                cout << "size not match between gameAction and stragegy: " << gameActions.size() << " " << one_strategy.size() << endl;
                throw runtime_error("size not match between gameAction and stragegy");
            }

            if ( range_number > 0)
                for(std::size_t indi = 0;indi < one_strategy.size();indi ++){
                    strategies[indi] += (one_strategy[indi] * (*current_range)[index1][index2] / range_number / strategy_number);
                }
        }

        for(std::size_t indi = 0;indi < strategies.size();indi ++){
            ret_strategy.push_back(std::pair<GameActions,float>(actionNode->getActions()[indi],
                                                                strategies[indi]));
        }

        return ret_strategy;
    }else{
        return ret_strategy;
    }

}
```