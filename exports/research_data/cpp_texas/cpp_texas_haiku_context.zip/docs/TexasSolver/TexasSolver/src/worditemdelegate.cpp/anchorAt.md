`anchorAt`: The function of `anchorAt` is to return the anchor text at a given point within an HTML-formatted string.

**Parameters**:
`QString html`: The HTML-formatted string to be analyzed.
`const QPoint &point`: The point within the HTML-formatted string to check for an anchor.

**Code Description**: The `anchorAt` function first creates a `QTextDocument` object and sets its HTML content to the provided `html` parameter. It then retrieves the document layout of the `QTextDocument` and calls the `anchorAt` method of the layout, passing the `point` parameter. The function returns the anchor text found at the specified point within the HTML-formatted string.\\
## Code: 
```
QString WordItemDelegate::anchorAt(QString html, const QPoint &point) const {
    QTextDocument doc;
    doc.setHtml(html);

    auto textLayout = doc.documentLayout();
    Q_ASSERT(textLayout != 0);
    return textLayout->anchorAt(point);
}
```