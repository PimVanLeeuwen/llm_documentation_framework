`build_game_tree`: The function of `build_game_tree` is to create a new `GameTree` object and assign it to the `game_tree` member variable of the `PokerSolver` class.

**Parameters**:
`float oop_commit`: The amount of money committed by the out-of-position player.
`float ip_commit`: The amount of money committed by the in-position player.
`int current_round`: The current round of the game (e.g., preflop, flop, turn, river).
`int raise_limit`: The maximum number of raises allowed in the current round.
`float small_blind`: The amount of the small blind.
`float big_blind`: The amount of the big blind.
`float stack`: The amount of money in the player's stack.
`GameTreeBuildingSettings buildingSettings`: Settings for building the game tree.
`float allin_threshold`: The threshold for determining when a player should go all-in.

**Code Description**: The `build_game_tree` function creates a new `GameTree` object using the provided parameters and assigns it to the `game_tree` member variable of the `PokerSolver` class. The `GameTree` object represents the game tree, which is a data structure that models the possible actions and outcomes of the poker game.

The `GameTree` constructor is called with the following arguments:
- `this->deck`: The deck of cards used in the game.
- `oop_commit`: The amount of money committed by the out-of-position player.
- `ip_commit`: The amount of money committed by the in-position player.
- `current_round`: The current round of the game.
- `raise_limit`: The maximum number of raises allowed in the current round.
- `small_blind`: The amount of the small blind.
- `big_blind`: The amount of the big blind.
- `stack`: The amount of money in the player's stack.
- `buildingSettings`: Settings for building the game tree.
- `allin_threshold`: The threshold for determining when a player should go all-in.

After creating the `GameTree` object, it is assigned to the `game_tree` member variable of the `Poker\\
## Code: 
```
void PokerSolver::build_game_tree(
        float oop_commit,
        float ip_commit,
        int current_round,
        int raise_limit,
        float small_blind,
        float big_blind,
        float stack,
        GameTreeBuildingSettings buildingSettings,
        float allin_threshold
){
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(
            this->deck,
            oop_commit,
            ip_commit,
            current_round,
            raise_limit,
            small_blind,
            big_blind,
            stack,
            buildingSettings,
            allin_threshold
    );
    this->game_tree = game_tree;
}
```