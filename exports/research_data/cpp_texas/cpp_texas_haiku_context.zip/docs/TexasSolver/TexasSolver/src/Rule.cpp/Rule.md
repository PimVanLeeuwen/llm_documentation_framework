`Rule`: The function of `Rule` is to initialize and set up the parameters for a poker game rule.

**Parameters**:
`Deck deck`: This parameter represents the deck of cards used in the poker game.
`float oop_commit`: This parameter represents the amount of commitment (e.g., bet or raise) made by the out-of-position player.
`float ip_commit`: This parameter represents the amount of commitment made by the in-position player.
`int current_round`: This parameter represents the current round of the poker game.
`int raise_limit`: This parameter represents the maximum number of raises allowed in the current round.
`float small_blind`: This parameter represents the small blind amount in the poker game.
`float big_blind`: This parameter represents the big blind amount in the poker game.
`float stack`: This parameter represents the current stack size of the player.
`GameTreeBuildingSettings build_settings`: This parameter represents the settings used for building the game tree.
`float allin_threshold`: This parameter represents the threshold for going all-in in the poker game.

**Code Description**: The `Rule` constructor initializes the various parameters related to the poker game, such as the deck, commitment amounts, current round, raise limit, blind amounts, stack size, game tree building settings, and all-in threshold. It also checks that the in-position commitment (`ip_commit`) is equal to the out-of-position commitment (`oop_commit`), and if not, it throws a `runtime_error` exception. Finally, it sets the `initial_effective_stack` variable to the current stack size.

The purpose of this `Rule` class is to encapsulate the various parameters and settings required for a poker game, making it easier to manage and maintain the game logic. By having a centralized place to store these values, the code can be more modular and easier to understand and maintain.\\
## Code: 
```
Rule::Rule(Deck deck, float oop_commit, float ip_commit, int current_round, int raise_limit, float small_blind,
           float big_blind, float stack, GameTreeBuildingSettings build_settings,float allin_threshold):
           deck(deck),oop_commit(oop_commit),ip_commit(ip_commit),current_round(current_round),raise_limit(raise_limit),
           small_blind(small_blind),big_blind(big_blind),stack(stack),build_settings(build_settings),allin_threshold(allin_threshold){
    if(oop_commit != ip_commit) throw runtime_error("ip commit should equal with oop commit");
    this->initial_effective_stack = stack;
}
```