`isAllZeros`: The function of `isAllZeros` is to check if all the elements in the input array are zero.

**Parameters**:
`vector<float> input_array`: This parameter is a vector of floating-point numbers that will be checked for all-zero values.

**Code Description**: The `isAllZeros` function takes a `vector<float>` called `input_array` as its parameter. It then iterates through each element `i` in the input array using a `for` loop. For each element, it checks if the value is not equal to zero. If any element is found to be non-zero, the function immediately returns `false`, indicating that the input array does not contain all-zero values. If the loop completes without finding any non-zero elements, the function returns `true`, indicating that all elements in the input array are zero.\\
## Code: 
```
bool CfrPlusTrainable::isAllZeros(vector<float> input_array) {
    for(float i:input_array){
        if (i != 0)return false;
    }
    return true;
}
```