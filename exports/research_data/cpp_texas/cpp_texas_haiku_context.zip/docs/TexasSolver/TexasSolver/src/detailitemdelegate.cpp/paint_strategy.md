`paint_strategy`: The function of `paint_strategy` is to paint the strategy visualization for a specific game action in a table view.

**Parameters**:
`QPainter *painter`: This parameter is a pointer to the QPainter object that will be used to draw the strategy visualization.
`const QStyleOptionViewItem &option`: This parameter contains the style options for the current view item, which are used to determine the layout and appearance of the item.
`const QModelIndex &index`: This parameter represents the index of the current item in the model, which is used to retrieve the relevant data for the strategy visualization.

**Code Description**:
The `paint_strategy` function first initializes the style options for the current view item using the `initStyleOption` function. It then retrieves the `DetailViewerModel` associated with the current model index.

If the `treeItem` in the `tableStrategyModel` is not null and its type is `GameTreeNode::ACTION`, the function proceeds to extract the relevant strategy information from the model. This includes the card combination, the probabilities for each action (fold, call, check, bet, raise), and the range information.

The function then calculates the heights of the different sections of the strategy visualization, including the fold probability, the "not in range" section, and the remaining section for the other actions. It then draws the background for the fold probability section and the remaining section, using different colors to represent the different actions.

Finally, the function generates an HTML-formatted string that displays the card combination and the probabilities for each action, and uses the `QTextDocument` class to draw this text within the view item's rectangle.

Overall, the `paint_strategy` function is responsible for rendering the detailed strategy information for a specific game action in a table view, using the data provided by the `DetailViewerModel` and the `tableStrategyModel`.\\
## Code: 
```
void DetailItemDelegate::paint_strategy(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);

    const DetailViewerModel * detailViewerModel = qobject_cast<const DetailViewerModel*>(index.model());
    //vector<pair<GameActions,float>> strategy = detailViewerModel->tableStrategyModel->get_strategy(this->detailWindowSetting->grid_i,this->detailWindowSetting->grid_j);

    options.text = "";
    if(detailViewerModel->tableStrategyModel->treeItem != NULL &&
            detailViewerModel->tableStrategyModel->treeItem->m_treedata.lock()->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<GameTreeNode> node = detailViewerModel->tableStrategyModel->treeItem->m_treedata.lock();
        int strategy_number = 0;
        if(this->detailWindowSetting->grid_i >= 0 && this->detailWindowSetting->grid_j >= 0){
           strategy_number = detailViewerModel->tableStrategyModel->ui_strategy_table[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j].size();
        }
        int ind = index.row() * detailViewerModel->columns + index.column();

        if(ind < strategy_number){

            pair<int,int> strategy_ui_table = detailViewerModel->tableStrategyModel->ui_strategy_table[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j][ind];
            int card1 = strategy_ui_table.first;
            int card2 = strategy_ui_table.second;
            vector<float> strategy = detailViewerModel->tableStrategyModel->current_strategy[card1][card2];


            shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);

            vector<GameActions>& gameActions = actionNode->getActions();
            if(gameActions.size() != strategy.size())throw runtime_error("size mismatch in DetailItemItemDelegate paint");
            float fold_prob = 0;
            vector<float> strategy_without_fold;
            float strategy_without_fold_sum = 0;
            for(std::size_t i = 0;i < strategy.size();i ++){
                GameActions one_action = gameActions[i];
                if(one_action.getAction() == GameTreeNode::PokerActions::FOLD){
                    fold_prob = strategy[i];
                }else{
                    strategy_without_fold.push_back(strategy[i]);
                    strategy_without_fold_sum += strategy[i];
                }
            }

            for(std::size_t i = 0;i < strategy_without_fold.size();i ++){
                strategy_without_fold[i] = strategy_without_fold[i] / strategy_without_fold_sum;
            }

            // get range data - copied initially from paint_range
            float range_number;
            if(0 == detailViewerModel->tableStrategyModel->current_player){
                range_number = detailViewerModel->tableStrategyModel->p1_range[card1][card2];
            }else{
                range_number = detailViewerModel->tableStrategyModel->p2_range[card1][card2];
            }
            if(range_number < 0 || range_number > 1) throw runtime_error("range number incorrect in strategyitemdeletage");
            // got range data

            float not_in_range = 1 - range_number;
            int niR_height = (int)(not_in_range * option.rect.height() * 0.975);

            int disable_height = (int)(0.5 + fold_prob * (option.rect.height()-niR_height));
            int remain_height = option.rect.height() - niR_height - disable_height;

            // draw background for flod
        if ( disable_height > 0) {
            QRect rect(option.rect.left(), option.rect.top() + niR_height,\
                 option.rect.width(), disable_height);
            QBrush brush(QColor	(0,191,255));
            painter->fillRect(rect, brush);
        }
        if (remain_height > 0){
            int ind = 0;
            float last_prob = 0;
            int bet_raise_num = 0;
            for(std::size_t i = 0;i < strategy.size();i ++){
                GameActions one_action = gameActions[i];
                QBrush brush(Qt::gray);
                if(one_action.getAction() != GameTreeNode::PokerActions::FOLD){
                if(one_action.getAction() == GameTreeNode::PokerActions::CHECK
                || one_action.getAction() == GameTreeNode::PokerActions::CALL){
                    brush = QBrush(Qt::green);
                }
                else if(one_action.getAction() == GameTreeNode::PokerActions::BET
                || one_action.getAction() == GameTreeNode::PokerActions::RAISE){
                    int color_base = max(128 - 32 * bet_raise_num - 1,0);
                    brush = QBrush(QColor(255,color_base,color_base));
                    bet_raise_num += 1;
                }else{
                brush = QBrush(Qt::blue);
                }

                int delta_x = (int)(option.rect.width() * last_prob);
                int delta_width = (int)(option.rect.width() * (last_prob + strategy_without_fold[ind])) - (int)(option.rect.width() * last_prob);

                QRect rect(option.rect.left() + delta_x, option.rect.top() + niR_height + disable_height,\
                 delta_width , remain_height);
                painter->fillRect(rect, brush);
            }

                last_prob += strategy_without_fold[ind];
                ind += 1;
                }
            }
            options.text = "";
            options.text += detailViewerModel->tableStrategyModel->cardint2card[card1].toFormattedHtml();
            options.text += detailViewerModel->tableStrategyModel->cardint2card[card2].toFormattedHtml();
            options.text = "<h2 >" + options.text + "<\/h2>";
            for(std::size_t i = 0;i < strategy.size();i ++){
                GameActions one_action = gameActions[i];
                float one_strategy = strategy[i] * 100;
                if(one_action.getAction() ==  GameTreeNode::PokerActions::FOLD){
                    options.text +=  QString(" <h5> %1 : %2\%<\/h5>").arg(tr("FOLD"),QString::number(one_strategy,'f',1));
                }
                else if(one_action.getAction() ==  GameTreeNode::PokerActions::CALL){
                    options.text +=  QString(" <h5> %1 : %2\%<\/h5>").arg(tr("CALL"),QString::number(one_strategy,'f',1));
                }
                else if(one_action.getAction() ==  GameTreeNode::PokerActions::CHECK){
                    options.text +=  QString(" <h5> %1 : %2\%<\/h5>").arg(tr("CHECK"),QString::number(one_strategy,'f',1));
                }
                else if(one_action.getAction() ==  GameTreeNode::PokerActions::BET){
                    options.text +=  QString(" <h5> %1 %2 : %3\%<\/h5>").arg(tr("BET"),QString::number(one_action.getAmount()),QString::number(one_strategy,'f',1));
                }
                else if(one_action.getAction() ==  GameTreeNode::PokerActions::RAISE){
                    options.text +=  QString(" <h5> %1 %2 : %3\%<\/h5>").arg(tr("RAISE"),QString::number(one_action.getAmount()),QString::number(one_strategy,'f',1));
                }
            }
        }
    }

    QTextDocument doc;
    doc.setHtml(options.text);

    options.text = "";
    //options.widget->style()->drawControl(QStyle::CE_ItemViewItem, &option, painter);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```