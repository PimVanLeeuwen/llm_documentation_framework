`getcurrentStrategy`: The function of `getcurrentStrategy` is to calculate and return the current strategy of the CfrPlusTrainable object.

**Code Description**: The `getcurrentStrategy` method is responsible for calculating and returning the current strategy of the CfrPlusTrainable object. The strategy is represented as a vector of float values, where each value corresponds to the probability of taking a particular action.

The method first checks if the `r_plus_sum` vector is empty. If it is, the method fills the `retval` vector with equal probabilities for each action (1.0 / `action_number`). This is the default strategy when no regrets have been accumulated.

If the `r_plus_sum` vector is not empty, the method iterates over all the actions and private cards, and calculates the strategy for each combination. The strategy for a particular action and private card is calculated as `r_plus[index] / r_plus_sum[private_id]`, where `index` is the index of the action and private card combination in the `r_plus` vector.

If the `r_plus_sum[private_id]` is zero, the method sets the strategy for that combination to the default value of `1.0 / action_number`. This is to handle the case where no regrets have been accumulated for a particular private card.

The method also checks if any of the `r_plus` values are `NaN` (Not a Number), and throws a `runtime_error` exception if such a value is found.

Finally, the method returns the `retval` vector, which contains the calculated strategy.\\
## Code: 
```
const vector<float> CfrPlusTrainable::getcurrentStrategy() {
    if(this->r_plus_sum.empty()){
        fill(retval.begin(),retval.end(),1.0 / this->action_number);
    }else {
        for (int action_id = 0; action_id < action_number; action_id++) {
            for (int private_id = 0; private_id < this->card_number; private_id++) {
                int index = action_id * this->card_number + private_id;
                if(this->r_plus_sum[private_id] != 0) {
                    retval[index] = this->r_plus[index] / this->r_plus_sum[private_id];
                }else{
                    retval[index] = 1.0 / this->action_number;
                }
                if(this->r_plus[index] != this->r_plus[index]) throw runtime_error("nan found");
                /*
                if(this.r_plus_sum[private_id] == 0)
                {
                    System.out.println("Exception regret status, r_plus_sum == 0:");
                    System.out.println(String.format("r plus length %s , card num %s",r_plus.length,this.card_number));
                    for(int i = index % this.card_number;i < this.r_plus.length;i += this.card_number){
                        System.out.print(String.format("%s:%s ",i,this.r_plus[i]));
                        if(i == index){
                            System.out.print("[current]");
                        }
                    }
                    System.out.println();
                    System.out.println();
                    throw new RuntimeException();
                }
                 */
            }
        }
    }
    return retval;
}
```