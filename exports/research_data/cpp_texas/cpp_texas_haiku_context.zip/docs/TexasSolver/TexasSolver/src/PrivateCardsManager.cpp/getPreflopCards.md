`getPreflopCards`: The function of `getPreflopCards` is to retrieve the private cards for a specific player.

**Parameters**:
`int player`: This parameter represents the player whose private cards are to be retrieved.

**Code Description**: The `getPreflopCards` method is part of the `PrivateCardsManager` class. It takes an `int` parameter `player` and returns a reference to a `vector<PrivateCards>` object, which represents the private cards for the specified player. The method directly accesses the `private_cards` member variable of the `PrivateCardsManager` class and returns the vector of private cards for the given player.\\
## Code: 
```
vector<PrivateCards>& PrivateCardsManager::getPreflopCards(int player) {
    return this->private_cards[player];
}
```