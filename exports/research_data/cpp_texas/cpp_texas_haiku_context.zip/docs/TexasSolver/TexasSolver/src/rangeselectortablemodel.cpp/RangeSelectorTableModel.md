`RangeSelectorTableModel`: The function of `RangeSelectorTableModel` is to create and manage a table model for a range selector UI component.

**Parameters**:
`QStringList ranks`: This parameter represents a list of ranks or labels that will be used to populate the rows and columns of the table.
`QString initial_board`: This parameter represents an initial board configuration that will be used to set the initial values in the table.
`QObject *parent`: This parameter represents the parent object of the `RangeSelectorTableModel` instance, which is used for memory management purposes.
`bool thumbnail`: This parameter is a flag that indicates whether the table model is being used for a thumbnail view or a full-size view.

**Code Description**:
The `RangeSelectorTableModel` constructor initializes the table model with the provided parameters. It first stores the `ranks` list and the `thumbnail` flag as member variables. Then, it creates two 2D vectors: `grids_string` and `grids_float`.

The `grids_string` vector is populated with the text to be displayed in each cell of the table. The text for each cell is generated using the `get_ij_text` method, which takes the row and column indices as input and returns the corresponding text. The `string2ij` map is also populated to store the mapping between the cell text and the corresponding row and column indices.

The `grids_float` vector is initialized with all values set to 0.0. This vector will be used to store the actual values associated with each cell in the table.

Finally, the `setRangeText` method is called with the `initial_board` parameter to set the initial values in the table.

Overall, the `RangeSelectorTableModel` class provides a way to manage a 2D table of values, where the rows and columns are labeled with the provided `ranks` list, and the initial values are set based on the `initial_board` parameter. The class also supports a thumbnail mode, which is controlled by the `thumbnail` flag.\\
## Code: 
```
RangeSelectorTableModel::RangeSelectorTableModel(QStringList ranks,QString initial_board,QObject *parent,bool thumbnail):QAbstractItemModel(parent){
    this->ranklist = ranks;
    this->thumbnail = thumbnail;

    this->grids_string = vector<vector<QString>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_string[i] = vector<QString>(this->ranklist.size());
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_string[i][j] = this->get_ij_text(i,j);
            this->string2ij[this->get_ij_text(i,j)] = pair<int,int>(i,j);
        }
    }

    this->grids_float = vector<vector<float>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_float[i] = vector<float>(this->ranklist.size(),0.0);
    }
    this->setRangeText(initial_board);
}
```