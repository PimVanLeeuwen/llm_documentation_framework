`saving`: The function of `saving` is to save the current state of the solver to a JSON file.

**Code Description**:

1. The function starts by printing a debug message indicating that it is saving the JSON file.

2. It then creates a QSettings object with the organization name "TexasSolver" and the application name "Setting". It begins a group called "solver" within the settings.

3. The function retrieves the value of the "dump_round" setting from the QSettings object and stores it in the `dump_rounds` member variable of the `QSolverJob` class.

4. It then prints a debug message indicating the current value of the `dump_rounds` variable. If the value is 3, it prints a warning message indicating that the dump to the river may be slow and could potentially consume a lot of RAM, as the dump to the river is not well optimized.

5. The function then checks the value of the `mode` member variable of the `QSolverJob` class. If the mode is `HOLDEM`, it calls the `dump_strategy` function of the `ps_holdem` member variable, passing the `savefile` and `dump_rounds` variables as arguments. If the mode is `SHORTDECK`, it calls the `dump_strategy` function of the `ps_shortdeck` member variable, passing the same arguments.

6. Finally, the function prints a debug message indicating that the saving process is complete.

Overall, the `saving` function is responsible for saving the current state of the solver to a JSON file, with the ability to control the level of detail in the dump by setting the `dump_rounds` variable. The function also includes some error handling and debugging messages to help with troubleshooting.\\
## Code: 
```
void QSolverJob::saving(){
    qDebug().noquote() << tr("Saving json file..");//.toStdString() << std::endl;

    QSettings setting("TexasSolver", "Setting");
    setting.beginGroup("solver");
    this->dump_rounds = setting.value("dump_round").toInt();

    qDebug().noquote() << tr("Dump round: ") << this->dump_rounds;
    if(this->dump_rounds == 3){
        qDebug().noquote() << tr("This could be slow, or even blow your RAM, dump to river is not well optimized :(");
    }
    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.dump_strategy(this->savefile,this->dump_rounds);
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.dump_strategy(this->savefile,this->dump_rounds);
    }
    qDebug().noquote() << tr("Saving done.");//.toStdString() << std::endl;
}
```