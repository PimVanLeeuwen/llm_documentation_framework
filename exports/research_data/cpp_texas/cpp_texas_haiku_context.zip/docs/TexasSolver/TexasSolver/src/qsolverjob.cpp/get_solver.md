`get_solver`: The function of `get_solver` is to return a pointer to a `PokerSolver` object based on the current mode of the `QSolverJob` instance.

**Code Description**:
The `get_solver` method is responsible for returning the appropriate `PokerSolver` object based on the current mode of the `QSolverJob` instance. The method checks the value of the `mode` member variable and returns a pointer to either the `ps_holdem` or `ps_shortdeck` member variables, which are both `PokerSolver` objects.

If the `mode` is set to `Mode::HOLDEM`, the method returns a pointer to the `ps_holdem` object. If the `mode` is set to `Mode::SHORTDECK`, the method returns a pointer to the `ps_shortdeck` object. If the `mode` is set to any other value, the method throws a `runtime_error` exception with the message "unknown mode in get_solver".

This method is likely used to provide the appropriate `PokerSolver` object to other parts of the application, depending on the current game mode. The `PokerSolver` object is likely responsible for performing various poker-related calculations or operations, and the `get_solver` method ensures that the correct object is used for the current game mode.\\
## Code: 
```
PokerSolver* QSolverJob::get_solver(){
    if(this->mode == Mode::HOLDEM){
        return &this->ps_holdem;
    }else if(this->mode == Mode::SHORTDECK){
        return &this->ps_shortdeck;
    }else throw runtime_error("unknown mode in get_solver");
}
```