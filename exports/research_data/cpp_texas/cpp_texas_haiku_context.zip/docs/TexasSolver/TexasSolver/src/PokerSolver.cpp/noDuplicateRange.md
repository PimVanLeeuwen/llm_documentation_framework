`noDuplicateRange`: The function of `noDuplicateRange` is to create a new vector of `PrivateCards` objects that do not have any duplicates and do not intersect with the given board.

**Parameters**:
`const vector<PrivateCards> &private_range`: This parameter is a reference to a vector of `PrivateCards` objects, representing a range of private cards.
`uint64_t board_long`: This parameter is a 64-bit unsigned integer representing the board cards.

**Code Description**:
The function first creates an empty vector `range_array` to store the unique `PrivateCards` objects that do not intersect with the board. It also creates an unordered map `rangekv` to keep track of the unique `PrivateCards` objects.

The function then iterates through the `private_range` vector. For each `PrivateCards` object, it checks if the object's hash code (obtained using the `hashCode()` method) already exists in the `rangekv` map. If the hash code is found, it means the `PrivateCards` object is a duplicate, and the function throws a runtime error with the string representation of the duplicate `PrivateCards` object.

If the `PrivateCards` object is unique, the function adds its hash code to the `rangekv` map and converts the card IDs stored in the `card_vec` member of the `PrivateCards` object to a 64-bit unsigned integer representation using the `boardInts2long()` function from the `Card` class.

The function then checks if the 64-bit representation of the `PrivateCards` object's cards does not intersect with the `board_long` parameter using the `boardsHasIntercept()` function from the `Card` class. If the cards do not intersect, the function adds the `PrivateCards` object to the `range_array` vector.

Finally, the function returns the `range_array` vector, which contains the unique `PrivateCards` objects that do not intersect with the given board.\\
## Code: 
```
vector<PrivateCards> noDuplicateRange(const vector<PrivateCards> &private_range, uint64_t board_long) {
    vector<PrivateCards> range_array;
    unordered_map<int,bool> rangekv;
    for(PrivateCards one_range:private_range){
        if(rangekv.find(one_range.hashCode()) != rangekv.end())
            throw runtime_error(tfm::format("duplicated key %s",one_range.toString()));
        rangekv[one_range.hashCode()] = true;
        uint64_t hand_long = Card::boardInts2long(one_range.get_hands());
        if(!Card::boardsHasIntercept(hand_long,board_long)){
            range_array.push_back(one_range);
        }
    }
    return range_array;
}
```