`printNodeHistory`: The function of `printNodeHistory` is to print the history of a game tree node, including the actions taken by the players and the chance events that occurred.

**Parameters**:
`GameTreeNode* node`: This parameter represents the current node in the game tree for which the history is to be printed.

**Code Description**:
The `printNodeHistory` function takes a `GameTreeNode` pointer as input and recursively traverses the game tree from the current node to the root, printing the actions and chance events that led to the current node.

The function first checks if the current node has a parent. If the parent is not `nullptr`, it checks the type of the parent node:

1. If the parent is an `ActionNode`, it iterates through the actions of the parent node and finds the action that led to the current node. It then prints a message in the format `"<- (player %s %s)"`, where `%s` is replaced with the player and the action taken.

2. If the parent is a `ChanceNode`, it iterates through the child nodes of the parent and finds the child node that is the current node. It then prints a message in the format `"<- (deal card %s)"`, where `%s` is replaced with the card dealt.

3. If the parent is neither an `ActionNode` nor a `ChanceNode`, it simply prints a message in the format `"<- (%s)"`, where `%s` is replaced with the string representation of the node.

The function then recursively calls itself with the parent node as the new argument, continuing the traversal up the game tree. Once the root node is reached, the function prints a newline character to complete the output.

Overall, the `printNodeHistory` function provides a way to visualize the sequence of actions and chance events that led to the current state of the game tree, which can be useful for debugging and understanding the game's logic.\\
## Code: 
```
void GameTreeNode::printNodeHistory(GameTreeNode* node) {
    /*
    while(node != nullptr) {
        shared_ptr<GameTreeNode>parent_node = node->parent;
        if (parent_node == nullptr) break;
        if(parent_node instanceof ActionNode){
            ActionNode action_node = (ActionNode)parent_node;
            for(int i = 0;i < action_node.getActions().size();i ++){
                if(action_node.getChildrens().get(i) == node){
                    System.out.print(String.format("<- (player %s %s)",
                                                   action_node.getPlayer(),
                                                   action_node.getActions().get(i).toString()
                    ));
                }
            }
        }else if(parent_node instanceof ChanceNode) {
            ChanceNode chance_node = (ChanceNode)parent_node;
            for(int i = 0;i < chance_node.getChildrens().size();i ++){
                if(chance_node.getChildrens().get(i) == node){
                    System.out.print(String.format("<- (deal card %s)",
                                                   chance_node.getCards().get(i).toString()
                    ));
                }
            }

        }else{
            System.out.print(String.format("<- (%s)",node.toString()));
        }
        node = parent_node;
    }
    System.out.println()
    }
     */
}
```