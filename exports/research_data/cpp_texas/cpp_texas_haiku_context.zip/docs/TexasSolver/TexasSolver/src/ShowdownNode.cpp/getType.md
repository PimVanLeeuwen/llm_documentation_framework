`getType`: The function of `getType` is to return the type of the `ShowdownNode` object.

**Code Description**: The `getType()` method is defined within the `ShowdownNode` class, which is likely a subclass of the `GameTreeNode` class. This method simply returns the constant `SHOWDOWN`, which is likely an enumeration value defined within the `GameTreeNode::GameTreeNodeType` type. This indicates that the current node represents a "showdown" in the game being modeled by the `TexasSolver` application.

The purpose of this method is to provide a way to identify the type of the current node in the game tree, which can be useful for implementing different behaviors or logic based on the node type. For example, the application may handle "showdown" nodes differently than other types of nodes in the game tree.\\
## Code: 
```
GameTreeNode::GameTreeNodeType ShowdownNode::getType() {
    return SHOWDOWN;
}
```