`playerHands`: The function of `playerHands` is to return the private card range for a given player.

**Parameters**:
`int player`: This parameter specifies the player whose private card range is to be returned. The value `0` represents the first player, and the value `1` represents the second player.

**Code Description**:
The `playerHands` function takes an `int` parameter `player` and returns a reference to a `vector<PrivateCards>` object. The function checks the value of the `player` parameter and returns the corresponding private card range:

1. If `player` is `0`, the function returns the `range1` vector, which represents the private card range for the first player.
2. If `player` is `1`, the function returns the `range2` vector, which represents the private card range for the second player.
3. If `player` is neither `0` nor `1`, the function throws a `runtime_error` with the message "player not found".

This function is likely used to retrieve the private card ranges for different players in the context of a Texas Hold'em poker solver or similar application.\\
## Code: 
```
const vector<PrivateCards> &PCfrSolver::playerHands(int player) {
    if(player == 0){
        return range1;
    }else if (player == 1){
        return range2;
    }else{
        throw runtime_error("player not found");
    }
}
```