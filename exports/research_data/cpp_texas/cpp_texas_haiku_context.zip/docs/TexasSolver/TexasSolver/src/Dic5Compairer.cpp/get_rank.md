`get_rank`: The function of `get_rank` is to calculate the rank of a poker hand given the private hand and public board.

**Parameters**:
`uint64_t private_hand`: A 64-bit integer representing the player's private hand cards.
`uint64_t public_board`: A 64-bit integer representing the public board cards.

**Code Description**:
The `get_rank` function is a method of the `Dic5Compairer` class. It takes the `private_hand` and `public_board` parameters, which are both 64-bit integers representing the player's private hand and the public board cards, respectively.

The function then calls another method within the `Dic5Compairer` class, `get_rank`, which takes two parameters: a vector of integers representing the private hand cards, and a vector of integers representing the public board cards. These vectors are obtained by calling the `long2board` static method of the `Card` class, which converts the 64-bit integer representations of the private hand and public board into the corresponding vectors of card indices.

The purpose of the `get_rank` function is to calculate the rank of the poker hand formed by the player's private hand and the public board. This rank is then returned as the output of the function.\\
## Code: 
```
int Dic5Compairer::get_rank(uint64_t private_hand, uint64_t public_board) {
    return this->get_rank(Card::long2board(private_hand),Card::long2board(public_board));
}
```