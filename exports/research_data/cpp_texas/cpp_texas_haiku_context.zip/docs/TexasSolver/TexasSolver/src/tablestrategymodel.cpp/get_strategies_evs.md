`get_strategies_evs`: The function of `get_strategies_evs` is to calculate the expected values (EVs) of the strategies for a given set of indices `i` and `j` in the `TableStrategyModel` class.

**Parameters**:
`int i`: The row index in the `ui_strategy_table` matrix.
`int j`: The column index in the `ui_strategy_table` matrix.

**Code Description**:
1. The function first checks if the `treeItem` is `NULL` or the `current_evs` vector is empty. If either of these conditions is true, it returns an empty `vector<float>`.
2. It then determines the current player's range (`p1_range` or `p2_range`) based on the value of the `current_player` variable.
3. If either `p1_range` or `p2_range` is empty, the function returns an empty `vector<float>`.
4. The function then retrieves the `GameTreeNode` associated with the `treeItem` and checks if it is an `ActionNode`.
5. If the node is an `ActionNode`, the function retrieves the list of `GameActions` associated with the node.
6. It then iterates through the indices in the `ui_strategy_table[i][j]` vector and calculates the expected values (EVs) for each action. The EV for each action is calculated as the sum of the product of the strategy probability, the EV, and the range for each index in the `ui_strategy_table[i][j]` vector.
7. The function then normalizes the EVs by dividing them by the sum of the strategy probabilities.
8. Finally, the function returns the calculated EVs as a `vector<float>`.

The purpose of this function is to provide the expected values of the strategies for a given set of indices in the `TableStrategyModel` class. This information can be used to inform decision-making in a game-playing algorithm or to provide feedback to users about the expected outcomes of their actions.\\
## Code: 
```
const vector<float> TableStrategyModel::get_strategies_evs(int i,int j)const{
    vector<float> ret_evs;
    if(this->treeItem == NULL || this->current_evs.empty())return ret_evs;

    const vector<vector<float>> *current_range;
    current_range = (0 == current_player ) ? & p1_range : & p2_range;
    if(p1_range.empty() || p2_range.empty()){
        return ret_evs;
    }

    shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();

    if(node->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);
        vector<GameActions>& gameActions = actionNode->getActions();

        vector<float> strategy_p;
        if(this->ui_strategy_table[i][j].size() > 0){
            ret_evs = vector<float>(gameActions.size());
            std::fill(ret_evs.begin(), ret_evs.end(), 0.);
            strategy_p = vector<float>(gameActions.size());
            std::fill(strategy_p.begin(), strategy_p.end(), 0.);
        }
        float range = 0;
        for(std::pair<int,int> index:this->ui_strategy_table[i][j]){
            int index1 = index.first;
            int index2 = index.second;
            const vector<float>& one_strategy = this->current_strategy[index1][index2];
            const vector<float>& one_ev = this->current_evs[index1][index2];
            const float one_range = (*current_range)[index1][index2];
            if(gameActions.size() != one_strategy.size() || one_ev.size() != one_strategy.size()){
                cout << "index: " << index1 << " " << index2 << endl;
                cout << "i,j: " << i << " " << j << endl;
                cout << "size not match between one_ev, gameAction and one_stragegy: "
                     << one_ev.size() << " " << gameActions.size() << " " << one_strategy.size() << endl;
                throw runtime_error("size not match between one_ev, gameAction and one_stragegy");
            }
            for(std::size_t indi = 0;indi < ret_evs.size();indi ++){
                ret_evs[indi] += one_strategy[indi] * one_ev[indi] * one_range;
                strategy_p[indi] += one_strategy[indi] * one_range;
            }
            range += one_range;
        }
        for(std::size_t indi = 0;indi < ret_evs.size();indi ++){
            if (strategy_p[indi] > 0. && range > 0.) {
                ret_evs[indi] = ret_evs[indi] / strategy_p[indi];
            }
        }
        return ret_evs;
    }else{
        return ret_evs;
    }
}
```