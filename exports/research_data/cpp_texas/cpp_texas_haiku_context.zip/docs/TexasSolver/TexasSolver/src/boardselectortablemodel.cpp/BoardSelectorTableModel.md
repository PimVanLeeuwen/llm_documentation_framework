`BoardSelectorTableModel`: The function of `BoardSelectorTableModel` is to create and manage a table model for a board selector in a Texas Hold'em poker application.

**Parameters**:
`QStringList ranks`: This parameter represents the list of card ranks (e.g., "2", "3", ..., "A") that will be used to populate the table model.
`QString initial_board`: This parameter represents the initial board state, which will be used to set the initial values in the table model.
`QObject *parent`: This parameter is the parent object of the `BoardSelectorTableModel` instance, which is used for memory management purposes.

**Code Description**:
The `BoardSelectorTableModel` constructor initializes the following member variables:
1. `ranklist`: Stores the list of card ranks passed as the `ranks` parameter.
2. `suitlist`: Initializes a list of card suits ("c", "d", "h", "s") that will be used to populate the table model.
3. `grids_string`: Initializes a 2D vector of `QString` values, where each element represents the text to be displayed in the corresponding cell of the table model. The `get_ij_text` method is used to generate the text for each cell.
4. `string2ij`: Initializes a map that stores the mapping between the cell text and the corresponding row and column indices.
5. `grids_float`: Initializes a 2D vector of `float` values, where each element represents the value to be associated with the corresponding cell in the table model.

The constructor then calls the `setBoardText` method, passing the `initial_board` parameter, to set the initial values in the `grids_float` vector.

The `BoardSelectorTableModel` class is likely used as the data model for a table view or table widget in a user interface, allowing the user to interact with and select the desired board state for a Texas Hold'em game.\\
## Code: 
```
BoardSelectorTableModel::BoardSelectorTableModel(QStringList ranks,QString initial_board,QObject *parent):QAbstractItemModel(parent){
    this->ranklist = ranks;
    this->suitlist = QString("c,d,h,s").split(",");

    this->grids_string = vector<vector<QString>>(this->suitlist.size());
    for(int i = 0;i < this->suitlist.size();i ++){
        this->grids_string[i] = vector<QString>(this->ranklist.size());
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_string[i][j] = this->get_ij_text(i,j);
            this->string2ij[this->get_ij_text(i,j)] = pair<int,int>(i,j);
        }
    }

    this->grids_float = vector<vector<float>>(this->suitlist.size());
    for(int i = 0;i < this->suitlist.size();i ++){
        this->grids_float[i] = vector<float>(this->ranklist.size(),0.0);
    }
    this->setBoardText(initial_board);
}
```