`DiscountedCfrTrainable`: The function of `DiscountedCfrTrainable` is to initialize and store various data structures required for the Discounted Counterfactual Regret Minimization (DCFR) algorithm.

**Parameters**:
`vector<PrivateCards> *privateCards`: This parameter is a pointer to a vector of `PrivateCards` objects, which likely represent the private cards held by each player in a game.
`ActionNode &actionNode`: This parameter is a reference to an `ActionNode` object, which represents a node in the game tree where an action can be taken.

**Code Description**:
The `DiscountedCfrTrainable` constructor initializes the following data structures:
1. `this->privateCards`: A pointer to the `privateCards` vector passed as a parameter.
2. `this->action_number`: The number of child nodes (actions) associated with the `actionNode` passed as a parameter.
3. `this->card_number`: The size of the `privateCards` vector passed as a parameter.
4. `this->evs`: A vector of floats with a size equal to the product of `action_number` and `card_number`, initialized to 0.0. This vector likely stores the expected values for each action-card combination.
5. `this->r_plus`: A vector of floats with a size equal to the product of `action_number` and `card_number`, initialized to 0.0. This vector likely stores the positive regrets for each action-card combination.
6. `this->r_plus_sum`: A vector of floats with a size equal to `card_number`, initialized to 0.0. This vector likely stores the sum of the positive regrets for each card.
7. `this->cum_r_plus`: A vector of floats with a size equal to the product of `action_number` and `card_number`, initialized to 0.0. This vector likely stores the cumulative positive regrets for each action-card combination.

The purpose of these data structures is to store and manage the necessary information for the DCFR algorithm, which is used to find an optimal strategy in a game. The `DiscountedCfrTrainable\\
## Code: 
```
DiscountedCfrTrainable::DiscountedCfrTrainable(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();

    this->evs = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus_sum = vector<float>(this->card_number,0.0);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number,0.0);
    //this->cum_r_plus_sum = vector<float>(this->card_number);
}
```