`get_commit`: The function of `get_commit` is to return the commitment value for a given player.

**Parameters**:
`int player`: This parameter represents the player whose commitment value needs to be retrieved. The value `0` represents the in-position (IP) player, and the value `1` represents the out-of-position (OOP) player.

**Code Description**:
The `get_commit` function checks the value of the `player` parameter and returns the corresponding commitment value. If the `player` parameter is `0`, the function returns the `ip_commit` value. If the `player` parameter is `1`, the function returns the `oop_commit` value. If the `player` parameter is neither `0` nor `1`, the function throws a `runtime_error` with the message "unknown player".

This function is likely used in a Texas Hold'em poker game simulation or analysis, where the commitment value represents the amount of money a player is willing to commit to a particular hand or round of the game. The commitment value can be used to determine the player's strategy or to calculate the expected value of a particular action.\\
## Code: 
```
float Rule::get_commit(int player) {
    if (player == 0) return this->ip_commit;
    else if(player == 1) return this->oop_commit;
    else throw runtime_error("unknown player");
}
```