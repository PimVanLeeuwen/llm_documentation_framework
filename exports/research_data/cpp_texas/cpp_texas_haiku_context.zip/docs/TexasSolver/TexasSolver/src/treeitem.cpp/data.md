`data`: The function of `data` is to return a QVariant representing the data associated with the current TreeItem object.

**Code Description**: The `data()` method of the `TreeItem` class is responsible for generating a textual representation of the game tree node represented by the `TreeItem`. The method first retrieves the parent node and the current node using the `getParent()` and `lock()` methods of the `GameTreeNode` class.

If the parent node is `nullptr`, it means the current node is the root of the game tree, and the method returns a string indicating the beginning of the round.

If the parent node is an `ActionNode`, the method iterates through the child nodes of the parent node to find the current node. Once the current node is identified, the method generates a string representing the action taken by the player, including whether the action was made by the in-position (IP) or out-of-position (OOP) player, and the type and amount of the action.

If the parent node is a `ChanceNode`, the method determines the game round (Flop, Turn, or River) and returns a corresponding string indicating the dealing of a new community card.

If the parent node's type is not recognized, the method returns the string "NodeError".

The `data()` method is an important part of the `TreeItem` class, as it provides a way to display the game tree information in a user-friendly format, which can be useful for debugging and visualization purposes.\\
## Code: 
```
QVariant TreeItem::data() const
{
    shared_ptr<GameTreeNode> parentNode = this->m_treedata.lock()->getParent();
    shared_ptr<GameTreeNode> currentNode = this->m_treedata.lock();
    if(parentNode == nullptr){
        return TreeItem::get_round_str(currentNode->getRound()) + QObject::tr(" begin");
    }
    if(parentNode->getType() == GameTreeNode::GameTreeNodeType::ACTION){
        shared_ptr<ActionNode> parentActionNode = dynamic_pointer_cast<ActionNode>(parentNode);
        vector<GameActions>& actions = parentActionNode->getActions();
        vector<shared_ptr<GameTreeNode>>& childrens = parentActionNode->getChildrens();
        for(std::size_t i = 0;i < childrens.size();i ++){
            if(childrens[i] == currentNode){
                float amount = childrens[i]->getPot() - parentNode->getPot();
                return (parentActionNode->getPlayer() == 0 ? QObject::tr("IP "):QObject::tr("OOP ")) + \
                       TreeItem::get_game_action_str(actions[i].getAction(),actions[i].getAmount());
            }
        }
    }if(parentNode->getType() == GameTreeNode::GameTreeNodeType::CHANCE){
        shared_ptr<ChanceNode> chanceNode = dynamic_pointer_cast<ChanceNode>(parentNode);
        if(chanceNode->getRound() == GameTreeNode::GameRound::FLOP){
            return QObject::tr("DEAL FLOP CARD");
        }
        else if(chanceNode->getRound() == GameTreeNode::GameRound::TURN){
            return QObject::tr("DEAL TURN CARD");
        }
        else if(chanceNode->getRound() == GameTreeNode::GameRound::RIVER){
            return QObject::tr("DEAL RIVER CARD");
        }else throw runtime_error("round not recognized");
    }
    return "NodeError";
}
```