`compairRanks`: The function of `compairRanks` is to compare the ranks of two cards and return the result of the comparison.

**Parameters**:
`int rank_former`: The rank of the first card.
`int rank_latter`: The rank of the second card.

**Code Description**:
The `compairRanks` function takes two integer parameters, `rank_former` and `rank_latter`, which represent the ranks of two cards. The function then compares the ranks of the two cards and returns a `CompairResult` enum value indicating the result of the comparison.

If `rank_former` is less than `rank_latter`, the function returns `CompairResult::LARGER`, indicating that the second card has a higher rank than the first card. If `rank_former` is greater than `rank_latter`, the function returns `CompairResult::SMALLER`, indicating that the first card has a higher rank than the second card. If `rank_former` is equal to `rank_latter`, the function returns `CompairResult::EQUAL`, indicating that the two cards have the same rank.

The logic behind this comparison is that in the context of the game or application being developed, a lower rank value represents a higher-ranking card. For example, in a standard deck of playing cards, the Ace has the lowest rank value (1) but is the highest-ranking card, while the 2 has the highest rank value (13) but is the lowest-ranking card. By comparing the ranks in this way, the function can determine the relative strength of the two cards.\\
## Code: 
```
Compairer::CompairResult Dic5Compairer::compairRanks(int rank_former, int rank_latter) {
    if (rank_former < rank_latter) {
        // rank更小的牌更大，0是同花顺
        return CompairResult::LARGER;
    } else if (rank_former > rank_latter) {
        return CompairResult::SMALLER;
    } else {
        // rank_former == rank_latter
        return CompairResult::EQUAL;
    }
}
```