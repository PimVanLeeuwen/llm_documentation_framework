`getTrainable`: The function of `getTrainable` is to retrieve a shared pointer to a `Trainable` object, which is stored in the `trainables` vector of the `ActionNode` class. If the requested `Trainable` object does not exist and `create_on_site` is set to `true`, the function will create a new `Trainable` object and store it in the `trainables` vector.

**Parameters**:
`int i`: The index of the `Trainable` object to be retrieved from the `trainables` vector.
`bool create_on_site`: A flag that determines whether a new `Trainable` object should be created if the requested one does not exist.
`int use_halffloats`: A flag that determines the type of `Trainable` object to be created. If the current `GameRound` is `RIVER` and `use_halffloats` is set to a non-zero value, the function will create a `DiscountedCfrTrainableSF` or `DiscountedCfrTrainableHF` object instead of a `DiscountedCfrTrainable` object.

**Code Description**:
1. The function first checks if the requested index `i` is within the bounds of the `trainables` vector. If not, it throws a `runtime_error` exception.
2. If the requested `Trainable` object does not exist (i.e., `trainables[i]` is `nullptr`) and `create_on_site` is set to `true`, the function creates a new `Trainable` object based on the value of `use_halffloats`:
   - If `use_halffloats` is 0, a `DiscountedCfrTrainable` object is created.
   - If `use_halffloats` is 1, a `DiscountedCfrTrainableSF` object is created.
   - If `use_halffloats` is 2, a `DiscountedCfrTrainableHF` object is created.
   The new `Trainable` object is then stored in the `trainables` vector at the requested index `i`.
3.\\
## Code: 
```
shared_ptr<Trainable> ActionNode::getTrainable(int i,bool create_on_site, int use_halffloats) {
    if(i > this->trainables.size()){
        throw runtime_error(tfm::format("size unacceptable %s > %s ",i,this->trainables.size()));
    }
    if(this->trainables[i] == nullptr && create_on_site){
        switch ((this->getRound() == GameTreeNode::RIVER) ? use_halffloats : 0 ){
        case 0:
            this->trainables[i] = make_shared<DiscountedCfrTrainable>(player_privates,*this);
            break;
        case 1:
            this->trainables[i] = make_shared<DiscountedCfrTrainableSF>(player_privates,*this);
            break;
        case 2:
            this->trainables[i] = make_shared<DiscountedCfrTrainableHF>(player_privates,*this);
            break;
        }
    }
    return this->trainables[i];
}
```