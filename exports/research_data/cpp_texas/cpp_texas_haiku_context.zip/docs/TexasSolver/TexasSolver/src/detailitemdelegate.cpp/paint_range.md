`paint_range`: The function of `paint_range` is to paint the range of cards displayed in a table cell of a detail viewer model.

**Parameters**:
`QPainter *painter`: This parameter is a pointer to the QPainter object that will be used to draw the range information in the table cell.
`const QStyleOptionViewItem &option`: This parameter contains the style options for the table cell, such as the size, position, and other visual properties.
`const QModelIndex &index`: This parameter represents the index of the table cell in the detail viewer model.

**Code Description**:
The `paint_range` function first initializes the style options for the table cell using the `initStyleOption` function. It then casts the model associated with the index to a `DetailViewerModel` object.

Next, the function checks if the `tableStrategyModel` associated with the `DetailViewerModel` has a non-null `treeItem`. If so, it retrieves the card coordinates for the player's range based on the current `detailWindowSetting` mode (either RANGE_IP or RANGE_OP).

For each card coordinate, the function calculates the fold probability (1 - range number) and uses it to determine the height of the disabled (folded) portion of the table cell. The remaining height is used to draw a yellow background for the active (non-folded) portion of the range.

The function then formats the card names and the range number as HTML text and displays it in the table cell using a `QTextDocument` object. The text is positioned and clipped within the table cell's rectangle.

Overall, the `paint_range` function is responsible for visually representing the range of cards displayed in a table cell of the detail viewer model, with the fold probability indicated by the height of the disabled portion of the cell.\\
## Code: 
```
void DetailItemDelegate::paint_range(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);

    const DetailViewerModel * detailViewerModel = qobject_cast<const DetailViewerModel*>(index.model());
    //vector<pair<GameActions,float>> strategy = detailViewerModel->tableStrategyModel->get_strategy(this->detailWindowSetting->grid_i,this->detailWindowSetting->grid_j);
    options.text = "";

    if(detailViewerModel->tableStrategyModel->treeItem != NULL){
        vector<pair<int,int>> card_cords;
        if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP){
            card_cords = detailViewerModel->tableStrategyModel->ui_p1_range[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j];
        }else{
            card_cords = detailViewerModel->tableStrategyModel->ui_p2_range[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j];
        }

        int ind = index.row() * detailViewerModel->columns + index.column();
        if(ind < card_cords.size()){
            pair<int,int> cord = card_cords[ind];
            float range_number;
            if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP){
                range_number = detailViewerModel->tableStrategyModel->p1_range[cord.first][cord.second];
            }else{
                range_number = detailViewerModel->tableStrategyModel->p2_range[cord.first][cord.second];
            }

            if(range_number < 0 || range_number > 1) throw runtime_error("range number incorrect in strategyitemdeletage");

            float fold_prob = 1 - range_number;
            int disable_height = (int)(fold_prob * option.rect.height());
            int remain_height = option.rect.height() - disable_height;

            // draw background for flod
            QRect rect(option.rect.left(), option.rect.top() + disable_height,\
             option.rect.width(), remain_height);
            QBrush brush(Qt::yellow);
            painter->fillRect(rect, brush);

            options.text = "";
            options.text += detailViewerModel->tableStrategyModel->cardint2card[cord.first].toFormattedHtml();
            options.text += detailViewerModel->tableStrategyModel->cardint2card[cord.second].toFormattedHtml();
            options.text = "<h2>" + options.text + "<\/h2>";

            options.text +=  QString(" <h2>%1<\/h2>").arg(QString::number(range_number,'f',3));
        }
    }

    QTextDocument doc;
    doc.setHtml(options.text);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```