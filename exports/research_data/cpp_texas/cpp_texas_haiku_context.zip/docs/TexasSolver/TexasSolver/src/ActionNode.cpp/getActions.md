`getActions`: The function of `getActions` is to return a reference to the `actions` vector stored within the `ActionNode` object.

**Code Description**: The `getActions` method is a member function of the `ActionNode` class. It simply returns a reference to the `actions` vector that is stored as a private member variable within the `ActionNode` object. This allows other parts of the code to access and manipulate the `actions` vector associated with the current `ActionNode` instance.\\
## Code: 
```
vector<GameActions>& ActionNode::getActions() {
    return this->actions;
}
```