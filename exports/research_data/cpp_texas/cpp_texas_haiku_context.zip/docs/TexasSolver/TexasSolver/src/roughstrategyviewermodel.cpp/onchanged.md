`onchanged`: The function of `onchanged` is to emit a signal indicating that the header data of the table model has changed.

**Code Description**: The `onchanged` function is a member function of the `RoughStrategyViewerModel` class. It is responsible for notifying the table view that the header data of the model has changed. 

When this function is called, it emits the `headerDataChanged` signal, which is a signal provided by the Qt framework. This signal is used to inform the table view that the header data has been modified, so the view can update its display accordingly.

The `headerDataChanged` signal is emitted with the following arguments:
- `Qt::Horizontal`: This indicates that the header data being changed is the horizontal (column) header.
- `0`: This is the first column index that has changed.
- `columnCount()`: This is the last column index that has changed. The `columnCount()` function is called to retrieve the total number of columns in the table model.

By emitting this signal, the `onchanged` function ensures that the table view is notified of the header data changes, allowing the view to update its display and maintain synchronization with the model.\\
## Code: 
```
void RoughStrategyViewerModel::onchanged(){
    emit headerDataChanged(Qt::Horizontal, 0 , columnCount());
}
```