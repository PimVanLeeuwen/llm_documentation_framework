`paint_evs`: The function of `paint_evs` is to paint the expected value (EV) grid in the strategy table view.

**Parameters**:
`QPainter *painter`: This parameter is a pointer to the QPainter object that will be used to draw the EV grid.
`const QStyleOptionViewItem &option`: This parameter contains the style options for the current view item, which are used to determine the appearance of the item.
`const QModelIndex &index`: This parameter is the model index of the current item in the strategy table, which is used to retrieve the EV values for that item.

**Code Description**:
The `paint_evs` function first initializes the style options for the current view item using the `initStyleOption` function. It then casts the model of the current index to a `TableStrategyModel` object, which is used to retrieve the EV values for the current item.

The function then sorts the EV values in descending order and iterates through them. For each EV value, it normalizes the value using the `normalization_tanh` function, which applies a hyperbolic tangent function to the EV value to produce a normalized value between 0 and 1.

The function then calculates the color of the EV grid cell based on the normalized EV value, with higher values being represented by green and lower values being represented by red. It then draws a rectangular area on the painter with the calculated color and width, where the width is proportional to the position of the EV value in the sorted list.

Finally, the function creates a QTextDocument object and draws the text content of the view item on top of the EV grid, using the `drawContents` function of the QTextDocument object.

Overall, the `paint_evs` function is responsible for rendering the EV grid in the strategy table view, using the EV values retrieved from the `TableStrategyModel` object and applying a color-coded visualization to represent the relative values of the EVs.\\
## Code: 
```
void StrategyItemDelegate::paint_evs(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);
    const TableStrategyModel * tableStrategyModel = qobject_cast<const TableStrategyModel*>(index.model());
    vector<float> evs = tableStrategyModel->get_ev_grid(index.row(),index.column());
    sort(evs.begin(), evs.end());

    int last_left = 0;
    for(std::size_t i = 0;i < evs.size();i ++ ){
        float one_ev = evs[evs.size() - i - 1];
        float normalized_ev = normalization_tanh(this->qSolverJob->stack,one_ev);
        //options.text += QString("</br>%1").arg(QString::number(normalized_ev));

        int red = max((int)(255 - normalized_ev * 255),0);
        int green = min((int)(normalized_ev * 255),255);
        int blue = min(red, green);

        QBrush brush = QBrush(QColor(red,green,blue));

        int this_width = (int)((float(i + 1) / evs.size()) * options.rect.width()) - last_left;

        QRect rect(option.rect.left() + last_left, option.rect.top(),\
             this_width , (int) (options.rect.height()));
        painter->fillRect(rect, brush);
        last_left += this_width;
    }
    QTextDocument doc;
    doc.setHtml(options.text);
    options.text = "";
    //options.widget->style()->drawControl(QStyle::CE_ItemViewItem, &option, painter);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```