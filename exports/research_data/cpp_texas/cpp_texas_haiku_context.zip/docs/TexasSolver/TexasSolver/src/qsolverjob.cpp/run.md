`run`: The function of `run` is to execute the appropriate task based on the current mission type set in the `QSolverJob` class.

**Code Description**: The `run()` method is responsible for executing the necessary tasks based on the current mission type. It checks the value of the `current_mission` variable and calls the corresponding method:

1. If `current_mission` is `MissionType::SOLVING`, it calls the `solving()` method to train the poker solver.
2. If `current_mission` is `MissionType::LOADING`, it calls the `loading()` method to initialize the necessary data structures for the poker solver.
3. If `current_mission` is `MissionType::BUILDTREE`, it calls the `build_tree()` method to build the game tree for the poker solver.
4. If `current_mission` is `MissionType::SAVING`, it calls the `saving()` method to save the strategy of the poker solver to a file.
5. If the `current_mission` is not one of the supported types, it throws a `runtime_error` with the message "unsupported mission type".

The `run()` method is wrapped in a `try-catch` block to handle any runtime errors that may occur during the execution of the tasks. If an error is encountered, it prints the error message to the debug output using `qDebug()`.

Overall, the `run()` method acts as a central dispatcher, routing the execution to the appropriate task based on the current mission type. This design allows the `QSolverJob` class to handle different types of tasks related to the poker solver application.\\
## Code: 
```
void QSolverJob::run()
{
    //QDebugStream qout(qDebug().noquote(), this->textEdit);
    try{
        if(this->current_mission == MissionType::SOLVING){
            this->solving();
        }else if(this->current_mission == MissionType::LOADING){
            this->loading();
        }else if(this->current_mission == MissionType::BUILDTREE){
            this->build_tree();
        }else if(this->current_mission == MissionType::SAVING){
            this->saving();
        }else{
            throw runtime_error("unsupported mission type");
        }
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```