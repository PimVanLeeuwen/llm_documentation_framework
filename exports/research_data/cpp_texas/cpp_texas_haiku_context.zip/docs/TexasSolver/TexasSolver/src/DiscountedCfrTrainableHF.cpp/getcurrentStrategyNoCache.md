`getcurrentStrategyNoCache`: The function of `getcurrentStrategyNoCache` is to calculate and return the current strategy of the DiscountedCfrTrainableHF class without using any cached values.

**Code Description**:

1. The function initializes a vector `current_strategy` of size `action_number * card_number` to store the current strategy.
2. It then calculates two auxiliary vectors: `r_plus_sum` and `r_plus`. `r_plus_sum` stores the sum of the positive values in `r_plus` for each private card, while `r_plus` stores the original `r_plus` values.
3. The function then iterates through all the actions and private cards, and for each index, it calculates the value of the current strategy as follows:
   - If the `r_plus_sum` for the current private card is not zero, the current strategy value is set to the maximum of 0 and the `r_plus` value divided by the `r_plus_sum`.
   - If the `r_plus_sum` for the current private card is zero, the current strategy value is set to 1 divided by the `action_number`.
4. The function also includes a `DEBUG` block that checks if any `r_plus` values are `NaN` (Not a Number) and throws a runtime error if any are found.
5. Finally, the function returns the `current_strategy` vector.

The purpose of this function is to calculate the current strategy of the DiscountedCfrTrainableHF class without using any cached values. This is likely used for debugging or testing purposes, as the cached values would normally be used for efficiency.\\
## Code: 
```
const vector<float> DiscountedCfrTrainableHF::getcurrentStrategyNoCache() {
    vector<float> current_strategy;
    current_strategy = vector<float>(this->action_number * this->card_number);
    // calculate r_plus_sum on the fly, store r_plus as floats locally
    vector<float> r_plus_sum = vector<float>(this->r_plus.size());
    vector<float> r_plus = vector<float>(this->r_plus.size());
    fill(r_plus_sum.begin(),r_plus_sum.end(),0);
    for (int action_id = 0;action_id < action_number;action_id ++) {
        for(int private_id = 0;private_id < this->card_number;private_id ++){
            int index = action_id * this->card_number + private_id;
            float this_r_plus_of_index = this->r_plus[index];
            r_plus_sum[private_id] += max(float(0.0),this_r_plus_of_index);
            r_plus[index] = this_r_plus_of_index;
        }
    }

    for (int action_id = 0; action_id < action_number; action_id++) {
        for (int private_id = 0; private_id < this->card_number; private_id++) {
            int index = action_id * this->card_number + private_id;
            if(r_plus_sum[private_id] != 0) {
                current_strategy[index] = max(float(0.0),r_plus[index]) / r_plus_sum[private_id];
            }else{
                current_strategy[index] = 1.0 / (this->action_number);
            }
#ifdef DEBUG
            if(this->r_plus[index] != this->r_plus[index]) throw runtime_error("nan found");
#endif
        }
    }
```