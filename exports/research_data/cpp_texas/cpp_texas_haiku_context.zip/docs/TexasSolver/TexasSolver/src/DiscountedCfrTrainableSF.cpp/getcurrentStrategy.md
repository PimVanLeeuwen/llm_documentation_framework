`getcurrentStrategy`: The function of `getcurrentStrategy` is to return the current strategy of the `DiscountedCfrTrainableSF` object.

**Code Description**: The `getcurrentStrategy` function simply calls the `getcurrentStrategyNoCache` function and returns its result. The `getcurrentStrategyNoCache` function is responsible for calculating the current strategy for the `DiscountedCfrTrainableSF` object without using any cached values. It iterates through the actions and private cards, calculating the strategy based on the `r_plus` values.\\
## Code: 
```
const vector<float> DiscountedCfrTrainableSF::getcurrentStrategy() {
    return this->getcurrentStrategyNoCache();
}
```