`get_total_strategy`: The function of `get_total_strategy` is to calculate the total strategy for a game tree node in the Texas Solver application.

**Code Description**:

1. The function first checks if the `treeItem` member variable is `NULL`. If it is, it returns an empty vector of `pair<GameActions, pair<float, float>>`.

2. If the `treeItem` is not `NULL`, the function retrieves the `GameTreeNode` object associated with the `treeItem` and casts it to an `ActionNode` object.

3. The function then iterates through the `current_strategy` vector, which contains the current strategy for the game. For each pair of indices in the `current_strategy` vector, it calculates the following:
   - The range of the current player (`p1_range` or `p2_range`) for the given indices.
   - The probability of each game action in the `ActionNode` object, weighted by the corresponding range value.
   - The sum of the weighted probabilities for all game actions.

4. After the iteration, the function calculates the average strategy for each game action by dividing the weighted probabilities by the sum of the weighted probabilities.

5. The function then creates a vector of `pair<GameActions, pair<float, float>>`, where the first element of the pair is the game action, and the second element is a pair containing the total probability of the action (the first float) and the average strategy for the action (the second float).

6. Finally, the function returns the vector of `pair<GameActions, pair<float, float>>`.

The purpose of this function is to calculate the total strategy for a game tree node, which is used to determine the optimal play in the Texas Solver application. The function takes into account the current strategy and the range of the current player to compute the overall strategy for the game tree node.\\
## Code: 
```
const vector<pair<GameActions,pair<float,float>>> TableStrategyModel::get_total_strategy() const{
    vector<pair<GameActions,pair<float,float>>> ret_strategy;
    if(this->treeItem == NULL)return ret_strategy;


    shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();

    if(node->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);
        vector<GameActions>& gameActions = actionNode->getActions();
        int current_player = actionNode->getPlayer();

        vector<float> combos(gameActions.size(),0.0);
        vector<float> avg_strategy(gameActions.size(),0.0);
        float sum_strategy = 0;

        for(std::size_t index1 = 0;index1 < this->current_strategy.size() ;index1 ++){
            for(std::size_t index2 = 0;index2 < this->current_strategy.size() ;index2 ++){
                const vector<float>& one_strategy = this->current_strategy[index1][index2];
                if(one_strategy.empty())continue;

                const vector<vector<float>>& range = current_player == 0? this->p1_range:this->p2_range;
                if(range.size() <= index1 || range[index1].size() < index2) throw runtime_error(" index error when get range in tablestrategymodel");
                const float one_range = range[index1][index2];

                for(std::size_t i = 0;i < one_strategy.size(); i ++ ){
                    float one_prob = one_strategy[i];
                    combos[i] += one_prob * one_range;
                    avg_strategy[i] += one_prob * one_range;
                    sum_strategy += one_prob * one_range;
                }

                if(gameActions.size() != one_strategy.size()){
                    cout << "index: " << index1 << " " << index2 << endl;
                    cout << "size not match between gameAction and stragegy: " << gameActions.size() << " " << one_strategy.size() << endl;
                    throw runtime_error("size not match between gameAction and stragegy");
                }
            }
        }

        for(std::size_t i = 0;i < gameActions.size(); i ++ ){
            avg_strategy[i] = avg_strategy[i] / sum_strategy;
            pair<float,float> statics = pair<float,float>(combos[i],avg_strategy[i]);
            pair<GameActions,pair<float,float>> one_ret = pair<GameActions,pair<float,float>>(gameActions[i],statics);
            ret_strategy.push_back(one_ret);
        }
        return ret_strategy;
    }else{
        return ret_strategy;
    }


}
```