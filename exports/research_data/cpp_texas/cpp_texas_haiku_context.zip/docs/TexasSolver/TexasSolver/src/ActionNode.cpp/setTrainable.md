`setTrainable`: The function of `setTrainable` is to set the `trainables` and `player_privates` member variables of the `ActionNode` class.

**Parameters**:
`vector<shared_ptr<Trainable>> trainables`: This parameter is a vector of shared pointers to `Trainable` objects. These objects likely represent some kind of trainable components or models that are used by the `ActionNode` class.
`vector<PrivateCards>* player_privates`: This parameter is a pointer to a vector of `PrivateCards` objects. These objects likely represent private cards or information associated with individual players in the game or application.

**Code Description**: The `setTrainable` function takes these two parameters and assigns them to the corresponding member variables of the `ActionNode` class. The `trainables` vector is assigned to the `trainables` member variable, and the `player_privates` pointer is assigned to the `player_privates` member variable. This allows the `ActionNode` class to access and use these objects as needed for its functionality.\\
## Code: 
```
void ActionNode::setTrainable(vector<shared_ptr<Trainable>> trainables,vector<PrivateCards>* player_privates) {
    this->trainables = trainables;
    this->player_privates = player_privates;
}
```