`estimate_tree_memory`: The function of `estimate_tree_memory` is to estimate the memory required to store the game tree for a given poker game scenario.

**Parameters**:
`QString range1`: The range of hole cards for the first player.
`QString range2`: The range of hole cards for the second player.
`QString board`: The community cards on the board.

**Code Description**:
The function first checks if the game tree has been built. If not, it prints a debug message and returns 0.

If the game tree has been built, the function proceeds to process the input parameters:
1. It converts the `QString` range and board inputs to `std::string` and `std::vector<int>` formats, respectively.
2. It uses the `PrivateRangeConverter::rangeStr2Cards` function to convert the range strings into vectors of `PrivateCards` objects for each player.
3. Finally, it calls the `estimate_tree_memory` function on the game tree, passing the number of remaining unseen cards, the size of the first player's range, and the size of the second player's range. This function returns the estimated memory required to store the game tree for the given scenario.

The key steps in the code are:
1. Checking if the game tree has been built.
2. Converting the input parameters to the appropriate data structures.
3. Calling the `estimate_tree_memory` function on the game tree to get the estimated memory usage.

This function is likely used to provide an estimate of the memory requirements for a given poker game scenario, which can be useful for planning and optimizing the performance of the poker solver application.\\
## Code: 
```
long long PokerSolver::estimate_tree_memory(QString range1,QString range2,QString board){
    if(this->game_tree == nullptr){
        qDebug().noquote() << QObject::tr("Please buld tree first.");
        return 0;
    }
    else{
        string player1RangeStr = range1.toStdString();
        string player2RangeStr = range2.toStdString();

        vector<string> board_str_arr = string_split(board.toStdString(),',');
        vector<int> initialBoard;
        for(string one_board_str:board_str_arr){
            initialBoard.push_back(Card::strCard2int(one_board_str));
        }

        vector<PrivateCards> range1 = PrivateRangeConverter::rangeStr2Cards(player1RangeStr,initialBoard);
        vector<PrivateCards> range2 = PrivateRangeConverter::rangeStr2Cards(player2RangeStr,initialBoard);
        return this->game_tree->estimate_tree_memory(this->deck.getCards().size() - initialBoard.size(),range1.size(),range2.size());
    }
}
```