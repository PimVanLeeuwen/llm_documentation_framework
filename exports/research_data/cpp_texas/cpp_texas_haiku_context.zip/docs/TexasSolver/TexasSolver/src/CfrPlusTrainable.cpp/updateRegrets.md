`updateRegrets`: The function of `updateRegrets` is to update the regrets and cumulative regrets for each action and private card in the game.

**Parameters**:
`const vector<float>& regrets`: This parameter represents the current regrets for each action and private card combination.
`int iteration_number`: This parameter represents the current iteration number of the training process.
`const vector<float>& reach_probs`: This parameter represents the reach probabilities for each private card.

**Code Description**:
1. The function first assigns the `regrets` parameter to the `regrets` member variable of the `CfrPlusTrainable` class.
2. It then checks if the length of the `regrets` vector matches the expected length, which is the product of the `action_number` and `card_number` member variables. If the lengths do not match, it throws a `runtime_error`.
3. The function then initializes the `r_plus_sum` and `cum_r_plus_sum` vectors to all zeros.
4. It then iterates over all the actions and private cards, and for each combination, it performs the following steps:
   - Calculates the index of the current action and private card combination in the `regrets` vector.
   - Updates the `r_plus` value for the current combination by taking the maximum of 0 and the sum of the current regret and the previous `r_plus` value.
   - Adds the current `r_plus` value to the `r_plus_sum` for the current private card.
   - Adds the current `r_plus` value multiplied by the `iteration_number` to the `cum_r_plus` for the current combination.
   - Adds the current `cum_r_plus` value to the `cum_r_plus_sum` for the current private card.
5. The function does not return any value, but it updates the `regrets`, `r_plus`, `r_plus_sum`, `cum_r_plus`, and `cum_r_plus_sum` member variables of the `CfrPlusTrainable` class.

The purpose of this function is to update the regrets and cumulative regrets for each action and private card combination based on\\
## Code: 
```
void CfrPlusTrainable::updateRegrets(const vector<float>& regrets, int iteration_number, const vector<float>& reach_probs) {
    this->regrets = regrets;
    if(regrets.size() != this->action_number * this->card_number) throw runtime_error("length not match");

    //Arrays.fill(this.r_plus_sum,0);
    fill(r_plus_sum.begin(),r_plus_sum.end(),0);
    fill(cum_r_plus_sum.begin(),cum_r_plus_sum.end(),0);
    for (int action_id = 0;action_id < action_number;action_id ++) {
        for(int private_id = 0;private_id < this->card_number;private_id ++){
            int index = action_id * this->card_number + private_id;
            float one_reg = regrets[index];

            // 更新 R+
            this->r_plus[index] = max((float)0.0,one_reg + this->r_plus[index]);
            this->r_plus_sum[private_id] += this->r_plus[index];

            // 更新累计策略
            this->cum_r_plus[index] += this->r_plus[index] * iteration_number;
            this->cum_r_plus_sum[private_id] += this->cum_r_plus[index];
        }
    }
}
```