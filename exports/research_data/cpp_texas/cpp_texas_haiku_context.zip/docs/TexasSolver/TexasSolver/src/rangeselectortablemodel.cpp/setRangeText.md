`setRangeText`: The function of `setRangeText` is to set the range values in a 2D array based on the input range string.

**Parameters**:
`QString input_range`: This parameter represents the input range string, which is a comma-separated list of ranges. Each range can be a single value or a range of values separated by a colon.

**Code Description**:
1. The function first clears the existing range values in the `grids_float` 2D array by calling the `clear_range()` method.
2. It then splits the input range string by commas to get individual ranges.
3. For each individual range, the function checks if it has a valid format (i.e., contains one or two parts separated by a colon).
4. If the range format is valid, the function extracts the key range and checks if it exists in the `string2ij` map, which maps string keys to row and column indices.
5. If the key range is not found in the `string2ij` map, the function appends "o" and "s" to the key range and checks for those keys instead.
6. For each valid key, the function retrieves the corresponding row and column indices from the `string2ij` map and sets the value in the `grids_float` 2D array to the specified range value (or 1.0 if no range value is provided).
7. If the range format is invalid or the key is not found in the `string2ij` map, the function logs a debug message and skips the range.

Overall, the `setRangeText` function is responsible for parsing the input range string and updating the corresponding values in the `grids_float` 2D array based on the provided ranges.\\
## Code: 
```
void RangeSelectorTableModel::setRangeText(QString input_range){
    this->clear_range();
    for(QString one_range:input_range.split(",")){
        if(one_range.trimmed() == "")continue;
        QStringList one_range_list = one_range.split(":");

        if(one_range_list.size() > 2 || one_range_list.size() < 1){
            qDebug().noquote() << QString(tr("skipping range %1, format error, range list should contain two part seperate by ':'")).arg(one_range);
        }

        float range_float = 1.0;
        QString key_range = one_range_list[0];
        QStringList keys;
        if(this->string2ij.count(one_range_list[0])){
            keys.append(key_range);
        }else{
            keys.append(key_range + "o");
            keys.append(key_range + "s");
        }

        for(QString one_key: keys){
            if(one_key.count(" ") == one_key.length() || one_key == "")continue;
            if(!this->string2ij.count(one_key)){
                qDebug().noquote() << QString(tr("skipping range %1, format error")).arg(one_range);
                continue;
            }
            pair<int,int> cord = this->string2ij[one_key];
            if(one_range_list.size() > 1)range_float = one_range_list[1].toFloat();
            this->grids_float[cord.first][cord.second] = range_float;
        }
    }
}
```