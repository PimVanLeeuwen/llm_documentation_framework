`PrivateCards`: The function of `PrivateCards` is to create an object that represents a pair of private cards in a Texas Hold'em poker game.

**Parameters**:
`int card1`: The first card in the pair of private cards.
`int card2`: The second card in the pair of private cards.
`float weight`: The weight or importance associated with this pair of private cards.

**Code Description**:
The `PrivateCards` constructor initializes the following member variables:
- `card1`: Stores the first card in the pair.
- `card2`: Stores the second card in the pair.
- `weight`: Stores the weight or importance associated with this pair of private cards.
- `relative_prob`: Initializes the relative probability to 0.
- `card_vec`: Creates a vector containing the two card IDs (`card1` and `card2`).
- `hash_code`: Calculates a unique hash code for the pair of cards by multiplying the larger card ID by 52 and adding the smaller card ID. This ensures that the hash code is unique for each possible combination of two cards.
- `board_long`: Converts the vector of card IDs (`card_vec`) into a single 64-bit unsigned integer representation using the `Card::boardInts2long` function. This function is likely used to efficiently store and compare the board state.

The purpose of this class is to encapsulate the information about a pair of private cards, including their IDs, weight, and a unique hash code. This information can be used in a Texas Hold'em poker solver or analysis application to represent and manipulate the private cards held by a player.\\
## Code: 
```
PrivateCards::PrivateCards(int card1, int card2, float weight) {
    this->card1 = card1;
    this->card2 = card2;
    this->weight = weight;
    this->relative_prob = 0;
    this->card_vec = vector<int>{this->card1,this->card2};
    if (card1 > card2){
        this->hash_code = card1 * 52 + card2;
    }else{
        this->hash_code = card2 * 52 + card1;
    }
    this->board_long = Card::boardInts2long(this->card_vec);
}
```