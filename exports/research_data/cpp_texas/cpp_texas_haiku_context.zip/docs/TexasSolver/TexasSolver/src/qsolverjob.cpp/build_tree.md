`build_tree`: The function of `build_tree` is to build the game tree for the current poker game mode, either Texas Hold'em or Short Deck.

**Code Description**: The `build_tree` function is responsible for constructing the game tree for the current poker game mode. It first prints a debug message indicating that the tree is being built. Then, it checks the current game mode and calls the appropriate `build_game_tree` function from the `PokerSolver` class, passing in the relevant parameters such as the commitment amounts, current round, raise limit, blind sizes, stack sizes, and the game tree builder object.

The `build_game_tree` function is responsible for creating a new `GameTree` object and initializing it with the provided parameters. This `GameTree` object represents the complete game tree for the current poker game setup, which can be used for further analysis and decision-making.

After the game tree has been built, the function prints another debug message indicating that the tree building process has finished.

The code is designed to be flexible and support different poker game modes, as evidenced by the conditional statements that check the current mode and call the appropriate `build_game_tree` function. This allows the `build_tree` function to be used for both Texas Hold'em and Short Deck poker games.\\
## Code: 
```
void QSolverJob::build_tree(){
    qDebug().noquote() << tr("building tree..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        ps_holdem.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }else if(this->mode == Mode::SHORTDECK){
        ps_shortdeck.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }
    qDebug().noquote() << tr("build tree finished");//.toStdString() << endl;
}
```