`getReachProbs`: The function of `getReachProbs` is to calculate the reach probabilities for each player's private cards.

**Code Description**: The `getReachProbs` method in the `PCfrSolver` class calculates the reach probabilities for each player's private cards. It does this by:

1. Initializing a 2D vector `retval` with a size equal to the number of players.
2. Iterating through each player (from 0 to `player_number - 1`).
3. For each player, it calls the `playerHands` method to get the vector of `PrivateCards` for that player.
4. It then creates a vector `reach_prob` of the same size as the `player_cards` vector, and fills it with the `weight` values of each `PrivateCards` object.
5. The `reach_prob` vector is then stored in the corresponding row of the `retval` 2D vector.
6. Finally, the `retval` 2D vector is returned, containing the reach probabilities for each player's private cards.

The `getReachProbs` method is likely used to calculate the reach probabilities for each player's private cards, which can be used in further calculations or analysis related to the Texas Hold'em poker game.\\
## Code: 
```
vector<vector<float>> PCfrSolver::getReachProbs() {
    vector<vector<float>> retval(this->player_number);
    for(int player = 0;player < this->player_number;player ++){
        vector<PrivateCards> player_cards = this->playerHands(player);
        vector<float> reach_prob(player_cards.size());
        for(std::size_t i = 0;i < player_cards.size();i ++){
            reach_prob[i] = player_cards[i].weight;
        }
        retval[player] = reach_prob;
    }
    return retval;
}
```