`get_game_action_str`: The function of `get_game_action_str` is to return a QString (a Qt string type) that represents the given poker action and amount.

**Parameters**:
`GameTreeNode::PokerActions action`: This parameter represents the poker action to be converted to a string. The possible actions are CHECK, BET, RAISE, FOLD, and CALL.
`float amount`: This parameter represents the amount associated with the poker action, such as the bet or raise amount.

**Code Description**:
The function uses a series of `if-else` statements to determine the appropriate string representation for the given poker action:

1. If the action is `CHECK`, the function returns the string "CHECK".
2. If the action is `BET`, the function returns the string "BET " followed by the amount.
3. If the action is `RAISE`, the function returns the string "RAISE " followed by the amount.
4. If the action is `FOLD`, the function returns the string "FOLD ".
5. If the action is `CALL`, the function returns the string "CALL".
6. If the action is none of the above, the function throws a `runtime_error` with the message "unknown action when converting in get_game_action_str".

The function uses the `QObject::tr()` function to provide translation support for the string representations of the poker actions.\\
## Code: 
```
QString TreeItem::get_game_action_str(GameTreeNode::PokerActions action,float amount) const{
    if(action == GameTreeNode::PokerActions::CHECK){
        return QObject::tr("CHECK");
    }
    else if(action == GameTreeNode::PokerActions::BET){
        return QObject::tr("BET ") + QString::number(amount);
    }
    else if(action == GameTreeNode::PokerActions::RAISE){
        return QObject::tr("RAISE ") + QString::number(amount);
    }
    else if(action == GameTreeNode::PokerActions::FOLD){
        return QObject::tr("FOLD ");
    }
    else if(action == GameTreeNode::PokerActions::CALL){
        return QObject::tr("CALL");
    }else{
        throw runtime_error("unknown action when converting in get_game_action_str");
    }

}
```