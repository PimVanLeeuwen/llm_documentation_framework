`getAverageStrategy`: The function of `getAverageStrategy` is to return the current strategy of the player.

**Code Description**: The `getAverageStrategy` method is defined in the `CfrPlusTrainable` class. It is responsible for calculating and returning the average strategy of the player based on the values stored in the `cum_r_plus` and `cum_r_plus_sum` vectors.

The method first initializes a vector `retval` with a size equal to the product of the `action_number` and `card_number` variables. If the `cum_r_plus_sum` vector is empty or all its elements are zero, the method fills the `retval` vector with equal probabilities (1.0 / `action_number`) for each action.

Otherwise, the method iterates through each action and private card ID, and calculates the average strategy for each combination. If the corresponding `cum_r_plus_sum` value is not zero, the method sets the `retval` element to the ratio of the `cum_r_plus` value to the `cum_r_plus_sum` value. If the `cum_r_plus_sum` value is zero, the method sets the `retval` element to the equal probability (1.0 / `action_number`).

Finally, the method returns the `retval` vector, which represents the current average strategy of the player.

The commented-out code in the method suggests that the original implementation was different, but the current implementation simply calls the `getcurrentStrategy()` method to obtain the current strategy.\\
## Code: 
```
const vector<float> CfrPlusTrainable::getAverageStrategy() {
    /*
    vector<float> retval(this->action_number * this->card_number);
    if(this->cum_r_plus_sum.empty() || this->isAllZeros(this->cum_r_plus_sum)){
        fill(retval.begin(),retval.end(),1.0 / this->action_number);
    }else {
        for (int action_id = 0; action_id < action_number; action_id++) {
            for (int private_id = 0; private_id < this->card_number; private_id++) {
                int index = action_id * this->card_number + private_id;
                if(this->cum_r_plus_sum[private_id] != 0) {
                    retval[index] = this->cum_r_plus[index] / this->cum_r_plus_sum[private_id];
                }else{
                    retval[index] = 1.0 / this->action_number;
                }
            }
        }
    }
    */
    return this->getcurrentStrategy();
}
```