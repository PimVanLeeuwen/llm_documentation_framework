`getRound`: The function of `getRound` is to return the current round of the game.

**Code Description**: The `getRound` method is a member function of the `GameTreeNode` class. It simply returns the value of the `round` member variable of the current `GameTreeNode` object. The `round` variable likely represents the current round or turn of the game being played. By calling this method, the caller can retrieve the current round information for the game state represented by this `GameTreeNode`.\\
## Code: 
```
GameTreeNode::GameRound GameTreeNode::getRound() {
    return this->round;
}
```