`toString`: The function of `toString` is to return a string representation of the `GameActions` object.

**Code Description**: The `toString` function in the `GameActions` class is responsible for generating a string representation of the `GameActions` object. The function checks the value of the `amount` member variable:

1. If `amount` is `-1`, the function calls the `pokerActionToString` function and returns the string representation of the `action` member variable.
2. If `amount` is not `-1`, the function calls the `pokerActionToString` function and appends the string representation of the `action` member variable with the string representation of the `amount` member variable.

The `pokerActionToString` function is a helper function that takes a `GameTreeNode::PokerActions` enum value and returns a corresponding string representation of the action. This function is used to convert the `action` member variable of the `GameActions` object into a human-readable string.

The purpose of the `toString` function is to provide a way to easily represent the `GameActions` object as a string, which can be useful for logging, debugging, or displaying the object's information in a user interface.\\
## Code: 
```
string GameActions::toString() {
    if(this->amount == -1) {
        return this->pokerActionToString(this->action);
    }else{
        return this->pokerActionToString(this->action) + " " + to_string(amount);
    }
}
```