`estimate_tree_memory`: The function of `estimate_tree_memory` is to estimate the memory required for the game tree based on the given parameters.

**Parameters**:
`QString range1`: The first player's range of possible hole cards.
`QString range2`: The second player's range of possible hole cards.
`QString board`: The community cards on the board.

**Code Description**: The `estimate_tree_memory` function first prints a debug message indicating that it is estimating the tree memory. Then, it checks the current mode of the `QSolverJob` object, which can be either `HOLDEM` (for Texas Hold'em) or `SHORTDECK` (for Short Deck Poker). Depending on the mode, the function calls the corresponding `estimate_tree_memory` function from either `ps_holdem` or `ps_shortdeck` objects, passing the `range1`, `range2`, and `board` parameters. The result of the estimation is then returned as a `long long` value.\\
## Code: 
```
long long QSolverJob::estimate_tree_memory(QString range1,QString range2,QString board){
    qDebug().noquote() << tr("Estimating tree memory..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        return ps_holdem.estimate_tree_memory(range1,range2,board);
    }else if(this->mode == Mode::SHORTDECK){
        return ps_shortdeck.estimate_tree_memory(range1,range2,board);
    }
    return 0;
}
```