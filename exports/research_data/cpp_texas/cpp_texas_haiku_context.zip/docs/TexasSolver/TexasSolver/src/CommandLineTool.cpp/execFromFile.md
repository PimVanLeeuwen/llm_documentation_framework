`execFromFile`: The function of `execFromFile` is to read and process commands from a file.

**Parameters**:
`string input_file`: The path to the input file containing the commands to be processed.

**Code Description**: The `execFromFile` method takes a file path as input and reads each line from the file using a `std::ifstream` object. For each line, it calls the `processCommand` method to handle the command. This allows the user to execute a series of commands from a file, rather than having to enter them individually on the command line.\\
## Code: 
```
void CommandLineTool::execFromFile(string input_file){
    std::ifstream infile(input_file);
    std::string input_line;
    while (std::getline(infile, input_line))
    {
        this->processCommand(input_line);
    }

}
```