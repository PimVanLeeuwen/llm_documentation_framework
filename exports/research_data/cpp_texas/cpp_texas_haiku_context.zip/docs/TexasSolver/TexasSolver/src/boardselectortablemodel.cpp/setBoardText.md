`setBoardText`: The function of `setBoardText` is to update the values of a 2D grid based on the input string `input_board`.

**Parameters**:
`QString input_board`: This parameter represents a string containing a comma-separated list of board positions. Each board position is represented as a string, such as "A1" or "D5".

**Code Description**:
1. The function first calls the `clear_board()` method to reset the values of the 2D grid stored in the `grids_float` member variable.
2. It then splits the `input_board` string on the comma character to get a list of individual board positions.
3. For each board position in the list:
   - If the board position is empty or consists of only spaces, the function skips it and moves on to the next position.
   - If the board position is not in the `string2ij` map (which maps board position strings to row and column indices), the function logs a debug message and skips the position.
   - If the board position is valid, the function retrieves the corresponding row and column indices from the `string2ij` map and sets the value of the `grids_float` grid at that position to 1.0.

The purpose of this function is to update the internal representation of a game board based on the input string provided. The `grids_float` member variable is likely used elsewhere in the application to display or manipulate the game board.\\
## Code: 
```
void BoardSelectorTableModel::setBoardText(QString input_board){
    this->clear_board();
    for(QString one_board:input_board.split(",")){
        float board_float = 1.0;


        if(one_board.count(" ") == one_board.length() || one_board == "")continue;
        if(!this->string2ij.count(one_board)){
            qDebug().noquote() << QString(tr("skipping board %1, format error")).arg(one_board);
            continue;
        }
        pair<int,int> cord = this->string2ij[one_board];
        this->grids_float[cord.first][cord.second] = board_float;
    }
}
```