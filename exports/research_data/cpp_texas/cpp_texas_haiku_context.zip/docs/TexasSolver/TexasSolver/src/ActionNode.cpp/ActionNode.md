`ActionNode`: The function of `ActionNode` is to create a node in a game tree that represents a set of possible actions that a player can take during a game round.

**Parameters**:
`vector<GameActions> actions`: This parameter represents the set of actions that the player can take at this node in the game tree.
`vector<shared_ptr<GameTreeNode>> childrens`: This parameter represents the child nodes of the current node, which represent the possible outcomes of the player's actions.
`int player`: This parameter represents the player whose turn it is at this node in the game tree.
`GameTreeNode::GameRound round`: This parameter represents the current round of the game.
`double pot`: This parameter represents the current size of the pot in the game.
`shared_ptr<GameTreeNode> parent`: This parameter represents the parent node of the current node in the game tree.

**Code Description**: The `ActionNode` constructor initializes an instance of the `ActionNode` class, which is a subclass of the `GameTreeNode` class. The constructor takes the following parameters:

1. `vector<GameActions> actions`: This parameter represents the set of actions that the player can take at this node in the game tree.
2. `vector<shared_ptr<GameTreeNode>> childrens`: This parameter represents the child nodes of the current node, which represent the possible outcomes of the player's actions.
3. `int player`: This parameter represents the player whose turn it is at this node in the game tree.
4. `GameTreeNode::GameRound round`: This parameter represents the current round of the game.
5. `double pot`: This parameter represents the current size of the pot in the game.
6. `shared_ptr<GameTreeNode> parent`: This parameter represents the parent node of the current node in the game tree.

The constructor initializes the `actions`, `player`, `childrens`, and `round`, `pot`, and `parent` member variables of the `ActionNode` class using the provided parameters. The `GameTreeNode` constructor is also called with the `round`, `pot`, and `parent` parameters to initialize the base class.

The purpose of the `ActionNode` class is to represent a node in a game tree that corresponds to a set of possible actions that a player can take during\\
## Code: 
```
ActionNode::ActionNode(vector<GameActions> actions, vector<shared_ptr<GameTreeNode>> childrens, int player,
                       GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent) :GameTreeNode(round,pot,std::move(parent)){
    this->actions = std::move(actions);
    this->player = player;
    this->childrens = std::move(childrens);
    //cout << "ActionNode created" << endl;
}
```