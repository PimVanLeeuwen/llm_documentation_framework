`toString`: The function of `toString` is to convert the two private card values stored in the `PrivateCards` object to a string representation.

**Code Description**: The `toString` method in the `PrivateCards` class is responsible for converting the two private card values (`card1` and `card2`) into a string representation. The method first checks if `card1` is greater than `card2`. If so, it calls the `intCard2Str` method from the `Card` class to convert `card1` and `card2` to their string representations and concatenates them in that order. If `card2` is greater than or equal to `card1`, it calls the `intCard2Str` method to convert `card2` and `card1` to their string representations and concatenates them in that order.

The `intCard2Str` method in the `Card` class is responsible for converting an integer card value to a string representation of the card, including both the rank and suit. It does this by extracting the rank and suit from the integer value and using the `rankToString` and `suitToString` methods to get the corresponding string representations.

The purpose of this `toString` method is to provide a convenient way to represent the two private card values stored in the `PrivateCards` object as a single string, which can be useful for various purposes, such as displaying the cards or storing them in a database.\\
## Code: 
```
string PrivateCards::toString() {
    if (card1 > card2) {
        return Card::intCard2Str(card1) + Card::intCard2Str(card2);
    }else{
        return Card::intCard2Str(card2) + Card::intCard2Str(card1);
    }
}
```