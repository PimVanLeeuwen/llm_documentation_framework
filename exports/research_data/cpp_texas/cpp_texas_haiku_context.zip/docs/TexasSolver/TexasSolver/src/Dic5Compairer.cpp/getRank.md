`getRank`: The function of `getRank` is to find the highest poker hand rank among all possible 5-card combinations from the given vector of cards.

**Parameters**:
`vector<Card> cards`: This parameter represents a vector of `Card` objects, which contain the cards to be evaluated for their poker hand rank.

**Code Description**:
The `getRank` function first creates a new vector `cards_int` of the same size as the input `cards` vector. It then iterates through the `cards` vector and populates the `cards_int` vector with the integer values of each `Card` object using the `getCardInt()` method.

After creating the `cards_int` vector, the function calls another `getRank` method (likely overloaded) that takes a vector of integers as input. This suggests that the actual logic for determining the poker hand rank is implemented in the other `getRank` method, which is likely defined elsewhere in the codebase.

The purpose of this particular `getRank` method is to provide a convenient way to convert the input `vector<Card>` into a `vector<int>` before calling the main `getRank` implementation. This abstraction allows the caller to work with `Card` objects directly, without needing to worry about the underlying integer representation.

Overall, the `getRank` function is a helper method that simplifies the process of evaluating the poker hand rank for a given set of cards, by handling the conversion from `Card` objects to their integer representations.\\
## Code: 
```
int Dic5Compairer::getRank(vector<Card> cards) {
    vector<int> cards_int(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_int[i] = cards[i].getCardInt();
    }
    return this->getRank(cards_int);
}
```