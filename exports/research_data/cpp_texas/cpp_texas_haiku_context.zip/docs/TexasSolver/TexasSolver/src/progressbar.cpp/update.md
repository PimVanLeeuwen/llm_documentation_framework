`update`: The function of `update` is to update the progress bar displayed in the console.

**Code Description**:

The `update()` function is responsible for updating the progress bar displayed in the console. It performs the following tasks:

1. Checks if the number of cycles has been set. If not, it throws a `std::runtime_error` exception.
2. Checks if the `update_is_called` flag is false. If so, it prints the opening bracket, 50 "todo_char" characters, and the closing bracket followed by "0%" to represent the initial state of the progress bar.
3. Updates the `update_is_called` flag to true.
4. Calculates the current percentage of progress based on the `progress` variable and the `n_cycles` variable.
5. If the current percentage is less than the last displayed percentage, the function returns without doing anything.
6. If the current percentage has increased by 1 unit, it updates the percentage display by erasing the previous percentage and printing the new one.
7. If the `do_show_bar` flag is true, it updates the progress bar visualization by:
   - Erasing the closing bracket and the trailing percentage characters.
   - Erasing the appropriate number of "todo_char" characters and replacing them with "done_char" characters to represent the progress.
   - Refilling the remaining "todo_char" characters.
   - Printing the closing bracket and the updated percentage.
8. Updates the `last_perc` variable with the current percentage.
9. Increments the `progress` variable.
10. Flushes the output stream to ensure the updates are immediately visible.

The purpose of this function is to provide a visual representation of the progress of a task or operation. It allows the user to see the current state of the progress and how much of the task has been completed.\\
## Code: 
```
void progressbar::update() {
    return;
    if (n_cycles == 0) throw std::runtime_error(
                "progressbar::update: number of cycles not set");

    if (!update_is_called) {
        if (do_show_bar == true) {
            std::cout << opening_bracket_char;
            for (int _ = 0; _ < 50; _++) std::cout << todo_char;
            std::cout << closing_bracket_char << " 0%";
        }
        else std::cout << "0%";
    }
    update_is_called = true;

    int perc = 0;

    // compute percentage, if did not change, do nothing and return
    perc = progress*100./(n_cycles-1);
    if (perc < last_perc) return;

    // update percentage each unit
    if (perc == last_perc + 1) {
        // erase the correct  number of characters
        if      (perc <= 10)                std::cout << "\b\b"   << perc << '%';
        else if (perc  > 10 && perc < 100) std::cout << "\b\b\b" << perc << '%';
        else if (perc == 100)               std::cout << "\b\b\b" << perc << '%';
    }
    if (do_show_bar == true) {
        // update bar every ten units
        if (perc % 2 == 0) {
            // erase closing bracket
            std::cout << std::string(closing_bracket_char.size(), '\b');
            // erase trailing percentage characters
            if      (perc  < 10)               std::cout << "\b\b\b";
            else if (perc >= 10 && perc < 100) std::cout << "\b\b\b\b";
            else if (perc == 100)              std::cout << "\b\b\b\b\b";

            // erase 'todo_char'
            for (int j = 0; j < 50-(perc-1)/2; ++j) {
                std::cout << std::string(todo_char.size(), '\b');
            }

            // add one additional 'done_char'
            if (perc == 0) std::cout << todo_char;
            else           std::cout << done_char;

            // refill with 'todo_char'
            for (int j = 0; j < 50-(perc-1)/2-1; ++j) std::cout << todo_char;

            // readd trailing percentage characters
            std::cout << closing_bracket_char << ' ' << perc << '%';
        }
    }
    last_perc = perc;
    ++progress;
    std::cout << std::flush;

    return;
}
```