`clear_range`: The function of `clear_range` is to reset all the values in the `grids_float` 2D array to 0.

**Code Description**: The `clear_range` function is a method of the `RangeSelectorTableModel` class. It is responsible for clearing the values in the `grids_float` 2D array, which is likely used to store some data related to a range selector table.

The function uses two nested loops to iterate through the `ranklist` array, which is likely a list of ranges or some other data structure. For each element in the `ranklist`, the function sets the corresponding value in the `grids_float` 2D array to 0.

This function is likely used to reset the state of the range selector table, for example, when the user wants to start a new selection or clear the current selection.\\
## Code: 
```
void RangeSelectorTableModel::clear_range(){
    for(int i = 0;i < this->ranklist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_float[i][j] = 0;
        }
    }
}
```