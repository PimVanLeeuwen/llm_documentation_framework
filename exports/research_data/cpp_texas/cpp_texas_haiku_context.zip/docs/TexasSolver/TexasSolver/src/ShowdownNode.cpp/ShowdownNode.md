`ShowdownNode`: The function of `ShowdownNode` is to create a new instance of the `GameTreeNode` class, which represents a node in a game tree, specifically for a showdown scenario in a game.

**Parameters**:
`vector<double> tie_payoffs`: This parameter represents the payoffs for each player in the event of a tie.
`vector<vector<double>> player_payoffs`: This parameter represents the payoffs for each player based on their individual hands.
`GameTreeNode::GameRound round`: This parameter represents the current round of the game.
`double pot`: This parameter represents the current pot size in the game.
`shared_ptr<GameTreeNode>parent`: This parameter represents the parent node of the current node in the game tree.

**Code Description**: The `ShowdownNode` constructor initializes a new instance of the `GameTreeNode` class, passing the `round`, `pot`, and `parent` parameters to the base class constructor. It then sets the `tie_payoffs` and `player_payoffs` member variables to the values passed in the corresponding parameters.

The purpose of the `ShowdownNode` class is to represent a node in the game tree where the game has reached a showdown, where the players' hands are revealed, and the payoffs are determined based on the relative strength of the hands. The `tie_payoffs` and `player_payoffs` parameters are used to store the payoff information for the showdown scenario, which can be used by the game engine to determine the outcome of the game and update the game state accordingly.\\
## Code: 
```
ShowdownNode::ShowdownNode(vector<double> tie_payoffs, vector<vector<double>> player_payoffs,
                           GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode>parent):
                           GameTreeNode(round,pot,std::move(parent)) {
    this->tie_payoffs = std::move(tie_payoffs);
    this->player_payoffs = std::move(player_payoffs);
}
```