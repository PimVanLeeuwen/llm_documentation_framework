`get_setting`: The function of `get_setting` is to retrieve the appropriate `StreetSetting` object based on the provided `player` and `round` parameters.

**Parameters**:
`string player`: The player position, either "ip" (in-position) or "oop" (out-of-position).
`string round`: The game round, either "flop", "turn", or "river".

**Code Description**:
The `get_setting` function takes two string parameters, `player` and `round`, and returns the corresponding `StreetSetting` object. It uses a series of `if-else` statements to determine which `StreetSetting` object to return based on the provided `player` and `round` values.

- If the `player` is "ip" (in-position) and the `round` is "flop", the function returns the `flop_ip` `StreetSetting` object.
- If the `player` is "ip" and the `round` is "turn", the function returns the `turn_ip` `StreetSetting` object.
- If the `player` is "ip" and the `round` is "river", the function returns the `river_ip` `StreetSetting` object.
- If the `player` is "oop" (out-of-position) and the `round` is "flop", the function returns the `flop_oop` `StreetSetting` object.
- If the `player` is "oop" and the `round` is "turn", the function returns the `turn_oop` `StreetSetting` object.
- If the `player` is "oop" and the `round` is "river", the function returns the `river_oop` `StreetSetting` object.

If the provided `player` and `round` combination is not valid, the function throws a `runtime_error` with the message "get_setting not valid".

The purpose of this function is to provide a centralized way to retrieve the appropriate `StreetSetting` object based on the player's position and the current game round. This allows the rest of the code to work with the correct `StreetSetting`\\
## Code: 
```
StreetSetting& GameTreeBuildingSettings::get_setting(string player,string round){
    if(player == "ip" && round == "flop") return flop_ip;
    else if(player == "ip" && round == "turn") return turn_ip;
    else if(player == "ip" && round == "river") return river_ip;
    else if(player == "oop" && round == "flop") return flop_oop;
    else if(player == "oop" && round == "turn") return turn_oop;
    else if(player == "oop" && round == "river") return river_oop;
    else throw runtime_error("get_setting not valid");
}
```