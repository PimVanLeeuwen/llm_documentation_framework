`DiscountedCfrTrainableSF`: The function of `DiscountedCfrTrainableSF` is to initialize and store various data structures related to the discounted counterfactual regret minimization (DCFR) algorithm for a given `ActionNode` and a set of `PrivateCards`.

**Parameters**:
`vector<PrivateCards> *privateCards`: This parameter represents a pointer to a vector of `PrivateCards` objects, which likely contain information about the private cards held by each player in the game.
`ActionNode &actionNode`: This parameter is a reference to an `ActionNode` object, which represents a node in the game tree where a player can take an action.

**Code Description**:
The `DiscountedCfrTrainableSF` constructor initializes the following data structures:
1. `this->privateCards`: A pointer to the `privateCards` vector passed as a parameter.
2. `this->action_number`: The number of child nodes (actions) associated with the `actionNode` passed as a parameter, obtained by calling the `getChildrens` method.
3. `this->card_number`: The size of the `privateCards` vector, which represents the number of private cards.
4. `this->evs`: A vector of `EvsStorage` (likely a custom data type) with a size equal to the product of `action_number` and `card_number`. This vector is used to store the expected values (EVs) for each action-card combination.
5. `this->r_plus`: A vector of `RplusStorage` (likely a custom data type) with a size equal to the product of `action_number` and `card_number`. This vector is used to store the positive regret values for each action-card combination.
6. `this->cum_r_plus`: A vector of `CumRplusStorage` (likely a custom data type) with a size equal to the product of `action_number` and `card_number`. This vector is used to store the cumulative positive regret values for each action-card combination.

The purpose of these data structures is to facilitate the implementation of the DCFR algorithm, which is a reinforcement learning technique used in game theory to fin\\
## Code: 
```
DiscountedCfrTrainableSF::DiscountedCfrTrainableSF(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();
    this->evs = vector<EvsStorage>(this->action_number * this->card_number, (EvsStorage) 0.0);
    this->r_plus = vector<RplusStorage>(this->action_number * this->card_number, (RplusStorage) 0.0);
    this->cum_r_plus = vector<CumRplusStorage>(this->action_number * this->card_number, (CumRplusStorage) 0.0);
}
```