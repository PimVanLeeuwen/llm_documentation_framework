`StreetSetting`: The function of `StreetSetting` is to initialize and store the betting parameters for a specific street setting in a poker game.

**Parameters**:
`vector<float> bet_sizes`: This parameter represents a vector of floating-point values that define the possible bet sizes for the current street.
`vector<float> raise_sizes`: This parameter represents a vector of floating-point values that define the possible raise sizes for the current street.
`vector<float> donk_sizes`: This parameter represents a vector of floating-point values that define the possible donk bet sizes for the current street.
`bool allin`: This parameter is a boolean flag that indicates whether the all-in betting option is available for the current street.

**Code Description**: The `StreetSetting` constructor initializes the class members with the provided parameters. It assigns the `bet_sizes`, `raise_sizes`, and `donk_sizes` vectors to the corresponding class members, and sets the `allin` flag based on the provided value.

This class is likely used to encapsulate the betting parameters for a specific street in a poker game, such as the flop, turn, or river. By storing these parameters in a dedicated class, the code can easily manage and access the betting options for each street, which is important for implementing poker game logic and decision-making algorithms.\\
## Code: 
```
StreetSetting::StreetSetting(vector<float> bet_sizes, vector<float> raise_sizes, vector<float> donk_sizes,
                             bool allin) {
    this->bet_sizes = bet_sizes;
    this->raise_sizes = raise_sizes;
    this->donk_sizes = donk_sizes;
    this->allin = allin;
}
```