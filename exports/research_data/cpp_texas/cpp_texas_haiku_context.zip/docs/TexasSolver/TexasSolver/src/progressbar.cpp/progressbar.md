`progressbar`: The function of `progressbar` is to initialize a progress bar object with the specified number of cycles and options to show or hide the progress bar.

**Parameters**:
`int n`: This parameter specifies the total number of cycles or steps that the progress bar will represent.
`bool showbar`: This parameter determines whether the progress bar should be displayed or not. If `true`, the progress bar will be shown; if `false`, the progress bar will be hidden.

**Code Description**:
The `progressbar` function is a constructor that initializes the following member variables of the `progressbar` class:
- `progress`: Keeps track of the current progress of the progress bar.
- `n_cycles`: Stores the total number of cycles or steps that the progress bar will represent.
- `last_perc`: Stores the last percentage of progress that was displayed.
- `do_show_bar`: Determines whether the progress bar should be displayed or not.
- `update_is_called`: Keeps track of whether the `update()` function has been called.
- `done_char`, `todo_char`, `opening_bracket_char`, and `closing_bracket_char`: These variables store the characters used to represent the completed and remaining portions of the progress bar, as well as the opening and closing bracket characters.

The constructor initializes these member variables based on the provided parameters `n` and `showbar`. This sets up the progress bar object for subsequent use in the application.\\
## Code: 
```
progressbar::progressbar(int n, bool showbar) :
        progress(0),
        n_cycles(n),
        last_perc(0),
        do_show_bar(showbar),
        update_is_called(false),
        done_char("#"),
        todo_char(" "),
        opening_bracket_char("["),
        closing_bracket_char("]") {}
```