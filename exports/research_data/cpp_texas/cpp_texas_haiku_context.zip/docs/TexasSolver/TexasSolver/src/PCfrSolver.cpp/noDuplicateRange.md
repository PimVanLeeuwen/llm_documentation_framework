`noDuplicateRange`: The function of `noDuplicateRange` is to filter a given vector of `PrivateCards` objects and return a new vector containing only the unique elements.

**Parameters**:
`const vector<PrivateCards> &private_range`: This parameter represents a vector of `PrivateCards` objects, which are the input range to be processed.
`uint64_t board_long`: This parameter represents a 64-bit unsigned integer that encodes the current board state in a Texas Hold'em game.

**Code Description**:
The `noDuplicateRange` function first creates an empty vector `range_array` to store the unique `PrivateCards` objects. It also creates an `unordered_map` called `rangekv` to keep track of the unique `PrivateCards` objects.

The function then iterates through the `private_range` vector. For each `PrivateCards` object in the range, it checks if the object's hash code (obtained using the `hashCode()` method) already exists in the `rangekv` map. If the hash code is found, it means the `PrivateCards` object is a duplicate, and the function throws a `runtime_error` with a message indicating the duplicate key.

If the `PrivateCards` object is unique, the function adds its hash code to the `rangekv` map and then checks if the card combination represented by the `PrivateCards` object (obtained using the `get_hands()` method) has any intersection with the current board state (represented by the `board_long` parameter). If there is no intersection, the function adds the `PrivateCards` object to the `range_array` vector.

Finally, the function returns the `range_array` vector, which contains the unique `PrivateCards` objects that do not intersect with the current board state.

The purpose of this function is to ensure that the input range of `PrivateCards` objects is unique and does not contain any duplicates, and to further filter the range by removing any `PrivateCards` objects that represent card combinations that are already present on the board. This is likely done to optimize the performance of the Texas Hold'em solver algorithm by reducing the number of possible card combinations that need to\\
## Code: 
```
vector<PrivateCards>
PCfrSolver::noDuplicateRange(const vector<PrivateCards> &private_range, uint64_t board_long) {
    vector<PrivateCards> range_array;
    unordered_map<int,bool> rangekv;
    for(PrivateCards one_range:private_range){
        if(rangekv.find(one_range.hashCode()) != rangekv.end())
            throw runtime_error(tfm::format("duplicated key %s",one_range.toString()));
        rangekv[one_range.hashCode()] = true;
        uint64_t hand_long = Card::boardInts2long(one_range.get_hands());
        if(!Card::boardsHasIntercept(hand_long,board_long)){
            range_array.push_back(one_range);
        }
    }
    return range_array;

}
```