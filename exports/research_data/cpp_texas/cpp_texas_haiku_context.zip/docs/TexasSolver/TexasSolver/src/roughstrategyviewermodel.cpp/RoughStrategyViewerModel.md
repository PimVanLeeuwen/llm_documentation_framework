`RoughStrategyViewerModel`: The function of `RoughStrategyViewerModel` is to create a new instance of the `RoughStrategyViewerModel` class, which is a subclass of `QAbstractItemModel`. This class is responsible for providing a model for displaying and interacting with a table strategy model.

**Parameters**:
`TableStrategyModel* tableStrategyModel`: This parameter is a pointer to a `TableStrategyModel` object, which represents the table strategy model that the `RoughStrategyViewerModel` will be based on.
`QObject *parent`: This parameter is a pointer to a `QObject` that will be the parent of the `RoughStrategyViewerModel` object. This is a common pattern in Qt-based applications, where objects are organized in a parent-child hierarchy.

**Code Description**: The `RoughStrategyViewerModel` constructor takes two parameters: a `TableStrategyModel` pointer and a `QObject` pointer. The `TableStrategyModel` pointer is stored in the `tableStrategyModel` member variable of the `RoughStrategyViewerModel` class. This allows the `RoughStrategyViewerModel` to access and use the data from the `TableStrategyModel` when providing a model for displaying and interacting with the table strategy.

The constructor also calls the constructor of the `QAbstractItemModel` class, passing the `parent` parameter. This is a common pattern in Qt-based applications, where subclasses of `QAbstractItemModel` are used to provide data models for various UI components.

Overall, the `RoughStrategyViewerModel` class is responsible for providing a model for displaying and interacting with a table strategy model, using the data from a `TableStrategyModel` object.\\
## Code: 
```
RoughStrategyViewerModel::RoughStrategyViewerModel(TableStrategyModel* tableStrategyModel, QObject *parent):QAbstractItemModel(parent){
    this->tableStrategyModel = tableStrategyModel;
}
```