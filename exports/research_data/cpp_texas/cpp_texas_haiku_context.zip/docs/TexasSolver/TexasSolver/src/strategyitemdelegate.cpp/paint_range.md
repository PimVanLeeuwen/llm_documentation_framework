`paint_range`: The function of `paint_range` is to paint the range of a strategy item in a table view.

**Parameters**:
`QPainter *painter`: This parameter is a pointer to a QPainter object, which is used to draw the range on the table view.
`const QStyleOptionViewItem &option`: This parameter contains the style options for the current view item, which are used to determine the appearance of the item.
`const QModelIndex &index`: This parameter is the model index of the current table view item, which is used to retrieve the range data from the table model.

**Code Description**:
The `paint_range` function first initializes the style options for the current view item using the `initStyleOption` function. It then casts the model of the current index to a `TableStrategyModel` object.

Next, the function checks if the `TableStrategyModel` object has valid range data for the current index. If the range data is not available, the function returns without doing anything.

If the range data is available, the function calculates the average range value for the current index based on the range data. It then uses this range value to determine the height of the disabled (fold) area of the table view item. The function then draws a yellow background for the remaining (non-fold) area of the table view item.

Finally, the function draws the text content of the table view item using a `QTextDocument` object, which is positioned within the remaining (non-fold) area of the table view item.

Overall, the `paint_range` function is responsible for rendering the range information for a strategy item in a table view, with the fold probability represented by a disabled area at the top of the item.\\
## Code: 
```
void StrategyItemDelegate::paint_range(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);
    const TableStrategyModel * tableStrategyModel = qobject_cast<const TableStrategyModel*>(index.model());

    vector<pair<int,int>> card_cords;
    if(tableStrategyModel == NULL
            || tableStrategyModel->ui_p1_range.size() <= index.row()
            || tableStrategyModel->ui_p1_range.size() <= index.column()
            || tableStrategyModel->ui_p2_range.size() <= index.row()
            || tableStrategyModel->ui_p2_range.size() <= index.column()
            ){
        return;
    }
    if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP){
        card_cords = tableStrategyModel->ui_p1_range[index.row()][index.column()];
    }else{
        card_cords = tableStrategyModel->ui_p2_range[index.row()][index.column()];
    }

    if(tableStrategyModel->p1_range.empty() || tableStrategyModel->p2_range.empty()){
        return;
    }

    if(!card_cords.empty()){
        float range_number = 0;
        for(auto one_cord:card_cords){
            if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP){
                range_number += tableStrategyModel->p1_range[one_cord.first][one_cord.second];
            }else{
                // when it's oop, which is p1
                range_number += tableStrategyModel->p2_range[one_cord.first][one_cord.second];
            }
        }
        range_number = range_number / card_cords.size();

        if(range_number < 0 || range_number > 1) throw runtime_error("range number incorrect in strategyitemdeletage");

        float fold_prob = 1 - range_number;
        int disable_height = (int)(fold_prob * option.rect.height());
        int remain_height = option.rect.height() - disable_height;

        // draw background for flod
        QRect rect(option.rect.left(), option.rect.top() + disable_height,\
         option.rect.width(), remain_height);
        QBrush brush(Qt::yellow);
        painter->fillRect(rect, brush);
    }
    QTextDocument doc;
    doc.setHtml(options.text);

    options.text = "";
    //options.widget->style()->drawControl(QStyle::CE_ItemViewItem, &option, painter);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```