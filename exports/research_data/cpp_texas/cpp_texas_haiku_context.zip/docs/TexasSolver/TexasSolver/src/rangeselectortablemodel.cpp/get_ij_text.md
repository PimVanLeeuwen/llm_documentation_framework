`get_ij_text`: The function of `get_ij_text` is to generate a QString that represents the relationship between two indices `i` and `j`.

**Parameters**:
`int i`: The first index to be compared.
`int j`: The second index to be compared.

**Code Description**:
The function first determines which of the two indices, `i` and `j`, is larger and which is smaller. It then constructs a QString using the characters from the `ranklist` array, which is likely a list of ranks or values. The larger index is placed first, followed by the smaller index, and a character is appended to indicate the relationship between the two indices:

- If `i` is greater than `j`, the character "o" is appended.
- If `i` is less than `j`, the character "s" is appended.
- If `i` is equal to `j`, an empty string is appended.

The resulting QString is then returned.

This function is likely used in a table or grid-based UI component to display the relationship between different indices or values in a concise and readable format.\\
## Code: 
```
QString RangeSelectorTableModel::get_ij_text(int i,int j){
    int row = i;
    int col = j;
    int larger = row > col?row:col;
    int smaller = row > col?col:row;
    QString  retval = QString("%1%2%3")\
            .arg(QString(this->ranklist[smaller]))\
            .arg(QString(this->ranklist[larger]));
    if(row > col){
        retval = retval.arg("o");
    }else if(row < col){
        retval = retval.arg("s");
    }else{
        retval = retval.arg("");
    }
    return retval;
}
```