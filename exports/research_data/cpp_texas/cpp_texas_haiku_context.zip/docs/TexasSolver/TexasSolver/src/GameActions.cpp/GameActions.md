`GameActions`: The function of `GameActions` is to create a new `GameActions` object with the specified `PokerActions` and amount.

**Parameters**:
`GameTreeNode::PokerActions action`: This parameter represents the type of poker action being performed, such as `RAISE`, `BET`, `CHECK`, `FOLD`, or `CALL`.
`double amount`: This parameter represents the amount associated with the poker action. For `RAISE` and `BET` actions, the amount must be a positive value. For `CHECK`, `FOLD`, and `CALL` actions, the amount must be -1.

**Code Description**:
The `GameActions` constructor initializes the `action` and `amount` member variables based on the input parameters. It performs the following checks:
1. If the `action` is `RAISE` or `BET`, it checks if the `amount` is not -1. If the `amount` is -1, it throws a `runtime_error` with a formatted error message.
2. If the `action` is `CHECK`, `FOLD`, or `CALL`, it checks if the `amount` is -1. If the `amount` is not -1, it throws a `runtime_error` with a formatted error message.
3. If the checks pass, it assigns the `action` and `amount` to the corresponding member variables.

The purpose of this class is to encapsulate the information about a specific poker action, including the type of action and the associated amount. This information can be used in other parts of the `TexasSolver` application to represent and process poker actions during the game.\\
## Code: 
```
GameActions::GameActions(GameTreeNode::PokerActions action, double amount) {
    this->action = action;
    if (action == GameTreeNode::PokerActions::RAISE || action == GameTreeNode::PokerActions::BET ) {
        if (amount == -1) throw runtime_error(tfm::format("raise/bet amount should not be -1, find %s",amount));
    } else {
        if (amount != -1) throw runtime_error(tfm::format("check/fold/call amount should be -1, find %s",amount));
    }
    this->amount = amount;
}
```