`convert`: The function of `convert` is to process a map of card hash values and their corresponding strengths, and separate the entries into two separate maps: one for flush hands and one for non-flush hands.

**Parameters**:
`unordered_map<uint64_t, int>& strength_map`: This is the input map that contains the card hash values as keys and their corresponding hand strengths as values.

**Code Description**:
The `convert` function first clears the `flush_map` and `other_map` unordered maps. It then iterates through the `strength_map` using a pair of iterators `it` and `it_end`.

For each entry in the `strength_map`, the function performs the following steps:
1. Extracts the card hash value from the current entry using `it->first`.
2. Computes a new hash value using the `ranks_hash` function, which likely represents the ranks of the cards in the hand.
3. Checks if the hand represented by the current card hash value is a flush using the `is_flush` function.
4. If the hand is a flush, the function adds the card hash value and its corresponding strength to the `flush_map`.
5. If the hand is not a flush, the function adds the computed rank hash value and its corresponding strength to the `other_map`.

The purpose of this separation is to efficiently compare and evaluate the strengths of flush and non-flush hands separately, which is likely a common operation in the context of the Texas Hold'em poker game solver.\\
## Code: 
```
void FiveCardsStrength::convert(unordered_map<uint64_t, int>& strength_map) {
    flush_map.clear(); other_map.clear();
    auto it = strength_map.begin(), it_end = strength_map.end();
    for (; it != it_end; it++) {
        uint64_t cards_hash = it->first;
        uint64_t hash = ranks_hash(cards_hash);
        if (is_flush(cards_hash)) flush_map[cards_hash] = it->second;
        else {
            /*if (other_map.count(hash) && other_map[hash] != it->second) {
                printf("%zx,%zx:%d != %d\n", cards_hash, hash, it->second, other_map[hash]);
            }*/
            other_map[hash] = it->second;
        }
    }
}
```