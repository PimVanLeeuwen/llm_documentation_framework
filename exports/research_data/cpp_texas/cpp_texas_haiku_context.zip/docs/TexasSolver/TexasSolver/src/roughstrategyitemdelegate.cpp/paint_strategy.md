`paint_strategy`: The function of `paint_strategy` is to paint the strategy information for a specific cell in a table view.

**Parameters**:
`QPainter *painter`: This parameter is a pointer to the QPainter object that will be used to draw the strategy information on the cell.
`const QStyleOptionViewItem &option`: This parameter contains the style options for the current view item, which are used to determine the appearance of the cell.
`const QModelIndex &index`: This parameter represents the index of the current cell in the table view.

**Code Description**:
The `paint_strategy` function first initializes the style options for the current view item using the `initStyleOption` function. It then casts the model associated with the current index to a `RoughStrategyViewerModel` object.

The function then checks if the current tree item in the `RoughStrategyViewerModel` is an action node. If so, it retrieves the strategy information for the current column of the table view, including the action, the percentage of the strategy, and the number of combos.

Based on the action type (fold, check/call, bet/raise), the function sets the background color of the cell using a QBrush. It then formats the strategy information as HTML text and sets it as the text of the style options.

Finally, the function creates a QTextDocument object with the formatted HTML text and draws the contents of the document on the cell using the QPainter object. This ensures that the strategy information is displayed in a formatted and visually appealing way within the table view.\\
## Code: 
```
void RoughStrategyItemDelegate::paint_strategy(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);

    const RoughStrategyViewerModel * roughStrategyViewerModel = qobject_cast<const RoughStrategyViewerModel*>(index.model());

    options.text = "";
    if(roughStrategyViewerModel->tableStrategyModel->treeItem != NULL &&
            roughStrategyViewerModel->tableStrategyModel->treeItem->m_treedata.lock()->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<GameTreeNode> node = roughStrategyViewerModel->tableStrategyModel->treeItem->m_treedata.lock();
        if(index.column() >= roughStrategyViewerModel->tableStrategyModel->total_strategy.size()) return;

        pair<GameActions,pair<float,float>> one_strategy = roughStrategyViewerModel->tableStrategyModel->total_strategy[index.column()];

        QBrush brush(Qt::gray);
        int bet_raise_num = 0;
        for(int i = 0;i <= index.column();i ++){
            GameActions one_action = roughStrategyViewerModel->tableStrategyModel->total_strategy[i].first;
            if(one_action.getAction() == GameTreeNode::PokerActions::FOLD){
                brush = QBrush(QColor	(0,191,255));
            }
            else if(one_action.getAction() == GameTreeNode::PokerActions::CHECK
            || one_action.getAction() == GameTreeNode::PokerActions::CALL){
                brush = QBrush(Qt::green);
            }
            else if(one_action.getAction() == GameTreeNode::PokerActions::BET
            || one_action.getAction() == GameTreeNode::PokerActions::RAISE){
                int color_base = max(128 - 32 * bet_raise_num - 1,0);
                brush = QBrush(QColor(255,color_base,color_base));
                bet_raise_num += 1;
            }else{
                brush = QBrush(Qt::blue);
            }
        }
        QRect rect(option.rect.left(), option.rect.top(),\
             option.rect.width(), option.rect.height());
        painter->fillRect(rect, brush);

        options.text = "";
        GameActions one_action = one_strategy.first;
        float one_strategy_float = one_strategy.second.second * 100;
        float one_combo = one_strategy.second.first;
        if(one_action.getAction() ==  GameTreeNode::PokerActions::FOLD){
            options.text +=  QString(" <h3> %1 <\/h3> <h4>%2\%<\/h4> <h4>%3 %4<\/h4>").arg(tr("FOLD"),QString::number(one_strategy_float,'f',1),QString::number(one_combo,'f',1),tr("combos"));
        }
        else if(one_action.getAction() ==  GameTreeNode::PokerActions::CALL){
            options.text +=  QString(" <h3> %1 <\/h3> <h4>%2\%<\/h4> <h4>%3 %4<\/h4>").arg(tr("CALL"),QString::number(one_strategy_float,'f',1),QString::number(one_combo,'f',1),tr("combos"));

        }
        else if(one_action.getAction() ==  GameTreeNode::PokerActions::CHECK){
            options.text +=  QString(" <h3> %1 <\/h3> <h4>%2\%<\/h4> <h4>%3 %4<\/h4>").arg(tr("CHECK"),QString::number(one_strategy_float,'f',1),QString::number(one_combo,'f',1),tr("combos"));
        }
        else if(one_action.getAction() ==  GameTreeNode::PokerActions::BET){
            options.text +=  QString(" <h3> %1 %2 <\/h3> <h4>%3\%<\/h4> <h4>%4 %5<\/h4>").arg(tr("BET"),QString::number(one_action.getAmount(),'f',1),QString::number(one_strategy_float,'f',1),QString::number(one_combo,'f',1),tr("combos"));
        }
        else if(one_action.getAction() ==  GameTreeNode::PokerActions::RAISE){
            options.text +=  QString(" <h3> %1 %2 <\/h3> <h4>%3\%<\/h4> <h4>%4 %5<\/h4>").arg(tr("RAISE"),QString::number(one_action.getAmount(),'f',1),QString::number(one_strategy_float,'f',1),QString::number(one_combo,'f',1),tr("combos"));
        }

    }
    QTextDocument doc;
    doc.setHtml(options.text);

    options.text = "";
    //options.widget->style()->drawControl(QStyle::CE_ItemViewItem, &option, painter);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```