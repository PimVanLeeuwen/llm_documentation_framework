`get_payoffs`: The function of `get_payoffs` is to return the payoffs for the players based on the result of a showdown.

**Parameters**:
`ShowdownNode::ShowDownResult result`: This parameter represents the result of the showdown, which can be either `NOTTIE` (not a tie) or `NOTTIE` (a tie).
`int winner`: This parameter represents the index of the player who won the showdown. If the showdown is a tie, this parameter should be set to -1.

**Code Description**:
The function first checks the `result` parameter to determine whether the showdown was a tie or not. If the showdown was not a tie (`result == ShowDownResult::NOTTIE`), the function checks the `winner` parameter to ensure that it is not -1 (indicating a tie). If the `winner` parameter is valid, the function returns the payoffs for the winning player by accessing the `player_payoffs` vector at the index of the `winner` parameter.

If the showdown was a tie (`result == ShowDownResult::TIE`), the function checks the `winner` parameter to ensure that it is -1 (indicating a tie). If the `winner` parameter is not -1, the function throws a `runtime_error` exception. If the `winner` parameter is -1, the function returns the `tie_payoffs` vector, which contains the payoffs for each player in the case of a tie.

Overall, the `get_payoffs` function is responsible for retrieving the appropriate payoffs based on the result of the showdown and the winner of the showdown.\\
## Code: 
```
vector<double> ShowdownNode::get_payoffs(ShowdownNode::ShowDownResult result, int winner) {
    if(result == ShowDownResult::NOTTIE){
        if(winner == -1) throw runtime_error("winner == -1 in tie");
        vector<double> retval = player_payoffs[winner];
        return retval;
    }else{
        // if the showdown is a tie
        if(winner != -1) throw runtime_error("winner != -1 in not tie");
        return this->tie_payoffs;
    }
}
```