`setTrunCard`: The function of `setTrunCard` is to set the `turn_card` member variable of the `TableStrategyModel` class to the provided `turn_card` parameter.

**Parameters**:
`Card turn_card`: This parameter represents the card that will be set as the turn card for the `TableStrategyModel` instance.

**Code Description**: The `setTrunCard` method is a simple setter function that updates the `turn_card` member variable of the `TableStrategyModel` class with the provided `turn_card` parameter. This allows the `TableStrategyModel` to keep track of the current turn card, which is likely used in the game logic or strategy calculations performed by the class.\\
## Code: 
```
void TableStrategyModel::setTrunCard(Card turn_card){
    this->turn_card = turn_card;
}
```