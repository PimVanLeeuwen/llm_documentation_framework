`RiverCombs`: The function of `RiverCombs` is to initialize an object that represents the river combinations in a Texas Hold'em poker game.

**Parameters**:
`vector<int> board`: This parameter represents the community cards (the five cards on the board) in the game.
`PrivateCards private_cards`: This parameter represents the private cards (the two cards held by the player) in the game.
`int rank`: This parameter represents the rank or strength of the player's hand.
`int reach_prob_index`: This parameter represents the index of the reach probability, which is likely used to calculate the probability of the player reaching the river.

**Code Description**: The `RiverCombs` constructor initializes the object by setting the values of the `board`, `rank`, `private_cards`, and `reach_prob_index` member variables. These variables are likely used in other parts of the `TexasSolver` code to perform various calculations and analyses related to the river combinations in the Texas Hold'em game.\\
## Code: 
```
RiverCombs::RiverCombs(vector<int> board, PrivateCards private_cards, int rank, int reach_prob_index) {
    this->board = board;
    this->rank = rank;
    this->private_cards = private_cards;
    this->reach_prob_index = reach_prob_index;
}
```