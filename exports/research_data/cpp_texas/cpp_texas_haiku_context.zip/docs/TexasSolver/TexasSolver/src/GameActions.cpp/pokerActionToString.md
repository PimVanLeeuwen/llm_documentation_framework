`pokerActionToString`: The function of `pokerActionToString` is to convert a `GameTreeNode::PokerActions` enum value to a corresponding string representation.

**Parameters**:
`GameTreeNode::PokerActions pokerActions`: This parameter represents a specific poker action, such as `BEGIN`, `ROUNDBEGIN`, `BET`, `RAISE`, `CHECK`, `FOLD`, or `CALL`. The function will return the string representation of the provided poker action.

**Code Description**:
The `pokerActionToString` function uses a `switch` statement to map the `GameTreeNode::PokerActions` enum value to a corresponding string. Each case in the `switch` statement represents a specific poker action, and the function returns the appropriate string for that action. If the provided `pokerActions` value does not match any of the known cases, the function throws a `runtime_error` with the message "PokerActions not found".

This function is likely used in the `TexasSolver` project to provide a human-readable representation of the various poker actions that occur during the game. By converting the enum values to strings, the function can help with logging, debugging, or displaying the current state of the game to users or developers.\\
## Code: 
```
string GameActions::pokerActionToString(GameTreeNode::PokerActions pokerActions) {
    switch (pokerActions)
    {
        case GameTreeNode::PokerActions::BEGIN :   return "BEGIN";
        case GameTreeNode::PokerActions::ROUNDBEGIN :   return "ROUNDBEGIN";
        case GameTreeNode::PokerActions::BET :   return "BET";
        case GameTreeNode::PokerActions::RAISE :   return "RAISE";
        case GameTreeNode::PokerActions::CHECK :   return "CHECK";
        case GameTreeNode::PokerActions::FOLD :   return "FOLD";
        case GameTreeNode::PokerActions::CALL :   return "CALL";
        default:{
            throw runtime_error("PokerActions not found");
        }
    }
}
```