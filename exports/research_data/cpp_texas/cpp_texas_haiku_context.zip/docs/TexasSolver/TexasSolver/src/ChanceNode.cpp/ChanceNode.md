`ChanceNode`: The function of `ChanceNode` is to represent a node in a game tree where a chance event occurs, such as the dealing of cards.

**Parameters**:
`const shared_ptr<GameTreeNode> children`: This parameter represents the children nodes of the current `ChanceNode`, which are the possible outcomes of the chance event.
`GameTreeNode::GameRound round`: This parameter represents the current round of the game, which is used to determine the game state.
`double pot`: This parameter represents the current size of the pot in the game.
`shared_ptr<GameTreeNode> parent`: This parameter represents the parent node of the current `ChanceNode` in the game tree.
`const vector<Card>& cards`: This parameter represents the cards that are dealt to the player in the current game round.
`bool donk`: This parameter represents whether the current action is a "donk" bet, which is a bet made out of position.

**Code Description**: The `ChanceNode` constructor initializes a new `ChanceNode` object with the provided parameters. The `GameTreeNode` base class is initialized with the `round`, `pot`, and `parent` parameters, and the `cards` and `donk` member variables are set to the corresponding parameter values. The `children` parameter is also stored as a member variable of the `ChanceNode` object.

The `ChanceNode` class represents a node in a game tree where a chance event occurs, such as the dealing of cards. This node has one or more children nodes that represent the possible outcomes of the chance event. The `cards` and `donk` member variables store information about the cards dealt and the type of bet made, respectively, which can be used to determine the game state and the optimal strategy for the player.\\
## Code: 
```
ChanceNode::ChanceNode(const shared_ptr<GameTreeNode> children, GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent,
                       const vector<Card>& cards,bool donk): GameTreeNode(round,pot,std::move(parent)),cards(cards) {
    this->children = children;
    this->donk = donk;
}
```