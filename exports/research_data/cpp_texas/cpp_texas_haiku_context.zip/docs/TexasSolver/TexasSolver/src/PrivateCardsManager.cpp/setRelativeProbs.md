`setRelativeProbs`: The function of `setRelativeProbs` is to calculate the relative probabilities of each player's private cards based on the initial board state.

**Code Description**:

The `setRelativeProbs` method is responsible for calculating the relative probabilities of each player's private cards in the context of the initial board state. The method iterates through each player's private cards and performs the following steps:

1. It calculates the sum of the relative probabilities for each player's private cards.
2. For each of the player's private cards, it checks if the card's board representation has an intercept with the initial board state. If it does, the card is skipped.
3. For each of the opponent's private cards, it checks if the card's board representation has an intercept with the initial board state or the current player's card. If it does, the card is skipped.
4. The relative probability of the current player's card is calculated as the sum of the opponent's card weights multiplied by the current player's card weight.
5. The relative probability of each player's card is then normalized by dividing it by the sum of the player's relative probabilities.

The code uses the `Card::boardInts2long` function to convert the vector of card IDs representing the board into a single 64-bit unsigned integer representation. This is likely done to optimize the intercept checks performed in steps 2 and 3.

The `Card::boardsHasIntercept` function is used to check if the board representation of a card has an intercept with the initial board state or another player's card. This is an important step to ensure that the relative probabilities are calculated correctly, as cards that have an intercept with the board or another player's cards should not be considered in the probability calculations.

Overall, the `setRelativeProbs` method is a crucial part of the Texas Hold'em solver implementation, as it allows the system to accurately estimate the relative probabilities of each player's private cards based on the current game state.\\
## Code: 
```
void PrivateCardsManager::setRelativeProbs() {
    int players = this->private_cards.size();
    for(int player_id = 0; player_id < players;player_id ++){
        // TODO 这里只考虑了两个玩家的情况
        int oppo = 1 - player_id;
        float player_prob_sum = 0;

        for(std::size_t i = 0;i < this->private_cards[player_id].size();i ++) {
            float oppo_prob_sum = 0;
            PrivateCards* player_card = &this->private_cards[player_id][i];
            uint64_t player_long = Card::boardInts2long(player_card->get_hands());

            //
            if (Card::boardsHasIntercept(player_long,this->initialboard)){
                continue;
            }

            for (auto oppo_card : this->private_cards[oppo]) {
                uint64_t oppo_long = Card::boardInts2long(oppo_card.get_hands());
                if (Card::boardsHasIntercept(oppo_long,this->initialboard)
                    || Card::boardsHasIntercept(oppo_long,player_long)
                        ){
                    continue;
                }
                oppo_prob_sum += oppo_card.weight;

            }
            player_card->relative_prob = oppo_prob_sum * player_card->weight;
            player_prob_sum += player_card->relative_prob;
        }
        for(std::size_t i = 0;i < this->private_cards[player_id].size();i ++) {
            this->private_cards[player_id][i].relative_prob = this->private_cards[player_id][i].relative_prob / player_prob_sum;
            //player_card.relative_prob = player_card.relative_prob / player_prob_sum;
        }

    }
}
```