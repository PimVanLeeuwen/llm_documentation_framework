`GameTreeNode`: The function of `GameTreeNode` is to create a new node in a game tree data structure, representing a specific state of the game.

**Parameters**:
`GameTreeNode::GameRound round`: This parameter represents the current round of the game, such as pre-flop, flop, turn, or river.
`double pot`: This parameter represents the current size of the pot in the game.
`shared_ptr<GameTreeNode> parent`: This parameter represents the parent node of the current node in the game tree, allowing for the construction of the tree structure.

**Code Description**: The `GameTreeNode` constructor initializes a new node in the game tree with the provided parameters. It sets the `round` member variable to the `GameRound` value passed in, the `pot` member variable to the `double` value passed in, and the `parent` member variable to the `shared_ptr<GameTreeNode>` value passed in. The `std::move` function is used to efficiently transfer the ownership of the `parent` parameter to the `parent` member variable of the `GameTreeNode` object.

This constructor is likely used to create new nodes in the game tree as the game progresses, allowing for the representation of different states of the game and the ability to navigate through the tree to analyze potential game outcomes.\\
## Code: 
```
GameTreeNode::GameTreeNode(GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent) {
    this->round = round;
    this->pot = pot;
    this->parent = std::move(parent);
}
```