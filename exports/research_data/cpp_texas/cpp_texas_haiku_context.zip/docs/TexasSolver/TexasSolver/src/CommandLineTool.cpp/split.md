`split`: The function of `split` is to split a given string `s` into a vector of substrings using a specified delimiter character `c`.

**Parameters**:
`const string& s`: The input string to be split.
`char c`: The delimiter character used to split the input string.
`vector<string>& v`: The reference to a vector of strings where the split substrings will be stored.

**Code Description**:
The `split` function takes a string `s`, a delimiter character `c`, and a reference to a vector of strings `v` as input parameters. It then proceeds to split the input string `s` into substrings using the delimiter `c` and stores the resulting substrings in the vector `v`.

The function uses a while loop to iterate through the input string `s`. It starts by finding the first occurrence of the delimiter `c` in the string using the `find` function. The index of the first occurrence is stored in the variable `j`.

Inside the loop, the function extracts a substring from the input string `s` using the `substr` function. The substring starts from the index `i` and ends at the index `j-i`, which represents the portion of the string between the current position and the delimiter. This substring is then added to the vector `v` using the `push_back` function.

After adding the substring to the vector, the function updates the values of `i` and `j`. The new value of `i` is set to `j+1`, which is the index immediately after the delimiter. The new value of `j` is obtained by calling the `find` function again, this time starting the search from the updated index `j`.

The loop continues until the `find` function returns `string::npos`, which indicates that the delimiter `c` is no longer present in the remaining part of the string. At this point, the function extracts the final substring from the input string `s`, starting from the index `i` and extending to the end of the string, and adds it to the vector `v`.

Overall, the `split` function is a utility function that can be used to split a string into a vector of substrings based on a specified delimiter character. This functionality can be useful in various string processing tasks, such as parsing command-line arguments or processing data from text files\\
## Code: 
```
void split(const string& s, char c,
           vector<string>& v) {
    string::size_type i = 0;
    string::size_type j = s.find(c);

    while (j != string::npos) {
        v.push_back(s.substr(i, j-i));
        i = ++j;
        j = s.find(c, j);

        if (j == string::npos)
            v.push_back(s.substr(i, s.length()));
    }
}
```