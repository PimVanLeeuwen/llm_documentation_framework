`Solver`: The function of `Solver` is to initialize a new `Solver` object with a shared pointer to a `GameTree` object.

**Parameters**:
`shared_ptr<GameTree> tree`: This parameter is a shared pointer to a `GameTree` object, which represents the game tree that the `Solver` will use to solve the game.

**Code Description**: The `Solver` constructor takes a shared pointer to a `GameTree` object as its parameter and assigns it to the `tree` member variable of the `Solver` object. This allows the `Solver` to access and use the `GameTree` object to perform its solving operations.\\
## Code: 
```
Solver::Solver(shared_ptr<GameTree> tree) {
    this->tree = tree;
}
```