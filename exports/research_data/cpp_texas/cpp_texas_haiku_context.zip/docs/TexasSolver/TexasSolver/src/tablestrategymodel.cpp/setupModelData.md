`setupModelData`: The function of `setupModelData` is to initialize and set up the data structures used in the TableStrategyModel class.

**Code Description**:
1. The function first retrieves the list of cards and ranks from the `PokerSolver` object associated with the `qSolverJob`.
2. It then creates a map `cardint2card` that maps the integer representation of each card to the corresponding `Card` object.
3. Next, it initializes several data structures:
   - `ui_strategy_table`: a 3D vector that will store the strategy table for the user interface.
   - `p1_range` and `p2_range`: 2D vectors that will store the probability distributions of the player 1 and player 2 ranges, respectively.
   - `ui_p1_range` and `ui_p2_range`: 3D vectors that will store the player 1 and player 2 ranges for the user interface.
4. The function then iterates through the player 1 and player 2 ranges obtained from the `PokerSolver` object and populates the corresponding data structures (`ui_p1_range` and `ui_p2_range`) based on the card ranks and suits.
5. Finally, it initializes an empty `total_strategy` vector that will store the overall strategy.

The purpose of this function is to set up the necessary data structures to represent the poker game's state and strategy, which can then be used by other parts of the application.\\
## Code: 
```
void TableStrategyModel::setupModelData()
{
    vector<Card> cards = this->qSolverJob->get_solver()->get_deck()->getCards();
    vector<string> ranks = this->qSolverJob->get_solver()->get_deck()->getRanks();
    for(auto one_card: cards){
        this->cardint2card.insert(std::pair<int, Card>(one_card.getCardInt(), one_card));
    }

    this->ui_strategy_table = vector<vector<vector<pair<int,int>>>>(ranks.size());
    for(std::size_t i = 0;i < ranks.size();i ++){
        this->ui_strategy_table[i] = vector<vector<pair<int,int>>>(ranks.size());
        for(std::size_t j = 0;j < ranks.size();j ++){
            this->ui_strategy_table[i][j] = vector<pair<int,int>>();
        }
    }

    this->p1_range = vector<vector<float>>(52);
    for(std::size_t i = 0;i < 52;i ++){
        this->p1_range[i] = vector<float>(52);
        for(std::size_t j = 0;j < 52;j ++){
            this->p1_range[i][j] = 0;
        }
    }

    this->p2_range = vector<vector<float>>(52);
    for(std::size_t i = 0;i < 52;i ++){
        this->p2_range[i] = vector<float>(52);
        for(std::size_t j = 0;j < 52;j ++){
            this->p2_range[i][j] = 0;
        }
    }

    this->ui_p1_range = vector<vector<vector<pair<int,int>>>>(ranks.size());
    for(std::size_t i = 0;i < ranks.size();i ++){
        this->ui_p1_range[i] = vector<vector<pair<int,int>>>(ranks.size());
        for(std::size_t j = 0;j < ranks.size();j ++){
            this->ui_p1_range[i][j] = vector<pair<int,int>>();
        }
    }

    this->ui_p2_range = vector<vector<vector<pair<int,int>>>>(ranks.size());
    for(std::size_t i = 0;i < ranks.size();i ++){
        this->ui_p2_range[i] = vector<vector<pair<int,int>>>(ranks.size());
        for(std::size_t j = 0;j < ranks.size();j ++){
            this->ui_p2_range[i][j] = vector<pair<int,int>>();
        }
    }

    vector<PrivateCards>& p1range = this->qSolverJob->get_solver()->player1Range;
    vector<PrivateCards>& p2range = this->qSolverJob->get_solver()->player2Range;

    for(PrivateCards one_private: p1range){
        Card card1 = this->cardint2card[one_private.card1];
        Card card2 = this->cardint2card[one_private.card2];

        int rank1 = card1.getCardInt() / 4;
        int suit1 = card1.getCardInt() - (rank1)*4;
        int index1 = 12 - rank1; // this index is the index of the actal ui, so AKQ would be the lower index and 234 would be high

        int rank2 = card2.getCardInt() / 4;
        int suit2 = card2.getCardInt() - (rank2)*4;
        int index2 = 12 - rank2;

        if(index1 == index2){
            this->ui_p1_range[index1][index2].push_back(std::pair<int,int>(one_private.card1,one_private.card2));
        }
        else if(suit1 == suit2){
            this->ui_p1_range[min(index1,index2)][max(index1,index2)].push_back(std::pair<int,int>(one_private.card1,one_private.card2));
        }else{
            this->ui_p1_range[max(index1,index2)][min(index1,index2)].push_back(std::pair<int,int>(one_private.card1,one_private.card2));
        }
    }
    for(PrivateCards one_private: p2range){
        Card card1 = this->cardint2card[one_private.card1];
        Card card2 = this->cardint2card[one_private.card2];

        int rank1 = card1.getCardInt() / 4;
        int suit1 = card1.getCardInt() - (rank1)*4;
        int index1 = 12 - rank1; // this index is the index of the actal ui, so AKQ would be the lower index and 234 would be high

        int rank2 = card2.getCardInt() / 4;
        int suit2 = card2.getCardInt() - (rank2)*4;
        int index2 = 12 - rank2;

        if(index1 == index2){
            this->ui_p2_range[index1][index2].push_back(std::pair<int,int>(one_private.card1,one_private.card2));
        }
        else if(suit1 == suit2){
            this->ui_p2_range[min(index1,index2)][max(index1,index2)].push_back(std::pair<int,int>(one_private.card1,one_private.card2));
        }else{
            this->ui_p2_range[max(index1,index2)][min(index1,index2)].push_back(std::pair<int,int>(one_private.card1,one_private.card2));
        }
    }
    this->total_strategy = vector<pair<GameActions,pair<float,float>>>();
}
```