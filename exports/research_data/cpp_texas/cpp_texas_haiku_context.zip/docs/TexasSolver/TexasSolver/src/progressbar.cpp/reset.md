`reset`: The function of `reset` is to reset the progress bar to its initial state.

**Code Description**: The `reset()` function is a method of the `progressbar` class. It is responsible for resetting the state of the progress bar to its initial condition.

The function performs the following actions:

1. Sets the `progress` variable to 0, which represents the current progress of the progress bar.
2. Sets the `update_is_called` flag to `false`, indicating that the `update()` function has not been called since the last reset.
3. Sets the `last_perc` variable to 0, which represents the last percentage of progress displayed.

After executing this function, the progress bar will be in its initial state, ready to be used again for a new progress tracking process.\\
## Code: 
```
void progressbar::reset() {
    progress = 0,
            update_is_called = false;
    last_perc = 0;
    return;
}
```