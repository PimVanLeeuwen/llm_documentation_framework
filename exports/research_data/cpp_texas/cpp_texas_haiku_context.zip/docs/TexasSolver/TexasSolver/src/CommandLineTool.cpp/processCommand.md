`processCommand`: The function of `processCommand` is to process and execute various commands related to a Texas Hold'em poker solver.

**Parameters**:
`string input`: The input string containing the command and its parameters.

**Code Description**:
The `processCommand` function takes a string `input` as its parameter, which represents a command to be executed. The function first splits the input string into a vector of strings `contents` using the `split` function, which separates the input string by spaces. If the `contents` vector is empty, it is set to a single-element vector containing the original `input` string.

The function then checks the size of the `contents` vector. If the size is not between 1 and 2, it throws a `runtime_error` with an error message indicating that the command is not valid.

Next, the function extracts the command and parameter(s) from the `contents` vector. The command is stored in the `command` variable, and the parameter(s) are stored in the `paramstr` variable.

The function then checks the command and performs the corresponding action:

1. `set_pot`: Sets the `ip_commit` and `oop_commit` variables to half the value of the parameter.
2. `set_effective_stack`: Sets the `stack` variable to the value of the parameter plus the `ip_commit` variable.
3. `set_board`: Sets the `board` variable to the parameter and determines the current round based on the number of board cards.
4. `set_range_ip`: Sets the `range_ip` variable to the parameter.
5. `set_range_oop`: Sets the `range_oop` variable to the parameter.
6. `set_bet_sizes`: Parses the parameter string to set the bet sizes for different bet types (bet, raise, donk) and the `allin` flag for a specific player and round.
7. `set_accuracy`: Sets the `accuracy` variable to the value of the parameter.
8. `set_allin_threshold`: Sets the `allin_threshold` variable to the value of the parameter.
9. `set_thread_num`: Sets the `thread_number` variable to the value of the parameter.
10. `build_tree`: Calls\\
## Code: 
```
void CommandLineTool::processCommand(string input) {
    vector<string> contents;
    split(input,' ',contents);
    if(contents.size() == 0) contents = {input};
    if(contents.size() > 2 || contents.size() < 1)throw runtime_error(tfm::format("command not valid: %s",input));
    string command = contents[0];
    string paramstr = contents.size() == 1 ? "" : contents[1];
    if(command == "set_pot"){
        this->ip_commit = stof(paramstr) / 2;
        this->oop_commit = stof(paramstr) / 2;
    }else if(command == "set_effective_stack"){
        this->stack = stof(paramstr) + this->ip_commit;
    }else if(command == "set_board"){
        this->board = paramstr;
        vector<string> board_str_arr = string_split(board,',');
        if(board_str_arr.size() == 3){
            this->current_round = 1;
        }else if(board_str_arr.size() == 4){
            this->current_round = 2;
        }else if(board_str_arr.size() == 5){
            this->current_round = 3;
        }else{
            throw runtime_error(tfm::format("board %s not recognized",this->board));
        }
    }else if(command == "set_range_ip"){
        this->range_ip = paramstr;
    }else if(command == "set_range_oop"){
        this->range_oop = paramstr;
    }else if(command == "set_bet_sizes"){
        vector<string> params;
        split(paramstr,',',params);
        if(params.size() < 3)throw runtime_error("param number error");
        // oop,turn,bet,30,70,100
        string player = params[0];
        string round = params[1];
        string bet_type = params[2];
        StreetSetting& streetSetting = this->gtbs->get_setting(player,round);
        vector<float>* sizes;
        if(bet_type == "allin") streetSetting.allin = true;
        else if(bet_type == "bet") sizes = &(streetSetting.bet_sizes);
        else if(bet_type == "raise") sizes = &(streetSetting.raise_sizes);
        else if(bet_type == "donk") sizes = &(streetSetting.donk_sizes);
        else throw runtime_error("");

        if(bet_type == "bet" || bet_type == "raise" || bet_type == "donk"){
            sizes->clear();
            for(std::size_t i = 3;i < params.size();i ++ ){
                sizes->push_back(stof(params[i]));
            }
        }
    }else if(command == "set_accuracy"){
        this->accuracy = stof(paramstr);
    }else if(command == "set_allin_threshold"){
        this->allin_threshold = stof(paramstr);
    }else if(command == "set_thread_num"){
        this->thread_number = stoi(paramstr);
    }else if(command == "build_tree"){
        this->ps.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }else if(command == "set_max_iteration"){
        this->max_iteration = stoi(paramstr);
    }else if(command == "set_use_isomorphism"){
        this->use_isomorphism = stoi(paramstr);
    }else if(command == "set_print_interval"){
        this->print_interval = stoi(paramstr);
    }else if(command == "start_solve"){
        cout << "<<<START SOLVING>>>" << endl;
        this->ps.train(
                this->range_ip,
                this->range_oop,
                this->board,
                "tmp_log.txt",
                max_iteration,
                this->print_interval,
                "discounted_cfr",
                -1,
                this->accuracy,
                this->use_isomorphism,
                0, // TODO: enable half float option for command line tool
                this->thread_number
        );
    }else if(command == "dump_result"){
        string output_file = paramstr;
        this->ps.dump_strategy(QString::fromStdString(output_file),this->dump_rounds);
    }else if(command == "set_dump_rounds"){
        this->dump_rounds = stoi(paramstr);
    }else{
        cout << "command not recognized: " << command << endl;
    }
}
```