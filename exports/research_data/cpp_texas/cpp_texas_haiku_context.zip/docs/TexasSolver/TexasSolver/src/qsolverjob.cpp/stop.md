`stop`: The function of `stop` is to stop the solver process.

**Code Description**: The `stop()` function is a method in the `QSolverJob` class. Its purpose is to stop the solver process, which can be either in "HOLDEM" mode or "SHORTDECK" mode.

The function first prints a debug message using `qDebug()` to indicate that it is trying to stop the solver. Then, it checks the current mode of the solver (`this->mode`) and calls the appropriate `stop()` function on either `this->ps_holdem` or `this->ps_shortdeck`, depending on the mode.

If the mode is "HOLDEM", the function calls `this->ps_holdem.stop()` to stop the HOLDEM solver process. If the mode is "SHORTDECK", the function calls `this->ps_shortdeck.stop()` to stop the SHORTDECK solver process.

This function is likely called when the user or the application wants to terminate the solver process, for example, when the user cancels a calculation or when the application needs to shut down.\\
## Code: 
```
void QSolverJob::stop(){
    qDebug().noquote() << tr("Trying to stop solver.");
    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.stop();
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.stop();
    }
}
```