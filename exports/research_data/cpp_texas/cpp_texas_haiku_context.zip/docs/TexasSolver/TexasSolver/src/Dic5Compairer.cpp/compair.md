`compair`: The function of `compair` is to compare the ranks of two 5-card hands, where each hand is composed of 2 private cards and 3 public cards.

**Parameters**:
`vector<int> private_former`: The 2 private cards of the first player.
`vector<int> private_latter`: The 2 private cards of the second player.
`vector<int> public_board`: The 5 public cards on the board.

**Code Description**:
The `compair` function first checks that the input vectors have the correct sizes (2 private cards and 5 public cards). If the sizes are incorrect, it throws a runtime error.

Next, the function creates two new vectors, `former_cards` and `latter_cards`, by combining the private cards and the public board cards for each player. It then calls the `getRank` function (which is not shown in the provided code) to determine the rank of each 5-card hand.

Finally, the function calls the `compairRanks` function (which is also not shown in the provided code) to compare the ranks of the two hands and return a `CompairResult` enum value indicating whether the first hand is larger, smaller, or equal to the second hand.

The purpose of this function is to determine the relative strength of two poker hands, which is a crucial step in implementing a Texas Hold'em poker solver.\\
## Code: 
```
Compairer::CompairResult
Dic5Compairer::compair(vector<int> private_former, vector<int> private_latter, vector<int> public_board) {
    if(private_former.size() != 2)
        throw runtime_error(
                tfm::format("private former size incorrect,excepted 2, actually %s",private_former.size())
        );
    if(private_latter.size() != 2)
        throw runtime_error(
                tfm::format("private latter size incorrect,excepted 2, actually %s",private_latter.size())
        );
    if(public_board.size() != 5)
        throw runtime_error(
                tfm::format("public board size incorrect,excepted 2, actually %s",public_board.size())
        );

    vector<int> former_cards(private_former);
    former_cards.insert(former_cards.end(),public_board.begin(),public_board.end());
    int rank_former = this->getRank(former_cards);

    vector<int> latter_cards(private_latter);
    latter_cards.insert(latter_cards.end(),public_board.begin(),public_board.end());
    int rank_latter = this->getRank(latter_cards);

    return this->compairRanks(rank_former,rank_latter);
}
```