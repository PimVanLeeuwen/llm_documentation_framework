`rowCount`: The function of `rowCount` is to return the number of ranks in the deck of cards used by the `PokerSolver` object.

**Parameters**:
`const QModelIndex &parent`: This parameter is not used in the implementation of the `rowCount` function. It is a standard parameter required by the `QAbstractItemModel` interface, which the `TableStrategyModel` class inherits from.

**Code Description**: The `rowCount` function first retrieves the `PokerSolver` object from the `qSolverJob` member variable using the `get_solver()` method. It then calls the `getRanks()` method on the deck of cards associated with the `PokerSolver` object, and returns the size of the resulting vector of ranks. This effectively returns the number of unique ranks in the deck of cards being used by the `PokerSolver`.\\
## Code: 
```
int TableStrategyModel::rowCount(const QModelIndex &parent) const
{
    return this->qSolverJob->get_solver()->get_deck()->getRanks().size();
}
```