`gameRound2int`: The function of `gameRound2int` is to convert a `GameTreeNode::GameRound` enum value to an integer representation.

**Parameters**:
`GameTreeNode::GameRound gameRound`: This parameter represents the game round, which can be one of the following values: `PREFLOP`, `FLOP`, `TURN`, or `RIVER`.

**Code Description**:
The `gameRound2int` function takes a `GameTreeNode::GameRound` enum value as input and returns an integer representation of the game round. The function uses a series of `if-else` statements to map the enum values to their corresponding integer values:

1. If the input `gameRound` is `GameRound::PREFLOP`, the function returns `0`.
2. If the input `gameRound` is `GameRound::FLOP`, the function returns `1`.
3. If the input `gameRound` is `GameRound::TURN`, the function returns `2`.
4. If the input `gameRound` is `GameRound::RIVER`, the function returns `3`.
5. If the input `gameRound` does not match any of the expected values, the function throws a `runtime_error` with the message "round not found".

This function is likely used to simplify the representation of the game round, as integers are often more convenient to work with than enum values, especially in data structures or algorithms that require numeric indices or identifiers.\\
## Code: 
```
int GameTreeNode::gameRound2int(GameTreeNode::GameRound gameRound) {
    if(gameRound == GameRound::PREFLOP) {
        return 0;
    }else if(gameRound == GameRound::FLOP){
        return 1;
    } else if(gameRound == GameRound::TURN) {
        return 2;
    } else if(gameRound == GameRound::RIVER) {
        return 3;
    }
    throw runtime_error("round not found");
}
```