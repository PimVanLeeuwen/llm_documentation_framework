`getTree`: The function of `getTree` is to return the `GameTree` object associated with the `Solver` instance.

**Code Description**: The `getTree` method is a simple getter function that returns the `shared_ptr<GameTree>` object stored in the `Solver` class. This allows other parts of the code to access the `GameTree` instance associated with the current `Solver` object. The method does not perform any complex operations, it simply returns the value of the `tree` member variable.\\
## Code: 
```
shared_ptr<GameTree> Solver::getTree() {
    return this->tree;
}
```