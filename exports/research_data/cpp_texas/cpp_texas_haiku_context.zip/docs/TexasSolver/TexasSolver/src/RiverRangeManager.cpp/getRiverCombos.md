`getRiverCombos`: The function of `getRiverCombos` is to retrieve a vector of `RiverCombs` objects for a given player, preflop card combinations, and board state.

**Parameters**:
`int player`: The player for whom the river combinations are being retrieved.
`const vector<PrivateCards> &riverCombos`: A reference to a vector of `PrivateCards` objects representing the preflop card combinations.
`const vector<int> &board`: A reference to a vector of integer card IDs representing the board state.

**Code Description**: The `getRiverCombos` function first converts the `board` vector of integer card IDs into a single 64-bit unsigned integer representation using the `Card::boardInts2long` function. This is likely done to improve performance and make it easier to work with the board state.

The function then calls another `getRiverCombos` function, passing in the `player`, `riverCombos`, and the 64-bit board representation. This suggests that the actual implementation of retrieving the river combinations is handled by the other `getRiverCombos` function, which is not shown in the provided code snippet.

The purpose of this function is to provide a convenient wrapper around the more complex `getRiverCombos` implementation, allowing the caller to pass in a vector of integer card IDs instead of having to convert it to the 64-bit representation themselves.\\
## Code: 
```
const vector<RiverCombs> &
RiverRangeManager::getRiverCombos(int player, const vector<PrivateCards> &riverCombos, const vector<int> &board) {
    uint64_t board_long = Card::boardInts2long(board);
    return this->getRiverCombos(player,riverCombos,board_long);
}
```