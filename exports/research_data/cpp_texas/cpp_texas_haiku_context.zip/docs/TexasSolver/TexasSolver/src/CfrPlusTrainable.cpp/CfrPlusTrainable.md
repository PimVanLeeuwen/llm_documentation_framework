`CfrPlusTrainable`: The function of `CfrPlusTrainable` is to initialize and store various vectors related to the CFR+ (Counterfactual Regret Minimization) algorithm for a given `ActionNode` and a set of `PrivateCards`.

**Parameters**:
`shared_ptr<ActionNode> action_node`: This parameter represents the `ActionNode` for which the `CfrPlusTrainable` object is being created. The `ActionNode` contains information about the available actions and their corresponding child nodes.
`vector<PrivateCards> privateCards`: This parameter represents the set of private cards associated with the current game state. The `CfrPlusTrainable` object will store information related to these private cards.

**Code Description**:
1. The constructor initializes the `action_node` and `privateCards` member variables with the provided values.
2. It calculates the `action_number`, which is the number of child nodes (actions) associated with the `ActionNode`.
3. It calculates the `card_number`, which is the number of `PrivateCards` in the provided vector.
4. It initializes the following vectors:
   - `r_plus`: A vector of size `action_number * card_number` to store the cumulative regret values for each action-card combination.
   - `r_plus_sum`: A vector of size `card_number` to store the sum of cumulative regret values for each card.
   - `cum_r_plus`: A vector of size `action_number * card_number` to store the cumulative regret values for each action-card combination.
   - `cum_r_plus_sum`: A vector of size `card_number` to store the sum of cumulative regret values for each card.
   - `retval`: A vector of size `action_number * card_number` to store the final regret values for each action-card combination.

The purpose of this code is to set up the necessary data structures to keep track of the regret values and cumulative regret values for each action-card combination in the CFR+ algorithm. These data structures will be used during the training process to update the regret values and compute the final strategy.\\
## Code: 
```
CfrPlusTrainable::CfrPlusTrainable(shared_ptr<ActionNode> action_node, vector<PrivateCards> privateCards) {
    this->action_node = action_node;
    this->privateCards = privateCards;
    this->action_number = action_node->getChildrens().size();
    this->card_number = privateCards.size();

    this->r_plus = vector<float>(this->action_number * this->card_number);
    this->r_plus_sum = vector<float>(this->card_number);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number);
    this->cum_r_plus_sum = vector<float>(this->card_number);
    this->retval = vector<float>(this->action_number * this->card_number);
}
```