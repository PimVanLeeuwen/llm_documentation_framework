`getcurrentStrategy`: The function of `getcurrentStrategy` is to return the current strategy of the `DiscountedCfrTrainable` object.

**Code Description**: The `getcurrentStrategy` method is a simple wrapper around the `getcurrentStrategyNoCache` method. It simply calls the `getcurrentStrategyNoCache` method and returns the result, which is a vector of floats representing the current strategy. The `getcurrentStrategyNoCache` method is responsible for calculating the current strategy based on the values of the `r_plus` and `r_plus_sum` member variables of the `DiscountedCfrTrainable` object.\\
## Code: 
```
const vector<float> DiscountedCfrTrainable::getcurrentStrategy() {
    return this->getcurrentStrategyNoCache();
}
```