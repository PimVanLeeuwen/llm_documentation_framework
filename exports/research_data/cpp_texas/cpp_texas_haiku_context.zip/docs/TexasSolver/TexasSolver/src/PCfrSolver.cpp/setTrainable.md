`setTrainable`: The function of `setTrainable` is to recursively set the trainable property of the nodes in a game tree.

**Parameters**:
`shared_ptr<GameTreeNode> root`: This parameter represents the root node of the game tree for which the trainable property needs to be set.

**Code Description**:
The `setTrainable` function first checks the type of the `root` node. If the node is an `ActionNode`, it sets the trainable property of the node based on the configured trainer. If the trainer is "cfr_plus", it throws a runtime error as this trainer is not supported. If the trainer is "discounted_cfr", it sets the trainable property of the node using the `DiscountedCfrTrainable` class, and calculates the number of trainable objects based on the gap between the current round and the root round.

If the node is a `ChanceNode`, the function recursively calls itself with the child node of the `ChanceNode`.

If the node is a `TerminalNode` or a `ShowdownNode`, the function does not perform any further actions.

After setting the trainable property of the current node, the function recursively calls itself for each child node of the `ActionNode`.

The purpose of this function is to ensure that the trainable property of each node in the game tree is properly set, which is necessary for the training process of the game solver.\\
## Code: 
```
void PCfrSolver::setTrainable(shared_ptr<GameTreeNode> root) {
    if(root->getType() == GameTreeNode::ACTION){
        shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(root);

        int player = action_node->getPlayer();

        if(this->trainer == "cfr_plus"){
            //vector<PrivateCards> player_privates = this->ranges[player];
            //action_node->setTrainable(make_shared<CfrPlusTrainable>(action_node,player_privates));
            throw runtime_error(tfm::format("trainer %s not supported",this->trainer));
        }else if(this->trainer == "discounted_cfr"){
            vector<PrivateCards>* player_privates = &this->ranges[player];
            //action_node->setTrainable(make_shared<DiscountedCfrTrainable>(action_node,player_privates));
            int num;
            GameTreeNode::GameRound gr = this->tree->getRoot()->getRound();
            int root_round = GameTreeNode::gameRound2int(gr);
            int current_round = GameTreeNode::gameRound2int(root->getRound());
            int gap = current_round - root_round;

            if(gap == 2) {
                num = this->deck.getCards().size() * this->deck.getCards().size() +
                          this->deck.getCards().size() + 1;
            }else if(gap == 1) {
                num = this->deck.getCards().size() + 1;
            }else if(gap == 0) {
                num =  1;
            }else{
                throw runtime_error("gap not understand");
            }
            action_node->setTrainable(vector<shared_ptr<Trainable>>(num),player_privates);
        }else{
            throw runtime_error(tfm::format("trainer %s not found",this->trainer));
        }

        vector<shared_ptr<GameTreeNode>> childrens =  action_node->getChildrens();
        for(shared_ptr<GameTreeNode> one_child:childrens) setTrainable(one_child);
    }else if(root->getType() == GameTreeNode::CHANCE) {
        shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(root);
        shared_ptr<GameTreeNode> children = chance_node->getChildren();
        setTrainable(children);
    }
    else if(root->getType() == GameTreeNode::TERMINAL){

    }else if(root->getType() == GameTreeNode::SHOWDOWN){

    }
}
```