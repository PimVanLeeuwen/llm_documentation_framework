`Deck`: The function of `Deck` is to create a deck of playing cards.

**Parameters**:
`const vector<string>& ranks`: This parameter represents the ranks of the playing cards, such as "Ace", "King", "Queen", "Jack", and the numbers 2 through 10.
`const vector<string>& suits`: This parameter represents the suits of the playing cards, such as "Hearts", "Diamonds", "Clubs", and "Spades".

**Code Description**:
The `Deck` constructor takes two vectors of strings, `ranks` and `suits`, as input. It initializes the `ranks` and `suits` member variables with the provided values.

The constructor then creates a deck of playing cards by iterating through the `ranks` and `suits` vectors. For each combination of rank and suit, it creates a string representation of the card (e.g., "AceHearts", "KingDiamonds", etc.) and stores it in the `cards_str` vector. Additionally, it creates a pair of the card string and a unique card number, and stores it in the `cards` vector.

The unique card number is assigned sequentially, starting from 0 and incrementing by 1 for each card. This allows the cards to be easily identified and referenced by their numerical index.

The purpose of this `Deck` class is to provide a convenient way to represent and manage a standard deck of playing cards, which can be useful in various card game applications.\\
## Code: 
```
Deck::Deck(const vector<string>& ranks, const vector<string>& suits) {
    this->ranks = ranks;
    this->suits = suits;
    int card_num = 0;
    for(const string& one_rank : ranks){
        for(const string& one_suit: suits){
            string one_card = one_rank + one_suit;
            cards_str.push_back(one_card);
            cards.emplace_back(one_card,card_num);
            card_num += 1;
        }
    }
}
```