`normalization_tanh`: The function of `normalization_tanh` is to apply a normalization transformation to the input value `ev` using the hyperbolic tangent (tanh) function.

**Parameters**:
`float stack`: The total value or "stack" that the input value `ev` is a part of.
`float ev`: The input value that needs to be normalized.
`float ratio`: A scaling factor used in the normalization calculation.

**Code Description**: The function first calculates a normalized value `x` by dividing the input value `ev` by the total stack value `stack` and multiplying it by the `ratio` parameter. This effectively scales the input value relative to the total stack.

The function then applies the hyperbolic tangent (tanh) function to the normalized value `x`. The tanh function maps the input value to the range [-1, 1]. To shift the output range to [0, 1], the function adds 0.5 and divides the result by 2. This final step ensures that the output of the `normalization_tanh` function is a value between 0 and 1, representing the normalized input value.

The purpose of this normalization function is likely to scale the input value `ev` to a standardized range, which can be useful in various data processing and machine learning applications.\\
## Code: 
```
float normalization_tanh(float stack,float ev,float ratio){
    float x = ev / stack * ratio;
    return tanh(x) / 2 + 0.5;
}
```