`string_split`: The function of `string_split` is to split a given input string into a vector of substrings using a specified delimiter character.

**Parameters**:
`string strin`: The input string to be split.
`char split`: The delimiter character used to split the input string.

**Code Description**: The `string_split` function takes two parameters: `strin` (the input string to be split) and `split` (the delimiter character to use for splitting). It then creates a `vector<string>` called `retval` to store the resulting substrings.

The function uses a `stringstream` object `ss` to read the input string `strin`. It then repeatedly calls the `getline` function to extract substrings from `ss`, using the `split` character as the delimiter. Each extracted substring is then added to the `retval` vector.

Finally, the function returns the `retval` vector containing the split substrings.\\
## Code: 
```
vector<string> string_split(string strin,char split){
    vector<string> retval;
    stringstream ss(strin);
    string token;
    while (getline(ss,token, split))
    {
        retval.push_back(token);
    }
    return retval;
}
```