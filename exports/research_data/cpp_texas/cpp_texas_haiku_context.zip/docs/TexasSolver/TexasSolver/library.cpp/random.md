`random`: The function of `random` is to generate a random integer within the specified range.

**Parameters**:
`int min`: The minimum value (inclusive) of the range from which the random number will be generated.
`int max`: The maximum value (exclusive) of the range from which the random number will be generated.

**Code Description**: The `random` function takes two integer parameters, `min` and `max`, and returns a random integer within the range `[min, max)`. The function uses the `rand()` function, which is a standard C++ function that generates a pseudo-random number, to generate a random number between 0 and `(max - min)`. The result is then added to `min` to ensure the output is within the specified range.\\
## Code: 
```
int random(int min, int max) //range : [min, max)
{
    return min + rand() % (( max ) - min);
}
```