`GameTree`: The function of `GameTree` is to create a game tree representation of a poker game, with the root node representing the current state of the game.

**Parameters**:
`Deck deck`: The deck of cards used in the poker game.
`float oop_commit`: The commitment (i.e., the amount of money put into the pot) of the out-of-position player.
`float ip_commit`: The commitment of the in-position player.
`int current_round`: The current round of the poker game (0 for preflop, 1 for flop, 2 for turn, 3 for river).
`int raise_limit`: The maximum number of raises allowed in the current round.
`float small_blind`: The small blind amount.
`float big_blind`: The big blind amount.
`float stack`: The stack size (i.e., the amount of money each player has).
`GameTreeBuildingSettings buildingSettings`: Settings for building the game tree.
`float allin_threshold`: The threshold for determining when a player should go all-in.

**Code Description**: The `GameTree` constructor initializes a `Rule` object with the provided parameters, which represents the current state of the poker game. It then creates an `ActionNode` object, which is the root node of the game tree, and calls the `__build` method to recursively build the rest of the game tree. The `__build` method is not shown in the provided code, but it is likely responsible for generating the possible actions and child nodes for each game state.

The constructor also sets the `deck` member variable to the provided `Deck` object and the `root` member variable to the newly created `ActionNode` object. This allows the `GameTree` object to be used to represent and manipulate the game state and the game tree.\\
## Code: 
```
GameTree::GameTree(Deck deck,
                   float oop_commit,
                   float ip_commit,
                   int current_round,
                   int raise_limit,
                   float small_blind,
                   float big_blind,
                   float stack,
                   GameTreeBuildingSettings buildingSettings,
                   float allin_threshold
){
    Rule rule = Rule(deck,oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,buildingSettings,allin_threshold);
    int current_player = 1;
    this->deck = deck;
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(rule.current_round);
    shared_ptr<ActionNode> node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(),current_player, round, (double) rule.get_pot(),
                                 nullptr);
    this->__build(node,rule);
    this->root = node;
}
```