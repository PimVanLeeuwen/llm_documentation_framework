`printTree`: The function of `printTree` is to print the game tree structure, including action nodes, showdown nodes, and terminal nodes, with their respective details such as actions, payoffs, and pot sizes.

**Parameters**:
`int depth`: The maximum depth of the game tree to be printed. If `depth` is set to -1, the entire game tree will be printed. If `depth` is set to a positive integer, only the nodes up to that depth will be printed.

**Code Description**: The `printTree` function first checks if the `depth` parameter is valid (greater than or equal to -1 and not equal to 0). If the `depth` is invalid, it throws a `runtime_error` exception.

The function then calls the `recurrentPrintTree` function, passing the root node of the game tree and the current depth (0) as arguments. The `recurrentPrintTree` function is responsible for the actual printing of the game tree.

The `printTree` function does not perform any other operations besides calling the `recurrentPrintTree` function. It serves as a wrapper for the recursive printing process, ensuring that the input `depth` parameter is valid before proceeding with the tree traversal and printing.\\
## Code: 
```
void GameTree::printTree(int depth) {
    if(depth < -1 || depth == 0){
        throw runtime_error("depth can only be -1 or positive");
    }
    vector<string> prefix;
    this->recurrentPrintTree(this->root,0,depth);
}
```