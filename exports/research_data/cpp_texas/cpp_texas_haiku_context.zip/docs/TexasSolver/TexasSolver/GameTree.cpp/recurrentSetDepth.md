`recurrentSetDepth`: The function of `recurrentSetDepth` is to recursively set the depth and calculate the subtree size for each node in the game tree.

**Parameters**:
`shared_ptr<GameTreeNode> node`: This parameter represents a shared pointer to a `GameTreeNode` object, which is the current node being processed in the recursive call.
`int depth`: This parameter represents the current depth of the node in the game tree.

**Code Description**:
The `recurrentSetDepth` function performs the following tasks:

1. It sets the `depth` member variable of the current `node` to the provided `depth` value.
2. It then checks the type of the current `node`:
   - If the node is an `ACTION` node, it casts the `node` to a `shared_ptr<ActionNode>` and iterates through the child nodes. For each child node, it recursively calls `recurrentSetDepth` with the child node and the current depth plus one. It then calculates the total subtree size by adding one (for the current node) and the subtree sizes of all the child nodes.
   - If the node is a `CHANCE` node, it casts the `node` to a `shared_ptr<ChanceNode>` and recursively calls `recurrentSetDepth` on the `children` of the `ChanceNode`, multiplying the subtree size by the number of cards in the `ChanceNode`.
   - If the node is neither an `ACTION` nor a `CHANCE` node, it sets the `subtree_size` of the current `node` to 1.
3. Finally, the function returns the `subtree_size` of the current `node`.

The purpose of this function is to traverse the game tree, setting the depth of each node and calculating the total subtree size for each node. This information is likely used later in the game tree analysis or decision-making process.\\
## Code: 
```
int GameTree::recurrentSetDepth(shared_ptr<GameTreeNode> node, int depth) {
    node->depth = depth;
    if(node->getType() == GameTreeNode::ACTION) {
        shared_ptr<ActionNode> actionNode = std::dynamic_pointer_cast<ActionNode>(node);
        int subtree_size = 1;
        for(shared_ptr<GameTreeNode> one_child:actionNode->getChildrens()){
            subtree_size += this->recurrentSetDepth(one_child,depth + 1);
        }
        node->subtree_size = subtree_size;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chanceNode = std::dynamic_pointer_cast<ChanceNode>(node);
        int subtree_size = 1;
        subtree_size += this->recurrentSetDepth(chanceNode->getChildren(),depth + 1) * chanceNode->getCards().size();
        node->subtree_size = subtree_size;
    }else{
        node->subtree_size = 1;
    }
    return node->subtree_size;
}
```