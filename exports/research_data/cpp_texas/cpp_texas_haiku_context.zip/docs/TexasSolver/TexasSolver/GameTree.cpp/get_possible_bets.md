`get_possible_bets`: The function of `get_possible_bets` is to calculate the possible bet amounts for a given player in a Texas Hold'em poker game.

**Parameters**:
`shared_ptr<ActionNode> root`: This parameter represents the root node of the game tree, which contains information about the current state of the game.
`int player`: This parameter represents the player for whom the possible bet amounts are being calculated.
`int next_player`: This parameter represents the player who will act after the current player.
`Rule rule`: This parameter represents the rules of the game, including information such as the big blind, small blind, and stack sizes.
`GameTree::BetType betType`: This parameter specifies the type of bet being considered, which can be one of three types: BET, DONK, or RAISE.

**Code Description**:
The `get_possible_bets` function first checks that the `player` and `next_player` parameters match the expected values. It then retrieves the `StreetSetting` object for the current game round and player, which contains information about the allowed bet sizes.

The function then calculates the possible bet amounts based on the bet type and the current game state. For BET and DONK bets, the function uses the bet sizes specified in the `StreetSetting` object. For RAISE bets, the function calculates the minimum raise amount based on the current commitments of the players.

The function also takes into account the player's stack size and the all-in threshold specified in the `Rule` object. If the calculated bet amount would exceed the player's remaining stack or the all-in threshold, the function adjusts the bet amount to the player's remaining stack.

Finally, the function applies some additional logic to ensure that the possible bet amounts are valid and consistent with the game rules. For example, it ensures that the bet amounts are multiples of the small blind, and that the bet amounts are greater than or equal to the minimum raise amount.

The function returns a vector of possible bet amounts that the player can make in the current game state.\\
## Code: 
```
vector<double> GameTree::get_possible_bets(shared_ptr<ActionNode> root, int player, int next_player, Rule rule,
                                           GameTree::BetType betType) {
    if(player != 1 - next_player)throw runtime_error("player error, player and next player not match");
    StreetSetting streetSetting = this->getSettings(root->getRound(),player,rule.build_settings);
    vector<double> bets_ratios;
    bool all_in = streetSetting.allin;
    vector<float> bets_from_rule;
    if(betType == BetType::BET)bets_from_rule = streetSetting.bet_sizes;
    else if(betType == BetType::DONK)bets_from_rule = streetSetting.donk_sizes;
    else if(betType == BetType::RAISE)bets_from_rule = streetSetting.raise_sizes;
    else throw runtime_error("bet type unknown");
    for(float one_bet:bets_from_rule){
        bets_ratios.push_back((double) one_bet / 100);
    }
    float pot = max(rule.ip_commit,rule.oop_commit) * 2;
    vector<double> possible_amounts;
    for(double one_bet: bets_ratios){
        double amount;
        if(rule.oop_commit == rule.small_blind){
            // 当德州扑克开始时，在第一个玩家动作时（sb位置玩家）,视作对手先下注一个bb,这个时候下注要扣除自己的sb
            amount = one_bet * rule.big_blind  - rule.small_blind;
            amount = this->round_nearest(amount, (double) rule.small_blind);
        }else if(rule.ip_commit == rule.big_blind && rule.oop_commit == rule.big_blind){
            // 当德州扑克开始时，在第一个玩家call 的时候第二个玩家要 raise的时候,需要特殊处理
            amount = one_bet * rule.big_blind;
            amount = this->round_nearest(amount, (double) rule.small_blind);
        }else{
            amount = one_bet * pot;
            amount = this->round_nearest(amount, (double) rule.big_blind);
        }
        if(betType == BetType::RAISE)amount += (rule.get_commit(next_player) - rule.get_commit(player));
        if(amount + rule.get_commit(player) > rule.initial_effective_stack * rule.allin_threshold)amount = (double) (rule.stack - rule.get_commit(player)); // if larget than allin thres then allin
        if(amount < rule.stack - rule.get_commit(player) && amount > 0) {
            possible_amounts.push_back(amount);
        }else if(amount == rule.stack - rule.get_commit(player)){
            possible_amounts.push_back(amount);
        }
        else if(amount > rule.stack - rule.get_commit(player)){
            possible_amounts.push_back(rule.stack - rule.get_commit(player));
        }
    }
    if(all_in) possible_amounts.push_back((double) (rule.stack - rule.get_commit(player)));

    if (rule.get_commit(player) != rule.small_blind){
        // 一开始的possible bet amount不能简单取整
        vector<double> tmp_vector;
        for(double val:possible_amounts){
            if(val > 0)tmp_vector.push_back(int(val));
        }
        possible_amounts = tmp_vector;
    }
    if (rule.get_commit(player) == rule.small_blind){
        vector<double> tmp_vector;
        for(double val:possible_amounts){
            if(val >= rule.big_blind)tmp_vector.push_back(val);
        }
        possible_amounts = tmp_vector;
    }else if (rule.get_commit(player) == rule.big_blind && rule.get_commit(next_player) == rule.big_blind){
        vector<double> tmp_vector;
        for(double val:possible_amounts){
            if(val >= rule.big_blind)tmp_vector.push_back(val);
        }
        possible_amounts = tmp_vector;
    }else{
        float gap = rule.get_commit(next_player) - rule.get_commit(player);
        vector<double> tmp_vector;
        for(double val:possible_amounts){
            if(val >= gap * 2)tmp_vector.push_back(val);
        }
        possible_amounts = tmp_vector;
    }
    vector<double> tmp_vector;
    for(double val:possible_amounts){
        if(
                (val > rule.get_commit(next_player) - rule.get_commit(player)) &&
                (val <= rule.stack - rule.get_commit(player)) &&
                find(tmp_vector.begin(),tmp_vector.end(), val) == tmp_vector.end()
        )tmp_vector.push_back(val);
    }
    possible_amounts = tmp_vector;
    return possible_amounts;
}
```