`__build`: The function of `__build` is to recursively build the game tree by processing different types of nodes.

**Parameters**:
`shared_ptr<GameTreeNode> node`: The current node being processed in the game tree.
`Rule rule`: The current rule being applied in the game.
`string last_action`: The last action taken in the game.
`int check_times`: The number of times the player has checked.
`int raise_times`: The number of times the player has raised.

**Code Description**:
The `__build` function takes a `GameTreeNode` object and processes it based on its type. The function uses a `switch` statement to handle different node types:

1. `GameTreeNode::ACTION`: If the node is an `ActionNode`, the function calls the `buildAction` method to process the node.
2. `GameTreeNode::SHOWDOWN`: If the node is a `ShowdownNode`, the function does nothing.
3. `GameTreeNode::TERMINAL`: If the node is a `TerminalNode`, the function does nothing.
4. `GameTreeNode::CHANCE`: If the node is a `ChanceNode`, the function calls the `buildChance` method to process the node.
5. If the node type is unknown, the function throws a `runtime_error`.

The `buildAction` method is responsible for processing `ActionNode` objects, and the `buildChance` method is responsible for processing `ChanceNode` objects. These methods are likely defined elsewhere in the codebase and are not shown in the provided code snippet.

The `__build` function returns the modified `GameTreeNode` object, which is then used to continue building the game tree.\\
## Code: 
```
shared_ptr<GameTreeNode> GameTree::__build(shared_ptr<GameTreeNode> node, Rule rule, string last_action,
                                           int check_times, int raise_times) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            this->buildAction(std::dynamic_pointer_cast<ActionNode>(node),rule,last_action,check_times,raise_times);
            break;
        }case GameTreeNode::SHOWDOWN: {
            break;
        }case GameTreeNode::TERMINAL: {
            break;
        }case GameTreeNode::CHANCE: {
            this->buildChance(std::dynamic_pointer_cast<ChanceNode>(node),rule);
            break;
        }default:
            throw runtime_error("node type unknown");
    }
    return node;
}
```