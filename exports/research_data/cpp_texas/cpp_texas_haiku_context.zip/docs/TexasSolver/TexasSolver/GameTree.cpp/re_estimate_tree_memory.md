`re_estimate_tree_memory`: The function of `re_estimate_tree_memory` is to recursively estimate the memory usage of a game tree.

**Parameters**:
`const shared_ptr<GameTreeNode>& node`: This parameter represents the current node in the game tree for which the memory usage is being estimated.
`int deck_num`: This parameter represents the number of cards in the deck.
`int p1range_num`: This parameter represents the number of possible hands for player 1.
`int p2range_num`: This parameter represents the number of possible hands for player 2.
`int num_current_deal`: This parameter represents the number of the current deal.

**Code Description**:
The `re_estimate_tree_memory` function is a recursive function that traverses the game tree and estimates the memory usage for each node. The function first checks the type of the current node:

1. If the node is an `ActionNode`, the function iterates through the child nodes and recursively calls `re_estimate_tree_memory` on each child. It then adds the estimated memory usage for the current `ActionNode` based on the number of child nodes, the player's range, and the number of the current deal.

2. If the node is a `ChanceNode`, the function recursively calls `re_estimate_tree_memory` on the child node, passing the `num_current_deal` multiplied by the `deck_num` as the new `num_current_deal` parameter.

The function returns the total estimated memory usage for the game tree starting from the current node.

The purpose of this function is to provide an estimate of the memory required to store the entire game tree, which is useful for optimizing the performance of the game solver.\\
## Code: 
```
long long GameTree::re_estimate_tree_memory(const shared_ptr<GameTreeNode>& node,int deck_num,int p1range_num,int p2range_num,int num_current_deal){
    if(node->getType() == GameTreeNode::ACTION){
        shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
        vector<shared_ptr<GameTreeNode>> childrens = action_node->getChildrens();
        vector<GameActions> actions = action_node->getActions();

        long long retnum = 0;
        for(std::size_t i = 0;i < childrens.size();i++){
            shared_ptr<GameTreeNode> one_child = childrens[i];
            retnum += re_estimate_tree_memory(one_child,deck_num, p1range_num, p2range_num, num_current_deal);
        }
        if(action_node->getPlayer() == 0){
            retnum += num_current_deal * p1range_num * (childrens.size() + 1) * 3;
        }else{
            retnum += num_current_deal * p2range_num * (childrens.size() + 1) * 3;
        }
        return retnum;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
        shared_ptr<GameTreeNode> children = chance_node->getChildren();
        return re_estimate_tree_memory(children,deck_num, p1range_num, p2range_num, num_current_deal * (deck_num));
    }
    return 0;
}
```