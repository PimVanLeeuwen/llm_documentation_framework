`estimate_tree_memory`: The function of `estimate_tree_memory` is to call the `re_estimate_tree_memory` function with the provided parameters and the root of the game tree.

**Parameters**:
`int deck_num`: The number of decks used in the game.
`int p1range_num`: The number of possible ranges for player 1.
`int p2range_num`: The number of possible ranges for player 2.
`int num_current_deal`: The number of the current deal being processed.

**Code Description**: The `estimate_tree_memory` function is a helper function that simplifies the call to `re_estimate_tree_memory`. It takes the same parameters as `re_estimate_tree_memory` and passes them, along with the root of the game tree, to that function. The purpose of this function is to provide a more concise and readable way to call `re_estimate_tree_memory` from other parts of the code.\\
## Code: 
```
long long GameTree::estimate_tree_memory(int deck_num,int p1range_num,int p2range_num,int num_current_deal){
    return this->re_estimate_tree_memory(this->root,deck_num, p1range_num, p2range_num, num_current_deal);
}
```