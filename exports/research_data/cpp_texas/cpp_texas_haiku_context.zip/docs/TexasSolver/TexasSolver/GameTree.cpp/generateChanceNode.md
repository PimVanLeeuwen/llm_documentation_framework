`generateChanceNode`: The function of `generateChanceNode` is to create a `ChanceNode` object, which is a type of `GameTreeNode` in the game tree.

**Parameters**:
`json meta`: This parameter contains metadata about the current game state, including the current pot size.
`const json& child`: This parameter represents the child node(s) of the current node being generated.
`string round`: This parameter specifies the current round of the game (e.g., "preflop", "flop", "turn", "river").
`shared_ptr<GameTreeNode> parent`: This parameter is a shared pointer to the parent node of the current node being generated.

**Code Description**:
The `generateChanceNode` function first extracts the current pot size from the `meta` JSON object. It then calls the `recurrentGenerateTreeNode` function to create a `GameTreeNode` object for the child node(s) specified in the `child` parameter.

Next, the function converts the `round` string to a `GameTreeNode::GameRound` enum value using the `strToGameRound` function.

The function then creates a new `ChanceNode` object, passing in the following parameters:
- The `GameTreeNode` object created for the child node(s)
- The `GameRound` enum value for the current round
- The current pot size
- The shared pointer to the parent node
- The cards in the deck

The function then sets the parent of the `GameTreeNode` object (which is the child of the `ChanceNode`) to the `ChanceNode` object that was just created.

Finally, the function returns the newly created `ChanceNode` object.

The purpose of the `generateChanceNode` function is to create a `ChanceNode` object, which represents a node in the game tree where the outcome of an action is determined by chance (e.g., the dealing of a card). The `ChanceNode` object contains information about the current game state, including the pot size and the current round of the game, as well as a reference to the child node(s) that represent the possible outcomes of the chance event.\\
## Code: 
```
shared_ptr<ChanceNode>
GameTree::generateChanceNode(json meta, const json& child, string round, shared_ptr<GameTreeNode> parent) {
    //节点上的下注额度
    double pot = meta["pot"];
    shared_ptr<GameTreeNode> one_child = recurrentGenerateTreeNode(child, nullptr);
    GameTreeNode::GameRound game_round = strToGameRound(std::move(round));
    shared_ptr<ChanceNode> chanceNode = make_shared<ChanceNode>(one_child,game_round,pot,parent,this->deck.getCards());
    shared_ptr<GameTreeNode> gameTreeNode = chanceNode->getChildren();
    gameTreeNode->setParent(chanceNode);
    return chanceNode;
}
```