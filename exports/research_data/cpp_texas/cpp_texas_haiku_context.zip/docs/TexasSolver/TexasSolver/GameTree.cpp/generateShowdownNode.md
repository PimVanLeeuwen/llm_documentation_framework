`generateShowdownNode`: The function of `generateShowdownNode` is to create a new `ShowdownNode` object, which represents a node in the game tree where the showdown phase of a Texas Hold'em poker game occurs.

**Parameters**:
`json meta`: This parameter contains metadata about the current game state, including the pot size and the payoffs for each player based on the outcome of the showdown.
`string round`: This parameter specifies the current round of the game (e.g., "river", "turn", "flop").
`shared_ptr<GameTreeNode> parent`: This parameter is a pointer to the parent node in the game tree, which is used to establish the hierarchical structure of the game tree.

**Code Description**:
The function first extracts the "payoffs" object from the `meta` parameter, which contains information about how the pot should be distributed among the players based on the outcome of the showdown. It then initializes two vectors: `tie_payoffs` and `player_payoffs`.

The `tie_payoffs` vector contains the payoff values for the case where the showdown results in a tie. The `player_payoffs` vector is a 2D vector that stores the payoff values for each player, where the first index corresponds to the player ID and the second index corresponds to the different possible outcomes (e.g., winning, losing, or tying).

The function then iterates over the keys in the "payoffs" object, skipping the "tie" key. For each player key, it extracts the player ID and the corresponding payoff values, and stores them in the `player_payoffs` vector.

Finally, the function calls the `strToGameRound` function (which is not shown in the provided code) to convert the `round` parameter to a `GameTreeNode::GameRound` enum value, and then creates a new `ShowdownNode` object using the extracted data and the parent node pointer. The `ShowdownNode` object is then returned as the result of the function.

Overall, the `generateShowdownNode` function is responsible for creating a new node in the game tree that represents the showdown phase of a Texas Hold'em poker game, with the necessary information about the payoffs and the current game state.\\
## Code: 
```
shared_ptr<ShowdownNode> GameTree::generateShowdownNode(json meta, string round, shared_ptr<GameTreeNode> parent) {
    json meta_payoffs = meta["payoffs"];
    vector<double> tie_payoffs = meta_payoffs["tie"];

    // meta_payoffs 的key有 n个玩家+1个平局,代表某个玩家赢了的时候如何分配payoff
    vector<vector<double>> player_payoffs(2);
    double pot = meta["pot"];

    for(auto one_player_meta=meta_payoffs.begin(); one_player_meta!=meta_payoffs.end(); one_player_meta++){
        const string& one_player = one_player_meta.key();
        if(one_player == "tie"){
            continue;
        }
        // 获胜玩家id
        int player_id = atoi(one_player.c_str());
        if(player_id < 0 or player_id > 1) throw runtime_error("player id json convert fail");

        // 玩家在当前Showdown节点能获得的收益
        //List<Object> tmp_payoffs =  (List<Object>)meta_payoffs.get(one_player);
        vector<double> player_payoff = one_player_meta.value();

        player_payoffs[atoi(one_player.c_str())] = player_payoff;
    }
    GameTreeNode::GameRound game_round = strToGameRound(std::move(round));
    return make_shared<ShowdownNode>(tie_payoffs,player_payoffs,game_round,pot,parent);
}
```