`getSettings`: The function of `getSettings` is to retrieve the appropriate `StreetSetting` based on the given `int_round`, `player`, and `gameTreeBuildingSettings`.

**Parameters**:
`int int_round`: The round of the game, represented as an integer (0 for preflop, 1 for flop, 2 for turn, and 3 for river).
`int player`: The player for whom the `StreetSetting` is being retrieved (0 for in-position, 1 for out-of-position).
`GameTreeBuildingSettings& gameTreeBuildingSettings`: A reference to the `GameTreeBuildingSettings` object, which contains the specific settings for each round and player position.

**Code Description**:
The `getSettings` function first converts the `int_round` to the corresponding `GameRound` enum value using the `intToGameRound` function from the `GameTreeNode` class. It then checks the `player` value to ensure it is either 0 or 1. If the `player` value is not valid, it throws a `runtime_error`.

Next, the function uses a series of `if-else` statements to determine the appropriate `StreetSetting` based on the `round` and `player` values:
- If the `round` is `RIVER` and the `player` is 0, it returns the `river_ip` setting from the `gameTreeBuildingSettings`.
- If the `round` is `TURN` and the `player` is 0, it returns the `turn_ip` setting from the `gameTreeBuildingSettings`.
- If the `round` is `FLOP` and the `player` is 0, it returns the `flop_ip` setting from the `gameTreeBuildingSettings`.
- If the `round` is `RIVER` and the `player` is 1, it returns the `river_oop` setting from the `gameTreeBuildingSettings`.
- If the `round` is `TURN` and the `player` is 1, it returns the `turn_oop` setting from the `gameTreeBuildingSettings`.
- If the `round` is\\
## Code: 
```
StreetSetting GameTree::getSettings(int int_round, int player,GameTreeBuildingSettings& gameTreeBuildingSettings){
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(int_round);
    if(!(player == 0 || player == 1)) throw runtime_error(tfm::format("player %s not known",player));
    if(round == GameTreeNode::GameRound::RIVER && player == 0) return gameTreeBuildingSettings.river_ip;
    else if(round == GameTreeNode::GameRound::TURN && player == 0) return gameTreeBuildingSettings.turn_ip;
    else if(round == GameTreeNode::GameRound::FLOP && player == 0) return gameTreeBuildingSettings.flop_ip;
    else if(round == GameTreeNode::GameRound::RIVER && player == 1) return gameTreeBuildingSettings.river_oop;
    else if(round == GameTreeNode::GameRound::TURN && player == 1) return gameTreeBuildingSettings.turn_oop;
    else if(round == GameTreeNode::GameRound::FLOP && player == 1) return gameTreeBuildingSettings.flop_oop;
    else throw new runtime_error(tfm::format("player %s and round not known",player));
}
```