`readAllBytes`: The function of `readAllBytes` is to open a file specified by the `filePath` parameter and return an `ifstream` object that can be used to read the contents of the file.

**Parameters**:
`const string& filePath`: This parameter specifies the file path of the file to be opened.

**Code Description**:
The `readAllBytes` function takes a `const string&` parameter `filePath`, which represents the file path of the file to be opened. It then creates an `ifstream` object `input_file` and initializes it with the `filePath` parameter using the `ifstream(filePath)` constructor. Finally, the function returns the `input_file` object, which can be used to read the contents of the file.

This function is a simple utility function that provides a convenient way to open a file and obtain an `ifstream` object that can be used to read the file's contents. It does not actually read the entire file into memory, but rather returns an `ifstream` object that can be used to read the file in a streaming fashion.\\
## Code: 
```
ifstream GameTree::readAllBytes(const string& filePath) {
    ifstream input_file(filePath);
    return input_file;
}
```