`strToGameRound`: The function of `strToGameRound` is to convert a string representation of a poker game round to the corresponding `GameTreeNode::GameRound` enum value.

**Parameters**:
`const string& round`: This parameter represents the string representation of the poker game round, which can be one of the following values: "preflop", "flop", "turn", or "river".

**Code Description**:
The function first initializes a `GameTreeNode::GameRound` variable called `game_round`. It then checks the value of the `round` parameter and assigns the corresponding `GameTreeNode::GameRound` enum value to `game_round`. If the `round` parameter does not match any of the expected values, the function throws a `runtime_error` with a formatted error message.

Finally, the function returns the `game_round` value, which represents the poker game round corresponding to the input string.\\
## Code: 
```
GameTreeNode::GameRound GameTree::strToGameRound(const string& round) {
    GameTreeNode::GameRound game_round;
    if(round == "preflop"){
        game_round = GameTreeNode::GameRound::PREFLOP;
    }
    else if (round == "flop"){
        game_round = GameTreeNode::GameRound::FLOP;
    }
    else if(round == "turn"){
        game_round = GameTreeNode::GameRound::TURN;
    }
    else if(round == "river"){
        game_round = GameTreeNode::GameRound::RIVER;
    }
    else{
        throw runtime_error(tfm::format("game round not found: %s",round));
    }
    return game_round;
}
```