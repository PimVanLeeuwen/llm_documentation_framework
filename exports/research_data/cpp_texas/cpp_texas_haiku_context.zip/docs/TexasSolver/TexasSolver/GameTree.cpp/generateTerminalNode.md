`generateTerminalNode`: The function of `generateTerminalNode` is to create a new `TerminalNode` object, which represents a terminal node in the game tree.

**Parameters**:
`json meta`: This parameter contains metadata about the game state, including the payoffs for each player, the current pot size, and the player who is the winner.
`string round`: This parameter specifies the current round of the game, which is used to determine the `GameRound` enum value for the `TerminalNode`.
`shared_ptr<GameTreeNode> parent`: This parameter is a pointer to the parent node of the `TerminalNode` being created, which is used to link the new node to the game tree.

**Code Description**:
The function first extracts the player payoffs from the `meta` JSON object and stores them in a `player_payoff` vector. It then retrieves the current pot size from the `meta` object.

Next, the function calls the `strToGameRound` method to convert the `round` string into the corresponding `GameTreeNode::GameRound` enum value. This enum value is used to represent the current round of the game.

Finally, the function creates a new `TerminalNode` object using the extracted information (player payoffs, winner, game round, and pot size) and the `parent` node, and returns a shared pointer to this new `TerminalNode`.

The `TerminalNode` class represents a terminal node in the game tree, which means it is a leaf node that does not have any children. The `TerminalNode` object stores the final payoffs for each player, the winner of the game, the current round of the game, and the size of the pot.\\
## Code: 
```
shared_ptr<TerminalNode> GameTree::generateTerminalNode(json meta, string round, shared_ptr<GameTreeNode> parent) {
    vector<double> player_payoff_list = meta["payoff"];
    vector<double> player_payoff(player_payoff_list.size());
    for(std::size_t one_player = 0;one_player < player_payoff_list.size();one_player ++){

        double tmp_payoff = player_payoff_list[one_player];
        player_payoff[one_player] = tmp_payoff;
    }

    //节点上的下注额度
    double pot = meta["pot"];

    GameTreeNode::GameRound game_round = this->strToGameRound(std::move(round));
    // 多人游戏的时候winner就不等于当前节点的玩家了，这里要注意
    int player = meta["player"];

    return make_shared<TerminalNode>(player_payoff,player,game_round,pot,parent);
}
```