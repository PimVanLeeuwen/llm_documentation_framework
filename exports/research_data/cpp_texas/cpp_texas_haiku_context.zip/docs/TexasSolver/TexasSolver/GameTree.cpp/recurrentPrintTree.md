`recurrentPrintTree`: The function of `recurrentPrintTree` is to recursively print the game tree structure, including the actions, showdowns, and terminal nodes.

**Parameters**:
`const shared_ptr<GameTreeNode>& node`: This parameter represents the current node in the game tree that the function is processing.
`int depth`: This parameter keeps track of the current depth in the game tree, used for indentation when printing the tree.
`int depth_limit`: This parameter specifies the maximum depth to which the function should print the tree. If set to -1, the function will print the entire tree.

**Code Description**:
The `recurrentPrintTree` function first checks if the `depth_limit` is set and if the current `depth` has reached or exceeded that limit. If so, the function returns without further processing.

Next, the function checks the type of the current `node`. Depending on the type, it performs the following actions:

1. If the node is an `ACTION` node, the function:
   - Casts the `node` to an `ActionNode` pointer.
   - Retrieves the child nodes and the corresponding actions from the `ActionNode`.
   - Prints the current player and the action for each child node.
   - Recursively calls `recurrentPrintTree` on each child node, incrementing the `depth`.

2. If the node is a `SHOWDOWN` node, the function:
   - Casts the `node` to a `ShowdownNode` pointer.
   - Prints the current pot size.
   - Prints the payoffs for each player if they win the showdown, as well as the payoffs if the showdown results in a tie.

3. If the node is a `TERMINAL` node, the function:
   - Casts the `node` to a `TerminalNode` pointer.
   - Prints the current pot size.
   - Prints the terminal payoffs for each player.

4. If the node is a `CHANCE` node, the function:
   - Casts the `node` to a `ChanceNode` pointer.
   - Retrieves the child node of the `ChanceNode`.
   - Prints the "CHANCE" label.\\
## Code: 
```
void GameTree::recurrentPrintTree(const shared_ptr<GameTreeNode>& node, int depth, int depth_limit) {
    if(depth_limit != -1 && depth >= depth_limit){
        return;
    }

    if(node->getType() == GameTreeNode::ACTION){
        shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
        vector<shared_ptr<GameTreeNode>> childrens = action_node->getChildrens();
        vector<GameActions> actions = action_node->getActions();

        for(std::size_t i = 0;i < childrens.size();i++){
            shared_ptr<GameTreeNode> one_child = childrens[i];
            GameActions one_action = actions[i];

            string prefix;
            for(int j = 0;j < depth;j++) prefix += "\t";
            cout << (tfm::format(
                    "%sp%s: %s",prefix,action_node->getPlayer(),one_action.toString()
            )) << endl;
            recurrentPrintTree(one_child,depth + 1,depth_limit);
        }
    }else if(node->getType() == GameTreeNode::SHOWDOWN){
        shared_ptr<ShowdownNode> showdown_node = std::dynamic_pointer_cast<ShowdownNode>(node);
        string prefix;
        for(int j = 0;j < depth;j++) prefix += "\t";
        cout << (tfm::format(
                "%s SHOWDOWN pot %s ",prefix,showdown_node->getPot()
        )) << endl;

        prefix += "\t";
        for(std::size_t i = 0;i < showdown_node->get_payoffs(ShowdownNode::ShowDownResult::TIE,-1).size();i++) {
            cout << (tfm::format("%sif player %s wins, payoff :", prefix,i));
            vector<double> payoffs = showdown_node->get_payoffs(ShowdownNode::ShowDownResult::NOTTIE, i);

            for (std::size_t player_id = 0; player_id < payoffs.size(); player_id++) {
                cout << (
                        tfm::format(" p%s %s ", player_id, payoffs[player_id])
                );
            }
            cout << endl;
        }
        cout << (tfm::format("%sif Tie, payoff :", prefix));
        vector<double> payoffs = showdown_node->get_payoffs(ShowdownNode::ShowDownResult::TIE, -1);

        for (std::size_t player_id = 0; player_id < payoffs.size(); player_id++) {
            cout << (
                    tfm::format(" p%s %s ", player_id, payoffs[player_id])
            );
        }
        cout << endl;
    }else if(node->getType() == GameTreeNode::TERMINAL){
        shared_ptr<TerminalNode> terminal_node = std::dynamic_pointer_cast<TerminalNode>(node);
        string prefix;
        for(int j = 0;j < depth;j++) prefix += "\t";
        cout << (tfm::format(
                "%s TERMINAL pot %s ",prefix,terminal_node->getPot()
        )) << endl;

        prefix += "\t";
        cout << (tfm::format("%sTerminal payoff :", prefix));
        vector<double> payoffs = terminal_node->get_payoffs();

        for (std::size_t player_id = 0; player_id < payoffs.size(); player_id++) {
            cout <<(
                    tfm::format("p%s %s ", player_id, payoffs[player_id])
            );
        }
        cout << endl;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
        shared_ptr<GameTreeNode> children = chance_node->getChildren();

        string prefix;
        for(int j = 0;j < depth;j++) prefix += "\t";
        cout << (tfm::format(
                "%s%s",prefix,"CHANCE"
        )) << endl;
        recurrentPrintTree(children,depth + 1,depth_limit);
    }
}
```