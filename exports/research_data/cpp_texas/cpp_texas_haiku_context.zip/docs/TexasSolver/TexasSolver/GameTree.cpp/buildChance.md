`buildChance`: The function of `buildChance` is to build a chance node in the game tree based on the given `Rule` object.

**Parameters**:
`shared_ptr<ChanceNode> root`: This is a shared pointer to the root `ChanceNode` of the game tree.
`Rule rule`: This is an object of the `Rule` class that contains information about the current state of the game, such as the pot size, player commitments, and the current round.

**Code Description**:
The `buildChance` function first checks if the current round is valid (less than or equal to 3). If the current round is greater than 3, it throws a runtime error.

Next, it checks if the out-of-position (oop) and in-position (ip) player commitments are equal and if they are equal to the stack size. If this condition is met, it means the game has reached the showdown phase.

If the game has reached the showdown phase (current round is greater than or equal to 3):
1. It calculates the amount of money each player will get back if they split the pot.
2. It creates a `ShowdownNode` object with the calculated payoffs and the current pot size, and sets it as the child of the `root` node.

If the game has not reached the showdown phase (current round is less than 3):
1. It creates a new `Rule` object by copying the `rule` object and incrementing the current round by 1.
2. It creates a `ChanceNode` object with the updated `Rule` object, the current pot size, and the deck of cards, and sets it as the child of the `root` node.

If the oop and ip player commitments are not equal, it creates an `ActionNode` object with an empty list of actions and children, the current round, and the current pot size, and sets it as the child of the `root` node.

Finally, the function calls the `__build` method of the `GameTree` class with the newly created node, the updated `Rule` object, the string "begin", and two zeros as arguments, and sets the `root` node's children to the newly created node.\\
## Code: 
```
void GameTree::buildChance(shared_ptr<ChanceNode> root,Rule rule){
    //节点上的下注额度
    double pot = (double)rule.get_pot();
    Rule nextrule = Rule(rule);
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));

    shared_ptr<GameTreeNode> one_node;
    if(rule.oop_commit == rule.ip_commit && rule.oop_commit == rule.stack) {
        if(rule.current_round >= 3){ // 3 is river
            double p1_commit = rule.ip_commit;
            double p2_commit = rule.oop_commit;
            double peace_getback = (p1_commit + p2_commit) / 2;


            vector<vector<double>> payoffs(2);
            payoffs[0] = {p2_commit, -p2_commit};
            payoffs[1] = {-p1_commit, p1_commit};
            vector<double> peace_getback_vec = {peace_getback - p1_commit, peace_getback - p2_commit};
            one_node = make_shared<ShowdownNode>(peace_getback_vec, payoffs, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
        }else {
            nextrule.current_round += 1;
            if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
            one_node = make_shared<ChanceNode>(nullptr, GameTreeNode::intToGameRound(rule.current_round + 1), (double) rule.get_pot(), root, this->deck.getCards());
        }
    }else {
        one_node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(), 1, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
    }
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
    this->__build(one_node,nextrule,"begin",0,0);
    root->setChildren(one_node);
}
```