`generateActionNode`: The function of `generateActionNode` is to create a new `ActionNode` object, which is a type of `GameTreeNode`, based on the provided input parameters.

**Parameters**:
`json meta`: This parameter contains metadata about the current game state, such as the current player and the pot size.
`vector<string> childrens_actions`: This parameter is a vector of strings representing the actions that can be taken by the current player (e.g., "check", "fold", "call", "bet_amount", "raise_amount").
`vector<json> childrens_nodes`: This parameter is a vector of JSON objects representing the child nodes of the current node in the game tree.
`const string& round`: This parameter is a string representing the current round of the game (e.g., "preflop", "flop", "turn", "river").
`shared_ptr<GameTreeNode> parent`: This parameter is a shared pointer to the parent node of the current node in the game tree.

**Code Description**:
The `generateActionNode` function first checks that the size of the `childrens_actions` and `childrens_nodes` vectors are the same. If they are not, it throws a runtime error.

Next, the function checks that the `round` parameter is one of the valid game rounds ("preflop", "flop", "turn", "river"). If the round is not valid, it throws a runtime error.

The function then iterates over the `childrens_actions` and `childrens_nodes` vectors, creating a `GameActions` object for each action and a `GameTreeNode` object for each child node. The `GameActions` objects are added to a `vector<GameActions>` called `actions`, and the `GameTreeNode` objects are added to a `vector<shared_ptr<GameTreeNode>>` called `childrens`.

After creating the `actions` and `childrens` vectors, the function creates a new `ActionNode` object using the `make_shared` function. The `ActionNode` constructor is called with the following parameters:
- `actions`: the `vector<GameActions>` created earlier
- `childrens`: the `vector<shared_ptr<GameTreeNode>>` created earlier
-\\
## Code: 
```
shared_ptr<ActionNode>
GameTree::generateActionNode(json meta, vector<string> childrens_actions, vector<json> childrens_nodes, const string& round,
                             shared_ptr<GameTreeNode> parent) {
    if(childrens_actions.size() != childrens_nodes.size()){
        throw runtime_error(
                tfm::format(
                        "mismatch when generate ActionNode, childrens_action length %s children_nodes length %s",
                        childrens_actions.size(),
                        childrens_nodes.size()
                ));
    }

    if(! (   round == "preflop"
          || round == "flop"
          || round == "turn"
          || round == "river"
          )
            ){
        throw runtime_error(tfm::format("round %s not found",round));
    }

    vector<GameActions> actions;
    vector<shared_ptr<GameTreeNode>> childrens;

    // 遍历所有children actions 来生成GameAction 的list，用于初始化ActionNode
    for(std::size_t i = 0;i < childrens_actions.size();i++){
        string one_action = childrens_actions[i];
        json one_children_map = childrens_nodes[i];
        if(one_action.empty()) throw runtime_error("action is null");

        GameTreeNode::PokerActions action;
        double amount = -1;
        if(one_action == "check"){
            action = GameTreeNode::PokerActions::CHECK;
        }
        else if(one_action == "fold"){
            action = GameTreeNode::PokerActions::FOLD;
        }
        else if(one_action == "call"){
            action = GameTreeNode::PokerActions::CALL;
        }
        else{
            if(one_action.find("bet")  != string::npos){
                vector<string> action_sp = string_split(one_action,'_');
                if(action_sp.size() != 2)
                    throw runtime_error(tfm::format("bet action sp length %s",action_sp.size()));
                string action_str = action_sp[0];
                action = GameTreeNode::PokerActions::BET;
                if(!(action_str == "bet")) throw runtime_error(tfm::format("Action %s not found",action_str));
                amount = stod(action_sp[1]);

            }else if (one_action.find("raise") != string::npos){
                vector<string> action_sp = string_split(one_action,'_');
                if(action_sp.size() != 2)
                    throw runtime_error(tfm::format("raise action sp length %s",action_sp.size()));
                string action_str = action_sp[0];
                action = GameTreeNode::PokerActions::RAISE;
                if(!(action_str == "raise"))
                    throw runtime_error(tfm::format("Action %s not found",action_str));
                amount = stod(action_sp[1]);
            }else{
                throw runtime_error(tfm::format("%s action not found",one_action));
            }
        }
        shared_ptr<GameTreeNode> one_children_node = recurrentGenerateTreeNode(one_children_map,parent);
        childrens.push_back(one_children_node);

        GameActions game_action = GameActions(action,amount);
        actions.push_back(game_action);
    }
    int player = meta["player"];
    double pot = meta["pot"];
    if(childrens.size() != actions.size()){
        throw runtime_error(tfm::format("childrens length %s, actions length %s"
                ,childrens.size()
                ,actions.size()));
    }
    GameTreeNode::GameRound game_round = strToGameRound(round);
    shared_ptr<ActionNode> actionNode = make_shared<ActionNode>(actions,childrens,player,game_round,pot,parent);
    for(const shared_ptr<GameTreeNode>& one_node: childrens){
        one_node->setParent(std::dynamic_pointer_cast<GameTreeNode>(actionNode));
    }
    return actionNode;

}
```