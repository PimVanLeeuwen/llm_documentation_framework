`api`: The function of `api` is to execute a Texas Hold'em or Short Deck poker game based on the provided input parameters.

**Parameters**:
`const char * input_file`: This parameter specifies the path to an input file that contains game configuration or commands. If this parameter is empty, the function will start the command-line tool in an interactive mode.
`const char * resource_dir = "./resources"`: This parameter specifies the directory where the game resources (e.g., card images, configuration files) are located. The default value is `"./resources"`.
`const char * mode = "holdem"`: This parameter specifies the game mode to be used, either "holdem" for Texas Hold'em or "shortdeck" for Short Deck poker. If an invalid mode is provided, the function will throw a `runtime_error`.

**Code Description**:
The `api` function first checks the value of the `mode` parameter. If the mode is not "holdem" or "shortdeck", it throws a `runtime_error` with an appropriate error message.

If the `input_file` parameter is empty, the function creates a `CommandLineTool` object with the specified `mode` and `resource_dir`, and then calls the `startWorking()` method to start the command-line tool in an interactive mode.

If the `input_file` parameter is not empty, the function prints "EXEC FROM FILE" to the console, creates a `CommandLineTool` object with the specified `mode` and `resource_dir`, and then calls the `execFromFile()` method with the provided `input_file` parameter to execute the game commands from the input file.

The `CommandLineTool` class is responsible for managing the game logic, user input, and output. The constructor of this class initializes various settings and objects required for the Texas Hold'em and Short Deck poker game modes.\\
## Code: 
```
EXPORT
int api(const char * input_file, const char * resource_dir = "./resources", const char * mode = "holdem") {
    string input_file_ = input_file;
    string resource_dir_ = resource_dir;
    string mode_ = mode;

    if(mode_ != "holdem" && mode_ != "shortdeck")
        throw runtime_error(tfm::format("mode %s error, not in ['holdem','shortdeck']", mode_));

    if(input_file_.empty()) {
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.startWorking();
    }else{
        cout << "EXEC FROM FILE" << endl;
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.execFromFile(input_file_);
    }
}
```