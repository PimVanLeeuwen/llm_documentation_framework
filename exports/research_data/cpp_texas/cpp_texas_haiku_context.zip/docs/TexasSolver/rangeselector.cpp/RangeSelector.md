`RangeSelector`: The function of `RangeSelector` is to create a dialog window that allows the user to select a range of cards for a Texas Hold'em or Short Deck poker game.

**Parameters**:
`QTextEdit* rangeEdit`: This parameter is a pointer to a `QTextEdit` widget that will display the selected range.
`QWidget *parent`: This parameter is a pointer to the parent widget of the `RangeSelector` dialog.
`QSolverJob::Mode mode`: This parameter specifies the mode of the poker game, either Texas Hold'em or Short Deck.

**Code Description**:
The `RangeSelector` constructor initializes the dialog and sets up the necessary components. It first determines the list of card ranks based on the specified `mode`. For Texas Hold'em, the ranks are "A,K,Q,J,T,9,8,7,6,5,4,3,2", and for Short Deck, the ranks are "A,K,Q,J,T,9,8,7,6".

The constructor then creates a `RangeSelectorTableModel` and a `RangeSelectorTableDelegate` based on the rank list and the initial range text from the `rangeEdit` widget. These models and delegates are used to populate and manage the range selection table in the dialog.

The constructor sets up the user interface by calling `ui->setupUi(this)` and connecting the necessary signals and slots. It sets the initial range text in the `textEdit` widget, sets the maximum value of the `rangeNumberSlider` to the maximum possible range size, and sets the initial slider value to the maximum.

The constructor also sets the window title to "RangeSelector" and connects several signals from the `rangeTableView` widget to corresponding slots in the `RangeSelector` class. These slots handle user interactions with the range selection table, such as pressing, dragging, and releasing cells.

Finally, the constructor sets up a `QFileSystemModel` to allow the user to browse and select pre-defined range files located in the "ranges" directory.

Overall, the `RangeSelector` class provides a user interface for selecting a range of cards for a poker game, with the ability to load and save pre-defined ranges.\\
## Code: 
```
RangeSelector::RangeSelector(QTextEdit* rangeEdit,QWidget *parent,QSolverJob::Mode mode) :
    QDialog(parent),
    ui(new Ui::RangeSelector)
{

    QString ranks;
    if(mode == QSolverJob::Mode::HOLDEM){
        ranks = "A,K,Q,J,T,9,8,7,6,5,4,3,2";
    }else if(mode == QSolverJob::Mode::SHORTDECK){
        ranks = "A,K,Q,J,T,9,8,7,6";
    }else{
        throw runtime_error("mode not found in range selector");
    }
    this->rank_list = ranks.split(",");
    this->rangeSelectorTableModel = new RangeSelectorTableModel(this->rank_list,rangeEdit->toPlainText(),this);
    this->rangeSelectorTableDelegate = new RangeSelectorTableDelegate(this->rank_list,this->rangeSelectorTableModel,this);
    ui->setupUi(this);
    this->ui->rangeTableView->setModel(this->rangeSelectorTableModel);
    this->ui->rangeTableView->setItemDelegate(this->rangeSelectorTableDelegate);
    this->rangeEdit = rangeEdit;
    this->ui->textEdit->setText(this->rangeEdit->toPlainText());
    this->ui->rangeNumberSlider->setMaximum(this->max_val);
    this->ui->rangeNumberSlider->setValue(this->max_val);
    this->setWindowTitle(tr("RangeSelector"));
    connect(this->ui->rangeTableView,SIGNAL(view_item_pressed(int,int)),this,SLOT(grid_pressed(int,int)));
    connect(this->ui->rangeTableView,SIGNAL(view_item_area(int,int,int,int)),this,SLOT(grid_area(int,int,int,int)));
    connect(this->ui->rangeTableView,SIGNAL(item_release(int,int)),this,SLOT(grid_release(int,int)));

    QStringList filters;
    filters << "*.txt";
    qFileSystemModel = new QFileSystemModel(this);
    QDir filedir = QDir::current().filePath("ranges");
    qFileSystemModel->setRootPath(filedir.path());
#ifdef Q_OS_MAC
```