`mousePressEvent`: The function of `mousePressEvent` is to handle mouse press events on the HTML table view.

**Parameters**:
`QMouseEvent *event`: This parameter represents the mouse press event that occurred. It contains information about the mouse button that was pressed and the position of the mouse cursor.

**Code Description**:
The `mousePressEvent` function is overridden from the base `QTableView` class. It first calls the base class's `mousePressEvent` function to handle the default behavior of the table view.

After that, the function calls the `anchorAt` method to get the anchor (hyperlink) at the position where the mouse was pressed. The result of this call is stored in the `_mousePressAnchor` member variable.

This code is likely part of a larger application that displays an HTML table and allows users to interact with the table, potentially by clicking on hyperlinks within the table cells. The `mousePressEvent` function is responsible for capturing the user's mouse press actions and storing the relevant information, such as the anchor that was clicked, for further processing or handling by the application.\\
## Code: 
```
void HtmlTableView::mousePressEvent(QMouseEvent *event) {
    QTableView::mousePressEvent(event);

    auto anchor = anchorAt(event->pos());
    _mousePressAnchor = anchor;
}
```