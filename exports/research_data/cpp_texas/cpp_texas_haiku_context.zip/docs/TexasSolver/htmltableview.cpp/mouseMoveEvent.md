`mouseMoveEvent`: The function of `mouseMoveEvent` is to handle the mouse movement event within the HtmlTableView widget.

**Parameters**:
`QMouseEvent *event`: This parameter represents the mouse event object that contains information about the current mouse position and state.

**Code Description**:
The `mouseMoveEvent` function is responsible for tracking the movement of the mouse cursor within the HtmlTableView widget. It performs the following tasks:

1. It retrieves the anchor (hyperlink) at the current mouse position using the `anchorAt` function.
2. It checks if the current anchor is different from the previously pressed anchor (`_mousePressAnchor`). If so, it clears the `_mousePressAnchor` variable.
3. It checks if the current hovered anchor (`_lastHoveredAnchor`) is different from the previous one. If so, it updates the `_lastHoveredAnchor` variable and performs the following actions:
   - If the current anchor is not empty (i.e., a valid anchor), it sets the cursor to a pointing hand cursor (`Qt::PointingHandCursor`) and emits a `linkHovered` signal with the anchor text.
   - If the current anchor is empty (i.e., no anchor), it restores the default cursor and emits a `linkUnhovered` signal.

This behavior allows the HtmlTableView to provide visual feedback to the user by changing the cursor shape when the mouse hovers over a hyperlink, and to emit signals to notify other parts of the application about the link hover and unhover events.\\
## Code: 
```
void HtmlTableView::mouseMoveEvent(QMouseEvent *event) {
    auto anchor = anchorAt(event->pos());

    if (_mousePressAnchor != anchor) {
        _mousePressAnchor.clear();
    }

    if (_lastHoveredAnchor != anchor) {
        _lastHoveredAnchor = anchor;
        if (!_lastHoveredAnchor.isEmpty()) {
            QApplication::setOverrideCursor(QCursor(Qt::PointingHandCursor));
            emit linkHovered(_lastHoveredAnchor);
        } else {
            QApplication::restoreOverrideCursor();
            emit linkUnhovered();
        }
    }
}
```