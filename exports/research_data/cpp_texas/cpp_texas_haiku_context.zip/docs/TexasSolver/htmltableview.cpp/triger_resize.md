`triger_resize`: The function of `triger_resize` is to trigger a resize event for the `HtmlTableView` object.

**Code Description**: The `triger_resize()` method is responsible for triggering a resize event for the `HtmlTableView` object. It does this by creating a new `QResizeEvent` object with the current size of the `HtmlTableView` object, and then calling the `resizeEvent()` method on the `HtmlTableView` object, passing the newly created `QResizeEvent` object as an argument. This effectively simulates a resize event, which can be useful for updating the layout and appearance of the table view when the size of the view changes.

The commented-out line `this->resize(this->parentWidget()->size());` suggests that an alternative approach was considered, which would have resized the `HtmlTableView` object to match the size of its parent widget. However, this line is currently not being used, and the method instead relies on the `resizeEvent()` method to handle the resize logic.

Overall, the `triger_resize()` method is a utility function that can be used to trigger a resize event for the `HtmlTableView` object, which can be useful for updating the layout and appearance of the table view in response to changes in the size of the view.\\
## Code: 
```
void HtmlTableView::triger_resize(){
    QResizeEvent* ev = new QResizeEvent(this->size(),this->size());
    this->resizeEvent(ev);
    //this->resize(this->parentWidget()->size());
    delete ev;
}
```