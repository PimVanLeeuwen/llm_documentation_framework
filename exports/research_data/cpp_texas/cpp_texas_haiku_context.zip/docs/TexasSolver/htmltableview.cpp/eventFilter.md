`eventFilter`: The function of `eventFilter` is to handle mouse events on the viewport of the `HtmlTableView` widget.

**Parameters**:
`QObject *watched`: The object that triggered the event being filtered.
`QEvent *event`: The event object that needs to be filtered.

**Code Description**:
The `eventFilter` function is overridden from the base `QTableView` class to provide custom event handling for the `HtmlTableView` widget. The function checks if the `watched` object is the viewport of the table view. If so, it checks the type of the `event` object.

If the event is a `QEvent::MouseMove` event, the function retrieves the model index at the current mouse position using the `indexAt` method. If the index is valid, it checks if the row and column indices have changed since the last mouse move event. If they have, it updates the `last_bearing_i` and `last_bearing_j` member variables and emits the `itemMouseChange` signal with the new row and column indices.

If the event is a `QEvent::Leave` event, the function does not perform any additional actions.

Finally, the function calls the base class's `eventFilter` implementation to allow the default event handling to occur.

The purpose of this code is to track the row and column indices of the table cell under the mouse cursor and emit a signal whenever the mouse moves to a different cell. This functionality can be useful for providing additional information or interactions related to the table cells, such as displaying tooltips or highlighting the current cell.\\
## Code: 
```
bool HtmlTableView::eventFilter(QObject *watched, QEvent *event){
    if(viewport() == watched){
        if(event->type() == QEvent::MouseMove){
        QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
        QModelIndex index = indexAt(mouseEvent->pos());
        if(index.isValid()){
            int i = index.row();
            int j = index.column();
            if(i != this->last_bearing_i || j != last_bearing_j){
                this->last_bearing_i = i;
                this->last_bearing_j = j;
                emit itemMouseChange(i,j);
            }
        }
        else{
        }
        }
        else if(event->type() == QEvent::Leave){
        }
    }
    return QTableView::eventFilter(watched, event);
}
```