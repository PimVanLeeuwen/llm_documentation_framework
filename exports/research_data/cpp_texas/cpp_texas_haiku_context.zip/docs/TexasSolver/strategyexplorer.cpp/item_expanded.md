`item_expanded`: The function of `item_expanded` is to expand the children of a tree item in the game tree view.

**Parameters**:
`const QModelIndex& index`: This parameter represents the index of the tree item that has been expanded in the game tree view.

**Code Description**:
The `item_expanded` function is called when a tree item in the game tree view is expanded. It performs the following steps:

1. It retrieves the `TreeItem` object associated with the expanded index using `static_cast<TreeItem*>(index.internalPointer())`.
2. It gets the number of child items of the expanded tree item using `item->childCount()`.
3. It iterates through each child item of the expanded tree item.
4. For each child item, it checks if the child item has any children of its own using `one_child->childCount() != 0`.
5. If the child item has no children, it calls the `reGenerateTreeItem` method of the `tree_model` object associated with the `gameTreeView` widget.
6. The `reGenerateTreeItem` method is called with the `getRound()` value of the child item's `m_treedata` object and the child item itself as parameters.

The purpose of this function is to ensure that the game tree view is properly updated when a tree item is expanded. If a child item has no children, the `reGenerateTreeItem` method is called to generate the necessary tree items for that child, effectively expanding the game tree view.\\
## Code: 
```
void StrategyExplorer::item_expanded(const QModelIndex& index){
    TreeItem *item = static_cast<TreeItem*>(index.internalPointer());
    int num_child = item->childCount();
    for (int i = 0;i < num_child;i ++){
        TreeItem* one_child = item->child(i);
        if(one_child->childCount() != 0)continue;
        this->ui->gameTreeView->tree_model->reGenerateTreeItem(one_child->m_treedata.lock()->getRound(),one_child);
    }
}
```