`on_oopRangeButtom_clicked`: The function of `on_oopRangeButtom_clicked` is to update the user interface and trigger related model changes when the "OOP Range" button is clicked.

**Code Description**: The `on_oopRangeButtom_clicked()` method is responsible for handling the user's interaction with the "OOP Range" button in the StrategyExplorer UI. When the button is clicked, the method performs the following actions:

1. It sets the `mode` property of the `detailWindowSetting` object to `DetailWindowMode::RANGE_OOP`, indicating that the detail view should display the OOP (Out-of-Position) range information.

2. It updates the viewport of the `strategyTableView` and `detailView` widgets, which are likely used to display strategy-related information. This ensures that the UI is refreshed to reflect the new mode.

3. It calls the `onchanged()` method of the `roughStrategyViewerModel` object. This likely triggers an update to the "Rough Strategy View" in the UI, which may display a high-level overview of the strategy being explored.

4. It updates the viewport of the `roughStrategyView` widget, ensuring that the "Rough Strategy View" is also refreshed to reflect the changes.

The purpose of this method is to provide a way for the user to switch the detail view to the OOP range mode, and to update the related UI elements and models accordingly. This allows the user to explore and analyze the OOP range information within the TexasSolver application.\\
## Code: 
```
void StrategyExplorer::on_oopRangeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::RANGE_OOP;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```