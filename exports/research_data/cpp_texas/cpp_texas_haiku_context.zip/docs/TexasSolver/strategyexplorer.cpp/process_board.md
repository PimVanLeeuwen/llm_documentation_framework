`process_board`: The function of `process_board` is to process the board cards and update the UI with the current board state.

**Parameters**:
`TreeItem* treeitem`: This parameter represents a pointer to a `TreeItem` object, which is likely part of a game tree data structure. The function uses this object to determine the current game round and retrieve any additional cards that should be displayed on the board.

**Code Description**:
1. The function first splits the `board` string (which is a member variable of the `qSolverJob` object) into a vector of individual card strings using the `string_split` function.
2. It then creates a vector of `Card` objects, one for each card string in the `board_str_arr` vector.
3. If the `treeitem` parameter is not `NULL`, the function checks the current game round:
   - If the round is `TURN` and the `tableStrategyModel` has a non-empty `trunCard`, the function adds that card to the `cards` vector.
   - If the round is `RIVER`, the function adds the `trunCard` and `riverCard` from the `tableStrategyModel` to the `cards` vector (if they are non-empty).
4. Finally, the function updates the `boardLabel` UI element with an HTML-formatted string representing the current board cards, using the `Card::boardCards2html` function.

The purpose of this function is to ensure that the UI displays the correct board cards based on the current game state, as represented by the `treeitem` parameter and the data in the `tableStrategyModel` object.\\
## Code: 
```
void StrategyExplorer::process_board(TreeItem* treeitem){
    vector<string> board_str_arr = string_split(this->qSolverJob->board,',');
    vector<Card> cards;
    for(string one_board_str:board_str_arr){
        cards.push_back(Card(one_board_str));
    }
    if(treeitem != NULL){
        if(treeitem->m_treedata.lock()->getRound() == GameTreeNode::GameRound::TURN && !this->tableStrategyModel->getTrunCard().empty()){
            cards.push_back(Card(this->tableStrategyModel->getTrunCard()));
        }
        else if(treeitem->m_treedata.lock()->getRound() == GameTreeNode::GameRound::RIVER){
            if(!this->tableStrategyModel->getTrunCard().empty())
                cards.push_back(Card(this->tableStrategyModel->getTrunCard()));
            if(!this->tableStrategyModel->getRiverCard().empty())
                cards.push_back(Card(this->tableStrategyModel->getRiverCard()));
        }
    }
    this->ui->boardLabel->setText(QString("<b>%1: </b>").arg(tr("board")) + Card::boardCards2html(cards));
}
```