`on_evOnlyModeButtom_clicked`: The function of `on_evOnlyModeButtom_clicked` is to set the detail window mode to `EV_ONLY`, update the viewport of the strategy table view, detail view, and rough strategy view, and notify the `roughStrategyViewerModel` that the data has changed.

**Code Description**: The `on_evOnlyModeButtom_clicked` method is a member function of the `StrategyExplorer` class. It is responsible for handling the user's interaction with the "EV Only" button in the application's user interface.

When the "EV Only" button is clicked, the method performs the following actions:

1. It sets the `mode` property of the `detailWindowSetting` object to `DetailWindowSetting::DetailWindowMode::EV_ONLY`. This indicates that the detail window should display information related to the "EV Only" mode.

2. It calls the `update()` method on the viewport of the `strategyTableView` and `detailView` widgets. This ensures that the visual representation of these views is updated to reflect the new "EV Only" mode.

3. It calls the `onchanged()` method on the `roughStrategyViewerModel` object. This method emits a `headerDataChanged` signal, which notifies the associated view that the header data has changed, spanning all columns in the model. This is likely done to trigger a refresh of the rough strategy view, ensuring that it displays the appropriate information for the "EV Only" mode.

4. Finally, it calls the `update()` method on the viewport of the `roughStrategyView` widget. This ensures that the visual representation of the rough strategy view is updated to reflect the changes made in the previous steps.

Overall, the `on_evOnlyModeButtom_clicked` method is responsible for updating the application's state and user interface to display the "EV Only" mode, which is likely a specific view or configuration of the strategy exploration functionality provided by the `StrategyExplorer` class.\\
## Code: 
```
void StrategyExplorer::on_evOnlyModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::EV_ONLY;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```