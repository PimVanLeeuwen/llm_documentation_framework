`item_clicked`: The function of `item_clicked` is to handle the user's click on an item in the game tree view.

**Parameters**:
`const QModelIndex& index`: This parameter represents the index of the clicked item in the game tree model.

**Code Description**:
The `item_clicked` function is responsible for processing the user's click on a node in the game tree. It performs the following tasks:

1. It retrieves the `TreeItem` pointer associated with the clicked index using `static_cast<TreeItem*>(index.internalPointer())`.
2. It calls the `process_treeclick` method, passing the retrieved `TreeItem` pointer as an argument. This method likely handles the display of different types of game tree nodes (action, chance, terminal, and showdown) based on the clicked node.
3. It calls the `process_board` method, also passing the `TreeItem` pointer. This method is responsible for processing the board cards in the Texas Hold'em game, splitting the board string into individual card strings, creating `Card` objects, and updating the UI to display the board cards.
4. It sets the `treeItem` member variable of the `TableStrategyModel` class to the clicked `TreeItem` pointer using the `setGameTreeNode` method.
5. It calls the `updateStrategyData` method of the `TableStrategyModel` class. This method is responsible for updating the strategy data in the table strategy model, including calculating the strategy and expected values, and updating the player's card ranges based on the chosen actions.
6. It triggers a viewport update for the `strategyTableView` widget to ensure the updated strategy data is displayed.
7. It calls the `onchanged` method of the `RoughStrategyViewerModel` class, which likely emits a `headerDataChanged` signal to notify the view that the header data has changed, spanning all columns in the model.
8. It triggers a resize of the `roughStrategyView` widget using the `triger_resize` method, which creates a `QResizeEvent` object and passes it to the `resizeEvent` method of the `HtmlTableView` class.
9. It triggers a viewport update for the `roughStrategyView` widget to ensure the updated strategy data is displayed.\\
## Code: 
```
void StrategyExplorer::item_clicked(const QModelIndex& index){
    try{
        TreeItem * treeNode = static_cast<TreeItem*>(index.internalPointer());
        this->process_treeclick(treeNode);
        this->process_board(treeNode);
        this->tableStrategyModel->setGameTreeNode(treeNode);
        this->tableStrategyModel->updateStrategyData();
        this->ui->strategyTableView->viewport()->update();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->triger_resize();
        this->ui->roughStrategyView->viewport()->update();
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```