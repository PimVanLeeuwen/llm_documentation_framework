`on_turnCardBox_currentIndexChanged`: The function of `on_turnCardBox_currentIndexChanged` is to update the table strategy model and the UI when the user selects a different turn card from the `turnCardBox` dropdown.

**Parameters**:
`int index`: The index of the selected turn card in the `turnCardBox` dropdown.

**Code Description**:
The function first checks if there are any cards in the `cards` vector and if the selected index is within the range of the `cards` vector. If so, it performs the following actions:

1. It sets the `turn_card` property of the `TableStrategyModel` to the card at the selected index in the `cards` vector.
2. It calls the `updateStrategyData()` method of the `TableStrategyModel` to update the strategy data based on the new turn card.
3. It calls the `process_board()` method, passing the `treeItem` property of the `TableStrategyModel` as an argument. This method likely processes the board cards and updates the UI accordingly.

After these updates, the function calls `viewport()->update()` on the `strategyTableView` and `detailView` widgets to ensure the UI is refreshed and displays the updated information.

The commented-out code at the end of the function suggests that there were some issues with calling the `onchanged()` method of the `roughStrategyViewerModel` and updating the `roughStrategyView` widget, which caused bugs or crashes. The developer has left a TODO comment to investigate and resolve these issues.

Overall, the `on_turnCardBox_currentIndexChanged` function is responsible for updating the table strategy model and the UI when the user selects a different turn card, ensuring that the application displays the correct strategy information based on the selected turn card.\\
## Code: 
```
void StrategyExplorer::on_turnCardBox_currentIndexChanged(int index)
{
    if(this->cards.size() > 0 && index < this->cards.size()){
        this->tableStrategyModel->setTrunCard(this->cards[index]);
        this->tableStrategyModel->updateStrategyData();
        // TODO this somehow cause bugs, crashes, why?
        //this->roughStrategyViewerModel->onchanged();
        //this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```