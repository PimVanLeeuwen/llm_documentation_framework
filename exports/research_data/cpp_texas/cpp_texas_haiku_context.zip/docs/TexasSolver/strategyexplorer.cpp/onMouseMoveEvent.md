`onMouseMoveEvent`: The function of `onMouseMoveEvent` is to update the detail window settings and trigger a viewport update for the detail view and strategy table view.

**Parameters**:
`int i`: The row index of the grid where the mouse is currently positioned.
`int j`: The column index of the grid where the mouse is currently positioned.

**Code Description**: The `onMouseMoveEvent` function is responsible for handling the mouse move event within the StrategyExplorer class. When the mouse is moved over the grid, this function is called to update the detail window settings with the current grid coordinates (`i` and `j`). After updating the detail window settings, the function triggers a viewport update for both the `detailView` and `strategyTableView` widgets. This ensures that the UI elements reflecting the detail information are updated to reflect the new mouse position within the grid.

The purpose of this function is to provide a responsive and interactive user experience, where the detail information displayed in the UI is dynamically updated as the user moves the mouse over the grid. This allows the user to quickly inspect and understand the details of the strategy being explored, without the need to manually select or click on specific grid cells.\\
## Code: 
```
void StrategyExplorer::onMouseMoveEvent(int i,int j){
    this->detailWindowSetting.grid_i = i;
    this->detailWindowSetting.grid_j = j;
    this->ui->detailView->viewport()->update();
    this->ui->strategyTableView->viewport()->update();
}
```