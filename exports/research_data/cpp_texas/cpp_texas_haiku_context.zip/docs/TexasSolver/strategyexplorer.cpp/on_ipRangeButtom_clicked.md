`on_ipRangeButtom_clicked`: The function of `on_ipRangeButtom_clicked` is to update the UI and models when the "IP Range" button is clicked.

**Code Description**: The `on_ipRangeButtom_clicked()` method is responsible for handling the user's interaction with the "IP Range" button in the StrategyExplorer UI. When the button is clicked, the method performs the following actions:

1. It sets the `mode` property of the `detailWindowSetting` object to `DetailWindowSetting::DetailWindowMode::RANGE_IP`, indicating that the detail view should display information related to IP ranges.

2. It updates the viewport of the `strategyTableView` and `detailView` widgets, which are likely used to display strategy-related information. This ensures that the UI is refreshed to reflect the new mode.

3. It calls the `onchanged()` method of the `roughStrategyViewerModel` object. This model is likely responsible for managing the data and presentation of the "rough strategy" view in the UI. The `onchanged()` method emits a `headerDataChanged` signal to notify the view that the header data has changed, which triggers a refresh of the view.

4. It updates the viewport of the `roughStrategyView` widget, which is likely used to display the "rough strategy" information. This ensures that the UI is refreshed to reflect the changes made by the `onchanged()` method.

In summary, the `on_ipRangeButtom_clicked()` method is responsible for updating the UI and models when the user interacts with the "IP Range" button in the StrategyExplorer application. It sets the appropriate mode, updates the relevant views, and notifies the models of the changes, ensuring that the application's UI reflects the user's actions.\\
## Code: 
```
void StrategyExplorer::on_ipRangeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::RANGE_IP;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```