`on_strategyModeButtom_clicked`: The function of `on_strategyModeButtom_clicked` is to update the user interface when the "Strategy Mode" button is clicked.

**Code Description**: The `on_strategyModeButtom_clicked()` method is responsible for updating the user interface when the "Strategy Mode" button is clicked. It performs the following actions:

1. Sets the `mode` property of the `DetailWindowSetting` object to `DetailWindowMode::STRATEGY`, indicating that the detail view should be in "Strategy" mode.

2. Updates the viewport of the `strategyTableView` and `detailView` widgets to ensure they are redrawn with the updated settings.

3. Calls the `onchanged()` method of the `roughStrategyViewerModel` object, which emits a `headerDataChanged` signal to notify the associated view that the header data has changed. This ensures the view is updated to reflect the changes in the model.

4. Updates the viewport of the `roughStrategyView` widget to ensure it is redrawn with the updated data.

The purpose of this method is to provide a way for the user to switch the application's mode to "Strategy" mode, which likely involves displaying different information or views related to the strategy being explored. By updating the various UI elements, the method ensures the application's state is properly synchronized with the user's interaction.\\
## Code: 
```
void StrategyExplorer::on_strategyModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::STRATEGY;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```