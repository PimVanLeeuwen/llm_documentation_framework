`process_treeclick`: The function of `process_treeclick` is to display the type of game tree node that has been clicked in the user interface.

**Parameters**:
`TreeItem* treeitem`: This parameter represents the tree item that has been clicked in the user interface. It contains the data associated with the clicked node.

**Code Description**:
The `process_treeclick` function first retrieves the `GameTreeNode` associated with the clicked `TreeItem` using the `m_treedata` member. It then checks the type of the `GameTreeNode` and sets the text of the `nodeDisplayLabel` in the user interface accordingly.

If the node is an `ActionNode`, the function displays a string indicating that it is an "IP decision node" or an "OOP decision node" based on the player associated with the node.

If the node is a `ChanceNode`, the function displays a string indicating that it is a "Chance node".

If the node is a `TerminalNode`, the function displays a string indicating that it is a "Terminal node".

If the node is a `ShowdownNode`, the function displays a string indicating that it is a "Showdown node".

The purpose of this function is to provide visual feedback to the user about the type of game tree node that has been clicked, which can be useful for understanding the structure and flow of the game tree being explored.\\
## Code: 
```
void StrategyExplorer::process_treeclick(TreeItem* treeitem){
    shared_ptr<GameTreeNode> treenode = treeitem->m_treedata.lock();
    if(treenode->getType() == GameTreeNode::GameTreeNodeType::ACTION){
        shared_ptr<ActionNode> actionnode = static_pointer_cast<ActionNode>(treenode);
        QString action_str = QString("<b>%1 %2</b>").arg(actionnode->getPlayer() == 0?tr("IP"):tr("OOP"),tr(" decision node"));
        this->ui->nodeDisplayLabel->setText(action_str);
    }
    else if(treenode->getType() == GameTreeNode::GameTreeNodeType::CHANCE){
        QString chance_str = tr("<b>Chance node</b>");
        this->ui->nodeDisplayLabel->setText(chance_str);
    }
    else if(treenode->getType() == GameTreeNode::GameTreeNodeType::TERMINAL){
        QString terminal_str = tr("<b>Terminal node</b>");
        this->ui->nodeDisplayLabel->setText(terminal_str);
    }
    else if(treenode->getType() == GameTreeNode::GameTreeNodeType::SHOWDOWN){
        QString showdown_str = tr("<b>Showdown node</b>");
        this->ui->nodeDisplayLabel->setText(showdown_str);
    }
}
```