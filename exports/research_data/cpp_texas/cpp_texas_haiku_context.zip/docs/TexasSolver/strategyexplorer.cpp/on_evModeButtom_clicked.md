`on_evModeButtom_clicked`: The function of `on_evModeButtom_clicked` is to update the user interface (UI) of the StrategyExplorer application when the "EV Mode" button is clicked.

**Code Description**: The `on_evModeButtom_clicked()` method is responsible for handling the user's interaction with the "EV Mode" button in the StrategyExplorer application. When the button is clicked, the method performs the following actions:

1. It sets the `mode` property of the `detailWindowSetting` object to `DetailWindowSetting::DetailWindowMode::EV`. This indicates that the application should switch to the "EV Mode" view.

2. It calls the `update()` method on the `viewport()` of the following UI elements:
   - `ui->strategyTableView`: This updates the strategy table view, which likely displays information related to the EV (expected value) mode.
   - `ui->detailView`: This updates the detail view, which may provide additional information or visualization related to the EV mode.
   - `ui->roughStrategyView`: This updates the rough strategy view, which could show a high-level overview of the strategy in the EV mode.

The purpose of these viewport updates is to ensure that the UI elements are properly refreshed and reflect the changes made when the "EV Mode" button is clicked. This allows the user to see the updated information and visualizations related to the EV mode.

The code does not include any calls to external methods or functions, so the functionality is limited to the UI updates within the StrategyExplorer application.\\
## Code: 
```
void StrategyExplorer::on_evModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::EV;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->ui->roughStrategyView->viewport()->update();
}
```