# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/strategyexplorer.cpp` \
**Type:** `Method` \
**Method Name:** `onMouseMoveEvent` \
**Code Content:** \
`void StrategyExplorer::onMouseMoveEvent(int i,int j){
    this->detailWindowSetting.grid_i = i;
    this->detailWindowSetting.grid_j = j;
    this->ui->detailView->viewport()->update();
    this->ui->strategyTableView->viewport()->update();
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/progressbar.cpp.update 
 - Explanation:  _This method updates a progress bar display, showing the completion percentage and optionally a visual bar. It handles the formatting and display of the progress, including erasing and redrawing characters to create a dynamic update effect in the console._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`onMouseMoveEvent`: The function of `onMouseMoveEvent` is *FILL IN* 
**Parameters**:\
`int i`: *FILL IN* \
`int j`: *FILL IN* \

**Code Description**: *FILL IN*
