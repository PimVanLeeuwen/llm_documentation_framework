# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/GameTree.cpp` \
**Type:** `Method` \
**Method Name:** `generateActionNode` \
**Code Content:** \
`shared_ptr<ActionNode>
GameTree::generateActionNode(json meta, vector<string> childrens_actions, vector<json> childrens_nodes, const string& round,
                             shared_ptr<GameTreeNode> parent) {
    if(childrens_actions.size() != childrens_nodes.size()){
        throw runtime_error(
                tfm::format(
                        "mismatch when generate ActionNode, childrens_action length %s children_nodes length %s",
                        childrens_actions.size(),
                        childrens_nodes.size()
                ));
    }

    if(! (   round == "preflop"
          || round == "flop"
          || round == "turn"
          || round == "river"
          )
            ){
        throw runtime_error(tfm::format("round %s not found",round));
    }

    vector<GameActions> actions;
    vector<shared_ptr<GameTreeNode>> childrens;

    // 遍历所有children actions 来生成GameAction 的list，用于初始化ActionNode
    for(std::size_t i = 0;i < childrens_actions.size();i++){
        string one_action = childrens_actions[i];
        json one_children_map = childrens_nodes[i];
        if(one_action.empty()) throw runtime_error("action is null");

        GameTreeNode::PokerActions action;
        double amount = -1;
        if(one_action == "check"){
            action = GameTreeNode::PokerActions::CHECK;
        }
        else if(one_action == "fold"){
            action = GameTreeNode::PokerActions::FOLD;
        }
        else if(one_action == "call"){
            action = GameTreeNode::PokerActions::CALL;
        }
        else{
            if(one_action.find("bet")  != string::npos){
                vector<string> action_sp = string_split(one_action,'_');
                if(action_sp.size() != 2)
                    throw runtime_error(tfm::format("bet action sp length %s",action_sp.size()));
                string action_str = action_sp[0];
                action = GameTreeNode::PokerActions::BET;
                if(!(action_str == "bet")) throw runtime_error(tfm::format("Action %s not found",action_str));
                amount = stod(action_sp[1]);

            }else if (one_action.find("raise") != string::npos){
                vector<string> action_sp = string_split(one_action,'_');
                if(action_sp.size() != 2)
                    throw runtime_error(tfm::format("raise action sp length %s",action_sp.size()));
                string action_str = action_sp[0];
                action = GameTreeNode::PokerActions::RAISE;
                if(!(action_str == "raise"))
                    throw runtime_error(tfm::format("Action %s not found",action_str));
                amount = stod(action_sp[1]);
            }else{
                throw runtime_error(tfm::format("%s action not found",one_action));
            }
        }
        shared_ptr<GameTreeNode> one_children_node = recurrentGenerateTreeNode(one_children_map,parent);
        childrens.push_back(one_children_node);

        GameActions game_action = GameActions(action,amount);
        actions.push_back(game_action);
    }
    int player = meta["player"];
    double pot = meta["pot"];
    if(childrens.size() != actions.size()){
        throw runtime_error(tfm::format("childrens length %s, actions length %s"
                ,childrens.size()
                ,actions.size()));
    }
    GameTreeNode::GameRound game_round = strToGameRound(round);
    shared_ptr<ActionNode> actionNode = make_shared<ActionNode>(actions,childrens,player,game_round,pot,parent);
    for(const shared_ptr<GameTreeNode>& one_node: childrens){
        one_node->setParent(std::dynamic_pointer_cast<GameTreeNode>(actionNode));
    }
    return actionNode;

}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/GameTree.cpp.recurrentGenerateTreeNode 
 - Explanation:  _This method recursively generates a game tree node based on JSON input, handling different node types (Action, Showdown, Terminal, Chance). It processes the node's metadata, validates input, and creates the appropriate node type by calling specific generation methods._ 
### TexasSolver/TexasSolver/library.cpp.string_split 
 - Explanation:  _This function splits a given string into a vector of substrings using a specified delimiter character. It utilizes a stringstream to tokenize the input string and populate the vector with the resulting substrings._ 
### TexasSolver/TexasSolver/GameTree.cpp.strToGameRound 
 - Explanation:  _This method converts a string representation of a poker game round to its corresponding GameRound enum value. It uses a series of if-else statements to match the input string and throws a runtime error if an invalid round is provided._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.GameTreeNode 
 - Explanation:  _This code defines a constructor for the GameTreeNode class, initializing a node with a game round, pot size, and parent node. It sets the round and pot values directly, and moves the parent pointer to the node's parent member variable._ 
### TexasSolver/TexasSolver/Card.cpp.empty 
 - Explanation:  _This method checks if the Card object is empty. It returns true if the card's value is "empty", and false otherwise._ 
### TexasSolver/TexasSolver/src/ActionNode.cpp.ActionNode 
 - Explanation:  _This code defines the constructor for the `ActionNode` class, which is derived from `GameTreeNode`. It initializes the node with actions, children nodes, player information, game round, pot size, and a parent node, setting up the structure for a game decision tree._ 
### TexasSolver/TexasSolver/src/GameActions.cpp.GameActions 
 - Explanation:  _This constructor initializes a GameActions object with a given poker action and amount. It validates that raise/bet actions have a non-negative amount, while other actions have an amount of -1, throwing exceptions for invalid inputs._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.setParent 
 - Explanation:  _This method sets the parent node of the current GameTreeNode object. It takes a shared pointer to another GameTreeNode as an argument and assigns it to the 'parent' member variable of the current node._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`generateActionNode`: The function of `generateActionNode` is *FILL IN* 
**Parameters**:\
`json meta`: *FILL IN* \
`vector<string> childrens_actions`: *FILL IN* \
`vector<json> childrens_nodes`: *FILL IN* \
`const string& round`: *FILL IN* \
`shared_ptr<GameTreeNode> parent`: *FILL IN* \

**Code Description**: *FILL IN*
