# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/GameTree.cpp` \
**Type:** `Method` \
**Method Name:** `recurrentGenerateTreeNode` \
**Code Content:** \
`shared_ptr<GameTreeNode> GameTree::recurrentGenerateTreeNode(json node_json, const shared_ptr<GameTreeNode>& parent) {
    json meta = node_json["meta"];
    string round = meta["round"];
    if(round.empty()){
        throw runtime_error("node json get round null pointer");
    }

    if(! (round == "preflop"
          || round == "flop"
          || round == "turn"
          || round == "river"
          )
            ){
        throw runtime_error(tfm::format("round %s not found",round));
    }

    string node_type = meta["node_type"];
    if(node_type.empty()){
        throw runtime_error("node json get round null pointer");
    }
    if (! (   node_type == "Terminal"
           || node_type == "Showdown"
           || node_type ==  "Action"
           || node_type ==  "Chance"
    )
            ){
        throw runtime_error(tfm::format("node type %s not found",node_type));
    }

    if(node_type == "Action") {
        // 孩子节点的动作，存在list里
        auto childrens_actions = node_json["children_actions"].get<std::vector<string>>();
        // 孩子节点本身，同样存在list里,和上面的children_actions 一一对应,事实上两者的长度一致
        vector<json> childrens = node_json["children"].get<std::vector<json>>();
        if (childrens.size() != childrens_actions.size()) {
            throw runtime_error("action node child length mismatch");
        }
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateActionNode(meta, childrens_actions, childrens, round,parent));
    }
    else if(node_type == "Showdown") {
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateShowdownNode(meta, round,parent));
    }
    else if(node_type == "Terminal") {
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateTerminalNode(meta, round,parent));
    }
    else if(node_type == "Chance") {
        auto childrens = node_json["children"].get<std::vector<json>>();
        if(childrens.size() != 1) throw runtime_error("Chance node should have only one child");
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateChanceNode(meta, childrens[0], round,parent));
    }
    else{
        throw runtime_error(tfm::format("node type %s not found",node_type));
    }
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/GameTree.cpp.generateChanceNode 
### TexasSolver/TexasSolver/GameTree.cpp.generateTerminalNode 
 - Explanation:  _This method generates a TerminalNode for a game tree, representing the end state of a poker game. It processes player payoffs, pot size, game round, and player information from JSON data to create and return a shared pointer to a TerminalNode object._ 
### TexasSolver/TexasSolver/Card.cpp.empty 
 - Explanation:  _This method checks if the Card object is empty. It returns true if the card's value is "empty", and false otherwise._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.GameTreeNode 
 - Explanation:  _This code defines a constructor for the GameTreeNode class, initializing a node with a game round, pot size, and parent node. It sets the round and pot values directly, and moves the parent pointer to the node's parent member variable._ 
### TexasSolver/TexasSolver/GameTree.cpp.generateActionNode 
### TexasSolver/TexasSolver/GameTree.cpp.generateShowdownNode 
 - Explanation:  _This method generates a ShowdownNode for a poker game tree, processing payoff information from JSON data. It extracts tie and player-specific payoffs, converts the game round string to an enum, and creates a ShowdownNode with the processed data._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`recurrentGenerateTreeNode`: The function of `recurrentGenerateTreeNode` is *FILL IN* 
**Parameters**:\
`json node_json`: *FILL IN* \
`const shared_ptr<GameTreeNode>& parent`: *FILL IN* \

**Code Description**: *FILL IN*
