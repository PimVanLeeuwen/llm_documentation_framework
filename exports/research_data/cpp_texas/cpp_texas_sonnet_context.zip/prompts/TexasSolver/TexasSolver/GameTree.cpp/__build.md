# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/GameTree.cpp` \
**Type:** `Method` \
**Method Name:** `__build` \
**Code Content:** \
`shared_ptr<GameTreeNode> GameTree::__build(shared_ptr<GameTreeNode> node, Rule rule, string last_action,
                                           int check_times, int raise_times) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            this->buildAction(std::dynamic_pointer_cast<ActionNode>(node),rule,last_action,check_times,raise_times);
            break;
        }case GameTreeNode::SHOWDOWN: {
            break;
        }case GameTreeNode::TERMINAL: {
            break;
        }case GameTreeNode::CHANCE: {
            this->buildChance(std::dynamic_pointer_cast<ChanceNode>(node),rule);
            break;
        }default:
            throw runtime_error("node type unknown");
    }
    return node;
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/ActionNode.cpp.ActionNode 
 - Explanation:  _This code defines the constructor for the `ActionNode` class, which is derived from `GameTreeNode`. It initializes the node with actions, children nodes, player information, game round, pot size, and a parent node, setting up the structure for a game decision tree._ 
### TexasSolver/TexasSolver/GameTree.cpp.buildChance 
### TexasSolver/TexasSolver/GameTree.cpp.buildAction 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.ChanceNode 
 - Explanation:  _This code defines the constructor for the ChanceNode class, which is derived from GameTreeNode. It initializes the ChanceNode object with various parameters including children nodes, game round, pot size, parent node, cards, and a donk flag, setting up the structure for a chance node in a game tree._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`__build`: The function of `__build` is *FILL IN* 
**Parameters**:\
`shared_ptr<GameTreeNode> node`: *FILL IN* \
`Rule rule`: *FILL IN* \
`string last_action`: *FILL IN* \
`int check_times`: *FILL IN* \
`int raise_times`: *FILL IN* \

**Code Description**: *FILL IN*
