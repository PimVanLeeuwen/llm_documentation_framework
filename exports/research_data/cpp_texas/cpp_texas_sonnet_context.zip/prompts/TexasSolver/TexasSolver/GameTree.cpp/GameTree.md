# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/GameTree.cpp` \
**Type:** `Method` \
**Method Name:** `GameTree` \
**Code Content:** \
`GameTree::GameTree(Deck deck,
                   float oop_commit,
                   float ip_commit,
                   int current_round,
                   int raise_limit,
                   float small_blind,
                   float big_blind,
                   float stack,
                   GameTreeBuildingSettings buildingSettings,
                   float allin_threshold
){
    Rule rule = Rule(deck,oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,buildingSettings,allin_threshold);
    int current_player = 1;
    this->deck = deck;
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(rule.current_round);
    shared_ptr<ActionNode> node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(),current_player, round, (double) rule.get_pot(),
                                 nullptr);
    this->__build(node,rule);
    this->root = node;
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/Rule.cpp.Rule 
 - Explanation:  _This code defines a constructor for the `Rule` class, initializing various game parameters such as deck, commitments, round, raise limits, blinds, and stack sizes. It also performs a check to ensure that the out-of-position (oop) and in-position (ip) commitments are equal, throwing an exception if they're not._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.intToGameRound 
 - Explanation:  _This method converts an integer representation of a game round to the corresponding GameRound enum value in the GameTreeNode class. It uses a switch statement to map integers 0-3 to PREFLOP, FLOP, TURN, and RIVER respectively, throwing an error for invalid inputs._ 
### TexasSolver/TexasSolver/GameTree.cpp.__build 
### TexasSolver/TexasSolver/src/ActionNode.cpp.ActionNode 
 - Explanation:  _This code defines the constructor for the `ActionNode` class, which is derived from `GameTreeNode`. It initializes the node with actions, children nodes, player information, game round, pot size, and a parent node, setting up the structure for a game decision tree._ 
### TexasSolver/TexasSolver/src/Rule.cpp.get_pot 
 - Explanation:  _This method returns the total pot size in a poker game by summing the out-of-position (oop) and in-position (ip) player commitments. It's a simple accessor function that retrieves the combined value of two member variables._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`GameTree`: The function of `GameTree` is *FILL IN* 
**Parameters**:\
`Deck deck`: *FILL IN* \
`float oop_commit`: *FILL IN* \
`float ip_commit`: *FILL IN* \
`int current_round`: *FILL IN* \
`int raise_limit`: *FILL IN* \
`float small_blind`: *FILL IN* \
`float big_blind`: *FILL IN* \
`float stack`: *FILL IN* \
`GameTreeBuildingSettings buildingSettings`: *FILL IN* \
`float allin_threshold`: *FILL IN* \

**Code Description**: *FILL IN*
