# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/GameTree.cpp` \
**Type:** `Method` \
**Method Name:** `buildChance` \
**Code Content:** \
`void GameTree::buildChance(shared_ptr<ChanceNode> root,Rule rule){
    //节点上的下注额度
    double pot = (double)rule.get_pot();
    Rule nextrule = Rule(rule);
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));

    shared_ptr<GameTreeNode> one_node;
    if(rule.oop_commit == rule.ip_commit && rule.oop_commit == rule.stack) {
        if(rule.current_round >= 3){ // 3 is river
            double p1_commit = rule.ip_commit;
            double p2_commit = rule.oop_commit;
            double peace_getback = (p1_commit + p2_commit) / 2;


            vector<vector<double>> payoffs(2);
            payoffs[0] = {p2_commit, -p2_commit};
            payoffs[1] = {-p1_commit, p1_commit};
            vector<double> peace_getback_vec = {peace_getback - p1_commit, peace_getback - p2_commit};
            one_node = make_shared<ShowdownNode>(peace_getback_vec, payoffs, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
        }else {
            nextrule.current_round += 1;
            if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
            one_node = make_shared<ChanceNode>(nullptr, GameTreeNode::intToGameRound(rule.current_round + 1), (double) rule.get_pot(), root, this->deck.getCards());
        }
    }else {
        one_node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(), 1, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
    }
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
    this->__build(one_node,nextrule,"begin",0,0);
    root->setChildren(one_node);
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.setChildren 
 - Explanation:  _This method sets the children of a ChanceNode object to the provided shared pointer of a GameTreeNode. It updates the internal 'children' member variable with the new value passed as an argument._ 
### TexasSolver/TexasSolver/src/ShowdownNode.cpp.ShowdownNode 
 - Explanation:  _This code defines the constructor for the ShowdownNode class, which is derived from GameTreeNode. It initializes the node with tie payoffs, player payoffs, game round, pot size, and a parent node, setting up the state for a showdown situation in a poker game._ 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.ChanceNode 
 - Explanation:  _This code defines the constructor for the ChanceNode class, which is derived from GameTreeNode. It initializes the ChanceNode object with various parameters including children nodes, game round, pot size, parent node, cards, and a donk flag, setting up the structure for a chance node in a game tree._ 
### TexasSolver/TexasSolver/src/Rule.cpp.Rule 
 - Explanation:  _This code defines a constructor for the `Rule` class, initializing various game parameters such as deck, commitments, round, raise limits, blinds, and stack sizes. It also performs a check to ensure that the out-of-position (oop) and in-position (ip) commitments are equal, throwing an exception if they're not._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.intToGameRound 
 - Explanation:  _This method converts an integer representation of a game round to the corresponding GameRound enum value in the GameTreeNode class. It uses a switch statement to map integers 0-3 to PREFLOP, FLOP, TURN, and RIVER respectively, throwing an error for invalid inputs._ 
### TexasSolver/TexasSolver/GameTree.cpp.__build 
 - Explanation:  _This method builds a game tree by recursively processing different types of nodes (Action, Showdown, Terminal, and Chance). It calls specific build methods for Action and Chance nodes, while Showdown and Terminal nodes are left unprocessed._ 
### TexasSolver/TexasSolver/src/ActionNode.cpp.ActionNode 
 - Explanation:  _This code defines the constructor for the `ActionNode` class, which is derived from `GameTreeNode`. It initializes the node with actions, children nodes, player information, game round, pot size, and a parent node, setting up the structure for a game decision tree._ 
### TexasSolver/TexasSolver/src/Rule.cpp.get_pot 
 - Explanation:  _This method returns the total pot size in a poker game by summing the out-of-position (oop) and in-position (ip) player commitments. It's a simple accessor function that retrieves the combined value of two member variables._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`buildChance`: The function of `buildChance` is *FILL IN* 
**Parameters**:\
`shared_ptr<ChanceNode> root`: *FILL IN* \
`Rule rule`: *FILL IN* \

**Code Description**: *FILL IN*
