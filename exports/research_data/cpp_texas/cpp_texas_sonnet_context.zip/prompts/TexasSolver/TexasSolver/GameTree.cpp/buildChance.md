# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/GameTree.cpp` \
**Type:** `Method` \
**Method Name:** `buildChance` \
**Code Content:** \
`void GameTree::buildChance(shared_ptr<ChanceNode> root,Rule rule){
    //节点上的下注额度
    double pot = (double)rule.get_pot();
    Rule nextrule = Rule(rule);
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));

    shared_ptr<GameTreeNode> one_node;
    if(rule.oop_commit == rule.ip_commit && rule.oop_commit == rule.stack) {
        if(rule.current_round >= 3){ // 3 is river
            double p1_commit = rule.ip_commit;
            double p2_commit = rule.oop_commit;
            double peace_getback = (p1_commit + p2_commit) / 2;


            vector<vector<double>> payoffs(2);
            payoffs[0] = {p2_commit, -p2_commit};
            payoffs[1] = {-p1_commit, p1_commit};
            vector<double> peace_getback_vec = {peace_getback - p1_commit, peace_getback - p2_commit};
            one_node = make_shared<ShowdownNode>(peace_getback_vec, payoffs, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
        }else {
            nextrule.current_round += 1;
            if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
            one_node = make_shared<ChanceNode>(nullptr, GameTreeNode::intToGameRound(rule.current_round + 1), (double) rule.get_pot(), root, this->deck.getCards());
        }
    }else {
        one_node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(), 1, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
    }
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
    this->__build(one_node,nextrule,"begin",0,0);
    root->setChildren(one_node);
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/ActionNode.cpp.ActionNode 
 - Explanation:  _This code defines a constructor for the `ActionNode` class, which initializes its member variables from input parameters. The constructor takes several inputs and assigns them to corresponding member variables in the object being constructed._ 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.ChanceNode 
 - Explanation:  _This code defines a constructor for a `ChanceNode` class, which appears to be part of a game tree data structure in a poker-related project. The constructor initializes various member variables with provided parameters._ 
### TexasSolver/TexasSolver/GameTree.cpp.__build 
 - Explanation:  _This code defines a method `__build` in the `GameTree` class, which recursively builds a game tree based on different node types. The method calls other methods to handle specific node types such as action and chance nodes._ 
### TexasSolver/TexasSolver/src/ShowdownNode.cpp.ShowdownNode 
 - Explanation:  _This code defines a constructor for a class called `ShowdownNode`, which appears to be part of a game tree data structure. The constructor initializes various member variables, including tie payoffs and player payoffs, with values passed from outside the class._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.intToGameRound 
 - Explanation:  _This code defines a method `intToGameRound` that converts an integer game round number to its corresponding enum value in the `GameTreeNode` class. The method uses a switch statement to map the integer values to their respective game rounds._ 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.setChildren 
 - Explanation:  _This code sets the children of a ChanceNode object in a game tree structure. The setChildren method takes a shared pointer to a GameTreeNode as input and assigns it to the children attribute of the ChanceNode instance._ 
### TexasSolver/TexasSolver/src/Rule.cpp.get_pot 
 - Explanation:  _This code defines a method `get_pot` in a class named `Rule`. The method returns the sum of two member variables: `oop_commit` and `ip_commit`, both of which are floats._ 
### TexasSolver/TexasSolver/src/Rule.cpp.Rule 
 - Explanation:  _This code defines a constructor for a class named `Rule`. The constructor initializes various member variables of the class, including deck and betting settings, while enforcing a specific condition on the odds-on and odds-off commitment values._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`buildChance`: The function of `buildChance` is *FILL IN* 
**Parameters**:\
`shared_ptr<ChanceNode> root`: *FILL IN* \
`Rule rule`: *FILL IN* \

**Code Description**: *FILL IN*
