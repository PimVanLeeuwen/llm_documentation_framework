# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/Card.cpp` \
**Type:** `Method` \
**Method Name:** `strCard2int` \
**Code Content:** \
`int Card::strCard2int(string card) {
    char rank = card.at(0);
    char suit = card.at(1);
    if(card.length() != 2){
        throw runtime_error( tfm::format("card %s not found",card));
    }
    return (rankToInt(rank) - 2) * 4 + suitToInt(suit);
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/Card.cpp.suitToInt 
 - Explanation:  _This method converts a character representing a card suit to its corresponding integer value. It uses a switch statement to map 'c', 'd', 'h', and 's' to 0, 1, 2, and 3 respectively, with 0 as the default return value._ 
### TexasSolver/TexasSolver/Card.cpp.rankToInt 
 - Explanation:  _This method converts a character representation of a card rank to its corresponding integer value. It uses a switch statement to map each valid rank character to a number between 2 and 14, with face cards and Ace having higher values._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`strCard2int`: The function of `strCard2int` is *FILL IN* 
**Parameters**:\
`string card`: *FILL IN* \

**Code Description**: *FILL IN*
