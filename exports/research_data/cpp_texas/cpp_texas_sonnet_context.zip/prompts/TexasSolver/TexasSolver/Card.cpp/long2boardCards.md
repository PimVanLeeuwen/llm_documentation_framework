# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/Card.cpp` \
**Type:** `Method` \
**Method Name:** `long2boardCards` \
**Code Content:** \
`vector<Card> Card::long2boardCards(uint64_t board_long){
        vector<int> board = long2board(board_long);
        vector<Card> board_cards(board.size());
        for(std::size_t i = 0;i < board.size();i ++){
            int one_board = board[i];
            board_cards[i] = Card(intCard2Str(one_board));
        }
        if (board_cards.size() < 1 || board_cards.size() > 7){
            throw runtime_error(tfm::format("board length not correct, board length %s",board_cards.size()));
        }
        vector<Card> retval(board_cards.size());
        for(std::size_t i = 0;i < board_cards.size();i ++){
            retval[i] = board_cards[i];
        }
        return retval;
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/Card.cpp.long2board 
 - Explanation:  _This method converts a 64-bit integer representation of a poker board into a vector of card indices. It iterates through the bits of the input, adding the corresponding card index to the vector when a bit is set, and throws an error if the resulting board size is invalid._ 
### TexasSolver/TexasSolver/Card.cpp.intCard2Str 
 - Explanation:  _This method converts an integer representation of a card to its string representation. It calculates the rank and suit from the input integer, then combines the string representations of both using helper methods._ 
### TexasSolver/TexasSolver/Card.cpp.Card 
 - Explanation:  _This code defines a constructor for the Card class that takes a string representation of a card as input. It initializes the card's string representation, converts it to an integer using the strCard2int method, and sets the card's number in the deck to -1._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`long2boardCards`: The function of `long2boardCards` is *FILL IN* 
**Parameters**:\
`uint64_t board_long`: *FILL IN* \

**Code Description**: *FILL IN*
