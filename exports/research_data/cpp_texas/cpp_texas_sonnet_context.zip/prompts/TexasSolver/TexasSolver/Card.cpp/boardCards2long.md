# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/Card.cpp` \
**Type:** `Method` \
**Method Name:** `boardCards2long` \
**Code Content:** \
`uint64_t Card::boardCards2long(vector<string> cards) {
    vector<Card> cards_objs(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_objs[i] = Card(cards[i]);
    }
    return Card::boardCards2long(cards_objs);
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/Card.cpp.boardCards2long 
 - Explanation:  _This method converts a vector of Card objects into a 64-bit integer representation of a poker board. It first transforms each Card object into its integer equivalent using card2int(), then uses boardInts2long() to combine these integers into a single long value._ 
### TexasSolver/TexasSolver/Card.cpp.Card 
 - Explanation:  _This code defines a constructor for the Card class that takes a string representation of a card as input. It initializes the card's string representation, converts it to an integer using the strCard2int method, and sets the card's number in the deck to -1._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`boardCards2long`: The function of `boardCards2long` is *FILL IN* 
**Parameters**:\
`vector<string> cards`: *FILL IN* \

**Code Description**: *FILL IN*
