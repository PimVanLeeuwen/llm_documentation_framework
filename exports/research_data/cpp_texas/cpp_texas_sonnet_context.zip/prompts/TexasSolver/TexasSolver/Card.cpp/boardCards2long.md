# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/Card.cpp` \
**Type:** `Method` \
**Method Name:** `boardCards2long` \
**Code Content:** \
`uint64_t Card::boardCards2long(vector<string> cards) {
    vector<Card> cards_objs(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_objs[i] = Card(cards[i]);
    }
    return Card::boardCards2long(cards_objs);
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/Card.cpp.boardCards2long 
 - Explanation:  _This code converts a vector of Card objects to a single 64-bit unsigned integer representing a poker board.
It does this by first converting each card object to its corresponding integer value and then combining these values into a single long integer._ 
### TexasSolver/TexasSolver/Card.cpp.Card 
 - Explanation:  _This code defines a constructor for the `Card` class, which initializes a card object from a string representation. The constructor calls another method to convert the string into an integer value representing the card._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`boardCards2long`: The function of `boardCards2long` is *FILL IN* 
**Parameters**:\
`vector<string> cards`: *FILL IN* \

**Code Description**: *FILL IN*
