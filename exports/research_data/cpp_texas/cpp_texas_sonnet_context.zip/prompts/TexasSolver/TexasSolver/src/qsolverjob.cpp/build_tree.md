# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/qsolverjob.cpp` \
**Type:** `Method` \
**Method Name:** `build_tree` \
**Code Content:** \
`void QSolverJob::build_tree(){
    qDebug().noquote() << tr("building tree..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        ps_holdem.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }else if(this->mode == Mode::SHORTDECK){
        ps_shortdeck.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }
    qDebug().noquote() << tr("build tree finished");//.toStdString() << endl;
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/PokerSolver.cpp.build_game_tree 
 - Explanation:  _This method initializes and builds a game tree for a poker solver. It creates a shared pointer to a GameTree object with specified parameters and assigns it to the solver's game_tree member._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`build_tree`: The function of `build_tree` is *FILL IN* 

**Code Description**: *FILL IN*
