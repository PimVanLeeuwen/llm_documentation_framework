# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/roughstrategyviewermodel.cpp` \
**Type:** `Method` \
**Method Name:** `onchanged` \
**Code Content:** \
`void RoughStrategyViewerModel::onchanged(){
    emit headerDataChanged(Qt::Horizontal, 0 , columnCount());
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/roughstrategyviewermodel.cpp.columnCount 
 - Explanation:  _This code defines a method `columnCount` in the class `RoughStrategyViewerModel`. The method returns the number of columns in a table, which is determined by the size of the `total_strategy` vector in the associated `tableStrategyModel`._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`onchanged`: The function of `onchanged` is *FILL IN* 

**Code Description**: *FILL IN*
