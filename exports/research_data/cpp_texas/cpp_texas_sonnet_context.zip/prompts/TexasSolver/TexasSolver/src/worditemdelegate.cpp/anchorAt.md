# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/worditemdelegate.cpp` \
**Type:** `Method` \
**Method Name:** `anchorAt` \
**Code Content:** \
`QString WordItemDelegate::anchorAt(QString html, const QPoint &point) const {
    QTextDocument doc;
    doc.setHtml(html);

    auto textLayout = doc.documentLayout();
    Q_ASSERT(textLayout != 0);
    return textLayout->anchorAt(point);
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/worditemdelegate.cpp.anchorAt 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`anchorAt`: The function of `anchorAt` is *FILL IN* 
**Parameters**:\
`QString html`: *FILL IN* \
`const QPoint &point`: *FILL IN* \

**Code Description**: *FILL IN*
