# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/treemodel.cpp` \
**Type:** `Method` \
**Method Name:** `TreeModel` \
**Code Content:** \
`TreeModel::TreeModel(QSolverJob * data, QObject *parent)
    : QAbstractItemModel(parent)
{
    this->qSolverJob = data;
    setupModelData();
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/treemodel.cpp.parent 
### TexasSolver/TexasSolver/src/treemodel.cpp.data 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`TreeModel`: The function of `TreeModel` is *FILL IN* 
**Parameters**:\
`QSolverJob * data`: *FILL IN* \
`QObject *parent`: *FILL IN* \

**Code Description**: *FILL IN*
