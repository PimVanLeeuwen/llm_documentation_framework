# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/CommandLineTool.cpp` \
**Type:** `Method` \
**Method Name:** `startWorking` \
**Code Content:** \
`void CommandLineTool::startWorking() {
    string input_line;
    while(cin) {
        getline(cin, input_line);
        this->processCommand(input_line);
    };
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/CommandLineTool.cpp.processCommand 
 - Explanation:  _This code implements a command line tool for processing Texas Hold'em poker game settings and solver commands.
The `processCommand` method parses input strings, updates internal state variables, and calls various methods to perform tasks such as building game trees or training poker solvers._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`startWorking`: The function of `startWorking` is *FILL IN* 

**Code Description**: *FILL IN*
