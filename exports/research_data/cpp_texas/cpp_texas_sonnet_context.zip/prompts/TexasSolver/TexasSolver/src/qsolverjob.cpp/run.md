# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/qsolverjob.cpp` \
**Type:** `Method` \
**Method Name:** `run` \
**Code Content:** \
`void QSolverJob::run()
{
    //QDebugStream qout(qDebug().noquote(), this->textEdit);
    try{
        if(this->current_mission == MissionType::SOLVING){
            this->solving();
        }else if(this->current_mission == MissionType::LOADING){
            this->loading();
        }else if(this->current_mission == MissionType::BUILDTREE){
            this->build_tree();
        }else if(this->current_mission == MissionType::SAVING){
            this->saving();
        }else{
            throw runtime_error("unsupported mission type");
        }
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/qsolverjob.cpp.build_tree 
 - Explanation:  _This method builds a game tree for either Texas Hold'em or Short Deck poker, depending on the selected mode. It calls the appropriate build_game_tree function with specified parameters and logs the start and completion of the tree-building process._ 
### TexasSolver/TexasSolver/src/qsolverjob.cpp.solving 
 - Explanation:  _This method initiates a poker solving process for either Texas Hold'em or Short Deck poker, depending on the selected mode. It calls the appropriate solver's train method with specified parameters and logs the start and completion of the solving process._ 
### TexasSolver/TexasSolver/src/qsolverjob.cpp.saving 
 - Explanation:  _This method handles saving the strategy to a JSON file. It retrieves the dump round setting, warns about potential issues with river dumps, and calls the appropriate dump_strategy method based on the game mode (Hold'em or Short Deck)._ 
### TexasSolver/TexasSolver/src/qsolverjob.cpp.loading 
 - Explanation:  _This method initializes PokerSolver objects for both Texas Hold'em and Short Deck poker variants. It loads necessary resources, including card ranks, suits, and comparison files, and sets up the solvers for both game types._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`run`: The function of `run` is *FILL IN* 

**Code Description**: *FILL IN*
