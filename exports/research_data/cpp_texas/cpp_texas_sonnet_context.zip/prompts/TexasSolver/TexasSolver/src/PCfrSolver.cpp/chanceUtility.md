# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/PCfrSolver.cpp` \
**Type:** `Method` \
**Method Name:** `chanceUtility` \
**Code Content:** \
`vector<float>
PCfrSolver::chanceUtility(int player, shared_ptr<ChanceNode> node, const vector<float> &reach_probs, int iter,
                         uint64_t current_board,int deal) {
    vector<Card>& cards = this->deck.getCards();
    //float[] cardWeights = getCardsWeights(player,reach_probs[1 - player],current_board);

    int card_num = node->getCards().size();
    if(card_num % 4 != 0) throw runtime_error("card num cannot round 4");
    // 可能的发牌情况,2代表每个人的holecard是两张
    int possible_deals = node->getCards().size() - Card::long2board(current_board).size() - 2;
    int oppo = 1 - player;

    //vector<float> chance_utility(reach_probs[player].size());
    vector<float> chance_utility = vector<float>(this->ranges[player].size());
    fill(chance_utility.begin(),chance_utility.end(),0);

    int random_deal = 0;
    if(this->monteCarolAlg==MonteCarolAlg::PUBLIC) {
        if (this->round_deal[GameTreeNode::gameRound2int(node->getRound())] == -1) {
            random_deal = random(1, possible_deals + 1 + 2);
            this->round_deal[GameTreeNode::gameRound2int(node->getRound())] = random_deal;
        } else {
            random_deal = this->round_deal[GameTreeNode::gameRound2int(node->getRound())];
        }
    }
    //vector<vector<vector<float>>> arr_new_reach_probs = vector<vector<vector<float>>>(node->getCards().size());

    vector<vector<float>> results(node->getCards().size());
    //fill(results.begin(),results.end(),nullptr);

    vector<float> multiplier;
    if(iter <= this->warmup){
        multiplier = vector<float>(card_num);
        fill(multiplier.begin(), multiplier.end(), 0);
        for (int card_base = 0; card_base < card_num / 4; card_base++) {
            int cardr = std::rand() % 4;
            int card_target = card_base * 4 + cardr;
            int multiplier_num = 0;
            for (int i = 0; i < 4; i++) {
                int i_card = card_base * 4 + i;
                if (i == cardr) {
                    Card *one_card = const_cast<Card *>(&(node->getCards()[i_card]));
                    uint64_t card_long = Card::boardInt2long(
                            one_card->getCardInt());
                    if (!Card::boardsHasIntercept(card_long, current_board)) {
                        multiplier_num += 1;
                    }
                } else {
                    Card *one_card = const_cast<Card *>(&(node->getCards()[i_card]));
                    uint64_t card_long = Card::boardInt2long(
                            one_card->getCardInt());
                    if (!Card::boardsHasIntercept(card_long, current_board)) {
                        multiplier_num += 1;
                    }
                }
            }
            multiplier[card_target] = multiplier_num;
        }
    }

    vector<int> valid_cards;
    valid_cards.reserve(node->getCards().size());

    for(std::size_t card = 0;card < node->getCards().size();card ++) {
        shared_ptr<GameTreeNode> one_child = node->getChildren();
        Card *one_card = const_cast<Card *>(&(node->getCards()[card]));
        uint64_t card_long = Card::boardInt2long(one_card->getCardInt());//Card::boardCards2long(new Card[]{one_card});
        if (Card::boardsHasIntercept(card_long, current_board)) continue;
        if (iter <= this->warmup && multiplier[card] == 0) continue;
        if (this->color_iso_offset[deal][one_card->getCardInt() % 4] < 0) continue;
        valid_cards.push_back(card);
    }

    #pragma omp parallel for schedule(static)
    for`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.getChildren 
 - Explanation:  _This method returns the children of a ChanceNode object. It provides access to the private 'children' member, which is a shared pointer to a GameTreeNode._ 
### TexasSolver/TexasSolver/Card.cpp.boardInt2long 
 - Explanation:  _This method converts a board card's integer representation to a 64-bit long integer. It uses bitwise operations to set a single bit corresponding to the card's position, throwing an error if the input is out of range._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.gameRound2int 
 - Explanation:  _This method converts a GameRound enum value to its corresponding integer representation. It maps PREFLOP to 0, FLOP to 1, TURN to 2, RIVER to 3, and throws a runtime error for any unrecognized round._ 
### TexasSolver/TexasSolver/library.cpp.random 
 - Explanation:  _This function generates a random integer within the specified range [min, max), where min is inclusive and max is exclusive. It uses the rand() function to produce a random number and then scales and shifts it to fit within the desired range._ 
### TexasSolver/TexasSolver/Card.cpp.long2board 
 - Explanation:  _This method converts a 64-bit integer representation of a poker board into a vector of card indices. It iterates through the bits of the input, adding the corresponding card index to the vector when a bit is set, and throws an error if the resulting board size is invalid._ 
### TexasSolver/TexasSolver/Card.cpp.getCardInt 
 - Explanation:  _This method is a getter function for the `card_int` member variable of the `Card` class. It returns the integer representation of the card, which is likely used to encode the card's value and suit._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.getRound 
 - Explanation:  _This method is a getter function for the `round` member variable of the `GameTreeNode` class. It returns the current game round, which is likely an enumeration of type `GameTreeNode::GameRound`._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`chanceUtility`: The function of `chanceUtility` is *FILL IN* 
**Parameters**:\
`int player`: *FILL IN* \
`shared_ptr<ChanceNode> node`: *FILL IN* \
`const vector<float> &reach_probs`: *FILL IN* \
`int iter`: *FILL IN* \
`uint64_t current_board`: *FILL IN* \
`int deal`: *FILL IN* \

**Code Description**: *FILL IN*
