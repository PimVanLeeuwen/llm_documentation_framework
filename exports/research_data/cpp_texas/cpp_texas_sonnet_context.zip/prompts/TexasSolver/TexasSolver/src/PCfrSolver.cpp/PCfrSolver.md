# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/PCfrSolver.cpp` \
**Type:** `Method` \
**Method Name:** `PCfrSolver` \
**Code Content:** \
`PCfrSolver::PCfrSolver(shared_ptr<GameTree> tree, vector<PrivateCards> range1, vector<PrivateCards> range2,
                     vector<int> initial_board, shared_ptr<Compairer> compairer, Deck deck, int iteration_number, bool debug,
                     int print_interval, string logfile, string trainer, Solver::MonteCarolAlg monteCarolAlg,int warmup,float accuracy,bool use_isomorphism,int use_halffloats,int num_threads) :Solver(tree){
    this->initial_board = initial_board;
    this->initial_board_long = Card::boardInts2long(initial_board);
    this->logfile = logfile;
    this->trainer = trainer;
    this->warmup = warmup;

    range1 = this->noDuplicateRange(range1,initial_board_long);
    range2 = this->noDuplicateRange(range2,initial_board_long);

    this->range1 = range1;
    this->range2 = range2;
    this->player_number = 2;
    this->ranges = vector<vector<PrivateCards>>(this->player_number);
    this->ranges[0] = range1;
    this->ranges[1] = range2;

    this->compairer = compairer;

    this->deck = deck;
    this->use_isomorphism = use_isomorphism;
    this->use_halffloats = use_halffloats;

    this->rrm = RiverRangeManager(compairer);
    this->iteration_number = iteration_number;

    vector<vector<PrivateCards>> private_cards(this->player_number);
    private_cards[0] = range1;
    private_cards[1] = range2;
    pcm = PrivateCardsManager(private_cards,this->player_number,Card::boardInts2long(this->initial_board));
    this->debug = debug;
    this->print_interval = print_interval;
    this->monteCarolAlg = monteCarolAlg;
    this->accuracy = accuracy;
    if(num_threads == -1){
        num_threads = omp_get_num_procs();
    }
    qDebug().noquote() << QString::fromStdString(tfm::format(QObject::tr("Using %s threads").toStdString().c_str(),num_threads));
    this->num_threads = num_threads;
    this->distributing_task = false;
    omp_set_num_threads(this->num_threads);
    setTrainable(this->tree->getRoot());
    this->root_round = this->tree->getRoot()->getRound();
    if(this->root_round == GameTreeNode::GameRound::PREFLOP){
        this->split_round = GameTreeNode::GameRound::FLOP;
    }else if(this->root_round == GameTreeNode::GameRound::FLOP){
        this->split_round = GameTreeNode::GameRound::TURN;
    }else if(this->root_round == GameTreeNode::GameRound::TURN){
        this->split_round = GameTreeNode::GameRound::RIVER;
    }else{
        // do not use multithread in river, really not necessary
        this->split_round = GameTreeNode::GameRound::PREFLOP;
    }
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/GameTree.cpp.getRoot 
 - Explanation:  _This method returns the root node of the game tree. It provides access to the starting point of the tree structure, allowing traversal and manipulation of the entire game tree._ 
### TexasSolver/TexasSolver/src/PCfrSolver.cpp.noDuplicateRange 
 - Explanation:  _This method filters a given range of private cards to remove any duplicates and cards that overlap with the board. It returns a new vector of PrivateCards containing only unique hands that don't conflict with the board cards._ 
### TexasSolver/TexasSolver/src/PrivateCardsManager.cpp.PrivateCardsManager 
 - Explanation:  _This constructor initializes a PrivateCardsManager object with given private cards, player count, and initial board. It sets up data structures to manage private card combinations for each player and calculates relative probabilities for the cards._ 
### TexasSolver/TexasSolver/src/PrivateCards.cpp.PrivateCards 
 - Explanation:  _This constructor initializes a PrivateCards object with two card values and a weight, setting up various properties including a hash code and a board representation. It uses the Card::boardInts2long method to convert the card vector into a 64-bit integer representation of the board._ 
### TexasSolver/TexasSolver/src/RiverRangeManager.cpp.RiverRangeManager 
 - Explanation:  _This code defines the constructor for the `RiverRangeManager` class, which initializes a `handEvaluator` member variable with a shared pointer passed as an argument. It also creates a shared mutex `maplock`, likely used for thread-safe operations within the class._ 
### TexasSolver/TexasSolver/Card.cpp.boardInts2long 
 - Explanation:  _This method converts a vector of card integers into a 64-bit integer representation of the board. It checks for valid input, then uses bitwise operations to create a unique long value for the given board configuration._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.getRound 
 - Explanation:  _This method is a getter function for the `round` member variable of the `GameTreeNode` class. It returns the current game round, which is likely an enumeration of type `GameTreeNode::GameRound`._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`PCfrSolver`: The function of `PCfrSolver` is *FILL IN* 
**Parameters**:\
`shared_ptr<GameTree> tree`: *FILL IN* \
`vector<PrivateCards> range1`: *FILL IN* \
`vector<PrivateCards> range2`: *FILL IN* \
`vector<int> initial_board`: *FILL IN* \
`shared_ptr<Compairer> compairer`: *FILL IN* \
`Deck deck`: *FILL IN* \
`int iteration_number`: *FILL IN* \
`bool debug`: *FILL IN* \
`int print_interval`: *FILL IN* \
`string logfile`: *FILL IN* \
`string trainer`: *FILL IN* \
`Solver::MonteCarolAlg monteCarolAlg`: *FILL IN* \
`int warmup`: *FILL IN* \
`float accuracy`: *FILL IN* \
`bool use_isomorphism`: *FILL IN* \
`int use_halffloats`: *FILL IN* \
`int num_threads`: *FILL IN* \

**Code Description**: *FILL IN*
