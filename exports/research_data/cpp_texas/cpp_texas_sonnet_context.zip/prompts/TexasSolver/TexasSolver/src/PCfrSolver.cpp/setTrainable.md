# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/PCfrSolver.cpp` \
**Type:** `Method` \
**Method Name:** `setTrainable` \
**Code Content:** \
`void PCfrSolver::setTrainable(shared_ptr<GameTreeNode> root) {
    if(root->getType() == GameTreeNode::ACTION){
        shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(root);

        int player = action_node->getPlayer();

        if(this->trainer == "cfr_plus"){
            //vector<PrivateCards> player_privates = this->ranges[player];
            //action_node->setTrainable(make_shared<CfrPlusTrainable>(action_node,player_privates));
            throw runtime_error(tfm::format("trainer %s not supported",this->trainer));
        }else if(this->trainer == "discounted_cfr"){
            vector<PrivateCards>* player_privates = &this->ranges[player];
            //action_node->setTrainable(make_shared<DiscountedCfrTrainable>(action_node,player_privates));
            int num;
            GameTreeNode::GameRound gr = this->tree->getRoot()->getRound();
            int root_round = GameTreeNode::gameRound2int(gr);
            int current_round = GameTreeNode::gameRound2int(root->getRound());
            int gap = current_round - root_round;

            if(gap == 2) {
                num = this->deck.getCards().size() * this->deck.getCards().size() +
                          this->deck.getCards().size() + 1;
            }else if(gap == 1) {
                num = this->deck.getCards().size() + 1;
            }else if(gap == 0) {
                num =  1;
            }else{
                throw runtime_error("gap not understand");
            }
            action_node->setTrainable(vector<shared_ptr<Trainable>>(num),player_privates);
        }else{
            throw runtime_error(tfm::format("trainer %s not found",this->trainer));
        }

        vector<shared_ptr<GameTreeNode>> childrens =  action_node->getChildrens();
        for(shared_ptr<GameTreeNode> one_child:childrens) setTrainable(one_child);
    }else if(root->getType() == GameTreeNode::CHANCE) {
        shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(root);
        shared_ptr<GameTreeNode> children = chance_node->getChildren();
        setTrainable(children);
    }
    else if(root->getType() == GameTreeNode::TERMINAL){

    }else if(root->getType() == GameTreeNode::SHOWDOWN){

    }
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/GameTree.cpp.getRoot 
 - Explanation:  _This method returns the root node of the game tree. It provides access to the starting point of the tree structure, allowing traversal and manipulation of the entire game tree._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.gameRound2int 
 - Explanation:  _This method converts a GameRound enum value to its corresponding integer representation. It maps PREFLOP to 0, FLOP to 1, TURN to 2, RIVER to 3, and throws a runtime error for any unrecognized round._ 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.ChanceNode 
 - Explanation:  _This code defines the constructor for the ChanceNode class, which is derived from GameTreeNode. It initializes the ChanceNode object with various parameters including children nodes, game round, pot size, parent node, cards, and a donk flag, setting up the structure for a chance node in a game tree._ 
### TexasSolver/TexasSolver/src/PCfrSolver.cpp.setTrainable 
### TexasSolver/TexasSolver/src/ActionNode.cpp.ActionNode 
 - Explanation:  _This code defines the constructor for the `ActionNode` class, which is derived from `GameTreeNode`. It initializes the node with actions, children nodes, player information, game round, pot size, and a parent node, setting up the structure for a game decision tree._ 
### TexasSolver/TexasSolver/src/ActionNode.cpp.getChildrens 
 - Explanation:  _This method returns a reference to the vector of child nodes for an ActionNode object. It provides access to the childrens member variable, which likely contains the next possible game states or actions._ 
### TexasSolver/TexasSolver/src/ChanceNode.cpp.getChildren 
 - Explanation:  _This method returns the children of a ChanceNode object. It provides access to the private 'children' member, which is a shared pointer to a GameTreeNode._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.getRound 
 - Explanation:  _This method is a getter function for the `round` member variable of the `GameTreeNode` class. It returns the current game round, which is likely an enumeration of type `GameTreeNode::GameRound`._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`setTrainable`: The function of `setTrainable` is *FILL IN* 
**Parameters**:\
`shared_ptr<GameTreeNode> root`: *FILL IN* \

**Code Description**: *FILL IN*
