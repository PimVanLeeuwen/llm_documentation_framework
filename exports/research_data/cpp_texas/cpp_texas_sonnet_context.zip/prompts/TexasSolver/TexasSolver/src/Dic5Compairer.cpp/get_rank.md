# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/Dic5Compairer.cpp` \
**Type:** `Method` \
**Method Name:** `get_rank` \
**Code Content:** \
`int Dic5Compairer::get_rank(uint64_t private_hand, uint64_t public_board) {
    return this->get_rank(Card::long2board(private_hand),Card::long2board(public_board));
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/Card.cpp.long2board 
 - Explanation:  _This code converts a 64-bit unsigned integer representing a long into a vector of integers, where each integer represents a card in a deck. The conversion process involves iterating through the bits of the input number and adding corresponding card indices to the output vector._ 
### TexasSolver/TexasSolver/src/Dic5Compairer.cpp.get_rank 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`get_rank`: The function of `get_rank` is *FILL IN* 
**Parameters**:\
`uint64_t private_hand`: *FILL IN* \
`uint64_t public_board`: *FILL IN* \

**Code Description**: *FILL IN*
