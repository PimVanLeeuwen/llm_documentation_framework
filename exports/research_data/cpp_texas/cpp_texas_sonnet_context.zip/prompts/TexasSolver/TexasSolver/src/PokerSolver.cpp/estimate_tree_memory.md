# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/PokerSolver.cpp` \
**Type:** `Method` \
**Method Name:** `estimate_tree_memory` \
**Code Content:** \
`long long PokerSolver::estimate_tree_memory(QString range1,QString range2,QString board){
    if(this->game_tree == nullptr){
        qDebug().noquote() << QObject::tr("Please buld tree first.");
        return 0;
    }
    else{
        string player1RangeStr = range1.toStdString();
        string player2RangeStr = range2.toStdString();

        vector<string> board_str_arr = string_split(board.toStdString(),',');
        vector<int> initialBoard;
        for(string one_board_str:board_str_arr){
            initialBoard.push_back(Card::strCard2int(one_board_str));
        }

        vector<PrivateCards> range1 = PrivateRangeConverter::rangeStr2Cards(player1RangeStr,initialBoard);
        vector<PrivateCards> range2 = PrivateRangeConverter::rangeStr2Cards(player2RangeStr,initialBoard);
        return this->game_tree->estimate_tree_memory(this->deck.getCards().size() - initialBoard.size(),range1.size(),range2.size());
    }
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/PrivateRangeConverter.cpp.rangeStr2Cards 
 - Explanation:  _This method converts a string representation of a poker hand range into a vector of PrivateCards objects. It handles various range notations, including suited and offsuit combinations, and applies weights to each hand while ensuring no duplicate or invalid combinations are included._ 
### TexasSolver/TexasSolver/library.cpp.string_split 
 - Explanation:  _This function splits a given string into a vector of substrings using a specified delimiter character. It utilizes a stringstream to tokenize the input string and populate the vector with the resulting substrings._ 
### TexasSolver/TexasSolver/Card.cpp.strCard2int 
 - Explanation:  _This method converts a two-character string representation of a card to an integer value. It calculates the card's unique index based on its rank and suit, using helper methods to convert individual components._ 
### TexasSolver/TexasSolver/src/PokerSolver.cpp.estimate_tree_memory 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`estimate_tree_memory`: The function of `estimate_tree_memory` is *FILL IN* 
**Parameters**:\
`QString range1`: *FILL IN* \
`QString range2`: *FILL IN* \
`QString board`: *FILL IN* \

**Code Description**: *FILL IN*
