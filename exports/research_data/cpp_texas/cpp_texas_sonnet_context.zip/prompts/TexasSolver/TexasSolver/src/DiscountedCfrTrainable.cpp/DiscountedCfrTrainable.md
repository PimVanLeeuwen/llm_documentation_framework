# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/DiscountedCfrTrainable.cpp` \
**Type:** `Method` \
**Method Name:** `DiscountedCfrTrainable` \
**Code Content:** \
`DiscountedCfrTrainable::DiscountedCfrTrainable(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();

    this->evs = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus_sum = vector<float>(this->card_number,0.0);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number,0.0);
    //this->cum_r_plus_sum = vector<float>(this->card_number);
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/ActionNode.cpp.getChildrens 
 - Explanation:  _This method returns a reference to the vector of child nodes for an ActionNode object. It provides access to the childrens member variable, which likely contains the next possible game states or actions._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`DiscountedCfrTrainable`: The function of `DiscountedCfrTrainable` is *FILL IN* 
**Parameters**:\
`vector<PrivateCards> *privateCards`: *FILL IN* \
`ActionNode &actionNode`: *FILL IN* \

**Code Description**: *FILL IN*
