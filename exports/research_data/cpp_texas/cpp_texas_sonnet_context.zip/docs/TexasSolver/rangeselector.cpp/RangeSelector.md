`RangeSelector`: The function of `RangeSelector` is to initialize a dialog for selecting poker hand ranges.

**Parameters**:
`QTextEdit* rangeEdit`: A pointer to a QTextEdit widget containing the initial range text.
`QWidget *parent`: The parent widget for this dialog.
`QSolverJob::Mode mode`: Specifies the poker game mode (HOLDEM or SHORTDECK).

**Code Description**: This constructor initializes a RangeSelector dialog for poker hand range selection. It sets up the UI and data models based on the specified game mode. The function first determines the valid card ranks based on the game mode (A-2 for Hold'em, A-6 for Short Deck). It then creates a RangeSelectorTableModel and RangeSelectorTableDelegate to manage the range selection grid. The UI is set up with the table view, connecting signals for user interactions. A file system model is initialized for loading range files. The dialog also includes a slider for adjusting the range, and a text edit for displaying the current range. Signal-slot connections are established to handle user interactions with the range selection grid.\\
## Code: 
```
RangeSelector::RangeSelector(QTextEdit* rangeEdit,QWidget *parent,QSolverJob::Mode mode) :
    QDialog(parent),
    ui(new Ui::RangeSelector)
{

    QString ranks;
    if(mode == QSolverJob::Mode::HOLDEM){
        ranks = "A,K,Q,J,T,9,8,7,6,5,4,3,2";
    }else if(mode == QSolverJob::Mode::SHORTDECK){
        ranks = "A,K,Q,J,T,9,8,7,6";
    }else{
        throw runtime_error("mode not found in range selector");
    }
    this->rank_list = ranks.split(",");
    this->rangeSelectorTableModel = new RangeSelectorTableModel(this->rank_list,rangeEdit->toPlainText(),this);
    this->rangeSelectorTableDelegate = new RangeSelectorTableDelegate(this->rank_list,this->rangeSelectorTableModel,this);
    ui->setupUi(this);
    this->ui->rangeTableView->setModel(this->rangeSelectorTableModel);
    this->ui->rangeTableView->setItemDelegate(this->rangeSelectorTableDelegate);
    this->rangeEdit = rangeEdit;
    this->ui->textEdit->setText(this->rangeEdit->toPlainText());
    this->ui->rangeNumberSlider->setMaximum(this->max_val);
    this->ui->rangeNumberSlider->setValue(this->max_val);
    this->setWindowTitle(tr("RangeSelector"));
    connect(this->ui->rangeTableView,SIGNAL(view_item_pressed(int,int)),this,SLOT(grid_pressed(int,int)));
    connect(this->ui->rangeTableView,SIGNAL(view_item_area(int,int,int,int)),this,SLOT(grid_area(int,int,int,int)));
    connect(this->ui->rangeTableView,SIGNAL(item_release(int,int)),this,SLOT(grid_release(int,int)));

    QStringList filters;
    filters << "*.txt";
    qFileSystemModel = new QFileSystemModel(this);
    QDir filedir = QDir::current().filePath("ranges");
    qFileSystemModel->setRootPath(filedir.path());
#ifdef Q_OS_MAC
```