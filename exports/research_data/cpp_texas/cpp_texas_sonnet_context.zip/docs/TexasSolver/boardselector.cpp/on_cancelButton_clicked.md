`on_cancelButton_clicked`: The function of `on_cancelButton_clicked` is to close the current window or dialog.

**Code Description**: This method is a slot function that is triggered when a cancel button is clicked in the user interface. It contains a single line of code that calls the `close()` method on the current object (`this`). The `close()` method is typically used to close the current window or dialog in a graphical user interface application. This function provides a simple way for users to exit or dismiss the current view without making any changes or selections.\\
## Code: 
```
void boardselector::on_cancelButton_clicked()
{
    this->close();
}
```