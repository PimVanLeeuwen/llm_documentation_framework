`on_clearBoardButton_clicked`: The function of `on_clearBoardButton_clicked` is to clear the board and reset related UI elements.

**Code Description**: This method is triggered when the clear board button is clicked. It performs the following actions:

1. Calls `clear_board()` on the `boardSelectorTableModel` to reset the board data.
2. Clears the content of the `boardEdit` UI element.
3. Updates the `boardSelectorTable` UI element to reflect the changes.
4. Sets focus to the `boardSelectorTable`.
5. Finally, sets focus to the `boardEdit` UI element.

These actions effectively reset the board state and prepare the UI for new input from the user.\\
## Code: 
```
void boardselector::on_clearBoardButton_clicked()
{
    this->boardSelectorTableModel->clear_board();
    this->ui->boardEdit->clear();
    this->ui->boardSelectorTable->update();
    this->ui->boardSelectorTable->setFocus();
    this->ui->boardEdit->setFocus();
}
```