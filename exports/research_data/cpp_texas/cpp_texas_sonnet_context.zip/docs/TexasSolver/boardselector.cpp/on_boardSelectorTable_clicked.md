`on_boardSelectorTable_clicked`: The function of `on_boardSelectorTable_clicked` is to toggle the selection state of a table cell in the board selector table.

**Parameters**: 
`const QModelIndex &index`: This parameter represents the index of the clicked table cell, containing information about its row and column position.

**Code Description**: When the user clicks on a table cell in the board selector table, this function is called. It retrieves the row and column indices of the clicked cell from the `QModelIndex` object passed as an argument. The function then updates the corresponding cell in the 2D grid data structure managed by the `BoardSelectorTableModel` class to toggle its selection state. If the text displayed in the board edit field does not match the current board text, it is updated with the new board text. Finally, the focus is set on the board edit field and the table view.\\
## Code: 
```
void boardselector::on_boardSelectorTable_clicked(const QModelIndex &index)
{
    int row = index.row();
    int col = index.column();
    this->boardSelectorTableModel->setBoardAt(row,col,1 - this->boardSelectorTableModel->getBoardAt(row,col));
    if(this->ui->boardEdit->text() != this->boardSelectorTableModel->getBoardText()){
        this->ui->boardEdit->setText(this->boardSelectorTableModel->getBoardText());
    }
    this->ui->boardEdit->setFocus();
    this->ui->boardSelectorTable->setFocus();
}
```