## Expected output
`api`: The function of `api` is to execute the Texas Hold'em solver based on the provided input and settings.
**Parameters**:\
`const char * input_file`: This parameter specifies the file from which to read input for the solver. If empty, it will use command-line inputs instead.
`const char * resource_dir = "./resources"`: This parameter sets the directory where resources such as card images or game data are stored.
`const char * mode = "holdem"`: This parameter determines the poker variant being played; currently supports either 'holdem' for Texas Hold'em or 'shortdeck'.

**Code Description**: The `api` function first checks if the provided mode is valid. If not, it throws an error. It then proceeds to either execute the solver from a file (if input_file is not empty) or start working in command-line mode. In both cases, it uses a CommandLineTool object to manage the game settings and execution flow.\\
## Code: 
```
EXPORT
int api(const char * input_file, const char * resource_dir = "./resources", const char * mode = "holdem") {
    string input_file_ = input_file;
    string resource_dir_ = resource_dir;
    string mode_ = mode;

    if(mode_ != "holdem" && mode_ != "shortdeck")
        throw runtime_error(tfm::format("mode %s error, not in ['holdem','shortdeck']", mode_));

    if(input_file_.empty()) {
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.startWorking();
    }else{
        cout << "EXEC FROM FILE" << endl;
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.execFromFile(input_file_);
    }
}
```