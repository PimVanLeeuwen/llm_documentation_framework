`api`: The function of `api` is to initialize and execute a poker solver based on input parameters.

**Parameters**:
`const char * input_file`: Path to an input file containing poker game settings or commands.
`const char * resource_dir = "./resources"`: Directory path for resource files, defaulting to "./resources".
`const char * mode = "holdem"`: Game mode, either "holdem" or "shortdeck", defaulting to "holdem".

**Code Description**: This function serves as an entry point for the poker solver application. It first converts the input parameters to C++ strings for easier manipulation. The function then validates the game mode, ensuring it's either "holdem" or "shortdeck". If an invalid mode is provided, it throws a runtime error.

The function's behavior depends on whether an input file is provided:

1. If no input file is specified (input_file_ is empty):
   - It creates a CommandLineTool object with the specified mode and resource directory.
   - Calls the startWorking() method, likely initiating an interactive command-line interface.

2. If an input file is provided:
   - It prints "EXEC FROM FILE" to the console.
   - Creates a CommandLineTool object with the specified mode and resource directory.
   - Calls the execFromFile() method with the input file path, likely executing commands or settings from the file.

The function utilizes the CommandLineTool class to handle the poker solver's operations, whether in interactive mode or file-based execution mode. This design allows for flexibility in how the poker solver is used, supporting both interactive and batch processing scenarios.\\
## Code: 
```
EXPORT
int api(const char * input_file, const char * resource_dir = "./resources", const char * mode = "holdem") {
    string input_file_ = input_file;
    string resource_dir_ = resource_dir;
    string mode_ = mode;

    if(mode_ != "holdem" && mode_ != "shortdeck")
        throw runtime_error(tfm::format("mode %s error, not in ['holdem','shortdeck']", mode_));

    if(input_file_.empty()) {
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.startWorking();
    }else{
        cout << "EXEC FROM FILE" << endl;
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.execFromFile(input_file_);
    }
}
```