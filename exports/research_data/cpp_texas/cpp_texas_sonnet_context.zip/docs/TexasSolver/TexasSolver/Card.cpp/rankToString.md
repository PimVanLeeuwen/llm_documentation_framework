`rankToString`: The function of `rankToString` is to convert a numeric card rank to its string representation.

**Parameters**:
`int rank`: An integer representing the rank of a playing card.

**Code Description**: This method takes an integer rank as input and returns the corresponding string representation of that rank for a standard playing card. It uses a switch statement to match the input rank with its string equivalent. For ranks 2 through 9, it returns the number as a string. For 10, it returns "T". Jack, Queen, King, and Ace are represented by "J", "Q", "K", and "A" respectively. If an invalid rank is provided (outside the range of 2-14), it defaults to returning "2". This function is likely used in displaying or formatting card information in a more readable format for users or other parts of the program.\\
## Code: 
```
string Card::rankToString(int rank)
{
    switch(rank)
    {
        case 2: return "2";
        case 3: return "3";
        case 4: return "4";
        case 5: return "5";
        case 6: return "6";
        case 7: return "7";
        case 8: return "8";
        case 9: return "9";
        case 10: return "T";
        case 11: return "J";
        case 12: return "Q";
        case 13: return "K";
        case 14: return "A";
        default: return "2";
    }
}
```