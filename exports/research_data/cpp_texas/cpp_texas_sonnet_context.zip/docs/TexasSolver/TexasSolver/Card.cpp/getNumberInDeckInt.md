`getNumberInDeckInt`: The function of `getNumberInDeckInt` is to return the card's number in the deck as an integer.

**Code Description**: This method is a member function of the `Card` class. It retrieves the value of the `card_number_in_deck` member variable and returns it as an integer. Before returning, it performs a validation check. If the `card_number_in_deck` is -1, which is likely considered an invalid value, the method throws a `runtime_error` exception with the message "card number in deck cannot be -1". This error handling ensures that only valid card numbers are returned, preventing potential issues in the program's logic that relies on this value.\\
## Code: 
```
int Card::getNumberInDeckInt(){
    if(this->card_number_in_deck == -1)throw runtime_error("card number in deck cannot be -1");
    return this->card_number_in_deck;
}
```