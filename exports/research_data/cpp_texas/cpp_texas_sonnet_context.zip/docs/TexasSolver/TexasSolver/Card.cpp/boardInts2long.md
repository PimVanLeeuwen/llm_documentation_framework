`boardInts2long`: The function of `boardInts2long` is to convert a vector of card integers into a 64-bit long integer representation.

**Parameters**:
`const vector<int>& board`: A vector of integers representing card IDs (0-51).

**Code Description**: This method takes a vector of card integers and converts it into a single 64-bit unsigned integer. It first checks if the input vector's size is between 1 and 7, throwing a runtime error if not. Then, it iterates through each card in the input vector, ensuring each card ID is within the valid range (0-51). For each valid card, it sets the corresponding bit in the 64-bit integer (using left shift and bitwise OR operations). This creates a unique bit representation of the board, where each set bit corresponds to a card present in the input vector. The method returns this 64-bit integer representation of the board.\\
## Code: 
```
uint64_t Card::boardInts2long(const vector<int>& board){
    if(board.size() < 1 || board.size() > 7){
        throw runtime_error(tfm::format("Card length incorrect: %s",board.size()));
    }
    uint64_t board_long = 0;
    for(int one_card: board){
        // 这里hard code了一副扑克牌是52张
        if(one_card < 0 || one_card >= 52){
            throw runtime_error(tfm::format("Card with id %s not found",one_card));
        }
        // uint64_7 的range 在0 ~ + 2^ 64之间,所以不用太担心溢出问题
        board_long += ((uint64_t)(1) << one_card);
    }
    return board_long;
}
```