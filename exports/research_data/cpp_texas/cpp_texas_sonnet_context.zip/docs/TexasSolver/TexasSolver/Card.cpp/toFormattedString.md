`toFormattedString`: The function of `toFormattedString` is to convert a card's string representation to a formatted version with Unicode suit symbols.

**Code Description**: This method takes the card's string representation stored in the `card` member variable and replaces the single-character suit indicators with their corresponding Unicode symbols. It first converts the string to a QString object, then uses the `replace` method to substitute 'c' with ♣️ (club), 'd' with ♦️ (diamond), 'h' with ♥️ (heart), and 's' with ♠️ (spade). Finally, it converts the modified QString back to a standard string and returns it. This formatting enhances readability by using visual symbols instead of letters to represent card suits.\\
## Code: 
```
string Card::toFormattedString() {
    QString qString = QString::fromStdString(this->card);
    qString = qString.replace("c", "♣️");
    qString = qString.replace("d", "♦️");
    qString = qString.replace("h", "♥️");
    qString = qString.replace("s", "♠️");
    return qString.toStdString();
}
```