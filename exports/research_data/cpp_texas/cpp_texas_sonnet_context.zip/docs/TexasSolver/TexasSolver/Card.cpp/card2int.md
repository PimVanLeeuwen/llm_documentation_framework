`card2int`: The function of `card2int` is to convert a Card object to its integer representation.

**Parameters**:
`Card card`: A Card object representing a playing card.

**Code Description**: This method takes a Card object as input and converts it to an integer representation. It does this by first calling the `getCard()` method on the input Card object to retrieve its string representation. Then, it passes this string to the `strCard2int()` function, which converts the string representation of the card to an integer value. The resulting integer is then returned. This method serves as a wrapper around the `strCard2int()` function, allowing for easy conversion of Card objects to their integer equivalents, which can be useful for various card game algorithms and comparisons.\\
## Code: 
```
int Card::card2int(Card card) {
    return strCard2int(card.getCard());
}
```