`getCardInt`: The function of `getCardInt` is to return the integer representation of a card.

**Code Description**: This method is a simple getter function that returns the value of the private member variable `card_int`. It doesn't perform any calculations or modifications; it simply provides read access to the card's integer representation stored within the `Card` object. This integer likely encodes information about the card's rank and suit in a compact form.\\
## Code: 
```
int Card::getCardInt() {
    return this->card_int;
}
```