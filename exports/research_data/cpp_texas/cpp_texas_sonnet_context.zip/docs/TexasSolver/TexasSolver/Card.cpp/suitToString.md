`suitToString`: The function of `suitToString` is to convert a numeric suit value to its corresponding string representation.

**Parameters**:
`int suit`: An integer representing the suit of a playing card (0-3).

**Code Description**: This method takes an integer parameter `suit` and uses a switch statement to return the corresponding single-character string representation of the card suit. The mapping is as follows:
- 0 returns "c" (clubs)
- 1 returns "d" (diamonds)
- 2 returns "h" (hearts)
- 3 returns "s" (spades)
If the input is not 0-3, it defaults to returning "c". This method is likely used for displaying or processing card suits in a more human-readable or standardized format.\\
## Code: 
```
string Card::suitToString(int suit)
{
    switch(suit)
    {
        case 0: return "c";
        case 1: return "d";
        case 2: return "h";
        case 3: return "s";
        default: return "c";
    }
}
```