`long2board`: The function of `long2board` is to convert a 64-bit integer representation of a poker board into a vector of card indices.

**Parameters**:
`uint64_t board_long`: A 64-bit integer where each bit represents the presence or absence of a card on the board.

**Code Description**: The function iterates through the 52 least significant bits of the input `board_long`. For each bit that is set to 1, it adds the corresponding index (0-51) to a vector called `board`. The function uses bitwise operations to check each bit and right-shifts the `board_long` after each iteration. After processing all bits, it checks if the resulting board size is between 1 and 7 cards (inclusive). If not, it throws a runtime error with a formatted error message. Finally, it returns the vector of card indices representing the board.\\
## Code: 
```
vector<int> Card::long2board(uint64_t board_long) {
    vector<int> board;
    board.reserve(7);
    for(int i = 0;i < 52;i ++){
        // 看二进制最后一位是否为1
        if((board_long & 1) == 1){
            board.push_back(i);
        }
        board_long = board_long >> 1;
    }
    if (board.size() < 1 || board.size() > 7){
        throw runtime_error(tfm::format("board length not correct, board length %s",board.size()));
    }
    return board;
}
```