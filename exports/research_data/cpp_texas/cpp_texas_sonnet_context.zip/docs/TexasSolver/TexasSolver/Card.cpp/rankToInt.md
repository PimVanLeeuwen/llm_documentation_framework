`rankToInt`: The function of `rankToInt` is to convert a card rank character to its corresponding integer value.

**Parameters**:
`char rank`: A character representing the rank of a playing card.

**Code Description**: This method uses a switch statement to map card rank characters to their numerical values. It handles ranks from '2' to '10' (represented by 'T'), as well as face cards (J, Q, K) and Ace (A). For numeric cards (2-9), it returns their face value. For 'T', it returns 10. Jack, Queen, King, and Ace are assigned values 11, 12, 13, and 14 respectively. If an unrecognized character is provided, it defaults to returning 2. This conversion is useful for comparing card ranks or performing calculations based on card values in card game implementations.\\
## Code: 
```
int Card::rankToInt(char rank)
{
    switch(rank)
    {
        case '2': return 2;
        case '3': return 3;
        case '4': return 4;
        case '5': return 5;
        case '6': return 6;
        case '7': return 7;
        case '8': return 8;
        case '9': return 9;
        case 'T': return 10;
        case 'J': return 11;
        case 'Q': return 12;
        case 'K': return 13;
        case 'A': return 14;
        default: return 2;
    }
}
```