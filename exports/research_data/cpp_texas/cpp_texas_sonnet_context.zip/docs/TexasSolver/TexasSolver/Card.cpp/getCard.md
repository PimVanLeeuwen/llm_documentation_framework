`getCard`: The function of `getCard` is to return the card value stored in the object.

**Code Description**: This is a simple getter method for the `Card` class. It returns the `string` value stored in the private member variable `card`. The method doesn't take any parameters and doesn't modify the object's state. It provides read-only access to the card's value, allowing other parts of the program to retrieve the card information without directly accessing the private member variable.\\
## Code: 
```
string Card::getCard() {
    return this->card;
}
```