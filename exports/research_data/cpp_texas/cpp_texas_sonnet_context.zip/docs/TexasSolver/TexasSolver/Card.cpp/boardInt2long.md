`boardInt2long`: The function of `boardInt2long` is to convert an integer representation of a card to a 64-bit long integer with a single bit set.

**Parameters**:
`int board`: An integer representing a card's position in a standard 52-card deck (0-51).

**Code Description**: This method takes an integer input representing a card's position in a standard 52-card deck and converts it to a 64-bit unsigned integer (uint64_t) with only one bit set. It first checks if the input is within the valid range of 0 to 51. If not, it throws a runtime error with a formatted error message. If valid, it uses bitwise left shift to set only the bit corresponding to the input value in the 64-bit integer. This representation allows for efficient bitwise operations on card combinations in poker algorithms.\\
## Code: 
```
uint64_t Card::boardInt2long(int board){
    // 这里hard code了一副扑克牌是52张
    if(board < 0 || board >= 52){
        throw runtime_error(tfm::format("Card with id %s not found",board));
    }
    // uint64_7 的range 在0 ~ + 2^ 64之间,所以不用太担心溢出问题
    return ((uint64_t)(1) << board);
}
```