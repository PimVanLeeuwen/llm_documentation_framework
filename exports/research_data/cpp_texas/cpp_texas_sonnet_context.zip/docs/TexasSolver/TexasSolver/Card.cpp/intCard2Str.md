`intCard2Str`: The function of `intCard2Str` is to convert an integer representation of a card to its string representation.

**Parameters**:
`int card`: An integer representing a playing card.

**Code Description**: This method takes an integer representation of a card and converts it to a string representation. It first calculates the rank by integer division of the card value by 4 and adding 2. The suit is determined by subtracting the product of (rank-2) and 4 from the card value. The method then calls `rankToString` to convert the numeric rank to its string equivalent and `suitToString` to convert the numeric suit to its string representation. Finally, it concatenates these two strings and returns the result, providing a complete string representation of the card (e.g., "Ah" for Ace of hearts).\\
## Code: 
```
string Card::intCard2Str(int card){
    int rank = card / 4 + 2;
    int suit = card - (rank-2)*4;
    return Card::rankToString(rank) + Card::suitToString(suit);
}
```