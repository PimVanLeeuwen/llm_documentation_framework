`strCard2int`: Converts a string representation of a card to its corresponding integer value.

**Parameters**:
`string card`: A string representing a card, with the first character being the rank and the second character being the suit.

**Code Description**: The function takes a string `card` as input, checks if it has a length of 2, and if not, throws an exception. It then extracts the rank and suit from the string using the `at()` method, converts them to their corresponding integer values using the `rankToInt()` and `suitToInt()` functions respectively, and returns a value calculated based on these integers.\\
## Code: 
```
int Card::strCard2int(string card) {
    char rank = card.at(0);
    char suit = card.at(1);
    if(card.length() != 2){
        throw runtime_error( tfm::format("card %s not found",card));
    }
    return (rankToInt(rank) - 2) * 4 + suitToInt(suit);
}
```