`strCard2int`: The function of `strCard2int` is to convert a string representation of a card to an integer value.

**Parameters**:
`string card`: A two-character string representing a playing card, where the first character is the rank and the second character is the suit.

**Code Description**: This method takes a string representation of a card and converts it to a unique integer value. It first checks if the input string has exactly two characters. If not, it throws a runtime error with a formatted error message. The method then extracts the rank and suit characters from the input string. It uses helper methods `rankToInt` and `suitToInt` to convert the rank and suit to their respective integer values. The final integer representation is calculated using the formula: (rank_value - 2) * 4 + suit_value. This formula ensures each card has a unique integer representation between 0 and 51, where ranks are prioritized over suits.\\
## Code: 
```
int Card::strCard2int(string card) {
    char rank = card.at(0);
    char suit = card.at(1);
    if(card.length() != 2){
        throw runtime_error( tfm::format("card %s not found",card));
    }
    return (rankToInt(rank) - 2) * 4 + suitToInt(suit);
}
```