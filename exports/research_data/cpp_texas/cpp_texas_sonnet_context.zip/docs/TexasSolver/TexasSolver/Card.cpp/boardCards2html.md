`boardCards2html`: The function of `boardCards2html` is to convert a vector of Card objects into an HTML string representation.

**Parameters**:
`vector<Card>& cards`: A reference to a vector containing Card objects representing the board cards.

**Code Description**: This method iterates through each Card object in the input vector. For each non-empty card, it calls the `toFormattedHtml()` method to get its HTML representation and appends it to a QString. Empty cards are skipped. The resulting HTML string combines the formatted representations of all non-empty cards in the vector. This function is useful for displaying board cards in a web-based interface or HTML output, where each card is represented by its formatted HTML equivalent.\\
## Code: 
```
QString Card::boardCards2html(vector<Card>& cards){
    QString ret_html = "";
    for(auto one_card:cards){
        if(one_card.empty())continue;
        ret_html += one_card.toFormattedHtml();
    }
    return ret_html;
}
```