`boardCards2long`: The function of `boardCards2long` is to convert a vector of string representations of cards into a 64-bit integer representation of a poker board.

**Parameters**:
`vector<string> cards`: A vector of strings, where each string represents a playing card.

**Code Description**: This method takes a vector of string representations of cards and converts it into a 64-bit integer representation of a poker board. It first creates a vector of Card objects from the input strings. For each string in the input vector, it creates a new Card object using the Card constructor. Once all Card objects are created, it calls another overload of the boardCards2long method, passing the vector of Card objects. This other method is responsible for converting the Card objects into the final 64-bit integer representation. The function essentially serves as a bridge between string representations of cards and their internal 64-bit integer representation used for efficient poker calculations.\\
## Code: 
```
uint64_t Card::boardCards2long(vector<string> cards) {
    vector<Card> cards_objs(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_objs[i] = Card(cards[i]);
    }
    return Card::boardCards2long(cards_objs);
}
```