`boardCards2long`: The function of `boardCards2long` is to convert a vector of string representations of poker cards into a single 64-bit unsigned integer.

**Parameters**:\
`vector<string> cards`: A vector of string representations of poker cards, where each string represents a card in the format "rank-suit" (e.g., "Ace-Hearts").

**Code Description**: The function first creates a vector of `Card` objects from the input vector of strings. It then calls another method `boardCards2long` on this vector of `Card` objects to convert them into a single 64-bit unsigned integer. This is done by iterating over each card object, converting it to its corresponding integer value, and combining these values into a single long integer.\\
## Code: 
```
uint64_t Card::boardCards2long(vector<string> cards) {
    vector<Card> cards_objs(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_objs[i] = Card(cards[i]);
    }
    return Card::boardCards2long(cards_objs);
}
```