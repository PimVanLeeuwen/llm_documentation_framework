`suitToInt`: The function of `suitToInt` is to convert a card suit character to its corresponding integer value.

**Parameters**:
`char suit`: A character representing the suit of a playing card ('c', 'd', 'h', or 's').

**Code Description**: This method takes a single character representing a card suit and returns an integer value associated with that suit. It uses a switch statement to map each suit character to a specific number:
- 'c' (clubs) returns 0
- 'd' (diamonds) returns 1
- 'h' (hearts) returns 2
- 's' (spades) returns 3
If an unrecognized character is provided, the method defaults to returning 0. This conversion is likely used for internal representation or ordering of card suits within the program.\\
## Code: 
```
int Card::suitToInt(char suit)
{
    switch(suit)
    {
        case 'c': return 0; // 梅花
        case 'd': return 1; // 方块
        case 'h': return 2; // 红桃
        case 's': return 3; // 黑桃
        default: return 0;
    }
}
```