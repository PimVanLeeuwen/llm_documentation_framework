`toFormattedHtml`: The function of `toFormattedHtml` is to convert a card's string representation into an HTML-formatted string with colored suit symbols.

**Code Description**: This method takes the card's string representation stored in `this->card` and converts it to a QString. It then checks for the presence of suit characters ('c' for clubs, 'd' for diamonds, 'h' for hearts, 's' for spades) and replaces them with their corresponding HTML-encoded Unicode symbols wrapped in colored span tags. Clubs and spades are displayed in black, while diamonds and hearts are displayed in red. The method uses QString's replace function to perform these substitutions. Finally, it returns the formatted HTML string representing the card with its appropriate colored suit symbol.\\
## Code: 
```
QString Card::toFormattedHtml() {
    QString qString = QString::fromStdString(this->card);
    if(qString.contains("c"))
        qString = qString.replace("c", QString::fromLocal8Bit("<span style=\"color:black;\">&#9827;<\/span>"));
    else if(qString.contains("d"))
        qString = qString.replace("d", QString::fromLocal8Bit("<span style=\"color:red;\">&#9830;<\/span>"));
    else if(qString.contains("h"))
        qString = qString.replace("h", QString::fromLocal8Bit("<span style=\"color:red;\">&#9829;<\/span>"));
    else if(qString.contains("s"))
        qString = qString.replace("s", QString::fromLocal8Bit("<span style=\"color:black;\">&#9824;<\/span>"));
    return qString;
}
```