`Card`: The function of `Card` is to initialize a Card object with a given string representation.

**Parameters**:
`string card`: A string representing a playing card (e.g., "As" for Ace of spades).

**Code Description**: This is a constructor for the Card class. It takes a string parameter representing a card and initializes the object's properties. The constructor sets the `card` member variable to the input string, converts the string representation to an integer value using the `strCard2int` method, and stores it in the `card_int` member variable. The `card_number_in_deck` is initially set to -1, likely to be updated later when the card is assigned a position in a deck.\\
## Code: 
```
Card::Card(string card){
    this->card = card;
    this->card_int = Card::strCard2int(this->card);
    this->card_number_in_deck = -1;
}
```