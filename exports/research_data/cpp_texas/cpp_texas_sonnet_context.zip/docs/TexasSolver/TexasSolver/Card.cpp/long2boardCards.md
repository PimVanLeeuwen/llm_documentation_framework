`long2boardCards`: The function of `long2boardCards` is to convert a 64-bit unsigned integer representing a long into a vector of Card objects, where each Card object represents a card in the board.

**Parameters**:\
`uint64_t board_long`: A 64-bit unsigned integer representing a long.

**Code Description**: 
The function first converts the input long into a vector of integers using the `long2board` method. It then creates a new vector to store the Card objects and iterates through each integer in the board vector, converting it into a Card object using the `intCard2Str` method. The resulting Card objects are stored in the new vector. Finally, the function checks if the size of the board_cards vector is within the correct range (1-7) and throws an exception if not. If valid, the function returns the vector of Card objects.\\
## Code: 
```
vector<Card> Card::long2boardCards(uint64_t board_long){
        vector<int> board = long2board(board_long);
        vector<Card> board_cards(board.size());
        for(std::size_t i = 0;i < board.size();i ++){
            int one_board = board[i];
            board_cards[i] = Card(intCard2Str(one_board));
        }
        if (board_cards.size() < 1 || board_cards.size() > 7){
            throw runtime_error(tfm::format("board length not correct, board length %s",board_cards.size()));
        }
        vector<Card> retval(board_cards.size());
        for(std::size_t i = 0;i < board_cards.size();i ++){
            retval[i] = board_cards[i];
        }
        return retval;
}
```