`long2boardCards`: The function of `long2boardCards` is to convert a 64-bit integer representation of a poker board into a vector of Card objects.

**Parameters**:
`uint64_t board_long`: A 64-bit integer representing the poker board.

**Code Description**: The method first calls `long2board` to convert the input `board_long` into a vector of integers. It then creates a vector of Card objects with the same size as the integer vector. For each integer in the board vector, it creates a Card object using the `intCard2Str` function to convert the integer to a string representation, which is then used to initialize the Card object. The method checks if the resulting board size is between 1 and 7 cards, throwing a runtime error if it's not. Finally, it creates a new vector of Card objects and copies the created cards into it before returning. This function essentially transforms a compact 64-bit representation of a poker board into a more usable vector of Card objects.\\
## Code: 
```
vector<Card> Card::long2boardCards(uint64_t board_long){
        vector<int> board = long2board(board_long);
        vector<Card> board_cards(board.size());
        for(std::size_t i = 0;i < board.size();i ++){
            int one_board = board[i];
            board_cards[i] = Card(intCard2Str(one_board));
        }
        if (board_cards.size() < 1 || board_cards.size() > 7){
            throw runtime_error(tfm::format("board length not correct, board length %s",board_cards.size()));
        }
        vector<Card> retval(board_cards.size());
        for(std::size_t i = 0;i < board_cards.size();i ++){
            retval[i] = board_cards[i];
        }
        return retval;
}
```