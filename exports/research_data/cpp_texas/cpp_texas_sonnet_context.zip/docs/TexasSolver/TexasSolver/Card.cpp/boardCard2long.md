`boardCard2long`: The function of `boardCard2long` is to convert a Card object into a unique long integer value representing its position in a standard 52-card deck.

**Parameters**:\
`Card& card`: This parameter is an input reference to a Card object, which contains the information about the card that needs to be converted.

**Code Description**: The `boardCard2long` function calls another method `boardInt2long` from the same class, passing the result of calling `getCardInt` on the provided `card` parameter. This suggests that the `boardCard2long` function is a wrapper around the more complex conversion logic implemented in `boardInt2long`.\\
## Code: 
```
uint64_t Card::boardCard2long(Card& card){
    return Card::boardInt2long(card.getCardInt());
}
```