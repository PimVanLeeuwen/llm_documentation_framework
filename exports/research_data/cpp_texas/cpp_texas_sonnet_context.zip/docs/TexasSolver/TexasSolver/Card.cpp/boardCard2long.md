`boardCard2long`: The function of `boardCard2long` is to convert a Card object to a 64-bit long integer representation.

**Parameters**:
`Card& card`: A reference to a Card object that needs to be converted to a 64-bit long integer.

**Code Description**: This method takes a Card object as input and converts it to a 64-bit long integer representation. It does this by first calling the `getCardInt()` method on the input Card object to obtain its integer representation. Then, it passes this integer to the static method `Card::boardInt2long()`, which performs the actual conversion to a 64-bit long integer. The resulting long integer is then returned. This method serves as a wrapper around `boardInt2long()`, allowing it to work directly with Card objects instead of raw integer values.\\
## Code: 
```
uint64_t Card::boardCard2long(Card& card){
    return Card::boardInt2long(card.getCardInt());
}
```