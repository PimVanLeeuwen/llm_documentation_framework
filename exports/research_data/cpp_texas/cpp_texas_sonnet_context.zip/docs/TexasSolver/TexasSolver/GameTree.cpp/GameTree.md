`GameTree`: The function of `GameTree` is to initialize and construct a game tree for a Texas Hold'em poker game.

**Parameters**:
`Deck deck`: The deck of cards used in the game
`float oop_commit`: The amount committed by the out-of-position player
`float ip_commit`: The amount committed by the in-position player
`int current_round`: The current round of the game
`int raise_limit`: The maximum number of raises allowed
`float small_blind`: The amount of the small blind
`float big_blind`: The amount of the big blind
`float stack`: The total stack size for each player
`GameTreeBuildingSettings buildingSettings`: Settings for building the game tree
`float allin_threshold`: The threshold for considering a bet as an all-in move

**Code Description**: This constructor initializes a `GameTree` object for a Texas Hold'em poker game. It creates a `Rule` object with the given parameters to set up the game rules. The constructor then initializes the current player to 1 and sets the deck. It converts the current round to a `GameRound` enum using the `intToGameRound` method. An `ActionNode` is created as the root of the game tree, initialized with an empty set of actions and children, the current player, game round, and pot size. The `__build` method is called to construct the rest of the game tree starting from this root node. Finally, the root of the tree is set to this initial action node.\\
## Code: 
```
GameTree::GameTree(Deck deck,
                   float oop_commit,
                   float ip_commit,
                   int current_round,
                   int raise_limit,
                   float small_blind,
                   float big_blind,
                   float stack,
                   GameTreeBuildingSettings buildingSettings,
                   float allin_threshold
){
    Rule rule = Rule(deck,oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,buildingSettings,allin_threshold);
    int current_player = 1;
    this->deck = deck;
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(rule.current_round);
    shared_ptr<ActionNode> node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(),current_player, round, (double) rule.get_pot(),
                                 nullptr);
    this->__build(node,rule);
    this->root = node;
}
```