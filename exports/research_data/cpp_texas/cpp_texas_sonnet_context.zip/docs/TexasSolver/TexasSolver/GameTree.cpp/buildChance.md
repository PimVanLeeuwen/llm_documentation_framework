`buildChance`: The function of `buildChance` is to construct the next level of the game tree from a given chance node.

**Parameters**:
`shared_ptr<ChanceNode> root`: A shared pointer to the current chance node in the game tree.
`Rule rule`: An object containing the current game state and rules.

**Code Description**: This method builds the next level of the game tree from a given chance node. It first calculates the pot size from the rule object. Then, it determines the next action based on the current game state:

1. If both players have committed their entire stack and the current round is the river (round 3), it creates a ShowdownNode.
2. If both players have committed their entire stack but it's not the river, it creates a new ChanceNode for the next round.
3. If the players haven't committed their entire stacks, it creates an ActionNode.

After creating the appropriate node, it calls the `__build` method to continue constructing the tree from this new node. Finally, it sets the created node as the child of the root chance node.

The method includes several checks to ensure the current round is valid (not exceeding 3). It uses the GameTreeNode::intToGameRound method to convert round numbers to GameRound enums. The method handles different scenarios in poker gameplay, including all-in situations and normal betting rounds, ensuring the game tree accurately represents possible game states.\\
## Code: 
```
void GameTree::buildChance(shared_ptr<ChanceNode> root,Rule rule){
    //节点上的下注额度
    double pot = (double)rule.get_pot();
    Rule nextrule = Rule(rule);
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));

    shared_ptr<GameTreeNode> one_node;
    if(rule.oop_commit == rule.ip_commit && rule.oop_commit == rule.stack) {
        if(rule.current_round >= 3){ // 3 is river
            double p1_commit = rule.ip_commit;
            double p2_commit = rule.oop_commit;
            double peace_getback = (p1_commit + p2_commit) / 2;


            vector<vector<double>> payoffs(2);
            payoffs[0] = {p2_commit, -p2_commit};
            payoffs[1] = {-p1_commit, p1_commit};
            vector<double> peace_getback_vec = {peace_getback - p1_commit, peace_getback - p2_commit};
            one_node = make_shared<ShowdownNode>(peace_getback_vec, payoffs, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
        }else {
            nextrule.current_round += 1;
            if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
            one_node = make_shared<ChanceNode>(nullptr, GameTreeNode::intToGameRound(rule.current_round + 1), (double) rule.get_pot(), root, this->deck.getCards());
        }
    }else {
        one_node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(), 1, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
    }
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
    this->__build(one_node,nextrule,"begin",0,0);
    root->setChildren(one_node);
}
```