`getSettings`: The function of `getSettings` is to retrieve the appropriate StreetSetting based on the game round and player position.

**Parameters**:
`int int_round`: An integer representing the current game round (0-3 for preflop, flop, turn, river).
`int player`: An integer (0 or 1) representing the player position (0 for in-position, 1 for out-of-position).
`GameTreeBuildingSettings& gameTreeBuildingSettings`: A reference to the game tree building settings object containing street settings for different rounds and positions.

**Code Description**: The method first converts the `int_round` to a `GameTreeNode::GameRound` enum using the `intToGameRound` function. It then checks if the player value is valid (0 or 1). Based on the combination of game round and player position, it returns the corresponding StreetSetting from the `gameTreeBuildingSettings` object. For example, if it's the river round and the player is in-position (player 0), it returns `gameTreeBuildingSettings.river_ip`. If the combination is not recognized, it throws a runtime error with a formatted error message.\\
## Code: 
```
StreetSetting GameTree::getSettings(int int_round, int player,GameTreeBuildingSettings& gameTreeBuildingSettings){
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(int_round);
    if(!(player == 0 || player == 1)) throw runtime_error(tfm::format("player %s not known",player));
    if(round == GameTreeNode::GameRound::RIVER && player == 0) return gameTreeBuildingSettings.river_ip;
    else if(round == GameTreeNode::GameRound::TURN && player == 0) return gameTreeBuildingSettings.turn_ip;
    else if(round == GameTreeNode::GameRound::FLOP && player == 0) return gameTreeBuildingSettings.flop_ip;
    else if(round == GameTreeNode::GameRound::RIVER && player == 1) return gameTreeBuildingSettings.river_oop;
    else if(round == GameTreeNode::GameRound::TURN && player == 1) return gameTreeBuildingSettings.turn_oop;
    else if(round == GameTreeNode::GameRound::FLOP && player == 1) return gameTreeBuildingSettings.flop_oop;
    else throw new runtime_error(tfm::format("player %s and round not known",player));
}
```