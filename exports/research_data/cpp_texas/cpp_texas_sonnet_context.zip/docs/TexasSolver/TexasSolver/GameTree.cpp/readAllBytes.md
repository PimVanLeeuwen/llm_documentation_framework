`readAllBytes`: The function of `readAllBytes` is to open a file for reading.

**Parameters**:
`const string& filePath`: The path to the file that needs to be opened.

**Code Description**: This method is a member function of the `GameTree` class. It takes a file path as a string parameter and creates an `ifstream` object to open the specified file for reading. The function then returns this `ifstream` object. It's important to note that the function doesn't actually read the file contents; it merely opens the file and returns the stream object, which can be used later to read from the file.\\
## Code: 
```
ifstream GameTree::readAllBytes(const string& filePath) {
    ifstream input_file(filePath);
    return input_file;
}
```