`__build`: The function of `__build` is to recursively construct and expand a game tree node based on its type.

**Parameters**:
`shared_ptr<GameTreeNode> node`: A shared pointer to the current game tree node being processed.
`Rule rule`: The rules of the game being played.
`string last_action`: The last action taken in the game.
`int check_times`: The number of times a check action has been performed.
`int raise_times`: The number of times a raise action has been performed.

**Code Description**: The `__build` function is a key component in constructing a game tree for a poker-like game. It takes a node and, based on its type, calls the appropriate building function to expand the tree. The function uses a switch statement to handle different node types:

1. For ACTION nodes, it calls `buildAction` to create child nodes representing possible player actions.
2. For SHOWDOWN nodes, it does nothing as these are end-game states.
3. For TERMINAL nodes, it also does nothing as these are final states.
4. For CHANCE nodes, it calls `buildChance` to create child nodes representing possible chance outcomes.

If an unknown node type is encountered, it throws a runtime error. The function uses dynamic casting to convert the generic `GameTreeNode` pointer to the specific derived class pointer when calling `buildAction` or `buildChance`. After processing, it returns the input node, potentially with new child nodes added. This recursive approach allows for the complete construction of the game tree, representing all possible game states and transitions.\\
## Code: 
```
shared_ptr<GameTreeNode> GameTree::__build(shared_ptr<GameTreeNode> node, Rule rule, string last_action,
                                           int check_times, int raise_times) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            this->buildAction(std::dynamic_pointer_cast<ActionNode>(node),rule,last_action,check_times,raise_times);
            break;
        }case GameTreeNode::SHOWDOWN: {
            break;
        }case GameTreeNode::TERMINAL: {
            break;
        }case GameTreeNode::CHANCE: {
            this->buildChance(std::dynamic_pointer_cast<ChanceNode>(node),rule);
            break;
        }default:
            throw runtime_error("node type unknown");
    }
    return node;
}
```