`recurrentSetDepth`: The function of `recurrentSetDepth` is to set the depth and calculate the subtree size for each node in a game tree recursively.

**Parameters**:
`shared_ptr<GameTreeNode> node`: A shared pointer to the current game tree node being processed.
`int depth`: The current depth of the node in the game tree.

**Code Description**: This method recursively traverses the game tree, setting the depth for each node and calculating its subtree size. It first sets the depth of the current node. Then, based on the node type (Action, Chance, or Terminal), it performs different operations:

1. For Action nodes:
   - Casts the node to an ActionNode.
   - Recursively calls `recurrentSetDepth` on each child node, incrementing the depth.
   - Calculates the subtree size by summing the sizes of all child subtrees plus one (for the current node).

2. For Chance nodes:
   - Casts the node to a ChanceNode.
   - Recursively calls `recurrentSetDepth` on the single child node, incrementing the depth.
   - Calculates the subtree size by multiplying the child's subtree size by the number of possible cards, plus one.

3. For Terminal nodes:
   - Sets the subtree size to 1 (as it has no children).

Finally, it returns the calculated subtree size for the current node. This method is crucial for understanding the structure and complexity of the game tree, which is essential for game-solving algorithms.\\
## Code: 
```
int GameTree::recurrentSetDepth(shared_ptr<GameTreeNode> node, int depth) {
    node->depth = depth;
    if(node->getType() == GameTreeNode::ACTION) {
        shared_ptr<ActionNode> actionNode = std::dynamic_pointer_cast<ActionNode>(node);
        int subtree_size = 1;
        for(shared_ptr<GameTreeNode> one_child:actionNode->getChildrens()){
            subtree_size += this->recurrentSetDepth(one_child,depth + 1);
        }
        node->subtree_size = subtree_size;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chanceNode = std::dynamic_pointer_cast<ChanceNode>(node);
        int subtree_size = 1;
        subtree_size += this->recurrentSetDepth(chanceNode->getChildren(),depth + 1) * chanceNode->getCards().size();
        node->subtree_size = subtree_size;
    }else{
        node->subtree_size = 1;
    }
    return node->subtree_size;
}
```