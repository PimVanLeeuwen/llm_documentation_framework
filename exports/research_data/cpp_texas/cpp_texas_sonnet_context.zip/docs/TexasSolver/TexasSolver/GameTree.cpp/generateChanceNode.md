`generateChanceNode`: The function of `generateChanceNode` is to create and return a ChanceNode object in a game tree.

**Parameters**:
`json meta`: Contains metadata for the node, including the pot size.
`const json& child`: Represents the child node information in JSON format.
`string round`: Specifies the current game round as a string.
`shared_ptr<GameTreeNode> parent`: Pointer to the parent node in the game tree.

**Code Description**: This method creates a ChanceNode object within a game tree structure. It first extracts the pot size from the metadata. Then, it recursively generates a child node using the `recurrentGenerateTreeNode` function. The game round is converted from a string to an enum using `strToGameRound`. A new ChanceNode is created with the generated child, game round, pot size, parent node, and the deck of cards. The method then sets up the parent-child relationship between the new ChanceNode and its child. Finally, it returns the created ChanceNode. This function is crucial for building the chance nodes in a poker game tree, representing points where random events (like dealing cards) occur.\\
## Code: 
```
shared_ptr<ChanceNode>
GameTree::generateChanceNode(json meta, const json& child, string round, shared_ptr<GameTreeNode> parent) {
    //节点上的下注额度
    double pot = meta["pot"];
    shared_ptr<GameTreeNode> one_child = recurrentGenerateTreeNode(child, nullptr);
    GameTreeNode::GameRound game_round = strToGameRound(std::move(round));
    shared_ptr<ChanceNode> chanceNode = make_shared<ChanceNode>(one_child,game_round,pot,parent,this->deck.getCards());
    shared_ptr<GameTreeNode> gameTreeNode = chanceNode->getChildren();
    gameTreeNode->setParent(chanceNode);
    return chanceNode;
}
```