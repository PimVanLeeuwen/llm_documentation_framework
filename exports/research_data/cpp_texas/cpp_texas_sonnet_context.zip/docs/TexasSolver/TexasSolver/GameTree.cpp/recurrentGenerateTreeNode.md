`recurrentGenerateTreeNode`: The function of `recurrentGenerateTreeNode` is to recursively generate a game tree node based on the provided JSON data and parent node.

**Parameters**:
`json node_json`: A JSON object containing the node's metadata and children information.
`const shared_ptr<GameTreeNode>& parent`: A shared pointer to the parent node in the game tree.

**Code Description**: This method processes the JSON data to create different types of game tree nodes. It first extracts and validates the round and node type from the metadata. The function then creates and returns a specific type of node based on the node_type:

1. For "Action" nodes, it processes children actions and their corresponding JSON data, then generates an ActionNode.
2. For "Showdown" nodes, it creates a ShowdownNode.
3. For "Terminal" nodes, it generates a TerminalNode.
4. For "Chance" nodes, it ensures there's only one child and creates a ChanceNode.

The method uses helper functions (generateActionNode, generateShowdownNode, generateTerminalNode, generateChanceNode) to create the specific node types. It handles potential errors by throwing runtime exceptions for invalid data or unexpected conditions. The function returns a shared pointer to the newly created GameTreeNode.\\
## Code: 
```
shared_ptr<GameTreeNode> GameTree::recurrentGenerateTreeNode(json node_json, const shared_ptr<GameTreeNode>& parent) {
    json meta = node_json["meta"];
    string round = meta["round"];
    if(round.empty()){
        throw runtime_error("node json get round null pointer");
    }

    if(! (round == "preflop"
          || round == "flop"
          || round == "turn"
          || round == "river"
          )
            ){
        throw runtime_error(tfm::format("round %s not found",round));
    }

    string node_type = meta["node_type"];
    if(node_type.empty()){
        throw runtime_error("node json get round null pointer");
    }
    if (! (   node_type == "Terminal"
           || node_type == "Showdown"
           || node_type ==  "Action"
           || node_type ==  "Chance"
    )
            ){
        throw runtime_error(tfm::format("node type %s not found",node_type));
    }

    if(node_type == "Action") {
        // 孩子节点的动作，存在list里
        auto childrens_actions = node_json["children_actions"].get<std::vector<string>>();
        // 孩子节点本身，同样存在list里,和上面的children_actions 一一对应,事实上两者的长度一致
        vector<json> childrens = node_json["children"].get<std::vector<json>>();
        if (childrens.size() != childrens_actions.size()) {
            throw runtime_error("action node child length mismatch");
        }
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateActionNode(meta, childrens_actions, childrens, round,parent));
    }
    else if(node_type == "Showdown") {
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateShowdownNode(meta, round,parent));
    }
    else if(node_type == "Terminal") {
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateTerminalNode(meta, round,parent));
    }
    else if(node_type == "Chance") {
        auto childrens = node_json["children"].get<std::vector<json>>();
        if(childrens.size() != 1) throw runtime_error("Chance node should have only one child");
        return std::dynamic_pointer_cast<GameTreeNode>(this->generateChanceNode(meta, childrens[0], round,parent));
    }
    else{
        throw runtime_error(tfm::format("node type %s not found",node_type));
    }
}
```