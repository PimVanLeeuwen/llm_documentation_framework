`getRoot`: The function of `getRoot` is to return the root node of the game tree.

**Code Description**: This method is a simple accessor function for the GameTree class. It returns a shared pointer to the root node of the game tree, which is stored as a member variable named `root`. The use of a shared pointer (`shared_ptr`) suggests that the ownership of the root node is shared, allowing multiple parts of the program to safely access and manage the lifetime of the root node.\\
## Code: 
```
shared_ptr<GameTreeNode> GameTree::getRoot() {
    return this->root;
}
```