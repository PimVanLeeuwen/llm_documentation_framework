`round_nearest`: The function of `round_nearest` is to round a given number to the nearest multiple of a specified value.

**Parameters**:
`double number`: The input number to be rounded.
`double round_num`: The value to round to (e.g., 0.01 for rounding to the nearest cent).

**Code Description**: This method takes two double parameters: `number` and `round_num`. It first inverts `round_num` by calculating its reciprocal (1 / round_num). Then, it multiplies the input `number` by this inverted value, rounds the result to the nearest integer using the `round()` function, and finally divides the rounded value by the inverted `round_num`. This process effectively rounds the input `number` to the nearest multiple of `round_num`. For example, if `number` is 3.14159 and `round_num` is 0.01, the function will return 3.14, rounding to the nearest hundredth.\\
## Code: 
```
double GameTree::round_nearest(double number, double round_num) {
    round_num = 1 / round_num;
    return round((number * round_num)) / round_num;

}
```