`strToGameRound`: The function of `strToGameRound` is to convert a string representation of a game round to its corresponding enumeration value.

**Parameters**:
`const string& round`: A string representing the game round (e.g., "preflop", "flop", "turn", or "river").

**Code Description**: This method takes a string parameter representing a game round and converts it to the corresponding `GameTreeNode::GameRound` enumeration value. It uses a series of if-else statements to check the input string against known round names. If the input matches "preflop", it returns `GameTreeNode::GameRound::PREFLOP`. Similarly, it returns `FLOP`, `TURN`, or `RIVER` for the respective input strings. If the input doesn't match any known round name, the function throws a runtime_error with a formatted error message. This method ensures that string representations of game rounds are correctly translated to their enumerated types for use within the game tree structure.\\
## Code: 
```
GameTreeNode::GameRound GameTree::strToGameRound(const string& round) {
    GameTreeNode::GameRound game_round;
    if(round == "preflop"){
        game_round = GameTreeNode::GameRound::PREFLOP;
    }
    else if (round == "flop"){
        game_round = GameTreeNode::GameRound::FLOP;
    }
    else if(round == "turn"){
        game_round = GameTreeNode::GameRound::TURN;
    }
    else if(round == "river"){
        game_round = GameTreeNode::GameRound::RIVER;
    }
    else{
        throw runtime_error(tfm::format("game round not found: %s",round));
    }
    return game_round;
}
```