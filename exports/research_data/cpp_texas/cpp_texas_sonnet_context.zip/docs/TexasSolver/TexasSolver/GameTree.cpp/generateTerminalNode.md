`generateTerminalNode`: The function of `generateTerminalNode` is to generate a terminal node in the game tree based on the provided meta information, round, and parent node.

**Parameters**:
- `json meta`: A JSON object containing metadata about the game, including player payoffs and pot.
- `string round`: A string representing the current game round.
- `shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node in the game tree.

**Code Description**: The function first extracts the player payoffs from the meta information and creates a vector of doubles. It then converts the round string to a GameRound enum value using the strToGameRound method. The function also retrieves the current player ID from the meta information. Finally, it creates a new TerminalNode object with the extracted data and returns it as a shared pointer.\\
## Code: 
```
shared_ptr<TerminalNode> GameTree::generateTerminalNode(json meta, string round, shared_ptr<GameTreeNode> parent) {
    vector<double> player_payoff_list = meta["payoff"];
    vector<double> player_payoff(player_payoff_list.size());
    for(std::size_t one_player = 0;one_player < player_payoff_list.size();one_player ++){

        double tmp_payoff = player_payoff_list[one_player];
        player_payoff[one_player] = tmp_payoff;
    }

    //节点上的下注额度
    double pot = meta["pot"];

    GameTreeNode::GameRound game_round = this->strToGameRound(std::move(round));
    // 多人游戏的时候winner就不等于当前节点的玩家了，这里要注意
    int player = meta["player"];

    return make_shared<TerminalNode>(player_payoff,player,game_round,pot,parent);
}
```