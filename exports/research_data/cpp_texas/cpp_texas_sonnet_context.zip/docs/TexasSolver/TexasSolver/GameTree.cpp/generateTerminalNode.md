`generateTerminalNode`: The function of `generateTerminalNode` is to create and return a shared pointer to a TerminalNode object representing the end state of a game.

**Parameters**:
`json meta`: A JSON object containing game state information such as player payoffs, pot size, and current player.
`string round`: A string representing the current game round.
`shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node in the game tree.

**Code Description**: This method creates a TerminalNode object for a poker game tree. It first extracts player payoffs from the `meta` JSON object and stores them in a vector. The pot size is also retrieved from `meta`. The `round` string is converted to a GameRound enum using the `strToGameRound` method. The current player is obtained from `meta`. Finally, a new TerminalNode is created and returned as a shared pointer, initialized with the extracted payoffs, current player, game round, pot size, and parent node. This node represents a terminal state in the game tree, typically the end of a hand where payoffs are determined.\\
## Code: 
```
shared_ptr<TerminalNode> GameTree::generateTerminalNode(json meta, string round, shared_ptr<GameTreeNode> parent) {
    vector<double> player_payoff_list = meta["payoff"];
    vector<double> player_payoff(player_payoff_list.size());
    for(std::size_t one_player = 0;one_player < player_payoff_list.size();one_player ++){

        double tmp_payoff = player_payoff_list[one_player];
        player_payoff[one_player] = tmp_payoff;
    }

    //节点上的下注额度
    double pot = meta["pot"];

    GameTreeNode::GameRound game_round = this->strToGameRound(std::move(round));
    // 多人游戏的时候winner就不等于当前节点的玩家了，这里要注意
    int player = meta["player"];

    return make_shared<TerminalNode>(player_payoff,player,game_round,pot,parent);
}
```