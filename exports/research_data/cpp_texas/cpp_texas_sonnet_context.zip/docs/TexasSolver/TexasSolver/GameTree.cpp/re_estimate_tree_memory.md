`re_estimate_tree_memory`: The function of `re_estimate_tree_memory` is to recursively estimate the memory usage of a game tree.

**Parameters**:
`const shared_ptr<GameTreeNode>& node`: A shared pointer to the current node in the game tree being analyzed.
`int deck_num`: The number of cards in the deck.
`int p1range_num`: The number of possible hands for player 1.
`int p2range_num`: The number of possible hands for player 2.
`int num_current_deal`: The number of possible deals at the current node.

**Code Description**: This function recursively traverses the game tree to estimate memory usage. It handles two types of nodes:

1. For Action nodes:
   - It recursively calls itself on all child nodes.
   - Calculates additional memory based on the player, number of children, and range sizes.
   - For player 1, it adds: num_current_deal * p1range_num * (childrens.size() + 1) * 3
   - For player 2, it adds: num_current_deal * p2range_num * (childrens.size() + 1) * 3

2. For Chance nodes:
   - It recursively calls itself on the child node.
   - Updates num_current_deal by multiplying it with deck_num.

The function returns the total estimated memory usage in bytes as a long long integer. This estimation helps in understanding the space complexity of the game tree, which is crucial for optimizing memory usage in large-scale game simulations.\\
## Code: 
```
long long GameTree::re_estimate_tree_memory(const shared_ptr<GameTreeNode>& node,int deck_num,int p1range_num,int p2range_num,int num_current_deal){
    if(node->getType() == GameTreeNode::ACTION){
        shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
        vector<shared_ptr<GameTreeNode>> childrens = action_node->getChildrens();
        vector<GameActions> actions = action_node->getActions();

        long long retnum = 0;
        for(std::size_t i = 0;i < childrens.size();i++){
            shared_ptr<GameTreeNode> one_child = childrens[i];
            retnum += re_estimate_tree_memory(one_child,deck_num, p1range_num, p2range_num, num_current_deal);
        }
        if(action_node->getPlayer() == 0){
            retnum += num_current_deal * p1range_num * (childrens.size() + 1) * 3;
        }else{
            retnum += num_current_deal * p2range_num * (childrens.size() + 1) * 3;
        }
        return retnum;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
        shared_ptr<GameTreeNode> children = chance_node->getChildren();
        return re_estimate_tree_memory(children,deck_num, p1range_num, p2range_num, num_current_deal * (deck_num));
    }
    return 0;
}
```