`generateShowdownNode`: The function of `generateShowdownNode` is to generate a Showdown node in the game tree based on the provided meta information, round number, and parent node.

**Parameters**:
- `json meta`: A JSON object containing payoff information for different players and tie scenarios.
- `string round`: A string representing the current round of the game.
- `shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node in the game tree.

**Code Description**: The function first extracts relevant information from the provided meta JSON, including tie payoffs and player-specific payoff vectors. It then constructs a ShowdownNode object with this information, along with the current round number and pot value, and returns it as a shared pointer. If any player ID is invalid (i.e., not 0 or 1), it throws a runtime error.\\
## Code: 
```
shared_ptr<ShowdownNode> GameTree::generateShowdownNode(json meta, string round, shared_ptr<GameTreeNode> parent) {
    json meta_payoffs = meta["payoffs"];
    vector<double> tie_payoffs = meta_payoffs["tie"];

    // meta_payoffs 的key有 n个玩家+1个平局,代表某个玩家赢了的时候如何分配payoff
    vector<vector<double>> player_payoffs(2);
    double pot = meta["pot"];

    for(auto one_player_meta=meta_payoffs.begin(); one_player_meta!=meta_payoffs.end(); one_player_meta++){
        const string& one_player = one_player_meta.key();
        if(one_player == "tie"){
            continue;
        }
        // 获胜玩家id
        int player_id = atoi(one_player.c_str());
        if(player_id < 0 or player_id > 1) throw runtime_error("player id json convert fail");

        // 玩家在当前Showdown节点能获得的收益
        //List<Object> tmp_payoffs =  (List<Object>)meta_payoffs.get(one_player);
        vector<double> player_payoff = one_player_meta.value();

        player_payoffs[atoi(one_player.c_str())] = player_payoff;
    }
    GameTreeNode::GameRound game_round = strToGameRound(std::move(round));
    return make_shared<ShowdownNode>(tie_payoffs,player_payoffs,game_round,pot,parent);
}
```