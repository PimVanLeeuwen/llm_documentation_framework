`estimate_tree_memory`: The function of `estimate_tree_memory` is to estimate the memory usage of the game tree.

**Parameters**:
`int deck_num`: The number of cards in the deck
`int p1range_num`: The number of possible hands for player 1
`int p2range_num`: The number of possible hands for player 2
`int num_current_deal`: The number of cards currently dealt

**Code Description**: This method is a wrapper function that calls the recursive method `re_estimate_tree_memory` with the same parameters, starting from the root node of the game tree. It returns a long long integer representing the estimated memory usage in bytes. The actual estimation logic is implemented in the `re_estimate_tree_memory` method, which likely traverses the game tree and calculates the memory requirements based on the tree structure and the given parameters.\\
## Code: 
```
long long GameTree::estimate_tree_memory(int deck_num,int p1range_num,int p2range_num,int num_current_deal){
    return this->re_estimate_tree_memory(this->root,deck_num, p1range_num, p2range_num, num_current_deal);
}
```