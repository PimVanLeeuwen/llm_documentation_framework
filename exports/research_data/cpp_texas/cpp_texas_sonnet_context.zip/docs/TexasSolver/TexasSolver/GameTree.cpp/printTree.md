`printTree`: The function of `printTree` is to initiate the printing of the game tree structure.

**Parameters**:
`int depth`: Specifies the maximum depth of the tree to print. A value of -1 means print the entire tree.

**Code Description**: This method serves as an entry point for printing the game tree. It first performs a validation check on the depth parameter, throwing a runtime error if the depth is less than -1 or equal to 0. If the depth is valid, it initializes an empty vector of strings called `prefix`, which is likely used for formatting the tree output. Finally, it calls the recursive method `recurrentPrintTree`, passing the root node of the tree, an initial depth of 0, and the specified maximum depth. This recursive method is responsible for traversing the tree and printing its structure.\\
## Code: 
```
void GameTree::printTree(int depth) {
    if(depth < -1 || depth == 0){
        throw runtime_error("depth can only be -1 or positive");
    }
    vector<string> prefix;
    this->recurrentPrintTree(this->root,0,depth);
}
```