The function of `printTree` is to print the game tree structure in a hierarchical manner.

**Parameters**:
`int depth`: The depth at which to start printing the game tree. A value of -1 indicates that the entire tree should be printed, while positive values indicate the maximum depth to reach.

**Code Description**: 
The `printTree` function is designed to print out relevant information about each node in a hierarchical manner. It takes an integer parameter `depth`, which determines how deep into the game tree to print. If `depth` is -1 or greater than 0, it calls the `recurrentPrintTree` method to recursively traverse and print the game tree structure. The function throws a runtime error if `depth` is not within the valid range of -1 or positive values.\\
## Code: 
```
void GameTree::printTree(int depth) {
    if(depth < -1 || depth == 0){
        throw runtime_error("depth can only be -1 or positive");
    }
    vector<string> prefix;
    this->recurrentPrintTree(this->root,0,depth);
}
```