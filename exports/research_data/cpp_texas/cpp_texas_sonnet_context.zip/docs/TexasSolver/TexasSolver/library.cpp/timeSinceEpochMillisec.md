`timeSinceEpochMillisec`: The function of `timeSinceEpochMillisec` is to return the current time in milliseconds since the Unix epoch.

**Code Description**: This function uses C++11's chrono library to calculate and return the number of milliseconds that have elapsed since January 1, 1970 (Unix epoch). It does this by getting the current system time (`system_clock::now()`), converting it to a duration since the epoch (`.time_since_epoch()`), and then casting that duration to milliseconds using `duration_cast<milliseconds>()`. The `.count()` method is then called to return the number of milliseconds as a `uint64_t` (64-bit unsigned integer) value. This function is useful for high-precision timing and generating timestamps in millisecond resolution.\\
## Code: 
```
uint64_t timeSinceEpochMillisec() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
}
```