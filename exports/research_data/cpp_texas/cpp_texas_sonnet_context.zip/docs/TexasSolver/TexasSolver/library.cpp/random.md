`random`: The function of `random` is to generate a random integer within a specified range.

**Parameters**:
`int min`: The lower bound of the range (inclusive)
`int max`: The upper bound of the range (exclusive)

**Code Description**: This function uses the C++ built-in `rand()` function to generate a random number. It takes two parameters, `min` and `max`, which define the range of the random number to be generated. The function returns an integer that is greater than or equal to `min` and less than `max`. The calculation `rand() % ((max) - min)` generates a random number between 0 and (max - min - 1), which is then added to `min` to shift the range to start from the desired minimum value. This ensures that the returned value falls within the specified range [min, max).\\
## Code: 
```
int random(int min, int max) //range : [min, max)
{
    return min + rand() % (( max ) - min);
}
```