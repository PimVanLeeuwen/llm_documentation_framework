`normalization_tanh`: The function of `normalization_tanh` is to normalize a value using the hyperbolic tangent function.

**Parameters**:
`float stack`: The stack size or total amount available.
`float ev`: The expected value or target amount.
`float ratio`: A scaling factor to adjust the normalization.

**Code Description**: This function performs a normalization using the hyperbolic tangent (tanh) function. It first calculates `x` by dividing `ev` by `stack` and multiplying by `ratio`. This `x` value is then passed through the tanh function, which maps the input to a value between -1 and 1. The result is then scaled and shifted to fall between 0 and 1 by dividing by 2 and adding 0.5. This normalization technique is useful for mapping potentially large or small input values to a consistent range, which can be beneficial in various algorithms or decision-making processes, particularly in game theory or financial modeling contexts.\\
## Code: 
```
float normalization_tanh(float stack,float ev,float ratio){
    float x = ev / stack * ratio;
    return tanh(x) / 2 + 0.5;
}
```