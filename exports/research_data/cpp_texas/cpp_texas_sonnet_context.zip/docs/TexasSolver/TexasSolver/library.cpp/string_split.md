`string_split`: The function of `string_split` is to split a string into substrings based on a specified delimiter character.

**Parameters**:
`string strin`: The input string to be split
`char split`: The delimiter character used to split the string

**Code Description**: This function takes a string `strin` and a character `split` as input. It uses a `stringstream` to process the input string and the `getline` function to extract substrings. The function iterates through the input string, splitting it at each occurrence of the delimiter character. Each resulting substring is stored as an element in a vector of strings. Finally, the function returns this vector containing all the split substrings.\\
## Code: 
```
vector<string> string_split(string strin,char split){
    vector<string> retval;
    stringstream ss(strin);
    string token;
    while (getline(ss,token, split))
    {
        retval.push_back(token);
    }
    return retval;
}
```