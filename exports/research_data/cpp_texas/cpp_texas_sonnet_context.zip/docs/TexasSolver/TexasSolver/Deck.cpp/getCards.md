`getCards`: The function of `getCards` is to return a reference to the vector of cards in the deck.

**Code Description**: This method is a simple getter function that provides access to the private member variable `cards` of the `Deck` class. It returns a reference to the `vector<Card>` object, allowing the caller to directly access and potentially modify the cards in the deck. The use of a reference return type (`vector<Card>&`) ensures that no copy of the vector is made, which can be more efficient, especially for large decks.\\
## Code: 
```
vector<Card>& Deck::getCards() {
    return this->cards;
}
```