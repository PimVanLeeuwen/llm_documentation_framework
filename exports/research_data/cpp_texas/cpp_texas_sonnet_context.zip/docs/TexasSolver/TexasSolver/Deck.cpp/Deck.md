`Deck`: The function of `Deck` is to initialize a deck of cards.

**Parameters**:
`const vector<string>& ranks`: A vector containing the ranks of cards (e.g., "2", "3", ..., "K", "A").
`const vector<string>& suits`: A vector containing the suits of cards (e.g., "♠", "♥", "♦", "♣").

**Code Description**: This constructor initializes a deck of cards based on the provided ranks and suits. It first stores the input ranks and suits in the object's member variables. Then, it generates all possible combinations of ranks and suits to create individual cards. Each card is represented as a string (e.g., "A♠") and stored in the `cards_str` vector. Additionally, it creates `Card` objects for each combination, assigning them a unique numerical identifier, and stores these in the `cards` vector. The numerical identifiers start from 0 and increment for each card created.\\
## Code: 
```
Deck::Deck(const vector<string>& ranks, const vector<string>& suits) {
    this->ranks = ranks;
    this->suits = suits;
    int card_num = 0;
    for(const string& one_rank : ranks){
        for(const string& one_suit: suits){
            string one_card = one_rank + one_suit;
            cards_str.push_back(one_card);
            cards.emplace_back(one_card,card_num);
            card_num += 1;
        }
    }
}
```