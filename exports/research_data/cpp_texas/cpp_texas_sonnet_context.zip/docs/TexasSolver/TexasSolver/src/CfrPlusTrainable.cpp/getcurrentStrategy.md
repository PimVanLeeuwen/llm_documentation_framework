`getcurrentStrategy`: The function of `getcurrentStrategy` is to calculate and return the current strategy probabilities for each action and private card combination.

**Code Description**: This method computes the current strategy probabilities based on the regret-matching algorithm used in Counterfactual Regret Minimization (CFR+). It initializes a vector `retval` with strategy probabilities. If `r_plus_sum` is empty, it sets equal probabilities for all actions. Otherwise, it calculates probabilities using the formula: strategy[action][card] = r_plus[action][card] / r_plus_sum[card]. If `r_plus_sum` for a card is zero, it assigns equal probabilities. The method includes error checking for NaN values and returns the computed strategy vector.\\
## Code: 
```
const vector<float> CfrPlusTrainable::getcurrentStrategy() {
    if(this->r_plus_sum.empty()){
        fill(retval.begin(),retval.end(),1.0 / this->action_number);
    }else {
        for (int action_id = 0; action_id < action_number; action_id++) {
            for (int private_id = 0; private_id < this->card_number; private_id++) {
                int index = action_id * this->card_number + private_id;
                if(this->r_plus_sum[private_id] != 0) {
                    retval[index] = this->r_plus[index] / this->r_plus_sum[private_id];
                }else{
                    retval[index] = 1.0 / this->action_number;
                }
                if(this->r_plus[index] != this->r_plus[index]) throw runtime_error("nan found");
                /*
                if(this.r_plus_sum[private_id] == 0)
                {
                    System.out.println("Exception regret status, r_plus_sum == 0:");
                    System.out.println(String.format("r plus length %s , card num %s",r_plus.length,this.card_number));
                    for(int i = index % this.card_number;i < this.r_plus.length;i += this.card_number){
                        System.out.print(String.format("%s:%s ",i,this.r_plus[i]));
                        if(i == index){
                            System.out.print("[current]");
                        }
                    }
                    System.out.println();
                    System.out.println();
                    throw new RuntimeException();
                }
                 */
            }
        }
    }
    return retval;
}
```