`CfrPlusTrainable`: The function of `CfrPlusTrainable` is to initialize a CFR+ (Counterfactual Regret Minimization Plus) trainable object for a given action node and set of private cards in a Texas Hold'em poker game.

**Parameters**:
`shared_ptr<ActionNode> action_node`: A shared pointer to the action node in the game tree for which the CFR+ trainable object is being created.
`vector<PrivateCards> privateCards`: A vector containing the possible private card combinations for the current player.

**Code Description**: This constructor initializes a CFR+ trainable object with the provided action node and private cards. It sets up the necessary data structures for the CFR+ algorithm:

1. Stores the input action node and private cards.
2. Determines the number of possible actions and private card combinations.
3. Initializes vectors for storing regret values (r_plus), cumulative regret values (cum_r_plus), and strategy values (retval).
4. Creates vectors for summing regret values (r_plus_sum and cum_r_plus_sum) across different actions for each private card combination.

These data structures are essential for implementing the CFR+ algorithm, which is an improved version of the standard CFR algorithm used for solving imperfect information games like poker. The initialized vectors will be used to store and update regret values and strategies during the training process.\\
## Code: 
```
CfrPlusTrainable::CfrPlusTrainable(shared_ptr<ActionNode> action_node, vector<PrivateCards> privateCards) {
    this->action_node = action_node;
    this->privateCards = privateCards;
    this->action_number = action_node->getChildrens().size();
    this->card_number = privateCards.size();

    this->r_plus = vector<float>(this->action_number * this->card_number);
    this->r_plus_sum = vector<float>(this->card_number);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number);
    this->cum_r_plus_sum = vector<float>(this->card_number);
    this->retval = vector<float>(this->action_number * this->card_number);
}
```