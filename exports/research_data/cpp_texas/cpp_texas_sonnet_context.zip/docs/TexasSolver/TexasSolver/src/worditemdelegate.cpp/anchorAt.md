`anchorAt`: The function of `anchorAt` is to retrieve the anchor at a specific point in an HTML document.

**Parameters**:
`QString html`: The HTML content to be analyzed.
`const QPoint &point`: The coordinates of the point to check for an anchor.

**Code Description**: This method creates a QTextDocument object and sets its content to the provided HTML string. It then obtains the document layout and uses it to find the anchor at the specified point. The method returns the anchor text as a QString. If no anchor is found at the given point, an empty string is returned. The function utilizes Qt's text rendering capabilities to interpret the HTML and locate anchors within it.\\
## Code: 
```
QString WordItemDelegate::anchorAt(QString html, const QPoint &point) const {
    QTextDocument doc;
    doc.setHtml(html);

    auto textLayout = doc.documentLayout();
    Q_ASSERT(textLayout != 0);
    return textLayout->anchorAt(point);
}
```