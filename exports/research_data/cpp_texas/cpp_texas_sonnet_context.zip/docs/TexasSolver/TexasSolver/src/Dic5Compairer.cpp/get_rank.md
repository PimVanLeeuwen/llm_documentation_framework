`get_rank`: The function of `get_rank` is to determine the rank of a poker hand.

**Parameters**:
`uint64_t private_hand`: A 64-bit integer representing the private hand cards.
`uint64_t public_board`: A 64-bit integer representing the public board cards.

**Code Description**: This method is an overload of the `get_rank` function that takes two `uint64_t` parameters representing the private hand and public board. It converts these 64-bit integer representations into board representations using the `Card::long2board` method, then calls another overload of `get_rank` with these converted board representations. The function returns an integer value representing the rank of the poker hand formed by the combination of the private hand and public board cards.\\
## Code: 
```
int Dic5Compairer::get_rank(uint64_t private_hand, uint64_t public_board) {
    return this->get_rank(Card::long2board(private_hand),Card::long2board(public_board));
}
```