`setBoardAt`: The function of `setBoardAt` is to set a float value at a specific position in a 2D grid.

**Parameters**:
`int i`: The row index in the grid.
`int j`: The column index in the grid.
`float value`: The float value to be set at the specified position.

**Code Description**: This method sets a float value at a specific position (i, j) in a 2D grid represented by `grids_float`. It first checks if the provided indices are valid by comparing them against the sizes of `suitlist` and `ranklist`. If either index is out of bounds, it logs a debug message with the invalid index. If both indices are valid, it assigns the given `value` to the corresponding position in the `grids_float` array. The method uses Qt's debug logging system (qDebug()) for error reporting.\\
## Code: 
```
void BoardSelectorTableModel::setBoardAt(int i, int j,float value){
    if(i < 0 || i >= this->suitlist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::setBoardAt i not valid: " << i;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::setBoardAt j not valid: " << j;
    }
    else{
        this->grids_float[i][j] = value;
    }
}
```