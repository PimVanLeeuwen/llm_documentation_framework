`parent`: The function of `parent` is to return the parent index of a given child index in a hierarchical model.

**Parameters**:
`const QModelIndex &child`: The child index for which to find the parent.

**Code Description**: This method is an implementation of the `parent` function from the Qt Model/View framework. It always returns an invalid `QModelIndex()`, indicating that all items in this model are top-level items with no parent. This implementation suggests that the `RangeSelectorTableModel` represents a flat, non-hierarchical structure where each item is at the root level.\\
## Code: 
```
QModelIndex RangeSelectorTableModel::parent(const QModelIndex &child) const {
    return QModelIndex();
}
```