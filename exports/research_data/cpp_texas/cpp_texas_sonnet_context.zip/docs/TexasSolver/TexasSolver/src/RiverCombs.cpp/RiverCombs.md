`RiverCombs`: The function of `RiverCombs` is to initialize a RiverCombs object with given parameters.

**Parameters**:
`vector<int> board`: Represents the community cards on the board.
`PrivateCards private_cards`: Represents the private cards of a player.
`int rank`: Represents the rank of the hand.
`int reach_prob_index`: Represents the index for reach probability.

**Code Description**: This is a constructor for the RiverCombs class. It takes four parameters and initializes the corresponding member variables of the class. The board is set to the input vector of integers, representing the community cards. The private_cards member is set to the input PrivateCards object, which likely contains information about a player's hole cards. The rank member is set to the input integer value, which probably represents the strength or ranking of the hand. Finally, the reach_prob_index is set to the input integer value, which may be used for probability calculations in poker simulations or analysis.\\
## Code: 
```
RiverCombs::RiverCombs(vector<int> board, PrivateCards private_cards, int rank, int reach_prob_index) {
    this->board = board;
    this->rank = rank;
    this->private_cards = private_cards;
    this->reach_prob_index = reach_prob_index;
}
```