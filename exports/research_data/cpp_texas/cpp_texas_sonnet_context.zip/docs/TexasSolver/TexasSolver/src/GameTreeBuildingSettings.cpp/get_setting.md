`get_setting`: The function of `get_setting` is to retrieve the appropriate StreetSetting based on the player position and game round.

**Parameters**:
`string player`: Specifies the player position, either "ip" (in position) or "oop" (out of position)
`string round`: Indicates the game round, can be "flop", "turn", or "river"

**Code Description**: This method takes two string parameters, `player` and `round`, and returns a reference to the corresponding StreetSetting object. It uses a series of if-else statements to determine which StreetSetting to return based on the input parameters. The method checks for six possible combinations:

1. In position (ip) on the flop
2. In position (ip) on the turn
3. In position (ip) on the river
4. Out of position (oop) on the flop
5. Out of position (oop) on the turn
6. Out of position (oop) on the river

If the input doesn't match any of these combinations, the method throws a runtime_error with the message "get_setting not valid". This ensures that only valid player positions and game rounds are used when retrieving settings.\\
## Code: 
```
StreetSetting& GameTreeBuildingSettings::get_setting(string player,string round){
    if(player == "ip" && round == "flop") return flop_ip;
    else if(player == "ip" && round == "turn") return turn_ip;
    else if(player == "ip" && round == "river") return river_ip;
    else if(player == "oop" && round == "flop") return flop_oop;
    else if(player == "oop" && round == "turn") return turn_oop;
    else if(player == "oop" && round == "river") return river_oop;
    else throw runtime_error("get_setting not valid");
}
```