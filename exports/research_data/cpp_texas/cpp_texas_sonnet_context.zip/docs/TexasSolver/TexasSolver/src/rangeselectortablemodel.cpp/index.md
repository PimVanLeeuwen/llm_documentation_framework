`index`: The function of `index` is to create and return a valid model index for a given row and column in the table model.

**Parameters**:
`int row`: The row number for which to create the index.
`int column`: The column number for which to create the index.
`const QModelIndex &parent`: The parent index, which is not used in this implementation as the model represents a flat table structure.

**Code Description**: This method implements the `index` function for a custom table model. It first checks if the requested index is valid using the `hasIndex` function. If the index is not valid, it returns an invalid `QModelIndex`. For valid indices, it creates and returns a new `QModelIndex` using the `createIndex` function, passing the row and column numbers, and a null pointer as the internal pointer (since no custom data is associated with the index in this implementation). This method is essential for the model/view framework to locate and access data items in the model.\\
## Code: 
```
QModelIndex RangeSelectorTableModel::index(int row, int column,
          const QModelIndex &parent) const  {
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    return createIndex(row, column, nullptr);
}
```