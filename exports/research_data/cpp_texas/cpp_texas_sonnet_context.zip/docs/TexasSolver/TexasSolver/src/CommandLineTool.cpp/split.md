`split`: The function of `split` is to divide a string into substrings based on a specified delimiter character.

**Parameters**:
`const string& s`: The input string to be split
`char c`: The delimiter character used to split the string
`vector<string>& v`: A reference to a vector of strings where the split substrings will be stored

**Code Description**: The function iterates through the input string, searching for occurrences of the delimiter character. It uses two string::size_type variables, i and j, to keep track of the current position and the next occurrence of the delimiter, respectively. When a delimiter is found, the substring between i and j is extracted using substr() and added to the vector v. The process continues until no more delimiters are found. If there's remaining text after the last delimiter, it's added as the final substring. This method modifies the vector v directly, populating it with the split substrings.\\
## Code: 
```
void split(const string& s, char c,
           vector<string>& v) {
    string::size_type i = 0;
    string::size_type j = s.find(c);

    while (j != string::npos) {
        v.push_back(s.substr(i, j-i));
        i = ++j;
        j = s.find(c, j);

        if (j == string::npos)
            v.push_back(s.substr(i, s.length()));
    }
}
```