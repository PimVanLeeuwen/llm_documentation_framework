`estimate_tree_memory`: The function of `estimate_tree_memory` is to calculate the estimated memory usage of the game tree based on given player ranges and the board.

**Parameters**:
`QString range1`: A string representing the range of hands for player 1.
`QString range2`: A string representing the range of hands for player 2.
`QString board`: A string representing the community cards on the board.

**Code Description**: This method first checks if the game tree has been built. If not, it returns 0 and outputs a debug message. If the tree exists, it processes the input parameters:

1. Converts player ranges from QString to std::string.
2. Splits the board string into individual card strings.
3. Converts each board card string to its integer representation using Card::strCard2int.
4. Converts player range strings to vectors of PrivateCards using PrivateRangeConverter::rangeStr2Cards.
5. Calculates the number of remaining cards in the deck by subtracting the board size from the total deck size.
6. Calls the game tree's estimate_tree_memory method with the number of remaining cards and the sizes of both player ranges.

The method handles the conversion between different data types (QString to std::string, string to int for cards) and uses helper functions to process the input data. It ultimately delegates the actual memory estimation to the game tree object, passing it the processed information about the game state.\\
## Code: 
```
long long PokerSolver::estimate_tree_memory(QString range1,QString range2,QString board){
    if(this->game_tree == nullptr){
        qDebug().noquote() << QObject::tr("Please buld tree first.");
        return 0;
    }
    else{
        string player1RangeStr = range1.toStdString();
        string player2RangeStr = range2.toStdString();

        vector<string> board_str_arr = string_split(board.toStdString(),',');
        vector<int> initialBoard;
        for(string one_board_str:board_str_arr){
            initialBoard.push_back(Card::strCard2int(one_board_str));
        }

        vector<PrivateCards> range1 = PrivateRangeConverter::rangeStr2Cards(player1RangeStr,initialBoard);
        vector<PrivateCards> range2 = PrivateRangeConverter::rangeStr2Cards(player2RangeStr,initialBoard);
        return this->game_tree->estimate_tree_memory(this->deck.getCards().size() - initialBoard.size(),range1.size(),range2.size());
    }
}
```