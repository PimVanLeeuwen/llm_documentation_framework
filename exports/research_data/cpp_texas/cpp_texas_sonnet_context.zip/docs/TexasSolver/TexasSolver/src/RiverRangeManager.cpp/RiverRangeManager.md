`RiverRangeManager`: The function of `RiverRangeManager` is to initialize the RiverRangeManager object with a hand evaluator and create a mutex for thread-safe operations.

**Parameters**:
`shared_ptr<Compairer> handEvaluator`: A shared pointer to a Compairer object used for evaluating hands in poker.

**Code Description**: This constructor initializes a RiverRangeManager object. It takes a shared pointer to a Compairer object as a parameter, which is likely used for evaluating poker hands. The constructor moves the passed handEvaluator to the class member variable, ensuring ownership transfer. Additionally, it creates a new shared pointer to a std::mutex object, which is assigned to the maplock member variable. This mutex is likely used to ensure thread-safe access to shared resources within the RiverRangeManager class.\\
## Code: 
```
RiverRangeManager::RiverRangeManager(shared_ptr<Compairer> handEvaluator) {
    this->handEvaluator = std::move(handEvaluator);
    this->maplock = std::make_shared<std::mutex>();
}
```