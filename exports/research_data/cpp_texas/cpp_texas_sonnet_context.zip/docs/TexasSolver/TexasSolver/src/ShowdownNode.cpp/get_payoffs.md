`get_payoffs`: The function of `get_payoffs` is to return the appropriate payoffs based on the showdown result and the winner.

**Parameters**:
`ShowdownNode::ShowDownResult result`: Indicates whether the showdown resulted in a tie or not.
`int winner`: The index of the winning player, or -1 if there's a tie.

**Code Description**: This method determines and returns the payoffs for a poker showdown. It first checks the `result` parameter. If it's `ShowDownResult::NOTTIE`, it ensures the `winner` is not -1 and returns the payoffs for the winning player from the `player_payoffs` vector. If the result is a tie, it verifies that `winner` is -1 and returns the `tie_payoffs`. The function throws runtime errors if there are inconsistencies between the `result` and `winner` parameters. The payoffs are returned as a vector of doubles, representing the winnings or losses for each player in the showdown.\\
## Code: 
```
vector<double> ShowdownNode::get_payoffs(ShowdownNode::ShowDownResult result, int winner) {
    if(result == ShowDownResult::NOTTIE){
        if(winner == -1) throw runtime_error("winner == -1 in tie");
        vector<double> retval = player_payoffs[winner];
        return retval;
    }else{
        // if the showdown is a tie
        if(winner != -1) throw runtime_error("winner != -1 in not tie");
        return this->tie_payoffs;
    }
}
```