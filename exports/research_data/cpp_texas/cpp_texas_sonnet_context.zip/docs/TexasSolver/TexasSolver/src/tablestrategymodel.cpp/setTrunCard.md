`setTurnCard`: The function of `setTurnCard` is to set the turn card for the table strategy model.

**Parameters**:
`Card turn_card`: The card to be set as the turn card.

**Code Description**: This method is a simple setter function for the `TableStrategyModel` class. It takes a `Card` object as an argument and assigns it to the `turn_card` member variable of the class. This allows the table strategy model to keep track of the current turn card, which is likely an important piece of information for the poker game strategy being modeled.\\
## Code: 
```
void TableStrategyModel::setTrunCard(Card turn_card){
    this->turn_card = turn_card;
}
```