`data`: The function of `data` is to retrieve and return data for a specific cell in the model.

**Parameters**:
`const QModelIndex &index`: Specifies the row and column of the cell for which data is requested.
`int role`: Determines the type of data to be returned (e.g., display role, edit role).

**Code Description**: This method implements the data() function required by Qt's model/view framework for the RoughStrategyViewerModel class. It retrieves data for a specific cell in the model based on the provided index. The function first checks if the requested column is within the range of the total_strategy vector. If it is, it accesses the strategy data for that column and returns the second float value of the strategy pair as a QString. If the column is out of range, it returns the string "Rough Strategy". This method is crucial for populating the view with the appropriate data from the model.\\
## Code: 
```
QVariant RoughStrategyViewerModel::data(const QModelIndex &index, int role) const
{
    std::size_t col = index.column();
    if(col < this->tableStrategyModel->total_strategy.size()){
        pair<GameActions,pair<float,float>> one_strategy = this->tableStrategyModel->total_strategy[col];
        return QString::number(one_strategy.second.second);
    }else{
        return "Rough Strategy";
    }
}
```