`get_solver`: The function of `get_solver` is to return the appropriate PokerSolver object based on the current game mode.

**Code Description**: This method is part of the QSolverJob class and serves as a selector for the correct PokerSolver instance. It uses a conditional statement to check the value of the 'mode' member variable. If the mode is set to HOLDEM, it returns a pointer to the 'ps_holdem' object. If the mode is SHORTDECK, it returns a pointer to the 'ps_shortdeck' object. For any other unrecognized mode, it throws a runtime_error with the message "unknown mode in get_solver". This design allows the class to manage different types of poker solvers and provide the appropriate one based on the current game mode, enhancing flexibility and modularity in the codebase.\\
## Code: 
```
PokerSolver* QSolverJob::get_solver(){
    if(this->mode == Mode::HOLDEM){
        return &this->ps_holdem;
    }else if(this->mode == Mode::SHORTDECK){
        return &this->ps_shortdeck;
    }else throw runtime_error("unknown mode in get_solver");
}
```