`getGameTree`: The function of `getGameTree` is to return a constant reference to the game tree.

**Code Description**: This method is a simple getter function that returns a constant reference to a shared pointer of a GameTree object. The `const` qualifier at the end of the function signature ensures that this method doesn't modify the object's state. The returned game tree is stored as a member variable named `game_tree` in the PokerSolver class. By returning a reference to a shared pointer, the method allows access to the game tree without copying it, while the shared pointer ensures safe memory management.\\
## Code: 
```
const shared_ptr<GameTree> &PokerSolver::getGameTree() const {
    return game_tree;
}
```