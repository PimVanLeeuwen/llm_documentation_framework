`getActions`: The function of `getActions` is to return the vector of GameActions stored in the ActionNode object.

**Code Description**: This method is a simple getter function that returns a reference to the private member variable `actions` of the ActionNode class. The `actions` variable is a vector containing GameActions objects. By returning a reference, the method allows direct access to the stored actions without creating a copy, which can be more efficient for large collections. This function is likely used to retrieve the available game actions associated with a particular node in a game tree or decision-making structure.\\
## Code: 
```
vector<GameActions>& ActionNode::getActions() {
    return this->actions;
}
```