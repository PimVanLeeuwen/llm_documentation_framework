`PrivateCards`: The function of `PrivateCards` is to initialize a PrivateCards object with two cards and their associated weight.

**Parameters**:
`int card1`: The first card in the private hand
`int card2`: The second card in the private hand
`float weight`: The weight associated with this private hand

**Code Description**: This constructor initializes a PrivateCards object with the given cards and weight. It sets the card1 and card2 members to the input values and assigns the weight. The relative_prob is initialized to 0. A vector card_vec is created containing both cards. A hash_code is generated based on the card values, ensuring consistency regardless of card order. Finally, it calls Card::boardInts2long to convert the card vector into a 64-bit integer representation stored in board_long.\\
## Code: 
```
PrivateCards::PrivateCards(int card1, int card2, float weight) {
    this->card1 = card1;
    this->card2 = card2;
    this->weight = weight;
    this->relative_prob = 0;
    this->card_vec = vector<int>{this->card1,this->card2};
    if (card1 > card2){
        this->hash_code = card1 * 52 + card2;
    }else{
        this->hash_code = card2 * 52 + card1;
    }
    this->board_long = Card::boardInts2long(this->card_vec);
}
```