`DetailViewerModel`: The function of `DetailViewerModel` is to initialize a custom model for displaying detailed information in a Qt application.

**Parameters**:
`TableStrategyModel* tableStrategyModel`: A pointer to a TableStrategyModel object that this DetailViewerModel will be associated with.
`QObject *parent`: The parent QObject for memory management purposes, following Qt's parent-child ownership model.

**Code Description**: This constructor initializes a DetailViewerModel object, which is derived from QAbstractItemModel. It sets up the basic structure of the model by assigning the provided TableStrategyModel pointer to a member variable, and initializing the number of columns and rows to 4 and 3 respectively. The constructor uses the initialization list to call the base class constructor with the provided parent object.\\
## Code: 
```
DetailViewerModel::DetailViewerModel(TableStrategyModel* tableStrategyModel, QObject *parent):QAbstractItemModel(parent){
    this->tableStrategyModel = tableStrategyModel;
    this->columns = 4;
    this->rows = 3;
}
```