`rowCount`: The function of `rowCount` is to return the number of ranks in the deck.

**Parameters**:
`const QModelIndex &parent`: An unused parameter representing the parent model index.

**Code Description**: This method is part of the TableStrategyModel class and implements the rowCount function required by Qt's model/view framework. It retrieves the solver object from the qSolverJob member, accesses the deck associated with the solver, and returns the size of the ranks vector in the deck. This count represents the number of distinct card ranks in the poker deck being used, which determines the number of rows in the table model.\\
## Code: 
```
int TableStrategyModel::rowCount(const QModelIndex &parent) const
{
    return this->qSolverJob->get_solver()->get_deck()->getRanks().size();
}
```