`pokerActionToString`: The function of `pokerActionToString` is to convert a PokerActions enum value to its corresponding string representation.

**Parameters**:
`GameTreeNode::PokerActions pokerActions`: An enum value representing a poker action.

**Code Description**: This method uses a switch statement to match the input `pokerActions` enum value with its corresponding string representation. It handles seven specific poker actions: BEGIN, ROUNDBEGIN, BET, RAISE, CHECK, FOLD, and CALL. For each case, it returns the action name as a string. If the input doesn't match any of these cases, the function throws a runtime_error with the message "PokerActions not found". This ensures that all possible enum values are accounted for and provides error handling for unexpected inputs.\\
## Code: 
```
string GameActions::pokerActionToString(GameTreeNode::PokerActions pokerActions) {
    switch (pokerActions)
    {
        case GameTreeNode::PokerActions::BEGIN :   return "BEGIN";
        case GameTreeNode::PokerActions::ROUNDBEGIN :   return "ROUNDBEGIN";
        case GameTreeNode::PokerActions::BET :   return "BET";
        case GameTreeNode::PokerActions::RAISE :   return "RAISE";
        case GameTreeNode::PokerActions::CHECK :   return "CHECK";
        case GameTreeNode::PokerActions::FOLD :   return "FOLD";
        case GameTreeNode::PokerActions::CALL :   return "CALL";
        default:{
            throw runtime_error("PokerActions not found");
        }
    }
}
```