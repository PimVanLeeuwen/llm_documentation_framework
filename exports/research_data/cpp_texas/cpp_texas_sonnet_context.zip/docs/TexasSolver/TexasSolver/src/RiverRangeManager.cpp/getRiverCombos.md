`getRiverCombos`: The function of `getRiverCombos` is to retrieve river combinations for a specific player and board state.

**Parameters**:
`int player`: The identifier of the player for whom river combinations are being retrieved.
`const vector<PrivateCards> &riverCombos`: A vector containing possible private card combinations for the river.
`const vector<int> &board`: A vector representing the community cards on the board.

**Code Description**: This method serves as an overload for another `getRiverCombos` function, providing a convenient way to convert the board representation from a vector of integers to a 64-bit long integer. It first calls `Card::boardInts2long(board)` to convert the `board` vector into a 64-bit integer representation (`board_long`). Then, it calls another version of `getRiverCombos` with the same `player` and `riverCombos` parameters, but using the converted `board_long` instead of the original `board` vector. This allows for consistent internal representation and potentially more efficient processing of the board state in subsequent operations.\\
## Code: 
```
const vector<RiverCombs> &
RiverRangeManager::getRiverCombos(int player, const vector<PrivateCards> &riverCombos, const vector<int> &board) {
    uint64_t board_long = Card::boardInts2long(board);
    return this->getRiverCombos(player,riverCombos,board_long);
}
```