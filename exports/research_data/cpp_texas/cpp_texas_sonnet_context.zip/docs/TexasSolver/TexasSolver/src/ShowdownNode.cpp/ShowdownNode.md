`ShowdownNode`: The function of `ShowdownNode` is to initialize a ShowdownNode object, which represents the final state of a poker game where players reveal their hands.

**Parameters**:
`vector<double> tie_payoffs`: A vector containing payoff values for tie situations.
`vector<vector<double>> player_payoffs`: A 2D vector containing payoff values for each player in different scenarios.
`GameTreeNode::GameRound round`: Enum value representing the current round of the game.
`double pot`: The total amount of money in the pot.
`shared_ptr<GameTreeNode>parent`: A shared pointer to the parent node in the game tree.

**Code Description**: This constructor initializes a ShowdownNode object, which is derived from GameTreeNode. It takes in payoff information, game round, pot size, and a pointer to the parent node. The constructor first calls the base class constructor (GameTreeNode) with the round, pot, and parent parameters. Then, it moves the tie_payoffs and player_payoffs vectors into the object's member variables using std::move. This approach ensures efficient transfer of ownership for these potentially large data structures, avoiding unnecessary copying.\\
## Code: 
```
ShowdownNode::ShowdownNode(vector<double> tie_payoffs, vector<vector<double>> player_payoffs,
                           GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode>parent):
                           GameTreeNode(round,pot,std::move(parent)) {
    this->tie_payoffs = std::move(tie_payoffs);
    this->player_payoffs = std::move(player_payoffs);
}
```