`is_flush`: The function of `is_flush` is to determine if a hand of cards is a flush.

**Parameters**:
`uint64_t hash`: A 64-bit integer representing the encoded card information.

**Code Description**: This function checks if the given hand is a flush by examining the suit distribution of the cards. It uses bitwise operations to check the presence of cards in each of the four suits (represented by SUIT_X_MASK constants). The function counts the number of suits present in the hand. If at any point more than one suit is detected, it immediately returns false. A flush occurs when all cards are of the same suit, so the function returns true only if exactly one suit is present in the hand. The implementation is optimized for early termination, checking suits sequentially and returning false as soon as a second suit is detected.\\
## Code: 
```
bool is_flush(uint64_t hash) {
    int cnt = (hash & SUIT_0_MASK) != 0;
    cnt += (hash & SUIT_1_MASK) != 0;
    if (cnt > 1) return false;
    cnt += (hash & SUIT_2_MASK) != 0;
    if (cnt > 1) return false;
    cnt += (hash & SUIT_3_MASK) != 0;
    return cnt > 1 ? false : true;
}
```