`DiscountedCfrTrainableSF`: The function of `DiscountedCfrTrainableSF` is to initialize a discounted counterfactual regret minimization (CFR) trainable object for a specific game state in Texas Hold'em poker.

**Parameters**:
`vector<PrivateCards> *privateCards`: A pointer to a vector containing the possible private card combinations for the current game state.
`ActionNode &actionNode`: A reference to the current action node in the game tree.

**Code Description**: This constructor initializes a `DiscountedCfrTrainableSF` object with the given private cards and action node. It sets up the necessary data structures for CFR training:

1. Stores the pointer to the private cards vector.
2. Determines the number of possible actions from the action node's children.
3. Calculates the number of possible private card combinations.
4. Initializes vectors for expected values (evs), positive regrets (r_plus), and cumulative positive regrets (cum_r_plus) with sizes based on the number of actions and card combinations.

These data structures are essential for implementing the discounted CFR algorithm, which is used to compute optimal strategies in imperfect information games like poker. The initialization prepares the object for subsequent training iterations and strategy updates.\\
## Code: 
```
DiscountedCfrTrainableSF::DiscountedCfrTrainableSF(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();
    this->evs = vector<EvsStorage>(this->action_number * this->card_number, (EvsStorage) 0.0);
    this->r_plus = vector<RplusStorage>(this->action_number * this->card_number, (RplusStorage) 0.0);
    this->cum_r_plus = vector<CumRplusStorage>(this->action_number * this->card_number, (CumRplusStorage) 0.0);
}
```