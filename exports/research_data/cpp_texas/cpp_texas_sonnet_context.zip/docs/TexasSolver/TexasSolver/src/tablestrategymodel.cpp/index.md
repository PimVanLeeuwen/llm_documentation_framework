`index`: The function of `index` is to return a QModelIndex that represents the item at the specified row and column within the model, or an invalid QModelIndex if the index does not exist.

**Parameters**:
`int row`: The row number of the item in the model.
`int column`: The column number of the item in the model.
`const QModelIndex &parent`: A reference to the parent QModelIndex of the item, which is used to determine the item's position within its parent's child items list.

**Code Description**: This function checks if the specified index exists using the `hasIndex` method. If it does not exist, an invalid QModelIndex is returned. Otherwise, a new QModelIndex is created with the specified row and column values, and a null pointer as the internal data value.\\
## Code: 
```
QModelIndex TableStrategyModel::index(int row, int column, const QModelIndex &parent) const
{
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    return createIndex(row, column, nullptr);
}
```