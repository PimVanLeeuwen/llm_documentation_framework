`toString`: The function of `toString` is to convert a GameAction object to its string representation.

**Code Description**: This method returns a string representation of a GameAction object. If the `amount` field is -1, it simply returns the string representation of the action by calling `pokerActionToString(this->action)`. Otherwise, it concatenates the string representation of the action with the amount, separated by a space. The `pokerActionToString` method is called to convert the action enum to its string equivalent. This method provides a human-readable format for GameAction objects, which is useful for logging, debugging, or displaying game actions to users.\\
## Code: 
```
string GameActions::toString() {
    if(this->amount == -1) {
        return this->pokerActionToString(this->action);
    }else{
        return this->pokerActionToString(this->action) + " " + to_string(amount);
    }
}
```