`isDonk`: The function of `isDonk` is to return the value of the `donk` member variable.

**Code Description**: This method is a simple getter function for the `ChanceNode` class. It returns the boolean value stored in the `donk` member variable. The `donk` variable likely represents whether a particular action or state in the Texas Hold'em poker game is considered a "donk bet" or not. A donk bet is a poker term for when a player who was not the aggressor in the previous betting round makes the first bet in the current round. The method allows other parts of the program to check this state without directly accessing the private member variable.\\
## Code: 
```
bool ChanceNode::isDonk(){
    return this->donk;
}
```