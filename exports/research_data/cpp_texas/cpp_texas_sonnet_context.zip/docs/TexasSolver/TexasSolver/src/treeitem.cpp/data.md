`data`: The function of `data` is to return a QVariant representing the node's data in a game tree structure.

**Code Description**: This method retrieves and formats information about a node in a game tree. It first checks if the node is the root (no parent), returning a string indicating the beginning of a round. For nodes with parents, it differentiates between action nodes and chance nodes. For action nodes, it identifies the player (IP or OOP) and the action taken, including any bet amount. For chance nodes, it returns a string describing the dealing of community cards (flop, turn, or river). The method uses various helper functions and accesses node properties to construct the appropriate string representation. If the node type is unrecognized, it returns "NodeError". The returned QVariant allows for flexible data representation in a tree model structure.\\
## Code: 
```
QVariant TreeItem::data() const
{
    shared_ptr<GameTreeNode> parentNode = this->m_treedata.lock()->getParent();
    shared_ptr<GameTreeNode> currentNode = this->m_treedata.lock();
    if(parentNode == nullptr){
        return TreeItem::get_round_str(currentNode->getRound()) + QObject::tr(" begin");
    }
    if(parentNode->getType() == GameTreeNode::GameTreeNodeType::ACTION){
        shared_ptr<ActionNode> parentActionNode = dynamic_pointer_cast<ActionNode>(parentNode);
        vector<GameActions>& actions = parentActionNode->getActions();
        vector<shared_ptr<GameTreeNode>>& childrens = parentActionNode->getChildrens();
        for(std::size_t i = 0;i < childrens.size();i ++){
            if(childrens[i] == currentNode){
                float amount = childrens[i]->getPot() - parentNode->getPot();
                return (parentActionNode->getPlayer() == 0 ? QObject::tr("IP "):QObject::tr("OOP ")) + \
                       TreeItem::get_game_action_str(actions[i].getAction(),actions[i].getAmount());
            }
        }
    }if(parentNode->getType() == GameTreeNode::GameTreeNodeType::CHANCE){
        shared_ptr<ChanceNode> chanceNode = dynamic_pointer_cast<ChanceNode>(parentNode);
        if(chanceNode->getRound() == GameTreeNode::GameRound::FLOP){
            return QObject::tr("DEAL FLOP CARD");
        }
        else if(chanceNode->getRound() == GameTreeNode::GameRound::TURN){
            return QObject::tr("DEAL TURN CARD");
        }
        else if(chanceNode->getRound() == GameTreeNode::GameRound::RIVER){
            return QObject::tr("DEAL RIVER CARD");
        }else throw runtime_error("round not recognized");
    }
    return "NodeError";
}
```