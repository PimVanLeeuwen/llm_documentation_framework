`getReachProbs`: The function of `getReachProbs` is to calculate and return the reach probabilities for each player's private cards.

**Code Description**: This method creates a 2D vector to store reach probabilities for all players. It iterates through each player, retrieves their private cards using the `playerHands` method, and then assigns the weight of each private card combination as the reach probability. The resulting vector contains reach probabilities for each player's possible hand combinations, which is then returned. This information is crucial for probability calculations in poker strategy algorithms.\\
## Code: 
```
vector<vector<float>> PCfrSolver::getReachProbs() {
    vector<vector<float>> retval(this->player_number);
    for(int player = 0;player < this->player_number;player ++){
        vector<PrivateCards> player_cards = this->playerHands(player);
        vector<float> reach_prob(player_cards.size());
        for(std::size_t i = 0;i < player_cards.size();i ++){
            reach_prob[i] = player_cards[i].weight;
        }
        retval[player] = reach_prob;
    }
    return retval;
}
```