`get_round_str`: The function of `get_round_str` is to convert a game round enumeration to its corresponding string representation.

**Parameters**:
`GameTreeNode::GameRound round`: An enumeration value representing the current game round (FLOP, TURN, or RIVER).

**Code Description**: This method takes a `GameTreeNode::GameRound` enumeration as input and returns a `QString` representation of the game round. It uses a series of if-else statements to check the input round and return the appropriate translated string. For FLOP, it returns the translated string "FLOP". For TURN, it returns the translated string "TURN". For RIVER, it returns the translated string "RIVER". If the input round doesn't match any of these cases, the function throws a runtime_error with a message indicating that the round is not recognized and must be one of flop, turn, or river. The function uses `QObject::tr()` for string translation, making it suitable for internationalization.\\
## Code: 
```
QString TreeItem::get_round_str(GameTreeNode::GameRound round) const{
    if(round == GameTreeNode::GameRound::FLOP){
        return QObject::tr("FLOP");
    }
    else if(round == GameTreeNode::GameRound::TURN){
        return QObject::tr("TURN");
    }
    else if(round == GameTreeNode::GameRound::RIVER){
        return QObject::tr("RIVER");
    }
    else throw runtime_error("round not recognized, must be in flop,turn,river");
}
```