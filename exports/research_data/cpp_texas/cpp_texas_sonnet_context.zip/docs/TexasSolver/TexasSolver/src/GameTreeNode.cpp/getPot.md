`getPot`: The function of `getPot` is to return the current pot value of the game.

**Code Description**: This is a simple getter method for the `GameTreeNode` class. It returns the value of the private member variable `pot`, which represents the current amount of money or chips in the game's pot. The method is declared as `double`, indicating that the pot value is stored and returned as a floating-point number. This allows for precise representation of monetary values, including cents or fractional amounts. The method doesn't modify any data; it only provides read access to the pot value.\\
## Code: 
```
double GameTreeNode::getPot() {
    return this->pot;
}
```