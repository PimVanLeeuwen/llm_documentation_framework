`GameActions`: The function of `GameActions` is to construct a GameActions object with specified poker action and amount.

**Parameters**:
`GameTreeNode::PokerActions action`: The type of poker action to be performed (e.g., RAISE, BET, CHECK, FOLD, CALL).
`double amount`: The amount associated with the action, used for RAISE or BET actions.

**Code Description**: This constructor initializes a GameActions object with the given poker action and amount. It performs validation to ensure that the amount is consistent with the action type. For RAISE or BET actions, the amount must not be -1. For other actions (CHECK, FOLD, CALL), the amount must be -1. If these conditions are not met, the constructor throws a runtime_error with a formatted error message. The action and amount are then stored as member variables of the GameActions object.\\
## Code: 
```
GameActions::GameActions(GameTreeNode::PokerActions action, double amount) {
    this->action = action;
    if (action == GameTreeNode::PokerActions::RAISE || action == GameTreeNode::PokerActions::BET ) {
        if (amount == -1) throw runtime_error(tfm::format("raise/bet amount should not be -1, find %s",amount));
    } else {
        if (amount != -1) throw runtime_error(tfm::format("check/fold/call amount should be -1, find %s",amount));
    }
    this->amount = amount;
}
```