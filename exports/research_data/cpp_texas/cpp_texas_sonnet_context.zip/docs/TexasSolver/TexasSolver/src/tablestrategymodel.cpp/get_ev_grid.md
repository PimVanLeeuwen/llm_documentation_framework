`get_ev_grid`: The function of `get_ev_grid` is to calculate and return the expected value (EV) grid for a specific position in the strategy table.

**Parameters**:
`int i`: Row index in the strategy table
`int j`: Column index in the strategy table

**Code Description**: This method calculates the expected values for a specific position (i, j) in the strategy table. It first checks if the necessary data structures (treeItem and current_evs) are available. If not, it returns an empty vector. The function then retrieves the game tree node associated with the current position. If the node is an ActionNode, it processes the strategies and expected values for each action. It iterates through the strategy table entries for the given position, calculating the weighted average of expected values based on the current strategy. The function handles potential size mismatches between game actions and strategies, throwing an error if inconsistencies are found. Finally, it returns a vector of calculated expected values for the specified position in the strategy table. If the node is not an ActionNode, an empty vector is returned.\\
## Code: 
```
const vector<float> TableStrategyModel::get_ev_grid(int i,int j)const{
    vector<float> ret_evs;
    if(this->treeItem == NULL || this->current_evs.empty())return ret_evs;

    int strategy_number = this->ui_strategy_table[i][j].size();

    shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();

    if(node->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);

        vector<GameActions>& gameActions = actionNode->getActions();

//        vector<float> strategies;

//        if(this->ui_strategy_table[i][j].size() > 0){
//            strategies = vector<float>(gameActions.size());
//            std::fill(strategies.begin(), strategies.end(), 0.);
//        }
        for(std::pair<int,int> index:this->ui_strategy_table[i][j]){
            int index1 = index.first;
            int index2 = index.second;
            const vector<float>& one_strategy = this->current_strategy[index1][index2];
            const vector<float>& one_ev = this->current_evs[index1][index2];
            if(one_ev.size() != one_strategy.size()) return vector<float>();

            if(gameActions.size() != one_strategy.size()){
                cout << "index: " << index1 << " " << index2 << endl;
                cout << "i,j: " << i << " " << j << endl;
                cout << "size not match between gameAction and stragegy: " << gameActions.size() << " " << one_strategy.size() << endl;
                throw runtime_error("size not match between gameAction and stragegy");
            }
            float one_ev_float = 0;
            for(std::size_t indi = 0;indi < one_strategy.size();indi ++){
                one_ev_float += one_strategy[indi] * one_ev[indi];
            }
            ret_evs.push_back(one_ev_float);
        }

        return ret_evs;
    }else{
        return ret_evs;
    }
}
```