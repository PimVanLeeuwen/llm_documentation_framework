`onchanged`: The function of `onchanged` is to notify the view that the horizontal header data has changed for all columns.

**Code Description**: This method is a slot in the RoughStrategyViewerModel class that emits a signal to indicate that the horizontal header data has been modified. It calls the `headerDataChanged` signal with parameters specifying that the change affects all columns in the horizontal header. The method uses `Qt::Horizontal` to indicate the horizontal orientation and passes 0 as the first column and `columnCount()` as the last column, effectively covering the entire range of columns in the model. This signal is typically used to prompt the associated view to update its display of the header data.\\
## Code: 
```
void RoughStrategyViewerModel::onchanged(){
    emit headerDataChanged(Qt::Horizontal, 0 , columnCount());
}
```