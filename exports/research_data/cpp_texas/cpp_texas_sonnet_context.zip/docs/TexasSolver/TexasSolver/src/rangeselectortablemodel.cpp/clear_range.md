`clear_range`: The function of `clear_range` is to reset all values in the `grids_float` 2D array to zero.

**Code Description**: This method iterates through a 2D array called `grids_float` using nested loops. The outer loop runs from 0 to the size of `ranklist` minus 1, and the inner loop does the same. For each element in the 2D array, it sets the value to 0. This effectively clears or resets all the values in the `grids_float` array to zero, regardless of their previous values. The size of the array is determined by the size of the `ranklist` vector.\\
## Code: 
```
void RangeSelectorTableModel::clear_range(){
    for(int i = 0;i < this->ranklist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_float[i][j] = 0;
        }
    }
}
```