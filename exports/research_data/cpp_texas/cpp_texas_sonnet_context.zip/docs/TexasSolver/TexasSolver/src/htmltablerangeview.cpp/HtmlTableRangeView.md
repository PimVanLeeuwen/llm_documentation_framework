`HtmlTableRangeView`: The function of `HtmlTableRangeView` is to initialize a custom table view with range selection capabilities.

**Parameters**:
`QWidget *parent`: The parent widget for this view, used in the base class constructor.

**Code Description**: This constructor initializes an `HtmlTableRangeView` object, which is derived from `HtmlTableView`. It sets up event filtering for the viewport, enables mouse tracking, and initializes mouse tracking-related variables. The constructor installs an event filter on the viewport, allowing the object to intercept and process events before they reach the viewport. Mouse tracking is enabled, which means the widget will receive mouse move events even when no buttons are pressed. The `mouseTracker` struct is initialized with default values: tracking is set to false, and the pressed row and column indices are set to -1, indicating no cell is currently selected.\\
## Code: 
```
HtmlTableRangeView::HtmlTableRangeView(QWidget *parent):
HtmlTableView(parent)
{
    viewport()->installEventFilter(this);
    setMouseTracking(true);
    mouseTracker.tracking = false;
    mouseTracker.pressed_i = -1;
    mouseTracker.pressed_j = -1;
}
```