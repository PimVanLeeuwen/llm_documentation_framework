`RoughStrategyViewerModel`: The function of `RoughStrategyViewerModel` is to initialize a new RoughStrategyViewerModel object.

**Parameters**:
`TableStrategyModel* tableStrategyModel`: A pointer to a TableStrategyModel object that this viewer model will use.
`QObject *parent`: The parent QObject for memory management purposes, following Qt's parent-child system.

**Code Description**: This is the constructor for the RoughStrategyViewerModel class. It initializes a new instance of the class by calling the base class constructor QAbstractItemModel with the provided parent object. It then stores the passed TableStrategyModel pointer as a member variable. This setup allows the RoughStrategyViewerModel to interact with the TableStrategyModel while providing a custom view or interface for it, likely for displaying or manipulating strategy data in a specific way.\\
## Code: 
```
RoughStrategyViewerModel::RoughStrategyViewerModel(TableStrategyModel* tableStrategyModel, QObject *parent):QAbstractItemModel(parent){
    this->tableStrategyModel = tableStrategyModel;
}
```