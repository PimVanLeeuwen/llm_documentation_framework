`set_niter`: The function of `set_niter` is to set the total number of iterations for a progress bar.

**Parameters**:
`int niter`: The number of iterations to set for the progress bar.

**Code Description**: This method is part of the `progressbar` class and is responsible for setting the total number of iterations for the progress bar. It first checks if the input `niter` is valid (greater than zero). If `niter` is zero or negative, it throws an `std::invalid_argument` exception with an error message. If the input is valid, it assigns the value of `niter` to the class member variable `n_cycles`, which presumably represents the total number of iterations or cycles for the progress bar. The function doesn't return any value (void).\\
## Code: 
```
void progressbar::set_niter(int niter) {
    if (niter <= 0) throw std::invalid_argument(
                "progressbar::set_niter: number of iterations null or negative");
    n_cycles = niter;
    return;
}
```