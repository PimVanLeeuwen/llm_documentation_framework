`index`: The function of `index` is to return a QModelIndex object that represents the item at the specified row and column within the table model, or an empty QModelIndex if the index does not exist.

**Parameters**:
`int row`: The row number of the item in the table model.
`int column`: The column number of the item in the table model.
`const QModelIndex &parent`: A reference to the parent QModelIndex object, which is used to determine whether the specified row and column are valid indices within the table model.

**Code Description**: This function checks if the specified row and column are valid indices within the table model using the `hasIndex` method. If they are not valid, it returns an empty QModelIndex. Otherwise, it creates a new QModelIndex object with the specified row and column, and returns it.\\
## Code: 
```
QModelIndex BoardSelectorTableModel::index(int row, int column,
          const QModelIndex &parent) const  {
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    return createIndex(row, column, nullptr);
}
```