`DiscountedCfrTrainableHF`: The function of `DiscountedCfrTrainableHF` is to initialize a discounted counterfactual regret minimization (CFR) object for training in a Texas Hold'em poker game.

**Parameters**:
`vector<PrivateCards> *privateCards`: A pointer to a vector of PrivateCards objects, representing the possible private card combinations in the game.
`ActionNode &actionNode`: A reference to an ActionNode object, representing the current node in the game tree.

**Code Description**: This constructor initializes a DiscountedCfrTrainableHF object with the given private cards and action node. It sets up the necessary data structures for the CFR algorithm:

1. Stores the pointer to the privateCards vector.
2. Determines the number of actions (action_number) by getting the size of the action_node's children.
3. Sets the card_number to the size of the privateCards vector.
4. Initializes three vectors with sizes equal to action_number * card_number:
   - evs: Expected values storage, initialized with 0.0.
   - r_plus: Positive regret storage, initialized with 0.0.
   - cum_r_plus: Cumulative positive regret storage, initialized with 0.0.

These data structures are essential for implementing the discounted CFR algorithm, allowing the object to store and update regrets and expected values during the training process.\\
## Code: 
```
DiscountedCfrTrainableHF::DiscountedCfrTrainableHF(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();
    this->evs = vector<EvsStorage>(this->action_number * this->card_number, (EvsStorage) 0.0);
    this->r_plus = vector<RplusStorage>(this->action_number * this->card_number, (RplusStorage) 0.0);
    this->cum_r_plus = vector<CumRplusStorage>(this->action_number * this->card_number, (CumRplusStorage) 0.0);
}
```