`getAverageStrategy`: The function of `getAverageStrategy` is to return the current strategy of the CFR+ algorithm.

**Code Description**: This method is part of the CfrPlusTrainable class and is designed to return the average strategy. However, the main body of the function is commented out, and instead, it simply calls and returns the result of the `getcurrentStrategy()` method. The commented-out code suggests that originally, this method was intended to calculate an average strategy based on cumulative regrets (cum_r_plus and cum_r_plus_sum), but this functionality has been replaced with returning the current strategy. The method doesn't perform any calculations itself and serves as a wrapper for `getcurrentStrategy()`.\\
## Code: 
```
const vector<float> CfrPlusTrainable::getAverageStrategy() {
    /*
    vector<float> retval(this->action_number * this->card_number);
    if(this->cum_r_plus_sum.empty() || this->isAllZeros(this->cum_r_plus_sum)){
        fill(retval.begin(),retval.end(),1.0 / this->action_number);
    }else {
        for (int action_id = 0; action_id < action_number; action_id++) {
            for (int private_id = 0; private_id < this->card_number; private_id++) {
                int index = action_id * this->card_number + private_id;
                if(this->cum_r_plus_sum[private_id] != 0) {
                    retval[index] = this->cum_r_plus[index] / this->cum_r_plus_sum[private_id];
                }else{
                    retval[index] = 1.0 / this->action_number;
                }
            }
        }
    }
    */
    return this->getcurrentStrategy();
}
```