`setRangeText`: The function of `setRangeText` is to parse and set range values based on an input string.

**Parameters**:
`QString input_range`: A string containing range information in a specific format.

**Code Description**: This method processes the input range string to update the internal range representation. It first clears the existing range using `clear_range()`. Then, it splits the input string by commas and processes each range separately. For each range:

1. It splits the range by colon, expecting up to two parts.
2. If the format is incorrect, it logs an error and skips that range.
3. It determines the key(s) for the range, adding 'o' and 's' suffixes if necessary.
4. For each valid key, it retrieves the corresponding grid coordinates from `string2ij`.
5. If a second part exists in the range, it's converted to a float value.
6. The float value is then assigned to the corresponding position in the `grids_float` 2D array.

The method handles both single card ranges and pair ranges, accommodating for suited and offsuit variations. It also includes error checking for invalid formats and skips empty or invalid entries.\\
## Code: 
```
void RangeSelectorTableModel::setRangeText(QString input_range){
    this->clear_range();
    for(QString one_range:input_range.split(",")){
        if(one_range.trimmed() == "")continue;
        QStringList one_range_list = one_range.split(":");

        if(one_range_list.size() > 2 || one_range_list.size() < 1){
            qDebug().noquote() << QString(tr("skipping range %1, format error, range list should contain two part seperate by ':'")).arg(one_range);
        }

        float range_float = 1.0;
        QString key_range = one_range_list[0];
        QStringList keys;
        if(this->string2ij.count(one_range_list[0])){
            keys.append(key_range);
        }else{
            keys.append(key_range + "o");
            keys.append(key_range + "s");
        }

        for(QString one_key: keys){
            if(one_key.count(" ") == one_key.length() || one_key == "")continue;
            if(!this->string2ij.count(one_key)){
                qDebug().noquote() << QString(tr("skipping range %1, format error")).arg(one_range);
                continue;
            }
            pair<int,int> cord = this->string2ij[one_key];
            if(one_range_list.size() > 1)range_float = one_range_list[1].toFloat();
            this->grids_float[cord.first][cord.second] = range_float;
        }
    }
}
```