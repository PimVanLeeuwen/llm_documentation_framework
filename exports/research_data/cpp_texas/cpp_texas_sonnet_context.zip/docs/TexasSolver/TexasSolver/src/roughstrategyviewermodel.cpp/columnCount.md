`columnCount`: The function of `columnCount` is to return the number of columns in the strategy model.

**Parameters**:
`const QModelIndex &parent`: This parameter is unused in the function.

**Code Description**: This method is part of the `RoughStrategyViewerModel` class and implements the `columnCount` function, which is likely overriding a virtual function from a base model class. It returns the size of the `total_strategy` vector from the `tableStrategyModel` object. This size represents the number of columns in the strategy model. The function doesn't use the `parent` parameter, suggesting it doesn't support hierarchical data structures and treats the model as a flat table.\\
## Code: 
```
int RoughStrategyViewerModel::columnCount(const QModelIndex &parent) const
{
    return this->tableStrategyModel->total_strategy.size();
}
```