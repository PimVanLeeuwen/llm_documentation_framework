`getCards`: The function of `getCards` is to return a constant reference to the vector of cards stored in the ChanceNode object.

**Code Description**: This method is a simple getter function that provides read-only access to the private `cards` member variable of the ChanceNode class. It returns a constant reference to a vector of Card objects, ensuring that the caller cannot modify the original vector. The use of a reference return type avoids unnecessary copying of the vector, which can be beneficial for performance, especially if the vector contains many elements.\\
## Code: 
```
const vector<Card>& ChanceNode::getCards() {
    return this->cards;
}
```