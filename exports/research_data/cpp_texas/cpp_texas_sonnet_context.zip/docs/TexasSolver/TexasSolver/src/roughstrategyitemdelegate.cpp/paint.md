`paint`: The function of `paint` is to draw a gray rectangle and then paint the strategy item.

**Parameters**:
- `QPainter *painter`: A pointer to a QPainter object used for drawing.
- `const QStyleOptionViewItem &option`: A reference to a QStyleOptionViewItem object containing information about the item being painted.
- `const QModelIndex &index`: A reference to a QModelIndex object representing the index of the item in a model.

**Code Description**: The function saves the current painter state, fills a rectangle with gray color at the specified position and size, calls the paint_strategy method to draw the strategy item, and then restores the painter state.\\
## Code: 
```
void RoughStrategyItemDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    painter->save();

    QRect rect(option.rect.left(), option.rect.top(),\
             option.rect.width(), option.rect.height());
    QBrush brush(Qt::gray);
    painter->fillRect(rect, brush);

    this->paint_strategy(painter,option,index);

    painter->restore();
}
```