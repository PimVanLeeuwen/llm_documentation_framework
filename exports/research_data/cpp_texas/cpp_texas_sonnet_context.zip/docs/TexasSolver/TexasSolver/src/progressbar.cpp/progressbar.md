`progressbar`: The function of `progressbar` is to initialize a progress bar object.

**Parameters**:
`int n`: The total number of cycles or steps the progress bar will represent.
`bool showbar`: A flag to determine whether the progress bar should be displayed or not.

**Code Description**: This is a constructor for the `progressbar` class. It initializes various member variables of the progress bar object. The `progress` is set to 0, indicating the starting point. `n_cycles` is set to the input parameter `n`, representing the total number of steps. `last_perc` is initialized to 0, likely used to track the last displayed percentage. `do_show_bar` is set to the input `showbar`, determining whether the bar should be visible. `update_is_called` is set to false, possibly used to track if an update method has been called. The constructor also sets default characters for the progress bar appearance: "#" for completed portions, " " (space) for uncompleted portions, "[" for the opening bracket, and "]" for the closing bracket of the progress bar.\\
## Code: 
```
progressbar::progressbar(int n, bool showbar) :
        progress(0),
        n_cycles(n),
        last_perc(0),
        do_show_bar(showbar),
        update_is_called(false),
        done_char("#"),
        todo_char(" "),
        opening_bracket_char("["),
        closing_bracket_char("]") {}
```