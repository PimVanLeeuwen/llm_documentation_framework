`get_game_action_str`: The function of `get_game_action_str` is to convert a poker action and amount into a human-readable string representation.

**Parameters**:
`GameTreeNode::PokerActions action`: An enumeration representing the type of poker action (CHECK, BET, RAISE, FOLD, or CALL).
`float amount`: The betting amount associated with the action (used for BET and RAISE actions).

**Code Description**: This method takes a poker action and an optional amount as input, then returns a QString containing a textual description of the action. It uses a series of if-else statements to check the action type and constructs the appropriate string:

1. For CHECK action, it returns "CHECK".
2. For BET action, it returns "BET" followed by the amount.
3. For RAISE action, it returns "RAISE" followed by the amount.
4. For FOLD action, it returns "FOLD".
5. For CALL action, it returns "CALL".

If an unknown action is provided, the method throws a runtime_error with an error message. The method uses QObject::tr() for internationalization support, allowing the text to be translated into different languages if needed. The amount is converted to a string using QString::number() when applicable.\\
## Code: 
```
QString TreeItem::get_game_action_str(GameTreeNode::PokerActions action,float amount) const{
    if(action == GameTreeNode::PokerActions::CHECK){
        return QObject::tr("CHECK");
    }
    else if(action == GameTreeNode::PokerActions::BET){
        return QObject::tr("BET ") + QString::number(amount);
    }
    else if(action == GameTreeNode::PokerActions::RAISE){
        return QObject::tr("RAISE ") + QString::number(amount);
    }
    else if(action == GameTreeNode::PokerActions::FOLD){
        return QObject::tr("FOLD ");
    }
    else if(action == GameTreeNode::PokerActions::CALL){
        return QObject::tr("CALL");
    }else{
        throw runtime_error("unknown action when converting in get_game_action_str");
    }

}
```