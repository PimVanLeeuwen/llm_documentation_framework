`noDuplicateRange`: The function of `noDuplicateRange` is to filter out duplicate private cards and those that conflict with the given board.

**Parameters**:
`const vector<PrivateCards> &private_range`: A vector of PrivateCards objects representing the initial range of private hands.
`uint64_t board_long`: A 64-bit integer representation of the community cards on the board.

**Code Description**: This method processes a given range of private cards, removing duplicates and hands that conflict with the board. It first creates an empty vector `range_array` to store the filtered results. Then, it uses an unordered map `rangekv` to track unique hands by their hash codes. The function iterates through each PrivateCards object in the input range. If a duplicate hash code is found, it throws a runtime error. Otherwise, it marks the hash code as seen in the map. The method then converts the private cards to a 64-bit long representation using `Card::boardInts2long`. It checks if there's no intersection between the hand and the board using `Card::boardsHasIntercept`. If there's no conflict, the PrivateCards object is added to `range_array`. Finally, the function returns the filtered `range_array`, containing only unique, non-conflicting private hands.\\
## Code: 
```
vector<PrivateCards>
PCfrSolver::noDuplicateRange(const vector<PrivateCards> &private_range, uint64_t board_long) {
    vector<PrivateCards> range_array;
    unordered_map<int,bool> rangekv;
    for(PrivateCards one_range:private_range){
        if(rangekv.find(one_range.hashCode()) != rangekv.end())
            throw runtime_error(tfm::format("duplicated key %s",one_range.toString()));
        rangekv[one_range.hashCode()] = true;
        uint64_t hand_long = Card::boardInts2long(one_range.get_hands());
        if(!Card::boardsHasIntercept(hand_long,board_long)){
            range_array.push_back(one_range);
        }
    }
    return range_array;

}
```