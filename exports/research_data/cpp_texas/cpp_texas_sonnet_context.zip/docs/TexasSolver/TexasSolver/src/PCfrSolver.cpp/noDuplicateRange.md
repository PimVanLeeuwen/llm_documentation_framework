`noDuplicateRange`: The function of `noDuplicateRange` is to remove duplicate private card ranges from the input vector and filter out those that do not intersect with the given board.

**Parameters**:
`const vector<PrivateCards> &private_range`: This parameter is a reference to a vector of PrivateCards objects, which represents the set of private card ranges to be processed.
`uint64_t board_long`: This parameter is a 64-bit unsigned integer representing the poker board.

**Code Description**: The function iterates over each PrivateCards object in the input vector. It checks if the current range has been seen before by looking up its hash code in an unordered map. If it has, the function throws a runtime error indicating a duplicate key. Otherwise, it adds the range to the map and checks if the board intersects with the hand represented by the current range using the `boardsHasIntercept` method from the Card class. If there is no intersection, the range is added to the output vector. The function finally returns the filtered vector of PrivateCards objects.\\
## Code: 
```
vector<PrivateCards>
PCfrSolver::noDuplicateRange(const vector<PrivateCards> &private_range, uint64_t board_long) {
    vector<PrivateCards> range_array;
    unordered_map<int,bool> rangekv;
    for(PrivateCards one_range:private_range){
        if(rangekv.find(one_range.hashCode()) != rangekv.end())
            throw runtime_error(tfm::format("duplicated key %s",one_range.toString()));
        rangekv[one_range.hashCode()] = true;
        uint64_t hand_long = Card::boardInts2long(one_range.get_hands());
        if(!Card::boardsHasIntercept(hand_long,board_long)){
            range_array.push_back(one_range);
        }
    }
    return range_array;

}
```