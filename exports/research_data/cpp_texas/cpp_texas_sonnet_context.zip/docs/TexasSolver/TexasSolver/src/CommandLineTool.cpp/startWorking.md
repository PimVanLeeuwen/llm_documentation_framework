`startWorking`: The function of `startWorking` is to continuously read input from the command line and process each line as a command.

**Code Description**: This method implements a simple command-line interface loop. It uses a while loop that continues as long as there is input available from cin (standard input). For each iteration, it reads a line of input using getline() and stores it in the input_line string variable. The method then calls the processCommand() function, passing the input line as an argument. This allows the program to handle multiple commands in succession, processing each one as it's entered by the user. The loop will continue until there is no more input (e.g., when the user closes the input stream or reaches the end of a file if input is being redirected from a file).\\
## Code: 
```
void CommandLineTool::startWorking() {
    string input_line;
    while(cin) {
        getline(cin, input_line);
        this->processCommand(input_line);
    };
}
```