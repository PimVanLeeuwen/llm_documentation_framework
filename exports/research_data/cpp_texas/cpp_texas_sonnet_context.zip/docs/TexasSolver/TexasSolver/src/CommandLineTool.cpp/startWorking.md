`startWorking`: The function of `startWorking` is to continuously read input from the standard input (cin) and process each line as a command.

**Code Description**: This code implements an infinite loop that reads input lines from the user, processes each line as a command using the `processCommand` method, and continues until the program is terminated. The `processCommand` method is responsible for parsing the input string, updating internal state variables, and performing tasks such as building game trees or training poker solvers based on the parsed command.\\
## Code: 
```
void CommandLineTool::startWorking() {
    string input_line;
    while(cin) {
        getline(cin, input_line);
        this->processCommand(input_line);
    };
}
```