`getRound`: The function of `getRound` is to return the current game round of the GameTreeNode object.

**Code Description**: This method is a simple getter function for the `GameTreeNode` class. It returns the value of the private member variable `round`, which is of type `GameTreeNode::GameRound`. The `GameRound` is likely an enumeration or similar type that represents different stages or rounds in a game of Texas Hold'em poker. By providing this method, other parts of the program can access the current round information of a `GameTreeNode` instance without directly accessing its private members, maintaining encapsulation.\\
## Code: 
```
GameTreeNode::GameRound GameTreeNode::getRound() {
    return this->round;
}
```