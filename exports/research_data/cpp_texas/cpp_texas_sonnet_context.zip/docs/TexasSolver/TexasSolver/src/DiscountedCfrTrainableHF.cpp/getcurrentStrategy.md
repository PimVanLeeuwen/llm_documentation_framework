`getcurrentStrategy`: The function of `getcurrentStrategy` is to return the current strategy vector.

**Code Description**: This method is a simple wrapper that calls and returns the result of `getcurrentStrategyNoCache()`. It doesn't perform any additional operations or modifications to the strategy. The method returns a vector of floats, which represents the current strategy. By using `getcurrentStrategyNoCache()`, it ensures that the most up-to-date strategy is returned without relying on any cached values.\\
## Code: 
```
const vector<float> DiscountedCfrTrainableHF::getcurrentStrategy() {
    return this->getcurrentStrategyNoCache();
}
```