`getRank`: The function of `getRank` is to calculate the minimum rank of a given set of 5 cards in poker.

**Parameters**:\
`vector<Card> cards`: A vector of Card objects, where each Card object represents a card in the poker game.

**Code Description**: 
The code first converts the vector of Card objects into a vector of integers using the `getCardInt()` method. It then calls another instance of the `getRank()` method, passing the vector of integers as an argument. This suggests that the `getRank()` method is overloaded to accept either a vector of Card objects or a vector of integers. The code description implies that the `getRank()` method uses a hash table to quickly look up the rank of each combination of 5 cards and returns the minimum rank found.\\
## Code: 
```
int Dic5Compairer::getRank(vector<Card> cards) {
    vector<int> cards_int(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_int[i] = cards[i].getCardInt();
    }
    return this->getRank(cards_int);
}
```