`getRank`: The function of `getRank` is to convert a vector of Card objects to their integer representations and then calculate their rank.

**Parameters**:
`vector<Card> cards`: A vector containing Card objects representing a hand of cards.

**Code Description**: This method takes a vector of Card objects as input. It creates a new vector of integers with the same size as the input vector. It then iterates through each Card object in the input vector, calling the `getCardInt()` method on each to obtain its integer representation. These integer values are stored in the new vector. Finally, the method calls another overloaded version of `getRank` that takes a vector of integers as input, passing the newly created vector of integer card representations. The result of this call is then returned as the rank of the hand.\\
## Code: 
```
int Dic5Compairer::getRank(vector<Card> cards) {
    vector<int> cards_int(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_int[i] = cards[i].getCardInt();
    }
    return this->getRank(cards_int);
}
```