`build_tree`: The function of `build_tree` is to construct a game tree for either Texas Hold'em or Short Deck poker based on the specified mode.

**Code Description**: This method begins by logging a debug message indicating that tree building has started. It then checks the game mode (HOLDEM or SHORTDECK) and calls the appropriate `build_game_tree` method from either the `ps_holdem` or `ps_shortdeck` object. The `build_game_tree` method is called with several parameters: out-of-position commit, in-position commit, current round, raise limit, small blind, big blind, stack size, game tree builder strategy, and all-in threshold. These parameters are used to construct the game tree according to the specific poker variant and game state. After the tree is built, another debug message is logged to indicate completion. This method is crucial for setting up the game structure that the solver will use for strategy computation.\\
## Code: 
```
void QSolverJob::build_tree(){
    qDebug().noquote() << tr("building tree..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        ps_holdem.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }else if(this->mode == Mode::SHORTDECK){
        ps_shortdeck.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }
    qDebug().noquote() << tr("build tree finished");//.toStdString() << endl;
}
```