`build_tree`: The function of `build_tree` is to build a game tree data structure for Texas Hold'em poker using provided settings and rules.

**Code Description**: This code snippet, located in the `qsolverjob.cpp` file within the `TexasSolver` project, defines a method called `build_tree`. It appears to be part of a larger system responsible for solving poker games. The `build_tree` function takes various parameters such as game mode (Hold'em or Shortdeck), player commitments, current round, raise limit, small and big blinds, stack size, and all-in threshold. Based on the game mode, it calls either the `ps_holdem.build_game_tree` or `ps_shortdeck.build_game_tree` method to construct a game tree data structure. The function logs messages indicating its start and completion using `qDebug`.\\
## Code: 
```
void QSolverJob::build_tree(){
    qDebug().noquote() << tr("building tree..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        ps_holdem.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }else if(this->mode == Mode::SHORTDECK){
        ps_shortdeck.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }
    qDebug().noquote() << tr("build tree finished");//.toStdString() << endl;
}
```