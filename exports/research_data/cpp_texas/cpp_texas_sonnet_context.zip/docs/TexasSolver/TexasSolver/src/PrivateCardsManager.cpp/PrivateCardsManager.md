`PrivateCardsManager`: The function of `PrivateCardsManager` is to initialize the PrivateCardsManager object with player hands, player count, and initial board state.

**Parameters**:
`vector<vector<PrivateCards>> private_cards`: A 2D vector containing private card combinations for each player
`int player_number`: The number of players in the game
`uint64_t initialboard`: The initial board state represented as a 64-bit integer

**Code Description**: This constructor initializes the PrivateCardsManager object with the given parameters. It stores the private cards and player number, then creates a 2D vector `card_player_index` to map private card combinations to player indices. The constructor iterates through each player's private card combinations, calculating their hash codes and storing the corresponding indices in `card_player_index`. This mapping allows for efficient lookup of matching private cards across players. Finally, it stores the initial board state and calls the `setRelativeProbs()` method to calculate relative probabilities for the private cards.\\
## Code: 
```
PrivateCardsManager::PrivateCardsManager(vector<vector<PrivateCards>> private_cards, int player_number,
                                         uint64_t initialboard) {
    this->private_cards = private_cards;
    this->player_number = player_number;
    this->card_player_index = vector<vector<int>>(52 * 52);
    for(int i = 0;i < 52 * 52;i ++){
        this->card_player_index[i] = vector<int>(this->player_number,-1);
    }

    // 用一个二维数组记录每个Private Combo的对应index,方便从一方的手牌找对方的同名卡牌的index
    for(int player_id = 0;player_id < player_number;player_id ++){
        vector<PrivateCards> privateCombos = private_cards[player_id];
        for(std::size_t i = 0;i < privateCombos.size();i ++){
            PrivateCards one_private_combo = privateCombos[i];
            this->card_player_index[one_private_combo.hashCode()][player_id] = i;
        }
    }

    this->initialboard = initialboard;
    this->setRelativeProbs();
}
```