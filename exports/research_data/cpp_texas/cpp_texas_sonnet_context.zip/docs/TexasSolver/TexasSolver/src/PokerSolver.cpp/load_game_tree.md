`load_game_tree`: The function of `load_game_tree` is to load a game tree from a file into the PokerSolver's data structure.

**Parameters**:
`string game_tree_file`: This parameter represents the path or name of the file containing the game tree data.

**Code Description**: 
The `load_game_tree` method creates a shared pointer to a `GameTree` object using the provided file and deck, then assigns this new game tree to the PokerSolver's own game tree member variable.\\
## Code: 
```
void PokerSolver::load_game_tree(string game_tree_file) {
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(game_tree_file,this->deck);
    this->game_tree = game_tree;
}
```