`load_game_tree`: The function of `load_game_tree` is to load a game tree from a file and store it in the PokerSolver object.

**Parameters**:
`string game_tree_file`: The file path of the game tree to be loaded.

**Code Description**: This method creates a new GameTree object using the provided file path and the deck stored in the PokerSolver instance. It then assigns this newly created GameTree to the game_tree member of the PokerSolver object. The GameTree is created as a shared pointer, allowing for efficient memory management and shared ownership of the game tree across different parts of the program.\\
## Code: 
```
void PokerSolver::load_game_tree(string game_tree_file) {
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(game_tree_file,this->deck);
    this->game_tree = game_tree;
}
```