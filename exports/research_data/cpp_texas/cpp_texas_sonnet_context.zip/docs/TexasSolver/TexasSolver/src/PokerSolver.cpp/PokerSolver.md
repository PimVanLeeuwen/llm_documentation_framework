`PokerSolver`: The function of `PokerSolver` is to initialize a PokerSolver object with a deck of cards and a card comparison system.

**Parameters**:
`string ranks`: A comma-separated string of card ranks
`string suits`: A comma-separated string of card suits
`string compairer_file`: The file path for the card comparison data
`int compairer_file_lines`: The number of lines in the comparison data file
`string compairer_file_bin`: The file path for the binary version of the comparison data

**Code Description**: This constructor initializes a PokerSolver object by creating a deck of cards and setting up a card comparison system. It first splits the input `ranks` and `suits` strings into vectors using the `string_split` function. These vectors are then used to create a `Deck` object, which represents the complete set of cards for the game. The constructor also initializes a shared pointer to a `Dic5Compairer` object, which is responsible for comparing and ranking poker hands. The `Dic5Compairer` is created using the provided file paths and line count for the comparison data. This setup allows the PokerSolver to efficiently manage the deck of cards and evaluate poker hands during gameplay or analysis.\\
## Code: 
```
PokerSolver::PokerSolver(string ranks, string suits, string compairer_file,int compairer_file_lines, string compairer_file_bin) {
    vector<string> ranks_vector = string_split(ranks,',');
    vector<string> suits_vector = string_split(suits,',');
    this->deck = Deck(ranks_vector,suits_vector);
    this->compairer = make_shared<Dic5Compairer>(compairer_file,compairer_file_lines,compairer_file_bin);
}
```