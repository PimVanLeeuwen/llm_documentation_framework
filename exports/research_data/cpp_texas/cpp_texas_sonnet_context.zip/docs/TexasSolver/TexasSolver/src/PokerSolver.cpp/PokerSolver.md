`PokerSolver`: The function of `PokerSolver` is to initialize a poker solver object with the given parameters.

**Parameters**:
`string ranks`: This parameter represents the ranks of cards in the deck, separated by commas.
`string suits`: This parameter represents the suits of cards in the deck, separated by commas.
`string compairer_file`: This parameter specifies the file containing the poker hand data to be used for comparison.
`int compairer_file_lines`: This parameter indicates the number of lines in the comparison file.
`string compairer_file_bin`: This parameter represents the binary representation of the comparison file.

**Code Description**: The `PokerSolver` function initializes a deck of cards using the provided ranks and suits, and loads poker hand data from the specified file. It then creates an instance of the `Dic5Compairer` class to perform comparisons based on the loaded data.\\
## Code: 
```
PokerSolver::PokerSolver(string ranks, string suits, string compairer_file,int compairer_file_lines, string compairer_file_bin) {
    vector<string> ranks_vector = string_split(ranks,',');
    vector<string> suits_vector = string_split(suits,',');
    this->deck = Deck(ranks_vector,suits_vector);
    this->compairer = make_shared<Dic5Compairer>(compairer_file,compairer_file_lines,compairer_file_bin);
}
```