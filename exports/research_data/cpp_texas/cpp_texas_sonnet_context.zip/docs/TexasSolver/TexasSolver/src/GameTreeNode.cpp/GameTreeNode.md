`GameTreeNode`: The function of `GameTreeNode` is to initialize a new game tree node with the specified round, pot size, and parent node.

**Parameters**:
`GameTreeNode::GameRound round`: The current round of the game for this node.
`double pot`: The size of the pot at this node in the game tree.
`shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node in the game tree.

**Code Description**: This constructor initializes a new `GameTreeNode` object. It sets the `round` member variable to the provided game round, the `pot` member variable to the given pot size, and the `parent` member variable to the provided parent node using `std::move`. The use of `std::move` suggests that ownership of the parent node is being transferred to this new node. This constructor is likely used to build a tree structure representing different states or decision points in a poker game, with each node containing information about the current game round, pot size, and its relationship to other nodes in the tree.\\
## Code: 
```
GameTreeNode::GameTreeNode(GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent) {
    this->round = round;
    this->pot = pot;
    this->parent = std::move(parent);
}
```