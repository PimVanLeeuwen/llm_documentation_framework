`chanceUtility`: The function of `chanceUtility` is to calculate the utility of chance nodes in a poker game simulation.

**Parameters**:
`int player`: The current player (0 or 1) for whom the utility is being calculated.
`shared_ptr<ChanceNode> node`: A shared pointer to the current chance node in the game tree.
`const vector<float> &reach_probs`: The reach probabilities for both players.
`int iter`: The current iteration number in the simulation.
`uint64_t current_board`: A 64-bit integer representing the current board state.
`int deal`: An identifier for the current deal.

**Code Description**: This method calculates the utility of chance nodes in a Texas Hold'em poker game solver. It handles the randomness of card dealing and evaluates possible outcomes. The function first determines the number of possible card deals based on the current board state. It then initializes a vector to store the chance utility for each possible hand range of the current player.

The method implements a Monte Carlo algorithm (either PUBLIC or another unspecified type) to handle random card selection. For warm-up iterations, it uses a weighted random selection process for cards.

The function then iterates through all possible cards that could be dealt, filtering out invalid cards (those already on the board or not allowed due to color isomorphism). For each valid card, it recursively evaluates the resulting game state by calling the child node's utility function (not shown in this snippet).

The code uses OpenMP for parallel processing, likely to improve performance when evaluating multiple possible card deals. The utility calculations for different card deals are performed concurrently.

Overall, this function is a crucial part of the Counter-Factual Regret Minimization (CFR) algorithm used in poker solvers, handling the chance events (card deals) and their impact on the game's expected utility for each player.\\
## Code: 
```
vector<float>
PCfrSolver::chanceUtility(int player, shared_ptr<ChanceNode> node, const vector<float> &reach_probs, int iter,
                         uint64_t current_board,int deal) {
    vector<Card>& cards = this->deck.getCards();
    //float[] cardWeights = getCardsWeights(player,reach_probs[1 - player],current_board);

    int card_num = node->getCards().size();
    if(card_num % 4 != 0) throw runtime_error("card num cannot round 4");
    // 可能的发牌情况,2代表每个人的holecard是两张
    int possible_deals = node->getCards().size() - Card::long2board(current_board).size() - 2;
    int oppo = 1 - player;

    //vector<float> chance_utility(reach_probs[player].size());
    vector<float> chance_utility = vector<float>(this->ranges[player].size());
    fill(chance_utility.begin(),chance_utility.end(),0);

    int random_deal = 0;
    if(this->monteCarolAlg==MonteCarolAlg::PUBLIC) {
        if (this->round_deal[GameTreeNode::gameRound2int(node->getRound())] == -1) {
            random_deal = random(1, possible_deals + 1 + 2);
            this->round_deal[GameTreeNode::gameRound2int(node->getRound())] = random_deal;
        } else {
            random_deal = this->round_deal[GameTreeNode::gameRound2int(node->getRound())];
        }
    }
    //vector<vector<vector<float>>> arr_new_reach_probs = vector<vector<vector<float>>>(node->getCards().size());

    vector<vector<float>> results(node->getCards().size());
    //fill(results.begin(),results.end(),nullptr);

    vector<float> multiplier;
    if(iter <= this->warmup){
        multiplier = vector<float>(card_num);
        fill(multiplier.begin(), multiplier.end(), 0);
        for (int card_base = 0; card_base < card_num / 4; card_base++) {
            int cardr = std::rand() % 4;
            int card_target = card_base * 4 + cardr;
            int multiplier_num = 0;
            for (int i = 0; i < 4; i++) {
                int i_card = card_base * 4 + i;
                if (i == cardr) {
                    Card *one_card = const_cast<Card *>(&(node->getCards()[i_card]));
                    uint64_t card_long = Card::boardInt2long(
                            one_card->getCardInt());
                    if (!Card::boardsHasIntercept(card_long, current_board)) {
                        multiplier_num += 1;
                    }
                } else {
                    Card *one_card = const_cast<Card *>(&(node->getCards()[i_card]));
                    uint64_t card_long = Card::boardInt2long(
                            one_card->getCardInt());
                    if (!Card::boardsHasIntercept(card_long, current_board)) {
                        multiplier_num += 1;
                    }
                }
            }
            multiplier[card_target] = multiplier_num;
        }
    }

    vector<int> valid_cards;
    valid_cards.reserve(node->getCards().size());

    for(std::size_t card = 0;card < node->getCards().size();card ++) {
        shared_ptr<GameTreeNode> one_child = node->getChildren();
        Card *one_card = const_cast<Card *>(&(node->getCards()[card]));
        uint64_t card_long = Card::boardInt2long(one_card->getCardInt());//Card::boardCards2long(new Card[]{one_card});
        if (Card::boardsHasIntercept(card_long, current_board)) continue;
        if (iter <= this->warmup && multiplier[card] == 0) continue;
        if (this->color_iso_offset[deal][one_card->getCardInt() % 4] < 0) continue;
        valid_cards.push_back(card);
    }

    #pragma omp parallel for schedule(static)
    for
```