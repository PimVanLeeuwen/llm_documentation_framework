`run`: The function of `run` is to execute different tasks based on the current mission type.

**Code Description**: This method is responsible for executing various operations depending on the value of `current_mission`. It uses a series of if-else statements to determine which specific task to perform:

1. If `current_mission` is `MissionType::SOLVING`, it calls the `solving()` method.
2. If `current_mission` is `MissionType::LOADING`, it calls the `loading()` method.
3. If `current_mission` is `MissionType::BUILDTREE`, it calls the `build_tree()` method.
4. If `current_mission` is `MissionType::SAVING`, it calls the `saving()` method.

If the `current_mission` doesn't match any of these types, it throws a runtime error with the message "unsupported mission type".

The entire execution is wrapped in a try-catch block to handle any runtime errors that may occur during the process. If an error is caught, it prints an error message using `qDebug().noquote()`, which likely outputs to a debug console or log.

This structure allows the `QSolverJob` class to perform different operations based on the current state or requirements of the poker solver application, providing a centralized method to manage various tasks related to solving, loading, building game trees, and saving results.\\
## Code: 
```
void QSolverJob::run()
{
    //QDebugStream qout(qDebug().noquote(), this->textEdit);
    try{
        if(this->current_mission == MissionType::SOLVING){
            this->solving();
        }else if(this->current_mission == MissionType::LOADING){
            this->loading();
        }else if(this->current_mission == MissionType::BUILDTREE){
            this->build_tree();
        }else if(this->current_mission == MissionType::SAVING){
            this->saving();
        }else{
            throw runtime_error("unsupported mission type");
        }
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```