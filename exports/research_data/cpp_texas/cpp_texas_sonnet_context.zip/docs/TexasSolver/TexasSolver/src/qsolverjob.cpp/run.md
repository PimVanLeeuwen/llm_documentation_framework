`run`: The function of `run` is to execute a specific mission type based on the current_mission attribute of the QSolverJob object.

**Code Description**: The code in the run method checks the value of the current_mission attribute and calls the corresponding method (solving, loading, build_tree, or saving) if it matches one of the predefined mission types. If the mission type is not recognized, a runtime_error is thrown with an error message indicating that the mission type is unsupported. The code also catches any runtime_errors that occur during execution and prints an error message to the console.\\
## Code: 
```
void QSolverJob::run()
{
    //QDebugStream qout(qDebug().noquote(), this->textEdit);
    try{
        if(this->current_mission == MissionType::SOLVING){
            this->solving();
        }else if(this->current_mission == MissionType::LOADING){
            this->loading();
        }else if(this->current_mission == MissionType::BUILDTREE){
            this->build_tree();
        }else if(this->current_mission == MissionType::SAVING){
            this->saving();
        }else{
            throw runtime_error("unsupported mission type");
        }
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```