`reset`: The function of `reset` is to reinitialize the progress bar to its starting state.

**Code Description**: This method resets the internal state of the progressbar object. It sets the `progress` variable to 0, indicating the progress bar is back at the beginning. The `update_is_called` flag is set to false, suggesting that no updates have been made since the reset. The `last_perc` variable, likely used to track the last displayed percentage, is also set to 0. This method effectively prepares the progress bar for a new tracking session by clearing all previous progress data.\\
## Code: 
```
void progressbar::reset() {
    progress = 0,
            update_is_called = false;
    last_perc = 0;
    return;
}
```