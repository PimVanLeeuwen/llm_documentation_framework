`rowCount`: The function of `rowCount` is to return the number of rows in the model.

**Parameters**:
`const QModelIndex &parent`: A reference to the parent model index, which is not used in this implementation.

**Code Description**: This method is a part of the `BoardSelectorTableModel` class and implements the `rowCount` function required by Qt's model/view framework. It simply returns the size of the `suitlist` member variable, which represents the number of rows in the model. The `parent` parameter is not used in this implementation, suggesting that this model does not have a hierarchical structure.\\
## Code: 
```
int BoardSelectorTableModel::rowCount(const QModelIndex &parent) const {
    return this->suitlist.size();
}
```