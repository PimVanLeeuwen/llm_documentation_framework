`compairRanks`: The function of `compairRanks` is to compare two poker hand ranks and determine their relative strength.

**Parameters**:
`int rank_former`: The rank of the first hand to be compared
`int rank_latter`: The rank of the second hand to be compared

**Code Description**: This method compares two poker hand ranks and returns a `CompairResult` enum value indicating their relative strength. In poker, a lower rank number typically represents a stronger hand. The function first checks if `rank_former` is less than `rank_latter`. If true, it returns `CompairResult::LARGER`, indicating the first hand is stronger. If `rank_former` is greater than `rank_latter`, it returns `CompairResult::SMALLER`, indicating the second hand is stronger. If the ranks are equal, it returns `CompairResult::EQUAL`. The comment suggests that a rank of 0 represents a royal flush, which is the strongest possible hand in poker.\\
## Code: 
```
Compairer::CompairResult Dic5Compairer::compairRanks(int rank_former, int rank_latter) {
    if (rank_former < rank_latter) {
        // rank更小的牌更大，0是同花顺
        return CompairResult::LARGER;
    } else if (rank_former > rank_latter) {
        return CompairResult::SMALLER;
    } else {
        // rank_former == rank_latter
        return CompairResult::EQUAL;
    }
}
```