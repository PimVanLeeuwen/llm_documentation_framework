`gameRound2int`: The function of `gameRound2int` is to convert a GameRound enum value to its corresponding integer representation.

**Parameters**:
`GameTreeNode::GameRound gameRound`: An enum value representing a specific round in a poker game.

**Code Description**: This method takes a GameRound enum value as input and returns an integer based on the game round. It uses a series of if-else statements to check the input against different GameRound values. For PREFLOP, it returns 0; for FLOP, it returns 1; for TURN, it returns 2; and for RIVER, it returns 3. If the input doesn't match any of these rounds, the function throws a runtime_error with the message "round not found". This conversion allows for easier numerical representation and comparison of game rounds in other parts of the program.\\
## Code: 
```
int GameTreeNode::gameRound2int(GameTreeNode::GameRound gameRound) {
    if(gameRound == GameRound::PREFLOP) {
        return 0;
    }else if(gameRound == GameRound::FLOP){
        return 1;
    } else if(gameRound == GameRound::TURN) {
        return 2;
    } else if(gameRound == GameRound::RIVER) {
        return 3;
    }
    throw runtime_error("round not found");
}
```