`noDuplicateRange`: The function of `noDuplicateRange` is to filter out duplicate private card combinations and those that conflict with the given board.

**Parameters**:
`const vector<PrivateCards> &private_range`: A vector of PrivateCards objects representing the initial range of private card combinations.
`uint64_t board_long`: A 64-bit integer representation of the community cards on the board.

**Code Description**: This function processes a given range of private card combinations and removes duplicates and hands that conflict with the board. It first creates an empty vector `range_array` to store the filtered results and an unordered map `rangekv` to track unique hands. The function iterates through each PrivateCards object in the input range. For each hand, it checks if it's already in the `rangekv` map using the `hashCode()` method. If a duplicate is found, it throws a runtime error. Otherwise, it adds the hand to the map. The function then converts the private cards to a 64-bit long representation using `Card::boardInts2long()`. It checks if this hand conflicts with the board using `Card::boardsHasIntercept()`. If there's no conflict, the hand is added to `range_array`. Finally, the function returns the filtered `range_array` containing unique, non-conflicting hands.\\
## Code: 
```
vector<PrivateCards> noDuplicateRange(const vector<PrivateCards> &private_range, uint64_t board_long) {
    vector<PrivateCards> range_array;
    unordered_map<int,bool> rangekv;
    for(PrivateCards one_range:private_range){
        if(rangekv.find(one_range.hashCode()) != rangekv.end())
            throw runtime_error(tfm::format("duplicated key %s",one_range.toString()));
        rangekv[one_range.hashCode()] = true;
        uint64_t hand_long = Card::boardInts2long(one_range.get_hands());
        if(!Card::boardsHasIntercept(hand_long,board_long)){
            range_array.push_back(one_range);
        }
    }
    return range_array;
}
```