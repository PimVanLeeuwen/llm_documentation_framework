`noDuplicateRange`: The function of `noDuplicateRange` is to remove duplicate private card ranges and filter out those that do not intersect with the given board.

**Parameters**:
`const vector<PrivateCards> &private_range`: This parameter is a reference to a vector of PrivateCards objects, which represents a collection of private card ranges.
`uint64_t board_long`: This parameter is a 64-bit unsigned integer representing the poker board.

**Code Description**: The function iterates through each PrivateCards object in the input vector. It checks if the hash code of the current range already exists in the unordered map `rangekv`. If it does, it throws an exception indicating that there's a duplicate key. Otherwise, it adds the hash code to the map and calculates the long integer representation of the current hand using the `boardInts2long` method from the Card class. It then checks if this hand intersects with the given board using the `boardsHasIntercept` method from the Card class. If there's no intersection, it adds the current PrivateCards object to the output vector `range_array`. Finally, it returns the filtered and deduplicated range array.\\
## Code: 
```
vector<PrivateCards> noDuplicateRange(const vector<PrivateCards> &private_range, uint64_t board_long) {
    vector<PrivateCards> range_array;
    unordered_map<int,bool> rangekv;
    for(PrivateCards one_range:private_range){
        if(rangekv.find(one_range.hashCode()) != rangekv.end())
            throw runtime_error(tfm::format("duplicated key %s",one_range.toString()));
        rangekv[one_range.hashCode()] = true;
        uint64_t hand_long = Card::boardInts2long(one_range.get_hands());
        if(!Card::boardsHasIntercept(hand_long,board_long)){
            range_array.push_back(one_range);
        }
    }
    return range_array;
}
```