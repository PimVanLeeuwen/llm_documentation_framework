`getcurrentStrategy`: The function of `getcurrentStrategy` is to return the current strategy for the game state.

**Code Description**: This method is a simple wrapper that calls and returns the result of `getcurrentStrategyNoCache()`. It doesn't perform any additional computations or modifications to the strategy. The method is likely designed to provide a consistent interface for retrieving the current strategy, while the actual calculation is delegated to the `getcurrentStrategyNoCache()` method. This approach allows for potential future optimizations or caching mechanisms to be implemented without changing the public interface of the class.\\
## Code: 
```
const vector<float> DiscountedCfrTrainableSF::getcurrentStrategy() {
    return this->getcurrentStrategyNoCache();
}
```