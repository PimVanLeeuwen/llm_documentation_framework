`setBoardText`: The function of `setBoardText` is to update the board state based on an input string of board positions.

**Parameters**:
`QString input_board`: A string containing comma-separated board positions to be set.

**Code Description**: This method processes the input string to update the board state. It first clears the existing board using the `clear_board()` method. Then, it splits the input string by commas and iterates through each board position. For each valid position, it converts it to a pair of coordinates using the `string2ij` map and sets the corresponding value in the `grids_float` 2D array to 1.0. The method skips empty or invalid board positions, logging a debug message for format errors. This function is designed to handle multiple board positions in a single input string, allowing for efficient batch updates of the board state.\\
## Code: 
```
void BoardSelectorTableModel::setBoardText(QString input_board){
    this->clear_board();
    for(QString one_board:input_board.split(",")){
        float board_float = 1.0;


        if(one_board.count(" ") == one_board.length() || one_board == "")continue;
        if(!this->string2ij.count(one_board)){
            qDebug().noquote() << QString(tr("skipping board %1, format error")).arg(one_board);
            continue;
        }
        pair<int,int> cord = this->string2ij[one_board];
        this->grids_float[cord.first][cord.second] = board_float;
    }
}
```