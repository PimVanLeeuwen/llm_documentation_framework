`toBoardLong`: The function of `toBoardLong` is to return the board representation as a 64-bit unsigned integer.

**Code Description**: This method is a member of the `PrivateCards` class and returns the value of the `board_long` member variable. The `board_long` is likely a 64-bit unsigned integer (uint64_t) that represents the current state of the board in a compact form. The commented-out line suggests that there might have been an alternative implementation using a `Card::boardInts2long` function to convert a vector of cards to this long representation, but it's currently not in use. The method simply returns the pre-calculated or pre-stored `board_long` value, providing quick access to the board state in a format that's efficient for further processing or comparison operations in the Texas Hold'em solver.\\
## Code: 
```
uint64_t PrivateCards::toBoardLong() {
    return this->board_long;
    //return Card::boardInts2long(this->card_vec);
}
```