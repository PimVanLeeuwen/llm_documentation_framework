`paint_evs`: The function of `paint_evs` is to paint expected values (EVs) for a given game state in the Texas Solver application.

**Parameters**:
- `QPainter *painter`: A pointer to a QPainter object used to draw graphics on the screen.
- `const QStyleOptionViewItem &option`: A reference to a QStyleOptionViewItem object containing information about the item being painted, such as its geometry and style options.
- `const QModelIndex &index`: A constant reference to a QModelIndex object representing the index of the item in the model.

**Code Description**: The function first initializes an option variable with the provided option and then casts the index's model to a TableStrategyModel pointer. It retrieves the expected values for the given game state from the table strategy model using the get_ev_grid method, sorts them in ascending order, and iterates over each value. For each EV, it calculates a normalized color based on the EV's magnitude and uses this color to fill a rectangle representing the EV in the item's view. Finally, it draws any text associated with the item.\\
## Code: 
```
void StrategyItemDelegate::paint_evs(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);
    const TableStrategyModel * tableStrategyModel = qobject_cast<const TableStrategyModel*>(index.model());
    vector<float> evs = tableStrategyModel->get_ev_grid(index.row(),index.column());
    sort(evs.begin(), evs.end());

    int last_left = 0;
    for(std::size_t i = 0;i < evs.size();i ++ ){
        float one_ev = evs[evs.size() - i - 1];
        float normalized_ev = normalization_tanh(this->qSolverJob->stack,one_ev);
        //options.text += QString("</br>%1").arg(QString::number(normalized_ev));

        int red = max((int)(255 - normalized_ev * 255),0);
        int green = min((int)(normalized_ev * 255),255);
        int blue = min(red, green);

        QBrush brush = QBrush(QColor(red,green,blue));

        int this_width = (int)((float(i + 1) / evs.size()) * options.rect.width()) - last_left;

        QRect rect(option.rect.left() + last_left, option.rect.top(),\
             this_width , (int) (options.rect.height()));
        painter->fillRect(rect, brush);
        last_left += this_width;
    }
    QTextDocument doc;
    doc.setHtml(options.text);
    options.text = "";
    //options.widget->style()->drawControl(QStyle::CE_ItemViewItem, &option, painter);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```