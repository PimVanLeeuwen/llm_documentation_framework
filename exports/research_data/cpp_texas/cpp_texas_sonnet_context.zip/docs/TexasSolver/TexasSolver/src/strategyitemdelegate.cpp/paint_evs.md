`paint_evs`: The function of `paint_evs` is to visualize expected value (EV) data for a strategy item in a custom-painted table cell.

**Parameters**:
`QPainter *painter`: A pointer to the QPainter object used for drawing the cell content.
`const QStyleOptionViewItem &option`: Contains style options for rendering the item.
`const QModelIndex &index`: Represents the model index of the item being painted.

**Code Description**: This method paints a visual representation of expected values (EVs) for a strategy item in a table cell. It first retrieves the EV data from the TableStrategyModel using the provided index. The EVs are then sorted in descending order. The method calculates a normalized EV value for each data point using a tanh normalization function.

The cell is divided into vertical sections, each representing an EV value. The width of each section is proportional to its position in the sorted list. Colors are assigned to each section based on the normalized EV: red for lower values, green for higher values, and a mix for intermediate values.

The painting process involves filling rectangles with these color-coded sections from left to right. After painting the EV visualization, the method sets up a QTextDocument to render any additional text content specified in the style options.

This visualization technique allows for a quick, color-coded overview of the EV distribution within the strategy item, making it easier for users to interpret the data at a glance.\\
## Code: 
```
void StrategyItemDelegate::paint_evs(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);
    const TableStrategyModel * tableStrategyModel = qobject_cast<const TableStrategyModel*>(index.model());
    vector<float> evs = tableStrategyModel->get_ev_grid(index.row(),index.column());
    sort(evs.begin(), evs.end());

    int last_left = 0;
    for(std::size_t i = 0;i < evs.size();i ++ ){
        float one_ev = evs[evs.size() - i - 1];
        float normalized_ev = normalization_tanh(this->qSolverJob->stack,one_ev);
        //options.text += QString("</br>%1").arg(QString::number(normalized_ev));

        int red = max((int)(255 - normalized_ev * 255),0);
        int green = min((int)(normalized_ev * 255),255);
        int blue = min(red, green);

        QBrush brush = QBrush(QColor(red,green,blue));

        int this_width = (int)((float(i + 1) / evs.size()) * options.rect.width()) - last_left;

        QRect rect(option.rect.left() + last_left, option.rect.top(),\
             this_width , (int) (options.rect.height()));
        painter->fillRect(rect, brush);
        last_left += this_width;
    }
    QTextDocument doc;
    doc.setHtml(options.text);
    options.text = "";
    //options.widget->style()->drawControl(QStyle::CE_ItemViewItem, &option, painter);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```