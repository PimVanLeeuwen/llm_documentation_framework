`getRangeAt`: The function of `getRangeAt` is to retrieve a float value from a 2D grid at the specified indices.

**Parameters**:
`int i`: The row index of the grid.
`int j`: The column index of the grid.

**Code Description**: This method is part of the `RangeSelectorTableModel` class and is used to access values from a 2D grid stored in the `grids_float` member variable. It first checks if the provided indices `i` and `j` are within valid bounds (0 to `ranklist.size() - 1`). If either index is out of bounds, it prints a debug message and returns 0. If both indices are valid, it returns the float value stored at `grids_float[i][j]`. This method ensures safe access to the grid data by performing bounds checking before retrieving the value.\\
## Code: 
```
float RangeSelectorTableModel::getRangeAt(int i, int j){
    if(i < 0 || i >= this->ranklist.size()){
        qDebug().noquote() << "RangeSelectorTableModel::getRangeAt i not valid: " << i;
        return 0;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "RangeSelectorTableModel::getRangeAt j not valid: " << j;
        return 0;
    }
    else{
        return this->grids_float[i][j];
    }
}
```