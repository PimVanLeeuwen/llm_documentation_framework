`convert`: The function of `convert` is to separate a given strength map into flush and non-flush hands.

**Parameters**:
`unordered_map<uint64_t`: A hash map where keys are 64-bit integers representing card combinations
`int>& strength_map`: The corresponding strength values for each card combination

**Code Description**: This method processes an input strength map and separates it into two distinct maps: one for flush hands and another for non-flush hands. It iterates through each entry in the input strength_map. For each entry, it calculates a hash of the card ranks using the ranks_hash function. It then checks if the hand is a flush using the is_flush function. If it's a flush, the original cards_hash and strength are stored in the flush_map. If it's not a flush, the calculated rank hash and strength are stored in the other_map. This separation allows for more efficient lookup and comparison of hand strengths based on whether they are flushes or not. The method clears both flush_map and other_map at the beginning to ensure fresh data for each conversion.\\
## Code: 
```
void FiveCardsStrength::convert(unordered_map<uint64_t, int>& strength_map) {
    flush_map.clear(); other_map.clear();
    auto it = strength_map.begin(), it_end = strength_map.end();
    for (; it != it_end; it++) {
        uint64_t cards_hash = it->first;
        uint64_t hash = ranks_hash(cards_hash);
        if (is_flush(cards_hash)) flush_map[cards_hash] = it->second;
        else {
            /*if (other_map.count(hash) && other_map[hash] != it->second) {
                printf("%zx,%zx:%d != %d\n", cards_hash, hash, it->second, other_map[hash]);
            }*/
            other_map[hash] = it->second;
        }
    }
}
```