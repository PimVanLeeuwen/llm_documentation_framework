`convert`: The function of `convert` is to process a given unordered map of poker hand strengths and categorize them into flush and non-flush hands.

**Parameters**:
`unordered_map<uint64_t, int>& strength_map`: This parameter represents the input unordered map containing poker hand strengths, where each key is a 64-bit unsigned integer representing a poker hand's hash value, and each value is an integer representing the corresponding hand strength.

**Code Description**: The `convert` function iterates over the input unordered map, processes each entry, and categorizes the poker hands into two separate maps: one for flush hands (`flush_map`) and another for non-flush hands (`other_map`). It uses a helper function `ranks_hash` to modify the hash value of each hand and checks if the hand has a flush using the `is_flush` function. If the hand is not already present in the `other_map`, it adds the entry; otherwise, it updates the strength value if necessary. The processed maps are then cleared at the beginning of the function.\\
## Code: 
```
void FiveCardsStrength::convert(unordered_map<uint64_t, int>& strength_map) {
    flush_map.clear(); other_map.clear();
    auto it = strength_map.begin(), it_end = strength_map.end();
    for (; it != it_end; it++) {
        uint64_t cards_hash = it->first;
        uint64_t hash = ranks_hash(cards_hash);
        if (is_flush(cards_hash)) flush_map[cards_hash] = it->second;
        else {
            /*if (other_map.count(hash) && other_map[hash] != it->second) {
                printf("%zx,%zx:%d != %d\n", cards_hash, hash, it->second, other_map[hash]);
            }*/
            other_map[hash] = it->second;
        }
    }
}
```