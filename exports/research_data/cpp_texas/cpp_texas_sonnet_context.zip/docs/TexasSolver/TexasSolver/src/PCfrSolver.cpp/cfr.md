`cfr`: The function of `cfr` is to perform the Counterfactual Regret Minimization algorithm on different types of game tree nodes.

**Parameters**:
`int player`: The current player's index
`shared_ptr<GameTreeNode> node`: A shared pointer to the current game tree node
`const vector<float> &reach_probs`: A vector of reach probabilities for each player
`int iter`: The current iteration number of the CFR algorithm
`uint64_t current_board`: A representation of the current board state
`int deal`: The current deal or hand being played

**Code Description**: This method implements the core of the Counterfactual Regret Minimization (CFR) algorithm for a poker solver. It takes a game tree node and recursively calculates the utility for different node types. The function uses a switch statement to determine the type of the current node (Action, Showdown, Terminal, or Chance) and calls the appropriate utility calculation method for each type. For Action nodes, it calls `actionUtility`; for Showdown nodes, `showdownUtility`; for Terminal nodes, `terminalUtility`; and for Chance nodes, `chanceUtility`. Each of these utility methods is expected to return a vector of float values representing the utility for each player. If an unknown node type is encountered, the function throws a runtime error. This structure allows the CFR algorithm to traverse the game tree and compute strategies for different game situations in poker.\\
## Code: 
```
vector<float> PCfrSolver::cfr(int player, shared_ptr<GameTreeNode> node, const vector<float> &reach_probs, int iter,
                                    uint64_t current_board,int deal) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
            return actionUtility(player, action_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::SHOWDOWN: {
            shared_ptr<ShowdownNode> showdown_node = std::dynamic_pointer_cast<ShowdownNode>(node);
            return showdownUtility(player, showdown_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::TERMINAL: {
            shared_ptr<TerminalNode> terminal_node = std::dynamic_pointer_cast<TerminalNode>(node);
            return terminalUtility(player, terminal_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::CHANCE: {
            shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
            return chanceUtility(player, chance_node, reach_probs, iter, current_board,deal);
        }default:
            throw runtime_error("node type unknown");
    }
}
```