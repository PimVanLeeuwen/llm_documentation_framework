`cfr`: The function of `cfr` is to calculate the Counterfactual Regret Minimization (CFR) value for a given game state.

**Parameters**:
`int player`: The index of the player whose CFR value is being calculated.
`shared_ptr<GameTreeNode> node`: A pointer to the current game tree node.
`const vector<float> &reach_probs`: A reference to a vector containing the reach probabilities for each possible outcome.
`int iter`: The number of iterations to perform in the Monte Carlo simulation.
`uint64_t current_board`: The current state of the board, represented as a 64-bit unsigned integer.
`int deal`: The type of deal being used (e.g. flop, turn, river).

**Code Description**: The `cfr` function uses a switch statement to determine the type of game tree node it is currently processing. Based on the node type, it calls one of four utility functions: `actionUtility`, `showdownUtility`, `terminalUtility`, or `chanceUtility`. Each of these functions calculates the CFR value for the corresponding type of node using Monte Carlo simulations and reach probabilities. The function returns a vector containing the calculated CFR values.\\
## Code: 
```
vector<float> PCfrSolver::cfr(int player, shared_ptr<GameTreeNode> node, const vector<float> &reach_probs, int iter,
                                    uint64_t current_board,int deal) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
            return actionUtility(player, action_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::SHOWDOWN: {
            shared_ptr<ShowdownNode> showdown_node = std::dynamic_pointer_cast<ShowdownNode>(node);
            return showdownUtility(player, showdown_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::TERMINAL: {
            shared_ptr<TerminalNode> terminal_node = std::dynamic_pointer_cast<TerminalNode>(node);
            return terminalUtility(player, terminal_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::CHANCE: {
            shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
            return chanceUtility(player, chance_node, reach_probs, iter, current_board,deal);
        }default:
            throw runtime_error("node type unknown");
    }
}
```