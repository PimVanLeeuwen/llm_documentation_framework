`paint`: The function of `paint` is to render custom content for items in a view based on different detail window modes.

**Parameters**:
`QPainter *painter`: A pointer to the QPainter object used for drawing.
`const QStyleOptionViewItem &option`: Contains style options for the item being painted.
`const QModelIndex &index`: Represents the model index of the item being painted.

**Code Description**: This method is responsible for painting custom content for items in a view, adapting the display based on the current detail window mode. It begins by saving the painter's state and filling the item's rectangle with a gray background. The method then checks the `detailWindowSetting->mode` to determine which specific painting function to call:

1. For the STRATEGY mode, it calls `paint_strategy`.
2. For RANGE_IP or RANGE_OOP modes, it calls `paint_range`.
3. For the EV mode, it calls `paint_evs`.
4. For the EV_ONLY mode, it calls `paint_evs_only`.

Each of these specialized painting functions is responsible for rendering the appropriate content for its respective mode. After the specific painting is complete, the method restores the painter's state. This design allows for flexible and mode-specific rendering of item content in the view.\\
## Code: 
```
void DetailItemDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    painter->save();

    QRect rect(option.rect.left(), option.rect.top(),\
             option.rect.width(), option.rect.height());
    QBrush brush(Qt::gray);
    painter->fillRect(rect, brush);

    if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::STRATEGY){
        this->paint_strategy(painter,option,index);
    }
    else if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP ||
            this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_OOP ){
        this->paint_range(painter,option,index);
    }
    else if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::EV){
        this->paint_evs(painter,option,index);
    }
    else if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::EV_ONLY){
        this->paint_evs_only(painter,option,index);
    }


    painter->restore();
}
```