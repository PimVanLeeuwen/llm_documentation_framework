`operator[]`: The function of `operator[]` is to retrieve the strength value for a given hand represented by a hash.

**Parameters**:
`uint64_t hash`: A 64-bit unsigned integer representing the hash of a poker hand.

**Code Description**: This method is part of the `FiveCardsStrength` class and serves as an overloaded array access operator. It takes a hash value representing a poker hand and returns an integer strength value for that hand. The function first checks if the hash exists in the `flush_map`. If found, it returns the corresponding strength value. If not found in the flush_map, it recalculates the hash using the `ranks_hash` function and then looks up the strength value in the `other_map`. This approach allows for efficient retrieval of hand strengths for both flush and non-flush hands.\\
## Code: 
```
int FiveCardsStrength::operator[](uint64_t hash) {
    auto it = flush_map.find(hash);
    if (it != flush_map.end()) return it->second;
    hash = ranks_hash(hash);
    return other_map.at(hash);
}
```