`copyStrategy`: The function of `copyStrategy` is to copy strategy data from another DiscountedCfrTrainableSF object.

**Parameters**:
`shared_ptr<Trainable> other_trainable`: A shared pointer to another Trainable object, expected to be of type DiscountedCfrTrainableSF.

**Code Description**: This method copies the strategy data from another DiscountedCfrTrainableSF object to the current object. It first performs a dynamic cast to ensure the passed object is of the correct type. Then, it assigns the values of `r_plus` and `cum_r_plus` vectors from the source object to the corresponding vectors in the current object using the `assign` method. This effectively duplicates the strategy information, allowing the current object to adopt the same state as the source object.\\
## Code: 
```
void DiscountedCfrTrainableSF::copyStrategy(shared_ptr<Trainable> other_trainable){
    shared_ptr<DiscountedCfrTrainableSF> trainable = dynamic_pointer_cast<DiscountedCfrTrainableSF>(other_trainable);
    this->r_plus.assign(trainable->r_plus.begin(),trainable->r_plus.end());
    this->cum_r_plus.assign(trainable->cum_r_plus.begin(),trainable->cum_r_plus.end());
}
```