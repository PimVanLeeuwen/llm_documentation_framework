`rowCount`: The function of `rowCount` is to return the number of child items for a given parent item in a tree model.

**Parameters**:
`const QModelIndex &parent`: The model index of the parent item for which to count the number of child rows.

**Code Description**: This method determines the number of child items (rows) for a given parent item in a tree structure. It first checks if the parent index's column is greater than 0, returning 0 if true since only the first column should have child items. If the parent index is invalid, it uses the root item as the parent. Otherwise, it casts the internal pointer of the parent index to a TreeItem. Finally, it returns the child count of the parent item using the childCount() method.\\
## Code: 
```
int TreeModel::rowCount(const QModelIndex &parent) const
{
    TreeItem *parentItem;
    if (parent.column() > 0)
        return 0;

    if (!parent.isValid())
        parentItem = rootItem;
    else
        parentItem = static_cast<TreeItem*>(parent.internalPointer());

    return parentItem->childCount();
}
```