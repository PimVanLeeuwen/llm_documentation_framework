`getBoardText`: The function of `getBoardText` is to generate a comma-separated string representation of selected board positions.

**Code Description**: This method iterates through a 2D grid (represented by `suitlist` and `ranklist`) and constructs a string containing the text values of non-zero grid positions. It uses nested loops to traverse the grid, skipping positions with a value of 0. For each non-zero position, it appends the corresponding text from `grids_string` to the return string, separating entries with commas. The resulting string represents all selected board positions in a compact, comma-separated format.\\
## Code: 
```
QString BoardSelectorTableModel::getBoardText(){
    QString retval = "";
    for(int i = 0;i < this->suitlist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            if(this->grids_float[i][j] == 0)continue;
            QString one_board_str = QString("%1").arg(this->grids_string[i][j]);
            if(retval == ""){
                retval = one_board_str;
            }else{
                retval = retval + "," + one_board_str;
            }
        }
    }
    return retval;
}
```