`build_game_tree`: The function of `build_game_tree` is to create and initialize a new game tree for a poker game simulation.

**Parameters**:
`float oop_commit`: The amount committed by the out-of-position player
`float ip_commit`: The amount committed by the in-position player
`int current_round`: The current round of the game
`int raise_limit`: The maximum number of raises allowed
`float small_blind`: The amount of the small blind
`float big_blind`: The amount of the big blind
`float stack`: The total stack size for each player
`GameTreeBuildingSettings buildingSettings`: Settings for building the game tree
`float allin_threshold`: The threshold for considering a bet as an all-in move

**Code Description**: This method creates a new `GameTree` object using the provided parameters and assigns it to the `game_tree` member variable of the `PokerSolver` class. It uses `make_shared` to create a shared pointer to the new `GameTree` object. The `GameTree` constructor is called with all the input parameters, including the `deck` member of the `PokerSolver` class. This setup initializes the game tree with the current game state and settings, which can then be used for further game analysis or simulation.\\
## Code: 
```
void PokerSolver::build_game_tree(
        float oop_commit,
        float ip_commit,
        int current_round,
        int raise_limit,
        float small_blind,
        float big_blind,
        float stack,
        GameTreeBuildingSettings buildingSettings,
        float allin_threshold
){
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(
            this->deck,
            oop_commit,
            ip_commit,
            current_round,
            raise_limit,
            small_blind,
            big_blind,
            stack,
            buildingSettings,
            allin_threshold
    );
    this->game_tree = game_tree;
}
```