`build_game_tree`: The function of `build_game_tree` is to construct a game tree data structure for Texas Hold'em poker based on the provided settings and rules.

**Parameters**:
`float oop_commit`: The out-of-position commitment, representing the amount committed by an opponent.
`float ip_commit`: The in-position commitment, representing the amount committed by the player themselves when they are in position to act.
`int current_round`: The current round of betting in the game.
`int raise_limit`: The maximum number of raises allowed in a single hand.
`float small_blind`: The size of the small blind bet.
`float big_blind`: The size of the big blind bet.
`float stack`: The player's current stack size, representing their available funds.
`GameTreeBuildingSettings buildingSettings`: A set of settings used to build the game tree, including rules and parameters for the game.
`float allin_threshold`: The threshold at which a player is considered "all-in", meaning they have committed their entire stack.

**Code Description**: This function creates a new `GameTree` object using the provided parameters and settings, and assigns it to the `game_tree` member variable of the `PokerSolver` class. The `GameTree` constructor recursively builds the game tree data structure based on the input parameters and rules.\\
## Code: 
```
void PokerSolver::build_game_tree(
        float oop_commit,
        float ip_commit,
        int current_round,
        int raise_limit,
        float small_blind,
        float big_blind,
        float stack,
        GameTreeBuildingSettings buildingSettings,
        float allin_threshold
){
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(
            this->deck,
            oop_commit,
            ip_commit,
            current_round,
            raise_limit,
            small_blind,
            big_blind,
            stack,
            buildingSettings,
            allin_threshold
    );
    this->game_tree = game_tree;
}
```