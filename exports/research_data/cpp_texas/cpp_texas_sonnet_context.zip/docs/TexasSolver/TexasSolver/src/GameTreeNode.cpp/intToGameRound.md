`intToGameRound`: The function of `intToGameRound` is to convert an integer representation of a game round to its corresponding GameRound enum value.

**Parameters**:
`int round`: An integer representing the game round (0-3).

**Code Description**: This method takes an integer input and maps it to the corresponding GameRound enum value in a Texas Hold'em poker game. It uses a switch statement to handle four cases:

0 maps to PREFLOP
1 maps to FLOP
2 maps to TURN
3 maps to RIVER

If the input is not within this range (0-3), the function throws a runtime_error with a formatted error message. The method returns the appropriate GameRound enum value. This conversion is likely used to maintain a more readable and type-safe representation of game rounds throughout the TexasSolver project.\\
## Code: 
```
GameTreeNode::GameRound GameTreeNode::intToGameRound(int round){
    GameTreeNode::GameRound game_round;
    switch(round){
        case 0:{
            game_round = GameTreeNode::GameRound::PREFLOP;
            break;
        }
        case 1:{
            game_round = GameTreeNode::GameRound::FLOP;
            break;
        }
        case 2:{
            game_round = GameTreeNode::GameRound::TURN;
            break;
        }
        case 3:{
            game_round = GameTreeNode::GameRound::RIVER;
            break;
        }
        default:{
            throw runtime_error(tfm::format("round %s not found",round));
        }
    }
    return game_round;
}
```