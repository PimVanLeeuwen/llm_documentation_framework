`setRiverCard`: The function of `setRiverCard` is to set the river card for the TableStrategyModel.

**Parameters**:
`Card river_card`: The card to be set as the river card in Texas Hold'em poker.

**Code Description**: This method is a simple setter function for the TableStrategyModel class. It takes a Card object as a parameter and assigns it to the class member variable 'river_card'. The river card in poker is the fifth and final community card dealt in a hand of Texas Hold'em. By setting this card, the TableStrategyModel can update its internal state to reflect the current game situation, which is crucial for strategy calculations and decision-making processes in poker gameplay simulations or analysis.\\
## Code: 
```
void TableStrategyModel::setRiverCard(Card river_card){
    this->river_card = river_card;
}
```