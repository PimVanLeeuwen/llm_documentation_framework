`updateRegrets`: The function of `updateRegrets` is to update regret values and cumulative strategies in a Counterfactual Regret Minimization (CFR) algorithm implementation.

**Parameters**:
`const vector<float>& regrets`: A vector containing the current regret values for each action and card combination.
`int iteration_number`: The current iteration number of the CFR algorithm.
`const vector<float>& reach_probs`: A vector of reach probabilities (unused in this implementation).

**Code Description**: The function first updates the internal regrets vector and checks if its size matches the expected length (action_number * card_number). It then resets r_plus_sum and cum_r_plus_sum vectors to zero. The main loop iterates over all actions and private cards, updating the following for each combination:

1. R+ (positive regret) values: It calculates the maximum of 0 and the sum of the current regret and previous R+ value.
2. R+ sum: It accumulates the R+ values for each private card.
3. Cumulative R+: It updates the cumulative R+ by adding the product of the current R+ and the iteration number.
4. Cumulative R+ sum: It accumulates the cumulative R+ values for each private card.

These updates are crucial for the CFR algorithm to converge towards an optimal strategy over multiple iterations.\\
## Code: 
```
void CfrPlusTrainable::updateRegrets(const vector<float>& regrets, int iteration_number, const vector<float>& reach_probs) {
    this->regrets = regrets;
    if(regrets.size() != this->action_number * this->card_number) throw runtime_error("length not match");

    //Arrays.fill(this.r_plus_sum,0);
    fill(r_plus_sum.begin(),r_plus_sum.end(),0);
    fill(cum_r_plus_sum.begin(),cum_r_plus_sum.end(),0);
    for (int action_id = 0;action_id < action_number;action_id ++) {
        for(int private_id = 0;private_id < this->card_number;private_id ++){
            int index = action_id * this->card_number + private_id;
            float one_reg = regrets[index];

            // 更新 R+
            this->r_plus[index] = max((float)0.0,one_reg + this->r_plus[index]);
            this->r_plus_sum[private_id] += this->r_plus[index];

            // 更新累计策略
            this->cum_r_plus[index] += this->r_plus[index] * iteration_number;
            this->cum_r_plus_sum[private_id] += this->cum_r_plus[index];
        }
    }
}
```