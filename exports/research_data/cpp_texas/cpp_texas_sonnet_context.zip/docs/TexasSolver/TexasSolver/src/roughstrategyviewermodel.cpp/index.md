`index`: The function of `index` is to return a QModelIndex object that represents the item at the specified row and column within the model, with the given parent index.

**Parameters**:
`int row`: The row number of the item in the model.
`int column`: The column number of the item in the model.
`const QModelIndex &parent`: The parent index of the item, which is used to determine its position within the model's hierarchy.

**Code Description**: This function checks if the specified row and column are valid indices for an item within the model. If they are not, it returns a null QModelIndex object. Otherwise, it creates a new QModelIndex object with the given row, column, and parent index, and returns it. The purpose of this function is to allow the model to provide access to its items based on their position in the hierarchy.\\
## Code: 
```
QModelIndex RoughStrategyViewerModel::index(int row, int column, const QModelIndex &parent) const
{
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    return createIndex(row, column, nullptr);
}
```