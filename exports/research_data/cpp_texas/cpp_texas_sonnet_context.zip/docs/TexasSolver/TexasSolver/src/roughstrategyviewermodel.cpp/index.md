`index`: The function of `index` is to create and return a model index for a given row and column.

**Parameters**:
`int row`: The row number for which to create the index.
`int column`: The column number for which to create the index.
`const QModelIndex &parent`: The parent index, which is not used in this implementation.

**Code Description**: This method is part of the RoughStrategyViewerModel class and implements the index() function required by Qt's model/view framework. It first checks if the requested index is valid using the hasIndex() function. If the index is not valid, it returns an invalid QModelIndex. For valid indices, it creates and returns a new QModelIndex using createIndex(), with the given row and column, and a null pointer as the internal pointer. This implementation treats all items as top-level items, ignoring the parent parameter.\\
## Code: 
```
QModelIndex RoughStrategyViewerModel::index(int row, int column, const QModelIndex &parent) const
{
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    return createIndex(row, column, nullptr);
}
```