`getRangeText`: The function of `getRangeText` is to generate a formatted string representation of the range data stored in the model.

**Code Description**: This method iterates through a 2D grid of range data, combining non-zero entries into a single string. Each non-zero entry is formatted as "grid_string:grid_float_value" (with the float value rounded to 3 decimal places). These formatted entries are then concatenated into a comma-separated list. The method skips over any grid entries with a value of 0. The resulting string provides a compact representation of the selected ranges in the model, which can be used for display or further processing.\\
## Code: 
```
QString RangeSelectorTableModel::getRangeText(){
    QString retval = "";
    for(int i = 0;i < this->ranklist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            if(this->grids_float[i][j] == 0)continue;
            QString one_range_str = QString("%1:%2").arg(this->grids_string[i][j],QString::number(this->grids_float[i][j],'f',3));
            if(retval == ""){
                retval = one_range_str;
            }else{
                retval = retval + "," + one_range_str;
            }
        }
    }
    return retval;
}
```