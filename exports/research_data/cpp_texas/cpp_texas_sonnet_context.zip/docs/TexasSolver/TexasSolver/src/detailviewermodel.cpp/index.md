`index`: The function of `index` is to create and return a valid QModelIndex for a given row and column in the model.

**Parameters**:
`int row`: The row number for which to create the index.
`int column`: The column number for which to create the index.
`const QModelIndex &parent`: The parent index, which is not used in this implementation.

**Code Description**: This method implements the `index` function for a custom model in Qt. It first checks if the requested index is valid using the `hasIndex` function. If the index is not valid, it returns an invalid QModelIndex. Otherwise, it creates and returns a new QModelIndex using the `createIndex` function, passing the row, column, and a null pointer as the internal pointer. This implementation treats all items as top-level items without hierarchical structure, as it doesn't use the parent parameter and always passes nullptr as the internal pointer.\\
## Code: 
```
QModelIndex DetailViewerModel::index(int row, int column, const QModelIndex &parent) const
{
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    return createIndex(row, column, nullptr);
}
```