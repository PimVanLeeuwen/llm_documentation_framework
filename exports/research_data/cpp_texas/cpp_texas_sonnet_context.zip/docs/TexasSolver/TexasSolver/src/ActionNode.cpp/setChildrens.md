`setChildrens`: The function of `setChildrens` is to set the children nodes of an ActionNode.

**Parameters**:
`const vector<shared_ptr<GameTreeNode>> &childrens`: A constant reference to a vector of shared pointers to GameTreeNode objects, representing the children nodes to be set.

**Code Description**: This method is a simple setter function for the ActionNode class. It assigns the provided vector of child nodes to the member variable `childrens` of the ActionNode instance. The method takes a constant reference to the vector to avoid unnecessary copying and to ensure that the original vector is not modified. By using shared pointers, it allows for efficient memory management and shared ownership of the child nodes across different parts of the game tree.\\
## Code: 
```
void ActionNode::setChildrens(const vector<shared_ptr<GameTreeNode>> &childrens) {
    ActionNode::childrens = childrens;
}
```