`compair`: The function of `compair` is to compare two poker hands in Texas Hold'em.

**Parameters**:
`vector<int> private_former`: The two private cards of the first player
`vector<int> private_latter`: The two private cards of the second player
`vector<int> public_board`: The five community cards on the board

**Code Description**: This method compares two Texas Hold'em poker hands. It first validates the input sizes, ensuring that each player has exactly two private cards and the public board has five cards. If these conditions are not met, it throws a runtime error with a formatted message. 

The function then combines each player's private cards with the public board to form two seven-card hands. It calls the `getRank` method to evaluate the strength of each hand, which likely returns a numerical representation of the hand's rank.

Finally, it calls the `compairRanks` method to compare these two ranks and determine which hand is stronger. The result is returned as a `Compairer::CompairResult` enum, which likely indicates whether the first hand is better, worse, or equal to the second hand.

This implementation follows the standard rules of Texas Hold'em, where the best five-card hand is formed from the seven available cards (two private and five community).\\
## Code: 
```
Compairer::CompairResult
Dic5Compairer::compair(vector<int> private_former, vector<int> private_latter, vector<int> public_board) {
    if(private_former.size() != 2)
        throw runtime_error(
                tfm::format("private former size incorrect,excepted 2, actually %s",private_former.size())
        );
    if(private_latter.size() != 2)
        throw runtime_error(
                tfm::format("private latter size incorrect,excepted 2, actually %s",private_latter.size())
        );
    if(public_board.size() != 5)
        throw runtime_error(
                tfm::format("public board size incorrect,excepted 2, actually %s",public_board.size())
        );

    vector<int> former_cards(private_former);
    former_cards.insert(former_cards.end(),public_board.begin(),public_board.end());
    int rank_former = this->getRank(former_cards);

    vector<int> latter_cards(private_latter);
    latter_cards.insert(latter_cards.end(),public_board.begin(),public_board.end());
    int rank_latter = this->getRank(latter_cards);

    return this->compairRanks(rank_former,rank_latter);
}
```