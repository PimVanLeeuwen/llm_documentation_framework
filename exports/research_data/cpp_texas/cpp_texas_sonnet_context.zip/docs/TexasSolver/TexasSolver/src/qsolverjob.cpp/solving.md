`solving`: The function of `solving` is to initiate and execute the poker solving process for either Texas Hold'em or Short Deck poker variants.

**Code Description**: This method begins by logging a debug message indicating the start of the solving process. It then checks the game mode (HOLDEM or SHORTDECK) and calls the appropriate train method from either the ps_holdem or ps_shortdeck object. The train method is invoked with several parameters:

1. range_ip and range_oop: Likely represent the ranges for in-position and out-of-position players.
2. board: Represents the community cards.
3. max_iteration: Maximum number of iterations for the solving algorithm.
4. print_interval: Frequency of progress updates.
5. "discounted_cfr": The solving algorithm used (Discounted Counterfactual Regret Minimization).
6. accuracy: Desired accuracy of the solution.
7. use_isomorphism: Boolean flag for using isomorphism in calculations.
8. use_halffloats: Boolean flag for using half-precision floating-point format.
9. thread_number: Number of threads to use for parallel processing.

After the solving process is complete, it logs another debug message indicating the completion. The method also includes TODO comments noting potential memory leak issues and unexplained crashes, suggesting areas for future investigation and improvement.\\
## Code: 
```
void QSolverJob::solving(){
    // TODO  为什么ui上多次求解会积累memory？哪里leak了？
    // TODO  为什么有时候会莫名闪退？
    qDebug().noquote() << tr("Start Solving..");//.toStdString() << std::endl;

    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }
    qDebug().noquote() << tr("Solving done.");//.toStdString() << std::endl;
}
```