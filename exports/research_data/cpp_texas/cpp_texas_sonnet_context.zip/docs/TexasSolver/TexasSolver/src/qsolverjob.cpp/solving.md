`solving`: The function of `solving` is to train a poker solver on given player ranges, boards, and parameters to optimize its performance.

**Code Description**: This code snippet implements the `solving` method in the `QSolverJob` class. It trains either a Hold'em or Shortdeck poker solver (depending on the mode) using the provided ranges, board, and parameters. The training process involves calling the `train` method of the respective poker solver object (`ps_holdem` or `ps_shortdeck`). The `train` method is likely implemented in the `PokerSolver.cpp` file, which is called within this code snippet.\\
## Code: 
```
void QSolverJob::solving(){
    // TODO  为什么ui上多次求解会积累memory？哪里leak了？
    // TODO  为什么有时候会莫名闪退？
    qDebug().noquote() << tr("Start Solving..");//.toStdString() << std::endl;

    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }
    qDebug().noquote() << tr("Solving done.");//.toStdString() << std::endl;
}
```