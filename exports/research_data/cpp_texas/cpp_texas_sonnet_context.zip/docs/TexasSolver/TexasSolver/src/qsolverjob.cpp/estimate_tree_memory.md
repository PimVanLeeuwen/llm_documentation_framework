`estimate_tree_memory`: The function of `estimate_tree_memory` is to estimate the memory required for the game tree based on the given ranges and board.

**Parameters**:
`QString range1`: A string representing the first player's hand range
`QString range2`: A string representing the second player's hand range
`QString board`: A string representing the community cards on the board

**Code Description**: This method estimates the memory required for the game tree in a poker solver. It first logs a debug message indicating that tree memory estimation is in progress. The function then checks the game mode (HOLDEM or SHORTDECK) and calls the corresponding `estimate_tree_memory` method from either the `ps_holdem` or `ps_shortdeck` object, passing along the range and board parameters. If neither mode matches, it returns 0. The estimated memory is returned as a long long integer value.\\
## Code: 
```
long long QSolverJob::estimate_tree_memory(QString range1,QString range2,QString board){
    qDebug().noquote() << tr("Estimating tree memory..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        return ps_holdem.estimate_tree_memory(range1,range2,board);
    }else if(this->mode == Mode::SHORTDECK){
        return ps_shortdeck.estimate_tree_memory(range1,range2,board);
    }
    return 0;
}
```