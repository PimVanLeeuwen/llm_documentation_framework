`execFromFile`: The function of `execFromFile` is to execute a series of commands from a file.

**Parameters**: 
`string input_file`: This parameter specifies the path to the file containing the commands to be executed.

**Code Description**: 
The code reads a file line by line, and for each line, it calls the `processCommand` method with the current line as an argument.\\
## Code: 
```
void CommandLineTool::execFromFile(string input_file){
    std::ifstream infile(input_file);
    std::string input_line;
    while (std::getline(infile, input_line))
    {
        this->processCommand(input_line);
    }

}
```