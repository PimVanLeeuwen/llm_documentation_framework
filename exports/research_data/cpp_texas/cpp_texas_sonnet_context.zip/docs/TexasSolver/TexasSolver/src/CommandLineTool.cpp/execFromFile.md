`execFromFile`: The function of `execFromFile` is to read and process commands from a specified input file.

**Parameters**:
`string input_file`: The path to the file containing commands to be executed.

**Code Description**: This method opens the specified input file using an `ifstream` object. It then reads the file line by line using a while loop and `std::getline`. For each line read from the file, it calls the `processCommand` method, passing the line as an argument. This allows the function to execute a series of commands stored in a file, effectively automating the command processing for the Texas Hold'em poker solver.\\
## Code: 
```
void CommandLineTool::execFromFile(string input_file){
    std::ifstream infile(input_file);
    std::string input_line;
    while (std::getline(infile, input_line))
    {
        this->processCommand(input_line);
    }

}
```