`printNodeHistory`: The function of `printNodeHistory` is to print the history of actions and chance events leading to a given node in the game tree.

**Parameters**:
`GameTreeNode* node`: A pointer to the current node in the game tree for which the history needs to be printed.

**Code Description**: This method is currently commented out and not functional. If implemented, it would traverse the game tree backwards from the given node to the root, printing information about each parent node along the way. For action nodes, it would print the player and the action taken. For chance nodes, it would print the card dealt. The method would use a while loop to move up the tree, checking the type of each parent node (ActionNode or ChanceNode) and printing the relevant information. The history would be printed in reverse order, with each step preceded by an arrow "<-". The method would terminate when it reaches a node with no parent (the root of the tree).\\
## Code: 
```
void GameTreeNode::printNodeHistory(GameTreeNode* node) {
    /*
    while(node != nullptr) {
        shared_ptr<GameTreeNode>parent_node = node->parent;
        if (parent_node == nullptr) break;
        if(parent_node instanceof ActionNode){
            ActionNode action_node = (ActionNode)parent_node;
            for(int i = 0;i < action_node.getActions().size();i ++){
                if(action_node.getChildrens().get(i) == node){
                    System.out.print(String.format("<- (player %s %s)",
                                                   action_node.getPlayer(),
                                                   action_node.getActions().get(i).toString()
                    ));
                }
            }
        }else if(parent_node instanceof ChanceNode) {
            ChanceNode chance_node = (ChanceNode)parent_node;
            for(int i = 0;i < chance_node.getChildrens().size();i ++){
                if(chance_node.getChildrens().get(i) == node){
                    System.out.print(String.format("<- (deal card %s)",
                                                   chance_node.getCards().get(i).toString()
                    ));
                }
            }

        }else{
            System.out.print(String.format("<- (%s)",node.toString()));
        }
        node = parent_node;
    }
    System.out.println()
    }
     */
}
```