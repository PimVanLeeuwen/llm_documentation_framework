`saving`: The function of `saving` is to save the current strategy to a JSON file.

**Code Description**: This method begins by logging a debug message indicating that a JSON file is being saved. It then retrieves the 'dump_round' value from the application settings, storing it in the `dump_rounds` member variable. The method logs the dump round value and provides a warning if it's set to 3, indicating potential performance issues. Depending on the game mode (HOLDEM or SHORTDECK), it calls the appropriate `dump_strategy` method on either `ps_holdem` or `ps_shortdeck` objects, passing the `savefile` and `dump_rounds` as parameters. Finally, it logs a message indicating that the saving process is complete. This method appears to be part of a larger poker solver application, specifically handling the strategy saving functionality for different poker variants.\\
## Code: 
```
void QSolverJob::saving(){
    qDebug().noquote() << tr("Saving json file..");//.toStdString() << std::endl;

    QSettings setting("TexasSolver", "Setting");
    setting.beginGroup("solver");
    this->dump_rounds = setting.value("dump_round").toInt();

    qDebug().noquote() << tr("Dump round: ") << this->dump_rounds;
    if(this->dump_rounds == 3){
        qDebug().noquote() << tr("This could be slow, or even blow your RAM, dump to river is not well optimized :(");
    }
    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.dump_strategy(this->savefile,this->dump_rounds);
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.dump_strategy(this->savefile,this->dump_rounds);
    }
    qDebug().noquote() << tr("Saving done.");//.toStdString() << std::endl;
}
```