`TerminalNode`: The function of `TerminalNode` is to initialize a terminal node in a game tree for a Texas Hold'em poker game.

**Parameters**:
`vector<double> payoffs`: A vector containing the payoffs for each player at this terminal node.
`int winner`: The index of the winning player at this terminal node.
`GameTreeNode::GameRound round`: The game round in which this terminal node occurs.
`double pot`: The total amount of money in the pot at this terminal node.
`shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node in the game tree.

**Code Description**: This constructor initializes a `TerminalNode` object, which is a derived class of `GameTreeNode`. It first calls the base class constructor `GameTreeNode(round, pot, parent)` to set up the common attributes. Then, it assigns the `payoffs` vector to the corresponding member variable, storing the payoff information for each player. Finally, it sets the `winner` member variable to the index of the winning player. This node represents an end state in the game tree where the game has concluded, and the payoffs and winner are determined.\\
## Code: 
```
TerminalNode::TerminalNode(vector<double> payoffs, int winner, GameTreeNode::GameRound round, double pot,
                           shared_ptr<GameTreeNode> parent):GameTreeNode(round,pot,parent){
    this->payoffs = payoffs;
    this->winner = winner;
}
```