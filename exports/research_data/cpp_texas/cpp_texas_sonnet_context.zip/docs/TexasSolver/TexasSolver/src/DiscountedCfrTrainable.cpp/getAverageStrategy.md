`getAverageStrategy`: The function of `getAverageStrategy` is to calculate and return the average strategy for each action and private card combination.

**Code Description**: This method computes the average strategy based on cumulative regret values stored in `cum_r_plus`. It initializes a vector `average_strategy` with size `action_number * card_number`. For each private card, it calculates the sum of cumulative regrets across all actions. Then, for each action, it computes the probability by dividing the cumulative regret for that action by the sum. If the sum is zero, it assigns equal probability to all actions. The resulting `average_strategy` vector represents the probability distribution over actions for each private card, which is then returned.\\
## Code: 
```
const vector<float> DiscountedCfrTrainable::getAverageStrategy() {
    vector<float> average_strategy;
    average_strategy = vector<float>(this->action_number * this->card_number);
    for (int private_id = 0; private_id < this->card_number; private_id++) {
        float r_plus_sum = 0;
        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            r_plus_sum += this->cum_r_plus[index];
        }

        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            if(r_plus_sum) {
                average_strategy[index] = this->cum_r_plus[index] / r_plus_sum;
            }else{
                average_strategy[index] = 1.0 / this->action_number;
            }
        }
    }
    return average_strategy;
}
```