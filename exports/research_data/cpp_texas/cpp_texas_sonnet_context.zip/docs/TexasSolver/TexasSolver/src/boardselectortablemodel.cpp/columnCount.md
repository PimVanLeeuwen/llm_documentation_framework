`columnCount`: The function of `columnCount` is to return the number of columns in the table model.

**Parameters**:
`const QModelIndex &parent`: A reference to the parent model index, which is not used in this implementation.

**Code Description**: This method is a part of the `BoardSelectorTableModel` class and implements the `columnCount` function required by Qt's model/view framework. It returns the size of the `ranklist` member variable, which represents the number of columns in the table model. The `parent` parameter is not used in this implementation, suggesting that this model does not have a hierarchical structure. The function is declared as `const`, indicating that it does not modify the object's state.\\
## Code: 
```
int BoardSelectorTableModel::columnCount(const QModelIndex &parent) const {
    return this->ranklist.size();
}
```