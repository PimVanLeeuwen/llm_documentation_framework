`copyStrategy`: The function of `copyStrategy` is to copy the strategy data from another DiscountedCfrTrainable object to the current object.

**Parameters**:
`shared_ptr<Trainable> other_trainable`: A shared pointer to another Trainable object, expected to be a DiscountedCfrTrainable object.

**Code Description**: This method first performs a dynamic cast to convert the input `other_trainable` to a `DiscountedCfrTrainable` object. It then copies the contents of two vectors, `r_plus` and `cum_r_plus`, from the input object to the corresponding vectors in the current object. The `assign` method is used for both vectors to copy all elements, effectively replacing the current object's strategy data with that of the input object.\\
## Code: 
```
void DiscountedCfrTrainable::copyStrategy(shared_ptr<Trainable> other_trainable){
    shared_ptr<DiscountedCfrTrainable> trainable = dynamic_pointer_cast<DiscountedCfrTrainable>(other_trainable);
    this->r_plus.assign(trainable->r_plus.begin(),trainable->r_plus.end());
    this->cum_r_plus.assign(trainable->cum_r_plus.begin(),trainable->cum_r_plus.end());
}
```