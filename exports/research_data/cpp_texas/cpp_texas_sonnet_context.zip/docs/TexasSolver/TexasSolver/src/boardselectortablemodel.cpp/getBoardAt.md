`getBoardAt`: The function of `getBoardAt` is to retrieve a float value from a 2D grid at the specified coordinates.

**Parameters**:
`int i`: The row index of the grid.
`int j`: The column index of the grid.

**Code Description**: This method is part of the `BoardSelectorTableModel` class and is designed to safely access elements in a 2D float array called `grids_float`. It first checks if the provided indices `i` and `j` are within valid bounds (0 to `ranklist.size() - 1`). If either index is out of bounds, it logs a debug message with the invalid index and returns 0. If both indices are valid, it returns the float value stored at `grids_float[i][j]`. This approach ensures that array access is safe and prevents potential crashes due to out-of-bounds errors.\\
## Code: 
```
float BoardSelectorTableModel::getBoardAt(int i, int j){
    if(i < 0 || i >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::getBoardAt i not valid: " << i;
        return 0;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::getBoardAt j not valid: " << j;
        return 0;
    }
    else{
        return this->grids_float[i][j];
    }
}
```