`StreetSetting`: The function of `StreetSetting` is to initialize a StreetSetting object with betting parameters.

**Parameters**:
`vector<float> bet_sizes`: A vector of float values representing the available bet sizes.
`vector<float> raise_sizes`: A vector of float values representing the available raise sizes.
`vector<float> donk_sizes`: A vector of float values representing the available donk bet sizes.
`bool allin`: A boolean flag indicating whether an all-in bet is allowed.

**Code Description**: This constructor initializes a StreetSetting object by assigning the input parameters to the corresponding member variables of the class. It sets the bet sizes, raise sizes, and donk sizes using the provided vectors, and sets the all-in flag with the given boolean value. This allows the object to store and manage various betting options and rules for a specific street in a poker game.\\
## Code: 
```
StreetSetting::StreetSetting(vector<float> bet_sizes, vector<float> raise_sizes, vector<float> donk_sizes,
                             bool allin) {
    this->bet_sizes = bet_sizes;
    this->raise_sizes = raise_sizes;
    this->donk_sizes = donk_sizes;
    this->allin = allin;
}
```