`DetailWindowSetting`: The function of `DetailWindowSetting` is to initialize the default mode of a detail window.

**Code Description**: This is a constructor for the `DetailWindowSetting` class. It sets the initial value of the `mode` member variable to `DetailWindowMode::STRATEGY`. This suggests that the class is used to manage settings for a detail window, with different modes of operation. The default mode is set to "STRATEGY", which likely determines how information is displayed or processed in the detail window when it is first created or opened.\\
## Code: 
```
DetailWindowSetting::DetailWindowSetting(){
    this->mode = DetailWindowMode::STRATEGY;
}
```