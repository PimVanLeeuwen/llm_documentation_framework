`stop`: The function of `stop` is to halt the execution of the solver based on the current game mode.

**Code Description**: This method is responsible for stopping the solver's operation. It first logs a debug message indicating an attempt to stop the solver. Then, it checks the current game mode (stored in the `mode` member variable) and calls the appropriate `stop()` method on the corresponding solver object. If the mode is `Mode::HOLDEM`, it calls `stop()` on the `ps_holdem` object. If the mode is `Mode::SHORTDECK`, it calls `stop()` on the `ps_shortdeck` object. This design allows the method to handle different game types (Texas Hold'em and Short Deck) using the same interface.\\
## Code: 
```
void QSolverJob::stop(){
    qDebug().noquote() << tr("Trying to stop solver.");
    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.stop();
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.stop();
    }
}
```