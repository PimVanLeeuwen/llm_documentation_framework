`load`: The function of `load` is to read and load data from a binary file into two maps.

**Parameters**:
`const char* file_path`: A C-style string representing the path to the binary file to be loaded.

**Code Description**: This method loads data from a binary file into two maps: `flush_map` and `other_map`. It uses Qt's QFile for file operations. The function first clears both maps, then opens the specified file in read-only mode. If the file can't be opened, it throws a runtime error. The function reads the number of entries for each map, then iterates through the file, reading key-value pairs (uint64_t for keys, int for values) and inserting them into the respective maps. It uses assert statements to verify that the number of entries read matches the expected count. The function returns true if the loading process is successful.\\
## Code: 
```
bool FiveCardsStrength::load(const char* file_path) {
    //ifstream file(file_path, ios::binary);
    /*if (!file) {
        file.close();
        return false;
    }*/

    QFile file(QString::fromStdString(file_path));
    if (!file.open(QIODevice::ReadOnly)){
        throw runtime_error("unable to load compairer file");
    }
    flush_map.clear(); other_map.clear();
    int size_key = sizeof(uint64_t), size_int = sizeof(int), val, cnt = 0;
    uint64_t key = 0;
    char* p_key = (char*)&key, * p_val = (char*)&val, * p_cnt = (char*)&cnt;
    file.read(p_cnt, size_int);// 读取行数
    for (int i = 0; i < cnt; i++) {
        file.read(p_key, size_key);
        file.read(p_val, size_int);
        flush_map[key] = val;
    }
    assert(flush_map.size() == cnt);
    file.read(p_cnt, size_int);// 读取行数
    for (int i = 0; i < cnt; i++) {
        file.read(p_key, size_key);
        file.read(p_val, size_int);
        other_map[key] = val;
    }
    assert(other_map.size() == cnt);
    file.close();
    return true;
}
```