`PCfrSolver`: The function of `PCfrSolver` is to initialize a Poker Counterfactual Regret Minimization (CFR) solver.

**Parameters**:
`shared_ptr<GameTree> tree`: A shared pointer to the game tree structure
`vector<PrivateCards> range1`: The range of private cards for player 1
`vector<PrivateCards> range2`: The range of private cards for player 2
`vector<int> initial_board`: The initial board cards
`shared_ptr<Compairer> compairer`: A shared pointer to a card comparison object
`Deck deck`: The deck of cards
`int iteration_number`: The number of iterations for the CFR algorithm
`bool debug`: A flag to enable debug mode
`int print_interval`: The interval for printing progress
`string logfile`: The path to the log file
`string trainer`: The type of trainer being used
`Solver::MonteCarolAlg monteCarolAlg`: The Monte Carlo algorithm to be used
`int warmup`: The number of warmup iterations
`float accuracy`: The desired accuracy for the solver
`bool use_isomorphism`: A flag to enable isomorphism
`int use_halffloats`: A flag to use half-precision floats
`int num_threads`: The number of threads to use for parallel processing

**Code Description**: This constructor initializes a PCfrSolver object with the given parameters. It sets up the initial game state, including the board and player ranges, and configures various solver settings. The constructor removes duplicate cards from the ranges, initializes the RiverRangeManager and PrivateCardsManager, and sets up multithreading parameters. It also determines the split round for parallel processing based on the root round of the game tree. The solver is prepared for CFR iterations with the specified number of iterations, debug settings, and logging options. The use of isomorphism and half-precision floats is configured based on the input parameters. The constructor also sets up the necessary data structures for managing private cards and ranges throughout the solving process.\\
## Code: 
```
PCfrSolver::PCfrSolver(shared_ptr<GameTree> tree, vector<PrivateCards> range1, vector<PrivateCards> range2,
                     vector<int> initial_board, shared_ptr<Compairer> compairer, Deck deck, int iteration_number, bool debug,
                     int print_interval, string logfile, string trainer, Solver::MonteCarolAlg monteCarolAlg,int warmup,float accuracy,bool use_isomorphism,int use_halffloats,int num_threads) :Solver(tree){
    this->initial_board = initial_board;
    this->initial_board_long = Card::boardInts2long(initial_board);
    this->logfile = logfile;
    this->trainer = trainer;
    this->warmup = warmup;

    range1 = this->noDuplicateRange(range1,initial_board_long);
    range2 = this->noDuplicateRange(range2,initial_board_long);

    this->range1 = range1;
    this->range2 = range2;
    this->player_number = 2;
    this->ranges = vector<vector<PrivateCards>>(this->player_number);
    this->ranges[0] = range1;
    this->ranges[1] = range2;

    this->compairer = compairer;

    this->deck = deck;
    this->use_isomorphism = use_isomorphism;
    this->use_halffloats = use_halffloats;

    this->rrm = RiverRangeManager(compairer);
    this->iteration_number = iteration_number;

    vector<vector<PrivateCards>> private_cards(this->player_number);
    private_cards[0] = range1;
    private_cards[1] = range2;
    pcm = PrivateCardsManager(private_cards,this->player_number,Card::boardInts2long(this->initial_board));
    this->debug = debug;
    this->print_interval = print_interval;
    this->monteCarolAlg = monteCarolAlg;
    this->accuracy = accuracy;
    if(num_threads == -1){
        num_threads = omp_get_num_procs();
    }
    qDebug().noquote() << QString::fromStdString(tfm::format(QObject::tr("Using %s threads").toStdString().c_str(),num_threads));
    this->num_threads = num_threads;
    this->distributing_task = false;
    omp_set_num_threads(this->num_threads);
    setTrainable(this->tree->getRoot());
    this->root_round = this->tree->getRoot()->getRound();
    if(this->root_round == GameTreeNode::GameRound::PREFLOP){
        this->split_round = GameTreeNode::GameRound::FLOP;
    }else if(this->root_round == GameTreeNode::GameRound::FLOP){
        this->split_round = GameTreeNode::GameRound::TURN;
    }else if(this->root_round == GameTreeNode::GameRound::TURN){
        this->split_round = GameTreeNode::GameRound::RIVER;
    }else{
        // do not use multithread in river, really not necessary
        this->split_round = GameTreeNode::GameRound::PREFLOP;
    }
}
```