`DiscountedCfrTrainable`: The function of `DiscountedCfrTrainable` is to initialize a discounted counterfactual regret minimization (CFR) trainable object for Texas Hold'em poker.

**Parameters**:
`vector<PrivateCards> *privateCards`: A pointer to a vector of PrivateCards objects, representing the possible private card combinations in the game.
`ActionNode &actionNode`: A reference to an ActionNode object, representing the current node in the game tree.

**Code Description**: This constructor initializes a DiscountedCfrTrainable object with the given private cards and action node. It sets up the necessary data structures for the CFR algorithm:

1. Stores the privateCards pointer and the reference to the action_node.
2. Calculates the number of actions (action_number) based on the children of the action node.
3. Sets the card_number to the size of the privateCards vector.
4. Initializes vectors for expected values (evs), positive regrets (r_plus), cumulative positive regrets (cum_r_plus), and sums of positive regrets (r_plus_sum) with appropriate sizes and initial values.

These data structures are essential for implementing the discounted CFR algorithm, which is used to compute optimal strategies in imperfect information games like poker. The method prepares the object for subsequent training and strategy computation.\\
## Code: 
```
DiscountedCfrTrainable::DiscountedCfrTrainable(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();

    this->evs = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus_sum = vector<float>(this->card_number,0.0);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number,0.0);
    //this->cum_r_plus_sum = vector<float>(this->card_number);
}
```