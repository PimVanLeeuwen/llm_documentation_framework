`reGenerateTreeItem`: The function of `reGenerateTreeItem` is to recursively regenerate the tree structure for a given game round.

**Parameters**:
`GameTreeNode::GameRound round`: The specific game round for which the tree structure is being regenerated.
`TreeItem* node_to_process`: The current tree item node being processed in the regeneration.

**Code Description**: This method recursively rebuilds the tree structure for a specific game round. It processes each node based on its type (ACTION or CHANCE). For ACTION nodes, it iterates through all child nodes, creates new TreeItems for each, and recursively calls itself for children of the same round. For CHANCE nodes, it creates a single child TreeItem and continues the recursion. The method uses dynamic casting to handle different node types and manages shared pointers for memory efficiency. It builds the tree structure by inserting child nodes into their respective parents using the `insertChild` method. The recursion continues until all relevant nodes for the specified round have been processed, effectively regenerating the portion of the tree structure corresponding to the given game round.\\
## Code: 
```
void TreeModel::reGenerateTreeItem(GameTreeNode::GameRound round,TreeItem* node_to_process){
    const shared_ptr<GameTreeNode> gameTreeNode = node_to_process->m_treedata.lock();
    if(gameTreeNode->getType() == GameTreeNode::GameTreeNodeType::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(gameTreeNode);
        vector<shared_ptr<GameTreeNode>>& childrens = actionNode->getChildrens();
        for(shared_ptr<GameTreeNode> one_child:childrens){
            TreeItem * child_node = new TreeItem(one_child,node_to_process);
            node_to_process->insertChild(child_node);
            if(one_child->getRound() != round){
                continue;
            }
            this->reGenerateTreeItem(round,child_node);
        }
    }
    else if(gameTreeNode->getType() == GameTreeNode::GameTreeNodeType::CHANCE){
        shared_ptr<ChanceNode> chanceNode = dynamic_pointer_cast<ChanceNode>(gameTreeNode);
        TreeItem * child_node = new TreeItem(chanceNode->getChildren(),node_to_process);
        node_to_process->insertChild(child_node);
        this->reGenerateTreeItem(round,child_node);
    }
}
```