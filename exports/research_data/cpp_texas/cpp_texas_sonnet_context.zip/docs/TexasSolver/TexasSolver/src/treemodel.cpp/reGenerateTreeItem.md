`reGenerateTreeItem`: The function of `reGenerateTreeItem` is to recursively regenerate the tree item for a given game round.

**Parameters**:
`GameTreeNode::GameRound round`: This parameter represents the current game round number.
`TreeItem* node_to_process`: This parameter points to the tree item that needs to be regenerated.

**Code Description**: The `reGenerateTreeItem` function takes two parameters: `round` and `node_to_process`. It first checks if the type of the game tree node associated with `node_to_process` is an action. If it is, it retrieves a vector of child nodes from the action node and iterates over them. For each child node, it creates a new tree item and inserts it into the current tree item's children list. It then recursively calls itself for each child node if its round number matches the given `round`. If the type of the game tree node is a chance, it retrieves a vector of child nodes from the chance node and iterates over them. For each child node, it creates a new tree item and inserts it into the current tree item's children list. It then recursively calls itself for each child node.\\
## Code: 
```
void TreeModel::reGenerateTreeItem(GameTreeNode::GameRound round,TreeItem* node_to_process){
    const shared_ptr<GameTreeNode> gameTreeNode = node_to_process->m_treedata.lock();
    if(gameTreeNode->getType() == GameTreeNode::GameTreeNodeType::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(gameTreeNode);
        vector<shared_ptr<GameTreeNode>>& childrens = actionNode->getChildrens();
        for(shared_ptr<GameTreeNode> one_child:childrens){
            TreeItem * child_node = new TreeItem(one_child,node_to_process);
            node_to_process->insertChild(child_node);
            if(one_child->getRound() != round){
                continue;
            }
            this->reGenerateTreeItem(round,child_node);
        }
    }
    else if(gameTreeNode->getType() == GameTreeNode::GameTreeNodeType::CHANCE){
        shared_ptr<ChanceNode> chanceNode = dynamic_pointer_cast<ChanceNode>(gameTreeNode);
        TreeItem * child_node = new TreeItem(chanceNode->getChildren(),node_to_process);
        node_to_process->insertChild(child_node);
        this->reGenerateTreeItem(round,child_node);
    }
}
```