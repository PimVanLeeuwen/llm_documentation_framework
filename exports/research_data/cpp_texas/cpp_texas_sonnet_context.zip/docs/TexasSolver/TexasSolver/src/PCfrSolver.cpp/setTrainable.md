`setTrainable`: The function of `setTrainable` is to recursively set up trainable components for nodes in a game tree.

**Parameters**:
`shared_ptr<GameTreeNode> root`: A shared pointer to the root node of the game tree or subtree to be processed.

**Code Description**: This method traverses the game tree starting from the given root node and sets up trainable components for action nodes. It handles different types of nodes:

1. For action nodes:
   - It determines the player and the current game round.
   - Based on the 'trainer' type (currently only supporting "discounted_cfr"), it sets up trainable components.
   - For "discounted_cfr", it calculates the number of trainable components based on the difference between the current round and the root round.
   - It then sets the trainable components for the action node using the calculated number and the player's private cards.
   - After setting up the current node, it recursively calls `setTrainable` on all child nodes.

2. For chance nodes:
   - It retrieves the child node and recursively calls `setTrainable` on it.

3. For terminal and showdown nodes:
   - No action is taken.

The method throws runtime errors for unsupported trainer types or unexpected game round gaps. It uses dynamic casting to convert the generic GameTreeNode pointer to specific node types (ActionNode or ChanceNode) when necessary. The code also includes commented-out sections for a "cfr_plus" trainer, which is currently not implemented.\\
## Code: 
```
void PCfrSolver::setTrainable(shared_ptr<GameTreeNode> root) {
    if(root->getType() == GameTreeNode::ACTION){
        shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(root);

        int player = action_node->getPlayer();

        if(this->trainer == "cfr_plus"){
            //vector<PrivateCards> player_privates = this->ranges[player];
            //action_node->setTrainable(make_shared<CfrPlusTrainable>(action_node,player_privates));
            throw runtime_error(tfm::format("trainer %s not supported",this->trainer));
        }else if(this->trainer == "discounted_cfr"){
            vector<PrivateCards>* player_privates = &this->ranges[player];
            //action_node->setTrainable(make_shared<DiscountedCfrTrainable>(action_node,player_privates));
            int num;
            GameTreeNode::GameRound gr = this->tree->getRoot()->getRound();
            int root_round = GameTreeNode::gameRound2int(gr);
            int current_round = GameTreeNode::gameRound2int(root->getRound());
            int gap = current_round - root_round;

            if(gap == 2) {
                num = this->deck.getCards().size() * this->deck.getCards().size() +
                          this->deck.getCards().size() + 1;
            }else if(gap == 1) {
                num = this->deck.getCards().size() + 1;
            }else if(gap == 0) {
                num =  1;
            }else{
                throw runtime_error("gap not understand");
            }
            action_node->setTrainable(vector<shared_ptr<Trainable>>(num),player_privates);
        }else{
            throw runtime_error(tfm::format("trainer %s not found",this->trainer));
        }

        vector<shared_ptr<GameTreeNode>> childrens =  action_node->getChildrens();
        for(shared_ptr<GameTreeNode> one_child:childrens) setTrainable(one_child);
    }else if(root->getType() == GameTreeNode::CHANCE) {
        shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(root);
        shared_ptr<GameTreeNode> children = chance_node->getChildren();
        setTrainable(children);
    }
    else if(root->getType() == GameTreeNode::TERMINAL){

    }else if(root->getType() == GameTreeNode::SHOWDOWN){

    }
}
```