`getTrainable`: The function of `getTrainable` is to retrieve a trainable object from the trainables vector at index i, or create and return one if it does not exist.

**Parameters**:
`int i`: The index of the trainable object in the trainables vector.
`bool create_on_site`: A flag indicating whether to create the trainable object on site if it does not exist.
`int use_halffloats`: An integer value that determines which type of trainable object to create, with values 0, 1, and 2 corresponding to DiscountedCfrTrainable, DiscountedCfrTrainableSF, and DiscountedCfrTrainableHF respectively.

**Code Description**: The function first checks if the index i is within the bounds of the trainables vector. If it is not, a runtime error is thrown. Then, it checks if the trainable object at index i is null and create_on_site is true. If both conditions are met, it creates a trainable object based on the value of use_halffloats and assigns it to the trainables vector at index i. Finally, it returns the trainable object at index i.\\
## Code: 
```
shared_ptr<Trainable> ActionNode::getTrainable(int i,bool create_on_site, int use_halffloats) {
    if(i > this->trainables.size()){
        throw runtime_error(tfm::format("size unacceptable %s > %s ",i,this->trainables.size()));
    }
    if(this->trainables[i] == nullptr && create_on_site){
        switch ((this->getRound() == GameTreeNode::RIVER) ? use_halffloats : 0 ){
        case 0:
            this->trainables[i] = make_shared<DiscountedCfrTrainable>(player_privates,*this);
            break;
        case 1:
            this->trainables[i] = make_shared<DiscountedCfrTrainableSF>(player_privates,*this);
            break;
        case 2:
            this->trainables[i] = make_shared<DiscountedCfrTrainableHF>(player_privates,*this);
            break;
        }
    }
    return this->trainables[i];
}
```