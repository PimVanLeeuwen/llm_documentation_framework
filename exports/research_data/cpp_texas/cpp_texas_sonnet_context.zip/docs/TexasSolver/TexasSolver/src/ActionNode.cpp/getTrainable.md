`getTrainable`: The function of `getTrainable` is to retrieve or create a Trainable object for a specific index.

**Parameters**:
`int i`: The index of the Trainable object to retrieve or create.
`bool create_on_site`: A flag indicating whether to create a new Trainable object if it doesn't exist.
`int use_halffloats`: An integer specifying the type of Trainable object to create (0 for DiscountedCfrTrainable, 1 for DiscountedCfrTrainableSF, 2 for DiscountedCfrTrainableHF).

**Code Description**: This method retrieves or creates a Trainable object from the `trainables` vector at the specified index. It first checks if the requested index is valid. If the Trainable object at the given index is null and `create_on_site` is true, it creates a new Trainable object based on the game round and `use_halffloats` parameter. For non-RIVER rounds, it always creates a DiscountedCfrTrainable object. For the RIVER round, it creates either a DiscountedCfrTrainable, DiscountedCfrTrainableSF, or DiscountedCfrTrainableHF object based on the `use_halffloats` value. The method then returns the Trainable object at the specified index.\\
## Code: 
```
shared_ptr<Trainable> ActionNode::getTrainable(int i,bool create_on_site, int use_halffloats) {
    if(i > this->trainables.size()){
        throw runtime_error(tfm::format("size unacceptable %s > %s ",i,this->trainables.size()));
    }
    if(this->trainables[i] == nullptr && create_on_site){
        switch ((this->getRound() == GameTreeNode::RIVER) ? use_halffloats : 0 ){
        case 0:
            this->trainables[i] = make_shared<DiscountedCfrTrainable>(player_privates,*this);
            break;
        case 1:
            this->trainables[i] = make_shared<DiscountedCfrTrainableSF>(player_privates,*this);
            break;
        case 2:
            this->trainables[i] = make_shared<DiscountedCfrTrainableHF>(player_privates,*this);
            break;
        }
    }
    return this->trainables[i];
}
```