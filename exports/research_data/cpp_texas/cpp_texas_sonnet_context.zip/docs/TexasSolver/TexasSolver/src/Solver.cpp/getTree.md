`getTree`: The function of `getTree` is to return the game tree stored in the Solver object.

**Code Description**: This method is a simple getter function that returns a shared pointer to the GameTree object stored as a member variable named `tree` in the Solver class. The use of a shared pointer (`shared_ptr`) suggests that the ownership of the GameTree object is shared, allowing multiple parts of the program to access and potentially modify the same game tree without worrying about memory management. The method doesn't perform any calculations or modifications; it simply provides access to the existing game tree.\\
## Code: 
```
shared_ptr<GameTree> Solver::getTree() {
    return this->tree;
}
```