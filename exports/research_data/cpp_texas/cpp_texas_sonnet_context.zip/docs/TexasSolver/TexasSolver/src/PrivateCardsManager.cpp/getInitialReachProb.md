`getInitialReachProb`: The function of `getInitialReachProb` is to calculate and return the initial reach probabilities for a player's private cards given an initial board state.

**Parameters**:
`int player`: The index of the player for whom to calculate the reach probabilities.
`uint64_t initialboard`: A 64-bit integer representing the initial board state.

**Code Description**: This method iterates through all possible private card combinations for the specified player. For each combination, it checks if there's an intersection between the initial board and the player's private cards. If there's an intersection, the probability is set to 0 (impossible hand). Otherwise, it assigns the weight of the private card combination as the probability. The method returns a vector of floats representing the reach probabilities for each possible private card combination of the player.

The function first determines the number of possible private card combinations for the player. It then creates a vector to store the probabilities. For each private card combination, it retrieves the cards and converts them to a 64-bit integer representation using `Card::boardInts2long`. It then checks for intersection with the initial board using `Card::boardsHasIntercept`. Based on this check, it either assigns 0 or the weight of the private card combination to the probability vector. Finally, it returns the vector of probabilities.\\
## Code: 
```
vector<float> PrivateCardsManager::getInitialReachProb(int player, uint64_t initialboard) {
    int cards_len =  this->private_cards[player].size();
    vector<float> probs = vector<float>(cards_len);
    for(int i = 0;i < cards_len;i ++){
        PrivateCards pc = this->private_cards[player][i];
        if(Card::boardsHasIntercept(initialboard,Card::boardInts2long(pc.get_hands()))) {
            probs[i] = 0;
        }else{
            probs[i] = this->private_cards[player][i].weight;
        }
    }
    return probs;
}
```