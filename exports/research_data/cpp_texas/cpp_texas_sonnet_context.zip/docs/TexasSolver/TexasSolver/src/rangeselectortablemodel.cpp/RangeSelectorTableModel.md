`RangeSelectorTableModel`: The function of `RangeSelectorTableModel` is to initialize a table model for representing poker hand ranges.

**Parameters**:
`QStringList ranks`: A list of card ranks used to generate the hand combinations.
`QString initial_board`: A string representing the initial range configuration.
`QObject *parent`: The parent object for the model in the Qt object hierarchy.
`bool thumbnail`: A flag indicating whether this is a thumbnail view.

**Code Description**: This constructor initializes a table model for poker hand ranges. It sets up a 2D grid representing all possible hand combinations based on the provided ranks. The grid is stored in two formats: `grids_string` for text representations and `grids_float` for numerical values. 

The constructor populates `grids_string` with hand combinations (e.g., "AKs" for Ace-King suited) using the `get_ij_text` method. It also creates a mapping (`string2ij`) from these text representations to their corresponding grid positions.

The `grids_float` is initialized with zeros, representing probabilities or weights for each hand combination. Finally, the constructor calls `setRangeText` with the `initial_board` parameter to set up the initial range configuration.

This model is designed to be used with Qt's Model/View framework, likely for displaying and manipulating poker hand ranges in a graphical user interface.\\
## Code: 
```
RangeSelectorTableModel::RangeSelectorTableModel(QStringList ranks,QString initial_board,QObject *parent,bool thumbnail):QAbstractItemModel(parent){
    this->ranklist = ranks;
    this->thumbnail = thumbnail;

    this->grids_string = vector<vector<QString>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_string[i] = vector<QString>(this->ranklist.size());
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_string[i][j] = this->get_ij_text(i,j);
            this->string2ij[this->get_ij_text(i,j)] = pair<int,int>(i,j);
        }
    }

    this->grids_float = vector<vector<float>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_float[i] = vector<float>(this->ranklist.size(),0.0);
    }
    this->setRangeText(initial_board);
}
```