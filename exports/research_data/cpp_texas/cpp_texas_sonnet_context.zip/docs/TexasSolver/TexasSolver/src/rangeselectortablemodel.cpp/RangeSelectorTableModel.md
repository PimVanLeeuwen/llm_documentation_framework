`RangeSelectorTableModel`: The function of `RangeSelectorTableModel` is to initialize and configure a table model for range selection, allowing users to interact with a grid of ranks.

**Parameters**:
`QStringList ranks`: A list of rank values used to populate the table.
`QString initial_board`: An input string specifying the initial state of the range selector table.
`QObject *parent`: The parent object of the table model (optional).
`bool thumbnail`: A boolean flag indicating whether a thumbnail representation is required.

**Code Description**: 
The `RangeSelectorTableModel` class initializes and configures a table model for range selection. It takes four parameters: `ranks`, `initial_board`, `parent`, and `thumbnail`. The code first sets up the rank list, grid string, and grid float data structures based on the provided ranks. Then, it calls the `setRangeText` method to parse the initial board input string and update the grid accordingly. Finally, it initializes the table model with the specified thumbnail flag.\\
## Code: 
```
RangeSelectorTableModel::RangeSelectorTableModel(QStringList ranks,QString initial_board,QObject *parent,bool thumbnail):QAbstractItemModel(parent){
    this->ranklist = ranks;
    this->thumbnail = thumbnail;

    this->grids_string = vector<vector<QString>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_string[i] = vector<QString>(this->ranklist.size());
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_string[i][j] = this->get_ij_text(i,j);
            this->string2ij[this->get_ij_text(i,j)] = pair<int,int>(i,j);
        }
    }

    this->grids_float = vector<vector<float>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_float[i] = vector<float>(this->ranklist.size(),0.0);
    }
    this->setRangeText(initial_board);
}
```