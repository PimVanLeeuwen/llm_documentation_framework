`getPreflopCards`: The function of `getPreflopCards` is to retrieve the preflop cards for a specific player.

**Parameters**:
`int player`: The index or identifier of the player whose preflop cards are being requested.

**Code Description**: This method is a member of the `PrivateCardsManager` class. It returns a reference to a vector of `PrivateCards` objects for the specified player. The cards are accessed from the `private_cards` member variable, which is likely a 2D vector or array storing the private cards for all players. The method simply returns the vector of private cards corresponding to the given player index.\\
## Code: 
```
vector<PrivateCards>& PrivateCardsManager::getPreflopCards(int player) {
    return this->private_cards[player];
}
```