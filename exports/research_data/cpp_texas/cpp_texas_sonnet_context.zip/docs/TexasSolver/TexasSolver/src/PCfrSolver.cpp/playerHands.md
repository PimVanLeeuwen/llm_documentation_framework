`playerHands`: The function of `playerHands` is to return the private cards (hand) of a specified player.

**Parameters**:
`int player`: An integer representing the player number (0 or 1).

**Code Description**: This method is part of the `PCfrSolver` class and retrieves the private cards for a given player. It takes a single parameter `player` to determine which player's hand to return. If `player` is 0, it returns `range1`, which presumably contains the private cards for player 1. If `player` is 1, it returns `range2`, which likely contains the private cards for player 2. If any other value is passed, the method throws a runtime error with the message "player not found". The private cards are stored as vectors of `PrivateCards` objects, suggesting that each player may have multiple possible hand combinations in their range.\\
## Code: 
```
const vector<PrivateCards> &PCfrSolver::playerHands(int player) {
    if(player == 0){
        return range1;
    }else if (player == 1){
        return range2;
    }else{
        throw runtime_error("player not found");
    }
}
```