`getcurrentStrategy`: The function of `getcurrentStrategy` is to return the current strategy of the DiscountedCfrTrainable object.

**Code Description**: This method is a simple wrapper that calls and returns the result of the `getcurrentStrategyNoCache()` method. It doesn't perform any additional computations or modifications to the strategy. The method returns a vector of float values representing the current strategy, which is obtained without using any caching mechanism. This approach ensures that the most up-to-date strategy is always returned, potentially at the cost of increased computation time compared to a cached version.\\
## Code: 
```
const vector<float> DiscountedCfrTrainable::getcurrentStrategy() {
    return this->getcurrentStrategyNoCache();
}
```