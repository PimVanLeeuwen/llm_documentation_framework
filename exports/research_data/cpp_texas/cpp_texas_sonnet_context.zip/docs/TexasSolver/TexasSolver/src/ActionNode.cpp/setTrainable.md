`setTrainable`: The function of `setTrainable` is to set the trainable objects and player private cards for an ActionNode.

**Parameters**:
`vector<shared_ptr<Trainable>> trainables`: A vector of shared pointers to Trainable objects.
`vector<PrivateCards>* player_privates`: A pointer to a vector of PrivateCards objects.

**Code Description**: This method assigns the provided trainable objects and player private cards to the corresponding member variables of the ActionNode class. It takes a vector of shared pointers to Trainable objects and assigns it to the `trainables` member variable. It also takes a pointer to a vector of PrivateCards objects and assigns it to the `player_privates` member variable. This allows the ActionNode to have access to these trainable objects and private cards for further processing or decision-making within the Texas Hold'em solver context.\\
## Code: 
```
void ActionNode::setTrainable(vector<shared_ptr<Trainable>> trainables,vector<PrivateCards>* player_privates) {
    this->trainables = trainables;
    this->player_privates = player_privates;
}
```