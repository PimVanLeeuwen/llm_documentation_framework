`isAllZeros`: The function of `isAllZeros` is to check if all elements in a given vector are zero.

**Parameters**:
`const vector<float>& input_array`: A constant reference to a vector of float values to be checked.

**Code Description**: The function iterates through each element in the input vector using a range-based for loop. It checks if any element is not equal to zero. If a non-zero element is found, the function immediately returns false. If the loop completes without finding any non-zero elements, the function returns true, indicating that all elements in the vector are zero.\\
## Code: 
```
bool DiscountedCfrTrainableSF::isAllZeros(const vector<float>& input_array) {
    for(float i:input_array){
        if (i != 0)return false;
    }
    return true;
}
```