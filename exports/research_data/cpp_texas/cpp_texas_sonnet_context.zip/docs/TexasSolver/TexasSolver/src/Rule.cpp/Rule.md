`Rule`: The function of `Rule` is to initialize a Rule object with given game parameters for Texas Hold'em poker.

**Parameters**:
`Deck deck`: The deck of cards being used in the game
`float oop_commit`: The amount committed by the out-of-position player
`float ip_commit`: The amount committed by the in-position player
`int current_round`: The current round of the game
`int raise_limit`: The maximum number of raises allowed
`float small_blind`: The amount of the small blind
`float big_blind`: The amount of the big blind
`float stack`: The initial stack size for players
`GameTreeBuildingSettings build_settings`: Settings for building the game tree
`float allin_threshold`: The threshold for considering a bet as an all-in

**Code Description**: This constructor initializes a Rule object with the provided game parameters. It sets up the initial state of the game, including the deck, player commitments, current round, raise limits, blinds, stack sizes, and game tree building settings. The constructor performs a check to ensure that the out-of-position (oop) commit is equal to the in-position (ip) commit, throwing a runtime error if they differ. It also sets the initial effective stack size. This Rule object likely serves as a foundation for managing the rules and state of a Texas Hold'em poker game simulation or analysis.\\
## Code: 
```
Rule::Rule(Deck deck, float oop_commit, float ip_commit, int current_round, int raise_limit, float small_blind,
           float big_blind, float stack, GameTreeBuildingSettings build_settings,float allin_threshold):
           deck(deck),oop_commit(oop_commit),ip_commit(ip_commit),current_round(current_round),raise_limit(raise_limit),
           small_blind(small_blind),big_blind(big_blind),stack(stack),build_settings(build_settings),allin_threshold(allin_threshold){
    if(oop_commit != ip_commit) throw runtime_error("ip commit should equal with oop commit");
    this->initial_effective_stack = stack;
}
```