`BoardSelectorTableModel`: The function of `BoardSelectorTableModel` is to initialize a table model for selecting cards on a poker board.

**Parameters**:
`QStringList ranks`: A list of card ranks (e.g., "2", "3", ..., "A").
`QString initial_board`: A string representing the initial board configuration.
`QObject *parent`: The parent object for the model in the Qt object hierarchy.

**Code Description**: This constructor initializes a `BoardSelectorTableModel` object, which is derived from `QAbstractItemModel`. It sets up a 2D grid representation of a deck of cards, with suits as rows and ranks as columns. The constructor performs the following tasks:

1. Stores the provided ranks and initializes a list of suits ("c", "d", "h", "s").
2. Creates a 2D vector `grids_string` to store string representations of each card (e.g., "2c" for 2 of clubs).
3. Populates `grids_string` and a map `string2ij` that associates card strings with their grid positions.
4. Initializes a 2D vector `grids_float` with the same dimensions as `grids_string`, filled with 0.0 values.
5. Calls `setBoardText` with the `initial_board` parameter to set up the initial board configuration.

This model can be used in a Qt application to display and interact with a poker board selection interface, where each cell represents a card that can be selected or deselected.\\
## Code: 
```
BoardSelectorTableModel::BoardSelectorTableModel(QStringList ranks,QString initial_board,QObject *parent):QAbstractItemModel(parent){
    this->ranklist = ranks;
    this->suitlist = QString("c,d,h,s").split(",");

    this->grids_string = vector<vector<QString>>(this->suitlist.size());
    for(int i = 0;i < this->suitlist.size();i ++){
        this->grids_string[i] = vector<QString>(this->ranklist.size());
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_string[i][j] = this->get_ij_text(i,j);
            this->string2ij[this->get_ij_text(i,j)] = pair<int,int>(i,j);
        }
    }

    this->grids_float = vector<vector<float>>(this->suitlist.size());
    for(int i = 0;i < this->suitlist.size();i ++){
        this->grids_float[i] = vector<float>(this->ranklist.size(),0.0);
    }
    this->setBoardText(initial_board);
}
```