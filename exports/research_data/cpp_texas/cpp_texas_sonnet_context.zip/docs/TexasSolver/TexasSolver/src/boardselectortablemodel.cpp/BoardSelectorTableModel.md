`BoardSelectorTableModel`: The function of `BoardSelectorTableModel` is to initialize a table model for selecting boards in a TexasSolver application.

**Parameters**:
`QStringList ranks`: A list of card ranks.
`QString initial_board`: The text representation of an initial board.
`QObject *parent`: The parent object of the table model.

**Code Description**: 
The code initializes a `BoardSelectorTableModel` by setting up a 2D grid structure to represent a deck of cards. It takes in a list of card ranks and an initial board text, which is parsed into individual grid values. The grid is represented as two separate data structures: one for string representation (`grids_string`) and another for floating-point values (`grids_float`). The `setBoardText` method is called to update the grid with the provided initial board text.\\
## Code: 
```
BoardSelectorTableModel::BoardSelectorTableModel(QStringList ranks,QString initial_board,QObject *parent):QAbstractItemModel(parent){
    this->ranklist = ranks;
    this->suitlist = QString("c,d,h,s").split(",");

    this->grids_string = vector<vector<QString>>(this->suitlist.size());
    for(int i = 0;i < this->suitlist.size();i ++){
        this->grids_string[i] = vector<QString>(this->ranklist.size());
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_string[i][j] = this->get_ij_text(i,j);
            this->string2ij[this->get_ij_text(i,j)] = pair<int,int>(i,j);
        }
    }

    this->grids_float = vector<vector<float>>(this->suitlist.size());
    for(int i = 0;i < this->suitlist.size();i ++){
        this->grids_float[i] = vector<float>(this->ranklist.size(),0.0);
    }
    this->setBoardText(initial_board);
}
```