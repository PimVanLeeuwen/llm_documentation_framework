`RoughStrategyItemDelegate`: The function of `RoughStrategyItemDelegate` is to initialize a custom item delegate for rough strategy items.

**Parameters**:
`DetailWindowSetting* detailWindowSetting`: A pointer to a DetailWindowSetting object that contains settings for the detail window.
`QObject *parent`: A pointer to the parent QObject, used for memory management in Qt's object hierarchy.

**Code Description**: This constructor initializes a `RoughStrategyItemDelegate` object. It inherits from `WordItemDelegate` and takes two parameters. The constructor sets the `detailWindowSetting` member variable to the provided `detailWindowSetting` pointer. This allows the delegate to access and use the detail window settings when rendering or interacting with rough strategy items in a view. The `parent` parameter is passed to the base class constructor of `WordItemDelegate`, which handles the standard Qt parent-child relationship for memory management.\\
## Code: 
```
RoughStrategyItemDelegate::RoughStrategyItemDelegate(DetailWindowSetting* detailWindowSetting,QObject *parent) :
    WordItemDelegate(parent)
{
    this->detailWindowSetting = detailWindowSetting;
}
```