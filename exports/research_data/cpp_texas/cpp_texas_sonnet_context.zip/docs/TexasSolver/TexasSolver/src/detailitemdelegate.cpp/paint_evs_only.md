`paint_evs_only`: The function of `paint_evs_only` is to render expected value (EV) information for a specific cell in a detail view.

**Parameters**:
`QPainter *painter`: A pointer to the QPainter object used for drawing on the widget.
`const QStyleOptionViewItem &option`: Contains style options for rendering the item.
`const QModelIndex &index`: Represents the model index of the item being painted.

**Code Description**: This method paints expected value (EV) information for a specific cell in a detail view. It first initializes style options and retrieves the DetailViewerModel. If the corresponding tree item is an ACTION node, it processes the EV data for the given grid position. The method calculates a normalized EV using the `normalization_tanh` function and determines a color based on this value. It then paints the cell background with this color. The cell content is set to display the card symbols (converted to HTML format) and the EV value. The text is formatted as HTML and rendered using a QTextDocument. The method handles edge cases and ensures that painting only occurs for valid data within the strategy table's bounds.\\
## Code: 
```
void DetailItemDelegate::paint_evs_only(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);

    const DetailViewerModel * detailViewerModel = qobject_cast<const DetailViewerModel*>(index.model());
    //vector<pair<GameActions,float>> strategy = detailViewerModel->tableStrategyModel->get_strategy(this->detailWindowSetting->grid_i,this->detailWindowSetting->grid_j);
    options.text = "";

    if(detailViewerModel->tableStrategyModel->treeItem != NULL &&
            detailViewerModel->tableStrategyModel->treeItem->m_treedata.lock()->getType() == GameTreeNode::GameTreeNode::ACTION){

        shared_ptr<GameTreeNode> node = detailViewerModel->tableStrategyModel->treeItem->m_treedata.lock();
        int strategy_number = 0;
        if(this->detailWindowSetting->grid_i >= 0 && this->detailWindowSetting->grid_j >= 0){
           strategy_number = detailViewerModel->tableStrategyModel->ui_strategy_table[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j].size();
        }

        vector<float> evs = detailViewerModel->tableStrategyModel->get_ev_grid(this->detailWindowSetting->grid_i,this->detailWindowSetting->grid_j);
        std::size_t ind = index.row() * detailViewerModel->columns + index.column();

        if(ind < evs.size() and ind < strategy_number)
        {
            float one_ev = evs[ind];
            float normalized_ev = normalization_tanh(detailViewerModel->tableStrategyModel->get_solver()->stack,one_ev);
            //options.text += QString("</br>%1").arg(QString::number(normalized_ev));

            pair<int,int> strategy_ui_table = detailViewerModel->tableStrategyModel->ui_strategy_table[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j][ind];
            int card1 = strategy_ui_table.first;
            int card2 = strategy_ui_table.second;

            int red = max((int)(255 - normalized_ev * 255),0);
            int green = min((int)(normalized_ev * 255),255);
            int blue = min(red, green);
            QBrush brush = QBrush(QColor(red,green,blue));

            // draw background for flod
            QRect rect(option.rect.left(), option.rect.top(),
             option.rect.width(), option.rect.height());
            painter->fillRect(rect, brush);

            options.text = "";
            options.text += detailViewerModel->tableStrategyModel->cardint2card[card1].toFormattedHtml();
            options.text += detailViewerModel->tableStrategyModel->cardint2card[card2].toFormattedHtml();
            options.text = "<h2>" + options.text + "<\/h2>";

            options.text +=  QString(" <h2>%1<\/h2>").arg(QString::number(one_ev,'f',3));
        }
    }

    QTextDocument doc;
    doc.setHtml(options.text);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```