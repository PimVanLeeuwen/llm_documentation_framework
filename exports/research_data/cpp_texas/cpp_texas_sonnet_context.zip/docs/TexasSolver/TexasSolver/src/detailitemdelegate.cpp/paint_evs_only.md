`paint_evs_only`: The function of `paint_evs_only` is to paint a detail item in a view with expected values only.

**Parameters**:
`QPainter *painter`: A pointer to a QPainter object used for painting.
`const QStyleOptionViewItem &option`: A reference to a QStyleOptionViewItem object containing information about the item being painted.
`const QModelIndex &index`: A reference to a QModelIndex object representing the index of the item in the model.

**Code Description**: The `paint_evs_only` function is a method of the DetailItemDelegate class. It takes a QPainter, a QStyleOptionViewItem, and a QModelIndex as parameters. The function initializes a copy of the QStyleOptionViewItem object and sets its text to an empty string. If the table strategy model has a tree item with an action type and the index row is within the bounds of the expected value grid, it retrieves the expected values for the current game state from the table-based strategy model using a grid structure. It then normalizes the expected value using the `normalization_tanh` function and uses this normalized value to determine the color of the background rectangle. The function draws a background rectangle with the determined color and sets the text of the QStyleOptionViewItem object to display the cards involved in the action and the expected value. Finally, it translates the painter to the position of the item being painted and draws the contents of the QStyleOptionViewItem object using the QTextDocument class.\\
## Code: 
```
void DetailItemDelegate::paint_evs_only(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);

    const DetailViewerModel * detailViewerModel = qobject_cast<const DetailViewerModel*>(index.model());
    //vector<pair<GameActions,float>> strategy = detailViewerModel->tableStrategyModel->get_strategy(this->detailWindowSetting->grid_i,this->detailWindowSetting->grid_j);
    options.text = "";

    if(detailViewerModel->tableStrategyModel->treeItem != NULL &&
            detailViewerModel->tableStrategyModel->treeItem->m_treedata.lock()->getType() == GameTreeNode::GameTreeNode::ACTION){

        shared_ptr<GameTreeNode> node = detailViewerModel->tableStrategyModel->treeItem->m_treedata.lock();
        int strategy_number = 0;
        if(this->detailWindowSetting->grid_i >= 0 && this->detailWindowSetting->grid_j >= 0){
           strategy_number = detailViewerModel->tableStrategyModel->ui_strategy_table[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j].size();
        }

        vector<float> evs = detailViewerModel->tableStrategyModel->get_ev_grid(this->detailWindowSetting->grid_i,this->detailWindowSetting->grid_j);
        std::size_t ind = index.row() * detailViewerModel->columns + index.column();

        if(ind < evs.size() and ind < strategy_number)
        {
            float one_ev = evs[ind];
            float normalized_ev = normalization_tanh(detailViewerModel->tableStrategyModel->get_solver()->stack,one_ev);
            //options.text += QString("</br>%1").arg(QString::number(normalized_ev));

            pair<int,int> strategy_ui_table = detailViewerModel->tableStrategyModel->ui_strategy_table[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j][ind];
            int card1 = strategy_ui_table.first;
            int card2 = strategy_ui_table.second;

            int red = max((int)(255 - normalized_ev * 255),0);
            int green = min((int)(normalized_ev * 255),255);
            int blue = min(red, green);
            QBrush brush = QBrush(QColor(red,green,blue));

            // draw background for flod
            QRect rect(option.rect.left(), option.rect.top(),
             option.rect.width(), option.rect.height());
            painter->fillRect(rect, brush);

            options.text = "";
            options.text += detailViewerModel->tableStrategyModel->cardint2card[card1].toFormattedHtml();
            options.text += detailViewerModel->tableStrategyModel->cardint2card[card2].toFormattedHtml();
            options.text = "<h2>" + options.text + "<\/h2>";

            options.text +=  QString(" <h2>%1<\/h2>").arg(QString::number(one_ev,'f',3));
        }
    }

    QTextDocument doc;
    doc.setHtml(options.text);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```