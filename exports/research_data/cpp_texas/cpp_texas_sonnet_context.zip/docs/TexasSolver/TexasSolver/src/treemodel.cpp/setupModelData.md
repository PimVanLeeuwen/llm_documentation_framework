`setupModelData`: The function of `setupModelData` is to initialize and set up the tree model data structure for a poker solver.

**Code Description**: This method initializes the tree model data structure for either a Texas Hold'em or Short Deck poker game. It first determines which solver to use based on the game mode stored in `qSolverJob`. If the game tree or its root is not available, the method returns early. Otherwise, it creates the root item of the tree model using the game tree's root node. It then creates a child item for the root and recursively generates the rest of the tree structure by calling `reGenerateTreeItem`. The method handles potential runtime errors if an incorrect game mode is specified. This setup process is crucial for representing the game state and possible actions in a tree-like structure, which is likely used for game analysis or strategy computation in the poker solver.\\
## Code: 
```
void TreeModel::setupModelData()
{
    PokerSolver * solver;
    if(this->qSolverJob->mode == QSolverJob::Mode::HOLDEM){
        solver = &(this->qSolverJob->ps_holdem);
    }else if(this->qSolverJob->mode == QSolverJob::Mode::SHORTDECK){
        solver = &(this->qSolverJob->ps_shortdeck);
    }else{
        throw runtime_error("holdem mode incorrect");
    }

    if(solver->get_game_tree() == nullptr || solver->get_game_tree()->getRoot() == nullptr){
        return;
    }

    GameTreeNode::GameRound round =	solver->get_game_tree()->getRoot()->getRound();

    this->rootItem = new TreeItem(solver->get_game_tree()->getRoot());
    TreeItem* ti = new TreeItem(solver->get_game_tree()->getRoot(),this->rootItem);
    rootItem->insertChild(ti);
    this->reGenerateTreeItem(round,ti);
}
```