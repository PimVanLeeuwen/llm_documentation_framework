`setupModelData`: The function of `setupModelData` is to set up the model data for a tree structure, specifically in the context of a poker game.

**Code Description**: This function appears to be part of a larger system that constructs and updates a graphical representation of a game's decision tree. It retrieves relevant information from a PokerSolver object based on the current mode (Hold'em or ShortDeck), checks if the game tree is valid, and then generates the tree structure by recursively calling the `reGenerateTreeItem` method. The function also inserts child items into the tree structure using the `insertChild` method of the TreeItem class.\\
## Code: 
```
void TreeModel::setupModelData()
{
    PokerSolver * solver;
    if(this->qSolverJob->mode == QSolverJob::Mode::HOLDEM){
        solver = &(this->qSolverJob->ps_holdem);
    }else if(this->qSolverJob->mode == QSolverJob::Mode::SHORTDECK){
        solver = &(this->qSolverJob->ps_shortdeck);
    }else{
        throw runtime_error("holdem mode incorrect");
    }

    if(solver->get_game_tree() == nullptr || solver->get_game_tree()->getRoot() == nullptr){
        return;
    }

    GameTreeNode::GameRound round =	solver->get_game_tree()->getRoot()->getRound();

    this->rootItem = new TreeItem(solver->get_game_tree()->getRoot());
    TreeItem* ti = new TreeItem(solver->get_game_tree()->getRoot(),this->rootItem);
    rootItem->insertChild(ti);
    this->reGenerateTreeItem(round,ti);
}
```