`ChanceNode`: The function of `ChanceNode` is to construct a ChanceNode object representing a chance event in a game tree.

**Parameters**:
`const shared_ptr<GameTreeNode> children`: A shared pointer to the child node(s) of this ChanceNode.
`GameTreeNode::GameRound round`: The current round of the game.
`double pot`: The current pot size in the game.
`shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node of this ChanceNode.
`const vector<Card>& cards`: A vector of Card objects representing the cards associated with this chance event.
`bool donk`: A boolean flag indicating whether this is a donk bet situation.

**Code Description**: This constructor initializes a ChanceNode object, which is derived from GameTreeNode. It sets up the node with the given game round, pot size, and parent node by calling the base class constructor. The constructor then assigns the provided children to the node's children member, stores the vector of cards, and sets the donk flag. This node represents a point in the game where a chance event occurs, such as dealing community cards in Texas Hold'em poker.\\
## Code: 
```
ChanceNode::ChanceNode(const shared_ptr<GameTreeNode> children, GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent,
                       const vector<Card>& cards,bool donk): GameTreeNode(round,pot,std::move(parent)),cards(cards) {
    this->children = children;
    this->donk = donk;
}
```