`columnCount`: The function of `columnCount` is to return the number of columns in the table model.

**Parameters**:
`const QModelIndex &parent`: This parameter is unused in the function.

**Code Description**: This method is part of the TableStrategyModel class and implements the columnCount function required by Qt's model/view framework. It returns the number of columns in the table model, which corresponds to the number of card ranks in the poker deck. The function retrieves this information by accessing the solver object through the qSolverJob member, then getting the deck object, and finally calling the getRanks() method to obtain the vector of ranks. The size of this vector determines the number of columns in the model.\\
## Code: 
```
int TableStrategyModel::columnCount(const QModelIndex &parent) const
{
    return this->qSolverJob->get_solver()->get_deck()->getRanks().size();
}
```