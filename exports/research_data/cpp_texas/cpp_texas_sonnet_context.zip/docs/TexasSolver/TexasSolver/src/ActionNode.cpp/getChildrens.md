`getChildrens`: The function of `getChildrens` is to return a reference to the vector of child nodes.

**Code Description**: This method is a simple getter function that returns a reference to the `childrens` member variable of the `ActionNode` class. The `childrens` variable is a vector of shared pointers to `GameTreeNode` objects, representing the child nodes of the current action node in a game tree. By returning a reference, the function allows direct access to the vector of child nodes, enabling the caller to read or modify the children without creating a copy of the vector.\\
## Code: 
```
vector<shared_ptr<GameTreeNode>>& ActionNode::getChildrens() {
    return this->childrens;
}
```