`getAmount`: The function of `getAmount` is to return the value of the `amount` member variable.

**Code Description**: This is a simple getter method in the `GameActions` class. It returns the `amount` stored in the object as a `double` value. The method doesn't take any parameters and doesn't modify any object state. It's a straightforward accessor that allows other parts of the program to retrieve the current `amount` value associated with this `GameActions` instance.\\
## Code: 
```
double GameActions::getAmount() {
    return this->amount;
}
```