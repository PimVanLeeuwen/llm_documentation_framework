`indPlayer2Player`: The function of `indPlayer2Player` is to map a card index from one player to another player's corresponding card index.

**Parameters**:
`int from_player`: The index of the player whose card is being mapped.
`int to_player`: The index of the player to whom the card is being mapped.
`int index`: The index of the card in the `from_player`'s hand.

**Code Description**: This method first checks if the provided index is valid by comparing it with the size of the `from_player`'s preflop cards. If the index is out of range, it throws a runtime error. Then, it uses the `hashCode()` of the card at the given index in the `from_player`'s hand to look up the corresponding index in the `to_player`'s hand using the `card_player_index` data structure. If a matching card is found in the `to_player`'s hand, its index is returned. If no matching card is found, the method returns -1. This function is likely used in game situations where it's necessary to track the same card across different players' hands, such as in card dealing or hand comparison scenarios.\\
## Code: 
```
int PrivateCardsManager::indPlayer2Player(int from_player, int to_player, int index) {
    if(index < 0 || index >= this->getPreflopCards(from_player).size()) throw runtime_error("index out of range");
    //PrivateCards player_combo = this->getPreflopCards(from_player)[index];
    int to_player_index = this->card_player_index[this->private_cards[from_player][index].hashCode()][to_player];
    if(to_player_index == -1){
        return -1;
    }else {
        return to_player_index;
    }
}
```