`paint`: The function of `paint` is to render a custom cell in a table view with a colored background and card text.

**Parameters**:
`QPainter *painter`: The painter object used for drawing operations
`const QStyleOptionViewItem &option`: Contains style options for the item being painted
`const QModelIndex &index`: Represents the model index of the item being painted

**Code Description**: This method customizes the appearance of a cell in a table view. It first fills the entire cell with a gray background. Then, it calculates a yellow portion of the cell based on a board float value, which is retrieved from the boardSelectorTableModel. The yellow portion is drawn from the bottom of the cell, with its height determined by the board float value.

The method then creates a QTextDocument to render the card text in HTML format. It uses the Card class to convert the text to formatted HTML, which likely includes suit symbols and colors. Finally, it draws the formatted card text within the cell.

The painting process involves saving and restoring the painter's state, translating the painter to the correct position, and using clipping to ensure the text stays within the cell boundaries. This custom painting allows for a visual representation of probabilities (through the colored portions of the cell) alongside the card information.\\
## Code: 
```
void BoardSelectorTableDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const{

    painter->save();
    auto options = option;
    initStyleOption(&options, index);

    QRect rect(option.rect.left(), option.rect.top(),\
             option.rect.width(), option.rect.height());
    QBrush brush(Qt::gray);
    painter->fillRect(rect, brush);

    float board_float = this->boardSelectorTableModel->getBoardAt(index.row(),index.column());

    float fold_prob = 1 - board_float;
    int disable_height = (int)(fold_prob * option.rect.height());
    int remain_height = option.rect.height() - disable_height;

    rect = QRect(option.rect.left(), option.rect.top() + disable_height,\
     option.rect.width(), remain_height);
    brush = QBrush(Qt::yellow);
    painter->fillRect(rect, brush);

    QTextDocument doc;
    doc.setHtml(Card(options.text.toStdString()).toFormattedHtml());

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
    painter->restore();
}
```