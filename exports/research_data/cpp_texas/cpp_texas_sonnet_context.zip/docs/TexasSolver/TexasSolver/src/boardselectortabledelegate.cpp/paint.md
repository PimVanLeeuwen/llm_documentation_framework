`paint`: The function of `paint` is to draw a table item in the BoardSelectorTableDelegate class, representing a card from a deck.

**Parameters**:
`QPainter *painter`: A pointer to a QPainter object used for drawing.
`const QStyleOptionViewItem &option`: A reference to a QStyleOptionViewItem object containing information about the item being painted.
`const QModelIndex &index`: A reference to a QModelIndex object representing the index of the item in the model.

**Code Description**: The `paint` function saves the current painter state, initializes a style option from the provided index, and sets up a rectangle for drawing. It then fills this rectangle with a gray brush to represent the folded part of the card. The function retrieves the board value at the specified index from the BoardSelectorTableModel and calculates the height of the folded part based on this value. A yellow brush is used to fill the remaining rectangle, representing the visible part of the card. Finally, the function draws the card's text using a QTextDocument object and restores the painter state.\\
## Code: 
```
void BoardSelectorTableDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const{

    painter->save();
    auto options = option;
    initStyleOption(&options, index);

    QRect rect(option.rect.left(), option.rect.top(),\
             option.rect.width(), option.rect.height());
    QBrush brush(Qt::gray);
    painter->fillRect(rect, brush);

    float board_float = this->boardSelectorTableModel->getBoardAt(index.row(),index.column());

    float fold_prob = 1 - board_float;
    int disable_height = (int)(fold_prob * option.rect.height());
    int remain_height = option.rect.height() - disable_height;

    rect = QRect(option.rect.left(), option.rect.top() + disable_height,\
     option.rect.width(), remain_height);
    brush = QBrush(Qt::yellow);
    painter->fillRect(rect, brush);

    QTextDocument doc;
    doc.setHtml(Card(options.text.toStdString()).toFormattedHtml());

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
    painter->restore();
}
```