`loading`: The function of `loading` is to initialize and load comparison files for both Texas Hold'em and Short Deck poker variants.

**Code Description**: This method sets up the necessary resources for poker hand comparisons in both Texas Hold'em and Short Deck poker. It defines the suits and ranks for cards, specifies file paths for comparison data, and creates PokerSolver objects for each variant.

The method first sets the resource directory and outputs a debug message about loading the Hold'em comparison file. It then defines the ranks for standard poker (2 through Ace) and specifies the file paths for the Hold'em comparison data. A PokerSolver object for Hold'em is created using these parameters.

Next, it repeats a similar process for Short Deck poker, defining the ranks (6 through Ace), specifying the file paths for Short Deck comparison data, and creating a PokerSolver object for Short Deck.

The method uses hardcoded values for the number of lines in each comparison file (2,598,961 for Hold'em and 376,993 for Short Deck). It concludes by outputting a debug message indicating that loading is complete.\\
## Code: 
```
void QSolverJob::loading(){
    string suits = "c,d,h,s";
    string ranks;
    this->resource_dir =  ":/resources";
    string compairer_file, compairer_file_bin;
    int lines;
    qDebug().noquote() << tr("Loading holdem compairing file");//.toStdString() << endl;
    //if(mode == "holdem"){
    ranks = "2,3,4,5,6,7,8,9,T,J,Q,K,A";
    compairer_file = this->resource_dir + "/compairer/card5_dic_sorted.txt";
    compairer_file_bin = this->resource_dir + "/compairer/card5_dic_zipped.bin";
    //qDebug().noquote() << compairer_file_bin.c_str();
    lines = 2598961;
    this->ps_holdem = PokerSolver(ranks,suits,compairer_file,lines,compairer_file_bin);

    qDebug().noquote() << tr("Loading shortdeck compairing file");//.toStdString() << endl;
    //}else if(mode == "shortdeck"){
    ranks = "6,7,8,9,T,J,Q,K,A";
    compairer_file = this->resource_dir + "/compairer/card5_dic_sorted_shortdeck.txt";
    compairer_file_bin = this->resource_dir + "/compairer/card5_dic_zipped_shortdeck.bin";
    lines = 376993;
    this->ps_shortdeck = PokerSolver(ranks,suits,compairer_file,lines,compairer_file_bin);
    qDebug().noquote() << tr("Loading finished. Good to go.");//.toStdString() << endl;
}
```