`GameTreeBuildingSettings`: The function of `GameTreeBuildingSettings` is to initialize a game tree building settings object with specific street settings for different positions and streets in a Texas Hold'em poker game.

**Parameters**:
`StreetSetting flop_ip`: Settings for the flop street when in position
`StreetSetting turn_ip`: Settings for the turn street when in position
`StreetSetting river_ip`: Settings for the river street when in position
`StreetSetting flop_oop`: Settings for the flop street when out of position
`StreetSetting turn_oop`: Settings for the turn street when out of position
`StreetSetting river_oop`: Settings for the river street when out of position

**Code Description**: This is a constructor for the `GameTreeBuildingSettings` class. It takes six parameters, each of type `StreetSetting`, representing different streets (flop, turn, river) and positions (in position, out of position) in a Texas Hold'em poker game. The constructor uses an initialization list to set the corresponding member variables of the class with the provided parameters. This allows for the creation of a `GameTreeBuildingSettings` object with specific settings for each street and position combination, which can be used to configure the building of a game tree for poker strategy analysis or simulation.\\
## Code: 
```
GameTreeBuildingSettings::GameTreeBuildingSettings(
        StreetSetting flop_ip,
        StreetSetting turn_ip,
        StreetSetting river_ip,
        StreetSetting flop_oop,
        StreetSetting turn_oop,
        StreetSetting river_oop):flop_ip(flop_ip),turn_ip(turn_ip),river_ip(river_ip),flop_oop(flop_oop),turn_oop(turn_oop),river_oop(river_oop) {
}
```