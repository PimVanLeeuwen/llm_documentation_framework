`setRelativeProbs`: The function of `setRelativeProbs` is to calculate and set the relative probabilities of private cards for each player in a Texas Hold'em poker game.

**Code Description**: This method iterates through each player's possible private cards and calculates their relative probabilities based on the opponent's possible hands. It considers two players, using their private cards and the initial board state. The process involves:

1. Iterating through each player's possible private cards.
2. Converting the player's cards to a 64-bit integer representation.
3. Checking for conflicts with the initial board, skipping if there's an overlap.
4. For each valid player hand, it then iterates through the opponent's possible hands:
   - Converting the opponent's cards to a 64-bit integer.
   - Checking for conflicts with the initial board and the player's hand.
   - If no conflicts, adding the opponent's hand weight to a sum.
5. Calculating the relative probability for the player's hand by multiplying the opponent's probability sum with the player's hand weight.
6. Summing up all relative probabilities for the player.
7. Normalizing the relative probabilities by dividing each by the total sum.

The method handles the complexity of considering card conflicts and weights to produce accurate relative probabilities for each possible private hand. These probabilities are essential for strategic decision-making in poker simulations or analysis.\\
## Code: 
```
void PrivateCardsManager::setRelativeProbs() {
    int players = this->private_cards.size();
    for(int player_id = 0; player_id < players;player_id ++){
        // TODO 这里只考虑了两个玩家的情况
        int oppo = 1 - player_id;
        float player_prob_sum = 0;

        for(std::size_t i = 0;i < this->private_cards[player_id].size();i ++) {
            float oppo_prob_sum = 0;
            PrivateCards* player_card = &this->private_cards[player_id][i];
            uint64_t player_long = Card::boardInts2long(player_card->get_hands());

            //
            if (Card::boardsHasIntercept(player_long,this->initialboard)){
                continue;
            }

            for (auto oppo_card : this->private_cards[oppo]) {
                uint64_t oppo_long = Card::boardInts2long(oppo_card.get_hands());
                if (Card::boardsHasIntercept(oppo_long,this->initialboard)
                    || Card::boardsHasIntercept(oppo_long,player_long)
                        ){
                    continue;
                }
                oppo_prob_sum += oppo_card.weight;

            }
            player_card->relative_prob = oppo_prob_sum * player_card->weight;
            player_prob_sum += player_card->relative_prob;
        }
        for(std::size_t i = 0;i < this->private_cards[player_id].size();i ++) {
            this->private_cards[player_id][i].relative_prob = this->private_cards[player_id][i].relative_prob / player_prob_sum;
            //player_card.relative_prob = player_card.relative_prob / player_prob_sum;
        }

    }
}
```