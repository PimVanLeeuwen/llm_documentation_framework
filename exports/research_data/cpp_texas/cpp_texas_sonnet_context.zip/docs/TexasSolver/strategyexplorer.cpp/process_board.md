`process_board`: The function of `process_board` is to update the board display with the current game state.

**Parameters**:
`TreeItem* treeitem`: A pointer to a TreeItem object representing the current game state node.

**Code Description**: This method processes the board state and updates the UI accordingly. It first splits the board string into individual card strings and converts them to Card objects. If a valid TreeItem is provided, it checks the game round and adds Turn and River cards if applicable. Finally, it updates the UI's boardLabel with an HTML representation of the board cards. The method handles different game rounds (TURN and RIVER) by conditionally adding cards based on the current state of the game tree node.\\
## Code: 
```
void StrategyExplorer::process_board(TreeItem* treeitem){
    vector<string> board_str_arr = string_split(this->qSolverJob->board,',');
    vector<Card> cards;
    for(string one_board_str:board_str_arr){
        cards.push_back(Card(one_board_str));
    }
    if(treeitem != NULL){
        if(treeitem->m_treedata.lock()->getRound() == GameTreeNode::GameRound::TURN && !this->tableStrategyModel->getTrunCard().empty()){
            cards.push_back(Card(this->tableStrategyModel->getTrunCard()));
        }
        else if(treeitem->m_treedata.lock()->getRound() == GameTreeNode::GameRound::RIVER){
            if(!this->tableStrategyModel->getTrunCard().empty())
                cards.push_back(Card(this->tableStrategyModel->getTrunCard()));
            if(!this->tableStrategyModel->getRiverCard().empty())
                cards.push_back(Card(this->tableStrategyModel->getRiverCard()));
        }
    }
    this->ui->boardLabel->setText(QString("<b>%1: </b>").arg(tr("board")) + Card::boardCards2html(cards));
}
```