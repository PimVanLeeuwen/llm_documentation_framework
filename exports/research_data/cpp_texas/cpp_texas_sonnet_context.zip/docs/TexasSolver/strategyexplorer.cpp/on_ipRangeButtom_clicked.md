`on_ipRangeButtom_clicked`: The function of `on_ipRangeButtom_clicked` is to update the detail window setting mode to RANGE_IP and refresh the views.

**Code Description**: When the ipRangeButtom button is clicked, this method updates the detail window setting mode to RANGE_IP. It then triggers an update on the strategy table view, detail view, and rough strategy viewer model, causing them to refresh their contents. This ensures that the user interface remains up-to-date with the current state of the data being displayed.\\
## Code: 
```
void StrategyExplorer::on_ipRangeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::RANGE_IP;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```