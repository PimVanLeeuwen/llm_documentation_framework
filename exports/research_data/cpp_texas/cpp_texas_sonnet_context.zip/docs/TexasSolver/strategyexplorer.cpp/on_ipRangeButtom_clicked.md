`on_ipRangeButtom_clicked`: The function of `on_ipRangeButtom_clicked` is to update the display mode and refresh various UI components when the IP range button is clicked.

**Code Description**: This method is triggered when an IP range button is clicked in the StrategyExplorer interface. It performs the following actions:

1. Sets the `mode` of `detailWindowSetting` to `RANGE_IP`, indicating that the detail window should display information related to IP ranges.

2. Calls `update()` on the viewport of `strategyTableView` to refresh its display.

3. Calls `update()` on the viewport of `detailView` to refresh its display.

4. Invokes the `onchanged()` method of `roughStrategyViewerModel`, which likely updates the model's data or notifies listeners of changes.

5. Calls `update()` on the viewport of `roughStrategyView` to refresh its display.

These actions collectively ensure that the user interface is updated to reflect the new IP range mode and that all relevant components are refreshed to display the appropriate information.\\
## Code: 
```
void StrategyExplorer::on_ipRangeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::RANGE_IP;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```