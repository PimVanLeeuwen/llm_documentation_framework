`on_evOnlyModeButtom_clicked`: The function of `on_evOnlyModeButtom_clicked` is to update the detail window setting mode to EV_ONLY when the "EV Only Mode" button is clicked.

**Code Description**: When the "EV Only Mode" button is clicked, this function updates the detail window setting mode to EV_ONLY. It then updates the viewport of several UI elements: the strategy table view, the detail view, and the rough strategy viewer model's header data. The `onchanged` method of the rough strategy viewer model is called to update its contents, and finally, the viewport of the rough strategy view is updated.\\
## Code: 
```
void StrategyExplorer::on_evOnlyModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::EV_ONLY;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```