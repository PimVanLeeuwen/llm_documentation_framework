`item_clicked`: The function of `item_clicked` is to process a tree click event in the strategy explorer.

**Parameters**: 
`const QModelIndex& index`: This parameter represents the index of the item that was clicked in the tree view.

**Code Description**: When an item is clicked, this function retrieves the TreeItem associated with the index and calls several other functions to update the game state and display relevant information. It processes the board by adding table strategy cards if applicable, updates a UI label based on the type of game node clicked, sets a new game tree node in the TableStrategyModel object, updates the strategy data in the model, and triggers a resize event in the rough strategy view to update its layout. If any errors occur during this process, it catches the exception and logs an error message.\\
## Code: 
```
void StrategyExplorer::item_clicked(const QModelIndex& index){
    try{
        TreeItem * treeNode = static_cast<TreeItem*>(index.internalPointer());
        this->process_treeclick(treeNode);
        this->process_board(treeNode);
        this->tableStrategyModel->setGameTreeNode(treeNode);
        this->tableStrategyModel->updateStrategyData();
        this->ui->strategyTableView->viewport()->update();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->triger_resize();
        this->ui->roughStrategyView->viewport()->update();
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```