`item_clicked`: The function of `item_clicked` is to handle the user's click on an item in a tree view and update various UI components accordingly.

**Parameters**:
`const QModelIndex& index`: The model index of the clicked item in the tree view.

**Code Description**: This method is triggered when a user clicks on an item in a tree view. It first retrieves the TreeItem pointer associated with the clicked index. Then, it performs several actions:

1. Calls `process_treeclick` to handle the tree item click, likely updating UI elements based on the selected node.
2. Calls `process_board` to update the game board display with the current state.
3. Updates the `tableStrategyModel` with the new game tree node and refreshes its data.
4. Triggers a viewport update for the strategy table view.
5. Calls `onchanged` for the `roughStrategyViewerModel` to signal data changes.
6. Triggers a resize and viewport update for the rough strategy view.

The method is wrapped in a try-catch block to handle any runtime errors, printing debug information if an exception occurs. This comprehensive update ensures that all relevant UI components reflect the newly selected game tree node, providing a synchronized view of the game state and strategy information.\\
## Code: 
```
void StrategyExplorer::item_clicked(const QModelIndex& index){
    try{
        TreeItem * treeNode = static_cast<TreeItem*>(index.internalPointer());
        this->process_treeclick(treeNode);
        this->process_board(treeNode);
        this->tableStrategyModel->setGameTreeNode(treeNode);
        this->tableStrategyModel->updateStrategyData();
        this->ui->strategyTableView->viewport()->update();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->triger_resize();
        this->ui->roughStrategyView->viewport()->update();
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```