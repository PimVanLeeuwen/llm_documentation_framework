`on_evModeButtom_clicked`: The function of `on_evModeButtom_clicked` is to switch the detail window mode to EV (Expected Value) and update related views.

**Code Description**: This method is triggered when an EV mode button is clicked in the StrategyExplorer interface. It sets the mode of the detailWindowSetting to EV (Expected Value) mode. After changing the mode, it updates three different views: the strategy table view, the detail view, and the rough strategy view. This is done by calling the update() method on each view's viewport, which triggers a repaint of the visible area. The purpose of these updates is likely to refresh the displayed information to reflect the newly selected EV mode.\\
## Code: 
```
void StrategyExplorer::on_evModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::EV;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->ui->roughStrategyView->viewport()->update();
}
```