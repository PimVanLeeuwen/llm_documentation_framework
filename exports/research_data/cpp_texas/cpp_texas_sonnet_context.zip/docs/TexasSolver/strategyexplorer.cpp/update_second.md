`update_second`: The function of `update_second` is to update various UI components and process the poker board when there are cards in the game.

**Code Description**: When the number of cards in the game exceeds zero, `update_second` updates the strategy data in the table strategy model, triggers a change event in the rough strategy viewer model, updates the viewport of several UI components (including the rough strategy view and detail view), and processes the poker board by adding relevant table strategy cards.\\
## Code: 
```
void StrategyExplorer::update_second(){
    if(this->cards.size() > 0){
        this->tableStrategyModel->updateStrategyData();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```