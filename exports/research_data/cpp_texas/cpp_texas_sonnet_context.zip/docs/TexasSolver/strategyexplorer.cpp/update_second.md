`update_second`: The function of `update_second` is to refresh and update various UI components and strategy models based on the current game state.

**Code Description**: This method first checks if there are any cards in play. If so, it updates the strategy data in the table strategy model, triggers changes in the rough strategy viewer model, and refreshes the rough strategy view's viewport. It then processes the current board state using the table strategy model's tree item. Regardless of whether there are cards or not, the method updates the viewports of the strategy table view and detail view. This ensures that all relevant UI components reflect the most current game state and strategy information, providing an up-to-date visual representation for the user.\\
## Code: 
```
void StrategyExplorer::update_second(){
    if(this->cards.size() > 0){
        this->tableStrategyModel->updateStrategyData();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```