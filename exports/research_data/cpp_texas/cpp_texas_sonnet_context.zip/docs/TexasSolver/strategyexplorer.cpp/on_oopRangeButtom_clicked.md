`on_oopRangeButtom_clicked`: The function of `on_oopRangeButtom_clicked` is to update the strategy explorer interface when the out-of-position (OOP) range button is clicked.

**Code Description**: This method is triggered when the OOP range button is clicked in the StrategyExplorer interface. It performs the following actions:

1. Sets the `mode` of `detailWindowSetting` to `RANGE_OOP`, indicating that the detail window should display the out-of-position range.

2. Calls `update()` on the viewport of `strategyTableView` to refresh its display.

3. Calls `update()` on the viewport of `detailView` to refresh its display.

4. Invokes the `onchanged()` method of `roughStrategyViewerModel`, which likely updates the model and emits signals to notify of changes.

5. Calls `update()` on the viewport of `roughStrategyView` to refresh its display.

These actions collectively refresh the user interface components to reflect the new OOP range selection, ensuring that all relevant views are updated to show the appropriate information for the out-of-position range strategy.\\
## Code: 
```
void StrategyExplorer::on_oopRangeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::RANGE_OOP;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```