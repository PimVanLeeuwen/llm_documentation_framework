`on_strategyModeButtom_clicked`: The function of `on_strategyModeButtom_clicked` is to update the detail window setting mode to strategy and refresh the corresponding views.

**Code Description**: When the strategy mode button is clicked, this function updates the detail window setting mode to strategy. It then refreshes the strategy table view, detail view, and rough strategy viewer by calling their respective viewport update methods. Additionally, it calls the onchanged method of the rough strategy viewer model to update its header data.\\
## Code: 
```
void StrategyExplorer::on_strategyModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::STRATEGY;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```