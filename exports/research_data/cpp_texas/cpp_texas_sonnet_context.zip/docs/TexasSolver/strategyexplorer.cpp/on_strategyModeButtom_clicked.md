`on_strategyModeButtom_clicked`: The function of `on_strategyModeButtom_clicked` is to switch the detail window to strategy mode and update related views.

**Code Description**: This method is triggered when a strategy mode button is clicked. It sets the `mode` of `detailWindowSetting` to `STRATEGY`, indicating a change in the display mode. The method then updates several UI components:

1. It updates the viewport of the strategy table view.
2. It updates the viewport of the detail view.
3. It calls the `onchanged()` method of the `roughStrategyViewerModel`, which likely refreshes the model's data.
4. Finally, it updates the viewport of the rough strategy view.

These updates ensure that all relevant parts of the user interface reflect the change to strategy mode, providing a consistent and responsive user experience.\\
## Code: 
```
void StrategyExplorer::on_strategyModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::STRATEGY;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```