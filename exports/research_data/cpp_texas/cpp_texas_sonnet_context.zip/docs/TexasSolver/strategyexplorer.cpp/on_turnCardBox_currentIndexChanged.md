`on_turnCardBox_currentIndexChanged`: The function of `on_turnCardBox_currentIndexChanged` is to update the table strategy model and process the poker board when a new card is selected from the turn card box.

**Parameters**:\
`int index`: The index of the selected card in the cards list, used to retrieve the corresponding card object.

**Code Description**: When a new card is selected from the turn card box, this function updates the table strategy model by setting the selected card as the turn card and updating the strategy data. It then processes the poker board by splitting it into individual cards, adding relevant table strategy cards if applicable, and displaying the resulting card list in HTML format on a UI label. The function also updates the progress bar and detail view to reflect the new state of the game.\\
## Code: 
```
void StrategyExplorer::on_turnCardBox_currentIndexChanged(int index)
{
    if(this->cards.size() > 0 && index < this->cards.size()){
        this->tableStrategyModel->setTrunCard(this->cards[index]);
        this->tableStrategyModel->updateStrategyData();
        // TODO this somehow cause bugs, crashes, why?
        //this->roughStrategyViewerModel->onchanged();
        //this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```