`on_turnCardBox_currentIndexChanged`: The function of `on_turnCardBox_currentIndexChanged` is to update the strategy and display when a new turn card is selected.

**Parameters**:
`int index`: The index of the newly selected turn card in the combo box.

**Code Description**: This method is triggered when the user selects a different turn card from a combo box. It first checks if there are cards available and if the selected index is valid. If so, it updates the turn card in the table strategy model using `setTrunCard` and then calls `updateStrategyData` to recalculate the strategy based on the new turn card. The method then processes the updated board state using `process_board`. Finally, it refreshes the display of the strategy table view and detail view. There's a commented-out section that suggests updating a rough strategy viewer, but it's currently disabled due to potential bugs or crashes.\\
## Code: 
```
void StrategyExplorer::on_turnCardBox_currentIndexChanged(int index)
{
    if(this->cards.size() > 0 && index < this->cards.size()){
        this->tableStrategyModel->setTrunCard(this->cards[index]);
        this->tableStrategyModel->updateStrategyData();
        // TODO this somehow cause bugs, crashes, why?
        //this->roughStrategyViewerModel->onchanged();
        //this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```