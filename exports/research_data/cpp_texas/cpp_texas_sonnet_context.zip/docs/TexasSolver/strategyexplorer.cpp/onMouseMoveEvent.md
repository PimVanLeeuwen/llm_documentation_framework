`onMouseMoveEvent`: The function of `onMouseMoveEvent` is to update the display when the mouse moves over the strategy explorer grid.

**Parameters**:
`int i`: The row index of the grid cell where the mouse is currently positioned.
`int j`: The column index of the grid cell where the mouse is currently positioned.

**Code Description**: This method is triggered when the mouse moves over the strategy explorer grid. It updates the `detailWindowSetting` object with the current grid coordinates (`i` and `j`) where the mouse is positioned. Then, it calls the `update()` method on the viewports of both the `detailView` and `strategyTableView` UI elements. This causes these views to refresh their display, likely to show detailed information about the strategy at the current mouse position. The method enables real-time feedback as the user explores different parts of the strategy grid with their mouse.\\
## Code: 
```
void StrategyExplorer::onMouseMoveEvent(int i,int j){
    this->detailWindowSetting.grid_i = i;
    this->detailWindowSetting.grid_j = j;
    this->ui->detailView->viewport()->update();
    this->ui->strategyTableView->viewport()->update();
}
```