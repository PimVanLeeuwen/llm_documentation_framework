`on_riverCardBox_currentIndexChanged`: The function of `on_riverCardBox_currentIndexChanged` is to update the table strategy model with a new river card when the user selects a different card from the river card box.

**Parameters**:\
`int index`: This parameter represents the index of the selected river card in the cards list.

**Code Description**: When the function is called, it first checks if there are any cards in the list and if the selected index is within the bounds of the list. If both conditions are met, it sets the current river card to the one at the specified index using `tableStrategyModel->setRiverCard(this->cards[index])`. It then updates the strategy data by calling `tableStrategyModel->updateStrategyData()`. Additionally, it processes the board by calling `process_board(this->tableStrategyModel->treeItem)`, which likely involves adding relevant table strategy cards to the board. Finally, it updates the UI by calling `this->ui->strategyTableView->viewport()->update()` and `this->ui->detailView->viewport()->update()`.\\
## Code: 
```
void StrategyExplorer::on_riverCardBox_currentIndexChanged(int index)
{
    if(this->cards.size() > 0  && index < this->cards.size()){
        this->tableStrategyModel->setRiverCard(this->cards[index]);
        this->tableStrategyModel->updateStrategyData();
        //this->roughStrategyViewerModel->onchanged();
        //this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```