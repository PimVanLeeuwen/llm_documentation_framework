`on_riverCardBox_currentIndexChanged`: The function of `on_riverCardBox_currentIndexChanged` is to update the strategy and UI elements when a new river card is selected.

**Parameters**:
`int index`: The index of the newly selected river card in the combo box.

**Code Description**: This method is triggered when the user selects a different river card from a combo box. It first checks if there are cards available and if the selected index is valid. If so, it updates the river card in the table strategy model, recalculates the strategy data, and processes the game board with the new card. Finally, it refreshes the strategy table view and detail view in the user interface. The method ensures that the displayed strategy and game state are consistent with the newly selected river card.\\
## Code: 
```
void StrategyExplorer::on_riverCardBox_currentIndexChanged(int index)
{
    if(this->cards.size() > 0  && index < this->cards.size()){
        this->tableStrategyModel->setRiverCard(this->cards[index]);
        this->tableStrategyModel->updateStrategyData();
        //this->roughStrategyViewerModel->onchanged();
        //this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```