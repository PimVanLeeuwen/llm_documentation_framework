`item_expanded`: The function of `item_expanded` is to expand child items in a tree view when a parent item is expanded.

**Parameters**:
`const QModelIndex& index`: The model index of the expanded item in the tree view.

**Code Description**: This method is called when an item in the tree view is expanded. It iterates through all the immediate children of the expanded item. For each child that doesn't have any children of its own (i.e., it hasn't been expanded before), it calls the `reGenerateTreeItem` method of the tree model to populate that child with its own children. This process uses the game round information obtained from the child's associated tree data. The method ensures that only unexpanded children are processed, skipping those that already have child items.\\
## Code: 
```
void StrategyExplorer::item_expanded(const QModelIndex& index){
    TreeItem *item = static_cast<TreeItem*>(index.internalPointer());
    int num_child = item->childCount();
    for (int i = 0;i < num_child;i ++){
        TreeItem* one_child = item->child(i);
        if(one_child->childCount() != 0)continue;
        this->ui->gameTreeView->tree_model->reGenerateTreeItem(one_child->m_treedata.lock()->getRound(),one_child);
    }
}
```