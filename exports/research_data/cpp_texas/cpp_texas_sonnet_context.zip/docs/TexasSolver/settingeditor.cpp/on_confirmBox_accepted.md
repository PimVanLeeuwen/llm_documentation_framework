`on_confirmBox_accepted`: The function of `on_confirmBox_accepted` is to save user-selected settings for language and dump round to the application's configuration.

**Code Description**: This method is triggered when a confirmation box is accepted. It uses QSettings to store configuration data for the "TexasSolver" application. The method begins by creating a settings group called "solver". It then retrieves the selected language from a UI element (languageBox) and converts it to a two-letter code ("EN" for English, "CN" for Chinese). If an unknown language is selected, it logs an error message. The language setting is saved using the key "language". Next, it retrieves the selected round number from another UI element (roundBox), converts it to an integer, and saves it with the key "dump_round". These settings are presumably used elsewhere in the application to control language display and some form of round-based functionality.\\
## Code: 
```
void SettingEditor::on_confirmBox_accepted()
{
    QSettings setting("TexasSolver", "Setting");
    setting.beginGroup("solver");
    QString lang = this->ui->languageBox->currentText();
    QString language_str;
    if(lang == "English"){
        language_str = "EN";
    }else if(lang == "Chinese"){
        language_str = "CN";
    }else{
        qDebug().noquote() << tr("Unknown language: ") << lang << tr("Setting fail");
    }
    setting.setValue("language",language_str);

    int round = this->ui->roundBox->currentText().toInt();
    setting.setValue("dump_round",round);
}
```