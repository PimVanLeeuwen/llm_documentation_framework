`on_languageBox_currentIndexChanged`: The function of `on_languageBox_currentIndexChanged` is to handle language selection changes and notify the user to restart the program.

**Parameters**:
`int index`: The index of the newly selected language in the language box.

**Code Description**: This method is triggered when the user changes the selected language in a language selection box. It first checks if the initialization is complete using the `initized` flag. If not initialized, the function returns immediately. If initialized, it creates a message informing the user that the program needs to be restarted for the language change to take effect. This message is then logged using `qDebug()` and displayed to the user through a `QMessageBox`. The function uses Qt's internationalization system (tr()) for potential translation of the message. The message box is created, set with the informative text, and then displayed to the user using `msgBox.exec()`.\\
## Code: 
```
void SettingEditor::on_languageBox_currentIndexChanged(int index)
{
    if(!initized)return;
    QString message = tr("Restart program to make language selection effective.");
    qDebug().noquote() << message;
    QMessageBox msgBox;
    msgBox.setText(message);
    msgBox.exec();
}
```