`resizeEvent`: The function of `resizeEvent` is to adjust the column widths and row heights of the table view when the widget is resized.

**Parameters**:
`QResizeEvent* ev`: A pointer to the QResizeEvent object containing information about the resize event.

**Code Description**: This method is triggered when the widget is resized. It first checks if a model is set for the table view. If so, it calculates the number of columns and rows in the model. For column widths, it distributes the available width proportionally among all columns, with the last column taking up any remaining space. Similarly, for row heights, it distributes the available height proportionally among all rows, with the last row taking up any remaining space. The method uses a percentage-based calculation to determine the width and height of each column and row, respectively. Finally, it calls the parent class's resizeEvent method to ensure proper handling of the resize event.\\
## Code: 
```
void HtmlTableView::resizeEvent(QResizeEvent* ev){
    if(model() != NULL){
        int num_columns = this->model()->columnCount(QModelIndex());
        int num_rows = this->model()->rowCount(QModelIndex());
        if (num_columns > 0) {
        int width = ev->size().width();
        int used_width = 0;
        // Set our widths to be a percentage of the available width
        for (int i = 0; i < num_columns - 1; i++) {
            //int column_width = width / num_columns;
            int column_width = (int)((float)width * (i + 1) / num_columns) -  (int)((float)width * (i) / num_columns);
            this->setColumnWidth(i, column_width);
            used_width += column_width;
        }

        // Set our last column to the remaining width
        this->setColumnWidth(num_columns - 1, width - used_width);
        }
        if (num_columns > 0) {
        int height = ev->size().height();
        int used_height = 0;
        for (int i = 0; i < num_columns - 1; i++) {
            //int column_height = height / num_rows;
            int column_height = (int)((float)height * (i + 1) / num_rows) -  (int)((float)height * (i) / num_rows);
            this->setRowHeight(i, column_height);
            used_height += column_height;
        }
        this->setRowHeight(num_columns - 1, height - used_height);
        }
    }
    QTableView::resizeEvent(ev);
}
```