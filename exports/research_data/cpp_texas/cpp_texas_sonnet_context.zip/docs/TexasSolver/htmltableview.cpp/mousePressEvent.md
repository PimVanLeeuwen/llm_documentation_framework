`mousePressEvent`: The function of `mousePressEvent` is to handle mouse press events on the HtmlTableView widget.

**Parameters**:
`QMouseEvent *event`: A pointer to the QMouseEvent object containing information about the mouse press event.

**Code Description**: This method overrides the default mousePressEvent behavior of QTableView. It first calls the parent class's mousePressEvent to maintain the default functionality. Then, it retrieves the anchor (if any) at the position where the mouse was pressed using the anchorAt method. The retrieved anchor is stored in the _mousePressAnchor member variable for potential later use. This allows the HtmlTableView to track which anchor, if any, was clicked during a mouse press event, which can be useful for handling hyperlinks or other interactive elements within the table cells.\\
## Code: 
```
void HtmlTableView::mousePressEvent(QMouseEvent *event) {
    QTableView::mousePressEvent(event);

    auto anchor = anchorAt(event->pos());
    _mousePressAnchor = anchor;
}
```