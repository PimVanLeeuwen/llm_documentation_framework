`eventFilter`: The function of `eventFilter` is to handle mouse move events within the viewport of the HtmlTableView.

**Parameters**:
`QObject *watched`: The object being watched for events.
`QEvent *event`: The event that occurred.

**Code Description**: This method filters events for the viewport of the HtmlTableView. It specifically handles mouse move events. When a mouse move event occurs, it determines the table cell (index) at the current mouse position. If the index is valid and different from the last recorded position, it updates the last_bearing_i and last_bearing_j variables and emits an itemMouseChange signal with the new row and column indices. The method also handles leave events, though no specific action is taken for them. Finally, it calls the parent class's eventFilter method to handle any other events.\\
## Code: 
```
bool HtmlTableView::eventFilter(QObject *watched, QEvent *event){
    if(viewport() == watched){
        if(event->type() == QEvent::MouseMove){
        QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
        QModelIndex index = indexAt(mouseEvent->pos());
        if(index.isValid()){
            int i = index.row();
            int j = index.column();
            if(i != this->last_bearing_i || j != last_bearing_j){
                this->last_bearing_i = i;
                this->last_bearing_j = j;
                emit itemMouseChange(i,j);
            }
        }
        else{
        }
        }
        else if(event->type() == QEvent::Leave){
        }
    }
    return QTableView::eventFilter(watched, event);
}
```