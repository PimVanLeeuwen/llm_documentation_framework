`mouseMoveEvent`: The function of `mouseMoveEvent` is to handle mouse movement events and update the cursor and link hover state accordingly.

**Parameters**:
`QMouseEvent *event`: A pointer to a QMouseEvent object containing information about the mouse movement event.

**Code Description**: This method is triggered when the mouse moves over the HtmlTableView widget. It first retrieves the anchor (likely a hyperlink) at the current mouse position using the `anchorAt` function. If the current anchor differs from the anchor where the mouse was last pressed, it clears the `_mousePressAnchor`. The method then compares the current anchor with the last hovered anchor. If they differ, it updates the `_lastHoveredAnchor` and performs the following actions:

1. If the new anchor is not empty:
   - Sets the cursor to a pointing hand cursor using `QApplication::setOverrideCursor`.
   - Emits a `linkHovered` signal with the new anchor.
2. If the new anchor is empty:
   - Restores the default cursor using `QApplication::restoreOverrideCursor`.
   - Emits a `linkUnhovered` signal.

This behavior provides visual feedback to the user when hovering over links in the HTML table view and allows connected slots to respond to link hover events.\\
## Code: 
```
void HtmlTableView::mouseMoveEvent(QMouseEvent *event) {
    auto anchor = anchorAt(event->pos());

    if (_mousePressAnchor != anchor) {
        _mousePressAnchor.clear();
    }

    if (_lastHoveredAnchor != anchor) {
        _lastHoveredAnchor = anchor;
        if (!_lastHoveredAnchor.isEmpty()) {
            QApplication::setOverrideCursor(QCursor(Qt::PointingHandCursor));
            emit linkHovered(_lastHoveredAnchor);
        } else {
            QApplication::restoreOverrideCursor();
            emit linkUnhovered();
        }
    }
}
```