`mouseReleaseEvent`: The function of `mouseReleaseEvent` is to handle mouse release events in an HTML table view.

**Parameters**:
`QMouseEvent *event`: A pointer to a QMouseEvent object containing information about the mouse release event.

**Code Description**: This method is triggered when a mouse button is released on the HTML table view. It first checks if there's a stored mouse press anchor (_mousePressAnchor). If an anchor exists, it compares it with the anchor at the current mouse position. If they match, it emits a linkActivated signal with the anchor. The _mousePressAnchor is then cleared. Finally, it calls the parent class's mouseReleaseEvent to ensure default behavior is maintained. This implementation allows for detecting and handling clicks on hyperlinks within the table view.\\
## Code: 
```
void HtmlTableView::mouseReleaseEvent(QMouseEvent *event) {
    if (!_mousePressAnchor.isEmpty()) {
        auto anchor = anchorAt(event->pos());

        if (anchor == _mousePressAnchor) {
            emit linkActivated(_mousePressAnchor);
        }

        _mousePressAnchor.clear();
    }

    QTableView::mouseReleaseEvent(event);
}
```