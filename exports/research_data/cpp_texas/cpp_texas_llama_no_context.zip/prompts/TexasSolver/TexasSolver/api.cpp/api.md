# PROMPT
## Information
**Code Content:** \
`EXPORT
int api(const char * input_file, const char * resource_dir = "./resources", const char * mode = "holdem") {
    string input_file_ = input_file;
    string resource_dir_ = resource_dir;
    string mode_ = mode;

    if(mode_ != "holdem" && mode_ != "shortdeck")
        throw runtime_error(tfm::format("mode %s error, not in ['holdem','shortdeck']", mode_));

    if(input_file_.empty()) {
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.startWorking();
    }else{
        cout << "EXEC FROM FILE" << endl;
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.execFromFile(input_file_);
    }
}`

## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`api`: The function of `api` is *FILL IN* 

**Code Description**: *FILL IN*
