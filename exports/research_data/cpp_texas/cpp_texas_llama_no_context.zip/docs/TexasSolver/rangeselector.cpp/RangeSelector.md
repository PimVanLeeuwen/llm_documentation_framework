**Expected Output**
The function of `RangeSelector` is to provide a graphical user interface for selecting and visualizing poker hand ranges, allowing users to interactively define and explore different range scenarios.

**Code Description**
`RangeSelector` is a custom dialog class that inherits from `QDialog`. It takes three parameters in its constructor: a `QTextEdit*` object representing the current hand range, a `QWidget*` parent widget, and an enumeration value of type `QSolverJob::Mode`, which determines the poker variant being used (e.g., Texas Hold'em or Short Deck). The class uses this information to initialize its internal state and set up its user interface accordingly.\\
## Code: 
```
RangeSelector::RangeSelector(QTextEdit* rangeEdit,QWidget *parent,QSolverJob::Mode mode) :
    QDialog(parent),
    ui(new Ui::RangeSelector)
{

    QString ranks;
    if(mode == QSolverJob::Mode::HOLDEM){
        ranks = "A,K,Q,J,T,9,8,7,6,5,4,3,2";
    }else if(mode == QSolverJob::Mode::SHORTDECK){
        ranks = "A,K,Q,J,T,9,8,7,6";
    }else{
        throw runtime_error("mode not found in range selector");
    }
    this->rank_list = ranks.split(",");
    this->rangeSelectorTableModel = new RangeSelectorTableModel(this->rank_list,rangeEdit->toPlainText(),this);
    this->rangeSelectorTableDelegate = new RangeSelectorTableDelegate(this->rank_list,this->rangeSelectorTableModel,this);
    ui->setupUi(this);
    this->ui->rangeTableView->setModel(this->rangeSelectorTableModel);
    this->ui->rangeTableView->setItemDelegate(this->rangeSelectorTableDelegate);
    this->rangeEdit = rangeEdit;
    this->ui->textEdit->setText(this->rangeEdit->toPlainText());
    this->ui->rangeNumberSlider->setMaximum(this->max_val);
    this->ui->rangeNumberSlider->setValue(this->max_val);
    this->setWindowTitle(tr("RangeSelector"));
    connect(this->ui->rangeTableView,SIGNAL(view_item_pressed(int,int)),this,SLOT(grid_pressed(int,int)));
    connect(this->ui->rangeTableView,SIGNAL(view_item_area(int,int,int,int)),this,SLOT(grid_area(int,int,int,int)));
    connect(this->ui->rangeTableView,SIGNAL(item_release(int,int)),this,SLOT(grid_release(int,int)));

    QStringList filters;
    filters << "*.txt";
    qFileSystemModel = new QFileSystemModel(this);
    QDir filedir = QDir::current().filePath("ranges");
    qFileSystemModel->setRootPath(filedir.path());
#ifdef Q_OS_MAC
```