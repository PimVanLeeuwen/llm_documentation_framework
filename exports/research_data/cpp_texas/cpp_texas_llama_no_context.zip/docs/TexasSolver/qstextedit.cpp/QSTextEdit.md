## Expected Output
`QSTextEdit`: The function of `QSTextEdit` is to serve as a custom text edit widget that connects its own signal to its own slot, allowing it to process and display messages.

**Code Description**: This code snippet defines the constructor for a custom text edit widget called `QSTextEdit`. It inherits from `QTextEdit`, which is a standard Qt widget for displaying and editing text. The constructor establishes a connection between two signals and slots within the same object, specifically between the `message_signal` signal and the `message_slot` slot. This setup enables the widget to receive and process messages internally without requiring external connections or callbacks.\\
## Code: 
```
QSTextEdit::QSTextEdit(QWidget *parent) : QTextEdit(parent)
{
    connect(this,SIGNAL(message_signal(const QString&)),this,SLOT(message_slot(const QString)));
}
```