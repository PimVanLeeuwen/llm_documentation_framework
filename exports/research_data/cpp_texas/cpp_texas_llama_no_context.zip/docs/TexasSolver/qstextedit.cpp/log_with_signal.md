`log_with_signal`: The function of `log_with_signal` is to emit a signal with the given message.

**Code Description**: This function, `log_with_signal`, takes a QString (a string in Qt) as input and emits a signal named `message_signal` with that message. It does not modify or store the message itself but rather notifies any connected slots of its occurrence.\\
## Code: 
```
void QSTextEdit::log_with_signal(QString message){
    emit message_signal(message);
}
```