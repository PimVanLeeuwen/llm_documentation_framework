## Expected Output
`~QSTreeView`: The function of `~QSTreeView` is to properly deallocate memory when a QSTreeView object is destroyed.

**Code Description**: This code snippet appears to be the destructor for a class named QSTreeView. It checks if a pointer to an object (tree_model) exists, and if so, it deletes that object to free up any resources it was using.\\
## Code: 
```
QSTreeView::~QSTreeView(){
    if(this->tree_model != NULL){
        delete this->tree_model;
    }
}
```