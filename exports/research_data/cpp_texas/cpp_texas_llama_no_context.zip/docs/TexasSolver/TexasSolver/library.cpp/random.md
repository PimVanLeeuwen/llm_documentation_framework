`random`: The function of `random` is to generate a random integer within a specified range, inclusive of the minimum value but exclusive of the maximum value.

**Code Description**: This function takes two parameters, `min` and `max`, which represent the lower and upper bounds of the desired range. It uses the `rand()` function to generate a random number, then adds this value to the `min` parameter and returns the result. The `% (( max ) - min)` operation ensures that the generated number falls within the specified range, but does not include the maximum value.\\
## Code: 
```
int random(int min, int max) //range : [min, max)
{
    return min + rand() % (( max ) - min);
}
```