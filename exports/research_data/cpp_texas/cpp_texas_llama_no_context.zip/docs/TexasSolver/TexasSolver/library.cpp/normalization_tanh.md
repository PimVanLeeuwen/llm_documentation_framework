**Expected Output**
`normalization_tanh`: The function of `normalization_tanh` is to normalize a value using the hyperbolic tangent (tanh) function.

**Code Description**: This function takes three parameters: `stack`, `ev`, and `ratio`. It calculates a new value `x` by dividing `ev` by `stack` and then multiplying it by `ratio`. The tanh function is applied to this value, and the result is scaled by 0.5 to ensure the output falls within the range of [0, 1].\\
## Code: 
```
float normalization_tanh(float stack,float ev,float ratio){
    float x = ev / stack * ratio;
    return tanh(x) / 2 + 0.5;
}
```