`timeSinceEpochMillisec`: The function of `timeSinceEpochMillisec` is to return the number of milliseconds since the Unix epoch (January 1, 1970).

**Code Description**: This function uses the C++11 chrono library to get the current system time using `system_clock::now()`. It then calculates the duration from the Unix epoch to the current time using `time_since_epoch()` and casts it to milliseconds using `duration_cast<milliseconds>`. The resulting count is returned as a `uint64_t` value.\\
## Code: 
```
uint64_t timeSinceEpochMillisec() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
}
```