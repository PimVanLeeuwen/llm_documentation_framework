**string_split**: The function of `string_split` is to split a given string into substrings based on a specified delimiter character, and return the resulting list of strings.

**Code Description**: The `string_split` function takes two parameters: a string (`strin`) and a character (`split`). It uses a stringstream object to parse the input string into individual tokens separated by the specified delimiter. The function then populates a vector with these tokens, which is returned as the result.\\
## Code: 
```
vector<string> string_split(string strin,char split){
    vector<string> retval;
    stringstream ss(strin);
    string token;
    while (getline(ss,token, split))
    {
        retval.push_back(token);
    }
    return retval;
}
```