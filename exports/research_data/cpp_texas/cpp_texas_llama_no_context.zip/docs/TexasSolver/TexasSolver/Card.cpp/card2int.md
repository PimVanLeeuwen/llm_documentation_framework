## card2int: 
The function of `card2int` is to convert a Card object into an integer representation, likely using the string representation of the card (e.g., "Ace of Hearts") and returning its corresponding integer value.

## Code Description:
This function takes a Card object as input, calls the `getCard()` method on it to retrieve the string representation of the card, passes this string to another function `strCard2int()`, which presumably converts the string into an integer, and returns this integer.\\
## Code: 
```
int Card::card2int(Card card) {
    return strCard2int(card.getCard());
}
```