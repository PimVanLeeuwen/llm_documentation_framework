**Expected Output**
The function of `long2board` is to convert a given 64-bit unsigned integer (`uint64_t`) representing a binary board into a vector of integers, where each integer corresponds to the index of a card in a standard deck (0-51), based on the binary representation.

**Code Description**: The `long2board` function takes a `uint64_t` value as input and iterates through its 64 bits. It checks if the least significant bit (LSB) is set to 1, indicating that the corresponding card index should be included in the output vector. The function then shifts the input value right by one bit to move to the next bit position. This process continues until all 64 bits have been processed. If the resulting vector does not contain exactly 7 elements (the expected length of a standard board), the function throws a runtime error with an informative message.\\
## Code: 
```
vector<int> Card::long2board(uint64_t board_long) {
    vector<int> board;
    board.reserve(7);
    for(int i = 0;i < 52;i ++){
        // 看二进制最后一位是否为1
        if((board_long & 1) == 1){
            board.push_back(i);
        }
        board_long = board_long >> 1;
    }
    if (board.size() < 1 || board.size() > 7){
        throw runtime_error(tfm::format("board length not correct, board length %s",board.size()));
    }
    return board;
}
```