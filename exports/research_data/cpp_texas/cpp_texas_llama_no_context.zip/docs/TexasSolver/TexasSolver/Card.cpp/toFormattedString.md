## toFormattedString: 
The function of `toFormattedString` is to format a card string into a human-readable format with Unicode characters for the suits.

## Code Description:
This function takes no arguments and returns a formatted string representation of a card. It uses the `QString` class from Qt to manipulate strings, replacing specific characters in the input string with their corresponding Unicode suit symbols. The input string is assumed to be in a standard format where "c", "d", "h", or "s" represent the suits (clubs, diamonds, hearts, and spades respectively).\\
## Code: 
```
string Card::toFormattedString() {
    QString qString = QString::fromStdString(this->card);
    qString = qString.replace("c", "♣️");
    qString = qString.replace("d", "♦️");
    qString = qString.replace("h", "♥️");
    qString = qString.replace("s", "♠️");
    return qString.toStdString();
}
```