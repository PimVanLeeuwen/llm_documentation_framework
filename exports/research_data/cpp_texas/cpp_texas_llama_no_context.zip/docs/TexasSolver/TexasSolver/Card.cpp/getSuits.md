`getSuits`: The function of `getSuits` is to return a vector of strings representing the four suits in a standard deck of cards.

**Code Description**: This function is part of the Card class and returns a list of string values, each representing one of the four suits: clubs ("c"), diamonds ("d"), hearts ("h"), and spades ("s").\\
## Code: 
```
vector<string> Card::getSuits(){
    return {"c","d","h","s"};
}
```