## Expected Output
`boardInt2long`: The function of `boardInt2long` is to convert a 1-based index of a card in a standard deck (52 cards) into a unique long integer representation.

## Code Description
The function takes an integer `board` as input, which represents the 1-based index of a card in a standard deck. It checks if the input `board` is within the valid range (0 to 51), and if not, it throws a runtime error with a message indicating that the card with the given ID was not found. If the input is valid, it returns a unique long integer representation of the card using bitwise left shift operation. The function assumes that the range of `uint64_t` is sufficient to represent all possible cards in the deck without overflow issues.\\
## Code: 
```
uint64_t Card::boardInt2long(int board){
    // 这里hard code了一副扑克牌是52张
    if(board < 0 || board >= 52){
        throw runtime_error(tfm::format("Card with id %s not found",board));
    }
    // uint64_7 的range 在0 ~ + 2^ 64之间,所以不用太担心溢出问题
    return ((uint64_t)(1) << board);
}
```