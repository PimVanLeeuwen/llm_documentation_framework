`getCard`: The function of `getCard` is to return the value of the `card` attribute of a Card object.

**Code Description**: This function, `getCard`, is a member function of the Card class. It takes no arguments and returns a string representing the card's value. The function simply returns the value stored in the `card` data member of the current object instance.\\
## Code: 
```
string Card::getCard() {
    return this->card;
}
```