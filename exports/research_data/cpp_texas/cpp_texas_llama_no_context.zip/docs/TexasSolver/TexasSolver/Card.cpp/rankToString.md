`rankToString`: The function of `rankToString` is to convert an integer rank value into a string representation of the card's rank, such as "2", "3", ..., "A".

**Code Description**: This function uses a switch statement to map each integer rank value (from 2 to 14) to its corresponding string representation. If the input rank is outside this range, it returns "2" by default.\\
## Code: 
```
string Card::rankToString(int rank)
{
    switch(rank)
    {
        case 2: return "2";
        case 3: return "3";
        case 4: return "4";
        case 5: return "5";
        case 6: return "6";
        case 7: return "7";
        case 8: return "8";
        case 9: return "9";
        case 10: return "T";
        case 11: return "J";
        case 12: return "Q";
        case 13: return "K";
        case 14: return "A";
        default: return "2";
    }
}
```