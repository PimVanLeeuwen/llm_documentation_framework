`empty`: The function of `empty` is to check if a card is empty or not.

**Code Description**: This function checks the state of a card and returns true if it's empty, false otherwise. It does this by comparing the current card with the string "empty". If they match, it means the card is indeed empty, so the function returns true; otherwise, it returns false.\\
## Code: 
```
bool Card::empty(){
    if(this->card == "empty")return true;
    else return false;
}
```