## Expected Output
`boardCard2long`: The function of `boardCard2long` is to convert a Card object into a long integer representation.

**Code Description**: This function appears to be part of the Card class and is used to translate a card's board integer value into its corresponding long integer equivalent. It takes a reference to a Card object as input, calls another member function `boardInt2long` on that object, and returns the result. The purpose seems to be data transformation or conversion for further processing or storage.\\
## Code: 
```
uint64_t Card::boardCard2long(Card& card){
    return Card::boardInt2long(card.getCardInt());
}
```