**Expected Output**
The function of `strCard2int` is to convert a string representation of a card (e.g., "A1", "K3") into an integer value.

**Code Description**
This function takes a string `card` as input, which represents a playing card with the rank and suit. It extracts the first character (`rank`) and second character (`suit`) from the string using `at(0)` and `at(1)`. The function then checks if the length of the string is exactly 2 characters; if not, it throws a runtime error with a message indicating that the card was not found. If the string has the correct length, the function uses two helper functions (`rankToInt` and `suitToInt`) to convert the rank and suit into integer values. The converted values are then combined using arithmetic operations to produce an integer result.\\
## Code: 
```
int Card::strCard2int(string card) {
    char rank = card.at(0);
    char suit = card.at(1);
    if(card.length() != 2){
        throw runtime_error( tfm::format("card %s not found",card));
    }
    return (rankToInt(rank) - 2) * 4 + suitToInt(suit);
}
```