**The function of `toFormattedHtml` is to format a card string into HTML, replacing specific characters with corresponding Unicode symbols for card suits.**

**The code description is: The function takes a QString object representing a card and replaces occurrences of "c", "d", "h", or "s" with their respective HTML-formatted Unicode symbols for the four card suits (clubs, diamonds, hearts, and spades). It returns the modified QString as an HTML-formatted string.**\\
## Code: 
```
QString Card::toFormattedHtml() {
    QString qString = QString::fromStdString(this->card);
    if(qString.contains("c"))
        qString = qString.replace("c", QString::fromLocal8Bit("<span style=\"color:black;\">&#9827;<\/span>"));
    else if(qString.contains("d"))
        qString = qString.replace("d", QString::fromLocal8Bit("<span style=\"color:red;\">&#9830;<\/span>"));
    else if(qString.contains("h"))
        qString = qString.replace("h", QString::fromLocal8Bit("<span style=\"color:red;\">&#9829;<\/span>"));
    else if(qString.contains("s"))
        qString = qString.replace("s", QString::fromLocal8Bit("<span style=\"color:black;\">&#9824;<\/span>"));
    return qString;
}
```