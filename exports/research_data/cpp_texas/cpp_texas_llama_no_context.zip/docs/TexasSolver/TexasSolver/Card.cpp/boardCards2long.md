**The function of `boardCards2long` is to convert a vector of string representations of cards into a single uint64_t value, representing the combined card values.**

**The code description is: The function takes a vector of strings, each representing a card (e.g., "AH", "KH"), and creates a corresponding vector of Card objects. It then calls another overloaded `boardCards2long` function that takes this vector of Card objects as input, which likely performs some operation on the cards to produce a single uint64_t value. The resulting value is returned by the original function.**\\
## Code: 
```
uint64_t Card::boardCards2long(vector<string> cards) {
    vector<Card> cards_objs(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_objs[i] = Card(cards[i]);
    }
    return Card::boardCards2long(cards_objs);
}
```