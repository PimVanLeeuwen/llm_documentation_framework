## Expected Output
The function of `boardCards2html` is to convert a list of cards into an HTML string.

## Code Description
This function takes a vector of Card objects as input, iterates over each card in the vector, and appends the formatted HTML representation of each card to a return string. If a card is empty (i.e., its `empty()` method returns true), it skips that card and continues with the next one. The final HTML string is then returned by the function.\\
## Code: 
```
QString Card::boardCards2html(vector<Card>& cards){
    QString ret_html = "";
    for(auto one_card:cards){
        if(one_card.empty())continue;
        ret_html += one_card.toFormattedHtml();
    }
    return ret_html;
}
```