`getNumberInDeckInt`: The function of `getNumberInDeckInt` is to return the card number in deck as an integer.

**Code Description**: This function retrieves and returns the card's position within a deck, represented by an integer. It checks if the internal `card_number_in_deck` variable has been set to -1, which would indicate an invalid or uninitialized state. If this condition is met, it throws a runtime error with a descriptive message. Otherwise, it returns the stored value of `card_number_in_deck`.\\
## Code: 
```
int Card::getNumberInDeckInt(){
    if(this->card_number_in_deck == -1)throw runtime_error("card number in deck cannot be -1");
    return this->card_number_in_deck;
}
```