## suitToInt: The function of `suitToInt` is to convert a character representing the suit of a card into an integer value, where each suit has a unique integer representation.

## Code Description: This function uses a switch statement to map each possible suit character ('c', 'd', 'h', or 's') to its corresponding integer value (0, 1, 2, or 3), respectively. If the input suit is not one of these four characters, it returns 0 by default.\\
## Code: 
```
int Card::suitToInt(char suit)
{
    switch(suit)
    {
        case 'c': return 0; // 梅花
        case 'd': return 1; // 方块
        case 'h': return 2; // 红桃
        case 's': return 3; // 黑桃
        default: return 0;
    }
}
```