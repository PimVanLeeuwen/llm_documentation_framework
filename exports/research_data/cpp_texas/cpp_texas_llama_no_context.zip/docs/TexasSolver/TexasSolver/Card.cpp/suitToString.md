## suitToString: The function of `suitToString` is to convert an integer representing a card suit into its corresponding string representation.

## Code Description: This function takes an integer `suit` as input and uses a switch statement to determine which string representation of the suit to return. The possible suits are 0 for clubs, 1 for diamonds, 2 for hearts, and 3 for spades. If any other value is passed, it defaults to "c" representing clubs.\\
## Code: 
```
string Card::suitToString(int suit)
{
    switch(suit)
    {
        case 0: return "c";
        case 1: return "d";
        case 2: return "h";
        case 3: return "s";
        default: return "c";
    }
}
```