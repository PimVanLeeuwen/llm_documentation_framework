`rankToInt`: The function of `rankToInt` is to convert a given card rank (represented as a character) into its corresponding integer value.

**Code Description**: This function takes a single character representing the rank of a playing card and returns an integer equivalent. It uses a switch statement to match the input character with one of the predefined cases, returning the corresponding integer value for each case. If the input character does not match any of the cases, it defaults to returning 2.\\
## Code: 
```
int Card::rankToInt(char rank)
{
    switch(rank)
    {
        case '2': return 2;
        case '3': return 3;
        case '4': return 4;
        case '5': return 5;
        case '6': return 6;
        case '7': return 7;
        case '8': return 8;
        case '9': return 9;
        case 'T': return 10;
        case 'J': return 11;
        case 'Q': return 12;
        case 'K': return 13;
        case 'A': return 14;
        default: return 2;
    }
}
```