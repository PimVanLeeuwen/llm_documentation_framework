**Expected Output**
The function of `intCard2Str` is to convert an integer representation of a playing card into a string.

**Code Description**
This function takes an integer `card` as input, which represents a playing card with the rank and suit encoded in it. The function uses this integer to extract the rank and suit, then converts them into strings using the `rankToString` and `suitToString` functions respectively. The resulting strings are concatenated together to form the final string representation of the card.\\
## Code: 
```
string Card::intCard2Str(int card){
    int rank = card / 4 + 2;
    int suit = card - (rank-2)*4;
    return Card::rankToString(rank) + Card::suitToString(suit);
}
```