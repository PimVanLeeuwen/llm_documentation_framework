`GameTree`: The function of `GameTree` is to initialize a game tree data structure with the given parameters, including the deck, commitment levels, current round, raise limit, small and big blinds, stack size, building settings, and all-in threshold.

**Code Description**: 
The `GameTree` constructor takes in several parameters to configure the game tree. It creates a new instance of the `Rule` class based on these parameters and uses it to initialize the game tree. The constructor also sets up the initial state of the game tree by creating an `ActionNode` as the root node, which represents the current player's action at this point in the game. The `__build` function is then called to recursively build the rest of the game tree based on the rules and settings provided.\\
## Code: 
```
GameTree::GameTree(Deck deck,
                   float oop_commit,
                   float ip_commit,
                   int current_round,
                   int raise_limit,
                   float small_blind,
                   float big_blind,
                   float stack,
                   GameTreeBuildingSettings buildingSettings,
                   float allin_threshold
){
    Rule rule = Rule(deck,oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,buildingSettings,allin_threshold);
    int current_player = 1;
    this->deck = deck;
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(rule.current_round);
    shared_ptr<ActionNode> node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(),current_player, round, (double) rule.get_pot(),
                                 nullptr);
    this->__build(node,rule);
    this->root = node;
}
```