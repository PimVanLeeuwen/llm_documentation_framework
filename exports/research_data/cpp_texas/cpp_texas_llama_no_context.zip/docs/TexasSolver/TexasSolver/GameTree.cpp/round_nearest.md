`round_nearest`: The function of `round_nearest` is to round a given number to the nearest multiple of another specified number.

**Code Description**: This function takes two parameters, `number` and `round_num`, where `number` is the value to be rounded and `round_num` is the number to which the rounding should be done. The function first calculates the reciprocal of `round_num` and then multiplies it with `number`. It then rounds the result to the nearest integer using the `round()` function, effectively rounding `number` to the nearest multiple of `round_num`. Finally, it divides the rounded result by the reciprocal of `round_num` to obtain the final rounded value.\\
## Code: 
```
double GameTree::round_nearest(double number, double round_num) {
    round_num = 1 / round_num;
    return round((number * round_num)) / round_num;

}
```