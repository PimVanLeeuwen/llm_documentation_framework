**Expected Output**
`generateTerminalNode`: The function generates a terminal node in the game tree, representing a final state where the game has ended and payoffs are determined.

**Code Description**: This function takes in three parameters: `meta`, `round`, and `parent`. It extracts relevant information from the `meta` json object, including player payoffs, pot size, and game round. The function then creates a new terminal node with this information, passing it to the parent node if provided.\\
## Code: 
```
shared_ptr<TerminalNode> GameTree::generateTerminalNode(json meta, string round, shared_ptr<GameTreeNode> parent) {
    vector<double> player_payoff_list = meta["payoff"];
    vector<double> player_payoff(player_payoff_list.size());
    for(std::size_t one_player = 0;one_player < player_payoff_list.size();one_player ++){

        double tmp_payoff = player_payoff_list[one_player];
        player_payoff[one_player] = tmp_payoff;
    }

    //节点上的下注额度
    double pot = meta["pot"];

    GameTreeNode::GameRound game_round = this->strToGameRound(std::move(round));
    // 多人游戏的时候winner就不等于当前节点的玩家了，这里要注意
    int player = meta["player"];

    return make_shared<TerminalNode>(player_payoff,player,game_round,pot,parent);
}
```