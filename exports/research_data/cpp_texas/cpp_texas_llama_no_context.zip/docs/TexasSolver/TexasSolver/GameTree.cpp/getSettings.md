`getSettings`: The function of `getSettings` is to retrieve specific settings for a given game round and player in the StreetSetting GameTree.

**Code Description**: This function takes three parameters: `int_round`, `player`, and `gameTreeBuildingSettings`. It converts the `int_round` parameter into a `GameRound` enum value using the `intToGameRound` method. Based on the `round` and `player` values, it returns specific settings from the `gameTreeBuildingSettings` object. If an invalid player or round is provided, it throws a runtime error with a corresponding message.\\
## Code: 
```
StreetSetting GameTree::getSettings(int int_round, int player,GameTreeBuildingSettings& gameTreeBuildingSettings){
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(int_round);
    if(!(player == 0 || player == 1)) throw runtime_error(tfm::format("player %s not known",player));
    if(round == GameTreeNode::GameRound::RIVER && player == 0) return gameTreeBuildingSettings.river_ip;
    else if(round == GameTreeNode::GameRound::TURN && player == 0) return gameTreeBuildingSettings.turn_ip;
    else if(round == GameTreeNode::GameRound::FLOP && player == 0) return gameTreeBuildingSettings.flop_ip;
    else if(round == GameTreeNode::GameRound::RIVER && player == 1) return gameTreeBuildingSettings.river_oop;
    else if(round == GameTreeNode::GameRound::TURN && player == 1) return gameTreeBuildingSettings.turn_oop;
    else if(round == GameTreeNode::GameRound::FLOP && player == 1) return gameTreeBuildingSettings.flop_oop;
    else throw new runtime_error(tfm::format("player %s and round not known",player));
}
```