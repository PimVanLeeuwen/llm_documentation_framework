`buildChance`: The function of `buildChance` is to recursively build a game tree for a chance node in the game, given a shared pointer to the root node and a rule object.

**Code Description**: This function appears to be part of a larger game tree building process. It takes in a shared pointer to a ChanceNode (the root node) and a Rule object as input parameters. The function then checks if the current round is greater than 3, which seems to be an invalid condition based on the code's logic. If this condition is met, it throws a runtime error with a message indicating that the current round is not valid.

The function then proceeds to create a new node based on the rule object's properties. If the player's commit (oop_commit) and opponent's commit (ip_commit) are equal and also equal to the stack value, it creates a ShowdownNode. This node takes in several parameters, including the peace getback vector, payoffs matrix, game round, pot, and root node.

If the current round is less than 3, it increments the rule object's current round by 1 and creates a new ChanceNode with the updated round value. If the player's commit and opponent's commit are not equal or do not match the stack value, it creates an ActionNode instead.

The function then calls another function (`__build`) to recursively build the game tree for the newly created node, passing in the node, updated rule object, a string parameter ("begin"), and two integer parameters (0 and 0). Finally, it sets the children of the root node to the newly built node.\\
## Code: 
```
void GameTree::buildChance(shared_ptr<ChanceNode> root,Rule rule){
    //节点上的下注额度
    double pot = (double)rule.get_pot();
    Rule nextrule = Rule(rule);
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));

    shared_ptr<GameTreeNode> one_node;
    if(rule.oop_commit == rule.ip_commit && rule.oop_commit == rule.stack) {
        if(rule.current_round >= 3){ // 3 is river
            double p1_commit = rule.ip_commit;
            double p2_commit = rule.oop_commit;
            double peace_getback = (p1_commit + p2_commit) / 2;


            vector<vector<double>> payoffs(2);
            payoffs[0] = {p2_commit, -p2_commit};
            payoffs[1] = {-p1_commit, p1_commit};
            vector<double> peace_getback_vec = {peace_getback - p1_commit, peace_getback - p2_commit};
            one_node = make_shared<ShowdownNode>(peace_getback_vec, payoffs, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
        }else {
            nextrule.current_round += 1;
            if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
            one_node = make_shared<ChanceNode>(nullptr, GameTreeNode::intToGameRound(rule.current_round + 1), (double) rule.get_pot(), root, this->deck.getCards());
        }
    }else {
        one_node = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(), 1, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
    }
    if(rule.current_round > 3)throw runtime_error(tfm::format("current round not valid : %d",rule.current_round));
    this->__build(one_node,nextrule,"begin",0,0);
    root->setChildren(one_node);
}
```