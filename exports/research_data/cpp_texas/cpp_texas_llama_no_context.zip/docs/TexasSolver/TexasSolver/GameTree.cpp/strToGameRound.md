`strToGameRound`: The function of `strToGameRound` is to convert a given string representing a game round into an enumeration value of type `GameTreeNode::GameRound`.

**Code Description**: This function takes a string parameter `round` and returns a `GameTreeNode::GameRound` enumeration value. It uses if-else statements to check the input string against predefined values ("preflop", "flop", "turn", "river") and assigns the corresponding `GameTreeNode::GameRound` value accordingly. If the input string does not match any of these values, it throws a runtime error with a message indicating that the game round was not found.\\
## Code: 
```
GameTreeNode::GameRound GameTree::strToGameRound(const string& round) {
    GameTreeNode::GameRound game_round;
    if(round == "preflop"){
        game_round = GameTreeNode::GameRound::PREFLOP;
    }
    else if (round == "flop"){
        game_round = GameTreeNode::GameRound::FLOP;
    }
    else if(round == "turn"){
        game_round = GameTreeNode::GameRound::TURN;
    }
    else if(round == "river"){
        game_round = GameTreeNode::GameRound::RIVER;
    }
    else{
        throw runtime_error(tfm::format("game round not found: %s",round));
    }
    return game_round;
}
```