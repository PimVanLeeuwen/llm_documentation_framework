## Expected Output
`readAllBytes`: The function of `readAllBytes` is to read all bytes from a file specified by the given path.

**Code Description**: This function opens an input stream (`ifstream`) on the specified file path and returns it. It does not perform any operations on the data; it merely provides access to the file's contents through the returned stream object.\\
## Code: 
```
ifstream GameTree::readAllBytes(const string& filePath) {
    ifstream input_file(filePath);
    return input_file;
}
```