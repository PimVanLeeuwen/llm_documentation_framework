`printTree`: The function of `printTree` is to print a game tree with the specified depth, starting from the root node.

**Code Description**: 
The `printTree` function in the GameTree class takes an integer parameter `depth`. It checks if the provided depth is valid (either -1 or positive), and throws a runtime error otherwise. The function then initializes a vector of strings called `prefix` and calls the recursive helper function `recurrentPrintTree` with the root node, 0 as the current depth, and the specified depth.\\
## Code: 
```
void GameTree::printTree(int depth) {
    if(depth < -1 || depth == 0){
        throw runtime_error("depth can only be -1 or positive");
    }
    vector<string> prefix;
    this->recurrentPrintTree(this->root,0,depth);
}
```