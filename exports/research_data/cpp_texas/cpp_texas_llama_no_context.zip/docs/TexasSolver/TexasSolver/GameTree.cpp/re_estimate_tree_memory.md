**The function of `re_estimate_tree_memory` is to recursively estimate the memory usage of a game tree.**

**The code estimates the memory usage by traversing the game tree, starting from a given node. It takes into account the number of children each node has and the number of deals in the current game state. The function returns an estimated total memory usage for the entire game tree.**

In more detail, the function:

*   Checks if the current node is an action node or a chance node.
*   If it's an action node, recursively estimates the memory usage of its children and adds the estimated memory usage of the current node to the total.
*   If it's a chance node, recursively estimates the memory usage of its child node and multiplies the result by the number of deals in the deck.
*   The function uses dynamic casting to ensure that the correct type of node is being used.

The code appears to be part of a larger system for estimating the memory usage of a game tree, possibly for a card game like poker.\\
## Code: 
```
long long GameTree::re_estimate_tree_memory(const shared_ptr<GameTreeNode>& node,int deck_num,int p1range_num,int p2range_num,int num_current_deal){
    if(node->getType() == GameTreeNode::ACTION){
        shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
        vector<shared_ptr<GameTreeNode>> childrens = action_node->getChildrens();
        vector<GameActions> actions = action_node->getActions();

        long long retnum = 0;
        for(std::size_t i = 0;i < childrens.size();i++){
            shared_ptr<GameTreeNode> one_child = childrens[i];
            retnum += re_estimate_tree_memory(one_child,deck_num, p1range_num, p2range_num, num_current_deal);
        }
        if(action_node->getPlayer() == 0){
            retnum += num_current_deal * p1range_num * (childrens.size() + 1) * 3;
        }else{
            retnum += num_current_deal * p2range_num * (childrens.size() + 1) * 3;
        }
        return retnum;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
        shared_ptr<GameTreeNode> children = chance_node->getChildren();
        return re_estimate_tree_memory(children,deck_num, p1range_num, p2range_num, num_current_deal * (deck_num));
    }
    return 0;
}
```