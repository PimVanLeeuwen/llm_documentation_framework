**Expected Output**
The function of `__build` is to recursively build a game tree by traversing the nodes and applying the given rule.

**Code Description**
This code snippet appears to be part of a class called `GameTree`, which seems to be responsible for building a game tree data structure. The `__build` method takes in several parameters: a shared pointer to a `GameTreeNode`, a `Rule` object, a string representing the last action taken, an integer representing the number of check times, and another integer representing the number of raise times.

The method uses a switch statement to determine the type of the input node. Depending on its type, it calls different methods (e.g., `buildAction`, `buildChance`) to recursively build the game tree. If the node type is unknown, it throws a runtime error.

The function returns the updated `GameTreeNode` object after building the subtree rooted at that node.\\
## Code: 
```
shared_ptr<GameTreeNode> GameTree::__build(shared_ptr<GameTreeNode> node, Rule rule, string last_action,
                                           int check_times, int raise_times) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            this->buildAction(std::dynamic_pointer_cast<ActionNode>(node),rule,last_action,check_times,raise_times);
            break;
        }case GameTreeNode::SHOWDOWN: {
            break;
        }case GameTreeNode::TERMINAL: {
            break;
        }case GameTreeNode::CHANCE: {
            this->buildChance(std::dynamic_pointer_cast<ChanceNode>(node),rule);
            break;
        }default:
            throw runtime_error("node type unknown");
    }
    return node;
}
```