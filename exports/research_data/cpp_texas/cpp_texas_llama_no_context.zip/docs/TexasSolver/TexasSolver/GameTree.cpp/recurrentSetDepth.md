**The function of `recurrentSetDepth` is to recursively set the depth and subtree size of a game tree node.**

**Code Description:**
The `recurrentSetDepth` function is a recursive method that traverses a game tree, setting the depth and subtree size of each node based on its type. It takes two parameters: a shared pointer to a `GameTreeNode` object (`node`) and an integer representing the current depth (`depth`). The function updates the `depth` attribute of the input node and calculates the subtree size by recursively calling itself for child nodes, depending on the node's type (ACTION or CHANCE). If the node is neither ACTION nor CHANCE, it sets the subtree size to 1.\\
## Code: 
```
int GameTree::recurrentSetDepth(shared_ptr<GameTreeNode> node, int depth) {
    node->depth = depth;
    if(node->getType() == GameTreeNode::ACTION) {
        shared_ptr<ActionNode> actionNode = std::dynamic_pointer_cast<ActionNode>(node);
        int subtree_size = 1;
        for(shared_ptr<GameTreeNode> one_child:actionNode->getChildrens()){
            subtree_size += this->recurrentSetDepth(one_child,depth + 1);
        }
        node->subtree_size = subtree_size;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chanceNode = std::dynamic_pointer_cast<ChanceNode>(node);
        int subtree_size = 1;
        subtree_size += this->recurrentSetDepth(chanceNode->getChildren(),depth + 1) * chanceNode->getCards().size();
        node->subtree_size = subtree_size;
    }else{
        node->subtree_size = 1;
    }
    return node->subtree_size;
}
```