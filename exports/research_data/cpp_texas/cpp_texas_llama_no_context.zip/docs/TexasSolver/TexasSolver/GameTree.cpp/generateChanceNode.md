`generateChanceNode`: The function of `generateChanceNode` is to generate a chance node in the game tree, which represents a decision point where the player has a choice to make.

**Code Description**: This function takes four parameters: `meta`, `child`, `round`, and `parent`. It uses these inputs to create a new `ChanceNode` object, which is then returned. The `ChanceNode` object contains information about the current game state, including the pot (the amount of money at stake), the child node (which represents the next decision point), the game round, and the parent node (which represents the previous decision point).\\
## Code: 
```
shared_ptr<ChanceNode>
GameTree::generateChanceNode(json meta, const json& child, string round, shared_ptr<GameTreeNode> parent) {
    //节点上的下注额度
    double pot = meta["pot"];
    shared_ptr<GameTreeNode> one_child = recurrentGenerateTreeNode(child, nullptr);
    GameTreeNode::GameRound game_round = strToGameRound(std::move(round));
    shared_ptr<ChanceNode> chanceNode = make_shared<ChanceNode>(one_child,game_round,pot,parent,this->deck.getCards());
    shared_ptr<GameTreeNode> gameTreeNode = chanceNode->getChildren();
    gameTreeNode->setParent(chanceNode);
    return chanceNode;
}
```