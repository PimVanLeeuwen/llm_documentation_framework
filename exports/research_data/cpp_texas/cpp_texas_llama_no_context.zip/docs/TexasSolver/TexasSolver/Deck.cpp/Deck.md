**The function of `Deck` is to initialize a deck of cards with the given ranks and suits.**

**Code Description: This code snippet defines a constructor for a class named `Deck`. It takes two parameters, `ranks` and `suits`, which are vectors of strings representing the different card ranks and suits respectively. The function populates a vector called `cards_str` with string representations of all possible cards (e.g., "Ace of Hearts", "2 of Diamonds", etc.) and creates a vector of pairs (`cards`) where each pair contains a string representation of a card and an integer representing the card's position in the deck.**\\
## Code: 
```
Deck::Deck(const vector<string>& ranks, const vector<string>& suits) {
    this->ranks = ranks;
    this->suits = suits;
    int card_num = 0;
    for(const string& one_rank : ranks){
        for(const string& one_suit: suits){
            string one_card = one_rank + one_suit;
            cards_str.push_back(one_card);
            cards.emplace_back(one_card,card_num);
            card_num += 1;
        }
    }
}
```