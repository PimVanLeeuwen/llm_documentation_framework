`getCards`: The function of `getCards` is to return a reference to the vector of cards in the Deck object.

**Code Description**: This function, `getCards`, is a member function of the `Deck` class. It returns a reference to the internal vector of `Card` objects, which stores all the cards in the deck. The function does not modify the state of the deck; it simply provides access to its contents.\\
## Code: 
```
vector<Card>& Deck::getCards() {
    return this->cards;
}
```