**The function of `api` is to execute a command-line tool for Hold'em or Shortdeck poker games, either from a file or interactively.**

**Code Description:**
The `api` function takes three parameters: `input_file`, `resource_dir`, and `mode`. It checks if the `mode` parameter is either "holdem" or "shortdeck", throwing an error if it's not one of these two values. If no input file is provided, it starts a command-line tool interactively; otherwise, it executes the tool from the specified input file. The function uses a `CommandLineTool` object to perform this execution.\\
## Code: 
```
EXPORT
int api(const char * input_file, const char * resource_dir = "./resources", const char * mode = "holdem") {
    string input_file_ = input_file;
    string resource_dir_ = resource_dir;
    string mode_ = mode;

    if(mode_ != "holdem" && mode_ != "shortdeck")
        throw runtime_error(tfm::format("mode %s error, not in ['holdem','shortdeck']", mode_));

    if(input_file_.empty()) {
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.startWorking();
    }else{
        cout << "EXEC FROM FILE" << endl;
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.execFromFile(input_file_);
    }
}
```