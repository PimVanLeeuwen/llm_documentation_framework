**The function of `noDuplicateRange` is to remove duplicate private card ranges from a given input vector and filter out the ones that intersect with a specified board long.**

**The code description is: The `noDuplicateRange` function takes in a vector of private card ranges (`private_range`) and a board long value (`board_long`). It uses an unordered map to keep track of unique hash codes from the input vector, ensuring no duplicates are present. Then, it iterates through each range in the input vector, checks if the range intersects with the specified board long using the `Card::boardsHasIntercept` function, and only adds non-intersecting ranges to a new output vector (`range_array`). The function returns this filtered vector of unique private card ranges that do not intersect with the given board.**\\
## Code: 
```
vector<PrivateCards> noDuplicateRange(const vector<PrivateCards> &private_range, uint64_t board_long) {
    vector<PrivateCards> range_array;
    unordered_map<int,bool> rangekv;
    for(PrivateCards one_range:private_range){
        if(rangekv.find(one_range.hashCode()) != rangekv.end())
            throw runtime_error(tfm::format("duplicated key %s",one_range.toString()));
        rangekv[one_range.hashCode()] = true;
        uint64_t hand_long = Card::boardInts2long(one_range.get_hands());
        if(!Card::boardsHasIntercept(hand_long,board_long)){
            range_array.push_back(one_range);
        }
    }
    return range_array;
}
```