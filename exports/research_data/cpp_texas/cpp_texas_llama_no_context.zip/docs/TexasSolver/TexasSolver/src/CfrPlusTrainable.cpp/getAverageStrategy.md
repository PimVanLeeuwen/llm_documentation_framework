`getAverageStrategy`: The function of `getAverageStrategy` is to return the average strategy based on the cumulative reward plus sum and current strategy.

**Code Description**: This function appears to be part of a class called `CfrPlusTrainable`. It calculates the average strategy by considering two scenarios: when the cumulative reward plus sum is empty or all zeros, and when it's not. If the cumulative reward plus sum is empty or all zeros, the function returns an array of equal probabilities for each action (1.0 / this->action_number). Otherwise, it iterates through each action and private ID, calculating the average strategy by dividing the cumulative reward by the cumulative reward plus sum for that private ID. If the cumulative reward plus sum is zero for a particular private ID, it defaults to an equal probability for that action. The function then returns this calculated average strategy.\\
## Code: 
```
const vector<float> CfrPlusTrainable::getAverageStrategy() {
    /*
    vector<float> retval(this->action_number * this->card_number);
    if(this->cum_r_plus_sum.empty() || this->isAllZeros(this->cum_r_plus_sum)){
        fill(retval.begin(),retval.end(),1.0 / this->action_number);
    }else {
        for (int action_id = 0; action_id < action_number; action_id++) {
            for (int private_id = 0; private_id < this->card_number; private_id++) {
                int index = action_id * this->card_number + private_id;
                if(this->cum_r_plus_sum[private_id] != 0) {
                    retval[index] = this->cum_r_plus[index] / this->cum_r_plus_sum[private_id];
                }else{
                    retval[index] = 1.0 / this->action_number;
                }
            }
        }
    }
    */
    return this->getcurrentStrategy();
}
```