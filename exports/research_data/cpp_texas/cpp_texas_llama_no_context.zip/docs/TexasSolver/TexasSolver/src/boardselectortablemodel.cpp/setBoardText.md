## Expected Output
`setBoardText`: The function of `setBoardText` is to update the board data with a new set of values from a comma-separated string input.

## Code Description
The `setBoardText` function takes a `QString` input representing a comma-separated list of board values. It iterates through each value in the list, processes it according to specific rules, and updates the corresponding grid data structure (`grids_float`) with a float value of 1.0. The processing involves checking for format errors (e.g., boards with spaces or empty strings) and skipping them if found. If a board string matches an entry in the `string2ij` map, it extracts the corresponding integer coordinates from the map and assigns the float value to the grid at those coordinates.\\
## Code: 
```
void BoardSelectorTableModel::setBoardText(QString input_board){
    this->clear_board();
    for(QString one_board:input_board.split(",")){
        float board_float = 1.0;


        if(one_board.count(" ") == one_board.length() || one_board == "")continue;
        if(!this->string2ij.count(one_board)){
            qDebug().noquote() << QString(tr("skipping board %1, format error")).arg(one_board);
            continue;
        }
        pair<int,int> cord = this->string2ij[one_board];
        this->grids_float[cord.first][cord.second] = board_float;
    }
}
```