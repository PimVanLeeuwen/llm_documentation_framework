`Solver`: The function of `Solver` is to initialize a solver object with a shared pointer to a game tree.

**Code Description**: This code snippet defines the constructor for a class named `Solver`. It takes a shared pointer to a `GameTree` object as an argument and assigns it to the `tree` member variable of the `Solver` class. The purpose of this constructor is likely to set up the solver with the game tree that it will operate on, allowing it to perform various operations such as finding solutions or analyzing the tree's structure.\\
## Code: 
```
Solver::Solver(shared_ptr<GameTree> tree) {
    this->tree = tree;
}
```