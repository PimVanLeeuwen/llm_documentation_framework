`clear_range`: The function of `clear_range` is to reset all values in the `grids_float` array to 0, effectively clearing any previously stored data.

**Code Description**: This function iterates over a 2D array (`grids_float`) and sets each element to 0. It appears to be part of a larger system that uses this array to store some kind of numerical data, possibly related to ranking or scoring. The function is called `clear_range`, suggesting it is used to clear or reset the range of values in this array.\\
## Code: 
```
void RangeSelectorTableModel::clear_range(){
    for(int i = 0;i < this->ranklist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_float[i][j] = 0;
        }
    }
}
```