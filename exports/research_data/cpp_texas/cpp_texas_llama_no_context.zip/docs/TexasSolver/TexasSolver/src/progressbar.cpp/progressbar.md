`progressbar::progressbar(int n, bool showbar) :`

The function of `progressbar` is to create a progress bar that displays the completion status of a task or process.

**Code Description**: 
This code snippet defines a constructor for a class named `progressbar`. The constructor takes two parameters: `n`, which represents the total number of cycles or iterations, and `showbar`, a boolean flag indicating whether to display the progress bar. 

The constructor initializes several member variables:

- `progress`: an integer representing the current progress (default value is 0).
- `n_cycles`: an integer storing the total number of cycles (set to `n`).
- `last_perc`: an integer for tracking the last percentage calculated (initialized with 0).
- `do_show_bar`: a boolean flag indicating whether to show the progress bar (set to `showbar`).
- `update_is_called`: a boolean flag used internally to track when the update method is called (initially set to false).
- `done_char`, `todo_char`, `opening_bracket_char`, and `closing_bracket_char`: characters used for displaying the progress bar.\\
## Code: 
```
progressbar::progressbar(int n, bool showbar) :
        progress(0),
        n_cycles(n),
        last_perc(0),
        do_show_bar(showbar),
        update_is_called(false),
        done_char("#"),
        todo_char(" "),
        opening_bracket_char("["),
        closing_bracket_char("]") {}
```