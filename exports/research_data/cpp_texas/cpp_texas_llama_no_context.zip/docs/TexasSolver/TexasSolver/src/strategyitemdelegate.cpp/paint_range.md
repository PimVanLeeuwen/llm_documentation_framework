`paint_range`: The function of `paint_range` is to paint a range of values in a table strategy model, specifically for a detail window setting.

**Code Description**: 
The code snippet defines the `paint_range` function within the `StrategyItemDelegate` class. This function is responsible for painting a specific range of values from a table strategy model onto a detail window setting. The function takes three parameters: a `QPainter` object, a `QStyleOptionViewItem` object, and a `QModelIndex` object.

The function first initializes an options variable with the provided option and then calls the `initStyleOption` function to set up the style option for painting. It then checks if the table strategy model is valid and if the range data exists within the model. If not, it returns without performing any further actions.

Next, the function determines which player's range data to use based on the current detail window setting mode. It retrieves the card coordinates from either the `ui_p1_range` or `ui_p2_range` vector of the table strategy model, depending on the mode.

The function then checks if there are any card coordinates available and calculates a range number by summing up the values at each coordinate point. If the calculated range number is outside the valid range (0 to 1), it throws a runtime error.

If the range number is within the valid range, the function calculates a fold probability as one minus the range number and determines the height of the disabled area based on this probability. It then draws a yellow background for the fold area using a `QBrush` object.

Finally, the function creates a `QTextDocument` object to draw the text from the style option onto the painter.\\
## Code: 
```
void StrategyItemDelegate::paint_range(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);
    const TableStrategyModel * tableStrategyModel = qobject_cast<const TableStrategyModel*>(index.model());

    vector<pair<int,int>> card_cords;
    if(tableStrategyModel == NULL
            || tableStrategyModel->ui_p1_range.size() <= index.row()
            || tableStrategyModel->ui_p1_range.size() <= index.column()
            || tableStrategyModel->ui_p2_range.size() <= index.row()
            || tableStrategyModel->ui_p2_range.size() <= index.column()
            ){
        return;
    }
    if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP){
        card_cords = tableStrategyModel->ui_p1_range[index.row()][index.column()];
    }else{
        card_cords = tableStrategyModel->ui_p2_range[index.row()][index.column()];
    }

    if(tableStrategyModel->p1_range.empty() || tableStrategyModel->p2_range.empty()){
        return;
    }

    if(!card_cords.empty()){
        float range_number = 0;
        for(auto one_cord:card_cords){
            if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP){
                range_number += tableStrategyModel->p1_range[one_cord.first][one_cord.second];
            }else{
                // when it's oop, which is p1
                range_number += tableStrategyModel->p2_range[one_cord.first][one_cord.second];
            }
        }
        range_number = range_number / card_cords.size();

        if(range_number < 0 || range_number > 1) throw runtime_error("range number incorrect in strategyitemdeletage");

        float fold_prob = 1 - range_number;
        int disable_height = (int)(fold_prob * option.rect.height());
        int remain_height = option.rect.height() - disable_height;

        // draw background for flod
        QRect rect(option.rect.left(), option.rect.top() + disable_height,\
         option.rect.width(), remain_height);
        QBrush brush(Qt::yellow);
        painter->fillRect(rect, brush);
    }
    QTextDocument doc;
    doc.setHtml(options.text);

    options.text = "";
    //options.widget->style()->drawControl(QStyle::CE_ItemViewItem, &option, painter);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```