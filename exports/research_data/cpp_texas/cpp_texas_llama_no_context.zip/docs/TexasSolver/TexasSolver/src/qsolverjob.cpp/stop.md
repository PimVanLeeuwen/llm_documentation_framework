`stop`: The function of `stop` is to terminate a solver job, specifically stopping any ongoing poker strategy (PS) calculations for the current game mode.

**Code Description**: This code snippet appears to be part of a class called `QSolverJob`, which seems to manage and control a poker solver. The `stop` function is used to halt the solver's activity when it is no longer needed or when the user wants to cancel the calculation process. The function checks the current game mode (either HOLDEM or SHORTDECK) and calls the corresponding stop method on the associated PS object (`ps_holdem` or `ps_shortdeck`). This suggests that the solver job is tailored for specific poker variants, and stopping it involves shutting down the relevant strategy calculations.\\
## Code: 
```
void QSolverJob::stop(){
    qDebug().noquote() << tr("Trying to stop solver.");
    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.stop();
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.stop();
    }
}
```