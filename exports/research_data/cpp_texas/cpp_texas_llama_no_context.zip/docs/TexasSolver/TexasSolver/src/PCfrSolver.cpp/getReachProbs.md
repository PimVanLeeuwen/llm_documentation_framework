`getReachProbs`: The function of `getReachProbs` is to return a vector of vectors containing the reach probabilities for each player.

**Code Description**: This function appears to be part of a poker game solver, specifically designed to calculate and retrieve reach probabilities for multiple players. It iterates through each player, retrieves their private cards, and then calculates the reach probability for each card in the player's hand by using the weight attribute of the PrivateCards object. The calculated reach probabilities are stored in a vector and returned as part of a larger vector structure, where each inner vector represents the reach probabilities for one player.\\
## Code: 
```
vector<vector<float>> PCfrSolver::getReachProbs() {
    vector<vector<float>> retval(this->player_number);
    for(int player = 0;player < this->player_number;player ++){
        vector<PrivateCards> player_cards = this->playerHands(player);
        vector<float> reach_prob(player_cards.size());
        for(std::size_t i = 0;i < player_cards.size();i ++){
            reach_prob[i] = player_cards[i].weight;
        }
        retval[player] = reach_prob;
    }
    return retval;
}
```