**Expected Output**
The function of `execFromFile` is to execute a command line tool from a file, where each line in the file represents a command to be processed.

**Code Description**
`execFromFile` reads a file specified by the input parameter `input_file`, and for each line in the file, it calls the `processCommand` function with that line as an argument. This allows the command line tool to process multiple commands from a single file.\\
## Code: 
```
void CommandLineTool::execFromFile(string input_file){
    std::ifstream infile(input_file);
    std::string input_line;
    while (std::getline(infile, input_line))
    {
        this->processCommand(input_line);
    }

}
```