`build_tree`: The function of `build_tree` is to build a game tree for the poker solver job, based on the specified mode and parameters.

**Code Description**: 
The `build_tree` function appears to be part of a class called `QSolverJob`. It takes no arguments and contains two conditional statements that call different functions (`ps_holdem.build_game_tree` or `ps_shortdeck.build_game_tree`) depending on the value of the `mode` variable. The function seems to be building a game tree for either Hold'em or Short Deck poker, using various parameters such as commit amounts, round number, raise limit, and stack size.\\
## Code: 
```
void QSolverJob::build_tree(){
    qDebug().noquote() << tr("building tree..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        ps_holdem.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }else if(this->mode == Mode::SHORTDECK){
        ps_shortdeck.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }
    qDebug().noquote() << tr("build tree finished");//.toStdString() << endl;
}
```