`RiverRangeManager`: The function of `RiverRangeManager` is to manage river ranges in a poker game, specifically handling the evaluation and locking mechanism for hand comparisons.

**Code Description**: 
The code snippet provided defines the constructor of the `RiverRangeManager` class. It takes a shared pointer to a `Compairer` object as an argument, which is used for evaluating hands. The constructor initializes two member variables: `handEvaluator` with the provided `Compairer` object and `maplock` with a new shared pointer to a mutex (a synchronization primitive).\\
## Code: 
```
RiverRangeManager::RiverRangeManager(shared_ptr<Compairer> handEvaluator) {
    this->handEvaluator = std::move(handEvaluator);
    this->maplock = std::make_shared<std::mutex>();
}
```