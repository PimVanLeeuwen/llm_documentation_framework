`cfr`: The function of `cfr` is to calculate the Counterfactual Regret (CFR) value for a given game state.

**Code Description**: 
The `cfr` function takes in several parameters: `player`, which represents the current player; `node`, which is a shared pointer to a GameTreeNode object; `reach_probs`, which is a vector of reach probabilities; `iter`, which is an integer representing the iteration number; `current_board`, which is a uint64_t value representing the current board state; and `deal`, which is an integer representing the deal.

The function uses a switch statement to determine the type of the GameTreeNode object. Based on the node type, it calls different utility functions (e.g., `actionUtility`, `showdownUtility`, etc.) to calculate the CFR value for that specific game state.

If the node type is unknown, the function throws a runtime_error exception.

The calculated CFR values are returned as a vector of floats.\\
## Code: 
```
vector<float> PCfrSolver::cfr(int player, shared_ptr<GameTreeNode> node, const vector<float> &reach_probs, int iter,
                                    uint64_t current_board,int deal) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
            return actionUtility(player, action_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::SHOWDOWN: {
            shared_ptr<ShowdownNode> showdown_node = std::dynamic_pointer_cast<ShowdownNode>(node);
            return showdownUtility(player, showdown_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::TERMINAL: {
            shared_ptr<TerminalNode> terminal_node = std::dynamic_pointer_cast<TerminalNode>(node);
            return terminalUtility(player, terminal_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::CHANCE: {
            shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
            return chanceUtility(player, chance_node, reach_probs, iter, current_board,deal);
        }default:
            throw runtime_error("node type unknown");
    }
}
```