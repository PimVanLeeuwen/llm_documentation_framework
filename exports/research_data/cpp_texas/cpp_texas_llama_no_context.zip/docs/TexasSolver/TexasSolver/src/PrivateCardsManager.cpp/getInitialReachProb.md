`getInitialReachProb`: The function calculates the initial reach probability for a given player and initial board state.

**Code Description**: This function takes an integer representing the player and a 64-bit unsigned integer representing the initial board state as input. It returns a vector of floats, where each element in the vector corresponds to the weight (probability) of a private card held by the player. The weights are calculated based on whether the card's hands intersect with the initial board state. If there is an intersection, the probability is set to 0; otherwise, it is set to the card's weight.\\
## Code: 
```
vector<float> PrivateCardsManager::getInitialReachProb(int player, uint64_t initialboard) {
    int cards_len =  this->private_cards[player].size();
    vector<float> probs = vector<float>(cards_len);
    for(int i = 0;i < cards_len;i ++){
        PrivateCards pc = this->private_cards[player][i];
        if(Card::boardsHasIntercept(initialboard,Card::boardInts2long(pc.get_hands()))) {
            probs[i] = 0;
        }else{
            probs[i] = this->private_cards[player][i].weight;
        }
    }
    return probs;
}
```