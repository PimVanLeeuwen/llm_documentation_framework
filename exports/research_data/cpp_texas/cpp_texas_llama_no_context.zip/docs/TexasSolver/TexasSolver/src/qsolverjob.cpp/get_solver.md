`get_solver`: The function of `get_solver` is to return a pointer to the appropriate PokerSolver object based on the current mode of the QSolverJob.

**Code Description**: 
The code snippet defines a method called `get_solver` within a class named `QSolverJob`. This method appears to be part of a larger system designed for solving poker-related problems. The function's primary purpose is to determine which type of PokerSolver object should be used based on the current mode set in the `QSolverJob` instance.

The code checks the value of `this->mode`, which seems to be an enumeration (Mode) that can take different values such as HOLDEM and SHORTDECK. Depending on the mode, it returns a pointer to either `ps_holdem` or `ps_shortdeck`. These are presumably instances of PokerSolver tailored for Hold'em and Short Deck poker variants, respectively.

If the mode does not match any of the expected values (HOLDEM or SHORTDECK), the function throws a runtime_error with a message indicating that an unknown mode was encountered. This suggests that the system is designed to handle specific poker game modes and will fail if it encounters a mode it doesn't understand.

The return type of `get_solver` is PokerSolver*, which means it returns a pointer to a PokerSolver object. The use of pointers here implies that the returned object might be used in contexts where memory management is crucial, possibly indicating that the solver objects are dynamically allocated and managed within this system.

Overall, the purpose of `get_solver` seems to be to provide access to the appropriate poker-solving logic based on the current game mode set in the QSolverJob instance.\\
## Code: 
```
PokerSolver* QSolverJob::get_solver(){
    if(this->mode == Mode::HOLDEM){
        return &this->ps_holdem;
    }else if(this->mode == Mode::SHORTDECK){
        return &this->ps_shortdeck;
    }else throw runtime_error("unknown mode in get_solver");
}
```