`getParent`: The function of `getParent` is to return a shared pointer to the parent GameTreeNode, if it exists.

**Code Description**: This function is a member of the GameTreeNode class and returns a shared pointer to its parent node. It uses a shared_ptr (shared smart pointer) to manage the memory of the parent node, which allows for safe and efficient sharing of ownership between different parts of the program. The `lock()` method is used to ensure that the function does not access the parent node if it has been deleted or reset.\\
## Code: 
```
shared_ptr<GameTreeNode>GameTreeNode::getParent() {
    return this->parent.lock();
}
```