`setRangeText`: The function of `setRangeText` is to update the range values in a grid-based data model based on user input.

**Code Description**: This function takes a string input representing multiple ranges, parses each range into its key and value components, and updates the corresponding grid cells with the specified float value. It handles cases where the input format is incorrect or missing, skipping such ranges to prevent errors. The function iterates over each range in the input string, splitting it by commas, and then further splits each range into a key and a value part separated by a colon. If the split results in more than two parts or less than one, it logs an error message and skips that range. It also checks if the key is already present in the `string2ij` map; if not, it appends both the key with 'o' and 's' suffixes to the keys list. For each key, it retrieves its corresponding coordinates from the `string2ij` map and updates the grid cell at those coordinates with the specified float value.\\
## Code: 
```
void RangeSelectorTableModel::setRangeText(QString input_range){
    this->clear_range();
    for(QString one_range:input_range.split(",")){
        if(one_range.trimmed() == "")continue;
        QStringList one_range_list = one_range.split(":");

        if(one_range_list.size() > 2 || one_range_list.size() < 1){
            qDebug().noquote() << QString(tr("skipping range %1, format error, range list should contain two part seperate by ':'")).arg(one_range);
        }

        float range_float = 1.0;
        QString key_range = one_range_list[0];
        QStringList keys;
        if(this->string2ij.count(one_range_list[0])){
            keys.append(key_range);
        }else{
            keys.append(key_range + "o");
            keys.append(key_range + "s");
        }

        for(QString one_key: keys){
            if(one_key.count(" ") == one_key.length() || one_key == "")continue;
            if(!this->string2ij.count(one_key)){
                qDebug().noquote() << QString(tr("skipping range %1, format error")).arg(one_range);
                continue;
            }
            pair<int,int> cord = this->string2ij[one_key];
            if(one_range_list.size() > 1)range_float = one_range_list[1].toFloat();
            this->grids_float[cord.first][cord.second] = range_float;
        }
    }
}
```