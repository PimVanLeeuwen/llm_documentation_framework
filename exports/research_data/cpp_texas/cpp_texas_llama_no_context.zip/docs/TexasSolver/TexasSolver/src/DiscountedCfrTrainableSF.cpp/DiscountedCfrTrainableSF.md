`DiscountedCfrTrainableSF`: The function of `DiscountedCfrTrainableSF` is to initialize and set up the necessary data structures for a Discounted CFR (Counterfactual Regret Minimization) algorithm implementation.

**Code Description**: This code snippet appears to be part of a class constructor, specifically initializing member variables for a `DiscountedCfrTrainableSF` object. It takes in two parameters: a pointer to a vector of private cards (`privateCards`) and an `ActionNode` reference (`actionNode`). The code sets up several vectors to store values related to the CFR algorithm, including `evs`, `r_plus`, and `cum_r_plus`. These vectors seem to be used for storing expected values, regret values, and cumulative regret values, respectively.\\
## Code: 
```
DiscountedCfrTrainableSF::DiscountedCfrTrainableSF(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();
    this->evs = vector<EvsStorage>(this->action_number * this->card_number, (EvsStorage) 0.0);
    this->r_plus = vector<RplusStorage>(this->action_number * this->card_number, (RplusStorage) 0.0);
    this->cum_r_plus = vector<CumRplusStorage>(this->action_number * this->card_number, (CumRplusStorage) 0.0);
}
```