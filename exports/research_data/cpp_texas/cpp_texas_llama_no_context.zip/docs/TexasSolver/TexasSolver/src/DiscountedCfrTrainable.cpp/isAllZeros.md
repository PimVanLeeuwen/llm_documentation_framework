## Expected output
`isAllZeros`: The function of `isAllZeros` is to check if all elements in a given input array are zero.

**Code Description**: This function iterates over each element in the input array and checks if any of them are non-zero. If it finds a single non-zero element, it immediately returns false, indicating that not all elements are zero. If it successfully iterates over the entire array without finding any non-zero elements, it returns true, indicating that all elements are indeed zero.\\
## Code: 
```
bool DiscountedCfrTrainable::isAllZeros(const vector<float>& input_array) {
    for(float i:input_array){
        if (i != 0)return false;
    }
    return true;
}
```