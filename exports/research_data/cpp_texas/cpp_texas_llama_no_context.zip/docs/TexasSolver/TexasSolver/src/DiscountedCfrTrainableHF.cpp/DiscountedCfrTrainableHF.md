`DiscountedCfrTrainableHF`: The function of `DiscountedCfrTrainableHF` is to initialize and set up the necessary data structures for a Discounted CFR (Counterfactual Regret Minimization) algorithm implementation.

**Code Description**: This code snippet appears to be part of a class constructor, specifically initializing member variables for a `DiscountedCfrTrainableHF` object. It takes in two parameters: a pointer to a vector of private cards (`PrivateCards`) and an `ActionNode`. The function sets up various data structures, including vectors to store expected values (`evs`), R+ values (`r_plus`), and cumulative R+ values (`cum_r_plus`). These data structures seem to be related to the computation of discounted CFR.\\
## Code: 
```
DiscountedCfrTrainableHF::DiscountedCfrTrainableHF(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();
    this->evs = vector<EvsStorage>(this->action_number * this->card_number, (EvsStorage) 0.0);
    this->r_plus = vector<RplusStorage>(this->action_number * this->card_number, (RplusStorage) 0.0);
    this->cum_r_plus = vector<CumRplusStorage>(this->action_number * this->card_number, (CumRplusStorage) 0.0);
}
```