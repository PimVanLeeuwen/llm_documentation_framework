`getPreflopCards`: The function of `getPreflopCards` is to retrieve the private cards of a specific player during the preflop stage.

**Code Description**: This function, part of the PrivateCardsManager class, returns a reference to a vector of PrivateCards objects associated with a given player. It takes an integer parameter representing the player's index and uses it to access the corresponding vector in the private_cards data member. The returned vector contains the private cards held by the specified player before the flop stage begins.\\
## Code: 
```
vector<PrivateCards>& PrivateCardsManager::getPreflopCards(int player) {
    return this->private_cards[player];
}
```