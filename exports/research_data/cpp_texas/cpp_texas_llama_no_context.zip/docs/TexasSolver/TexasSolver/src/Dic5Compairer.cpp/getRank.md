**getRank**: The function of `getRank` is to calculate and return a rank based on the given vector of cards.

**Code Description**: This function takes a vector of `Card` objects as input, converts each card into an integer representation (using the `getCardInt()` method), stores these integers in a new vector, and then calls another function named `getRank()` (which is presumably defined elsewhere) to calculate the rank based on this vector of integers.\\
## Code: 
```
int Dic5Compairer::getRank(vector<Card> cards) {
    vector<int> cards_int(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_int[i] = cards[i].getCardInt();
    }
    return this->getRank(cards_int);
}
```