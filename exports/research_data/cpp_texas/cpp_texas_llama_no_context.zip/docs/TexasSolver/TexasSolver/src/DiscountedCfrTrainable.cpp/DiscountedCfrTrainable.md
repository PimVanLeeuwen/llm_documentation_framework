`DiscountedCfrTrainable`: The function of `DiscountedCfrTrainable` is to initialize and set up the necessary data structures for training a Discounted CFR (Counterfactual Regret Minimization) algorithm.

**Code Description**: This code snippet appears to be part of a class implementation, specifically the constructor (`DiscountedCfrTrainable::DiscountedCfrTrainable`) of a `DiscountedCfrTrainable` class. The purpose of this function is to initialize various data structures and member variables that are necessary for training a Discounted CFR algorithm.

The code initializes several vectors: `evs`, `r_plus`, `r_plus_sum`, and `cum_r_plus`. These vectors seem to be used to store expected values, rewards, and cumulative rewards for different actions and card combinations. The sizes of these vectors are determined by the number of actions (`action_number`) and cards (`card_number`), which are obtained from the provided `ActionNode` and `PrivateCards` objects.

The code also initializes a member variable `this->privateCards` with the provided `PrivateCards` object, indicating that this class is likely used in a poker or card game context. The `action_node` parameter is assigned to a member variable `this->action_node`, suggesting that the `ActionNode` object represents a decision node in the game tree.

Overall, the purpose of this code snippet appears to be setting up the necessary data structures for training a Discounted CFR algorithm, which is a popular technique used in game theory and artificial intelligence research.\\
## Code: 
```
DiscountedCfrTrainable::DiscountedCfrTrainable(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();

    this->evs = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus_sum = vector<float>(this->card_number,0.0);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number,0.0);
    //this->cum_r_plus_sum = vector<float>(this->card_number);
}
```