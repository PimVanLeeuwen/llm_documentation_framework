~RoughStrategyViewerModel: The function of ~RoughStrategyViewerModel is to destroy the object.

**Code Description**: This is a destructor function in C++. It is called when an object of the class RoughStrategyViewerModel goes out of scope or is explicitly deleted. The purpose of this function is to release any resources held by the object, such as memory allocated for member variables. In this specific case, the destructor does not perform any actions, it simply exists and will be called automatically when the object is destroyed.\\
## Code: 
```
RoughStrategyViewerModel::~RoughStrategyViewerModel()
{
}
```