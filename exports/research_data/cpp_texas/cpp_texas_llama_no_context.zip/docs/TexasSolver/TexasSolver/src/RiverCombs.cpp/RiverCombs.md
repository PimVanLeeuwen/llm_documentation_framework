`RiverCombs`: The function of `RiverCombs` is to initialize an object with the given parameters, specifically a river comb in poker.

**Code Description**: This code snippet defines a constructor for a class named `RiverCombs`. It takes four parameters: `board`, `private_cards`, `rank`, and `reach_prob_index`. The constructor assigns these parameters to corresponding member variables of the class.\\
## Code: 
```
RiverCombs::RiverCombs(vector<int> board, PrivateCards private_cards, int rank, int reach_prob_index) {
    this->board = board;
    this->rank = rank;
    this->private_cards = private_cards;
    this->reach_prob_index = reach_prob_index;
}
```