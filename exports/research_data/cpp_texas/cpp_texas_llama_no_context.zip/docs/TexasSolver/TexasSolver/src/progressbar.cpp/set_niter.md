`set_niter`: The function of `set_niter` is to set the number of iterations for a progress bar.

**Code Description**: This function, `set_niter`, appears to be part of a class named `progressbar`. It takes an integer parameter `niter` and sets it as the value for `n_cycles`. If `niter` is less than or equal to 0, it throws an invalid argument exception.\\
## Code: 
```
void progressbar::set_niter(int niter) {
    if (niter <= 0) throw std::invalid_argument(
                "progressbar::set_niter: number of iterations null or negative");
    n_cycles = niter;
    return;
}
```