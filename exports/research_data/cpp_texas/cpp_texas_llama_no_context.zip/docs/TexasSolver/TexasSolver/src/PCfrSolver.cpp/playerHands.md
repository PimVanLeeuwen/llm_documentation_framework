**playerHands**: The function of `playerHands` is to return a reference to the vector of private cards for a given player.

**Code Description**: This function, part of the PCfrSolver class, takes an integer parameter representing the player number and returns a reference to a vector of PrivateCards. It uses if-else statements to determine which vector (range1 or range2) to return based on the player number. If the player number is neither 0 nor 1, it throws a runtime_error indicating that the player was not found.\\
## Code: 
```
const vector<PrivateCards> &PCfrSolver::playerHands(int player) {
    if(player == 0){
        return range1;
    }else if (player == 1){
        return range2;
    }else{
        throw runtime_error("player not found");
    }
}
```