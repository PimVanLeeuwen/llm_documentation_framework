`get_payoffs`: The function of `get_payoffs` is to return the payoffs for a given ShowdownNode result and winner.

**Code Description**: This function takes two parameters: `result` of type `ShowDownResult` and `winner` of type `int`. It checks if the showdown result is not a tie (`NOTTIE`) and returns the player payoffs for the specified winner. If the result is a tie, it returns the tie payoffs. The function throws runtime errors if the conditions are not met.\\
## Code: 
```
vector<double> ShowdownNode::get_payoffs(ShowdownNode::ShowDownResult result, int winner) {
    if(result == ShowDownResult::NOTTIE){
        if(winner == -1) throw runtime_error("winner == -1 in tie");
        vector<double> retval = player_payoffs[winner];
        return retval;
    }else{
        // if the showdown is a tie
        if(winner != -1) throw runtime_error("winner != -1 in not tie");
        return this->tie_payoffs;
    }
}
```