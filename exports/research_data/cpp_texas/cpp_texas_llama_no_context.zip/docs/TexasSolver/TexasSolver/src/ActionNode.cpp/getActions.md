`getActions`: The function of `getActions` is to return a reference to the vector of game actions associated with an ActionNode object.

**Code Description**: This function, `getActions`, is a member function of the ActionNode class. It returns a reference to a vector of GameActions objects, which are stored in the `actions` data member of the class. The purpose of this function appears to be to provide access to the game actions associated with an instance of the ActionNode class.\\
## Code: 
```
vector<GameActions>& ActionNode::getActions() {
    return this->actions;
}
```