**Expected Output**
The function of `toString` is to return a string representation of the game action, including any additional information such as the amount.

**Code Description**
This code snippet appears to be part of a class called `GameActions`, which has methods for converting poker actions and amounts into strings. The `toString()` method checks if an "amount" variable is set to -1, indicating that no specific amount should be included in the string representation. If this condition is met, it calls another method (`pokerActionToString`) to convert the game action into a string. Otherwise, it appends the amount (converted to a string using `to_string(amount)`) to the result of calling `pokerActionToString`.\\
## Code: 
```
string GameActions::toString() {
    if(this->amount == -1) {
        return this->pokerActionToString(this->action);
    }else{
        return this->pokerActionToString(this->action) + " " + to_string(amount);
    }
}
```