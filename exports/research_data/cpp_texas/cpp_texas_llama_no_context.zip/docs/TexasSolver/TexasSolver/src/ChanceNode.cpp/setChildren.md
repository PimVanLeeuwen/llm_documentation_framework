## Expected Output
`setChildren`: The function of `setChildren` is to set the children of a ChanceNode object.

**Code Description**: This function takes a shared pointer to a GameTreeNode as an argument and assigns it to the children member variable of the ChanceNode class. It does not perform any validation or error checking on the input, assuming that the provided GameTreeNode is valid.\\
## Code: 
```
void ChanceNode::setChildren(shared_ptr<GameTreeNode> children){
    this->children = children;
}
```