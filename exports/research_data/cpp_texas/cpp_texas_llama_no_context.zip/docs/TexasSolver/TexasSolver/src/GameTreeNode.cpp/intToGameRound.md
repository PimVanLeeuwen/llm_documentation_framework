`intToGameRound`: The function of `intToGameRound` is to convert an integer representing a game round into the corresponding GameTreeNode::GameRound enum value.

**Code Description**: This function takes an integer as input and uses a switch statement to determine which game round it represents. It then returns the corresponding GameTreeNode::GameRound enum value. If the input integer does not match any of the expected values (0-3), it throws a runtime_error with a message indicating that the round was not found.\\
## Code: 
```
GameTreeNode::GameRound GameTreeNode::intToGameRound(int round){
    GameTreeNode::GameRound game_round;
    switch(round){
        case 0:{
            game_round = GameTreeNode::GameRound::PREFLOP;
            break;
        }
        case 1:{
            game_round = GameTreeNode::GameRound::FLOP;
            break;
        }
        case 2:{
            game_round = GameTreeNode::GameRound::TURN;
            break;
        }
        case 3:{
            game_round = GameTreeNode::GameRound::RIVER;
            break;
        }
        default:{
            throw runtime_error(tfm::format("round %s not found",round));
        }
    }
    return game_round;
}
```