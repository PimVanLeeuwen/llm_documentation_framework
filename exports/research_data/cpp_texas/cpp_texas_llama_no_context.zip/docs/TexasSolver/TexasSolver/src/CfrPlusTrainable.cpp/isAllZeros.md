## Expected output
`isAllZeros`: The function of `isAllZeros` is to check if all elements in a given input array are zero.

**Code Description**: This function iterates over each element in the input array. If any element is not equal to zero, it immediately returns false, indicating that not all elements are zero. If the loop completes without finding a non-zero element, it returns true, indicating that all elements are indeed zero.\\
## Code: 
```
bool CfrPlusTrainable::isAllZeros(vector<float> input_array) {
    for(float i:input_array){
        if (i != 0)return false;
    }
    return true;
}
```