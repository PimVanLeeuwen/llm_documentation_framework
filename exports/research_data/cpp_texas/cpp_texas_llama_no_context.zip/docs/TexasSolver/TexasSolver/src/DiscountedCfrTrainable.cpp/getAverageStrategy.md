`getAverageStrategy`: The function calculates the average strategy for a game, where each player's strategy is represented as a vector of probabilities over possible actions.

**Code Description**: This function appears to be part of a class called `DiscountedCfrTrainable`, which seems to implement a variant of the Counterfactual Regret Minimization (CFR) algorithm. The CFR algorithm is used in game theory to compute Nash equilibria for games with multiple players and actions. The `getAverageStrategy` function calculates the average strategy over all possible private information states, where each player's strategy is represented as a vector of probabilities over possible actions.\\
## Code: 
```
const vector<float> DiscountedCfrTrainable::getAverageStrategy() {
    vector<float> average_strategy;
    average_strategy = vector<float>(this->action_number * this->card_number);
    for (int private_id = 0; private_id < this->card_number; private_id++) {
        float r_plus_sum = 0;
        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            r_plus_sum += this->cum_r_plus[index];
        }

        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            if(r_plus_sum) {
                average_strategy[index] = this->cum_r_plus[index] / r_plus_sum;
            }else{
                average_strategy[index] = 1.0 / this->action_number;
            }
        }
    }
    return average_strategy;
}
```