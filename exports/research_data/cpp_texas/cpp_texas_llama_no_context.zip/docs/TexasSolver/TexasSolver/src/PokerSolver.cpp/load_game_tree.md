`load_game_tree`: The function of `load_game_tree` is to load a game tree from a file into the PokerSolver object.

**Code Description**: This function takes a string parameter `game_tree_file`, which represents the path to the file containing the game tree. It creates a new instance of the GameTree class, passing in the file path and a reference to the PokerSolver's deck as parameters. The newly created GameTree object is then assigned to the PokerSolver's `game_tree` member variable.\\
## Code: 
```
void PokerSolver::load_game_tree(string game_tree_file) {
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(game_tree_file,this->deck);
    this->game_tree = game_tree;
}
```