`isDonk`: The function of `isDonk` is to check if a node in the ChanceNode class has been marked as "donk".

**Code Description**: This function returns a boolean value indicating whether the donk attribute of the current object (this) is true. It does not modify any attributes or perform any actions other than returning the state of the donk attribute.\\
## Code: 
```
bool ChanceNode::isDonk(){
    return this->donk;
}
```