**Expected Output**
The function of `toString` is to return a string representation of two private cards, with the card values in ascending order.

**Code Description**
The `toString` function is part of the `PrivateCards` class and its purpose is to convert the private card values into a human-readable format. The function takes no arguments and returns a string. It uses the `Card::intCard2Str` function to convert each card value into a string, and then concatenates these strings together in ascending order.\\
## Code: 
```
string PrivateCards::toString() {
    if (card1 > card2) {
        return Card::intCard2Str(card1) + Card::intCard2Str(card2);
    }else{
        return Card::intCard2Str(card2) + Card::intCard2Str(card1);
    }
}
```