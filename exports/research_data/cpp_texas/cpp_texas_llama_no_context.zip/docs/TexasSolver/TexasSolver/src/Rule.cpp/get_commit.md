`get_commit`: The function of `get_commit` is to return the commit value for a given player.

**Code Description**: This function, part of the Rule class, retrieves and returns the commit value associated with either player 0 or player 1. It throws an exception if any other player number is provided.\\
## Code: 
```
float Rule::get_commit(int player) {
    if (player == 0) return this->ip_commit;
    else if(player == 1) return this->oop_commit;
    else throw runtime_error("unknown player");
}
```