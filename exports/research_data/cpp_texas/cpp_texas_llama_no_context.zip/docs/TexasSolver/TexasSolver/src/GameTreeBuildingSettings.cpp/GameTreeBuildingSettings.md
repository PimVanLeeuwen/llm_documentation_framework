`GameTreeBuildingSettings`: The function of `GameTreeBuildingSettings` is to initialize and set up the settings for building a game tree, which is likely used in poker or other card games.

**Code Description**: This class constructor takes six parameters: flop_ip, turn_ip, river_ip, flop_oop, turn_oop, and river_oop, all of type StreetSetting. It initializes the corresponding member variables with these input values. The purpose of this class is to encapsulate the settings for building a game tree, which can be used in various scenarios such as poker hand evaluation or decision-making algorithms.\\
## Code: 
```
GameTreeBuildingSettings::GameTreeBuildingSettings(
        StreetSetting flop_ip,
        StreetSetting turn_ip,
        StreetSetting river_ip,
        StreetSetting flop_oop,
        StreetSetting turn_oop,
        StreetSetting river_oop):flop_ip(flop_ip),turn_ip(turn_ip),river_ip(river_ip),flop_oop(flop_oop),turn_oop(turn_oop),river_oop(river_oop) {
}
```