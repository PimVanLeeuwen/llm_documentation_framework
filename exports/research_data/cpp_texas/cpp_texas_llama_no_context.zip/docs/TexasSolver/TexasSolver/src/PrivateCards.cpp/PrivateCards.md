`PrivateCards`: The function of `PrivateCards` is to initialize a private card object with two cards and their corresponding weight, relative probability, and hash code.

**Code Description**: This function takes three parameters: `card1`, `card2`, and `weight`. It initializes the `card1` and `card2` member variables with the input values. The `weight` parameter is also stored in a member variable. Additionally, it calculates the relative probability and hash code based on the card values. The function also creates a vector of integers containing both cards and stores it as a member variable called `card_vec`.\\
## Code: 
```
PrivateCards::PrivateCards(int card1, int card2, float weight) {
    this->card1 = card1;
    this->card2 = card2;
    this->weight = weight;
    this->relative_prob = 0;
    this->card_vec = vector<int>{this->card1,this->card2};
    if (card1 > card2){
        this->hash_code = card1 * 52 + card2;
    }else{
        this->hash_code = card2 * 52 + card1;
    }
    this->board_long = Card::boardInts2long(this->card_vec);
}
```