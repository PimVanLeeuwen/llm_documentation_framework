`get_round_str`: The function of `get_round_str` is to return a string representation of the game round in poker, given an enumeration value.

**Code Description**: This function takes a GameTreeNode::GameRound enumeration value as input and returns a corresponding string. It uses the QObject::tr() function to translate the string for internationalization purposes. If the input round is not recognized (i.e., it's not FLOP, TURN, or RIVER), the function throws a runtime_error with an error message indicating that the round must be one of these three values.\\
## Code: 
```
QString TreeItem::get_round_str(GameTreeNode::GameRound round) const{
    if(round == GameTreeNode::GameRound::FLOP){
        return QObject::tr("FLOP");
    }
    else if(round == GameTreeNode::GameRound::TURN){
        return QObject::tr("TURN");
    }
    else if(round == GameTreeNode::GameRound::RIVER){
        return QObject::tr("RIVER");
    }
    else throw runtime_error("round not recognized, must be in flop,turn,river");
}
```