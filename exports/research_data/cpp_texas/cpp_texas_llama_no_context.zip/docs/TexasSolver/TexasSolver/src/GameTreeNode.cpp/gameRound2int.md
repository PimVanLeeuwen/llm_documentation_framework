`gameRound2int`: The function of `gameRound2int` is to convert a game round enum value into an integer representation.

**Code Description**: This function takes a GameTreeNode::GameRound enum value as input and returns the corresponding integer value. It uses if-else statements to check for specific game rounds (PREFLOP, FLOP, TURN, RIVER) and returns the respective integer values (0, 1, 2, 3). If the input game round is not found, it throws a runtime_error with the message "round not found".\\
## Code: 
```
int GameTreeNode::gameRound2int(GameTreeNode::GameRound gameRound) {
    if(gameRound == GameRound::PREFLOP) {
        return 0;
    }else if(gameRound == GameRound::FLOP){
        return 1;
    } else if(gameRound == GameRound::TURN) {
        return 2;
    } else if(gameRound == GameRound::RIVER) {
        return 3;
    }
    throw runtime_error("round not found");
}
```