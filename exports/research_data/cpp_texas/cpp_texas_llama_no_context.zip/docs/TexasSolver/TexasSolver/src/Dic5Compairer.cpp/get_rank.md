## get_rank: The function of `get_rank` is to calculate the rank of a poker hand given two input parameters, `private_hand` and `public_board`, which represent the player's private cards and the community cards on the board respectively.

## Code Description: 
The code snippet provided defines a method called `get_rank` within a class named `Dic5Compairer`. This method takes two 64-bit unsigned integer parameters, `private_hand` and `public_board`, which are likely representing the player's private hand and the community cards on the board in binary format. The function then calls another method named `get_rank` (assuming it is a member of the same class) with the results of converting these integers into board representations using the `Card::long2board` static method. This suggests that the input parameters are initially stored as 64-bit integers, possibly to represent card combinations in a compact binary format, and then converted back into a form suitable for ranking by the poker hand evaluation logic encapsulated within the `get_rank` method.\\
## Code: 
```
int Dic5Compairer::get_rank(uint64_t private_hand, uint64_t public_board) {
    return this->get_rank(Card::long2board(private_hand),Card::long2board(public_board));
}
```