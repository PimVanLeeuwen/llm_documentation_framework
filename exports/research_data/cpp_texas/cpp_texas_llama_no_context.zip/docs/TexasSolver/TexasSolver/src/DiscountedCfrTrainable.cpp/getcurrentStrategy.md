`getcurrentStrategy`: The function of `getcurrentStrategy` is to return the current strategy used by the DiscountedCfrTrainable object.

**Code Description**: This function appears to be a part of a class named DiscountedCfrTrainable, which seems to be related to a game theory or decision-making algorithm. The function getcurrentStrategyNoCache() is called within this function, suggesting that it retrieves and returns the current strategy being used by the object.\\
## Code: 
```
const vector<float> DiscountedCfrTrainable::getcurrentStrategy() {
    return this->getcurrentStrategyNoCache();
}
```