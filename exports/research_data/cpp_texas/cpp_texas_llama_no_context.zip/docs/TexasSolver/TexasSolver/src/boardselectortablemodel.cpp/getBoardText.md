**The function of `getBoardText` is to generate a string representation of the board, where each cell in the grid that has a value (i.e., not zero) is included in the string.**

**The code iterates over two lists: `suitlist` and `ranklist`. For each pair of suit and rank, it checks if the corresponding value in the `grids_float` array is non-zero. If so, it converts the value to a string using `QString("%1").arg(this->grids_string[i][j])`, and appends this string to the result string `retval`. The resulting string contains all non-zero values from the grid, separated by commas.**\\
## Code: 
```
QString BoardSelectorTableModel::getBoardText(){
    QString retval = "";
    for(int i = 0;i < this->suitlist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            if(this->grids_float[i][j] == 0)continue;
            QString one_board_str = QString("%1").arg(this->grids_string[i][j]);
            if(retval == ""){
                retval = one_board_str;
            }else{
                retval = retval + "," + one_board_str;
            }
        }
    }
    return retval;
}
```