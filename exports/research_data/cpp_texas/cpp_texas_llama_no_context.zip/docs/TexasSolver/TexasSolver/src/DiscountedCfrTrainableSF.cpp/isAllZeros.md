**Expected Output**
`isAllZeros`: The function of `isAllZeros` is to check if all elements in a given input array are zero.

**Code Description**: This function, `bool DiscountedCfrTrainableSF::isAllZeros(const vector<float>& input_array)`, takes an input array of floats and returns a boolean value indicating whether all elements in the array are zero. It iterates through each element in the array, checking if any are non-zero. If it finds a single non-zero element, it immediately returns `false`. If it successfully checks all elements without finding any non-zero values, it returns `true`, indicating that all elements in the input array are indeed zero.\\
## Code: 
```
bool DiscountedCfrTrainableSF::isAllZeros(const vector<float>& input_array) {
    for(float i:input_array){
        if (i != 0)return false;
    }
    return true;
}
```