`RoughStrategyItemDelegate`: The function of `RoughStrategyItemDelegate` is to act as a delegate for items in a rough strategy, handling their display and behavior.

**Code Description**: This code snippet defines the constructor for a class called `RoughStrategyItemDelegate`. It takes two parameters: `detailWindowSetting`, which is an instance of the `DetailWindowSetting` class, and `parent`, which is a pointer to a parent object. The constructor initializes the `detailWindowSetting` member variable with the provided value and calls the base class's constructor using the `WordItemDelegate(parent)` syntax.\\
## Code: 
```
RoughStrategyItemDelegate::RoughStrategyItemDelegate(DetailWindowSetting* detailWindowSetting,QObject *parent) :
    WordItemDelegate(parent)
{
    this->detailWindowSetting = detailWindowSetting;
}
```