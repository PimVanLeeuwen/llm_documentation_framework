`GameActions`: The function of `GameActions` is to initialize a game action with the specified poker action and amount, enforcing valid input for certain actions.

**Code Description**: This code snippet defines a constructor for the `GameActions` class. It takes two parameters: `action`, which represents the type of poker action (e.g., raise, bet, check, fold, or call), and `amount`, which is the associated monetary value for the action. The constructor initializes the corresponding member variables with these values while performing input validation.\\
## Code: 
```
GameActions::GameActions(GameTreeNode::PokerActions action, double amount) {
    this->action = action;
    if (action == GameTreeNode::PokerActions::RAISE || action == GameTreeNode::PokerActions::BET ) {
        if (amount == -1) throw runtime_error(tfm::format("raise/bet amount should not be -1, find %s",amount));
    } else {
        if (amount != -1) throw runtime_error(tfm::format("check/fold/call amount should be -1, find %s",amount));
    }
    this->amount = amount;
}
```