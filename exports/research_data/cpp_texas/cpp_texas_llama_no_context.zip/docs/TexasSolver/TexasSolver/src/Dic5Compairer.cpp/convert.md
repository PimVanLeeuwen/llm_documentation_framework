The function of `convert` is to categorize a given strength map into two separate maps: one for flushes and another for non-flushes.

**Code Description**: 
The `convert` function takes an unordered_map of uint64_t to int as input, representing the strength of different card combinations. It clears two pre-existing maps, `flush_map` and `other_map`, which will be used to store the strengths of flushes and non-flushes respectively. The function then iterates over each entry in the input map, calculates a hash value for the cards using the `ranks_hash` function, and checks if the combination is a flush using the `is_flush` function. If it's a flush, the strength is stored in `flush_map`; otherwise, it's stored in `other_map`.\\
## Code: 
```
void FiveCardsStrength::convert(unordered_map<uint64_t, int>& strength_map) {
    flush_map.clear(); other_map.clear();
    auto it = strength_map.begin(), it_end = strength_map.end();
    for (; it != it_end; it++) {
        uint64_t cards_hash = it->first;
        uint64_t hash = ranks_hash(cards_hash);
        if (is_flush(cards_hash)) flush_map[cards_hash] = it->second;
        else {
            /*if (other_map.count(hash) && other_map[hash] != it->second) {
                printf("%zx,%zx:%d != %d\n", cards_hash, hash, it->second, other_map[hash]);
            }*/
            other_map[hash] = it->second;
        }
    }
}
```