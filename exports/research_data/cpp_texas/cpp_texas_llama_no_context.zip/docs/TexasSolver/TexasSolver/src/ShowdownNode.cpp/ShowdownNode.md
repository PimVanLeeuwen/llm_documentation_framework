`ShowdownNode`: The function of `ShowdownNode` is to initialize a node in the game tree for a showdown scenario, where players' payoffs are determined based on their individual actions.

**Code Description**: This code snippet defines a constructor for the `ShowdownNode` class. It takes four parameters: `tie_payoffs`, `player_payoffs`, `round`, and `pot`. The constructor initializes the `tie_payoffs` and `player_payoffs` member variables of the `ShowdownNode` object with the provided values, using move semantics to transfer ownership of the vectors. It also calls the base class constructor (`GameTreeNode`) to initialize the `round` and `parent` member variables.\\
## Code: 
```
ShowdownNode::ShowdownNode(vector<double> tie_payoffs, vector<vector<double>> player_payoffs,
                           GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode>parent):
                           GameTreeNode(round,pot,std::move(parent)) {
    this->tie_payoffs = std::move(tie_payoffs);
    this->player_payoffs = std::move(player_payoffs);
}
```