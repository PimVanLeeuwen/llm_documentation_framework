**copyStrategy**: The function of `copyStrategy` is to copy the strategy from another trainable object, specifically a `DiscountedCfrTrainable`, into the current object.

**Code Description**: This function takes a shared pointer to a `Trainable` object as input and attempts to cast it to a `DiscountedCfrTrainable`. If successful, it copies the contents of the `r_plus` and `cum_r_plus` vectors from the other trainable object into the corresponding vectors in the current object.\\
## Code: 
```
void DiscountedCfrTrainable::copyStrategy(shared_ptr<Trainable> other_trainable){
    shared_ptr<DiscountedCfrTrainable> trainable = dynamic_pointer_cast<DiscountedCfrTrainable>(other_trainable);
    this->r_plus.assign(trainable->r_plus.begin(),trainable->r_plus.end());
    this->cum_r_plus.assign(trainable->cum_r_plus.begin(),trainable->cum_r_plus.end());
}
```