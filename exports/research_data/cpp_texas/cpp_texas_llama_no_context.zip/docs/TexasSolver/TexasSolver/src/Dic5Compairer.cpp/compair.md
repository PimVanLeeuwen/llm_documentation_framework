`compair`: The function of `compair` is to compare two private card combinations with a public board in a card game, and return the comparison result.

**Code Description**: The `compair` function takes three parameters: `private_former`, `private_latter`, and `public_board`. It checks if the sizes of `private_former` and `private_latter` are both 2, and if the size of `public_board` is 5. If any of these conditions are not met, it throws a runtime error with an informative message. Then, it combines each private card combination with the public board to form two new card combinations, calculates their ranks using the `getRank` function, and finally compares the ranks using the `compairRanks` function to return the comparison result.\\
## Code: 
```
Compairer::CompairResult
Dic5Compairer::compair(vector<int> private_former, vector<int> private_latter, vector<int> public_board) {
    if(private_former.size() != 2)
        throw runtime_error(
                tfm::format("private former size incorrect,excepted 2, actually %s",private_former.size())
        );
    if(private_latter.size() != 2)
        throw runtime_error(
                tfm::format("private latter size incorrect,excepted 2, actually %s",private_latter.size())
        );
    if(public_board.size() != 5)
        throw runtime_error(
                tfm::format("public board size incorrect,excepted 2, actually %s",public_board.size())
        );

    vector<int> former_cards(private_former);
    former_cards.insert(former_cards.end(),public_board.begin(),public_board.end());
    int rank_former = this->getRank(former_cards);

    vector<int> latter_cards(private_latter);
    latter_cards.insert(latter_cards.end(),public_board.begin(),public_board.end());
    int rank_latter = this->getRank(latter_cards);

    return this->compairRanks(rank_former,rank_latter);
}
```