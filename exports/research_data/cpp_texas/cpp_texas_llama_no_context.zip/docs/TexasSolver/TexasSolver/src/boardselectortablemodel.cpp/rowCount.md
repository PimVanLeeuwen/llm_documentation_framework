`rowCount`: The function of `rowCount` is to return the total number of rows in the table model, which corresponds to the size of the suitlist.

**Code Description**: This function is a part of the QAbstractTableModel interface and is used to determine the number of rows that should be displayed in the view. In this specific implementation, it returns the size of the suitlist, indicating that each row in the table model represents an item in the suitlist.\\
## Code: 
```
int BoardSelectorTableModel::rowCount(const QModelIndex &parent) const {
    return this->suitlist.size();
}
```