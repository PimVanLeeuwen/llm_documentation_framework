## getCards: The function of `getCards` is to return a reference to the vector of cards stored in the ChanceNode object.

**Code Description**: This function, `getCards`, is a member function of the ChanceNode class. It returns a constant reference to a vector of Card objects, which are presumably the cards associated with this particular node in some game or simulation. The function does not modify the vector; it simply provides access to its contents.\\
## Code: 
```
const vector<Card>& ChanceNode::getCards() {
    return this->cards;
}
```