`ActionNode`: The function of `ActionNode` is to represent a node in the game tree that corresponds to an action taken by a player.

**Code Description**: 
The `ActionNode` class inherits from `GameTreeNode` and takes several parameters: a vector of `GameActions`, a vector of child nodes, the current player, the game round, the pot, and a pointer to the parent node. The constructor initializes these parameters and moves ownership of the vectors and shared pointers to the new object.\\
## Code: 
```
ActionNode::ActionNode(vector<GameActions> actions, vector<shared_ptr<GameTreeNode>> childrens, int player,
                       GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent) :GameTreeNode(round,pot,std::move(parent)){
    this->actions = std::move(actions);
    this->player = player;
    this->childrens = std::move(childrens);
    //cout << "ActionNode created" << endl;
}
```