`getRound`: The function of `getRound` is to return the current game round.

**Code Description**: This function, `getRound`, is a member function of the `GameTreeNode` class. It returns the value of the `round` data member, which presumably represents the current round number in a game.\\
## Code: 
```
GameTreeNode::GameRound GameTreeNode::getRound() {
    return this->round;
}
```