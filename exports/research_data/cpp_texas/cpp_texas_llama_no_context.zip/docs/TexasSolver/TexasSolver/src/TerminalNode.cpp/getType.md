`getType`: The function of `getType` is to return the type of a game tree node.

**Code Description**: This code snippet appears to be part of a class hierarchy for a game tree data structure. Specifically, it defines a method called `getType()` within a class named `TerminalNode`. The `getType()` method returns an enumeration value named `TERMINAL`, which suggests that this node represents the end of a game tree branch (i.e., a terminal state).\\
## Code: 
```
GameTreeNode::GameTreeNodeType TerminalNode::getType() {
    return TERMINAL;
}
```