`get_setting`: The function of `get_setting` is to retrieve a specific StreetSetting object based on the player and round input parameters.

**Code Description**: This function takes two string parameters, `player` and `round`, and returns a reference to a StreetSetting object. It uses if-else statements to check for valid combinations of player and round inputs, and throws a runtime_error exception if an invalid combination is provided. The function appears to be part of a larger system that builds a game tree, with the returned StreetSetting objects likely used to configure the tree-building process based on different player positions (IP or OOP) and rounds (flop, turn, river).\\
## Code: 
```
StreetSetting& GameTreeBuildingSettings::get_setting(string player,string round){
    if(player == "ip" && round == "flop") return flop_ip;
    else if(player == "ip" && round == "turn") return turn_ip;
    else if(player == "ip" && round == "river") return river_ip;
    else if(player == "oop" && round == "flop") return flop_oop;
    else if(player == "oop" && round == "turn") return turn_oop;
    else if(player == "oop" && round == "river") return river_oop;
    else throw runtime_error("get_setting not valid");
}
```