`setRangeAt`: The function of `setRangeAt` is to set a specific value in the grid at position (i, j) for a given range.

**Code Description**: This function is part of the RangeSelectorTableModel class and is used to update the value of a cell in the grid. It takes three parameters: i and j, which represent the row and column indices respectively, and value, which is the new value to be set at that position. The function first checks if the provided indices are valid (i.e., within the bounds of the ranklist), and if so, it updates the corresponding cell in the grids_float array with the given value.\\
## Code: 
```
void RangeSelectorTableModel::setRangeAt(int i, int j,float value){
    if(i < 0 || i >= this->ranklist.size()){
        qDebug().noquote() << "RangeSelectorTableModel::setRangeAt i not valid: " << i;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "RangeSelectorTableModel::setRangeAt j not valid: " << j;
    }
    else{
        this->grids_float[i][j] = value;
    }
}
```