`setTrainable`: The function of `setTrainable` is to set the trainables and player private cards for an ActionNode.

**Code Description**: This function takes two parameters: a vector of shared pointers to Trainable objects and a pointer to a vector of PrivateCards. It assigns these values to the corresponding member variables of the ActionNode class, effectively setting the trainable elements and player private cards for this node in the action graph.\\
## Code: 
```
void ActionNode::setTrainable(vector<shared_ptr<Trainable>> trainables,vector<PrivateCards>* player_privates) {
    this->trainables = trainables;
    this->player_privates = player_privates;
}
```