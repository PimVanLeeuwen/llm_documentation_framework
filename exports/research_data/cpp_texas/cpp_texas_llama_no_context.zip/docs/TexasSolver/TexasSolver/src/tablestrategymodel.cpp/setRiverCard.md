`setRiverCard`: The function of `setRiverCard` is to set the river card in the TableStrategyModel.

**Code Description**: This function takes a Card object as input, assigns it to the member variable `river_card`, and updates the internal state of the TableStrategyModel with the provided river card.\\
## Code: 
```
void TableStrategyModel::setRiverCard(Card river_card){
    this->river_card = river_card;
}
```