**split**: The function of `split` is to split a given string into substrings based on a specified delimiter character and store the resulting substrings in a vector.

**Code Description**: This function takes three parameters: a string `s`, a delimiter character `c`, and a reference to a vector of strings `v`. It iterates through the input string `s` using the `find` method, which returns the position of the first occurrence of the delimiter character. The substrings between consecutive occurrences of the delimiter are then extracted using the `substr` method and added to the vector `v`. If the end of the string is reached without finding another delimiter, the remaining substring is also added to the vector.\\
## Code: 
```
void split(const string& s, char c,
           vector<string>& v) {
    string::size_type i = 0;
    string::size_type j = s.find(c);

    while (j != string::npos) {
        v.push_back(s.substr(i, j-i));
        i = ++j;
        j = s.find(c, j);

        if (j == string::npos)
            v.push_back(s.substr(i, s.length()));
    }
}
```