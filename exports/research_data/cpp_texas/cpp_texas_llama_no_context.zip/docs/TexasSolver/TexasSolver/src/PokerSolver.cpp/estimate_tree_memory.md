**estimate_tree_memory**: 
The function estimates the memory required by a game tree in poker, given two player ranges and a board.

**Code Description**: 
This function appears to be part of a PokerSolver class and is used to estimate the memory required for a game tree. It takes three parameters: `range1` (a string representing one player's range), `range2` (a string representing another player's range), and `board` (a string representing the current board state). The function first checks if a game tree has been built, and if not, it prints an error message and returns 0. If a game tree exists, it converts the input strings to vectors of PrivateCards objects using the `PrivateRangeConverter::rangeStr2Cards` function. It then calls the `estimate_tree_memory` method on the game tree object, passing in the number of cards remaining in the deck (minus the board size), and the sizes of the two player ranges. The result is returned as a long long integer.\\
## Code: 
```
long long PokerSolver::estimate_tree_memory(QString range1,QString range2,QString board){
    if(this->game_tree == nullptr){
        qDebug().noquote() << QObject::tr("Please buld tree first.");
        return 0;
    }
    else{
        string player1RangeStr = range1.toStdString();
        string player2RangeStr = range2.toStdString();

        vector<string> board_str_arr = string_split(board.toStdString(),',');
        vector<int> initialBoard;
        for(string one_board_str:board_str_arr){
            initialBoard.push_back(Card::strCard2int(one_board_str));
        }

        vector<PrivateCards> range1 = PrivateRangeConverter::rangeStr2Cards(player1RangeStr,initialBoard);
        vector<PrivateCards> range2 = PrivateRangeConverter::rangeStr2Cards(player2RangeStr,initialBoard);
        return this->game_tree->estimate_tree_memory(this->deck.getCards().size() - initialBoard.size(),range1.size(),range2.size());
    }
}
```