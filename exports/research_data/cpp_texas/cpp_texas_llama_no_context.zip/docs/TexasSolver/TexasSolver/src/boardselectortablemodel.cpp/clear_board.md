`clear_board`: The function of `clear_board` is to reset all values in the `grids_float` array to 0, effectively clearing the board.

**Code Description**: This function iterates over a 2D array (`grids_float`) using two nested loops. It clears the contents of this array by setting each element to 0. The outer loop iterates over the rows (represented by `i`), and the inner loop iterates over the columns (represented by `j`). This process is repeated for all elements in the array, effectively resetting its values.\\
## Code: 
```
void BoardSelectorTableModel::clear_board(){
    for(int i = 0;i < this->suitlist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_float[i][j] = 0;
        }
    }
}
```