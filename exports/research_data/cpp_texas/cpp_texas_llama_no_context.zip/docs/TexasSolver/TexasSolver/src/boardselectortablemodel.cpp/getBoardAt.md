`getBoardAt`: The function of `getBoardAt` is to retrieve the value at a specific position in a 2D grid.

**Code Description**: This function, `getBoardAt`, is part of the `BoardSelectorTableModel` class. It takes two integer parameters, `i` and `j`, which represent the row and column indices respectively. The function checks if these indices are within valid ranges for the `ranklist` vector and the 2D array `grids_float`. If the indices are invalid, it logs an error message using `qDebug()` and returns a default value of 0. Otherwise, it returns the value at the specified position in the `grids_float` array.\\
## Code: 
```
float BoardSelectorTableModel::getBoardAt(int i, int j){
    if(i < 0 || i >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::getBoardAt i not valid: " << i;
        return 0;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::getBoardAt j not valid: " << j;
        return 0;
    }
    else{
        return this->grids_float[i][j];
    }
}
```