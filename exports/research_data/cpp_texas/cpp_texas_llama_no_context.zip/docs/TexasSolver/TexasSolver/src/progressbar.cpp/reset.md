`reset`: The function of `reset` is to reset the progress bar's state to its initial condition.

**Code Description**: The `reset` function resets the progress bar's properties, including setting the progress value back to 0, indicating that no updates have been called (`update_is_called = false`), and resetting the last percentage displayed (`last_perc = 0`).\\
## Code: 
```
void progressbar::reset() {
    progress = 0,
            update_is_called = false;
    last_perc = 0;
    return;
}
```