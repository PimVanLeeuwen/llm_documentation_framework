`parent`: The function of `parent` is to return the parent index model for a given child index, which in this case always returns an empty QModelIndex.

**Code Description**: This code snippet defines a custom implementation of the `parent` method in the `RoughStrategyViewerModel` class. In Qt's item view framework, the `parent` method is used to determine the parent index of a given child index. The default implementation returns the parent index by calling the `parent()` method on the child index. However, this custom implementation always returns an empty QModelIndex, indicating that there is no parent index for the given child index.\\
## Code: 
```
QModelIndex RoughStrategyViewerModel::parent(const QModelIndex &child) const{
    return QModelIndex();
}
```