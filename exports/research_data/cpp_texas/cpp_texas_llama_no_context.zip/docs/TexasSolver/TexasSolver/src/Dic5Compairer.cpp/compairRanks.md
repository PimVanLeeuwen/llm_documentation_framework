`compairRanks`: The function of `compairRanks` is to compare the ranks of two cards and return a result indicating which card has a higher rank.

**Code Description**: This function takes in two integer parameters, `rank_former` and `rank_latter`, representing the ranks of two cards. It then uses if-else statements to determine the comparison result based on the values of these integers. If `rank_former` is less than `rank_latter`, it returns a value indicating that the latter card has a higher rank. If `rank_former` is greater than `rank_latter`, it returns a value indicating that the former card has a higher rank. If both ranks are equal, it returns a value indicating equality. The function returns an enum type called `CompairResult`.\\
## Code: 
```
Compairer::CompairResult Dic5Compairer::compairRanks(int rank_former, int rank_latter) {
    if (rank_former < rank_latter) {
        // rank更小的牌更大，0是同花顺
        return CompairResult::LARGER;
    } else if (rank_former > rank_latter) {
        return CompairResult::SMALLER;
    } else {
        // rank_former == rank_latter
        return CompairResult::EQUAL;
    }
}
```