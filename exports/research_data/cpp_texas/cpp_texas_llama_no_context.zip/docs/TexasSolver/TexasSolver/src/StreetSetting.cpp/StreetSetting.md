**StreetSetting**: The function of `StreetSetting` is to initialize a StreetSetting object with given parameters, which include bet sizes, raise sizes, donk sizes, and an all-in flag.

**Code Description**: This code defines a constructor for the `StreetSetting` class. It takes four parameters: three vectors (`bet_sizes`, `raise_sizes`, and `donk_sizes`) of float values, and a boolean value (`allin`). The constructor assigns these input values to corresponding member variables of the `StreetSetting` object.\\
## Code: 
```
StreetSetting::StreetSetting(vector<float> bet_sizes, vector<float> raise_sizes, vector<float> donk_sizes,
                             bool allin) {
    this->bet_sizes = bet_sizes;
    this->raise_sizes = raise_sizes;
    this->donk_sizes = donk_sizes;
    this->allin = allin;
}
```