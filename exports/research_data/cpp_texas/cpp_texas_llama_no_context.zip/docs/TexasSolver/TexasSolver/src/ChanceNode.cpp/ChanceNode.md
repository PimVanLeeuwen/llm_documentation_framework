`ChanceNode`: The function of `ChanceNode` is to initialize a node in the game tree with a chance event, which includes setting up the children nodes, round, pot, parent node, cards, and donk status.

**Code Description**: 
The ChanceNode class constructor initializes a new node in the game tree that represents a chance event. It takes several parameters: shared_ptr to GameTreeNode children (the child nodes), GameTreeNode::GameRound round (the current round of the game), double pot (the current pot size), shared_ptr to GameTreeNode parent (the parent node), const vector<Card>& cards (the cards involved in the chance event), and bool donk (a flag indicating whether it's a donk bet). The constructor sets up these parameters for the new ChanceNode instance.\\
## Code: 
```
ChanceNode::ChanceNode(const shared_ptr<GameTreeNode> children, GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent,
                       const vector<Card>& cards,bool donk): GameTreeNode(round,pot,std::move(parent)),cards(cards) {
    this->children = children;
    this->donk = donk;
}
```