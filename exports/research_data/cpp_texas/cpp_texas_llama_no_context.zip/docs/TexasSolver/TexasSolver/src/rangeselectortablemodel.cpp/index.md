`index`: The function of `index` is to return a QModelIndex object that represents the item at the specified row and column in the table model, or an invalid QModelIndex if the index does not exist.

**Code Description**: This function is part of the RangeSelectorTableModel class and is used to retrieve a QModelIndex object for a specific location in the table model. It takes three parameters: `row`, `column`, and `parent`. The `hasIndex` function is called with these parameters to check if the index exists, and if it does not, an invalid QModelIndex is returned. If the index does exist, a new QModelIndex is created using the `createIndex` function and returned.\\
## Code: 
```
QModelIndex RangeSelectorTableModel::index(int row, int column,
          const QModelIndex &parent) const  {
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    return createIndex(row, column, nullptr);
}
```