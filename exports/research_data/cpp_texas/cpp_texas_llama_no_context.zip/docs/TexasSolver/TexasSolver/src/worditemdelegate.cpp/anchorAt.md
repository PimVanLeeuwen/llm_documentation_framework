## Expected Output
`anchorAt`: The function of `anchorAt` is to find the anchor (link) at a given point in a HTML document.

**Code Description**: This function, `anchorAt`, is part of the `WordItemDelegate` class and is used to determine which link (if any) is located at a specific point within a QTextDocument. It takes two parameters: a QString representing the HTML content and a QPoint indicating the location on the screen where the anchor should be found. The function uses the QTextDocument's document layout to identify the anchor at the specified point, returning it as a QString.\\
## Code: 
```
QString WordItemDelegate::anchorAt(QString html, const QPoint &point) const {
    QTextDocument doc;
    doc.setHtml(html);

    auto textLayout = doc.documentLayout();
    Q_ASSERT(textLayout != 0);
    return textLayout->anchorAt(point);
}
```