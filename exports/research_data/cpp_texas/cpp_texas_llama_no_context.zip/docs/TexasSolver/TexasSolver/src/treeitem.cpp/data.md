`data`: The function of `data` is to return a string representation of the current node in a game tree, based on its position and parent node.

**Code Description**: This function appears to be part of a class called `TreeItem`, which seems to be used for displaying or manipulating a game tree data structure. It uses shared pointers to access the parent and current nodes, and dynamic casting to determine the type of these nodes. The function returns a string that describes the current node's position in the tree, including its round number and any relevant actions or chance events.\\
## Code: 
```
QVariant TreeItem::data() const
{
    shared_ptr<GameTreeNode> parentNode = this->m_treedata.lock()->getParent();
    shared_ptr<GameTreeNode> currentNode = this->m_treedata.lock();
    if(parentNode == nullptr){
        return TreeItem::get_round_str(currentNode->getRound()) + QObject::tr(" begin");
    }
    if(parentNode->getType() == GameTreeNode::GameTreeNodeType::ACTION){
        shared_ptr<ActionNode> parentActionNode = dynamic_pointer_cast<ActionNode>(parentNode);
        vector<GameActions>& actions = parentActionNode->getActions();
        vector<shared_ptr<GameTreeNode>>& childrens = parentActionNode->getChildrens();
        for(std::size_t i = 0;i < childrens.size();i ++){
            if(childrens[i] == currentNode){
                float amount = childrens[i]->getPot() - parentNode->getPot();
                return (parentActionNode->getPlayer() == 0 ? QObject::tr("IP "):QObject::tr("OOP ")) + \
                       TreeItem::get_game_action_str(actions[i].getAction(),actions[i].getAmount());
            }
        }
    }if(parentNode->getType() == GameTreeNode::GameTreeNodeType::CHANCE){
        shared_ptr<ChanceNode> chanceNode = dynamic_pointer_cast<ChanceNode>(parentNode);
        if(chanceNode->getRound() == GameTreeNode::GameRound::FLOP){
            return QObject::tr("DEAL FLOP CARD");
        }
        else if(chanceNode->getRound() == GameTreeNode::GameRound::TURN){
            return QObject::tr("DEAL TURN CARD");
        }
        else if(chanceNode->getRound() == GameTreeNode::GameRound::RIVER){
            return QObject::tr("DEAL RIVER CARD");
        }else throw runtime_error("round not recognized");
    }
    return "NodeError";
}
```