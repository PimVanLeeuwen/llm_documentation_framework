**Expected Output**
`isAllZeros`: The function of `isAllZeros` is to check if all elements in a given input array are zero.

**Code Description**: This function, `bool DiscountedCfrTrainableHF::isAllZeros(const vector<float>& input_array)`, takes an input parameter which is a vector of floats. It iterates over each element in the vector and checks if any of them are not equal to zero. If it finds such an element, it immediately returns false, indicating that not all elements in the array are zero. If it successfully checks all elements without finding any non-zero ones, it returns true, signifying that all elements in the input array are indeed zero.\\
## Code: 
```
bool DiscountedCfrTrainableHF::isAllZeros(const vector<float>& input_array) {
    for(float i:input_array){
        if (i != 0)return false;
    }
    return true;
}
```