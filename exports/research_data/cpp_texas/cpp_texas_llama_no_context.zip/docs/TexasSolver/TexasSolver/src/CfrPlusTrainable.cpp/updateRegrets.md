`updateRegrets`: The function of `updateRegrets` is to update the regrets and cumulative regrets for each action-private pair in a CFR+ algorithm.

**Code Description**: This function updates the regrets and cumulative regrets for each action-private pair based on the provided regrets, iteration number, and reach probabilities. It first checks if the length of the provided regrets matches the expected size, then initializes arrays to store the sum of R+ values and cumulative R+ values. It then iterates over each action-private pair, updates the R+ value for each pair by taking the maximum of 0 and the previous R+ value plus the current regret, and accumulates the updated R+ values in separate arrays. Finally, it updates the cumulative regrets for each action-private pair based on the iteration number and the accumulated R+ values.\\
## Code: 
```
void CfrPlusTrainable::updateRegrets(const vector<float>& regrets, int iteration_number, const vector<float>& reach_probs) {
    this->regrets = regrets;
    if(regrets.size() != this->action_number * this->card_number) throw runtime_error("length not match");

    //Arrays.fill(this.r_plus_sum,0);
    fill(r_plus_sum.begin(),r_plus_sum.end(),0);
    fill(cum_r_plus_sum.begin(),cum_r_plus_sum.end(),0);
    for (int action_id = 0;action_id < action_number;action_id ++) {
        for(int private_id = 0;private_id < this->card_number;private_id ++){
            int index = action_id * this->card_number + private_id;
            float one_reg = regrets[index];

            // 更新 R+
            this->r_plus[index] = max((float)0.0,one_reg + this->r_plus[index]);
            this->r_plus_sum[private_id] += this->r_plus[index];

            // 更新累计策略
            this->cum_r_plus[index] += this->r_plus[index] * iteration_number;
            this->cum_r_plus_sum[private_id] += this->cum_r_plus[index];
        }
    }
}
```