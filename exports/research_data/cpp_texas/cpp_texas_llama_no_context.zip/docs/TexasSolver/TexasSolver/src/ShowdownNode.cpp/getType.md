`getType`: The function of `getType` is to return the type of a game tree node, specifically in this case, a ShowdownNode.

**Code Description**: This code snippet appears to be part of a class hierarchy for a game tree data structure. It defines a method `getType()` within a class named `ShowdownNode`. The method returns an enumeration value named `SHOWDOWN`, which suggests that the node represents a specific type of game state or situation, likely related to a showdown in a card game like poker.\\
## Code: 
```
GameTreeNode::GameTreeNodeType ShowdownNode::getType() {
    return SHOWDOWN;
}
```