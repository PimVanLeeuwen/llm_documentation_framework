`getRiverCombos`: The function of `getRiverCombos` is to retrieve the river combinations for a given player.

**Code Description**: This function takes three parameters: an integer representing the player, a vector of private cards (riverCombos), and a vector of integers representing the board. It first converts the board vector into a 64-bit unsigned integer using the `Card::boardInts2long` method. The function then calls another overloaded version of `getRiverCombos`, passing in the player, riverCombos, and the converted board long value. The function returns a reference to a vector of RiverCombs, which is presumably used to store the retrieved river combinations for the given player.\\
## Code: 
```
const vector<RiverCombs> &
RiverRangeManager::getRiverCombos(int player, const vector<PrivateCards> &riverCombos, const vector<int> &board) {
    uint64_t board_long = Card::boardInts2long(board);
    return this->getRiverCombos(player,riverCombos,board_long);
}
```