`indPlayer2Player`: The function of `indPlayer2Player` is to find the index of a card in the private cards of one player that matches a card in the private cards of another player.

**Code Description**: This function takes three parameters: `from_player`, `to_player`, and `index`. It first checks if the provided `index` is within the valid range for the private cards of the `from_player`. If not, it throws a runtime error. Then, it uses the hash code of the card at the specified `index` in the private cards of the `from_player` to look up its index in the private cards of the `to_player`. If no match is found, it returns -1; otherwise, it returns the index of the matching card.\\
## Code: 
```
int PrivateCardsManager::indPlayer2Player(int from_player, int to_player, int index) {
    if(index < 0 || index >= this->getPreflopCards(from_player).size()) throw runtime_error("index out of range");
    //PrivateCards player_combo = this->getPreflopCards(from_player)[index];
    int to_player_index = this->card_player_index[this->private_cards[from_player][index].hashCode()][to_player];
    if(to_player_index == -1){
        return -1;
    }else {
        return to_player_index;
    }
}
```