`toBoardLong`: The function of `toBoardLong` is to return the board_long value of a PrivateCards object.

**Code Description**: This function appears to be part of a class called PrivateCards and is used to convert or retrieve the board state into a long integer representation. It returns the existing board_long value, which suggests that this value has been previously set or calculated within the class.\\
## Code: 
```
uint64_t PrivateCards::toBoardLong() {
    return this->board_long;
    //return Card::boardInts2long(this->card_vec);
}
```