**CfrPlusTrainable**: The function of `CfrPlusTrainable` is to initialize and set up the necessary data structures for a CFR+ (Counterfactual Regret Minimization) algorithm implementation.

**Code Description**: This code snippet appears to be part of a class definition, specifically initializing member variables for a CFR+ trainable object. It takes in two parameters: `action_node` and `privateCards`, which are used to set up the internal data structures required for the CFR+ algorithm. The code initializes vectors to store values such as `r_plus`, `cum_r_plus`, and `retval`, which seem to be related to regret calculations and cumulative sums, likely used in the decision-making process of the CFR+ algorithm.\\
## Code: 
```
CfrPlusTrainable::CfrPlusTrainable(shared_ptr<ActionNode> action_node, vector<PrivateCards> privateCards) {
    this->action_node = action_node;
    this->privateCards = privateCards;
    this->action_number = action_node->getChildrens().size();
    this->card_number = privateCards.size();

    this->r_plus = vector<float>(this->action_number * this->card_number);
    this->r_plus_sum = vector<float>(this->card_number);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number);
    this->cum_r_plus_sum = vector<float>(this->card_number);
    this->retval = vector<float>(this->action_number * this->card_number);
}
```