## Expected Output
`startWorking`: The function of `startWorking` is to continuously read input from the console until it is terminated, and for each line of input, it calls the `processCommand` method with that line as an argument.

## Code Description
**Code Content:** 
`void CommandLineTool::startWorking() {
    string input_line;
    while(cin) {
        getline(cin, input_line);
        this->processCommand(input_line);
    };
}`

This function appears to be part of a command-line tool class. It uses the `cin` object (which is typically used for console input in C++) to read lines of text from the user. The `getline` function is used to get each line, and then it calls the `processCommand` method with that line as an argument. This process continues until the console input is terminated, which usually happens when the program exits or encounters an error.\\
## Code: 
```
void CommandLineTool::startWorking() {
    string input_line;
    while(cin) {
        getline(cin, input_line);
        this->processCommand(input_line);
    };
}
```