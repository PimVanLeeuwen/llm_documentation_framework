`solving`: The function of `solving` is to initiate a solving process for a poker strategy problem, specifically for Hold'em and ShortDeck modes.

**Code Description**: This function appears to be part of a class called `QSolverJob`, which seems to be responsible for training or solving poker strategy problems using the PokerStrategy (PS) library. The function takes various parameters such as game mode, ranges, board, iteration limits, and other settings, and calls the corresponding train method on either `ps_holdem` or `ps_shortdeck` objects depending on the game mode.\\
## Code: 
```
void QSolverJob::solving(){
    // TODO  为什么ui上多次求解会积累memory？哪里leak了？
    // TODO  为什么有时候会莫名闪退？
    qDebug().noquote() << tr("Start Solving..");//.toStdString() << std::endl;

    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.train(
            this->range_ip,
            this->range_oop,
            this->board,
            "",
            max_iteration,
            this->print_interval,
            "discounted_cfr",
            -1,
            this->accuracy,
            this->use_isomorphism,
            this->use_halffloats,
            this->thread_number
        );
    }
    qDebug().noquote() << tr("Solving done.");//.toStdString() << std::endl;
}
```