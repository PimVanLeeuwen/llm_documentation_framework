**estimate_tree_memory**: 
The function estimates the memory required to store a tree data structure for a given poker game scenario, based on the provided ranges and board.

**Code Description**: 
This function appears to be part of a class called `QSolverJob` and is used to estimate the memory requirements for a tree data structure in a poker solver. It takes three parameters: `range1`, `range2`, and `board`, which are likely strings representing the ranges of hands or board configurations being considered. The function uses an if-else statement to determine which set of rules (Hold'em or Shortdeck) to apply, based on the value of the `mode` variable within the class. It then calls a corresponding method (`estimate_tree_memory`) from one of two pre-defined structures (`ps_holdem` or `ps_shortdeck`) to perform the actual estimation. If neither condition is met, the function returns 0.\\
## Code: 
```
long long QSolverJob::estimate_tree_memory(QString range1,QString range2,QString board){
    qDebug().noquote() << tr("Estimating tree memory..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        return ps_holdem.estimate_tree_memory(range1,range2,board);
    }else if(this->mode == Mode::SHORTDECK){
        return ps_shortdeck.estimate_tree_memory(range1,range2,board);
    }
    return 0;
}
```