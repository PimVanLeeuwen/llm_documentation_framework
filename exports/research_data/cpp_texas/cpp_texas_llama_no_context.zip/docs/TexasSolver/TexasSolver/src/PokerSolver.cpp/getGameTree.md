`getGameTree`: The function of `getGameTree` is to return a reference to the shared pointer of the game tree.

**Code Description**: This function, `getGameTree`, is a member function of the `PokerSolver` class. It returns a constant reference to a shared pointer that holds a `GameTree` object. The `const` keyword indicates that this function does not modify the state of the object it belongs to. The return type is a reference to a shared pointer, which means that the caller of this function will be responsible for managing the lifetime of the returned `GameTree` object.\\
## Code: 
```
const shared_ptr<GameTree> &PokerSolver::getGameTree() const {
    return game_tree;
}
```