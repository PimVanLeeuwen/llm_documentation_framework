`parent`: The function of `parent` is to return the parent index of a given child index in a tree model.

**Code Description**: This function, part of a TreeModel class, takes a QModelIndex as input and returns its corresponding parent index. It first checks if the input index is valid; if not, it returns an invalid QModelIndex. If the input index is valid, it retrieves the associated TreeItem from the internal pointer and then gets its parent item. If this parent item is the root item of the tree model, the function returns an invalid QModelIndex to indicate that there is no further parent. Otherwise, it creates a new QModelIndex for the parent item and returns it.\\
## Code: 
```
QModelIndex TreeModel::parent(const QModelIndex &index) const
{
    if (!index.isValid())
        return QModelIndex();

    TreeItem *childItem = static_cast<TreeItem*>(index.internalPointer());
    TreeItem *parentItem = childItem->parentItem();

    if (parentItem == rootItem)
        return QModelIndex();

    return createIndex(parentItem->row(), 0, parentItem);
}
```