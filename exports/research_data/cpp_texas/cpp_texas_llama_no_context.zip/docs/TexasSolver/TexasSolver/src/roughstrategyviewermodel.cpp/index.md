`index`: The function of `index` is to return a QModelIndex object that represents the item at the specified row and column in the model, or an invalid QModelIndex if the index does not exist.

**Code Description**: This function is part of the RoughStrategyViewerModel class and is used to retrieve a QModelIndex object for a specific item in the model. It takes three parameters: `row`, `column`, and `parent`. The function first checks if the specified index exists using the `hasIndex` method, and returns an invalid QModelIndex if it does not exist. If the index does exist, it creates a new QModelIndex object with the specified row, column, and parent index, and returns it.\\
## Code: 
```
QModelIndex RoughStrategyViewerModel::index(int row, int column, const QModelIndex &parent) const
{
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    return createIndex(row, column, nullptr);
}
```