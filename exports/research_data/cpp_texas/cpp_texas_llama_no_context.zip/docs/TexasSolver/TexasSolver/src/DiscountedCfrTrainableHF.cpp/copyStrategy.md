`copyStrategy`: The function of `copyStrategy` is to copy the strategy from another trainable object.

**Code Description**: This function, `copyStrategy`, takes a shared pointer to a `Trainable` object as input and copies its strategy into the current object. It uses dynamic casting to ensure that the input object is indeed an instance of `DiscountedCfrTrainableHF`. The strategy consists of two components: `r_plus` and `cum_r_plus`, which are vectors representing some kind of cumulative or incremental values. These vectors are copied from the input object to the current object using the assignment operator, effectively copying the entire strategy.\\
## Code: 
```
void DiscountedCfrTrainableHF::copyStrategy(shared_ptr<Trainable> other_trainable){
    shared_ptr<DiscountedCfrTrainableHF> trainable = dynamic_pointer_cast<DiscountedCfrTrainableHF>(other_trainable);
    this->r_plus.assign(trainable->r_plus.begin(),trainable->r_plus.end());
    this->cum_r_plus.assign(trainable->cum_r_plus.begin(),trainable->cum_r_plus.end());
}
```