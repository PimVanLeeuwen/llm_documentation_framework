`PokerSolver`: The function of `PokerSolver` is to initialize a poker game solver with the given parameters, including card ranks and suits, and a comparison file for ranking hands.

**Code Description**: 
The code initializes an instance of the `PokerSolver` class by calling its constructor. This constructor takes four parameters: `ranks`, `suits`, `compairer_file`, `compairer_file_lines`, and `compairer_file_bin`. The function first splits the input strings `ranks` and `suits` into vectors of individual ranks and suits using a helper function `string_split`. It then creates an instance of the `Deck` class, passing in the vectors of ranks and suits. Additionally, it creates a shared pointer to an instance of the `Dic5Compairer` class, which is initialized with the provided comparison file parameters. The resulting objects are stored as member variables within the `PokerSolver` instance.\\
## Code: 
```
PokerSolver::PokerSolver(string ranks, string suits, string compairer_file,int compairer_file_lines, string compairer_file_bin) {
    vector<string> ranks_vector = string_split(ranks,',');
    vector<string> suits_vector = string_split(suits,',');
    this->deck = Deck(ranks_vector,suits_vector);
    this->compairer = make_shared<Dic5Compairer>(compairer_file,compairer_file_lines,compairer_file_bin);
}
```