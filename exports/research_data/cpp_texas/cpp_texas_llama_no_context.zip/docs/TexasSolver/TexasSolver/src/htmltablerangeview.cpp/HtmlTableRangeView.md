`HtmlTableRangeView`: The function of `HtmlTableRangeView` is to provide a view for displaying and interacting with HTML tables, allowing users to select and manipulate ranges within the table.

**Code Description**: This code snippet appears to be part of a class constructor for `HtmlTableRangeView`, which inherits from `HtmlTableView`. It sets up event filtering and mouse tracking behavior for the viewport. The `mouseTracker` object is initialized with tracking disabled and pressed indices set to -1, indicating that no mouse press events have been recorded yet.\\
## Code: 
```
HtmlTableRangeView::HtmlTableRangeView(QWidget *parent):
HtmlTableView(parent)
{
    viewport()->installEventFilter(this);
    setMouseTracking(true);
    mouseTracker.tracking = false;
    mouseTracker.pressed_i = -1;
    mouseTracker.pressed_j = -1;
}
```