`Rule`: The function of `Rule` is to initialize a rule object with various parameters related to the game, such as deck, commitment levels, current round, raise limit, blinds, stack size, and building settings.

**Code Description**: This code defines a constructor for a class named `Rule`. It takes several parameters that are used to set up an instance of the `Rule` class. The parameters include the deck being used in the game, the out-of-position (oop) commitment level, the in-position (ip) commitment level, the current round number, the raise limit, the small and big blinds, the stack size, the settings for building a game tree, and the all-in threshold.\\
## Code: 
```
Rule::Rule(Deck deck, float oop_commit, float ip_commit, int current_round, int raise_limit, float small_blind,
           float big_blind, float stack, GameTreeBuildingSettings build_settings,float allin_threshold):
           deck(deck),oop_commit(oop_commit),ip_commit(ip_commit),current_round(current_round),raise_limit(raise_limit),
           small_blind(small_blind),big_blind(big_blind),stack(stack),build_settings(build_settings),allin_threshold(allin_threshold){
    if(oop_commit != ip_commit) throw runtime_error("ip commit should equal with oop commit");
    this->initial_effective_stack = stack;
}
```