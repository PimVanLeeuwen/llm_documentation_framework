## Expected Output
`setTrunCard`: The function of `setTrunCard` is to set the turn card in the TableStrategyModel.

**Code Description**: This function takes a Card object as input and assigns it to the turn_card member variable within the TableStrategyModel class. It does not return any value, implying that its primary purpose is to modify the internal state of the model rather than perform some operation that might require a return value.\\
## Code: 
```
void TableStrategyModel::setTrunCard(Card turn_card){
    this->turn_card = turn_card;
}
```