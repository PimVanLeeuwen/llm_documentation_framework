`rowCount`: The function of `rowCount` is to return the total number of rows in the table model, which is determined by the size of the `ranklist`.

**Code Description**: This function is a part of the QAbstractTableModel interface and is used to specify the number of rows that should be displayed in the view. It takes a QModelIndex object as an argument, but it's not used in this implementation. The function simply returns the current size of the `ranklist` vector, which contains the data for each row in the table model.\\
## Code: 
```
int RangeSelectorTableModel::rowCount(const QModelIndex &parent) const {
    return this->ranklist.size();
}
```