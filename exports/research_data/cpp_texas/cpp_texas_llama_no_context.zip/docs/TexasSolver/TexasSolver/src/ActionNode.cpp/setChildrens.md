`setChildrens`: The function of `setChildrens` is to set the children nodes of an ActionNode object.

**Code Description**: This function takes a vector of shared pointers to GameTreeNode objects as input and assigns it to the childrens member variable of the ActionNode class. It does not perform any validation or error checking on the input, assuming that the provided vector is valid. The assignment operation directly updates the internal state of the object, modifying its children nodes.\\
## Code: 
```
void ActionNode::setChildrens(const vector<shared_ptr<GameTreeNode>> &childrens) {
    ActionNode::childrens = childrens;
}
```