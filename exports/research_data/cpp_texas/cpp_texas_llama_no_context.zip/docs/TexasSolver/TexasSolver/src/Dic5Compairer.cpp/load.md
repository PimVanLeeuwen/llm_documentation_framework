`load`: The function loads a file containing card comparison data into memory, populating two maps (`flush_map` and `other_map`) with key-value pairs.

**Code Description**: This function reads binary data from a file specified by the `file_path` parameter. It first attempts to open the file in read-only mode using `QFile`. If successful, it clears the contents of both `flush_map` and `other_map`, then proceeds to read and populate these maps with key-value pairs from the file. The function assumes that each line of the file contains a count followed by key-value pairs, where each key is represented as an unsigned 64-bit integer (`uint64_t`) and each value is an integer (`int`). After reading all data from the file, it closes the file and returns `true` to indicate successful loading.\\
## Code: 
```
bool FiveCardsStrength::load(const char* file_path) {
    //ifstream file(file_path, ios::binary);
    /*if (!file) {
        file.close();
        return false;
    }*/

    QFile file(QString::fromStdString(file_path));
    if (!file.open(QIODevice::ReadOnly)){
        throw runtime_error("unable to load compairer file");
    }
    flush_map.clear(); other_map.clear();
    int size_key = sizeof(uint64_t), size_int = sizeof(int), val, cnt = 0;
    uint64_t key = 0;
    char* p_key = (char*)&key, * p_val = (char*)&val, * p_cnt = (char*)&cnt;
    file.read(p_cnt, size_int);// 读取行数
    for (int i = 0; i < cnt; i++) {
        file.read(p_key, size_key);
        file.read(p_val, size_int);
        flush_map[key] = val;
    }
    assert(flush_map.size() == cnt);
    file.read(p_cnt, size_int);// 读取行数
    for (int i = 0; i < cnt; i++) {
        file.read(p_key, size_key);
        file.read(p_val, size_int);
        other_map[key] = val;
    }
    assert(other_map.size() == cnt);
    file.close();
    return true;
}
```