`TerminalNode`: The function of `TerminalNode` is to represent a terminal node in the game tree, indicating that no further decisions can be made and the outcome is determined.

**Code Description**: 
The TerminalNode class inherits from GameTreeNode and initializes its member variables with the provided payoffs, winner, round number, pot value, and parent node. This suggests that once a terminal node is reached, the game's state is finalized, and the outcomes for all players are known. The payoffs variable likely stores the rewards or penalties each player receives in this final state.\\
## Code: 
```
TerminalNode::TerminalNode(vector<double> payoffs, int winner, GameTreeNode::GameRound round, double pot,
                           shared_ptr<GameTreeNode> parent):GameTreeNode(round,pot,parent){
    this->payoffs = payoffs;
    this->winner = winner;
}
```