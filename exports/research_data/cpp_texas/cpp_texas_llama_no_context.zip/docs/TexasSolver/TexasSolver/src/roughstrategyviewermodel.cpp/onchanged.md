## onchanged: 
The function of `onchanged` is to notify that data has changed in the model, triggering a refresh of the view.

## Code Description: 
This code snippet appears to be part of a class called `RoughStrategyViewerModel`. The method `onchanged()` emits a signal named `headerDataChanged`, which notifies any connected views that the header data for the specified range (in this case, all columns) has changed. This is likely used in a graphical user interface (GUI) application to update the display when the underlying data changes.\\
## Code: 
```
void RoughStrategyViewerModel::onchanged(){
    emit headerDataChanged(Qt::Horizontal, 0 , columnCount());
}
```