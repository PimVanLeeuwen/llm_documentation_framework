**Expected Output**
`PrivateCardsManager`: The function of `PrivateCardsManager` is to manage private cards for multiple players, including storing and indexing their private card combinations.

**Code Description**: 
The code defines a class called `PrivateCardsManager`, which takes in three parameters: `private_cards`, `player_number`, and `initialboard`. It initializes several member variables, including `private_cards`, `card_player_index`, and `initialboard`. The `card_player_index` is a 2D vector that stores the index of each private card combination for each player. The code then populates this index by iterating over each player's private card combinations and storing their hash codes as keys in the `card_player_index` array. Finally, it calls the `setRelativeProbs()` function to set relative probabilities.\\
## Code: 
```
PrivateCardsManager::PrivateCardsManager(vector<vector<PrivateCards>> private_cards, int player_number,
                                         uint64_t initialboard) {
    this->private_cards = private_cards;
    this->player_number = player_number;
    this->card_player_index = vector<vector<int>>(52 * 52);
    for(int i = 0;i < 52 * 52;i ++){
        this->card_player_index[i] = vector<int>(this->player_number,-1);
    }

    // 用一个二维数组记录每个Private Combo的对应index,方便从一方的手牌找对方的同名卡牌的index
    for(int player_id = 0;player_id < player_number;player_id ++){
        vector<PrivateCards> privateCombos = private_cards[player_id];
        for(std::size_t i = 0;i < privateCombos.size();i ++){
            PrivateCards one_private_combo = privateCombos[i];
            this->card_player_index[one_private_combo.hashCode()][player_id] = i;
        }
    }

    this->initialboard = initialboard;
    this->setRelativeProbs();
}
```