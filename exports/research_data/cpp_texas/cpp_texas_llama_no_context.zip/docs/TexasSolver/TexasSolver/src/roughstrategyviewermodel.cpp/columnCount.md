**Expected Output**

`columnCount`: The function of `columnCount` is to return the total number of columns in a table view, based on the size of the `total_strategy` vector in the `tableStrategyModel`.

**Code Description**
The code snippet provided defines a method named `columnCount` within the class `RoughStrategyViewerModel`. This method takes a `const QModelIndex &parent` as an argument but does not use it. The function returns the value of `this->tableStrategyModel->total_strategy.size()`, which implies that the size of the `total_strategy` vector in the `tableStrategyModel` is used to determine the number of columns in the table view.

This method seems to be part of a larger system for displaying data in a table format, possibly within a graphical user interface (GUI) application. The `columnCount` function is typically called by GUI frameworks such as Qt to determine how many columns should be displayed in a table widget or view.\\
## Code: 
```
int RoughStrategyViewerModel::columnCount(const QModelIndex &parent) const
{
    return this->tableStrategyModel->total_strategy.size();
}
```