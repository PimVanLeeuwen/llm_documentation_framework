`get_total_strategy`: The function calculates the total strategy for a given game state by aggregating the strategies from all possible combinations of actions.

**Code Description**: This function appears to be part of a TableStrategyModel class, which is responsible for managing a tree-based data structure representing different game states and their corresponding strategies. The `get_total_strategy` function takes into account the current player's perspective when calculating the total strategy. It iterates over all possible combinations of actions, multiplies each action's probability by its associated range value, and sums up these products to obtain the total strategy for a given game state.\\
## Code: 
```
const vector<pair<GameActions,pair<float,float>>> TableStrategyModel::get_total_strategy() const{
    vector<pair<GameActions,pair<float,float>>> ret_strategy;
    if(this->treeItem == NULL)return ret_strategy;


    shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();

    if(node->getType() == GameTreeNode::GameTreeNode::ACTION){
        shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);
        vector<GameActions>& gameActions = actionNode->getActions();
        int current_player = actionNode->getPlayer();

        vector<float> combos(gameActions.size(),0.0);
        vector<float> avg_strategy(gameActions.size(),0.0);
        float sum_strategy = 0;

        for(std::size_t index1 = 0;index1 < this->current_strategy.size() ;index1 ++){
            for(std::size_t index2 = 0;index2 < this->current_strategy.size() ;index2 ++){
                const vector<float>& one_strategy = this->current_strategy[index1][index2];
                if(one_strategy.empty())continue;

                const vector<vector<float>>& range = current_player == 0? this->p1_range:this->p2_range;
                if(range.size() <= index1 || range[index1].size() < index2) throw runtime_error(" index error when get range in tablestrategymodel");
                const float one_range = range[index1][index2];

                for(std::size_t i = 0;i < one_strategy.size(); i ++ ){
                    float one_prob = one_strategy[i];
                    combos[i] += one_prob * one_range;
                    avg_strategy[i] += one_prob * one_range;
                    sum_strategy += one_prob * one_range;
                }

                if(gameActions.size() != one_strategy.size()){
                    cout << "index: " << index1 << " " << index2 << endl;
                    cout << "size not match between gameAction and stragegy: " << gameActions.size() << " " << one_strategy.size() << endl;
                    throw runtime_error("size not match between gameAction and stragegy");
                }
            }
        }

        for(std::size_t i = 0;i < gameActions.size(); i ++ ){
            avg_strategy[i] = avg_strategy[i] / sum_strategy;
            pair<float,float> statics = pair<float,float>(combos[i],avg_strategy[i]);
            pair<GameActions,pair<float,float>> one_ret = pair<GameActions,pair<float,float>>(gameActions[i],statics);
            ret_strategy.push_back(one_ret);
        }
        return ret_strategy;
    }else{
        return ret_strategy;
    }


}
```