`get_game_action_str`: This function returns a string representation of a poker game action, given the type of action and an optional amount.

**Code Description**: The function takes two parameters: `action`, which is an enum value representing a poker action (CHECK, BET, RAISE, FOLD, CALL), and `amount`, which is a float representing the amount associated with the action. It returns a string representation of the action, using QObject's tr() function to translate the text into the current language. If the action is not recognized, it throws a runtime_error.\\
## Code: 
```
QString TreeItem::get_game_action_str(GameTreeNode::PokerActions action,float amount) const{
    if(action == GameTreeNode::PokerActions::CHECK){
        return QObject::tr("CHECK");
    }
    else if(action == GameTreeNode::PokerActions::BET){
        return QObject::tr("BET ") + QString::number(amount);
    }
    else if(action == GameTreeNode::PokerActions::RAISE){
        return QObject::tr("RAISE ") + QString::number(amount);
    }
    else if(action == GameTreeNode::PokerActions::FOLD){
        return QObject::tr("FOLD ");
    }
    else if(action == GameTreeNode::PokerActions::CALL){
        return QObject::tr("CALL");
    }else{
        throw runtime_error("unknown action when converting in get_game_action_str");
    }

}
```