`paint_range`: The function of `paint_range` is to paint a range item in the detail viewer, displaying information about a card and its corresponding probability.

**Code Description**: This function is part of the DetailItemDelegate class and is responsible for painting a single item in the detail viewer. It takes a QPainter object, a QStyleOptionViewItem object, and a QModelIndex as input parameters. The function first initializes the style option with the provided index. It then checks if the table strategy model has a tree item associated with it. If so, it retrieves the card coordinates from the model based on the current mode (RANGE_IP or RANGE_P2). It then calculates the probability of folding and uses this value to determine the height of the disable area in the range item. The function draws a yellow background for the fold area and displays the card information along with its corresponding probability.\\
## Code: 
```
void DetailItemDelegate::paint_range(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);

    const DetailViewerModel * detailViewerModel = qobject_cast<const DetailViewerModel*>(index.model());
    //vector<pair<GameActions,float>> strategy = detailViewerModel->tableStrategyModel->get_strategy(this->detailWindowSetting->grid_i,this->detailWindowSetting->grid_j);
    options.text = "";

    if(detailViewerModel->tableStrategyModel->treeItem != NULL){
        vector<pair<int,int>> card_cords;
        if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP){
            card_cords = detailViewerModel->tableStrategyModel->ui_p1_range[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j];
        }else{
            card_cords = detailViewerModel->tableStrategyModel->ui_p2_range[this->detailWindowSetting->grid_i][this->detailWindowSetting->grid_j];
        }

        int ind = index.row() * detailViewerModel->columns + index.column();
        if(ind < card_cords.size()){
            pair<int,int> cord = card_cords[ind];
            float range_number;
            if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP){
                range_number = detailViewerModel->tableStrategyModel->p1_range[cord.first][cord.second];
            }else{
                range_number = detailViewerModel->tableStrategyModel->p2_range[cord.first][cord.second];
            }

            if(range_number < 0 || range_number > 1) throw runtime_error("range number incorrect in strategyitemdeletage");

            float fold_prob = 1 - range_number;
            int disable_height = (int)(fold_prob * option.rect.height());
            int remain_height = option.rect.height() - disable_height;

            // draw background for flod
            QRect rect(option.rect.left(), option.rect.top() + disable_height,\
             option.rect.width(), remain_height);
            QBrush brush(Qt::yellow);
            painter->fillRect(rect, brush);

            options.text = "";
            options.text += detailViewerModel->tableStrategyModel->cardint2card[cord.first].toFormattedHtml();
            options.text += detailViewerModel->tableStrategyModel->cardint2card[cord.second].toFormattedHtml();
            options.text = "<h2>" + options.text + "<\/h2>";

            options.text +=  QString(" <h2>%1<\/h2>").arg(QString::number(range_number,'f',3));
        }
    }

    QTextDocument doc;
    doc.setHtml(options.text);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```