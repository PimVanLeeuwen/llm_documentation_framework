`getTrainable`: The function of `getTrainable` is to retrieve a trainable object associated with the current ActionNode instance.

**Code Description**: This function, `getTrainable`, appears to be part of a class hierarchy related to game tree search and training. It takes three parameters: an integer index `i`, a boolean flag `create_on_site`, and an integer value `use_halffloats`. The function checks if the requested trainable object exists at the specified index in the `trainables` vector. If it does not exist and the `create_on_site` flag is true, it creates a new trainable object based on the current game round and the value of `use_halffloats`. The created trainable object is then stored at the specified index in the `trainables` vector. Finally, the function returns the retrieved or newly created trainable object.\\
## Code: 
```
shared_ptr<Trainable> ActionNode::getTrainable(int i,bool create_on_site, int use_halffloats) {
    if(i > this->trainables.size()){
        throw runtime_error(tfm::format("size unacceptable %s > %s ",i,this->trainables.size()));
    }
    if(this->trainables[i] == nullptr && create_on_site){
        switch ((this->getRound() == GameTreeNode::RIVER) ? use_halffloats : 0 ){
        case 0:
            this->trainables[i] = make_shared<DiscountedCfrTrainable>(player_privates,*this);
            break;
        case 1:
            this->trainables[i] = make_shared<DiscountedCfrTrainableSF>(player_privates,*this);
            break;
        case 2:
            this->trainables[i] = make_shared<DiscountedCfrTrainableHF>(player_privates,*this);
            break;
        }
    }
    return this->trainables[i];
}
```