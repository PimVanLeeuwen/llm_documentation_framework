`rowCount`: The function of `rowCount` is to return the total number of rows in a table model.

**Code Description**: This function, `rowCount`, is a part of the TableStrategyModel class and is used to determine the number of rows that should be displayed in a table. It takes a QModelIndex object as an argument but does not use it in this implementation. The function returns the size of the "Ranks" collection obtained from the deck using the qSolverJob's solver.\\
## Code: 
```
int TableStrategyModel::rowCount(const QModelIndex &parent) const
{
    return this->qSolverJob->get_solver()->get_deck()->getRanks().size();
}
```