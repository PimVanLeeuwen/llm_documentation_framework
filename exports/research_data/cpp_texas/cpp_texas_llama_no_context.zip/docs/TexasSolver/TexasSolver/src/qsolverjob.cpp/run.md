`run`: The function of `run` is to execute a specific mission or task based on the current_mission variable.

**Code Description**: This function appears to be part of a class called QSolverJob and seems to handle different types of missions or tasks, such as solving, loading, building a tree, saving, etc. It uses if-else statements to determine which mission to execute and throws an exception if the current_mission type is not supported.\\
## Code: 
```
void QSolverJob::run()
{
    //QDebugStream qout(qDebug().noquote(), this->textEdit);
    try{
        if(this->current_mission == MissionType::SOLVING){
            this->solving();
        }else if(this->current_mission == MissionType::LOADING){
            this->loading();
        }else if(this->current_mission == MissionType::BUILDTREE){
            this->build_tree();
        }else if(this->current_mission == MissionType::SAVING){
            this->saving();
        }else{
            throw runtime_error("unsupported mission type");
        }
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```