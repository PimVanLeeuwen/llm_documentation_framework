`pokerActionToString`: The function of `pokerActionToString` is to convert a given poker action enum value into its corresponding string representation.

**Code Description**: This function takes an enum value of type `GameTreeNode::PokerActions` as input and returns the string equivalent of that action. It uses a switch statement to match the input enum value with the corresponding string, throwing a runtime error if the input is not recognized. The function appears to be part of a larger system for representing poker game states or actions in a tree-like data structure.\\
## Code: 
```
string GameActions::pokerActionToString(GameTreeNode::PokerActions pokerActions) {
    switch (pokerActions)
    {
        case GameTreeNode::PokerActions::BEGIN :   return "BEGIN";
        case GameTreeNode::PokerActions::ROUNDBEGIN :   return "ROUNDBEGIN";
        case GameTreeNode::PokerActions::BET :   return "BET";
        case GameTreeNode::PokerActions::RAISE :   return "RAISE";
        case GameTreeNode::PokerActions::CHECK :   return "CHECK";
        case GameTreeNode::PokerActions::FOLD :   return "FOLD";
        case GameTreeNode::PokerActions::CALL :   return "CALL";
        default:{
            throw runtime_error("PokerActions not found");
        }
    }
}
```