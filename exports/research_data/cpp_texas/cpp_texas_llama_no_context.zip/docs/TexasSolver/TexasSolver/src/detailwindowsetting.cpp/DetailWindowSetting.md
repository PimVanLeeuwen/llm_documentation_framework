`DetailWindowSetting`: The function of `DetailWindowSetting` is to initialize the object with a default mode setting, specifically setting it to `DetailWindowMode::STRATEGY`.

**Code Description**: This code snippet defines a constructor for the `DetailWindowSetting` class. The constructor sets the `mode` member variable to `DetailWindowMode::STRATEGY`.\\
## Code: 
```
DetailWindowSetting::DetailWindowSetting(){
    this->mode = DetailWindowMode::STRATEGY;
}
```