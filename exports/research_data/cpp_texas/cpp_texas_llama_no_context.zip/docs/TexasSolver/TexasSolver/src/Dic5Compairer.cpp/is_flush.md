`is_flush`: The function of `is_flush` is to determine whether a given hash value represents a flush in a card game, specifically when three or four cards of the same suit are present.

**Code Description**: This function takes an unsigned 64-bit integer (uint64_t) as input, representing the hash value of a set of cards. It uses bitwise operations and conditional statements to count the number of suits present in the hash value. If more than one suit is found, the function returns false, indicating that it's not a flush. Otherwise, it returns true, indicating that it is a flush.\\
## Code: 
```
bool is_flush(uint64_t hash) {
    int cnt = (hash & SUIT_0_MASK) != 0;
    cnt += (hash & SUIT_1_MASK) != 0;
    if (cnt > 1) return false;
    cnt += (hash & SUIT_2_MASK) != 0;
    if (cnt > 1) return false;
    cnt += (hash & SUIT_3_MASK) != 0;
    return cnt > 1 ? false : true;
}
```