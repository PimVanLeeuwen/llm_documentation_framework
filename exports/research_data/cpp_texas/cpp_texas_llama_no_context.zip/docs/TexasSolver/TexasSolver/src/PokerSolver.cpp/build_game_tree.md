`build_game_tree`: The function of `build_game_tree` is to construct a game tree for a poker game, representing all possible outcomes and decisions that can be made during the game.

**Code Description**: This function takes in several parameters related to the current state of the game, such as the current round, raise limit, small and big blinds, stack size, and building settings. It uses these inputs to create a shared pointer to a `GameTree` object, which is then assigned to the `game_tree` member variable of the `PokerSolver` class. The `GameTree` object is initialized with the provided parameters, allowing it to represent the game tree for the current state of the game.\\
## Code: 
```
void PokerSolver::build_game_tree(
        float oop_commit,
        float ip_commit,
        int current_round,
        int raise_limit,
        float small_blind,
        float big_blind,
        float stack,
        GameTreeBuildingSettings buildingSettings,
        float allin_threshold
){
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(
            this->deck,
            oop_commit,
            ip_commit,
            current_round,
            raise_limit,
            small_blind,
            big_blind,
            stack,
            buildingSettings,
            allin_threshold
    );
    this->game_tree = game_tree;
}
```