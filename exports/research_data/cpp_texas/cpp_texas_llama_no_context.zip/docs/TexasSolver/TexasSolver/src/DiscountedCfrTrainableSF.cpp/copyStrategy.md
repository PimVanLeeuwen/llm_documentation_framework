**copyStrategy**: The function of `copyStrategy` is to copy the strategy from another trainable object, specifically a `DiscountedCfrTrainableSF`, into the current object.

**Code Description**: This code snippet defines a method called `copyStrategy` within the class `DiscountedCfrTrainableSF`. It takes a shared pointer to a `Trainable` object as an argument. The purpose of this method is to copy specific attributes from the provided `Trainable` object, which must be of type `DiscountedCfrTrainableSF`, into the current object. This copying involves assigning the contents of two vectors (`r_plus` and `cum_r_plus`) from the source object to corresponding vectors in the destination object. The method uses a dynamic cast to ensure that the provided `Trainable` object is indeed of the correct type before attempting to access its attributes.\\
## Code: 
```
void DiscountedCfrTrainableSF::copyStrategy(shared_ptr<Trainable> other_trainable){
    shared_ptr<DiscountedCfrTrainableSF> trainable = dynamic_pointer_cast<DiscountedCfrTrainableSF>(other_trainable);
    this->r_plus.assign(trainable->r_plus.begin(),trainable->r_plus.end());
    this->cum_r_plus.assign(trainable->cum_r_plus.begin(),trainable->cum_r_plus.end());
}
```