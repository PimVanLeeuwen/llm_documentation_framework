`getRangeAt`: The function of `getRangeAt` is to retrieve the range value at a specific position in a 2D grid.

**Code Description**: This function, `getRangeAt`, is part of the `RangeSelectorTableModel` class. It takes two integer parameters, `i` and `j`, which represent the row and column indices respectively. The function checks if these indices are within valid ranges by comparing them to the size of the `ranklist`. If either index is out of range, it logs an error message using `qDebug()` and returns 0. Otherwise, it returns the value at the specified position in a 2D grid of floating-point numbers, `grids_float[i][j]`.\\
## Code: 
```
float RangeSelectorTableModel::getRangeAt(int i, int j){
    if(i < 0 || i >= this->ranklist.size()){
        qDebug().noquote() << "RangeSelectorTableModel::getRangeAt i not valid: " << i;
        return 0;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "RangeSelectorTableModel::getRangeAt j not valid: " << j;
        return 0;
    }
    else{
        return this->grids_float[i][j];
    }
}
```