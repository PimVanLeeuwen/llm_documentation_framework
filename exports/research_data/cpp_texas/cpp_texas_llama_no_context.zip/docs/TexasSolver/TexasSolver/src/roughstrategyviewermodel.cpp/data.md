`data`: The function of `data` is to return a value for a given model index and role in the context of a viewer model, specifically designed to display rough strategy data.

**Code Description**: This code snippet appears to be part of a class named `RoughStrategyViewerModel`, which inherits from a Qt model. The `data` function is overridden to provide custom behavior when retrieving values for specific indices and roles. It seems to be used in conjunction with another model, `tableStrategyModel`, which contains strategy data.\\
## Code: 
```
QVariant RoughStrategyViewerModel::data(const QModelIndex &index, int role) const
{
    std::size_t col = index.column();
    if(col < this->tableStrategyModel->total_strategy.size()){
        pair<GameActions,pair<float,float>> one_strategy = this->tableStrategyModel->total_strategy[col];
        return QString::number(one_strategy.second.second);
    }else{
        return "Rough Strategy";
    }
}
```