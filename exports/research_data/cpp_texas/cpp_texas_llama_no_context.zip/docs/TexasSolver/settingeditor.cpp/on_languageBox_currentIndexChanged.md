## Expected output
`on_languageBox_currentIndexChanged`: The function of `on_languageBox_currentIndexChanged` is to handle the selection change event in a language box.

**Code Description**: This function is triggered when the current index changes in a language box. It checks if the program has been initialized, and if so, displays a message box with a restart prompt to make the language selection effective.\\
## Code: 
```
void SettingEditor::on_languageBox_currentIndexChanged(int index)
{
    if(!initized)return;
    QString message = tr("Restart program to make language selection effective.");
    qDebug().noquote() << message;
    QMessageBox msgBox;
    msgBox.setText(message);
    msgBox.exec();
}
```