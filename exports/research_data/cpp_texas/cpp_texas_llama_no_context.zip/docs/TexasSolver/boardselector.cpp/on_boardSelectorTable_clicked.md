## on_boardSelectorTable_clicked: 
The function of `on_boardSelectorTable_clicked` is to toggle the selection state of a board in the table model when a cell in the table view is clicked.

## Code Description:
When a cell in the `boardSelectorTable` is clicked, this function toggles the selection state of the corresponding board in the `boardSelectorTableModel`. If the text in the `boardEdit` field does not match the text of the selected board, it updates the `boardEdit` field with the new text. Finally, it sets focus to the `boardEdit` and `boardSelectorTable` fields.\\
## Code: 
```
void boardselector::on_boardSelectorTable_clicked(const QModelIndex &index)
{
    int row = index.row();
    int col = index.column();
    this->boardSelectorTableModel->setBoardAt(row,col,1 - this->boardSelectorTableModel->getBoardAt(row,col));
    if(this->ui->boardEdit->text() != this->boardSelectorTableModel->getBoardText()){
        this->ui->boardEdit->setText(this->boardSelectorTableModel->getBoardText());
    }
    this->ui->boardEdit->setFocus();
    this->ui->boardSelectorTable->setFocus();
}
```