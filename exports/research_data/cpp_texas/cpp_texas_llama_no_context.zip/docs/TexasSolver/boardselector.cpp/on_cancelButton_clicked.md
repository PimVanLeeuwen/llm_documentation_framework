## on_cancelButton_clicked: 
The function of `on_cancelButton_clicked` is to close the current window when the cancel button is clicked.

## Code Description: 
When the cancel button is clicked, this function is triggered. It closes the current window using the `close()` method.\\
## Code: 
```
void boardselector::on_cancelButton_clicked()
{
    this->close();
}
```