## on_confirmButton_clicked: 
The function of `on_confirmButton_clicked` is to confirm the changes made in the board selection process.

## Code Description:
When the confirm button is clicked, this function updates the text of a widget named `boardEdit` with the current text from another widget also named `boardEdit`, and then closes the window.\\
## Code: 
```
void boardselector::on_confirmButton_clicked()
{
    this->boardEdit->setText(this->ui->boardEdit->text());
    this->close();
}
```