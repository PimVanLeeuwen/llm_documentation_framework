## on_boardEdit_textChanged: 
The function of `on_boardEdit_textChanged` is to update the board text in the table model and refresh the table view when the user types something into the edit field.

## Code Description:
When the text in the `boardEdit` field changes, this function updates the corresponding text in the `boardSelectorTableModel`, then triggers an update of the `boardSelectorTable` widget to reflect the new data.\\
## Code: 
```
void boardselector::on_boardEdit_textChanged(const QString &arg1)
{
    this->boardSelectorTableModel->setBoardText(arg1);
    this->ui->boardSelectorTable->update();
    this->ui->boardSelectorTable->setFocus();
    this->ui->boardEdit->setFocus();
}
```