## on_clearBoardButton_clicked: 
The function of `on_clearBoardButton_clicked` is to clear the board when the corresponding button is clicked.

## Code Description:
When the "Clear Board" button is clicked, this function clears the current board by calling the `clear_board()` method on the `boardSelectorTableModel`, clears any text in the `boardEdit` widget, updates the `boardSelectorTable` widget to reflect the new state of the board, sets the focus back to the `boardSelectorTable` and then to the `boardEdit` widget.\\
## Code: 
```
void boardselector::on_clearBoardButton_clicked()
{
    this->boardSelectorTableModel->clear_board();
    this->ui->boardEdit->clear();
    this->ui->boardSelectorTable->update();
    this->ui->boardSelectorTable->setFocus();
    this->ui->boardEdit->setFocus();
}
```