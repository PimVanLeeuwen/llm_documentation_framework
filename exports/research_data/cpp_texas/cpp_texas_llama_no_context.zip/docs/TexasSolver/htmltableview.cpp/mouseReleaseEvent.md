`mouseReleaseEvent`: The function of `mouseReleaseEvent` is to handle the release event of a mouse button in a graphical user interface.

**Code Description**: This function is part of a class called `HtmlTableView`, which inherits from `QTableView`. It overrides the default behavior of `QTableView::mouseReleaseEvent` and adds custom functionality. The function takes a `QMouseEvent *event` as an argument, representing the mouse release event that triggered this function call.\\
## Code: 
```
void HtmlTableView::mouseReleaseEvent(QMouseEvent *event) {
    if (!_mousePressAnchor.isEmpty()) {
        auto anchor = anchorAt(event->pos());

        if (anchor == _mousePressAnchor) {
            emit linkActivated(_mousePressAnchor);
        }

        _mousePressAnchor.clear();
    }

    QTableView::mouseReleaseEvent(event);
}
```