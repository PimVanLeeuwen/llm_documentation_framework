`mouseMoveEvent`: The function of `mouseMoveEvent` is to handle mouse movement events in a graphical user interface (GUI) application.

**Code Description**: This function, `mouseMoveEvent`, appears to be part of a class called `HtmlTableView`. It handles the event when the user moves their mouse while interacting with the GUI. The code snippet suggests that it updates the state of anchors or links on the screen based on the new mouse position.\\
## Code: 
```
void HtmlTableView::mouseMoveEvent(QMouseEvent *event) {
    auto anchor = anchorAt(event->pos());

    if (_mousePressAnchor != anchor) {
        _mousePressAnchor.clear();
    }

    if (_lastHoveredAnchor != anchor) {
        _lastHoveredAnchor = anchor;
        if (!_lastHoveredAnchor.isEmpty()) {
            QApplication::setOverrideCursor(QCursor(Qt::PointingHandCursor));
            emit linkHovered(_lastHoveredAnchor);
        } else {
            QApplication::restoreOverrideCursor();
            emit linkUnhovered();
        }
    }
}
```