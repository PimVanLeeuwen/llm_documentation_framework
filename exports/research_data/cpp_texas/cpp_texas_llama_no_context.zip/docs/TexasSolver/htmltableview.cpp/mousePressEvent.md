`mousePressEvent`: The function of `mousePressEvent` is to handle mouse press events in the HtmlTableView class, specifically when a user clicks on the table view.

**Code Description**: This code snippet defines the behavior of the `mousePressEvent` function in the HtmlTableView class. It calls the base class's `mousePressEvent` function using `QTableView::mousePressEvent(event)`, which likely handles the default mouse press event handling for tables. The code then retrieves the anchor at the position where the user clicked (`anchorAt(event->pos())`) and stores it in a member variable `_mousePressAnchor`. This suggests that the HtmlTableView class is tracking the anchor (likely a table cell or row) that was clicked by the user, possibly to perform further actions based on this information.\\
## Code: 
```
void HtmlTableView::mousePressEvent(QMouseEvent *event) {
    QTableView::mousePressEvent(event);

    auto anchor = anchorAt(event->pos());
    _mousePressAnchor = anchor;
}
```