`triger_resize`: The function of `triger_resize` is to trigger a resize event in the HtmlTableView object.

**Code Description**: This function creates a new QResizeEvent with the current size of the HtmlTableView object, calls the resizeEvent method on the object, and then deletes the event.\\
## Code: 
```
void HtmlTableView::triger_resize(){
    QResizeEvent* ev = new QResizeEvent(this->size(),this->size());
    this->resizeEvent(ev);
    //this->resize(this->parentWidget()->size());
    delete ev;
}
```