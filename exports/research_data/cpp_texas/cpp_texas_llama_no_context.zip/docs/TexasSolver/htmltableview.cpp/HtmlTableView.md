## Information
**Code Content:** \
`HtmlTableView::HtmlTableView(QWidget *parent):
    QTableView(parent)
{
    viewport()->installEventFilter(this);
    setMouseTracking(true);
}`

## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`HtmlTableView`: The function of `HtmlTableView` is *The HtmlTableView class inherits from QTableView, allowing it to display data in a table format.*

**Code Description**: *This code snippet defines the constructor for the HtmlTableView class. It initializes the parent widget and installs an event filter on the viewport, enabling the class to track mouse events. The setMouseTracking function is also called to enable mouse tracking.*\\
## Code: 
```
HtmlTableView::HtmlTableView(QWidget *parent):
    QTableView(parent)
{
    viewport()->installEventFilter(this);
    setMouseTracking(true);
}
```