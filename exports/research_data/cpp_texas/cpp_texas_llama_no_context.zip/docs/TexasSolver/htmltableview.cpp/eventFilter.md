`eventFilter`: The function of `eventFilter` is to filter events for a specific object, in this case, the viewport of an HtmlTableView.

**Code Description**: This code snippet defines the eventFilter method for a QTableView subclass called HtmlTableView. It overrides the default behavior of QTableView's eventFilter method and adds custom functionality to handle mouse move and leave events when the user interacts with the table view's viewport.\\
## Code: 
```
bool HtmlTableView::eventFilter(QObject *watched, QEvent *event){
    if(viewport() == watched){
        if(event->type() == QEvent::MouseMove){
        QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
        QModelIndex index = indexAt(mouseEvent->pos());
        if(index.isValid()){
            int i = index.row();
            int j = index.column();
            if(i != this->last_bearing_i || j != last_bearing_j){
                this->last_bearing_i = i;
                this->last_bearing_j = j;
                emit itemMouseChange(i,j);
            }
        }
        else{
        }
        }
        else if(event->type() == QEvent::Leave){
        }
    }
    return QTableView::eventFilter(watched, event);
}
```