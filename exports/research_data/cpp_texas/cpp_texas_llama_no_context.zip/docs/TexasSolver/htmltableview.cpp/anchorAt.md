**Expected Output**
The function of `anchorAt` is to return a string representing the anchor (hyperlink) at the specified position in the table view, if any.

**Code Description**
This function is part of the `HtmlTableView` class and is used to determine the anchor at a given point in the table view. It takes a `QPoint` object as input, which represents the mouse click position. The function first checks if an item exists at that position using the `indexAt` method. If an item is found, it retrieves the delegate for that item and checks if it's a `WordItemDelegate`. If so, it calculates the relative click position within the item's rectangle. It then retrieves the HTML content of the item from its model and passes it to the `anchorAt` method of the `WordItemDelegate`, along with the relative click position. The returned anchor string is then returned by this function.\\
## Code: 
```
QString HtmlTableView::anchorAt(const QPoint &pos) const {
    auto index = indexAt(pos);
    if (index.isValid()) {
        auto delegate = itemDelegate(index);
        auto wordDelegate = qobject_cast<WordItemDelegate *>(delegate);
        if (wordDelegate != 0) {
            auto itemRect = visualRect(index);
            auto relativeClickPosition = pos - itemRect.topLeft();

            if(model() != NULL){
                auto html = model()->data(index, Qt::DisplayRole).toString();
                return wordDelegate->anchorAt(html, relativeClickPosition);
            }
        }
    }

    return QString();
}
```