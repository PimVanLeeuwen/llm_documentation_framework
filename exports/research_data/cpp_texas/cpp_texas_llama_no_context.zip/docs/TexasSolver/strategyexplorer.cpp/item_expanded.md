`item_expanded`: The function of `item_expanded` is to regenerate the tree item for each child of the expanded item in the game tree view.

**Code Description**: This function, `item_expanded`, appears to be a slot function that handles the expansion of an item in a QTreeView. It takes a QModelIndex as input and casts it to a TreeItem pointer using internalPointer(). The function then retrieves the number of child items for the expanded item and iterates over them. If a child item has no children of its own, the function calls reGenerateTreeItem on the tree model with the round data from the child item's treedata lock and the child item itself as arguments.\\
## Code: 
```
void StrategyExplorer::item_expanded(const QModelIndex& index){
    TreeItem *item = static_cast<TreeItem*>(index.internalPointer());
    int num_child = item->childCount();
    for (int i = 0;i < num_child;i ++){
        TreeItem* one_child = item->child(i);
        if(one_child->childCount() != 0)continue;
        this->ui->gameTreeView->tree_model->reGenerateTreeItem(one_child->m_treedata.lock()->getRound(),one_child);
    }
}
```