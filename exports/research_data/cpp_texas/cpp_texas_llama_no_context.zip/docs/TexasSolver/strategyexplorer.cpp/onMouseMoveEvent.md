## onMouseMoveEvent: 
The function of `onMouseMoveEvent` is to update the grid coordinates and refresh the views when a mouse move event occurs.

## Code Description: 
When a mouse move event happens, the function updates the grid coordinates (`grid_i` and `grid_j`) in the `detailWindowSetting` object. It then triggers an update on two viewports: `detailView` and `strategyTableView`.\\
## Code: 
```
void StrategyExplorer::onMouseMoveEvent(int i,int j){
    this->detailWindowSetting.grid_i = i;
    this->detailWindowSetting.grid_j = j;
    this->ui->detailView->viewport()->update();
    this->ui->strategyTableView->viewport()->update();
}
```