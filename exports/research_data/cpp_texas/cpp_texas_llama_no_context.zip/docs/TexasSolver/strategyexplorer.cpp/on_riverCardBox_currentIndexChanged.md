`on_riverCardBox_currentIndexChanged`: The function of `on_riverCardBox_currentIndexChanged` is to update the table strategy model and process the board when a new river card is selected.

**Code Description**: This function is triggered when the current index in the river card box changes. It checks if there are cards available and if the selected index is within the bounds of the cards list. If so, it updates the table strategy model with the corresponding river card and triggers an update to the rough strategy viewer model. Additionally, it calls the process_board function with the updated tree item from the table strategy model. Finally, it updates the viewport of the strategy table view and detail view.\\
## Code: 
```
void StrategyExplorer::on_riverCardBox_currentIndexChanged(int index)
{
    if(this->cards.size() > 0  && index < this->cards.size()){
        this->tableStrategyModel->setRiverCard(this->cards[index]);
        this->tableStrategyModel->updateStrategyData();
        //this->roughStrategyViewerModel->onchanged();
        //this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```