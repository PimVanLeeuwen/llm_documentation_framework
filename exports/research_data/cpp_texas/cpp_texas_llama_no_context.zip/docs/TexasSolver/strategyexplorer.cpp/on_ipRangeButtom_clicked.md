`on_ipRangeButtom_clicked`: The function of `on_ipRangeButtom_clicked` is to update the GUI components and models when the "IP Range" button is clicked.

**Code Description**: This function is a slot that responds to the click event of the "IP Range" button. It updates the mode of the detail window setting to display IP range information, triggers an update of the viewport for several UI components (strategy table view, detail view, and rough strategy viewer), and notifies the rough strategy viewer model that its data has changed.\\
## Code: 
```
void StrategyExplorer::on_ipRangeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::RANGE_IP;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```