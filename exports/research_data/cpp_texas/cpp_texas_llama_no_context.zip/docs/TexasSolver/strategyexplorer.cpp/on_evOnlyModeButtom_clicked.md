`on_evOnlyModeButtom_clicked`: The function of `on_evOnlyModeButtom_clicked` is to update the application's settings and views when the "EV Only" mode button is clicked.

**Code Description**: When the "EV Only" mode button is clicked, this function updates the `detailWindowSetting.mode` to `DetailWindowMode::EV_ONLY`, which likely changes the display of certain information or data in the application. It then updates the viewports of several UI elements: `strategyTableView`, `detailView`, and `roughStrategyView`. Additionally, it calls the `onchanged()` function on the `roughStrategyViewerModel` to notify it that some data has changed, which likely triggers an update in the `roughStrategyView`.\\
## Code: 
```
void StrategyExplorer::on_evOnlyModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::EV_ONLY;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```