## on_evModeButtom_clicked: 
The function of `on_evModeButtom_clicked` is to update the mode of the detail window setting to EV (Electric Vehicle) mode.

## Code Description:
When the `on_evModeButtom_clicked` function is called, it sets the `mode` attribute of the `detailWindowSetting` object to `DetailWindowMode::EV`. This change triggers an update of three views: `strategyTableView`, `detailView`, and `roughStrategyView`. The `viewport()->update()` method is used to refresh these views with the updated mode.\\
## Code: 
```
void StrategyExplorer::on_evModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::EV;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->ui->roughStrategyView->viewport()->update();
}
```