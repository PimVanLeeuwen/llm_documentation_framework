## Expected Output
`on_strategyModeButtom_clicked`: The function of `on_strategyModeButtom_clicked` is to switch the application's mode to display strategy-related information.

**Code Description**: This function, triggered by a button click event, updates various UI components and models within the StrategyExplorer class. It sets the detail window setting to display strategy data, updates the views for the strategy table and rough strategy viewer, and notifies the rough strategy viewer model of changes.\\
## Code: 
```
void StrategyExplorer::on_strategyModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::STRATEGY;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```