`on_oopRangeButtom_clicked`: The function of `on_oopRangeButtom_clicked` is to update the display settings and refresh the views when the "OOP Range" button is clicked.

**Code Description**: This function is a slot that responds to the click event of the "OOP Range" button. It updates the mode of the detail window setting to RANGE_OOP, which likely indicates that the user wants to view or interact with data related to object-oriented programming (OOP) ranges. The function then updates the views in the UI by calling the update method on their respective viewport objects. Additionally, it notifies the rough strategy viewer model that its data has changed and updates the rough strategy view accordingly.\\
## Code: 
```
void StrategyExplorer::on_oopRangeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::RANGE_OOP;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```