`update_second`: The function of `update_second` is to update the strategy data and refresh the user interface when there are cards in the table.

**Code Description**: This function, `update_second`, appears to be part of a class called `StrategyExplorer`. It updates various components of the user interface (UI) based on the presence of cards in the table. The function is triggered when there are cards in the table and seems to be responsible for updating the strategy data and refreshing the UI accordingly.\\
## Code: 
```
void StrategyExplorer::update_second(){
    if(this->cards.size() > 0){
        this->tableStrategyModel->updateStrategyData();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```