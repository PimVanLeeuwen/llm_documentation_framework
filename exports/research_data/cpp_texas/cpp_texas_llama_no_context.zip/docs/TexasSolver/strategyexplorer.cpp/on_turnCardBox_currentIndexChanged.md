`on_turnCardBox_currentIndexChanged`: The function of `on_turnCardBox_currentIndexChanged` is to update the strategy data and process the board when a new card is selected from the turn card box.

**Code Description**: This function is triggered when the current index in the turn card box changes. It checks if there are cards available and if the selected index is within the valid range. If so, it updates the table strategy model with the selected card and triggers an update of the rough strategy viewer model. The process board function is then called to process the updated tree item from the table strategy model. Finally, the viewport of several UI elements (strategy table view, detail view) are updated.\\
## Code: 
```
void StrategyExplorer::on_turnCardBox_currentIndexChanged(int index)
{
    if(this->cards.size() > 0 && index < this->cards.size()){
        this->tableStrategyModel->setTrunCard(this->cards[index]);
        this->tableStrategyModel->updateStrategyData();
        // TODO this somehow cause bugs, crashes, why?
        //this->roughStrategyViewerModel->onchanged();
        //this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```