`item_clicked`: The function of `item_clicked` is to handle the click event on a tree item in the Strategy Explorer, triggering various processes and updates.

**Code Description**: When an item is clicked in the tree view, the `item_clicked` function is called. It attempts to process the click by casting the internal pointer of the QModelIndex to a TreeItem pointer, then calls two functions: `process_treeclick` and `process_board`. The tableStrategyModel is updated with the new game tree node, and the strategy data is refreshed. Additionally, the roughStrategyViewerModel is notified of changes, and the rough strategy view is resized and updated. If any runtime errors occur during this process, they are caught and logged using qDebug().\\
## Code: 
```
void StrategyExplorer::item_clicked(const QModelIndex& index){
    try{
        TreeItem * treeNode = static_cast<TreeItem*>(index.internalPointer());
        this->process_treeclick(treeNode);
        this->process_board(treeNode);
        this->tableStrategyModel->setGameTreeNode(treeNode);
        this->tableStrategyModel->updateStrategyData();
        this->ui->strategyTableView->viewport()->update();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->triger_resize();
        this->ui->roughStrategyView->viewport()->update();
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```