`create`: The function of `create` is to create a new workgroup in the database by inserting its details into the "workgroup" table.

**Code Description**: This code snippet defines a method called `create` which takes an object of type `Workgroup` as input. It attempts to insert this workgroup's details into the "workgroup" table in the database using a prepared statement. If the insertion is successful, it retrieves the newly inserted workgroup from the database and caches its ID along with the entire workgroup object for future reference.\\
## Code: 
```
boolean create(Workgroup workgroup) {
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO workgroup (job_id,worktype_id,workcount,description) VALUES (?,?,?,?);";
		String query2 = "SELECT * FROM workgroup ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, workgroup.getJob().getId());
			pst.setInt(2, workgroup.getWorktype().getId());
			pst.setInt(3, workgroup.getWorkCount());
			pst.setString(4, workgroup.getDescription());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					WorkgroupBuilder builder = new WorkgroupBuilder();
					builder.setId(rs.getInt("id"));
					builder.setJob_id(rs.getInt("job_id"));
					builder.setWorktype_id(rs.getInt("worktype_id"));
					builder.setWorkCount(rs.getInt("workcount"));
					builder.setDescription(rs.getString("description"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Workgroup wg = builder.build();
						cache.put(wg.getId(), wg);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id"));
					}
					
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```