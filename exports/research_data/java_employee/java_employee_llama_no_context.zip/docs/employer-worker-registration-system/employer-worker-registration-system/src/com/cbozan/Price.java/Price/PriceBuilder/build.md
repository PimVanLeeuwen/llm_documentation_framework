`build`: The function of `build` is to create a new instance of the Price entity.

**Code Description**: This method, `build`, is a part of a class that likely represents an entity or object in a system. It appears to be responsible for creating a new instance of another entity, specifically a `Price` entity, which is presumably related to this class. The `throws EntityException` clause suggests that the creation process might fail under certain conditions, and if so, it will throw an exception.\\
## Code: 
```
Price build() throws EntityException{
			return new Price(this);
		}
```