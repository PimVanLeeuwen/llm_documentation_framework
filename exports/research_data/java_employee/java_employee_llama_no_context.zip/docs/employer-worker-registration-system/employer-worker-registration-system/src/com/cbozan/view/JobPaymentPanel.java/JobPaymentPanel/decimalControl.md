**Expected Output**
The function of `decimalControl` is to validate whether a given string represents a decimal number with up to two digits after the decimal point.

**Code Description**
The `decimalControl` function takes a variable number of strings as input and returns a boolean value indicating whether all input strings match the pattern of a decimal number. The code uses regular expressions to define the pattern, which is "^\\d+(\\.\\d{1,2})?$". This pattern matches any string that starts with one or more digits (^\\d+), followed by an optional decimal point and up to two digits (\\.\\d{1,2}), and ends with a dollar sign ($). The function iterates over each input string, removes any whitespace characters, and checks if the resulting string matches the pattern using the `find` method of a `Matcher` object. If all strings match the pattern, the function returns true; otherwise, it returns false.\\
## Code: 
```
boolean decimalControl(String ...args) {
		Pattern pattern = Pattern.compile("^\\d+(\\.\\d{1,2})?$"); // decimal pattern xxx.xx
		boolean result = true;
		
		for(String arg : args)
			result = result && pattern.matcher(arg.replaceAll("\\s+", "")).find();
		
		return result;
	}
```