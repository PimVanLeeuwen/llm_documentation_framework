`setFname`: The function of `setFname` is to set the first name of an entity, ensuring it meets certain length criteria.

**Code Description**: This method, `setFname`, is a part of a class that handles entities. It takes in a string parameter, `fname`, which represents the first name of the entity. The function checks if the provided first name is empty or exceeds a specified maximum length (`DBConst.FNAME_LENGTH`). If either condition is met, it throws an `EntityException` with a descriptive message. Otherwise, it assigns the valid first name to the instance variable `this.fname`.\\
## Code: 
```
void setFname(String fname) throws EntityException {
		if(fname.length() == 0 || fname.length() > DBConst.FNAME_LENGTH)
			throw new EntityException("Employer name empty or too long");
		this.fname = fname;
	}
```