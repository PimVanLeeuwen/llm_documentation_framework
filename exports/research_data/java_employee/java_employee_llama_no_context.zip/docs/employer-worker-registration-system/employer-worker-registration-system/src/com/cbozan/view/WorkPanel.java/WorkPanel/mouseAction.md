## mouseAction: 
The function of `mouseAction` is to handle a mouse action event, specifically when an item in the search result list is clicked.

## Code Description:
When the user clicks on an item in the search result list, the `mouseAction` function adds the selected worker object to the default list model, removes it from the original list, clears the text field, updates the count label with the new size of the list model, and calls the superclass's mouse action method.\\
## Code: 
```
void mouseAction(MouseEvent e, Object searchResultObject, int chooseIndex) {
				selectedWorkerDefaultListModel.addElement((Worker) searchResultObject);
				getObjectList().remove(searchResultObject);
				this.setText("");
				selectedInfoCountLabel.setText(selectedWorkerDefaultListModel.size() + " person");
				super.mouseAction(e, searchResultObject, chooseIndex);
			}
```