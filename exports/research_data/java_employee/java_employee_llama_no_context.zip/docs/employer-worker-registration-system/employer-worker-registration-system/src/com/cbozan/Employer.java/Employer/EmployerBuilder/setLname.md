`setLname`: The function of `setLname` is to set the last name of an employer.

**Code Description**: This method, `setLname`, is a part of a class that builds an Employer object. It takes a string parameter `lname` and assigns it to the instance variable `this.lname`. The method returns the same instance (`this`) to allow for method chaining, enabling multiple methods to be called in a single statement.\\
## Code: 
```
EmployerBuilder setLname(String lname) {
			this.lname = lname;
			return this;
		}
```