`addHeight`: The function of `addHeight` is to increase the height of a graphical element by a specified amount.

**Code Description**: This function, `addHeight`, takes an integer parameter `height`. It uses this value to modify the size of a graphical element. Specifically, it calls another function, `setSize`, passing in the current width and the new height (which is the sum of the current height and the provided `height`).\\
## Code: 
```
void addHeight(int height) {
		setSize(getWidth(), getHeight() + height);
		
	}
```