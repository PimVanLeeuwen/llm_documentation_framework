## showEntityException: 
The function of `showEntityException` is to display an error message to the user when an EntityException occurs.

## Code Description:
This function takes two parameters, `e` (an EntityException object) and `msg` (a string message), and displays a customized error message using JOptionPane. The message includes the provided string, a default phrase "not added", the actual exception message, localized message, and cause of the exception.\\
## Code: 
```
void showEntityException(EntityException e, String msg) {
		String message = msg + " not added" + 
				"\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + e.getCause();
			JOptionPane.showMessageDialog(null, message);
	}
```