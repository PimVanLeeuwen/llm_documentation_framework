`delete`: The function of `delete` is to delete a work from the database.

**Code Description**: This code snippet defines a method called `delete` that takes an object of type `Work` as input. It attempts to delete this work from the database using a SQL query, and if successful, removes it from a cache. The method returns true if the deletion is successful (i.e., a row was deleted), and false otherwise.\\
## Code: 
```
boolean delete(Work work) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM work WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, work.getId());
			
			result = ps.executeUpdate();
			
			if(result != 0) {
				cache.remove(work.getId());
			}

		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
		
	}
```