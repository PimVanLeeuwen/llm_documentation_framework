## Expected Output
`showSQLException`: The function of `showSQLException` is to display the details of a SQL exception in a graphical user interface (GUI) message box.

**Code Description**: This function takes an instance of `SQLException` as input, extracts its error code, message, localized message, and cause, and then displays these details in a GUI message box using `JOptionPane.showMessageDialog`.\\
## Code: 
```
void showSQLException(SQLException e) {
		String message = e.getErrorCode() + "\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + "\n" + e.getCause();
		JOptionPane.showMessageDialog(null, message);
	}
```