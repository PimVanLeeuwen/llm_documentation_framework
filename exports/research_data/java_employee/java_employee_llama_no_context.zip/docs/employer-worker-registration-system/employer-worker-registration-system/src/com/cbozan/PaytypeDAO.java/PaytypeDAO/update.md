**Expected Output**
The function of `update` is to update a paytype in the database if the update control is successful.

**Code Description**
This code snippet describes the functionality of an `update` method for a Paytype object. The method takes a Paytype object as input and attempts to update it in the database. If the update control is successful, it updates the corresponding record in the paytype table with the provided title and id.\\
## Code: 
```
boolean update(Paytype paytype) {
		
		if(updateControl(paytype) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE paytype SET title=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1, paytype.getTitle());
			pst.setInt(2, paytype.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(paytype.getId(), paytype);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```