`setId`: The function of `setId` is to set a unique identifier for an entity, ensuring it remains non-negative and valid.

**Code Description**: This method, `setId`, is used to assign a specific integer value to the `id` field within an object. It takes one parameter, `id`, which represents the new identifier to be assigned. The function checks if the provided `id` is less than or equal to zero; if so, it throws an exception of type `EntityException`. This indicates that the input was invalid because a work ID cannot be negative or zero. If the `id` is valid (greater than zero), it updates the object's internal `id` field with this new value.\\
## Code: 
```
void setId(int id) throws EntityException{
		if(id <= 0)
			throw new EntityException("Work ID negative or zero");
		this.id = id;
	}
```