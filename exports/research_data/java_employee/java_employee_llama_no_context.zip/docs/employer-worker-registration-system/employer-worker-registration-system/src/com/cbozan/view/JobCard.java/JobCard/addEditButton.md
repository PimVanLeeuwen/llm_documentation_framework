**Expected Output**
The function of `addEditButton` is to create a JButton that toggles the editability of a JTextComponent and changes its icon based on the current state.

**Code Description**
The code creates a JButton with an edit icon, sets its properties (content area filled, focusable, border painted), and positions it next to a JTextComponent. When clicked, the button toggles the editability of the text field and changes its icon from "edit" to "check" if the text is not empty. If the text field is editable, it becomes non-editable and vice versa. The button also requests focus for the next component in the sequence or the current window if no next component is provided.\\
## Code: 
```
JButton addEditButton(JTextComponent textField, Component nextFocus) {
		JButton editButton = new JButton(new ImageIcon("src\\icon\\text_edit.png"));
		editButton.setContentAreaFilled(false);
		editButton.setFocusable(false);
		editButton.setBorderPainted(false);
		editButton.setBounds(textField.getX() + textField.getWidth() + BS, textField.getY(), BW, rowHeight);
		
		editButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(textField.isEditable()) {
					editButton.setIcon(new ImageIcon("src\\icon\\text_edit.png"));
					textField.setEditable(false);
					if(nextFocus != null) {
						nextFocus.requestFocus();
					} else {
						requestFocusInWindow();
					}
					
				} else if(!textField.getText().equals(INIT_TEXT)) {
						textField.setEditable(true);
						editButton.setIcon(new ImageIcon("src\\icon\\check.png"));
				}
				super.mouseClicked(e);
			}
		});
		
		return editButton;
	}
```