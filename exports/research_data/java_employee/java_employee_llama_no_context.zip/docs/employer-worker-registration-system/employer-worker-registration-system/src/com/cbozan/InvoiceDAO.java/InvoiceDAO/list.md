**Expected Output**
The function of `list` is to retrieve a list of invoices from the database based on a specified column name and ID value.

**Analysis**

The `list` function takes two parameters: `columnName` and `id`. It uses these values to construct a SQL query that selects all records from the `invoice` table where the specified column matches the provided ID. The function then executes this query, retrieves the results, and populates an `Invoice` object for each matching record using an `InvoiceBuilder`.

The `InvoiceBuilder` is used to set the properties of the `Invoice` object based on the values retrieved from the database. If any issues occur during the building process (e.g., due to invalid data), a catch block catches the `EntityException` and prints an error message.

Once all matching records have been processed, the function returns a list of populated `Invoice` objects. If no records are found or if errors occur during processing, the function still returns an empty list or throws an exception, respectively.

The code uses a try-catch block to handle any SQL-related exceptions that may occur during query execution. This ensures that the function does not terminate abruptly in case of database connectivity issues but instead prints an error message and continues executing.

Overall, the `list` function provides a simple way to retrieve invoices from the database based on specific criteria, making it suitable for use cases where invoice data needs to be retrieved and processed programmatically.\\
## Code: 
```
List<Invoice> list(String columnName, int id){
		
		List<Invoice> list = new ArrayList<>();
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM invoice WHERE " + columnName + "=" + id;
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			InvoiceBuilder builder;
			Invoice invoice;
			
			while(rs.next()) {
				
				builder = new InvoiceBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setAmount(rs.getBigDecimal("amount"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					invoice = builder.build();
					list.add(invoice);
				} catch (EntityException e) {
					System.err.println(e.getMessage());
					System.out.println("!! Invoice not added list !!");
				}
				
			}
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return list;
	}
```