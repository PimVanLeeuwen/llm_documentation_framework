`setIban`: The function of `setIban` is to set the value of an instance variable named `iban`.

**Code Description**: This method takes a string parameter `iban`, which represents an International Bank Account Number, and assigns it to the instance variable `iban`. It does not perform any validation or modification on the input string.\\
## Code: 
```
void setIban(String iban) {
		this.iban = iban;
	}
```