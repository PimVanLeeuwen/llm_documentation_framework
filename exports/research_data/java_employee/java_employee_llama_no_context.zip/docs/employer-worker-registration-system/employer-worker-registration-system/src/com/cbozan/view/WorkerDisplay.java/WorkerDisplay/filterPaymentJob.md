`filterPaymentJob`: The function of `filterPaymentJob` is to remove payments from a list that do not match the selected worker payment job.

**Code Description**: This function iterates over a list of payments, checks if each payment's job matches the selected worker payment job, and removes any payments that do not match.\\
## Code: 
```
void filterPaymentJob(List<Payment> paymentList) {
		if(selectedWorkerPaymentJob == null)
			return;
		
		Iterator<Payment> payment = paymentList.iterator();
		Payment paymentItem;
		while(payment.hasNext()) {
			paymentItem = payment.next();
			if(paymentItem.getJob().getId() != selectedWorkerPaymentJob.getId()) {
				payment.remove();
			}
		}
	}
```