`setLname`: The function of `setLname` is to set the last name of a worker.

**Code Description**: This method, `setLname`, is part of a class named `WorkerBuilder`. It takes a string parameter `lname` and assigns it to an instance variable also named `lname`. The method returns the same object (`this`) to allow for method chaining.\\
## Code: 
```
WorkerBuilder setLname(String lname) {
			this.lname = lname;
			return this;
		}
```