`toString`: The function of `toString` is to return a string representation of an object, in this case, a payment object.

**Code Description**: This method is used to convert the data of a Payment object into a human-readable format. It takes no arguments and returns a string that includes all the relevant details of the payment, such as its id, worker, job, pay type, amount, and date.\\
## Code: 
```
String toString() {
		return "Payment [id=" + id + ", worker=" + worker + ", job=" + job + ", paytype=" + paytype + ", amount="
				+ amount + ", date=" + date + "]";
	}
```