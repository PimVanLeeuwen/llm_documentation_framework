`update`: The function of `update` is to update an existing invoice in the database with new job ID and amount, and also update the cache.

**Code Description**: This code snippet defines a method called `update` that takes an `Invoice` object as input. It updates the corresponding record in the database with the new job ID and amount from the provided `Invoice` object, and also updates the cache with the updated invoice details. The method returns true if the update is successful (i.e., one or more rows are affected), and false otherwise.\\
## Code: 
```
boolean update(Invoice invoice) {
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE invoice SET job_id=?,"
				+ "amount=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, invoice.getJob().getId());
			pst.setBigDecimal(2, invoice.getAmount());
			pst.setInt(5, invoice.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(invoice.getId(), invoice);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```