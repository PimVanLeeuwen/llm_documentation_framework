## main: The function of `main` is to initialize the locale to Turkish (tr) and then invoke an event queue to run a login application.

## Code Description: This Java code sets the default locale to Turkish, creates a new instance of the Login class, and runs it using the EventQueue.invokeLater method.\\
## Code: 
```
void main(String[] args) {
		
		Locale.setDefault(new Locale("tr", "TR"));
		
		EventQueue.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				
				new Login();
				
			}
		});
			
	}
```