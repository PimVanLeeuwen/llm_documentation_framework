## Expected output
`toString`: The function of `toString` is to return a string representation of an object, specifically the first name and last name.

**Code Description**: This method returns a concatenated string of the first name and last name. It appears to be part of a class that has methods getFname() and getLname(), which likely retrieve the individual's first and last names from some data source or storage. The toString() function is often used in programming to provide a human-readable representation of an object, making it easier to understand its state or properties.\\
## Code: 
```
String toString() {
		return getFname() + " " + getLname();
	}
```