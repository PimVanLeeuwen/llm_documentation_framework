## Expected output
`clone`: The function of `clone` is to create a copy of the current Employer object, including all its attributes and properties.

## Code Description**: This code snippet defines a method called `clone()` in a class named Employer. The purpose of this method is to create a duplicate or clone of the current Employer object. It uses the built-in `super.clone()` method to perform the cloning operation. If any exception occurs during the cloning process, it catches the exception and returns null instead of throwing an error.\\
## Code: 
```
Employer clone(){
		// TODO Auto-generated method stub
		try {
			return (Employer) super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
			return null;
		}
	}
```