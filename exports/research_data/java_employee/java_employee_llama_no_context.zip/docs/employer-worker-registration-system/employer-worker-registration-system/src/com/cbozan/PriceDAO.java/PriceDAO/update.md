`update`: The function of `update` is to update a price record in the database with the provided details and refresh the cache if the update is successful.

**Code Description**: This method updates a price record in the database based on the given Price object. It first checks if the update control is successful, then it prepares an SQL query to update the corresponding row in the "price" table with the new fulltime, halftime, and overtime values. If the update is successful (i.e., the result is not zero), it refreshes the cache by storing the updated Price object with its ID as the key.\\
## Code: 
```
boolean update(Price price) {
		
		if(updateControl(price) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE price SET fulltime=?,"
				+ "halftime=?, overtime=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setBigDecimal(1, price.getFulltime());
			pst.setBigDecimal(2, price.getHalftime());
			pst.setBigDecimal(3, price.getOvertime());
			pst.setInt(4, price.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(price.getId(), price);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```