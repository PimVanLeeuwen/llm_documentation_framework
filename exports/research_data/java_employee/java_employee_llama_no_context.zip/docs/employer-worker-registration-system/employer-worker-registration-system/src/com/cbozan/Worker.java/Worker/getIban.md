`getIban`: The function of `getIban` is to return the IBAN (International Bank Account Number) value.

**Code Description**: This method, `getIban`, is a getter function that retrieves and returns the stored IBAN value. It does not modify or calculate any values; it simply provides access to the existing IBAN data.\\
## Code: 
```
String getIban() {
		return iban;
	}
```