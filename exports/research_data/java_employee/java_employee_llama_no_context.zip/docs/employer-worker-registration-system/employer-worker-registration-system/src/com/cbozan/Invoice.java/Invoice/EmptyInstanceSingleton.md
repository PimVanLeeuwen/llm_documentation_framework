**Expected Output**
`EmptyInstanceSingleton`: The function of `EmptyInstanceSingleton` is to ensure that only one instance of the Invoice class exists throughout the application.

**Code Description**: 
The provided code snippet defines a class named EmptyInstanceSingleton. This class contains a private static final variable named "instance" which holds an object of type Invoice. The key aspect here is the use of the keyword "final", indicating that once this instance is created, it cannot be changed or reassigned.\\
## Code: 
```
class EmptyInstanceSingleton{
		private static final Invoice instance = new Invoice(); 
	}
```