**Expected Output**
The function of `decimalControl` is to check if a given string matches a specified pattern, where the pattern is a regular expression that represents decimal numbers.

**Code Description**
The `decimalControl` function takes two parameters: a `Pattern` object and a variable number of strings (`String ...args`). It iterates over each string in the `args` array and uses the `find()` method of the `Matcher` object returned by the `matcher()` method of the `Pattern` object to search for a match. If any of the strings do not match the pattern, the function returns `false`. Otherwise, it returns `true`, indicating that all strings in the `args` array are decimal numbers according to the specified pattern.\\
## Code: 
```
boolean decimalControl(Pattern pattern, String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= pattern.matcher(arg).find();
		}
		return rValue;
	}
```