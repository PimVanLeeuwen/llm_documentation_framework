`updateJobTableData`: The function of `updateJobTableData` is to update the data displayed in a table with job information.

**Code Description**: This function retrieves a list of jobs associated with the currently selected employer from a database using the JobDAO instance. It then populates a 2D array with the job details, including ID, employer, title, and description. The array is used to create a new DefaultTableModel, which is set as the model for a JTable component. The table's columns are resized and formatted accordingly. Finally, the function updates a label displaying the total number of jobs in the list.\\
## Code: 
```
void updateJobTableData() {
		
		if(selectedEmployer != null) {
			
			List<Job> jobList = JobDAO.getInstance().list(selectedEmployer);
			
			String[][] tableData = new String[jobList.size()][jobTableColumns.length];
			
			int i = 0;
			for(Job j : jobList) {
				
				tableData[i][0] = j.getId() + "";
				tableData[i][1] = j.getEmployer().toString();
				tableData[i][2] = j.getTitle();
				tableData[i][3] = j.getDescription();
				++i;
			}
			
			((JTable)jobScrollPane.getViewport().getComponent(0)).setModel(new DefaultTableModel(tableData, jobTableColumns));
			((JTable)jobScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setPreferredWidth(5);
			((JTable)jobScrollPane.getViewport().getComponent(0)).setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
			
			DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
			centerRenderer.setHorizontalAlignment( SwingConstants.CENTER );
			((JTable)jobScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
			
			jobCountLabel.setText(jobList.size() + " Kayıt");
		}
		
	}
```