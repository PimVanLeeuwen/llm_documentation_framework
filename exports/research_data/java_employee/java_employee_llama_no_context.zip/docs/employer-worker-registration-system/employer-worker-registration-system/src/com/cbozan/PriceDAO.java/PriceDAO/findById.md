`findById`: The function of `findById` is to retrieve a price object from a cache or database by its unique identifier (id).

**Code Description**: This method, `findById`, appears to be part of a larger system that manages prices. It uses a caching mechanism to store previously retrieved prices. If the cache is not being used, it calls the `list()` function, which likely retrieves all price objects from a database or other data source and stores them in the cache. The method then checks if the requested id exists in the cache; if so, it returns the corresponding price object. If not, it returns null, indicating that the price was not found.\\
## Code: 
```
Price findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```