## Expected output
`createControl`: The function of `createControl` is to check if a new control can be created for the given worktype.

**Code Description**: This function iterates through a cache of existing entries and checks if a worktype with the same title already exists. If it does, the function returns false, indicating that a new control cannot be created. If no matching entry is found, the function returns true, allowing the creation of a new control.\\
## Code: 
```
boolean createControl(Worktype worktype) {
		for(Entry<Integer, Worktype> obj : cache.entrySet()) {
			if(obj.getValue().getTitle().equals(worktype.getTitle())) {
				return false;
			}
		}
		return true;
	}
```