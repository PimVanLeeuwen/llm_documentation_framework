`findById`: The function of `findById` is to retrieve a workgroup from the cache or database by its unique identifier if it exists, otherwise return null.

**Code Description**: This method appears to be part of a larger system that utilizes caching for performance optimization. It checks if the cache is being used (usingCache == false) and if so, it calls the list() function, which likely retrieves all workgroups from the database or another data source. The findById() function then checks if the requested workgroup ID exists in the cache. If it does, it returns the cached workgroup; otherwise, it returns null, indicating that the workgroup was not found in either the cache or the database.\\
## Code: 
```
Workgroup findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```