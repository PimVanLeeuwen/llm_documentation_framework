`notifyAllObservers`: The function of `notifyAllObservers` is to notify all registered observers that an update has occurred.

**Code Description**: This function iterates over a collection of observers, invoking the `update()` method on each one. The purpose of this method call is to inform the observer that some event or change has taken place and may require them to take action or perform some task based on the new information.\\
## Code: 
```
void notifyAllObservers() {
		for(Observer observer : observers) {
			observer.update();
		}
	}
```