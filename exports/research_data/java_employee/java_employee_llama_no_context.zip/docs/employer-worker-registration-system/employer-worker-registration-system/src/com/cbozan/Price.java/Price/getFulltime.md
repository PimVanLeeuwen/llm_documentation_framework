## Expected Output
`getFulltime`: The function of `getFulltime` is to return the full-time value.

## Code Description
The code snippet provided defines a method named `getFulltime()` that returns an object of type `BigDecimal`, which is stored in a variable named `fulltime`. This suggests that the purpose of this method is to provide access to the full-time value, presumably for use elsewhere in the program.\\
## Code: 
```
BigDecimal getFulltime() {
		return fulltime;
	}
```