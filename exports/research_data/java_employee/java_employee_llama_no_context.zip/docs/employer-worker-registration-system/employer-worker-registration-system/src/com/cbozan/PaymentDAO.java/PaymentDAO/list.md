**Expected Output**
The function of `list` is to retrieve a list of payments from a database based on specified column names and corresponding IDs.

**Code Description**
The `list` function takes two parameters: an array of column names (`columnName`) and an array of IDs (`id`). It returns a list of `Payment` objects. The function first checks if the lengths of the `columnName` and `id` arrays are equal, returning an empty list if they are not. It then constructs a SQL query by iterating over the `columnName` array and appending each column name with its corresponding ID to the query string. The query is executed on a database connection, and the results are retrieved as a `ResultSet`. Each row in the result set is used to create a new `Payment` object using a `PaymentBuilder`, which is then added to the list. If any errors occur during this process, they are caught and printed to the console.\\
## Code: 
```
List<Payment> list(String[] columnName, int[] id){
		
		List<Payment> list = new ArrayList<>();
		if(columnName.length != id.length)
			return list;
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM payment WHERE ";
		
		for(int i = 0; i < columnName.length; i++) {
			query += columnName[i] + "=" + id[i] + " AND ";
		}
		
		query = query.substring(0, query.length() - (" AND ".length()));
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			PaymentBuilder builder;
			Payment payment;
			
			while(rs.next()) {
				
				builder = new PaymentBuilder();
				builder.setId(rs.getInt("id"));
				builder.setWorker_id(rs.getInt("worker_id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setPaytype_id(rs.getInt("paytype_id"));
				builder.setAmount(rs.getBigDecimal("amount"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					payment = builder.build();
					list.add(payment);
				} catch (EntityException e) {
					System.err.println(e.getMessage());
					System.out.println("!! Payment not added list !!");
				}
				
			}
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return list;
	}
```