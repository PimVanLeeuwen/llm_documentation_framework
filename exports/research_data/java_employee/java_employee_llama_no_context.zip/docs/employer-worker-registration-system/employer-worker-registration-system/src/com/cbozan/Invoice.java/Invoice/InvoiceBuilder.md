**InvoiceBuilder**: The function of `InvoiceBuilder` is to create an invoice object by setting various attributes such as id, job_id, job, amount, and date.

**Code Description**: InvoiceBuilder is a class that provides a builder pattern for creating invoices. It has several setter methods (setId, setJob_id, setJob, setAmount, setDate) that allow you to set the corresponding attributes of an invoice. The build method returns an Invoice object once all required attributes are set. If a job is provided during construction or setting, it will be used in the Invoice creation; otherwise, the job_id will be used instead.\\
## Code: 
```
class InvoiceBuilder{
		
		private int id;
		private int job_id;
		private Job job;
		private BigDecimal amount;
		private Timestamp date;
		
		public InvoiceBuilder() {}
		public InvoiceBuilder(int id, int job_id, BigDecimal amount, Timestamp date) {
			this.id = id;
			this.job_id = job_id;
			this.amount = amount;
			this.date = date;
		}
		
		public InvoiceBuilder(int id, Job job, BigDecimal amount, Timestamp date) {
			this(id, 0, amount, date);
			this.job = job;
		}
		
		public InvoiceBuilder setId(int id) {
			this.id = id;
			return this;
		}
		
		public InvoiceBuilder setJob_id(int job_id) {
			this.job_id = job_id;
			return this;
		}
		
		public InvoiceBuilder setJob(Job job) {
			this.job = job;
			return this;
		}
		
		public InvoiceBuilder setAmount(BigDecimal amount) {
			this.amount = amount;
			return this;
		}
		
		public InvoiceBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Invoice build() throws EntityException {
			if(job == null)
				return new Invoice(this);
			return new Invoice(id, job, amount, date);
		}
		
	}
```