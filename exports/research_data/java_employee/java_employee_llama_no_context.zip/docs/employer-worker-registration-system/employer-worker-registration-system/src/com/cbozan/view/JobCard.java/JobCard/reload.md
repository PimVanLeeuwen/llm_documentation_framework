`reload`: The function of `reload` is to reload or update the selected job by calling the `setSelectedJob` function with the current `selectedJob`.

**Code Description**: This code snippet defines a function named `reload`. When called, it executes the statement `setSelectedJob(selectedJob);`, which likely updates some visual representation or internal state related to the currently selected job. The purpose of this function is to refresh or update the display or handling of the selected job, possibly in response to user input or other events that necessitate a change in what's being shown or processed.\\
## Code: 
```
void reload() {
		setSelectedJob(selectedJob);
	}
```