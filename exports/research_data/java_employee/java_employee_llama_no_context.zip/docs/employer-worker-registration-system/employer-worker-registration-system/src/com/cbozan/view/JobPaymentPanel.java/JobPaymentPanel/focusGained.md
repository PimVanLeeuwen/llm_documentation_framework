`focusGained`: The function of `focusGained` is to change the border and foreground color of a JTextField when it gains focus.

**Code Description**: This code snippet defines a method called `focusGained` which handles FocusEvent instances. It checks if the source of the event is an instance of JTextField, and if so, sets its border to a blue line border using LineBorder(Color.blue). Additionally, if the JTextField is specifically the "amountTextField", it also changes the foreground color of the "amountLabel" to blue.\\
## Code: 
```
void focusGained(FocusEvent e) {
		if(e.getSource() instanceof JTextField) {
			
			((JTextField)e.getSource()).setBorder(new LineBorder(Color.blue));
			
			if(((JTextField)e.getSource()) == amountTextField) {
				amountLabel.setForeground(Color.blue);
			}
			
		}
		
	}
```