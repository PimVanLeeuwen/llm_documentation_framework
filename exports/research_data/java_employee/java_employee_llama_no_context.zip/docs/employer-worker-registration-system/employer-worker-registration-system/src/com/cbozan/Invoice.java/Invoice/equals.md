**equals**: The function of `equals` is to determine whether two objects are equal, in this case, two Invoice objects.

**Code Description**: This code snippet implements the equals method for an Invoice class. It checks if the input object (obj) is the same instance as the current object, and returns true if they are the same. If the input object is null, it returns false. The code then checks if the classes of the two objects are the same, and returns false if they are not. Finally, it casts the input object to an Invoice and compares its properties (amount, date, id, job) with those of the current object using the Objects.equals method. If all properties match, it returns true; otherwise, it returns false.\\
## Code: 
```
boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Invoice other = (Invoice) obj;
		return Objects.equals(amount, other.amount) && Objects.equals(date, other.date) && id == other.id
				&& Objects.equals(job, other.job);
	}
```