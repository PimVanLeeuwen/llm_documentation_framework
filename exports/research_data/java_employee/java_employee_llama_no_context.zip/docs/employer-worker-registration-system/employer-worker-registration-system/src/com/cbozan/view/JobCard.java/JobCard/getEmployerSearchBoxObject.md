## getEmployerSearchBoxObject: 
The function of `getEmployerSearchBoxObject` is to retrieve the selected object from an employer search box.

**Code Description**: The code defines a method called `getEmployerSearchBoxObject` which returns the selected object from an employer search box.\\
## Code: 
```
Employer getEmployerSearchBoxObject() {
		return (Employer) employerSearchBox.getSelectedObject();
	}
```