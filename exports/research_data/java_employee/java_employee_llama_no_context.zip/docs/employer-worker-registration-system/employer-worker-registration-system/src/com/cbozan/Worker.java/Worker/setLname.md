`setLname`: The function of `setLname` is to set the last name of a worker entity.

**Code Description**: This method, `setLname`, is used to update or modify the last name attribute of an object representing a worker. It takes one parameter, `lname`, which is expected to be a string containing the new last name value. The function checks if the provided last name meets certain conditions: it must not be empty and its length should not exceed the maximum allowed length defined by `DBConst.LNAME_LENGTH`. If these conditions are not met, the method throws an exception of type `EntityException` with a message indicating that the worker's last name is either empty or too long. Otherwise, it assigns the provided last name to the object's `lname` attribute.\\
## Code: 
```
void setLname(String lname) throws EntityException {
		if(lname.length() == 0 || lname.length() > DBConst.LNAME_LENGTH)
			throw new EntityException("Worker last name empty or too long");
		this.lname = lname;
	}
```