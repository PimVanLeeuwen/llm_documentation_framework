`getSelectedJob`: The function of `getSelectedJob` is to return the selected job.

**Code Description**: This function, named `getSelectedJob`, appears to be part of a class or object that manages jobs. It returns an instance variable named `selectedJob`. The purpose of this function seems to be to provide access to the currently selected job, likely for use in other parts of the program.\\
## Code: 
```
Job getSelectedJob() {
		return selectedJob;
	}
```