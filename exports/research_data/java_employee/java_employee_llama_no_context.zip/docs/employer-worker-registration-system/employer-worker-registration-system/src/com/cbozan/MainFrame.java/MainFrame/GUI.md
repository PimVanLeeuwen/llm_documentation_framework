## GUI: The function of `GUI` is to initialize and display the graphical user interface (GUI) components, including menus and other visual elements.

## Code Description: 
The `GUI()` function creates the necessary menu structures using the `createMenus()` function and initializes the various GUI components with `createComponents()`. Although an initialization step (`init()`) is commented out, it suggests that this function may also handle any setup or configuration tasks required for the GUI to function properly.\\
## Code: 
```
void GUI() {
		createMenus();
		createComponents();
		//init();
		
	}
```