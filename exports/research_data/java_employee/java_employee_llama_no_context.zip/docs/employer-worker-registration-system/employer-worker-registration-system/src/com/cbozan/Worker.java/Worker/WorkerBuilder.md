**WorkerBuilder**: The function of `WorkerBuilder` is to build a `Worker` object by setting its properties and then creating the actual `Worker` instance.

**Code Description**: WorkerBuilder is a builder class used to construct a `Worker` object in a step-by-step manner. It provides a fluent interface for setting various attributes of the worker, such as ID, first name, last name, phone numbers, IBAN, description, and date. Once all properties are set, the `build()` method can be called to create the actual `Worker` instance.\\
## Code: 
```
class WorkerBuilder{
		
		private int id;
		private String fname;
		private String lname;
		private List<String> tel;
		private String iban;
		private String description;
		private Timestamp date;

		public WorkerBuilder() {}
		public WorkerBuilder(int id, String fname, String lname, List<String> tel, String iban, String description, Timestamp date) {
			super();
			this.id = id;
			this.fname = fname;
			this.lname = lname;
			this.tel = tel;
			this.iban = iban;
			this.description = description;
			this.date = date;
		}

		public WorkerBuilder setId(int id) {
			this.id = id;
			return this;
		}

		public WorkerBuilder setFname(String fname) {
			this.fname = fname;
			return this;
		}

		public WorkerBuilder setLname(String lname) {
			this.lname = lname;
			return this;
		}

		public WorkerBuilder setTel(List<String> tel) {
			this.tel = tel;
			return this;
		}
		
		public WorkerBuilder setIban(String iban) {
			this.iban = iban;
			return this;
		}

		public WorkerBuilder setDescription(String description) {
			this.description = description;
			return this;
		}

		public WorkerBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Worker build() throws EntityException {
			return new Worker(this);
		}		
		
	}
```