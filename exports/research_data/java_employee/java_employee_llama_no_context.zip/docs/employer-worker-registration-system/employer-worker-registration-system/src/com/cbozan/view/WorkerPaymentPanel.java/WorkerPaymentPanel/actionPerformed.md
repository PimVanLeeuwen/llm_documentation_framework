**Expected Output**
The function of `actionPerformed` is to handle the action performed on a specific button, in this case, the "payButton".

**Code Description**
When the "payButton" is clicked, the code retrieves selected worker, job, paytype, and amount from their respective UI components. It then checks if all necessary information has been entered correctly and if so, it creates a new Payment object using the builder pattern. The payment details are displayed in a confirmation dialog box, and upon user confirmation, the payment is saved to the database using the PaymentDAO instance. If the save operation fails, an error message is displayed.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		if(e.getSource() == payButton) {
			
			Worker worker;
			Job job;
			Paytype paytype;
			String amount;
			
			worker = selectedWorker;
			job = selectedJob;
			paytype = (Paytype) paytypeComboBox.getSelectedItem();
			amount = amountTextField.getText().replaceAll("\\s+", "");

			if(!decimalControl(amount) || worker == null || job == null || paytype == null) {
				
				String message;
				message = "Please enter selection parts or format correctly (max 2 floating point)";
				JOptionPane.showMessageDialog(this, message, "ERROR", JOptionPane.ERROR_MESSAGE);
				
			} else {
				
				JTextArea workerTextArea, jobTextArea, paytypeTextArea, amountTextArea;
				
				workerTextArea = new JTextArea(worker.toString());
				workerTextArea.setEditable(false);
				
				jobTextArea = new JTextArea(job.toString());
				jobTextArea.setEditable(false);
				
				paytypeTextArea = new JTextArea(paytype.toString());
				paytypeTextArea.setEditable(false);
				
				amountTextArea = new JTextArea(amount + " ₺");
				amountTextArea.setEditable(false);
				
				Object[] pane = {
						new JLabel("Worker"),
						workerTextArea,
						new JLabel("Job"),
						jobTextArea,
						new JLabel("Payment method"),
						paytypeTextArea,
						new JLabel("Amount of payment"),
						amountTextArea
				};
		
				int result = JOptionPane.showOptionDialog(this, pane, "Confirmation", 1, 1, 
						new ImageIcon("src\\icon\\accounting_icon_1_32.png"), new Object[] {"SAVE", "CANCEL"}, "CANCEL");
				
				
				// System.out.println(result);
				// 0 -> SAVE
				// 1 -> CANCEL
				
				if(result == 0) {
					
					Payment.PaymentBuilder builder = new Payment.PaymentBuilder();
					builder.setId(Integer.MAX_VALUE);
					builder.setWorker(worker);
					builder.setJob(job);
					builder.setPaytype(paytype);
					builder.setAmount(new BigDecimal(amount));
					
					Payment payment = null;
					try {
						payment = builder.build();
					} catch (EntityException e1) {
						System.out.println(e1.getMessage());
					}
					
					if(PaymentDAO.getInstance().create(payment)) { 
						JOptionPane.showMessageDialog(this, "Registraion successful");
						notifyAllObservers();
					} else {
						JOptionPane.showMessageDialog(this, "Not saved", "Database error", JOptionPane.ERROR_MESSAGE);
					}
				}
				
			}
			
			
		}
		
	}
```