**EmployerBuilder**: The function of `EmployerBuilder` is to create an instance of the `Employer` class by setting its properties and then calling the `build()` method.

**Code Description**: 
The `EmployerBuilder` class is a builder pattern implementation that allows for step-by-step construction of an `Employer` object. It provides setter methods for each property (id, fname, lname, tel, description, date) and returns the instance itself (`this`) to enable method chaining. The `build()` method creates and returns an `Employer` object with the specified properties.\\
## Code: 
```
class EmployerBuilder{
		
		private int id;
		private String fname;
		private String lname;
		private List<String> tel;
		private String description;
		private Timestamp date;

		public EmployerBuilder() {}
		public EmployerBuilder(int id, String fname, String lname, List<String> tel, String description, Timestamp date) {
			super();
			this.id = id;
			this.fname = fname;
			this.lname = lname;
			this.tel = tel;
			this.description = description;
			this.date = date;
		}

		public EmployerBuilder setId(int id) {
			this.id = id;
			return this;
		}

		public EmployerBuilder setFname(String fname) {
			this.fname = fname;
			return this;
		}

		public EmployerBuilder setLname(String lname) {
			this.lname = lname;
			return this;
		}

		public EmployerBuilder setTel(List<String> tel) {
			this.tel = tel;
			return this;
		}

		public EmployerBuilder setDescription(String description) {
			this.description = description;
			return this;
		}

		public EmployerBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Employer build() throws EntityException {
			return new Employer(this);
		}		
		
	}
```