## Expected Output
`setLname`: The function of `setLname` is to set the last name of an entity.

**Code Description**: This method, `setLname`, takes a string parameter representing the last name and checks if it meets certain conditions. If the length of the provided last name is either 0 (empty) or exceeds the maximum allowed length defined by `DBConst.LNAME_LENGTH`, it throws an `EntityException` with a specific error message. Otherwise, it assigns the given last name to the instance variable `lname`.\\
## Code: 
```
void setLname(String lname) throws EntityException {
		if(lname.length() == 0 || lname.length() > DBConst.LNAME_LENGTH)
			throw new EntityException("Employer last name empty or too long");
		this.lname = lname;
	}
```