`filterPaymentJob`: The function of `filterPaymentJob` is to remove invoices that do not belong to the selected job from a list of invoices.

**Code Description**: This function iterates over a list of invoices and removes any invoice that does not match the currently selected job. It appears to be part of a larger system for managing payments related to jobs, where each invoice is associated with a specific job. The function takes a list of invoices as input and modifies it in-place by removing invoices that do not belong to the selected job.\\
## Code: 
```
void filterPaymentJob(List<Invoice> invoiceList) {
		
		if(selectedJob == null)
			return;
		
		Iterator<Invoice> invoice = invoiceList.iterator();
		Invoice invoiceItem;
		while(invoice.hasNext()) {
			invoiceItem = invoice.next();
			if(invoiceItem.getJob().getId() != selectedJob.getId()) {
				invoice.remove();
			}
		}
		
	}
```