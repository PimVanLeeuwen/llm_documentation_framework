`filterJob`: The function of `filterJob` is to filter a list of work items based on their job ID, removing any items that do not match the selected job.

**Code Description**: This function iterates over a list of work items and removes any item whose job ID does not match the ID of the currently selected job. If no job is selected, the function returns without modifying the list.\\
## Code: 
```
void filterJob(List<Work> workList) {
		if(selectedWorkTableJob == null) {
			return;
		}
		
		Iterator<Work> work = workList.iterator();
		Work workItem;
		while(work.hasNext()) {
			workItem = work.next();
			if(workItem.getJob().getId() != selectedWorkTableJob.getId()) {
				work.remove();
			}
		}
		
	}
```