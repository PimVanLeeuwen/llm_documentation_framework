**Expected Output**
The function of `createControl` is to check if a new price record already exists in the cache before creating a control.

**Code Description**
The code checks for duplicate price records in the cache by iterating over each entry and comparing the fulltime, halftime, and overtime values with the provided price. If a match is found, it returns false and sets an error message indicating that the record already exists. If no match is found, it returns true, allowing the creation of a new control.\\
## Code: 
```
boolean createControl(Price price) {
		for(Entry<Integer, Price> obj : cache.entrySet()) {
			if(obj.getValue().getFulltime().compareTo(price.getFulltime()) == 0
					&& obj.getValue().getHalftime().compareTo(price.getHalftime()) == 0
					&& obj.getValue().getOvertime().compareTo(price.getOvertime()) == 0) {
				
				DB.ERROR_MESSAGE = "Bu fiyat bilgisi kaydı zaten mevcut.";
				return false;
			}
		}
		
		return true;
	}
```