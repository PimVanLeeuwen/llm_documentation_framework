`setFulltime`: The function of `setFulltime` is to set the full-time price of an entity to a specified value.

**Code Description**: This method, `setFulltime`, takes a `BigDecimal` object representing the full-time price as input. It checks if the provided price is null or less than or equal to zero. If either condition is true, it throws an `EntityException` with a message indicating that the price cannot be negative or null/zero. Otherwise, it assigns the given full-time price to the instance variable `fulltime`.\\
## Code: 
```
void setFulltime(BigDecimal fulltime) throws EntityException {
		if(fulltime == null || fulltime.compareTo(new BigDecimal("0.00")) <= 0)
			throw new EntityException("Price fulltime negative or null or zero");
		this.fulltime = fulltime;
	}
```