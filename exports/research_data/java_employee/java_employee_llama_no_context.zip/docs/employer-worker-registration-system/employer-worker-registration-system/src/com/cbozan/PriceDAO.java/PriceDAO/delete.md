`delete`: The function of `delete` is to delete a price record from the database based on its ID and update the cache accordingly.

**Code Description**: This code snippet defines a method called `delete` that takes an object of type `Price` as input. It attempts to delete the corresponding record from the database using a SQL query, and if successful, removes the cached data associated with the deleted price ID. The method returns a boolean value indicating whether the deletion was successful or not.\\
## Code: 
```
boolean delete(Price price) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM price WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, price.getId());
			result = ps.executeUpdate();
			
			if(result != 0) {
				cache.remove(price.getId());
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
		
	}
```