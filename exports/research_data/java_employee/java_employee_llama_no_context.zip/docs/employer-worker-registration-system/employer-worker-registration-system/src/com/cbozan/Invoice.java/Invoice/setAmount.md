`setAmount`: The function of `setAmount` is to set the amount of an invoice to a specified value, while ensuring it is not negative or zero.

**Code Description**: This method takes a BigDecimal object as input and checks if it is less than or equal to 0. If true, it throws an EntityException with a message indicating that the invoice amount cannot be negative or zero. Otherwise, it sets the amount of the invoice to the provided value.\\
## Code: 
```
void setAmount(BigDecimal amount) throws EntityException {
		if(amount.compareTo(new BigDecimal("0.00")) <= 0)
			throw new EntityException("Invoice amount negative or zero");
		this.amount = amount;
	}
```