## Expected Output
`setDescriptionTextAreaContent`: The function of `setDescriptionTextAreaContent` is to set the text content of a text area with the given description and update the selected job's description if it exists.

**Code Description**: This method updates the text area's content with the provided description. If a job has been selected, it also updates the job's description field with the new value.\\
## Code: 
```
void setDescriptionTextAreaContent(String description) {
		this.descriptionTextArea.setText(description);
		
		if(getSelectedJob() != null)
			getSelectedJob().setDescription(description);
	}
```