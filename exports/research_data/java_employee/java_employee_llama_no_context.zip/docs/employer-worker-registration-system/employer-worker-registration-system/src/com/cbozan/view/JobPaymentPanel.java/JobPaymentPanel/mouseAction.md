## mouseAction: The function of `mouseAction` is to handle a mouse action event, likely triggered by a user interaction such as clicking on an item in a list or search result.

**Code Description:** This method appears to be part of a larger class that handles GUI interactions. It takes three parameters: `MouseEvent e`, `Object searchResultObject`, and `int chooseIndex`. The function updates various UI components with information from the `searchResultObject` and disables editing on a search box, indicating that the user has selected an item and is now viewing its details.\\
## Code: 
```
void mouseAction(MouseEvent e, Object searchResultObject, int chooseIndex) {
				selectedJob = (Job) searchResultObject;
				searchJobSearchBox.setText(searchResultObject.toString());
				searchJobSearchBox.setEditable(false);
				jobTitleTextField.setText(selectedJob.toString());
				employerTextField.setText(selectedJob.getEmployer().toString());
				clearPanel();
				super.mouseAction(e, searchResultObject, chooseIndex);
			}
```