`findById`: The function of `findById` is to retrieve an invoice by its unique identifier (id).

**Code Description**: This method, `findById`, appears to be part of a larger system for managing invoices. It utilizes a cache mechanism to store previously retrieved invoices. If the cache is not being used (`usingCache == false`), it calls the `list()` function, which likely retrieves all invoices from a database or other data source. The `findById` method then checks if an invoice with the specified id exists in the cache. If it does, it returns that cached invoice; otherwise, it returns null, indicating no matching invoice was found.\\
## Code: 
```
Invoice findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
	}
```