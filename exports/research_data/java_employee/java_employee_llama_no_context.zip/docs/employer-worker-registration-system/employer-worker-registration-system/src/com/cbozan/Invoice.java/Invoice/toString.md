## toString: The function of `toString` is to return a string representation of an object, in this case, an invoice.

## Code Description: This method is used to convert the state of an object into a human-readable format. It takes no arguments and returns a string that includes the values of the object's properties (id, job, amount, date).\\
## Code: 
```
String toString() {
		return "Invoice [id=" + id + ", job=" + job + ", amount=" + amount + ", date=" + date + "]";
	}
```