`setHalftime`: The function of `setHalftime` is to set the halftime value for an entity, ensuring it is a positive number.

**Code Description**: This method takes a BigDecimal object representing the halftime as input and assigns it to the instance variable `halftime`. It first checks if the input halftime is null or less than or equal to zero. If either condition is true, it throws an EntityException with a message indicating that the halftime cannot be negative or null/zero. Otherwise, it proceeds to set the halftime value.\\
## Code: 
```
void setHalftime(BigDecimal halftime) throws EntityException {
		if(halftime == null || halftime.compareTo(new BigDecimal("0.00")) <= 0)
			throw new EntityException("Price halftime negative or null or zero");
		this.halftime = halftime;
	}
```