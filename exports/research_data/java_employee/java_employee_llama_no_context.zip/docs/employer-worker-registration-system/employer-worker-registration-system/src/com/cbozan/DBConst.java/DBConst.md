**DBConst**: The function of `DBConst` is to define and store constant values related to database constraints, specifically for handling names in a database.

**Code Description**: DBConst is a Java class that contains public static final integer variables representing the maximum length allowed for first name (FNAME_LENGTH) and last name (LNAME_LENGTH). These constants can be used throughout an application to enforce consistent naming conventions when interacting with a database.\\
## Code: 
```
class DBConst {
	public static final int FNAME_LENGTH = 30;
	public static final int LNAME_LENGTH = 20;
}
```