`equals`: The function of `equals` is to compare two objects for equality.

**Code Description**: This code snippet defines the `equals` method in Java, which is used to determine whether an object is equal to another object. It checks if the two objects are the same instance, and if not, it compares their class types, date, fulltime status, halftime status, overtime status, and ID. If all these attributes match, the method returns true; otherwise, it returns false.\\
## Code: 
```
boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Price other = (Price) obj;
		return Objects.equals(date, other.date) && Objects.equals(fulltime, other.fulltime)
				&& Objects.equals(halftime, other.halftime) && id == other.id
				&& Objects.equals(overtime, other.overtime);
	}
```