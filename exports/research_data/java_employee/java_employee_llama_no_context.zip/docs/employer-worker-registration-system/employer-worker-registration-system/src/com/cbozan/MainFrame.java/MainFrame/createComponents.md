`createComponents`: The function of `createComponents` is to create and display various panels related to job, worker, employer, price, payment, and work.

**Code Description**: This function creates instances of different panel classes (JobPanel, WorkerPanel, EmployerPanel, PricePanel, WorkerPaymentPanel, WorkPanel, JobPaymentPanel, JobDisplay, WorkerDisplay, EmployerDisplay) and adds them to a list. It then sets the content pane of the application to the panel corresponding to the active page.\\
## Code: 
```
void createComponents() {
		
		// record menu panels
		JobPanel job = new JobPanel();
		WorkerPanel worker = new WorkerPanel();
		EmployerPanel employer = new EmployerPanel();
		PricePanel price = new PricePanel();
		
		// add menu panels
		WorkerPaymentPanel workerPayment = new WorkerPaymentPanel();
		WorkPanel work = new WorkPanel();
		JobPaymentPanel jobPayment = new JobPaymentPanel();
		
		// display menu panels
		JobDisplay jobDisplay = new JobDisplay();
		WorkerDisplay workerDisplay = new WorkerDisplay();
		EmployerDisplay employerDisplay = new EmployerDisplay();
		
		components = new ArrayList<>();
		components.add(job);
		components.add(worker);
		components.add(employer);
		components.add(price);
		components.add(workerPayment);
		components.add(work);
		components.add(jobPayment);
		components.add(jobDisplay);
		components.add(workerDisplay);
		components.add(employerDisplay);
		
		setContentPane((JPanel) components.get(activePage));
		
	}
```