`filterWorktype`: The function of `filterWorktype` is to remove work items from a list that do not match the currently selected work type.

**Code Description**: This function iterates over a list of work items, and for each item, it checks if the work type matches the currently selected work type. If they do not match, the work item is removed from the list. The function returns without doing anything if no work type has been selected.\\
## Code: 
```
void filterWorktype(List<Work> workList) {
		if(selectedWorktype == null) {
			return;
		}
		
		Iterator<Work> work = workList.iterator();
		Work workItem;
		while(work.hasNext()) {
			workItem = work.next();
			if(workItem.getWorktype().getId() != selectedWorktype.getId()) {
				work.remove();
			}
		}
	}
```