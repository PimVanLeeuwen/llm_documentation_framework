**Expected Output**
The function of `updateControl` is to check if a new price record already exists in the cache with the same fulltime, halftime, and overtime values but a different ID.

**Code Description**
The code checks for an existing price record in the cache that matches the provided price's fulltime, halftime, and overtime values. If such a record is found with a different ID, it returns false and sets an error message indicating that the price information already exists. Otherwise, it returns true to indicate that the new price can be updated.\\
## Code: 
```
boolean updateControl(Price price) {
		for(Entry<Integer, Price> obj : cache.entrySet()) {
			if(obj.getValue().getFulltime().compareTo(price.getFulltime()) == 0
					&& obj.getValue().getHalftime().compareTo(price.getHalftime()) == 0
					&& obj.getValue().getOvertime().compareTo(price.getOvertime()) == 0
					&& obj.getValue().getId() != price.getId()) {
				
				DB.ERROR_MESSAGE = "Bu fiyat bilgisi kaydı zaten mevcut.";
				return false;
			}
		}
		
		return true;
	}
```