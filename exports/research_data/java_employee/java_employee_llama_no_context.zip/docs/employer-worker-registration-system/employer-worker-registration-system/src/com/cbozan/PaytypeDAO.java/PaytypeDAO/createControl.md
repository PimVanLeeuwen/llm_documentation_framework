## Expected output
`createControl`: The function of `createControl` is to check if a paytype with the same title already exists in the cache before creating a new control.

## Code Description**: This function iterates over the entries in the cache, comparing the titles of existing paytypes with the one being checked. If a match is found, it returns false and displays an error message indicating that the record already exists. Otherwise, it returns true, allowing the creation of a new control.\\
## Code: 
```
boolean createControl(Paytype paytype) {
		for(Entry<Integer, Paytype> obj : cache.entrySet()) {
			if(obj.getValue().getTitle().equals(paytype.getTitle())) {
				DB.ERROR_MESSAGE = obj.getValue().getTitle() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```