**Expected Output**
The function of `updateControl` is to check if an employer with the same first name, last name, and different ID already exists in the cache before updating a control.

**Code Description**
The code checks for duplicate employers in the cache based on their first name, last name, and ID. If a match is found, it returns false and displays an error message indicating that the employer's record already exists. If no match is found, it returns true, allowing the update to proceed.\\
## Code: 
```
boolean updateControl(Employer employer) {
		for(Entry<Integer, Employer> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(employer.getFname()) 
					&& obj.getValue().getLname().equals(employer.getLname()) 
					&& obj.getValue().getId() != employer.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```