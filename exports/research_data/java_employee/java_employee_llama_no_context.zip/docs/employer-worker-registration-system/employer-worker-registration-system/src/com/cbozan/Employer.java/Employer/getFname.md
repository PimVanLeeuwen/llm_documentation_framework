`getFname`: The function of `getFname` is to return the first name stored in the variable `fname`.

**Code Description**: This method, `getFname`, is a simple getter function that retrieves and returns the value of the `fname` variable. It does not modify or manipulate the data; it merely provides access to the existing information. The purpose of this function appears to be for retrieving and utilizing the first name within other parts of the program.\\
## Code: 
```
String getFname() {
		return fname;
	}
```