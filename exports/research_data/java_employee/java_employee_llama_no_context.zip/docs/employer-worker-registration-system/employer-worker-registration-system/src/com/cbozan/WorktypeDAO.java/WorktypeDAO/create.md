`create`: The function of `create` is to create a new worktype in the database.

**Code Description**: This code snippet appears to be part of a larger system that interacts with a database. It contains a method called `create` which takes an object of type `Worktype` as input and attempts to insert it into the database. The method also retrieves the newly inserted record from the database, builds a new `Worktype` object using the retrieved data, and caches it in memory. If any errors occur during this process, they are caught and handled by displaying error messages.\\
## Code: 
```
boolean create(Worktype worktype) {
		
		if(createControl(worktype) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO worktype (title,no) VALUES (?,?);";
		String query2 = "SELECT * FROM worktype ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1, worktype.getTitle());
			pst.setInt(2, worktype.getNo());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					WorktypeBuilder builder = new WorktypeBuilder();
					builder = new WorktypeBuilder();
					builder.setId(rs.getInt("id"));
					builder.setTitle(rs.getString("title"));
					builder.setNo(rs.getInt("no"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Worktype wt = builder.build();
						cache.put(wt.getId(), wt);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id") + ", Title : " + rs.getString("title"));
					}
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```