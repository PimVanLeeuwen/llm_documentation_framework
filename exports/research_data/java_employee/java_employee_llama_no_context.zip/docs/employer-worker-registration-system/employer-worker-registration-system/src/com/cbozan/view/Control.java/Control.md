**The function of Control is to validate various types of input data, such as phone numbers, IBANs (International Bank Account Numbers), and decimal values.**

**Code Description:**
The provided code defines a class named `Control` that contains several static methods for validating different types of input data. These methods use regular expressions to check if the input matches certain patterns.

*   The first method, `phoneNumberControl(String phoneNumber)`, validates Turkish phone numbers by checking if they match the pattern `^((((\\+90)?|(0)?)\\d{10})|())$`. This pattern allows for optional country code "+90" or "0", followed by 10 digits.
*   The second method, `phoneNumberControl(String phoneNumber, String regex)`, takes a regular expression as an argument and uses it to validate the phone number. This provides flexibility in defining custom patterns for different types of phone numbers.
*   The third method, `phoneNumberControl(String phoneNumber, Pattern pattern)`, is similar to the previous one but takes a compiled `Pattern` object instead of a string regex.
*   The next two methods, `ibanControl(String iban)` and `ibanControl(String iban, String regex)`, validate Turkish IBANs using the same approach as the phone number validation. They check if the input matches the pattern `^((TR\\d{24})|())$` or a custom regular expression.
*   The last two methods, `decimalControl(String ...args)` and `decimalControl(Pattern pattern, String ...args)`, validate decimal values by checking if they match the pattern `^((\\d+(\\.\\d{1,2})?)|())$`. These methods can take multiple arguments to validate multiple decimal values at once.

The code uses regular expressions to define patterns for different types of input data. The `Pattern` class is used to compile these patterns into objects that can be reused throughout the validation process. This approach provides a flexible and efficient way to validate various types of input data in Java applications.\\
## Code: 
```
class Control {

	public static boolean phoneNumberControl(String phoneNumber) {
		return Pattern.compile("^((((\\+90)?|(0)?)\\d{10})|())$").matcher(phoneNumber.replaceAll("\\s+", "")).find();
	}
	public static boolean phoneNumberControl(String phoneNumber, String regex) {
		return Pattern.compile(regex).matcher(phoneNumber.replaceAll("\\s+", "")).find();
	}
	public static boolean phoneNumberControl(String phoneNumber, Pattern pattern) {
		return pattern.matcher(phoneNumber).find();
	}
	
	
	public static boolean ibanControl(String iban) {
		return Pattern.compile("^((TR\\d{24})|())$", Pattern.CASE_INSENSITIVE).matcher(iban).find();
	}
	public static boolean ibanControl(String iban, String regex) {
		return Pattern.compile(regex).matcher(iban).find();
	}
	public static boolean ibanControl(String iban, Pattern pattern) {
		return pattern.matcher(iban).find();
	}
	
	
	public static boolean decimalControl(String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= Pattern.compile("^((\\d+(\\.\\d{1,2})?)|())$").matcher(arg).find();
		}
		return rValue;
	}
	public static boolean decimalControl(Pattern pattern, String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= pattern.matcher(arg).find();
		}
		return rValue;
	}
	
}
```