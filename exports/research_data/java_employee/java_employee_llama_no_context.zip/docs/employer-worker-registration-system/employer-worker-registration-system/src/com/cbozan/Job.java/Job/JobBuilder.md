**JobBuilder**: The function of `JobBuilder` is to create a builder object that can be used to construct and build a `Job` entity.

**Code Description**: JobBuilder is a class designed to facilitate the creation of a Job entity. It provides a set of methods (e.g., setId, setEmployer_id, setTitle) that allow for the step-by-step construction of a Job object. The builder pattern is used here to separate the construction process from the actual representation of the Job entity, making it easier to create and manage Jobs in a more controlled and flexible way.\\
## Code: 
```
class JobBuilder {
		
		private int id;
		private int employer_id;
		private int price_id;
		private String title;
		private String description;
		private Timestamp date;
		private Employer employer;
		private Price price;
		
		public JobBuilder() {}
		public JobBuilder(int id, int employer_id, int price_id, String title, String description, Timestamp date) {
			this.id = id;
			this.employer_id = employer_id;
			this.price_id = price_id;
			this.title = title;
			this.description = description;
			this.date = date;
		}
		
		public JobBuilder(int id, Employer employer, Price price, String title, String description, Timestamp date) {
			this(id, 0, 0, title, description, date);
			this.employer = employer;
			this.price = price;
		}
		
		public JobBuilder setId(int id) {
			this.id = id;
			return this;
		}
		
		public JobBuilder setEmployer_id(int employer_id) {
			this.employer_id = employer_id;
			return this;
		}
		
		public JobBuilder setPrice_id(int price_id) {
			this.price_id = price_id;
			return this;
		}
		
		public JobBuilder setTitle(String title) {
			this.title = title;
			return this;
		}
		
		public JobBuilder setDescription(String description) {
			this.description = description;
			return this;
		}
		
		public JobBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public JobBuilder setEmployer(Employer employer) {
			this.employer = employer;
			return this;
		}
		
		public JobBuilder setPrice(Price price) {
			this.price = price;
			return this;
		}
		
		public Job build() throws EntityException{
			if(this.employer == null || this.price == null)
				return new Job(this);
			return new Job(this.id, this.employer, this.price, this.title, this.description, this.date);
		}
		
	}
```