## Expected Output
`setFname`: The function of `setFname` is to set the first name of an entity.

**Code Description**: This method, `setFname`, is a part of a class that manages entities. It takes a string parameter `fname` and checks if it meets certain conditions before updating the entity's first name. If the length of `fname` is 0 or exceeds a predefined maximum length (`DBConst.FNAME_LENGTH`), it throws an `EntityException`. Otherwise, it assigns the provided string to the entity's first name field (`this.fname`).\\
## Code: 
```
void setFname(String fname) throws EntityException {
		if(fname.length() == 0 || fname.length() > DBConst.FNAME_LENGTH)
			throw new EntityException("Worker name empty or too long");
		this.fname = fname;
	}
```