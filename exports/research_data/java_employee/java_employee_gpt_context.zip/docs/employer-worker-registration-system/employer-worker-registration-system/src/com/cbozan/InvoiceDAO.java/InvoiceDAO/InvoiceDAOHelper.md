`InvoiceDAOHelper`: The function of `InvoiceDAOHelper` is to provide a single, shared instance of the `InvoiceDAO` class.

**Code Description**: The `InvoiceDAOHelper` class contains a private static final field named `instance`, which holds a single instance of the `InvoiceDAO` class. This ensures that there is only one instance of `InvoiceDAO` throughout the application, following the Singleton design pattern.\\
## Code: 
```
class InvoiceDAOHelper {
		private static final InvoiceDAO instance = new InvoiceDAO();
	}
```