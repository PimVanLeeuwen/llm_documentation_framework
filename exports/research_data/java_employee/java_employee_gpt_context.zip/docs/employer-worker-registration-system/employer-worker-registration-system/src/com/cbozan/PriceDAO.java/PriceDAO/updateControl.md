`updateControl`: The function of `updateControl` is to check if a given `Price` object already exists in the cache with the same `fulltime`, `halftime`, and `overtime` values but with a different `id`. If such a `Price` object exists, it returns `false` and sets an error message; otherwise, it returns `true`.

**Parameters**:\
`Price price`: The `Price` object that needs to be checked against the existing entries in the cache.

**Code Description**: The `updateControl` method iterates through the `cache`, which is a collection of `Price` objects mapped by their IDs. For each entry in the cache, it compares the `fulltime`, `halftime`, and `overtime` values of the current `Price` object with those of the `price` parameter. If all these values match but the IDs are different, it sets an error message indicating that the price information already exists and returns `false`. If no such match is found, it returns `true`, indicating that the `price` object can be updated or added without duplication.\\
## Code: 
```
boolean updateControl(Price price) {
		for(Entry<Integer, Price> obj : cache.entrySet()) {
			if(obj.getValue().getFulltime().compareTo(price.getFulltime()) == 0
					&& obj.getValue().getHalftime().compareTo(price.getHalftime()) == 0
					&& obj.getValue().getOvertime().compareTo(price.getOvertime()) == 0
					&& obj.getValue().getId() != price.getId()) {
				
				DB.ERROR_MESSAGE = "Bu fiyat bilgisi kaydı zaten mevcut.";
				return false;
			}
		}
		
		return true;
	}
```