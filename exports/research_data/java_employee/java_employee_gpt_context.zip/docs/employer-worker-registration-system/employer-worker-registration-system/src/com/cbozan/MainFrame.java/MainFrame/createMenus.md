`createMenus`: The function of `createMenus` is to initialize and set up the menu bar for the application's main frame, including various menus and menu items with associated action commands and listeners.

**Code Description**: 
- The method starts by creating a new `JMenuBar` instance and assigning it to the `menuBar` variable.
- It then creates three main menus: `newRecordMenu`, `addMenu`, and `displayMenu`, each represented by a `JMenu` object.
- For the `newRecordMenu`, it adds four `JMenuItem` objects: `newJobItem`, `newWorkerItem`, `newEmployerItem`, and `newPriceItem`. Each menu item is given a label, an action command, and an action listener.
- For the `addMenu`, it adds three `JMenuItem` objects: `newWorkerPaymentItem`, `newWorkItem`, and `newEmployerPaymentItem`, each with a label, an action command, and an action listener.
- For the `displayMenu`, it adds three `JMenuItem` objects: `displayJobItem`, `displayWorkerItem`, and `displayEmployerItem`, each with a label, an action command, and an action listener.
- The method then adds the `newRecordMenu`, `addMenu`, and `displayMenu` to the `menuBar`.
- Finally, it sets the `menuBar` as the menu bar for the main frame using `this.setJMenuBar(menuBar)`.\\
## Code: 
```
void createMenus() {
		
		menuBar = new JMenuBar();
		
		newRecordMenu = new JMenu("Record");
		addMenu = new JMenu("Add");
		displayMenu = new JMenu("Display");
		
		
		newJobItem = new JMenuItem("New Job");
		newJobItem.setActionCommand("0");
		newJobItem.addActionListener(this);
		
		newWorkerItem = new JMenuItem("New worker");
		newWorkerItem.setActionCommand("1");
		newWorkerItem.addActionListener(this);
		
		newEmployerItem = new JMenuItem("New employer");
		newEmployerItem.setActionCommand("2");
		newEmployerItem.addActionListener(this);
		
		newPriceItem = new JMenuItem("New price");
		newPriceItem.setActionCommand("3");
		newPriceItem.addActionListener(this);
		
		newRecordMenu.add(newJobItem);
		newRecordMenu.add(newWorkerItem);
		newRecordMenu.add(newEmployerItem);
		newRecordMenu.add(newPriceItem);
		
		
		newWorkerPaymentItem = new JMenuItem("Worker payment");
		newWorkerPaymentItem.setActionCommand("4");
		newWorkerPaymentItem.addActionListener(this);
		
		newWorkItem = new JMenuItem("Work");
		newWorkItem.setActionCommand("5");
		newWorkItem.addActionListener(this);
		
		newEmployerPaymentItem = new JMenuItem("Job payment");
		newEmployerPaymentItem.setActionCommand("6");
		newEmployerPaymentItem.addActionListener(this);
		
		addMenu.add(newWorkerPaymentItem);
		addMenu.add(newWorkItem);
		addMenu.add(newEmployerPaymentItem);
		
		
		displayJobItem = new JMenuItem("Display job");
		displayJobItem.setActionCommand("7");
		displayJobItem.addActionListener(this);
		
		displayWorkerItem = new JMenuItem("Display worker");
		displayWorkerItem.setActionCommand("8");
		displayWorkerItem.addActionListener(this);
		
		displayEmployerItem = new JMenuItem("Display employer");
		displayEmployerItem.setActionCommand("9");
		displayEmployerItem.addActionListener(this);
		
		
		displayMenu.add(displayJobItem);
		displayMenu.add(displayWorkerItem);
		displayMenu.add(displayEmployerItem);
		
		menuBar.add(newRecordMenu);
		menuBar.add(addMenu);
		menuBar.add(displayMenu);
		
		
		this.setJMenuBar(menuBar);
		
		
	}
```