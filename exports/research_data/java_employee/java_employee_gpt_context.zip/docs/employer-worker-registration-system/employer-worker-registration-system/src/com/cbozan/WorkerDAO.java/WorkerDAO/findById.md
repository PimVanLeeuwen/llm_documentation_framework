`findById`: The function of `findById` is to retrieve a `Worker` object by its unique identifier (ID) from the cache or database.

**Parameters**:\
`int id`: The unique identifier of the `Worker` to be retrieved.

**Code Description**: The `findById` method first checks if the cache is being used. If the cache is not being used (`usingCache == false`), it calls the `list` method to populate the cache with `Worker` objects from the database. Then, it checks if the cache contains a `Worker` object with the specified ID. If the cache contains the `Worker` object, it returns the object; otherwise, it returns `null`.\\
## Code: 
```
Worker findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```