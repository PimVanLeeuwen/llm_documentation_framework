`setLname`: The function of `setLname` is to set the last name of an employer while ensuring it meets specific length constraints.

**Parameters**:\
`String lname`: The last name to be set for the employer. It must not be empty and must not exceed the maximum length defined by `DBConst.LNAME_LENGTH`.

**Code Description**: The `setLname` method first checks if the provided `lname` is either empty or exceeds the maximum allowed length specified by `DBConst.LNAME_LENGTH`. If either condition is true, it throws an `EntityException` with the message "Employer last name empty or too long". If the `lname` passes these checks, it assigns the value to the `lname` attribute of the `Employer` object.\\
## Code: 
```
void setLname(String lname) throws EntityException {
		if(lname.length() == 0 || lname.length() > DBConst.LNAME_LENGTH)
			throw new EntityException("Employer last name empty or too long");
		this.lname = lname;
	}
```