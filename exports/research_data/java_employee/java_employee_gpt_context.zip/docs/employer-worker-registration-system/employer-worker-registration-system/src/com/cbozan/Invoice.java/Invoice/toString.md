`toString`: The function of `toString` is to provide a string representation of the `Invoice` object.

**Code Description**: This `toString` method returns a string that includes the `id`, `job`, `amount`, and `date` fields of the `Invoice` object, formatted in a readable way. The returned string follows the format: "Invoice [id=ID_VALUE, job=JOB_VALUE, amount=AMOUNT_VALUE, date=DATE_VALUE]", where `ID_VALUE`, `JOB_VALUE`, `AMOUNT_VALUE`, and `DATE_VALUE` are the actual values of the respective fields in the `Invoice` object. This method is useful for debugging and logging purposes, allowing developers to easily view the contents of an `Invoice` object.\\
## Code: 
```
String toString() {
		return "Invoice [id=" + id + ", job=" + job + ", amount=" + amount + ", date=" + date + "]";
	}
```