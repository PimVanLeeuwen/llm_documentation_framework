`Invoice`: The function of `Invoice` is to represent an invoice in the employer-worker registration system, encapsulating details such as the invoice ID, associated job, amount, and date.

**Code Description**: 
The `Invoice` class implements the `Serializable` interface, allowing invoice objects to be serialized. It contains fields for `id`, `job`, `amount`, and `date`, with corresponding getter and setter methods. The setters for `id`, `job`, and `amount` include validation to ensure the values are valid, throwing an `EntityException` if they are not.

The class provides a private constructor for initializing an empty invoice and another private constructor for initializing an invoice with specific values. The `InvoiceBuilder` nested class follows the builder pattern, allowing for flexible and readable construction of `Invoice` objects. It includes methods to set each field and a `build` method to create the `Invoice` object, either directly or by using the `JobDAO` to find a job by its ID.

The `EmptyInstanceSingleton` nested class ensures a single, empty instance of `Invoice` is created and accessed via the `getEmptyInstance` method.

The `toString` method provides a string representation of the invoice, while the `hashCode` and `equals` methods ensure proper behavior in hash-based collections and equality checks.\\
## Code: 
```
class Invoice implements Serializable {
	
	private static final long serialVersionUID = -7032103783419199929L;
	
	private int id;
	private Job job;
	private BigDecimal amount;
	private Timestamp date;
	
	private Invoice() {
		this.id = 0;
		this.job = null;
		this.amount = null;
		this.date = null;
	}
	
	private Invoice(Invoice.InvoiceBuilder builder) throws EntityException {
		this(builder.id,
				JobDAO.getInstance().findById(builder.job_id),
				builder.amount,
				builder.date);
	}
	
	private Invoice(int id, Job job, BigDecimal amount, Timestamp date) throws EntityException {
		setId(id);
		setJob(job);
		setAmount(amount);
		setDate(date);
	}
	
	
	public static class InvoiceBuilder{
		
		private int id;
		private int job_id;
		private Job job;
		private BigDecimal amount;
		private Timestamp date;
		
		public InvoiceBuilder() {}
		public InvoiceBuilder(int id, int job_id, BigDecimal amount, Timestamp date) {
			this.id = id;
			this.job_id = job_id;
			this.amount = amount;
			this.date = date;
		}
		
		public InvoiceBuilder(int id, Job job, BigDecimal amount, Timestamp date) {
			this(id, 0, amount, date);
			this.job = job;
		}
		
		public InvoiceBuilder setId(int id) {
			this.id = id;
			return this;
		}
		
		public InvoiceBuilder setJob_id(int job_id) {
			this.job_id = job_id;
			return this;
		}
		
		public InvoiceBuilder setJob(Job job) {
			this.job = job;
			return this;
		}
		
		public InvoiceBuilder setAmount(BigDecimal amount) {
			this.amount = amount;
			return this;
		}
		
		public InvoiceBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Invoice build() throws EntityException {
			if(job == null)
				return new Invoice(this);
			return new Invoice(id, job, amount, date);
		}
		
	}

	private static class EmptyInstanceSingleton{
		private static final Invoice instance = new Invoice(); 
	}
	
	public static final Invoice getEmptyInstance() {
		return EmptyInstanceSingleton.instance;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) throws EntityException {
		if(id <= 0)
			throw new EntityException("Invoice ID negative or zero");
		this.id = id;
	}

	public Job getJob() {
		return job;
	}

	public void setJob(Job job) throws EntityException {
		if(job == null)
			throw new EntityException("Job in Invoice is null");
		this.job = job;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) throws EntityException {
		if(amount.compareTo(new BigDecimal("0.00")) <= 0)
			throw new EntityException("Invoice amount negative or zero");
		this.amount = amount;
	}

	public Timestamp getDate() {
		return date;
	}

	public void setDate(Timestamp date) {
		this.date = date;
	}

	
	@Override
	public String toString() {
		return "Invoice [id=" + id + ", job=" + job + ", amount=" + amount + ", date=" + date + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(amount, date, id, job);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Invoice other = (Invoice) obj;
		return Objects.equals(amount, other.amount) && Objects.equals(date, other.date) && id == other.id
				&& Objects.equals(job, other.job);
	}
	
	
}
```