`setNo`: The function of `setNo` is to set the value of the `no` attribute for a `Worktype` object, ensuring that the value is positive.

**Parameters**:\
`int no`: The new value to be assigned to the `no` attribute. It must be a positive integer.

**Code Description**: The `setNo` method takes an integer parameter `no` and assigns it to the `no` attribute of the `Worktype` object. Before assignment, it checks if the provided value is less than or equal to zero. If the value is non-positive, it throws an `EntityException` with the message "Worktype no negative or zero". If the value is positive, it assigns the value to the `no` attribute.\\
## Code: 
```
void setNo(int no) throws EntityException {
		if(no <= 0)
			throw new EntityException("Worktype no negative or zero");
		this.no = no;
	}
```