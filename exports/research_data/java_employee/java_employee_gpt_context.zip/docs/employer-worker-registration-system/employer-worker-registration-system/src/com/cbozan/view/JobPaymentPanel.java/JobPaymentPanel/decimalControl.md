`decimalControl`: The function of `decimalControl` is to validate whether given string arguments represent valid decimal numbers with up to two decimal places.

**Code Description**: The `decimalControl` method takes a variable number of string arguments and checks if each string matches the pattern of a decimal number with up to two decimal places (e.g., "123", "123.4", "123.45"). It uses a regular expression pattern `^\\d+(\\.\\d{1,2})?$` to perform this validation. The method iterates through each argument, removes any whitespace, and checks if it matches the pattern. If all arguments match the pattern, the method returns `true`; otherwise, it returns `false`.\\
## Code: 
```
boolean decimalControl(String ...args) {
		Pattern pattern = Pattern.compile("^\\d+(\\.\\d{1,2})?$"); // decimal pattern xxx.xx
		boolean result = true;
		
		for(String arg : args)
			result = result && pattern.matcher(arg.replaceAll("\\s+", "")).find();
		
		return result;
	}
```