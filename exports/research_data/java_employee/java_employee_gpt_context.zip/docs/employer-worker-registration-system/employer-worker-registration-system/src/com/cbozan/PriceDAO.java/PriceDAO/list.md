`list`: The function of `list` is to retrieve a list of `Price` objects from the database, either from a cache if available or directly from the database if the cache is empty or not in use.

**Code Description**: 
The `list` method in the `PriceDAO` class retrieves a list of `Price` objects. It first checks if the cache is being used and contains data. If so, it populates the list from the cache. If the cache is empty or not in use, it clears the cache and queries the database for all records in the `price` table. For each record, it builds a `Price` object using the `PriceBuilder` class, adds it to the list, and updates the cache. If an `EntityException` occurs during the building of a `Price` object, it handles the exception by calling `showEntityException`. If an `SQLException` occurs during the database operations, it handles the exception by calling `showSQLException`. Finally, it returns the list of `Price` objects.\\
## Code: 
```
List<Price> list(){
		
		List<Price> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Price> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM price;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			PriceBuilder builder;
			Price price;
			
			while(rs.next()) {
				
				builder = new PriceBuilder();
				builder.setId(rs.getInt("id"));
				builder.setFulltime(rs.getBigDecimal("fulltime"));
				builder.setHalftime(rs.getBigDecimal("halftime"));
				builder.setOvertime(rs.getBigDecimal("overtime"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					price = builder.build();
					list.add(price);
					cache.put(price.getId(), price);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
		
	}
```