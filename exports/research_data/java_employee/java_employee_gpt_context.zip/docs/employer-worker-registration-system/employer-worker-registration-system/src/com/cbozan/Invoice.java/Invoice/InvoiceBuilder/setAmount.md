`setAmount`: The function of `setAmount` is to set the amount for the invoice being built. 
**Parameters**:\
`BigDecimal amount`: The monetary value to be set for the invoice. 

**Code Description**: This method sets the `amount` field of the `InvoiceBuilder` object to the provided `BigDecimal` value and returns the current instance of `InvoiceBuilder` to allow for method chaining.\\
## Code: 
```
InvoiceBuilder setAmount(BigDecimal amount) {
			this.amount = amount;
			return this;
		}
```