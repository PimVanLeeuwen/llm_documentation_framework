`toString`: The function of `toString` is to provide a string representation of the `Worker` object.

**Code Description**: This `toString` method returns a string that concatenates a space, the first name, and the last name of the `Worker` object. It calls the `getFname` method to retrieve the first name and the `getLname` method to retrieve the last name.\\
## Code: 
```
String toString() {
		return " " + getFname() + " " + getLname();
	}
```