`showEntityException`: The function of `showEntityException` is to display an error message dialog when an `EntityException` occurs.

**Parameters**:\
`EntityException e`: The exception object that contains details about the error.\
`String msg`: A custom message to be included in the error dialog.

**Code Description**: This method constructs an error message by combining the provided custom message (`msg`) with details from the `EntityException` object (`e`). The constructed message includes the custom message, the exception's message, its localized message, and its cause. This complete error message is then displayed in a dialog box using `JOptionPane.showMessageDialog`.\\
## Code: 
```
void showEntityException(EntityException e, String msg) {
		String message = msg + " not added" + 
				"\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + e.getCause();
			JOptionPane.showMessageDialog(null, message);
	}
```