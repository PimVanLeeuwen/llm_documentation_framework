`getLastAdded`: The function of `getLastAdded` is to retrieve the most recently added workgroup from the database.

**Code Description**: This method establishes a connection to the database and executes a SQL query to select the most recent entry from the `workgroup` table, ordered by the `id` in descending order and limited to one result. It then constructs a `Workgroup` object using the retrieved data. If an `EntityException` occurs during the building process, it prints the error message. If a `SQLException` occurs during the database operations, it prints the SQL error message. Finally, it returns the constructed `Workgroup` object or `null` if no workgroup was found or an error occurred.\\
## Code: 
```
Workgroup getLastAdded() {
		
		Workgroup workgroup = null;
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM workgroup ORDER BY id DESC LIMIT 1";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			WorkgroupBuilder builder; 
			
			while(rs.next()) {
				
				builder = new WorkgroupBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setWorktype_id(rs.getInt("worktype_id"));
				builder.setWorkCount(rs.getInt("workcount"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					workgroup = builder.build();
				} catch (EntityException e) {
					System.err.println(e.getMessage());
				}
				
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return workgroup;
	}
```