`actionPerformed`: The function of `actionPerformed` is to handle the payment process when the pay button is clicked, including validation, confirmation, and saving the payment details.

**Parameters**:\
`ActionEvent e`: The event that triggers this method, typically a button click.

**Code Description**: This method first checks if the source of the event is the `payButton`. If so, it retrieves the selected worker, job, payment type, and the entered amount. It validates the amount to ensure it is a decimal number with up to two decimal places and checks that none of the selections are null. If any validation fails, it shows an error message dialog. If validation passes, it displays a confirmation dialog with the payment details. If the user confirms the payment, it builds a `Payment` object using the provided details and attempts to save it to the database. If the payment is successfully saved, it shows a success message and notifies all observers. If the save fails, it shows an error message indicating a database error.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		if(e.getSource() == payButton) {
			
			Worker worker;
			Job job;
			Paytype paytype;
			String amount;
			
			worker = selectedWorker;
			job = selectedJob;
			paytype = (Paytype) paytypeComboBox.getSelectedItem();
			amount = amountTextField.getText().replaceAll("\\s+", "");

			if(!decimalControl(amount) || worker == null || job == null || paytype == null) {
				
				String message;
				message = "Please enter selection parts or format correctly (max 2 floating point)";
				JOptionPane.showMessageDialog(this, message, "ERROR", JOptionPane.ERROR_MESSAGE);
				
			} else {
				
				JTextArea workerTextArea, jobTextArea, paytypeTextArea, amountTextArea;
				
				workerTextArea = new JTextArea(worker.toString());
				workerTextArea.setEditable(false);
				
				jobTextArea = new JTextArea(job.toString());
				jobTextArea.setEditable(false);
				
				paytypeTextArea = new JTextArea(paytype.toString());
				paytypeTextArea.setEditable(false);
				
				amountTextArea = new JTextArea(amount + " ₺");
				amountTextArea.setEditable(false);
				
				Object[] pane = {
						new JLabel("Worker"),
						workerTextArea,
						new JLabel("Job"),
						jobTextArea,
						new JLabel("Payment method"),
						paytypeTextArea,
						new JLabel("Amount of payment"),
						amountTextArea
				};
		
				int result = JOptionPane.showOptionDialog(this, pane, "Confirmation", 1, 1, 
						new ImageIcon("src\\icon\\accounting_icon_1_32.png"), new Object[] {"SAVE", "CANCEL"}, "CANCEL");
				
				
				// System.out.println(result);
				// 0 -> SAVE
				// 1 -> CANCEL
				
				if(result == 0) {
					
					Payment.PaymentBuilder builder = new Payment.PaymentBuilder();
					builder.setId(Integer.MAX_VALUE);
					builder.setWorker(worker);
					builder.setJob(job);
					builder.setPaytype(paytype);
					builder.setAmount(new BigDecimal(amount));
					
					Payment payment = null;
					try {
						payment = builder.build();
					} catch (EntityException e1) {
						System.out.println(e1.getMessage());
					}
					
					if(PaymentDAO.getInstance().create(payment)) { 
						JOptionPane.showMessageDialog(this, "Registraion successful");
						notifyAllObservers();
					} else {
						JOptionPane.showMessageDialog(this, "Not saved", "Database error", JOptionPane.ERROR_MESSAGE);
					}
				}
				
			}
			
			
		}
		
	}
```