`filterJob`: The function of `filterJob` is to filter a list of `Work` objects based on a selected job criterion.

**Parameters**:\
`List<Work> workList`: A list of `Work` objects that need to be filtered based on the selected job.

**Code Description**: The `filterJob` method iterates through the provided list of `Work` objects (`workList`). If the `selectedWorkTableJob` is not set (i.e., it is `null`), the method returns immediately without making any changes. Otherwise, it iterates through the `workList` and removes any `Work` object whose associated job's ID does not match the ID of the `selectedWorkTableJob`. This effectively filters the list to only include `Work` objects that are associated with the selected job.\\
## Code: 
```
void filterJob(List<Work> workList) {
		if(selectedWorkTableJob == null) {
			return;
		}
		
		Iterator<Work> work = workList.iterator();
		Work workItem;
		while(work.hasNext()) {
			workItem = work.next();
			if(workItem.getJob().getId() != selectedWorkTableJob.getId()) {
				work.remove();
			}
		}
		
	}
```