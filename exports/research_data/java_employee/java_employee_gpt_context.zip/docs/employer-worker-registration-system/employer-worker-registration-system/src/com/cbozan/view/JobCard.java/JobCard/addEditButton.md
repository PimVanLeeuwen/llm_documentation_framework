`addEditButton`: The function of `addEditButton` is to create and return a customized JButton that toggles the editability of a given text field and changes its icon accordingly.

**Parameters**:\
`JTextComponent textField`: The text field whose editability is to be toggled by the button. \
`Component nextFocus`: The component to be focused on when the text field is set to non-editable.

**Code Description**: This method creates a JButton with an initial icon of a pencil (indicating edit mode). The button is customized to have no content area, no focusable property, and no border painting. It is positioned next to the provided text field. A mouse listener is added to the button to handle click events. When clicked, if the text field is editable, it becomes non-editable, and the button icon changes back to the pencil icon. If the text field is not editable and its text is not the initial text, it becomes editable, and the button icon changes to a checkmark. If the `nextFocus` component is provided, it gains focus when the text field becomes non-editable; otherwise, the current window gains focus. The method returns the customized button.\\
## Code: 
```
JButton addEditButton(JTextComponent textField, Component nextFocus) {
		JButton editButton = new JButton(new ImageIcon("src\\icon\\text_edit.png"));
		editButton.setContentAreaFilled(false);
		editButton.setFocusable(false);
		editButton.setBorderPainted(false);
		editButton.setBounds(textField.getX() + textField.getWidth() + BS, textField.getY(), BW, rowHeight);
		
		editButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(textField.isEditable()) {
					editButton.setIcon(new ImageIcon("src\\icon\\text_edit.png"));
					textField.setEditable(false);
					if(nextFocus != null) {
						nextFocus.requestFocus();
					} else {
						requestFocusInWindow();
					}
					
				} else if(!textField.getText().equals(INIT_TEXT)) {
						textField.setEditable(true);
						editButton.setIcon(new ImageIcon("src\\icon\\check.png"));
				}
				super.mouseClicked(e);
			}
		});
		
		return editButton;
	}
```