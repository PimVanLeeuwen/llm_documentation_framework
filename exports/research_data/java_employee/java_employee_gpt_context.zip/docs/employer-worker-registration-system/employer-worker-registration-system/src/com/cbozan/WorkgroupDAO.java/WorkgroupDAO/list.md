`list`: The function of `list` is to retrieve and return a list of all `Workgroup` objects from the database.

**Code Description**: 
The `list` method in the `WorkgroupDAO` class performs the following steps:
1. Initializes an empty list to store `Workgroup` objects.
2. Checks if the cache is not empty and caching is enabled (`usingCache`). If so, it adds all cached `Workgroup` objects to the list and returns it.
3. Clears the cache if it is not using the cache.
4. Establishes a database connection using the `DB.getConnection` method.
5. Executes a SQL query to select all records from the `workgroup` table.
6. Iterates through the result set, creating `Workgroup` objects using the `WorkgroupBuilder` class.
7. Sets the properties of each `Workgroup` object from the result set data.
8. Adds each successfully built `Workgroup` object to the list and the cache.
9. Handles any `EntityException` by displaying an error message with the `showEntityException` method.
10. Handles any `SQLException` by displaying an error message with the `showSQLException` method.
11. Returns the list of `Workgroup` objects.\\
## Code: 
```
List<Workgroup> list(){
		
		List<Workgroup> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Workgroup> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM workgroup;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorkgroupBuilder builder;
			Workgroup workgroup;
			
			while(rs.next()) {
				
				builder = new WorkgroupBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setWorktype_id(rs.getInt("worktype_id"));
				builder.setWorkCount(rs.getInt("workcount"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					workgroup = builder.build();
					list.add(workgroup);
					cache.put(workgroup.getId(), workgroup);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
	}
```