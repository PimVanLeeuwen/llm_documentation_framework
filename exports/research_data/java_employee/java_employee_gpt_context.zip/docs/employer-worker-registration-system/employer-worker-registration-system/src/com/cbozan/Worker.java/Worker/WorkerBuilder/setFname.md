`setFname`: The function of `setFname` is to set the first name of the worker in the `WorkerBuilder` object.
**Parameters**:\
`String fname`: The first name of the worker to be set in the `WorkerBuilder` object.

**Code Description**: The `setFname` method in the `WorkerBuilder` class assigns the provided `fname` parameter to the `fname` field of the `WorkerBuilder` instance. It then returns the current `WorkerBuilder` instance to allow for method chaining.\\
## Code: 
```
WorkerBuilder setFname(String fname) {
			this.fname = fname;
			return this;
		}
```