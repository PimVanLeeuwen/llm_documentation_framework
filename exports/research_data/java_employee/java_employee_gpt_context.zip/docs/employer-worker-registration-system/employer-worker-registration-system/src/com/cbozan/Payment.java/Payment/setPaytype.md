`setPaytype`: The function of `setPaytype` is to set the payment type for a payment instance, ensuring that the provided payment type is not null.

**Parameters**:\
`Paytype paytype`: The payment type to be set for the payment instance. This parameter must not be null.

**Code Description**: The `setPaytype` method assigns the provided `paytype` to the payment instance's `paytype` attribute. Before doing so, it checks if the `paytype` parameter is null. If it is null, the method throws an `EntityException` with the message "Paytype in Payment is null". This ensures that the payment type is always valid and not null when set.\\
## Code: 
```
void setPaytype(Paytype paytype) throws EntityException {
		if(paytype == null)
			throw new EntityException("Paytype in Payment is null");
		this.paytype = paytype;
	}
```