`equals`: The function of `equals` is to compare the current `Price` object with another object to determine if they are equal.

**Parameters**:\
`Object obj`: The object to be compared with the current `Price` object.

**Code Description**: The `equals` method first checks if the current object and the provided object reference the same instance. If they do, it returns `true`. If the provided object is `null` or not of the same class as the current object, it returns `false`. Otherwise, it casts the provided object to a `Price` object and compares their `date`, `fulltime`, `halftime`, `id`, and `overtime` fields for equality using the `Objects.equals` method for object fields and the `==` operator for the `id` field. If all these fields are equal, the method returns `true`; otherwise, it returns `false`.\\
## Code: 
```
boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Price other = (Price) obj;
		return Objects.equals(date, other.date) && Objects.equals(fulltime, other.fulltime)
				&& Objects.equals(halftime, other.halftime) && id == other.id
				&& Objects.equals(overtime, other.overtime);
	}
```