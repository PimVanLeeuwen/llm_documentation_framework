`setFulltime`: The function of `setFulltime` is to set the full-time price for a `PriceBuilder` object and return the updated `PriceBuilder` instance. \
**Parameters**:\
`BigDecimal fulltime`: The full-time price to be set for the `PriceBuilder` object. \

**Code Description**: This method assigns the provided `BigDecimal` value to the `fulltime` field of the `PriceBuilder` instance. After setting the value, it returns the current instance of `PriceBuilder` to allow for method chaining.\\
## Code: 
```
PriceBuilder setFulltime(BigDecimal fulltime) {
			this.fulltime = fulltime;
			return this;
		}
```