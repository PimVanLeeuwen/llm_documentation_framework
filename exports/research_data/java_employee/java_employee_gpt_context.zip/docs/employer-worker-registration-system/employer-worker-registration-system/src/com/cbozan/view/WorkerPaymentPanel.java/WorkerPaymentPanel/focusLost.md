`focusLost`: The function of `focusLost` is to handle the event when a text field loses focus and to validate the text input, changing the border color of the text field and the foreground color of a label based on the validation result.
**Parameters**:\
`FocusEvent e`: The event that indicates a component has lost the keyboard focus.

**Code Description**: When a text field loses focus, the `focusLost` method checks if the source of the event is a `JTextField`. It then validates the text in the text field using the `decimalControl` method. If the text is valid, the border color of the text field is set to green; otherwise, it is set to red. Additionally, if the text field is the `amountTextField`, the foreground color of the `amountLabel` is also updated to match the validation result.\\
## Code: 
```
void focusLost(FocusEvent e) {
		if(e.getSource() instanceof JTextField) {
			
			Color color = Color.white;
			
			if(decimalControl(((JTextField)e.getSource()).getText())) {
				color = new Color(0, 180, 0);
			} else {
				color = Color.red;
			}
			
			((JTextField)e.getSource()).setBorder(new LineBorder(color));
		
			if(((JTextField)e.getSource()) == amountTextField) {
				amountLabel.setForeground(color);
			}
		}
	}
```