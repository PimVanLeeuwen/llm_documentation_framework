`getAmount`: The function of `getAmount` is to retrieve the value of the `amount` field.

**Code Description**: This method returns the value of the `amount` field, which is of type `BigDecimal`. It does not take any parameters and simply provides access to the `amount` stored within the `Invoice` object.\\
## Code: 
```
BigDecimal getAmount() {
		return amount;
	}
```