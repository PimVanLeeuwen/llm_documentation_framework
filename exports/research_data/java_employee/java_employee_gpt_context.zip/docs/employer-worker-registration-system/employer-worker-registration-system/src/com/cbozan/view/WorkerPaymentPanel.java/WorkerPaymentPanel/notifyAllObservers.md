`notifyAllObservers`: The function of `notifyAllObservers` is to inform all registered observers about a change or event.

**Code Description**: The `notifyAllObservers` method iterates through a list of observers and calls the `update` method on each one. This ensures that all observers are notified and can react accordingly to the change or event that triggered the notification.\\
## Code: 
```
void notifyAllObservers() {
		for(Observer observer : observers) {
			observer.update();
		}
	}
```