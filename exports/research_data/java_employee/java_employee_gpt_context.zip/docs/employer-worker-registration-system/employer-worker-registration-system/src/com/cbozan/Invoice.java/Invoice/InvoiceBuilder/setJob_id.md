`setJob_id`: The function of `setJob_id` is to set the job ID for the invoice being built and return the `InvoiceBuilder` instance for method chaining. 
**Parameters**:\
`int job_id`: The job ID to be associated with the invoice.

**Code Description**: This method assigns the provided `job_id` to the `job_id` field of the `InvoiceBuilder` instance. It then returns the current `InvoiceBuilder` instance, allowing for method chaining in the builder pattern.\\
## Code: 
```
InvoiceBuilder setJob_id(int job_id) {
			this.job_id = job_id;
			return this;
		}
```