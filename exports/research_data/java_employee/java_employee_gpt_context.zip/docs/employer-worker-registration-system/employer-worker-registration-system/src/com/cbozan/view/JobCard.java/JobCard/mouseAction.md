`mouseAction`: The function of `mouseAction` is to handle mouse events and update the selected job's price based on the search result object.

**Parameters**:\
`MouseEvent e`: The mouse event that triggered this action. \
`Object searchResultObject`: The object resulting from a search operation, expected to be of type `Price`. \
`int chooseIndex`: An index indicating the chosen item from a list or search result.

**Code Description**: This method first checks if a job is selected (`selectedJob` is not null). If a job is selected, it attempts to set the job's price to the `searchResultObject` cast as a `Price`. If the `priceSearchBox` has a selected object, it updates the text of the `priceSearchBox` to the string representation of the selected object. If an `EntityException` occurs during this process, it is caught and its stack trace is printed. Finally, the method calls the superclass's `mouseAction` method with the same parameters.\\
## Code: 
```
void mouseAction(MouseEvent e, Object searchResultObject, int chooseIndex) {
				if(selectedJob != null) {
					try {
						selectedJob.setPrice((Price)searchResultObject);
						if(priceSearchBox.getSelectedObject() != null)
							priceSearchBox.setText(priceSearchBox.getSelectedObject().toString());
					} catch (EntityException e1) {
						e1.printStackTrace();
					}
				}
				super.mouseAction(e, searchResultObject, chooseIndex);
			}
```