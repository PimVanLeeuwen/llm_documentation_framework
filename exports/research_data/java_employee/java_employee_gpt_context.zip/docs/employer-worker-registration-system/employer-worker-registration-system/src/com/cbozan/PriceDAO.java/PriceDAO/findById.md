`findById`: The function of `findById` is to retrieve a `Price` object from the cache based on its unique identifier.

**Parameters**:\
`int id`: The unique identifier of the `Price` object to be retrieved.

**Code Description**: This method first checks if the cache is being used. If the cache is not being used (`usingCache == false`), it calls the `list()` method to populate the cache with `Price` objects from the database. Then, it checks if the cache contains an entry for the given `id`. If the cache contains the `id`, it returns the corresponding `Price` object. If the `id` is not found in the cache, it returns `null`.\\
## Code: 
```
Price findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```