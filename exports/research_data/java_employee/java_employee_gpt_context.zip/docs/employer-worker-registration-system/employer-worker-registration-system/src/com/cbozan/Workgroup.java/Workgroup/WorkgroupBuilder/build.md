`build`: The function of `build` is to create and return a `Workgroup` object based on the current state of the `WorkgroupBuilder`.

**Code Description**: The `build` method checks if the `job` or `worktype` fields are `null`. If either is `null`, it creates and returns a new `Workgroup` object using the current `WorkgroupBuilder` instance. If both fields are not `null`, it creates and returns a new `Workgroup` object using the specified `id`, `job`, `worktype`, `workCount`, `description`, and `date` fields. If any required fields are missing, an `EntityException` is thrown.\\
## Code: 
```
Workgroup build() throws EntityException {
			if(job == null || worktype == null)
				return new Workgroup(this);
			return new Workgroup(id, job, worktype, workCount, description, date);
		}
```