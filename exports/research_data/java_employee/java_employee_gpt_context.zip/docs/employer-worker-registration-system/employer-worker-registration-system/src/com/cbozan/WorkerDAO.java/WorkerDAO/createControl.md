`createControl`: The function of `createControl` is to check if a worker with the same first name and last name already exists in the cache.

**Parameters**:\
`Worker worker`: The worker object that needs to be checked for duplication in the cache.

**Code Description**: The `createControl` method iterates through the `cache` (a collection of worker entries) to determine if a worker with the same first name (`fname`) and last name (`lname`) as the provided `worker` object already exists. If a match is found, it sets an error message in the `DB.ERROR_MESSAGE` indicating that the worker is already registered and returns `false`. If no match is found, it returns `true`, indicating that the worker can be created.\\
## Code: 
```
boolean createControl(Worker worker) {
		for(Entry<Integer, Worker> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(worker.getFname()) && obj.getValue().getLname().equals(worker.getLname())) {
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```