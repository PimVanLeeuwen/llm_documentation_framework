`updateControl`: The function of `updateControl` is to check if a given `Paytype` object can be updated without causing a duplicate entry in the cache.

**Parameters**:\
`Paytype paytype`: The `Paytype` object that needs to be checked for potential duplication in the cache.

**Code Description**: The `updateControl` method iterates through the entries in the `cache` map, which stores `Paytype` objects with their corresponding IDs. For each entry, it compares the title of the `Paytype` object in the cache with the title of the provided `paytype` object. If a match is found and the IDs are different, it means there is already an existing `Paytype` with the same title but a different ID. In this case, it sets an error message in the `DB` class indicating that the title already exists and returns `false`. If no such duplicate is found, the method returns `true`, indicating that the `paytype` can be safely updated.\\
## Code: 
```
boolean updateControl(Paytype paytype) {
		for(Entry<Integer, Paytype> obj : cache.entrySet()) {
			if(obj.getValue().getTitle().equals(paytype.getTitle()) && obj.getValue().getId() != paytype.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getTitle() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```