`PriceBuilder`: The function of `PriceBuilder` is to facilitate the construction of `Price` objects by providing a flexible and readable way to set various attributes before creating the final `Price` instance.

**Code Description**: 
The `PriceBuilder` class is designed to simplify the creation of `Price` objects by using the builder pattern. It contains the following fields: `id`, `fulltime`, `halftime`, `overtime`, and `date`. The class provides a no-argument constructor and a parameterized constructor for initializing these fields. 

The `setId`, `setFulltime`, `setHalftime`, `setOvertime`, and `setDate` methods allow for setting the respective fields and return the current `PriceBuilder` instance to enable method chaining. 

Finally, the `build` method constructs and returns a new `Price` object using the current state of the `PriceBuilder` instance. If the `Price` object cannot be created, it throws an `EntityException`.\\
## Code: 
```
class PriceBuilder{
		
		private int id;
		private BigDecimal fulltime;
		private BigDecimal halftime;
		private BigDecimal overtime;
		private Timestamp date;
		
		public PriceBuilder() {}

		public PriceBuilder(int id, BigDecimal fulltime, BigDecimal halftime, BigDecimal overtime, Timestamp date) {
			super();
			this.id = id;
			this.fulltime = fulltime;
			this.halftime = halftime;
			this.overtime = overtime;
			this.date = date;
		}

		public PriceBuilder setId(int id) {
			this.id = id;
			return this;
		}

		public PriceBuilder setFulltime(BigDecimal fulltime) {
			this.fulltime = fulltime;
			return this;
		}

		public PriceBuilder setHalftime(BigDecimal halftime) {
			this.halftime = halftime;
			return this;
		}

		public PriceBuilder setOvertime(BigDecimal overtime) {
			this.overtime = overtime;
			return this;
		}

		public PriceBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Price build() throws EntityException{
			return new Price(this);
		}
		
	}
```