`update`: The function of `update` is to update an existing invoice record in the database with new values provided in the `Invoice` object.

**Parameters**:\
`Invoice invoice`: The `Invoice` object containing the updated information for the invoice, including job ID, amount, and invoice ID.

**Code Description**: This method updates an existing invoice record in the database. It first establishes a connection to the database using the `DB.getConnection` method. It then prepares an SQL `UPDATE` statement to modify the `job_id` and `amount` fields of the invoice record identified by its `id`. The method sets the parameters of the prepared statement with the values from the `Invoice` object. If the update operation is successful (i.e., the number of affected rows is not zero), the updated `Invoice` object is cached. If an `SQLException` occurs during the process, the `showSQLException` method is called to display the error details. The method returns `true` if the update was successful, otherwise `false`.\\
## Code: 
```
boolean update(Invoice invoice) {
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE invoice SET job_id=?,"
				+ "amount=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, invoice.getJob().getId());
			pst.setBigDecimal(2, invoice.getAmount());
			pst.setInt(5, invoice.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(invoice.getId(), invoice);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```