`toString`: The function of `toString` is to provide a string representation of the `Employer` object.

**Code Description**: This method overrides the default `toString` method to return a string that concatenates the first name and last name of the `Employer` object, separated by a space. It achieves this by calling the `getFname` method to retrieve the first name and the `getLname` method to retrieve the last name.\\
## Code: 
```
String toString() {
		return getFname() + " " + getLname();
	}
```