`focusGained`: The function of `focusGained` is to change the visual appearance of a `JTextField` and its associated label when the text field gains focus.
**Parameters**:\
`FocusEvent e`: The event that indicates a component has gained input focus.

**Code Description**: When a `JTextField` gains focus, this method sets its border to blue. If the focused text field is the `amountTextField`, it also changes the color of the `amountLabel` text to blue. This provides a visual cue to the user indicating which text field is currently active.\\
## Code: 
```
void focusGained(FocusEvent e) {
		if(e.getSource() instanceof JTextField) {
			
			((JTextField)e.getSource()).setBorder(new LineBorder(Color.blue));
			
			if(((JTextField)e.getSource()) == amountTextField) {
				amountLabel.setForeground(Color.blue);
			}
			
		}
		
	}
```