`decimalControl`: The function of `decimalControl` is to validate whether given string arguments represent valid decimal numbers with up to two decimal places.

**Code Description**: The `decimalControl` method takes a variable number of string arguments and checks each one to see if it matches a specific decimal number pattern. The pattern allows for integers or decimal numbers with up to two digits after the decimal point. The method removes any whitespace from the strings before matching them against the pattern. It returns `true` if all provided strings match the pattern, and `false` otherwise.\\
## Code: 
```
boolean decimalControl(String ...args) {
		Pattern pattern = Pattern.compile("^\\d+(\\.\\d{1,2})?$"); // decimal pattern xxx.xx
		boolean result = true;
		
		for(String arg : args)
			result = result && pattern.matcher(arg.replaceAll("\\s+", "")).find();
		
		return result;
	}
```