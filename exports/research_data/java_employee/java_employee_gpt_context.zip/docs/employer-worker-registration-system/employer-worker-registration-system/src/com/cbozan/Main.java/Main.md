`Main`: The function of `Main` is to initialize the application by setting the default locale and starting the login process in a thread-safe manner.

**Code Description**: 
The `Main` class contains the `main` method, which serves as the entry point for the application. It sets the default locale to Turkish (Turkey) using `Locale.setDefault(new Locale("tr", "TR"))`. This ensures that the application uses Turkish language and regional settings. The `EventQueue.invokeLater` method is used to schedule the creation of a new `Login` instance on the Event Dispatch Thread (EDT). This is important for ensuring that the user interface is created and updated in a thread-safe manner, adhering to the Swing framework's single-threaded rule.\\
## Code: 
```
class Main {
	
	public static void main(String[] args) {
		
		Locale.setDefault(new Locale("tr", "TR"));
		
		EventQueue.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				
				new Login();
				
			}
		});
			
	}
	
}
```