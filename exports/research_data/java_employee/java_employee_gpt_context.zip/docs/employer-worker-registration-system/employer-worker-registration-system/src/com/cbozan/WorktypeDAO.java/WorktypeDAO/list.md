`list`: The function of `list` is to retrieve a list of all `Worktype` objects from the database, either from a cache or by querying the database.

**Code Description**: 
The `list` method in the `WorktypeDAO` class retrieves all `Worktype` objects. It first checks if the cache is being used and is not empty. If so, it returns the cached `Worktype` objects. If the cache is empty or not used, it clears the cache and queries the database for all `Worktype` records. It then constructs `Worktype` objects using the `WorktypeBuilder`, adds them to the list, and updates the cache. If any SQL or entity-related exceptions occur, they are handled and displayed appropriately. Finally, the method returns the list of `Worktype` objects.\\
## Code: 
```
List<Worktype> list(){
		
		List<Worktype> list = new ArrayList<>();
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Worktype> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM worktype;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorktypeBuilder builder;
			Worktype worktype;
			
			while(rs.next()) {
				
				builder = new WorktypeBuilder();
				builder.setId(rs.getInt("id"));
				builder.setTitle(rs.getString("title"));
				builder.setNo(rs.getInt("no"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					worktype = builder.build();
					list.add(worktype);
					cache.put(worktype.getId(), worktype);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id") + ", Title : " + rs.getString("title"));
				}
				
			}
			
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
		
	}
```