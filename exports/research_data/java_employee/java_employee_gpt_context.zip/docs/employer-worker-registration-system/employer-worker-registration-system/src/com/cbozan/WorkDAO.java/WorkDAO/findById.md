`findById`: The function of `findById` is to retrieve a `Work` object by its unique identifier from the cache or database.

**Parameters**:\
`int id`: The unique identifier of the `Work` object to be retrieved.

**Code Description**: The `findById` method first checks if the cache is being used. If the cache is not being used (`usingCache == false`), it calls the `list` method to populate the cache with `Work` objects from the database. Then, it checks if the cache contains an entry for the given `id`. If the cache contains the `id`, it returns the corresponding `Work` object from the cache. If the `id` is not found in the cache, it returns `null`.\\
## Code: 
```
Work findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```