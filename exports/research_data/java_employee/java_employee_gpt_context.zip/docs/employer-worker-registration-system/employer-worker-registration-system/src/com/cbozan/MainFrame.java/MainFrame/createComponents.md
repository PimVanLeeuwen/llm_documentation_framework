`createComponents`: The function of `createComponents` is to initialize and organize various panels within the main frame of the application.

**Code Description**: The `createComponents` method initializes several panel objects, each representing different sections or functionalities of the application (e.g., `JobPanel`, `WorkerPanel`, `EmployerPanel`, `PricePanel`, etc.). These panels are then added to an `ArrayList` named `components`. Finally, the method sets the content pane of the main frame to the panel corresponding to the `activePage` index in the `components` list. This setup allows for dynamic switching and display of different panels within the main frame.\\
## Code: 
```
void createComponents() {
		
		// record menu panels
		JobPanel job = new JobPanel();
		WorkerPanel worker = new WorkerPanel();
		EmployerPanel employer = new EmployerPanel();
		PricePanel price = new PricePanel();
		
		// add menu panels
		WorkerPaymentPanel workerPayment = new WorkerPaymentPanel();
		WorkPanel work = new WorkPanel();
		JobPaymentPanel jobPayment = new JobPaymentPanel();
		
		// display menu panels
		JobDisplay jobDisplay = new JobDisplay();
		WorkerDisplay workerDisplay = new WorkerDisplay();
		EmployerDisplay employerDisplay = new EmployerDisplay();
		
		components = new ArrayList<>();
		components.add(job);
		components.add(worker);
		components.add(employer);
		components.add(price);
		components.add(workerPayment);
		components.add(work);
		components.add(jobPayment);
		components.add(jobDisplay);
		components.add(workerDisplay);
		components.add(employerDisplay);
		
		setContentPane((JPanel) components.get(activePage));
		
	}
```