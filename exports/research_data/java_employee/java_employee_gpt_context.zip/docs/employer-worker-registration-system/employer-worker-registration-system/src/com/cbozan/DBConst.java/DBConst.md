`DBConst`: The function of `DBConst` is to define constant values related to database fields.

**Code Description**: 
- `DBConst` is a class that contains static final integer constants.
- `FNAME_LENGTH` is a constant representing the maximum length of the first name field, set to 30 characters.
- `LNAME_LENGTH` is a constant representing the maximum length of the last name field, set to 20 characters.
- These constants are likely used to enforce consistent field lengths in the database schema or application logic.\\
## Code: 
```
class DBConst {
	public static final int FNAME_LENGTH = 30;
	public static final int LNAME_LENGTH = 20;
}
```