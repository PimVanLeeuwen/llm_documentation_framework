`createControl`: The function of `createControl` is to determine whether a payment can be processed or accepted.

**Parameters**:\
`Payment payment`: An object representing the payment details that need to be checked.

**Code Description**: The `createControl` method currently returns `true` unconditionally, indicating that any payment is accepted. The commented-out code suggests that there is an intention to iterate over a cache of payments to perform some checks, possibly to verify if sufficient payments have been received. However, this logic is not yet implemented.\\
## Code: 
```
boolean createControl(Payment payment) {
//		for(Entry<Integer, Payment> obj : cache.entrySet()) {
//			// yeteri kadar �deme alabilir mi? kontrol etme kodu buraya gelecek
//		}
		return true;
	}
```