`hashCode`: The function of `hashCode` is to generate a hash code for an `Invoice` object.

**Code Description**: This method generates a hash code for the `Invoice` object using the `Objects.hash` method. It combines the hash codes of the `amount`, `date`, `id`, and `job` fields to produce a single hash code value. This is useful for efficient storage and retrieval in hash-based collections like `HashMap` and `HashSet`.\\
## Code: 
```
int hashCode() {
		return Objects.hash(amount, date, id, job);
	}
```