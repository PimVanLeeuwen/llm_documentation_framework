`findById`: The function of `findById` is to retrieve a `Workgroup` object by its unique identifier from the cache or database.

**Parameters**:\
`int id`: The unique identifier of the `Workgroup` to be retrieved.

**Code Description**: The `findById` method first checks if the cache is being used. If the cache is not being used (`usingCache == false`), it calls the `list` method to populate the cache with `Workgroup` objects from the database. Then, it checks if the cache contains a `Workgroup` with the specified `id`. If found, it returns the `Workgroup` object from the cache; otherwise, it returns `null`.\\
## Code: 
```
Workgroup findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```