`getFname`: The function of `getFname` is to retrieve the first name of the worker.

**Code Description**: The `getFname` method is a public method that returns the value of the `fname` attribute, which represents the first name of the worker. This method does not take any parameters and returns a `String` containing the first name.\\
## Code: 
```
String getFname() {
		return fname;
	}
```