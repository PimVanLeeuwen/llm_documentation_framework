`createControl`: The function of `createControl` is to check if a given `Worktype` object already exists in the cache based on its title.

**Parameters**:\
`Worktype worktype`: The `Worktype` object that needs to be checked for existence in the cache.

**Code Description**: The `createControl` method iterates through the entries of the `cache` map, which stores `Worktype` objects. For each entry, it compares the title of the `Worktype` object in the cache with the title of the provided `worktype` object. If a match is found, the method returns `false`, indicating that the `worktype` already exists in the cache. If no match is found after checking all entries, the method returns `true`, indicating that the `worktype` does not exist in the cache and can be created.\\
## Code: 
```
boolean createControl(Worktype worktype) {
		for(Entry<Integer, Worktype> obj : cache.entrySet()) {
			if(obj.getValue().getTitle().equals(worktype.getTitle())) {
				return false;
			}
		}
		return true;
	}
```