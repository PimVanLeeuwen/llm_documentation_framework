`notifyAllObservers`: The function of `notifyAllObservers` is to inform all registered observers about a change or event.

**Code Description**: The `notifyAllObservers` method iterates through a list of registered observers and calls their `update` method. This ensures that each observer can refresh or update its state based on the latest data or changes. This method is typically used in the Observer design pattern to maintain consistency between the subject and its observers.\\
## Code: 
```
void notifyAllObservers() {
		for(Observer observer : observers) {
			observer.update();
		}
	}
```