`refresh`: The function of `refresh` is to update the list of `Invoice` objects by temporarily disabling the cache.

**Code Description**: The `refresh` method first disables the cache by calling `setUsingCache(false)`. It then calls the `list` method to retrieve and update the list of `Invoice` objects from the database. Finally, it re-enables the cache by calling `setUsingCache(true)`. This ensures that the list is refreshed with the most current data from the database, bypassing any cached data during the update process.\\
## Code: 
```
void refresh() {
		setUsingCache(false);
		list();
		setUsingCache(true);
	}
```