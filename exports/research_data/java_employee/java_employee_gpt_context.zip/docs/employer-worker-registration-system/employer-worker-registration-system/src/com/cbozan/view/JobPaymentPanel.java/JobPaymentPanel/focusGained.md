`focusGained`: The function of `focusGained` is to change the visual appearance of a `JTextField` and its associated label when the text field gains focus.
**Parameters**:\
`FocusEvent e`: The event that indicates a component has gained input focus.

**Code Description**: The `focusGained` method checks if the source of the focus event is an instance of `JTextField`. If true, it sets the border of the `JTextField` to a blue line border. Additionally, if the `JTextField` that gained focus is `amountTextField`, it changes the foreground color of `amountLabel` to blue.\\
## Code: 
```
void focusGained(FocusEvent e) {
		if(e.getSource() instanceof JTextField) {
			
			((JTextField)e.getSource()).setBorder(new LineBorder(Color.blue));
			
			if(((JTextField)e.getSource()) == amountTextField) {
				amountLabel.setForeground(Color.blue);
			}
			
		}
		
	}
```