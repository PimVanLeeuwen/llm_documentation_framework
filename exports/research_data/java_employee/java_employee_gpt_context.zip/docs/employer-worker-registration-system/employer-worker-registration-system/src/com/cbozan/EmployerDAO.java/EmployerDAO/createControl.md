`createControl`: The function of `createControl` is to check if an employer with the same first name and last name already exists in the cache.

**Parameters**:\
`Employer employer`: An `Employer` object that contains the details of the employer to be checked.

**Code Description**: The `createControl` method iterates through the `cache` (a collection of `Employer` objects) to determine if there is already an employer with the same first name and last name as the provided `employer` object. If a match is found, it sets an error message in the `DB` class indicating that the employer already exists and returns `false`. If no match is found, it returns `true`, indicating that the employer can be created.\\
## Code: 
```
boolean createControl(Employer employer) {
		
		for(Entry<Integer, Employer> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(employer.getFname())
					&& obj.getValue().getLname().equals(employer.getLname())) {
				
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		
		return true;
	}
```