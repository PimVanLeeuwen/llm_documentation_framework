`getEmptyInstance`: The function of `getEmptyInstance` is to return a singleton instance of an empty `Invoice`.

**Code Description**: This method returns a singleton instance of an empty `Invoice` by accessing the `instance` field of the `EmptyInstanceSingleton` class. This ensures that only one instance of an empty `Invoice` is created and used throughout the application, promoting efficient memory usage and consistent behavior.\\
## Code: 
```
Invoice getEmptyInstance() {
		return EmptyInstanceSingleton.instance;
	}
```