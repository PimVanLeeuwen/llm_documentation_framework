`update`: The function of `update` is to refresh and update the display components related to employers, jobs, and payments in the user interface.

**Code Description**: The `update` method performs several actions to refresh the user interface:
1. It updates the `employerSearchBox` with a list of all employers retrieved from the `EmployerDAO`.
2. It retrieves the currently selected employer from the `employerCard` and sets the text of the `employerSearchBox` to the selected employer's string representation or an empty string if no employer is selected.
3. It refreshes the data in the `JobDAO` and `InvoiceDAO` to ensure the latest job and invoice information is available.
4. It calls `updateJobTableData` to refresh the job table with the latest job details for the selected employer.
5. It calls `updateEmployerPaymentTableData` to refresh the employer payment table with the latest invoice data for the selected employer.
6. Finally, it calls `employerCard.reload` to reload the employer card component, ensuring it displays the most up-to-date information.\\
## Code: 
```
void update() {
		employerSearchBox.setObjectList(EmployerDAO.getInstance().list());
		selectedEmployer = employerCard.getSelectedEmployer();
		employerSearchBox.setText(selectedEmployer == null ? "" : selectedEmployer.toString());
		JobDAO.getInstance().refresh();
		InvoiceDAO.getInstance().refresh();
		updateJobTableData();
		updateEmployerPaymentTableData();
		employerCard.reload();
	}
```