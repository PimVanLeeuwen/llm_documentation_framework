`list`: The function of `list` is to retrieve a list of `Work` objects from the database or cache.

**Code Description**: 
- The `list` method first initializes an empty `ArrayList` of `Work` objects.
- It checks if the cache is not empty and if caching is enabled (`usingCache`). If both conditions are met, it populates the list from the cache and returns it.
- If the cache is empty or caching is not enabled, it clears the cache and proceeds to retrieve data from the database.
- It establishes a database connection using the `DB.getConnection` method.
- It executes a SQL query to select all records from the `work` table.
- For each record in the result set, it uses a `WorkBuilder` to construct a `Work` object with the retrieved data.
- It adds each successfully built `Work` object to the list and updates the cache with the new `Work` object.
- If an `EntityException` occurs during the building of a `Work` object, it handles the exception by calling `showEntityException`.
- If an `SQLException` occurs during the database operations, it handles the exception by calling `showSQLException`.
- Finally, it returns the list of `Work` objects.\\
## Code: 
```
List<Work> list(){
		
		List<Work> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Work> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM work;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorkBuilder builder;
			Work work;
			
			while(rs.next()) {
				
				builder = new WorkBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setWorker_id(rs.getInt("worker_id"));
				builder.setWorktype_id(rs.getInt("worktype_id"));
				builder.setWorkgroup_id(rs.getInt("workgroup_id"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					work = builder.build();
					list.add(work);
					cache.put(work.getId(), work);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
	}
```