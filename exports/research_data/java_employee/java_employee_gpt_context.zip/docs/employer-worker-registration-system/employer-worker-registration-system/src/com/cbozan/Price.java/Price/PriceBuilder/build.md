`build`: The function of `build` is to create and return a new `Price` object using the current state of the `PriceBuilder` instance.

**Code Description**: The `build` method in the `PriceBuilder` class constructs a new `Price` object by passing the current `PriceBuilder` instance to the `Price` constructor. If the construction of the `Price` object fails, it throws an `EntityException`.\\
## Code: 
```
Price build() throws EntityException{
			return new Price(this);
		}
```