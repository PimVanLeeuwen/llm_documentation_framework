`focusLost`: The function of `focusLost` is to handle the event when a text field loses focus, validating the text and updating the border and label color based on the validation result.
**Parameters**:\
`FocusEvent e`: The event that indicates a component has lost the keyboard focus.

**Code Description**: This method first checks if the source of the focus event is a `JTextField`. If it is, it initializes a color variable to white. It then validates the text of the `JTextField` using the `decimalControl` method. If the text is valid, the color is set to green; otherwise, it is set to red. The border of the `JTextField` is updated to this color. Additionally, if the `JTextField` is the `amountTextField`, the foreground color of the `amountLabel` is also updated to match the validation color.\\
## Code: 
```
void focusLost(FocusEvent e) {
		if(e.getSource() instanceof JTextField) {
			
			Color color = Color.white;
			
			if(decimalControl(((JTextField)e.getSource()).getText())) {
				color = new Color(0, 180, 0);
			} else {
				color = Color.red;
			}
			
			((JTextField)e.getSource()).setBorder(new LineBorder(color));
		
			if(((JTextField)e.getSource()) == amountTextField) {
				amountLabel.setForeground(color);
			}
		}
	}
```