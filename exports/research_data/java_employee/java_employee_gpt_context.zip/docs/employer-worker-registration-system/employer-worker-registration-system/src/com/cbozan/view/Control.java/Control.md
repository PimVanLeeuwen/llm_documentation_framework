`Control`: The function of `Control` is to provide utility methods for validating phone numbers, IBANs, and decimal numbers using regular expressions.

**Code Description**: 
The `Control` class contains static methods to validate different types of input data:

1. **Phone Number Validation**:
   - `phoneNumberControl(String phoneNumber)`: Validates a phone number against a default pattern that includes optional country code (+90 or 0) and a 10-digit number.
   - `phoneNumberControl(String phoneNumber, String regex)`: Validates a phone number against a custom regular expression pattern provided as a string.
   - `phoneNumberControl(String phoneNumber, Pattern pattern)`: Validates a phone number against a custom `Pattern` object.

2. **IBAN Validation**:
   - `ibanControl(String iban)`: Validates a Turkish IBAN (International Bank Account Number) against a default pattern that includes the country code "TR" followed by 24 digits.
   - `ibanControl(String iban, String regex)`: Validates an IBAN against a custom regular expression pattern provided as a string.
   - `ibanControl(String iban, Pattern pattern)`: Validates an IBAN against a custom `Pattern` object.

3. **Decimal Number Validation**:
   - `decimalControl(String ...args)`: Validates each string in the provided arguments to ensure they match a decimal number format with up to two decimal places.
   - `decimalControl(Pattern pattern, String ...args)`: Validates each string in the provided arguments against a custom `Pattern` object to ensure they match the specified pattern.

Each method removes any whitespace from the input before performing the validation and returns `true` if the input matches the pattern, otherwise `false`. The `decimalControl` methods use a logical AND operation to ensure all provided strings meet the pattern criteria.\\
## Code: 
```
class Control {

	public static boolean phoneNumberControl(String phoneNumber) {
		return Pattern.compile("^((((\\+90)?|(0)?)\\d{10})|())$").matcher(phoneNumber.replaceAll("\\s+", "")).find();
	}
	public static boolean phoneNumberControl(String phoneNumber, String regex) {
		return Pattern.compile(regex).matcher(phoneNumber.replaceAll("\\s+", "")).find();
	}
	public static boolean phoneNumberControl(String phoneNumber, Pattern pattern) {
		return pattern.matcher(phoneNumber).find();
	}
	
	
	public static boolean ibanControl(String iban) {
		return Pattern.compile("^((TR\\d{24})|())$", Pattern.CASE_INSENSITIVE).matcher(iban).find();
	}
	public static boolean ibanControl(String iban, String regex) {
		return Pattern.compile(regex).matcher(iban).find();
	}
	public static boolean ibanControl(String iban, Pattern pattern) {
		return pattern.matcher(iban).find();
	}
	
	
	public static boolean decimalControl(String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= Pattern.compile("^((\\d+(\\.\\d{1,2})?)|())$").matcher(arg).find();
		}
		return rValue;
	}
	public static boolean decimalControl(Pattern pattern, String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= pattern.matcher(arg).find();
		}
		return rValue;
	}
	
}
```