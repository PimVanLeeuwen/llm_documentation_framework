`toString`: The function of `toString` is to return the title of the job.

**Code Description**: This method overrides the default `toString` method to return the job title by calling the `getTitle` method. It does not take any parameters and returns a `String` representing the job title.\\
## Code: 
```
String toString() {
		return getTitle();
	}
```