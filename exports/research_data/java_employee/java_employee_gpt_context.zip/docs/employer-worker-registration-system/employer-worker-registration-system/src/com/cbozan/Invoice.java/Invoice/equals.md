`equals`: The function of `equals` is to compare the current `Invoice` object with another object to determine if they are equal.

**Parameters**:\
`Object obj`: The object to be compared with the current `Invoice` object.

**Code Description**: The `equals` method first checks if the current object and the provided object reference the same instance. If they do, it returns `true`. It then checks if the provided object is `null` or if it is of a different class, returning `false` in either case. If the provided object is of the same class, it casts the object to `Invoice` and compares the `amount`, `date`, `id`, and `job` fields of both objects using the `Objects.equals` method for the fields and the `==` operator for the `id` field. If all these fields are equal, the method returns `true`; otherwise, it returns `false`.\\
## Code: 
```
boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Invoice other = (Invoice) obj;
		return Objects.equals(amount, other.amount) && Objects.equals(date, other.date) && id == other.id
				&& Objects.equals(job, other.job);
	}
```