`PaymentBuilder`: The function of `PaymentBuilder` is to facilitate the construction of `Payment` objects by providing a flexible and readable way to set various properties before creating the final `Payment` instance.

**Code Description**: 
The `PaymentBuilder` class is designed to simplify the creation of `Payment` objects by using the builder pattern. It contains fields for `id`, `worker`, `worker_id`, `job`, `job_id`, `paytype`, `paytype_id`, `amount`, and `date`. The class provides multiple constructors to initialize these fields and a series of setter methods that return the `PaymentBuilder` instance for method chaining. The `build` method constructs and returns a `Payment` object, either using the `PaymentBuilder` instance or the provided parameters, and throws an `EntityException` if any required fields (`worker`, `job`, or `paytype`) are null.\\
## Code: 
```
class PaymentBuilder {
		
		private int id;
		private Worker worker;
		private int worker_id;
		private Job job;
		private int job_id;
		private Paytype paytype;
		private int paytype_id;
		private BigDecimal amount;
		private Timestamp date;
		
		public PaymentBuilder() {}
		public PaymentBuilder(int id, int worker_id, int job_id, int paytype_id, BigDecimal amount, Timestamp date) {
			super();
			this.id = id;
			this.worker_id = worker_id;
			this.job_id = job_id;
			this.paytype_id = paytype_id;
			this.amount = amount;
			this.date = date;
		}
		
		public PaymentBuilder(int id, Worker worker, Job job, Paytype paytype, BigDecimal amount, Timestamp date) {
			this(id, 0, 0, 0, amount, date);
			this.worker = worker;
			this.job = job;
			this.paytype = paytype;
		}
		
		public PaymentBuilder setId(int id) {
			this.id = id;
			return this;
		}
		
		public PaymentBuilder setWorker(Worker worker) {
			this.worker = worker;
			return this;
		}
		
		public PaymentBuilder setWorker_id(int worker_id) {
			this.worker_id = worker_id;
			return this;
		}
		
		public PaymentBuilder setJob(Job job) {
			this.job = job;
			return this;
		}
		
		public PaymentBuilder setJob_id(int job_id) {
			this.job_id = job_id;
			return this;
		}
		
		public PaymentBuilder setPaytype(Paytype paytype) {
			this.paytype = paytype;
			return this;
		}
		
		public PaymentBuilder setPaytype_id(int paytype_id) {
			this.paytype_id = paytype_id;
			return this;
		}
		
		public PaymentBuilder setAmount(BigDecimal amount) {
			this.amount = amount;
			return this;
		}
		
		public PaymentBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Payment build() throws EntityException{
			if(worker == null || job == null || paytype == null)
				return new Payment(this);
			return new Payment(id, worker, job, paytype, amount, date);
		}
	}
```