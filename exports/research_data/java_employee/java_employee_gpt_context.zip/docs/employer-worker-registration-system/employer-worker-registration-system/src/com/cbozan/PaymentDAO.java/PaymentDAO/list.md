`list`: The function of `list` is to retrieve a list of `Payment` objects from the database based on specified column names and their corresponding IDs.

**Parameters**:\
`String[] columnName`: An array of column names to be used in the WHERE clause of the SQL query. \
`int[] id`: An array of IDs corresponding to the column names, used to filter the results in the SQL query.

**Code Description**: This method constructs an SQL query to select records from the `payment` table where the specified columns match the provided IDs. It first checks if the lengths of `columnName` and `id` arrays are equal. If not, it returns an empty list. It then builds the SQL query dynamically by appending each column name and ID pair to the WHERE clause. After constructing the query, it establishes a database connection using `DB.getConnection()`, executes the query, and processes the result set. For each row in the result set, it creates a `PaymentBuilder` object, sets its properties from the result set, and attempts to build a `Payment` object. If successful, the `Payment` object is added to the list. If an `EntityException` occurs during the build process, an error message is printed, and the payment is not added to the list. Finally, the method returns the list of `Payment` objects.\\
## Code: 
```
List<Payment> list(String[] columnName, int[] id){
		
		List<Payment> list = new ArrayList<>();
		if(columnName.length != id.length)
			return list;
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM payment WHERE ";
		
		for(int i = 0; i < columnName.length; i++) {
			query += columnName[i] + "=" + id[i] + " AND ";
		}
		
		query = query.substring(0, query.length() - (" AND ".length()));
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			PaymentBuilder builder;
			Payment payment;
			
			while(rs.next()) {
				
				builder = new PaymentBuilder();
				builder.setId(rs.getInt("id"));
				builder.setWorker_id(rs.getInt("worker_id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setPaytype_id(rs.getInt("paytype_id"));
				builder.setAmount(rs.getBigDecimal("amount"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					payment = builder.build();
					list.add(payment);
				} catch (EntityException e) {
					System.err.println(e.getMessage());
					System.out.println("!! Payment not added list !!");
				}
				
			}
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return list;
	}
```