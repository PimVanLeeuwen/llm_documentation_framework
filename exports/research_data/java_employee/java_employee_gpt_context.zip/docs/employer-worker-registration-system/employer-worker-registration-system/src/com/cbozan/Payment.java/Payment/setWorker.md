`setWorker`: The function of `setWorker` is to assign a `Worker` object to the `worker` attribute of the `Payment` class. 

**Parameters**:\
`Worker worker`: The `Worker` object to be assigned to the `worker` attribute. This parameter must not be null.

**Code Description**: The `setWorker` method first checks if the provided `worker` parameter is null. If it is null, the method throws an `EntityException` with the message "Worker in Payment is null". If the `worker` parameter is not null, it assigns the provided `Worker` object to the `worker` attribute of the `Payment` class.\\
## Code: 
```
void setWorker(Worker worker) throws EntityException {
		if(worker == null)
			throw new EntityException("Worker in Payment is null");
		this.worker = worker;
	}
```