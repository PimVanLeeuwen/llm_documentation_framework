`getIban`: The function of `getIban` is to return the IBAN (International Bank Account Number) of the worker.

**Code Description**: This method, `getIban`, is a simple getter method that returns the value of the `iban` field from the `Worker` class. It does not take any parameters and returns a `String` representing the worker's IBAN. This method is typically used to access the IBAN value stored in a `Worker` object.\\
## Code: 
```
String getIban() {
		return iban;
	}
```