`update`: The function of `update` is to update the details of an existing employer in the database and cache.

**Parameters**:\
`Employer employer`: An `Employer` object containing the updated details of the employer to be modified in the database.

**Code Description**: The `update` method first checks if the provided `Employer` object passes the `updateControl` validation. If the validation fails, the method returns `false`. If the validation passes, it proceeds to update the employer's details in the database. It establishes a connection to the database using the `DB.getConnection` method and prepares an SQL `UPDATE` statement to modify the employer's first name, last name, telephone numbers, and description based on the employer's ID. The method sets the parameters for the prepared statement using the values from the `Employer` object and executes the update. If the update is successful, the employer's details are also updated in the cache. If an `SQLException` occurs during the process, the `showSQLException` method is called to display the error. The method returns `true` if the update is successful and `false` otherwise.\\
## Code: 
```
boolean update(Employer employer) {
		
		if(updateControl(employer) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE employer SET fname=?,"
				+ "lname=?, tel=?, description=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1, employer.getFname());
			pst.setString(2, employer.getLname());
			
			Array phones = conn.createArrayOf("VARCHAR", employer.getTel().toArray());
			pst.setArray(3, phones);
			
			pst.setString(4, employer.getDescription());
			pst.setInt(5, employer.getId());
			
			result = pst.executeUpdate();
			
			// update cache
			if(result != 0) {
				cache.put(employer.getId(), employer);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```