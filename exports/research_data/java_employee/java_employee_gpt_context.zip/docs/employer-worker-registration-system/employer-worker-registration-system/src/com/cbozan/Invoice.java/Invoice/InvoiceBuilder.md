`InvoiceBuilder`: The function of `InvoiceBuilder` is to facilitate the construction of `Invoice` objects by providing a flexible and readable way to set various properties before creating the final `Invoice` instance.

**Code Description**: 
The `InvoiceBuilder` class is designed to simplify the creation of `Invoice` objects. It includes fields for `id`, `job_id`, `job`, `amount`, and `date`. The class provides multiple constructors to initialize these fields in different ways. The `InvoiceBuilder` class also includes setter methods for each field, which return the current `InvoiceBuilder` instance to allow for method chaining. The `build` method constructs and returns an `Invoice` object, throwing an `EntityException` if the `job` field is null. This design pattern ensures that `Invoice` objects are created with all necessary fields properly set, improving code readability and maintainability.\\
## Code: 
```
class InvoiceBuilder{
		
		private int id;
		private int job_id;
		private Job job;
		private BigDecimal amount;
		private Timestamp date;
		
		public InvoiceBuilder() {}
		public InvoiceBuilder(int id, int job_id, BigDecimal amount, Timestamp date) {
			this.id = id;
			this.job_id = job_id;
			this.amount = amount;
			this.date = date;
		}
		
		public InvoiceBuilder(int id, Job job, BigDecimal amount, Timestamp date) {
			this(id, 0, amount, date);
			this.job = job;
		}
		
		public InvoiceBuilder setId(int id) {
			this.id = id;
			return this;
		}
		
		public InvoiceBuilder setJob_id(int job_id) {
			this.job_id = job_id;
			return this;
		}
		
		public InvoiceBuilder setJob(Job job) {
			this.job = job;
			return this;
		}
		
		public InvoiceBuilder setAmount(BigDecimal amount) {
			this.amount = amount;
			return this;
		}
		
		public InvoiceBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Invoice build() throws EntityException {
			if(job == null)
				return new Invoice(this);
			return new Invoice(id, job, amount, date);
		}
		
	}
```