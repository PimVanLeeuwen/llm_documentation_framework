`setFulltime`: The function of `setFulltime` is to set the full-time price for an entity, ensuring that the provided value is neither null, zero, nor negative.
**Parameters**:\
`BigDecimal fulltime`: The full-time price to be set. It must be a positive value greater than zero.

**Code Description**: The `setFulltime` method takes a `BigDecimal` parameter named `fulltime`. It first checks if the provided `fulltime` value is null or less than or equal to zero. If either condition is true, it throws an `EntityException` with the message "Price fulltime negative or null or zero". If the value is valid, it assigns the `fulltime` parameter to the instance variable `this.fulltime`.\\
## Code: 
```
void setFulltime(BigDecimal fulltime) throws EntityException {
		if(fulltime == null || fulltime.compareTo(new BigDecimal("0.00")) <= 0)
			throw new EntityException("Price fulltime negative or null or zero");
		this.fulltime = fulltime;
	}
```