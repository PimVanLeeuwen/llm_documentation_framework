`list`: The function of `list` is to retrieve a list of all workers from the database, utilizing a cache if available.

**Code Description**: 
- The `list` method initializes an empty list of `Worker` objects.
- It checks if the cache is not empty and if caching is enabled (`usingCache`). If both conditions are met, it populates the list from the cache and returns it.
- If the cache is empty or caching is not enabled, it clears the cache and proceeds to fetch data from the database.
- It establishes a database connection using `DB.getConnection()`.
- It executes a SQL query to select all records from the `worker` table.
- For each record in the result set, it uses a `WorkerBuilder` to construct a `Worker` object, setting its properties from the database fields.
- If the `tel` field is not null, it converts it to a list of strings.
- It adds each successfully built `Worker` object to the list and updates the cache with the new worker.
- If an `EntityException` occurs during the building of a `Worker` object, it calls `showEntityException` to display the error.
- If an `SQLException` occurs during the database operations, it calls `showSQLException` to display the error.
- Finally, it returns the list of `Worker` objects.\\
## Code: 
```
List<Worker> list(){
		
		List<Worker> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Worker> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM worker;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorkerBuilder builder;
			Worker worker;
			
			while(rs.next()) {
				
				builder = new WorkerBuilder();
				builder.setId(rs.getInt("id"));
				builder.setFname(rs.getString("fname"));
				builder.setLname(rs.getString("lname"));
				
				if(rs.getArray("tel") == null)
					builder.setTel(null);
				else
					builder.setTel(Arrays.asList((String [])rs.getArray("tel").getArray()));
				
				builder.setIban(rs.getString("iban"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					worker = builder.build();
					list.add(worker);
					cache.put(worker.getId(), worker);
				} catch (EntityException e) {
					showEntityException(e, rs.getString("fname") + " " + rs.getShort("lname"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
		
	}
```