`findById`: The function of `findById` is to retrieve an `Employer` object by its unique identifier (ID) from the cache or database.

**Parameters**:\
`int id`: The unique identifier of the `Employer` to be retrieved.

**Code Description**: The `findById` method first checks if the cache is being used. If the cache is not being used (`usingCache == false`), it calls the `list` method to populate the cache with all employers from the database. Then, it checks if the cache contains an `Employer` object with the specified ID. If the cache contains the `Employer` object, it returns the object; otherwise, it returns `null`.\\
## Code: 
```
Employer findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
	}
```