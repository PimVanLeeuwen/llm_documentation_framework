`actionPerformed`: The function of `actionPerformed` is to handle action events triggered by user interactions, such as button clicks, and update the displayed content accordingly.

**Parameters**:\
`ActionEvent e`: This parameter represents the action event that triggered the method. It contains information about the event, such as the command string associated with the action.

**Code Description**: The `actionPerformed` method first checks if the action command (converted to an integer) is within the valid range of component indices. If the action command corresponds to the currently active page, it calls the `update` method on the current component. If the action command corresponds to a different page, it updates the `activePage` variable to the new page index. The method then sets the content pane to the component corresponding to the new active page and calls `revalidate` to refresh the user interface.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		if(Integer.parseInt(e.getActionCommand())>= 0 && Integer.parseInt(e.getActionCommand()) < components.size()) {
			if(Integer.parseInt(e.getActionCommand()) == activePage) {
				components.get(activePage).update();
			} else {
				activePage = (byte) Integer.parseInt(e.getActionCommand());
			}
			setContentPane((JPanel)components.get(activePage));
			
			revalidate();
		}
		
	}
```