`setId`: The function of `setId` is to set the ID of a `Work` object, ensuring that the ID is a positive integer.

**Parameters**:\
`int id`: The ID to be assigned to the `Work` object. It must be a positive integer.

**Code Description**: The `setId` method takes an integer parameter `id` and assigns it to the `id` field of the `Work` object. Before assigning, it checks if the provided `id` is less than or equal to zero. If the `id` is invalid (i.e., zero or negative), it throws an `EntityException` with the message "Work ID negative or zero". If the `id` is valid, it sets the `id` field of the `Work` object to the provided value.\\
## Code: 
```
void setId(int id) throws EntityException{
		if(id <= 0)
			throw new EntityException("Work ID negative or zero");
		this.id = id;
	}
```