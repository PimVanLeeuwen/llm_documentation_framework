`getId`: The function of `getId` is to retrieve the value of the `id` field from an `Invoice` object.

**Code Description**: This method, `getId`, is a public method that returns an integer value representing the `id` of the `Invoice` object. When called, it accesses the private `id` field of the object and returns its value. This method does not take any parameters and simply provides read access to the `id` attribute.\\
## Code: 
```
int getId() {
		return id;
	}
```