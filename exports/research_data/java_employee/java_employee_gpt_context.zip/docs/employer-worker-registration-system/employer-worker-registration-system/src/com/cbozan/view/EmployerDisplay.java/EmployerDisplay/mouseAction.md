`mouseAction`: The function of `mouseAction` is to handle mouse events and update the employer payment job filter based on the selected job.

**Parameters**:\
`MouseEvent e`: The mouse event that triggered this action. \
`Object searchResultObject`: The object representing the search result, expected to be of type `Job`. \
`int chooseIndex`: The index of the chosen item in the search results.

**Code Description**: This method casts the `searchResultObject` to a `Job` object and assigns it to `selectedJob`. It then updates the `employerPaymentJobFilterSearchBox` with the string representation of the selected job and makes the search box non-editable. The label `employerPaymentJobFilterLabel` is set to a specific color, and the `removeEmployerPaymentJobFilterButton` is made visible. The method then calls `updateEmployerPaymentTableData` to refresh the table data and finally calls the superclass's `mouseAction` method with the same parameters.\\
## Code: 
```
void mouseAction(MouseEvent e, Object searchResultObject, int chooseIndex) {
				selectedJob = (Job) searchResultObject;
				employerPaymentJobFilterSearchBox.setText(selectedJob.toString());
				employerPaymentJobFilterSearchBox.setEditable(false);
				employerPaymentJobFilterLabel.setForeground(new Color(37, 217, 138));
				removeEmployerPaymentJobFilterButton.setVisible(true);
				updateEmployerPaymentTableData();
				super.mouseAction(e, searchResultObject, chooseIndex);
			}
```