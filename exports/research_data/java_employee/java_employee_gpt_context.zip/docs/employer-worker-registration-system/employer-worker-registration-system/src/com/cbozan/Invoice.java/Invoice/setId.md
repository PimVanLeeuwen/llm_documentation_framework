`setId`: The function of `setId` is to assign a valid ID to an invoice.

**Parameters**:\
`int id`: The ID to be assigned to the invoice. It must be a positive integer.

**Code Description**: The `setId` method checks if the provided `id` is greater than zero. If the `id` is less than or equal to zero, it throws an `EntityException` with the message "Invoice ID negative or zero". If the `id` is valid (greater than zero), it assigns the `id` to the invoice's `id` attribute.\\
## Code: 
```
void setId(int id) throws EntityException {
		if(id <= 0)
			throw new EntityException("Invoice ID negative or zero");
		this.id = id;
	}
```