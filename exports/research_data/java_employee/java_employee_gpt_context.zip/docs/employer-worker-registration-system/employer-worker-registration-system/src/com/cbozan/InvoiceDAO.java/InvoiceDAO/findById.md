`findById`: The function of `findById` is to retrieve an `Invoice` object by its unique identifier (ID) from a cache or database.

**Parameters**:\
`int id`: The unique identifier of the `Invoice` to be retrieved.

**Code Description**: The `findById` method first checks if the cache is being used. If the cache is not being used (`usingCache == false`), it calls the `list` method to populate the cache with `Invoice` objects from the database. Then, it checks if the cache contains an `Invoice` with the specified ID. If the cache contains the `Invoice`, it returns the `Invoice` object from the cache. If the cache does not contain the `Invoice`, it returns `null`.\\
## Code: 
```
Invoice findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
	}
```