`JobDAO`: The function of `JobDAO` is to manage the CRUD (Create, Read, Update, Delete) operations for `Job` objects in the database, utilizing caching to improve performance.

**Code Description**: 
- **Attributes**:
  - `cache`: A `HashMap` that stores `Job` objects with their IDs as keys to improve retrieval performance.
  - `usingCache`: A boolean flag indicating whether caching is enabled.
  
- **Constructor**:
  - `JobDAO()`: Private constructor that initializes the `JobDAO` instance and populates the cache by calling the `list` method.

- **Methods**:
  - `findById(int id)`: Retrieves a `Job` object by its ID from the cache. If caching is disabled, it repopulates the cache by calling `list()`.
  - `refresh()`: Temporarily disables caching, repopulates the cache by calling `list()`, and then re-enables caching.
  - `list(Employer employer)`: Retrieves a list of `Job` objects associated with a given employer from the database, building and caching `Job` objects as needed.
  - `list()`: Retrieves a list of all `Job` objects from the database, utilizing the cache if available. It constructs `Job` objects using a `JobBuilder` and handles any SQL or entity exceptions that occur.
  - `create(Job job)`: Inserts a new `Job` into the database and updates the cache with the newly created job if the insertion is successful. It performs a control check before insertion and handles SQL exceptions by displaying detailed error messages.
  - `createControl(Job job)`: Checks if a job with the same title already exists in the cache. If a duplicate is found, it sets an error message and returns `false`; otherwise, it returns `true`.
  - `update(Job job)`: Updates an existing job record in the database with new details and caches the updated job if the update is successful. It returns `true` if the update is successful and `false` otherwise.
  - `updateControl(Job job)`: Checks if a job with the same title but a different ID already exists in the cache. If such a job is found, it sets an error message and returns `false`; otherwise, it returns `true`.
  - `delete(Job job)`: Deletes a job entry from the database based on the job's ID and removes the job from the cache if the deletion is successful.\\
## Code: 
```
class JobDAO {
	
	private final HashMap<Integer, Job> cache = new HashMap<>();
	private boolean usingCache = true;
	
	private JobDAO() {list();}
	
	// Read by id
	public Job findById(int id) {
		
		if(usingCache == false)
			list();
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
	
	public void refresh() {
		setUsingCache(false);
		list();
		setUsingCache(true);
	}
	
	public List<Job> list(Employer employer){

		List<Job> jobList = new ArrayList<>();
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM job WHERE employer_id=" + employer.getId();
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			JobBuilder builder = new JobBuilder();
			Job job;
			
			while(rs.next()) {
				
				job = findById(rs.getInt("id"));
				if(job != null) { // cache control
					jobList.add(job);
				} else {
					
					builder.setId(rs.getInt("id"));
					builder.setEmployer_id(rs.getInt("employer_id"));
					builder.setPrice_id(rs.getInt("price_id"));
					builder.setTitle(rs.getString("title"));
					builder.setDescription(rs.getString("description"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						job = builder.build();
						jobList.add(job);
						cache.put(job.getId(), job);
					} catch (EntityException e) {
						showEntityException(e, "İŞ EKLEME HATASI");
					}
					
				}
			
			}
			
		} catch(SQLException sqle) {
			showSQLException(sqle);
		}
		
		return jobList;
		
	}
	
	
	//Read All
	public List<Job> list(){
		
		List<Job> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Job> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM job;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			JobBuilder builder;
			Job job;
			
			while(rs.next()) {
				
				builder = new JobBuilder();
				builder.setId(rs.getInt("id"));
				builder.setEmployer_id(rs.getInt("employer_id"));
				builder.setPrice_id(rs.getInt("price_id"));
				builder.setTitle(rs.getString("title"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					job = builder.build();
					list.add(job);
					cache.put(job.getId(), job);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id") + " Title : " + rs.getString("title"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
	}
	
	
	public boolean create(Job job) {
		
		if(createControl(job) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO job (employer_id,price_id,title,description) VALUES (?,?,?,?);";
		String query2 = "SELECT * FROM job ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, job.getEmployer().getId());
			pst.setInt(2, job.getPrice().getId());
			pst.setString(3, job.getTitle());
			pst.setString(4, job.getDescription());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					JobBuilder builder = new JobBuilder();
					builder.setId(rs.getInt("id"));
					builder.setEmployer_id(rs.getInt("employer_id"));
					builder.setPrice_id(rs.getInt("price_id"));
					builder.setTitle(rs.getString("title"));
					builder.setDescription(rs.getString("description"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Job obj = builder.build();
						cache.put(obj.getId(), obj);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id") + " Title : " + rs.getString("title"));
					}
				}
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
	
	private boolean createControl(Job job) {
		
		for(Entry<Integer, Job> obj : cache.entrySet()) {
			if(obj.getValue().getTitle().equals(job.getTitle())) {
				DB.ERROR_MESSAGE = obj.getValue().getTitle() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
	
	
	public boolean update(Job job) {
		
		if(updateControl(job) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE job SET employer_id=?,"
				+ "price_id=?, title=?, description=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, job.getEmployer().getId());
			pst.setInt(2, job.getPrice().getId());
			pst.setString(3, job.getTitle());
			pst.setString(4, job.getDescription());
			pst.setInt(5, job.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(job.getId(), job);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
	
	private boolean updateControl(Job job) {
		for(Entry<Integer, Job> obj : cache.entrySet()) {
			if(obj.getValue().getTitle().equals(job.getTitle()) && obj.getValue().getId() != job.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getTitle() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
	
	
	public boolean delete(Job job) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM job WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, job.getId());
			
			result = ps.executeUpdate();
			
			if(result != 0) {
				cache.remove(job.getId());
			}

		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
		
	}
	
	public boolean isUsingCache() {
		return this.usingCache;
	}
	
	public void setUsingCache(boolean usingCache) {
		this.usingCache = usingCache;
	}

	
	private static class JobDAOHelper {
		private static final JobDAO instance = new JobDAO();
	}
	
	public static JobDAO getInstance() {
		return JobDAOHelper.instance;
	}
	
	private void showEntityException(EntityException e, String msg) {
		String message = msg + " not added" + 
				"\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + e.getCause();
			JOptionPane.showMessageDialog(null, message);
	}
	
	private void showSQLException(SQLException e) {
		String message = e.getErrorCode() + "\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + "\n" + e.getCause();
		JOptionPane.showMessageDialog(null, message);
	}
}
```