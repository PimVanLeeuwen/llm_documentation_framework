`actionPerformed`: The function of `actionPerformed` is to handle the event when the `takePaymentButton` is clicked, validate the input, and process the payment for a selected job.

**Parameters**:\
`ActionEvent e`: The event that triggers this method, typically a button click.

**Code Description**: 
The `actionPerformed` method first checks if the source of the event is the `takePaymentButton`. If so, it retrieves the selected job and the amount entered by the user, removing any whitespace from the amount. It then validates the amount to ensure it is a properly formatted decimal number with up to two decimal places and checks if a job is selected. If the validation fails, it displays an error message to the user.

If the validation passes, it creates a confirmation dialog displaying the job details and the payment amount. If the user confirms the action by clicking "SAVE", it builds an `Invoice` object using the provided job and amount. The method then attempts to save the invoice to the database using `InvoiceDAO`. If the save operation is successful, it displays a success message and notifies all observers. If the save operation fails, it displays an error message indicating a database error.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		if(e.getSource() == takePaymentButton) {
			
			Job job;
			String amount;
			
			job = selectedJob;
			amount = amountTextField.getText().replaceAll("\\s+", "");

			if(!decimalControl(amount) || job == null) {
				
				String message;
				message = "Please enter job selection section or format correctly (max 2 floating point)";
				JOptionPane.showMessageDialog(this, message, "ERROR", JOptionPane.ERROR_MESSAGE);
				
			} else {
				
				JTextArea jobTextArea, amountTextArea;
				
				jobTextArea = new JTextArea(job.toString());
				jobTextArea.setEditable(false);
				
				amountTextArea = new JTextArea(amount + " ₺");
				amountTextArea.setEditable(false);
				
				Object[] pane = {
						new JLabel("Job"),
						jobTextArea,
						new JLabel("Amount of payment"),
						amountTextArea
				};
		
				int result = JOptionPane.showOptionDialog(this, pane, "Confirmation", 1, 1, 
						new ImageIcon("src\\icon\\accounting_icon_1_32.png"), new Object[] {"SAVE", "CANCEL"}, "CANCEL");
				
				
				// System.out.println(result);
				// 0 -> SAVE
				// 1 -> CANCEL
				
				if(result == 0) {
					
					Invoice.InvoiceBuilder builder = new Invoice.InvoiceBuilder();
					builder.setId(Integer.MAX_VALUE);
					builder.setJob(selectedJob);
					builder.setAmount(new BigDecimal(amount));
					
					Invoice invoice = null;
					try {
						invoice = builder.build();
					} catch (EntityException e1) {
						System.out.println(e1.getMessage());
					}
					
					if(InvoiceDAO.getInstance().create(invoice)) { 
						JOptionPane.showMessageDialog(this, "Registration successful");
						notifyAllObservers();
					} else {
						JOptionPane.showMessageDialog(this, "Not saved", "DataBase error", JOptionPane.ERROR_MESSAGE);
					}
				}
				
			}
			
		}
		
	}
```