`getFname`: The function of `getFname` is to return the first name of the employer.

**Code Description**: This method, `getFname`, is a public method that returns a `String` value representing the first name (`fname`) of the employer. It does not take any parameters and simply returns the value of the `fname` attribute of the `Employer` object.\\
## Code: 
```
String getFname() {
		return fname;
	}
```