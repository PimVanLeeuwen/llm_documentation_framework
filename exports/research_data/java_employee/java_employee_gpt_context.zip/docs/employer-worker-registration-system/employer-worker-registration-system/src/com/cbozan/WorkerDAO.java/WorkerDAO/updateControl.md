`updateControl`: The function of `updateControl` is to check if a worker with the same first name and last name but a different ID already exists in the cache.

**Parameters**:\
`Worker worker`: The worker object that needs to be checked for duplicate entries in the cache.

**Code Description**: The `updateControl` method iterates through the `cache` which is a collection of worker entries. For each entry, it compares the first name and last name of the worker in the cache with the first name and last name of the provided worker object. If a match is found and the IDs are different, it sets an error message indicating that a worker with the same name already exists and returns `false`. If no such duplicate is found, it returns `true`.\\
## Code: 
```
boolean updateControl(Worker worker) {
		for(Entry<Integer, Worker> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(worker.getFname()) 
					&& obj.getValue().getLname().equals(worker.getLname())
					&& obj.getValue().getId() != worker.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```