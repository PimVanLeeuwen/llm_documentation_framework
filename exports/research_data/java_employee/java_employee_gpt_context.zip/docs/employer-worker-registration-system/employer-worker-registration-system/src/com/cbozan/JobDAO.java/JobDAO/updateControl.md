`updateControl`: The function of `updateControl` is to check if a job with the same title already exists in the cache, excluding the job with the same ID as the one being checked.

**Parameters**:\
`Job job`: The job object that needs to be checked for duplicate titles in the cache.

**Code Description**: The `updateControl` method iterates through the entries in the `cache` map, which stores job objects. For each entry, it compares the title of the job in the cache with the title of the provided job object. If a job with the same title is found and its ID is different from the provided job's ID, it sets an error message in the `DB` class indicating that the job title already exists and returns `false`. If no such duplicate is found, it returns `true`.\\
## Code: 
```
boolean updateControl(Job job) {
		for(Entry<Integer, Job> obj : cache.entrySet()) {
			if(obj.getValue().getTitle().equals(job.getTitle()) && obj.getValue().getId() != job.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getTitle() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```