`getEmployerSearchBoxObject`: The function of `getEmployerSearchBoxObject` is to retrieve the currently selected `Employer` object from the `employerSearchBox`.

**Code Description**: This method, `getEmployerSearchBoxObject`, calls the `getSelectedObject` method on the `employerSearchBox` instance, which returns the currently selected object. It then casts this object to an `Employer` type and returns it. This allows the caller to obtain the `Employer` that is currently selected in the `employerSearchBox`.\\
## Code: 
```
Employer getEmployerSearchBoxObject() {
		return (Employer) employerSearchBox.getSelectedObject();
	}
```