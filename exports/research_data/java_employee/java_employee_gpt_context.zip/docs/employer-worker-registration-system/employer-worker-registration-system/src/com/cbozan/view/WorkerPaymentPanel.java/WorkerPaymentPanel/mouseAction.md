`mouseAction`: The function of `mouseAction` is to handle mouse events, update the job-related fields with the selected job, and refresh the data displayed in the panel.

**Parameters**:\
`MouseEvent e`: The mouse event that triggered this action. \
`Object searchResultObject`: The object representing the search result, which is expected to be a `Job` instance. \
`int chooseIndex`: The index of the chosen item in the search results.

**Code Description**: This method is triggered by a mouse event. It casts the `searchResultObject` to a `Job` and updates the `jobSearchBox` and `jobTextField` with the string representation of the selected job. It then sets the `jobSearchBox` to be non-editable and calls the `refreshData` method to update the panel with the new job information. Finally, it calls the superclass's `mouseAction` method to ensure any additional behavior defined in the superclass is executed.\\
## Code: 
```
void mouseAction(MouseEvent e, Object searchResultObject, int chooseIndex) {
				selectedJob = (Job) searchResultObject;
				jobSearchBox.setText(searchResultObject.toString());
				jobTextField.setText(searchResultObject.toString());
				jobSearchBox.setEditable(false);
				refreshData();
				super.mouseAction(e, searchResultObject, chooseIndex);
			}
```