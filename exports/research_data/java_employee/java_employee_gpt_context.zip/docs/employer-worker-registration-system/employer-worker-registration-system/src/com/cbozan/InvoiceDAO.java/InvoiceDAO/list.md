`list`: The function of `list` is to retrieve a list of `Invoice` objects from the database based on a specified column name and its corresponding integer value.

**Parameters**:\
`String columnName`: The name of the column in the `invoice` table to filter the results by.\
`int id`: The integer value used to filter the results in the specified column.

**Code Description**: This method establishes a connection to the database and executes a SQL query to select all rows from the `invoice` table where the specified column matches the given integer value. It iterates through the result set, creating `Invoice` objects using the `InvoiceBuilder` class, and adds them to a list. If an `EntityException` occurs during the building of an `Invoice`, it logs the error and skips adding that invoice to the list. Finally, it returns the list of `Invoice` objects.\\
## Code: 
```
List<Invoice> list(String columnName, int id){
		
		List<Invoice> list = new ArrayList<>();
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM invoice WHERE " + columnName + "=" + id;
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			InvoiceBuilder builder;
			Invoice invoice;
			
			while(rs.next()) {
				
				builder = new InvoiceBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setAmount(rs.getBigDecimal("amount"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					invoice = builder.build();
					list.add(invoice);
				} catch (EntityException e) {
					System.err.println(e.getMessage());
					System.out.println("!! Invoice not added list !!");
				}
				
			}
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return list;
	}
```