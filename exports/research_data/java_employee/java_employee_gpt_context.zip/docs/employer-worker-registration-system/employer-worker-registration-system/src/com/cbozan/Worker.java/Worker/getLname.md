`getLname`: The function of `getLname` is to return the last name of the worker.

**Code Description**: The `getLname` method is a public method that returns a `String` representing the last name (`lname`) of the worker. This method does not take any parameters and simply returns the value of the `lname` field, which is presumably a private member variable of the `Worker` class.\\
## Code: 
```
String getLname() {
		return lname;
	}
```