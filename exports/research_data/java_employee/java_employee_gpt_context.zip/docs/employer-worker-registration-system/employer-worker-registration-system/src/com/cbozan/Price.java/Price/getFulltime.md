`getFulltime`: The function of `getFulltime` is to return the value of the `fulltime` attribute.

**Code Description**: This method, `getFulltime`, is a getter that retrieves the value of the `fulltime` attribute, which is of type `BigDecimal`. It does not take any parameters and simply returns the `fulltime` value when called.\\
## Code: 
```
BigDecimal getFulltime() {
		return fulltime;
	}
```