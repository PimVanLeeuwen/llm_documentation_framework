`GUI`: The function of `GUI` is to initialize the graphical user interface of the application.

**Code Description**: The `GUI` method is responsible for setting up the main graphical user interface of the application. It does this by calling two other methods: `createMenus` and `createComponents`. The `createMenus` method sets up the menu bar with various menus and menu items, each with specific actions. The `createComponents` method initializes different panels related to jobs, workers, employers, and payments, and adds them to the main frame. The `init` method, which is currently commented out, is likely intended for additional initialization tasks.\\
## Code: 
```
void GUI() {
		createMenus();
		createComponents();
		//init();
		
	}
```