`getLname`: The function of `getLname` is to retrieve the last name of the employer.

**Code Description**: This method, `getLname`, is a public method that returns a `String` value representing the last name (`lname`) of the employer. It does not take any parameters and simply returns the value of the `lname` attribute of the `Employer` class.\\
## Code: 
```
String getLname() {
		return lname;
	}
```