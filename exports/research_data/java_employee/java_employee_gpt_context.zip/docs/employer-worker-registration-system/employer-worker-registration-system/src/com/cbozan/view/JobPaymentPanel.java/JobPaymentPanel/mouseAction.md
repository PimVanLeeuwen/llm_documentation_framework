`mouseAction`: The function of `mouseAction` is to handle mouse events and update the job payment panel with the selected job's details.

**Parameters**:\
`MouseEvent e`: The mouse event that triggered this action.\
`Object searchResultObject`: The object resulting from a search, expected to be of type `Job`.\
`int chooseIndex`: The index of the chosen item in the search results.

**Code Description**: This method updates the job payment panel when a job is selected from the search results. It casts the `searchResultObject` to a `Job` object and assigns it to `selectedJob`. It then updates the `searchJobSearchBox` to display the selected job's string representation and makes it non-editable. The `jobTitleTextField` and `employerTextField` are updated with the selected job's details. The `clearPanel` method is called to reset other parts of the panel, and finally, the superclass's `mouseAction` method is called to handle any additional actions.\\
## Code: 
```
void mouseAction(MouseEvent e, Object searchResultObject, int chooseIndex) {
				selectedJob = (Job) searchResultObject;
				searchJobSearchBox.setText(searchResultObject.toString());
				searchJobSearchBox.setEditable(false);
				jobTitleTextField.setText(selectedJob.toString());
				employerTextField.setText(selectedJob.getEmployer().toString());
				clearPanel();
				super.mouseAction(e, searchResultObject, chooseIndex);
			}
```