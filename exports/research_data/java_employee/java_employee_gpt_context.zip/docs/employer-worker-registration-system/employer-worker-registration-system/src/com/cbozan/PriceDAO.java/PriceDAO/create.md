`create`: The function of `create` is to insert a new `Price` record into the database and update the cache with the newly created `Price` object if the insertion is successful.

**Parameters**:\
`Price price`: The `Price` object containing the `fulltime`, `halftime`, and `overtime` values to be inserted into the database.

**Code Description**: The `create` method first checks if the `Price` object already exists in the cache using the `createControl` method. If the `Price` object is found in the cache, the method returns `false`. If not, it proceeds to insert the `Price` object into the database. It establishes a database connection using the `DB.getConnection` method and prepares an SQL `INSERT` statement to add the `fulltime`, `halftime`, and `overtime` values from the `Price` object. After executing the `INSERT` statement, it checks if the insertion was successful. If successful, it retrieves the newly inserted `Price` record using an SQL `SELECT` statement and constructs a `Price` object using the `PriceBuilder`. The newly created `Price` object is then added to the cache. If any `SQLException` occurs during the process, the `showSQLException` method is called to display the error details. The method returns `true` if the insertion was successful and `false` otherwise.\\
## Code: 
```
boolean create(Price price) {
		
		if(createControl(price) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO price (fulltime,halftime,overtime) VALUES (?,?,?);";
		String query2 = "SELECT * FROM price ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			
			pst.setBigDecimal(1, price.getFulltime());
			pst.setBigDecimal(2, price.getHalftime());
			pst.setBigDecimal(3, price.getOvertime());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					PriceBuilder builder = new PriceBuilder();
					builder.setId(rs.getInt("id"));
					builder.setFulltime(rs.getBigDecimal("fulltime"));
					builder.setHalftime(rs.getBigDecimal("halftime"));
					builder.setOvertime(rs.getBigDecimal("overtime"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Price prc = builder.build();
						cache.put(prc.getId(), prc);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id"));
					}
					
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```