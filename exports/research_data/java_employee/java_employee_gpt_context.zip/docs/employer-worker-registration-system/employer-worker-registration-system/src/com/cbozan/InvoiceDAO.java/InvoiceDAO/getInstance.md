`getInstance`: The function of `getInstance` is to provide a globally accessible instance of the `InvoiceDAO` class.

**Code Description**: The `getInstance` method returns the singleton instance of the `InvoiceDAO` class by accessing the `instance` field of the nested `InvoiceDAOHelper` class. This ensures that only one instance of `InvoiceDAO` is created and used throughout the application.\\
## Code: 
```
InvoiceDAO getInstance() {
		return InvoiceDAOHelper.instance;
	}
```