`clearPanel`: The function of `clearPanel` is to reset the input fields and update the table with the latest invoice data for the selected job.

**Code Description**: The `clearPanel` method performs the following actions:
1. Clears the text in the `amountTextField` and resets its border color to white.
2. Resets the foreground color of the `amountLabel` to its default color.
3. If a job is selected (`selectedJob` is not null), it retrieves a list of invoices associated with the selected job using the `InvoiceDAO` class.
4. Formats the invoice data into a table-friendly format, including the invoice ID, amount (formatted with a currency symbol), and date.
5. Updates the table model of the `lastPaymentsScroll` component with the new invoice data.
6. Adjusts the column widths and sets the cell renderer to center-align the text in the table columns.\\
## Code: 
```
void clearPanel() {
		
		amountTextField.setText("");
		amountTextField.setBorder(new LineBorder(Color.white));
		amountLabel.setForeground(defaultColor);
		
		
		if(selectedJob != null) {
			
			List<Invoice> invoiceList = InvoiceDAO.getInstance().list("job_id", selectedJob.getId());
			String[][] tableData = new String[invoiceList.size()][invoiceTableColumns.length];
			int i = 0;
			for(Invoice invoice : invoiceList) {
				tableData[i][0] = invoice.getId() + "";
				tableData[i][1] = NumberFormat.getInstance().format(invoice.getAmount()) + " ₺";
				tableData[i][2] = new SimpleDateFormat("dd.MM.yyyy").format(invoice.getDate()); 
				++i;
			}
			
			((JTable)lastPaymentsScroll.getViewport().getComponent(0)).setModel(new DefaultTableModel(tableData, invoiceTableColumns));
			((JTable)lastPaymentsScroll.getViewport().getComponent(0)).getColumnModel().getColumn(0).setPreferredWidth(5);
			((JTable)lastPaymentsScroll.getViewport().getComponent(0)).setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
			
			DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
			centerRenderer.setHorizontalAlignment( SwingConstants.CENTER );
			((JTable)lastPaymentsScroll.getViewport().getComponent(0)).getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
			((JTable)lastPaymentsScroll.getViewport().getComponent(0)).getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
			((JTable)lastPaymentsScroll.getViewport().getComponent(0)).getColumnModel().getColumn(2).setCellRenderer(centerRenderer);
		}
		
		
	}
```