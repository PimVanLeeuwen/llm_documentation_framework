`getDate`: The function of `getDate` is to retrieve the date associated with the invoice.

**Code Description**: This method, `getDate`, returns a `Timestamp` object representing the date stored in the `date` field of the `Invoice` class. It does not take any parameters and simply provides access to the `date` value when called.\\
## Code: 
```
Timestamp getDate() {
		return date;
	}
```