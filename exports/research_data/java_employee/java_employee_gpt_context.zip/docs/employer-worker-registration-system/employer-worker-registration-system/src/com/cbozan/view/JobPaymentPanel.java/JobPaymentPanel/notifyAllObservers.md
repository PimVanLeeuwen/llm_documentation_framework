`notifyAllObservers`: The function of `notifyAllObservers` is to inform all registered observers about a change or event.

**Code Description**: The `notifyAllObservers` method iterates through a list of `Observer` objects stored in the `observers` collection and calls the `update` method on each one. This ensures that all observers are notified and can refresh or update their state accordingly.\\
## Code: 
```
void notifyAllObservers() {
		for(Observer observer : observers) {
			observer.update();
		}
	}
```