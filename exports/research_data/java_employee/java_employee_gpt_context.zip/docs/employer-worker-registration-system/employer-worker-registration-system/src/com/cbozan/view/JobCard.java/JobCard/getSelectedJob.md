`getSelectedJob`: The function of `getSelectedJob` is to return the currently selected job.

**Code Description**: This method, `getSelectedJob`, is a simple getter that returns the value of the `selectedJob` field. The `selectedJob` is presumably an instance of the `Job` class, and this method allows other parts of the program to access the currently selected job.\\
## Code: 
```
Job getSelectedJob() {
		return selectedJob;
	}
```