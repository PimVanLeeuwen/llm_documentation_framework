`getPriceSearchBoxObject`: The function of `getPriceSearchBoxObject` is to retrieve the currently selected `Price` object from the `priceSearchBox`.

**Code Description**: This method calls the `getSelectedObject` method on the `priceSearchBox` object, which returns the currently selected item. It then casts this item to a `Price` object and returns it. This allows the caller to obtain the `Price` object that is currently selected in the `priceSearchBox`.\\
## Code: 
```
Price getPriceSearchBoxObject() {
		return (Price) priceSearchBox.getSelectedObject();
	}
```