`create`: The function of `create` is to insert a new invoice record into the database and update the cache with the newly created invoice.

**Parameters**:\
`Invoice invoice`: An `Invoice` object containing the details of the invoice to be created, including the job ID and the amount.

**Code Description**: This method starts by establishing a connection to the database using the `DB.getConnection` method. It then prepares an SQL `INSERT` statement to add a new invoice record with the job ID and amount from the provided `Invoice` object. The `executeUpdate` method is called to execute the insertion, and the result is checked to ensure the operation was successful.

If the insertion is successful, a second query is executed to retrieve the most recently added invoice record. The result set from this query is used to build a new `Invoice` object using the `InvoiceBuilder` class. The newly created `Invoice` object is then added to the cache.

If any `SQLException` occurs during the process, the `showSQLException` method is called to display the error details. The method returns `true` if the insertion was successful and `false` otherwise.\\
## Code: 
```
boolean create(Invoice invoice) {
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO invoice (job_id,amount) VALUES (?,?);";
		String query2 = "SELECT * FROM invoice ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, invoice.getJob().getId());
			pst.setBigDecimal(2, invoice.getAmount());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					InvoiceBuilder builder = new InvoiceBuilder();
					builder.setId(rs.getInt("id"));
					builder.setJob_id(rs.getInt("job_id"));
					builder.setAmount(rs.getBigDecimal("amount"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Invoice inv = builder.build();
						cache.put(inv.getId(), inv);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id"));
					}
					
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```