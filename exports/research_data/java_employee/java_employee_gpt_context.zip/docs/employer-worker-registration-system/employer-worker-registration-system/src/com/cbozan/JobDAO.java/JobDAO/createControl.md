`createControl`: The function of `createControl` is to check if a job with the same title already exists in the cache.

**Parameters**:\
`Job job`: The job object that needs to be checked for duplication in the cache.

**Code Description**: The `createControl` method iterates through the entries in the `cache` map. For each entry, it compares the title of the job in the cache with the title of the job passed as a parameter. If a job with the same title is found, it sets an error message in the `DB` class indicating that the job already exists and returns `false`. If no duplicate job title is found, it returns `true`.\\
## Code: 
```
boolean createControl(Job job) {
		
		for(Entry<Integer, Job> obj : cache.entrySet()) {
			if(obj.getValue().getTitle().equals(job.getTitle())) {
				DB.ERROR_MESSAGE = obj.getValue().getTitle() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```