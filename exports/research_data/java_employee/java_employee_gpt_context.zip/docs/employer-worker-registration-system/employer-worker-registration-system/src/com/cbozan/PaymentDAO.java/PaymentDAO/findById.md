`findById`: The function of `findById` is to retrieve a `Payment` object by its unique identifier (ID) from the cache or database.

**Parameters**:\
`int id`: The unique identifier of the `Payment` object to be retrieved.

**Code Description**: The `findById` method first checks if the cache is being used. If the cache is not being used (`usingCache == false`), it calls the `list` method to populate the cache with `Payment` objects from the database. Then, it checks if the cache contains a `Payment` object with the specified ID. If the object is found in the cache, it returns the `Payment` object; otherwise, it returns `null`.\\
## Code: 
```
Payment findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```