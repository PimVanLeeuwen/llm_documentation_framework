`GUI`: The function of `GUI` is to set up and display the login interface for the employer-worker registration system.

**Code Description**: 
The `GUI` method initializes and configures the graphical user interface components for the login screen. It sets up a `JPanel` as the content pane and arranges various elements within it, including labels, text fields, buttons, and an icon. 

1. **Content Pane**: A `JPanel` is created and set with a null layout. Its bounds are defined based on the frame's insets and dimensions.
2. **Username Label**: A `JLabel` for the username is created, styled with a specific font, and positioned on the panel.
3. **Password Label**: Another `JLabel` for the password is created, styled similarly to the username label, and positioned below it.
4. **Username TextField**: A `JTextField` for entering the username is created and positioned next to the username label. An `ActionListener` is added to move the focus to the password field when the user presses Enter.
5. **Password Field**: A `JPasswordField` for entering the password is created and positioned next to the password label. An `ActionListener` is added to trigger the login button when the user presses Enter.
6. **Login Button**: A `JButton` for submitting the login credentials is created and positioned below the text fields. An `ActionListener` is added to handle the login process:
   - It checks if the username or password fields are empty and displays an error message if they are.
   - If both fields are filled, it verifies the credentials using `LoginDAO`.
   - If the credentials are correct, a success message is displayed, and the main application frame is launched.
   - If the credentials are incorrect, an error message is displayed.
7. **Icon Label**: A `JLabel` with an icon is added above the text fields for visual enhancement.
8. **Error Text Label**: A `JLabel` for displaying error messages is created, styled with a red font, and positioned below the login button.

Finally, the configured `contentPane` is set as the content pane of the frame.\\
## Code: 
```
void GUI() {
		
		contentPane = new JPanel();
		contentPane.setLayout(null);
		contentPane.setBounds(insets.left, insets.top, W_FRAME - insets.left - insets.right, 
				H_FRAME - insets.bottom - insets.top);
	
		label_username = new JLabel("Username");
		label_username.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_username.setBounds(120, 140, 70, 20);
		contentPane.add(label_username);
		
		label_password = new JLabel("Password");
		label_password.setFont(label_username.getFont());
		label_password.setBounds(label_username.getX(), label_username.getY() + 40, 
				label_username.getWidth(), label_username.getHeight());
		contentPane.add(label_password);
		
		textField_username = new JTextField();
		textField_username.setBounds(label_username.getX() + label_username.getWidth() + 30, 
				label_username.getY(), 120, label_username.getHeight());
		textField_username.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				passwordField_password.requestFocus();
			}
		});
		contentPane.add(textField_username);
		
		passwordField_password = new JPasswordField();
		passwordField_password.setBounds(textField_username.getX(), label_password.getY(), 
				120, label_password.getHeight());
		passwordField_password.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				button_login.doClick();
			}
		});
		contentPane.add(passwordField_password);
		
		button_login = new JButton("Login");
		button_login.setBounds(textField_username.getX() + 20, label_username.getY() + 80, 80, 22);
		button_login.setFocusPainted(false);
		button_login.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
		
				if(textField_username.getText().equals("") || String.valueOf(passwordField_password.getPassword()).equals("")) {
					
					label_errorText.setText(errorText);
				
				} else {
					
					label_errorText.setText("");
					LoginDAO loginDAO = new LoginDAO();
					if(loginDAO.verifyLogin(textField_username.getText(), 
							String.valueOf(passwordField_password.getPassword()))) {
						JOptionPane.showMessageDialog(contentPane, "Login successful. Welcome", "Login", 
								JOptionPane.INFORMATION_MESSAGE);
						
						EventQueue.invokeLater(new Runnable() {
							@Override
							public void run() {
								Login.this.dispose();
								new MainFrame();
							}
						});
						
					} else {
						label_errorText.setText(errorText);
					}
					
				}
				
			}
		});
		contentPane.add(button_login);
		
		label_icon = new JLabel(new ImageIcon("src\\icon\\Login_user_72.png"));
		label_icon.setBounds(textField_username.getX() + 20, textField_username.getY() - 100, 72, 72);
		contentPane.add(label_icon);
		
		label_errorText = new JLabel();
		label_errorText.setForeground(Color.RED);
		label_errorText.setBounds(button_login.getX() - 45, button_login.getY() + 30, 
				170, 30);
		label_errorText.setFont(new Font("Tahoma", Font.PLAIN + Font.BOLD, 11));
		contentPane.add(label_errorText);
		
		setContentPane(contentPane);
		
	}
```