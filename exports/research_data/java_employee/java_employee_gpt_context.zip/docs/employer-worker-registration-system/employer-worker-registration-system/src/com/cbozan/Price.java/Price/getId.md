`getId`: The function of `getId` is to return the value of the `id` field of the `Price` object.

**Code Description**: This method, `getId`, is a simple getter that retrieves the value of the private instance variable `id` from the `Price` class. When called, it returns the integer value stored in the `id` field. This is typically used to access the `id` of a `Price` object from outside the class while maintaining encapsulation.\\
## Code: 
```
int getId() {
		return id;
	}
```