`setFname`: The function of `setFname` is to set the first name of an employer while ensuring it meets specific length constraints.
**Parameters**:\
`String fname`: The first name of the employer to be set. It must not be empty and must not exceed the maximum length defined by `DBConst.FNAME_LENGTH`.

**Code Description**: The `setFname` method first checks if the provided `fname` is either empty or exceeds the maximum allowed length specified by `DBConst.FNAME_LENGTH`. If either condition is true, it throws an `EntityException` with the message "Employer name empty or too long". If the `fname` is valid, it assigns the value to the instance variable `fname`.\\
## Code: 
```
void setFname(String fname) throws EntityException {
		if(fname.length() == 0 || fname.length() > DBConst.FNAME_LENGTH)
			throw new EntityException("Employer name empty or too long");
		this.fname = fname;
	}
```