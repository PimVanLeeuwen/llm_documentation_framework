`setWorker`: The function of `setWorker` is to assign a `Worker` object to the `worker` attribute of the `Work` class, ensuring that the `Worker` object is not null.

**Parameters**:\
`Worker worker`: The `Worker` object to be assigned to the `worker` attribute of the `Work` class. This parameter must not be null.

**Code Description**: The `setWorker` method first checks if the provided `worker` parameter is null. If it is null, the method throws an `EntityException` with the message "Worker in Work is null". If the `worker` parameter is not null, the method assigns the provided `Worker` object to the `worker` attribute of the `Work` class.\\
## Code: 
```
void setWorker(Worker worker) throws EntityException {
		if(worker == null)
			throw new EntityException("Worker in Work is null");
		this.worker = worker;
	}
```