`EmptyInstanceSingleton`: The function of `EmptyInstanceSingleton` is to provide a single, globally accessible instance of the `Invoice` class.

**Code Description**: The `EmptyInstanceSingleton` class contains a private static final field named `instance` which holds a single instance of the `Invoice` class. This ensures that only one instance of `Invoice` is created and can be accessed globally within the application. The singleton pattern is used here to control the instantiation of the `Invoice` class, ensuring that the same instance is reused throughout the application.\\
## Code: 
```
class EmptyInstanceSingleton{
		private static final Invoice instance = new Invoice(); 
	}
```