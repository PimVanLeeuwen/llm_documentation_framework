`create`: The function of `create` is to insert a new `Workgroup` record into the database and update the cache with the newly created `Workgroup` object.

**Parameters**:\
`Workgroup workgroup`: The `Workgroup` object containing the details to be inserted into the database.

**Code Description**: The `create` method starts by establishing a connection to the database using the `DB.getConnection` method. It then prepares an SQL `INSERT` statement to add a new record to the `workgroup` table with the provided `job_id`, `worktype_id`, `workcount`, and `description` from the `workgroup` object. After executing the `INSERT` statement, it checks if the insertion was successful by evaluating the result. If successful, it retrieves the most recently added `workgroup` record using a `SELECT` query ordered by `id` in descending order and limited to one result. The retrieved record is then used to build a new `Workgroup` object using the `WorkgroupBuilder` class. This new `Workgroup` object is added to the cache. If any SQL exceptions occur during the process, they are handled and displayed using the `showSQLException` method. The method returns `true` if the insertion was successful, otherwise `false`.\\
## Code: 
```
boolean create(Workgroup workgroup) {
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO workgroup (job_id,worktype_id,workcount,description) VALUES (?,?,?,?);";
		String query2 = "SELECT * FROM workgroup ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, workgroup.getJob().getId());
			pst.setInt(2, workgroup.getWorktype().getId());
			pst.setInt(3, workgroup.getWorkCount());
			pst.setString(4, workgroup.getDescription());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					WorkgroupBuilder builder = new WorkgroupBuilder();
					builder.setId(rs.getInt("id"));
					builder.setJob_id(rs.getInt("job_id"));
					builder.setWorktype_id(rs.getInt("worktype_id"));
					builder.setWorkCount(rs.getInt("workcount"));
					builder.setDescription(rs.getString("description"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Workgroup wg = builder.build();
						cache.put(wg.getId(), wg);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id"));
					}
					
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```