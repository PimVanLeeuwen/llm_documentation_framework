`setJob`: The function of `setJob` is to assign a `Job` object to the `Invoice` object.

**Parameters**:\
`Job job`: The `Job` object to be assigned to the `Invoice`. It must not be `null`.

**Code Description**: The `setJob` method first checks if the provided `Job` object is `null`. If it is, the method throws an `EntityException` with the message "Job in Invoice is null". If the `Job` object is not `null`, it assigns the `Job` object to the `job` attribute of the `Invoice` object.\\
## Code: 
```
void setJob(Job job) throws EntityException {
		if(job == null)
			throw new EntityException("Job in Invoice is null");
		this.job = job;
	}
```