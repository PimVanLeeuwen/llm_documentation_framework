`delete`: The function of `delete` is to remove a specified invoice from the database.

**Parameters**:\
`Invoice invoice`: The `Invoice` object that contains the details of the invoice to be deleted, specifically its ID.

**Code Description**: The `delete` method attempts to delete an invoice from the database using its ID. It first establishes a connection to the database using the `DB.getConnection` method. Then, it prepares a SQL `DELETE` statement with a placeholder for the invoice ID. The method sets the ID of the invoice to be deleted in the prepared statement and executes the update. If the deletion is successful (i.e., the result is not zero), it removes the invoice from the cache. The method returns `true` if the deletion was successful and `false` otherwise. If an `SQLException` occurs, it prints the error message and returns `false`.\\
## Code: 
```
boolean delete(Invoice invoice) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM invoice WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, invoice.getId());
			
			result = ps.executeUpdate();
			
			if(result != 0) {
				cache.remove(invoice.getId());
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return result == 0 ? false : true;
		
	}
```