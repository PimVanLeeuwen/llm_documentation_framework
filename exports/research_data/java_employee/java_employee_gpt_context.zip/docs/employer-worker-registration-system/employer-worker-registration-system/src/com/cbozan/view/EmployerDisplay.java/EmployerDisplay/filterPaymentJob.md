`filterPaymentJob`: The function of `filterPaymentJob` is to filter out invoices from the provided list that do not match the selected job.

**Parameters**:\
`List<Invoice> invoiceList`: A list of `Invoice` objects that need to be filtered based on the selected job.

**Code Description**: The `filterPaymentJob` method iterates through the provided list of invoices and removes any invoice whose associated job ID does not match the ID of the `selectedJob`. If `selectedJob` is `null`, the method returns immediately without making any changes to the list. The method uses an `Iterator` to safely remove elements from the list while iterating through it.\\
## Code: 
```
void filterPaymentJob(List<Invoice> invoiceList) {
		
		if(selectedJob == null)
			return;
		
		Iterator<Invoice> invoice = invoiceList.iterator();
		Invoice invoiceItem;
		while(invoice.hasNext()) {
			invoiceItem = invoice.next();
			if(invoiceItem.getJob().getId() != selectedJob.getId()) {
				invoice.remove();
			}
		}
		
	}
```