`decimalControl`: The function of `decimalControl` is to check if all provided strings match a given regular expression pattern.

**Parameters**:\
`Pattern pattern`: A compiled representation of a regular expression that will be used to match against the provided strings.\
`String ...args`: A variable number of string arguments that will be checked against the provided pattern.

**Code Description**: The method `decimalControl` takes a `Pattern` object and a variable number of string arguments. It initializes a boolean variable `rValue` to `true`. It then iterates over each string argument, using the `matcher` method of the `Pattern` object to create a `Matcher` for each string. The `find` method of the `Matcher` is called to check if the pattern matches any part of the string. The result of this check is combined with the current value of `rValue` using the bitwise AND assignment operator (`&=`). If all strings match the pattern, `rValue` remains `true`; otherwise, it becomes `false`. The method returns the final value of `rValue`.\\
## Code: 
```
boolean decimalControl(Pattern pattern, String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= pattern.matcher(arg).find();
		}
		return rValue;
	}
```