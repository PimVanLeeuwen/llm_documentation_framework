`WorkerDAO`: The function of `WorkerDAO` is to manage CRUD (Create, Read, Update, Delete) operations for `Worker` objects in a database, utilizing a cache to improve performance.

**Code Description**: 
- The `WorkerDAO` class is a singleton that manages `Worker` objects in a database.
- It uses a cache (`HashMap<Integer, Worker>`) to store `Worker` objects for quick access.
- The constructor initializes the cache by calling the `list` method.
- `findById(int id)`: Retrieves a `Worker` by its ID, using the cache if available.
- `refresh()`: Disables the cache, reloads the `Worker` list from the database, and re-enables the cache.
- `list()`: Retrieves all `Worker` objects from the database, populates the cache, and returns a list of `Worker` objects.
- `create(Worker worker)`: Inserts a new `Worker` into the database if it passes the `createControl` check, then caches the new `Worker`.
- `createControl(Worker worker)`: Checks for duplicate `Worker` entries in the cache based on first and last name.
- `update(Worker worker)`: Updates an existing `Worker` in the database and cache if it passes the `updateControl` check.
- `updateControl(Worker worker)`: Checks for duplicate `Worker` entries in the cache based on first and last name, excluding the current `Worker`.
- `delete(Worker worker)`: Deletes a `Worker` from the database and removes it from the cache.
- `WorkerDAOHelper`: Inner class that ensures a single instance of `WorkerDAO` is created.
- `getInstance()`: Returns the singleton instance of `WorkerDAO`.
- `isUsingCache()`: Returns whether the cache is being used.
- `setUsingCache(boolean usingCache)`: Enables or disables the use of the cache.
- `showEntityException(EntityException e, String msg)`: Displays an error message dialog for `EntityException`.
- `showSQLException(SQLException e)`: Displays an error message dialog for `SQLException`.\\
## Code: 
```
class WorkerDAO {
	
	private final HashMap<Integer, Worker> cache = new HashMap<>();
	private boolean usingCache = true;
	
	private WorkerDAO() {list();}
	
	// Read by id
	public Worker findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
	
	public void refresh() {
		setUsingCache(false);
		list();
		setUsingCache(true);
	}
	
	
	//Read All
	public List<Worker> list(){
		
		List<Worker> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Worker> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM worker;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorkerBuilder builder;
			Worker worker;
			
			while(rs.next()) {
				
				builder = new WorkerBuilder();
				builder.setId(rs.getInt("id"));
				builder.setFname(rs.getString("fname"));
				builder.setLname(rs.getString("lname"));
				
				if(rs.getArray("tel") == null)
					builder.setTel(null);
				else
					builder.setTel(Arrays.asList((String [])rs.getArray("tel").getArray()));
				
				builder.setIban(rs.getString("iban"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					worker = builder.build();
					list.add(worker);
					cache.put(worker.getId(), worker);
				} catch (EntityException e) {
					showEntityException(e, rs.getString("fname") + " " + rs.getShort("lname"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
		
	}
	
	
	public boolean create(Worker worker) {
		
		if(createControl(worker) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO worker (fname,lname,tel,iban,description) VALUES (?,?,?,?,?);";
		String query2 = "SELECT * FROM worker ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1, worker.getFname());
			pst.setString(2, worker.getLname());
			
			if(worker.getTel() == null)
				pst.setArray(3, null);
			else {
				java.sql.Array phones = conn.createArrayOf("VARCHAR", worker.getTel().toArray());
				pst.setArray(3, phones);
			}
			
			pst.setString(4, worker.getIban());
			pst.setString(5, worker.getDescription());
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					WorkerBuilder builder = new WorkerBuilder();
					builder = new WorkerBuilder();
					builder.setId(rs.getInt("id"));
					builder.setFname(rs.getString("fname"));
					builder.setLname(rs.getString("lname"));
					
					if(rs.getArray("tel") == null)
						builder.setTel(null);
					else
						builder.setTel(Arrays.asList((String [])rs.getArray("tel").getArray()));
					
					builder.setIban(rs.getString("iban"));
					builder.setDescription(rs.getString("description"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Worker wor = builder.build();
						cache.put(wor.getId(), wor);
					} catch (EntityException e) {
						showEntityException(e, rs.getString("fname") + " " + rs.getShort("lname"));
					}
					
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
	
	private boolean createControl(Worker worker) {
		for(Entry<Integer, Worker> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(worker.getFname()) && obj.getValue().getLname().equals(worker.getLname())) {
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
	
	public boolean update(Worker worker) {
		if(updateControl(worker) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE worker SET fname=?,"
				+ "lname=?, tel=?, iban=?, description=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1, worker.getFname());
			pst.setString(2, worker.getLname());
			
			java.sql.Array phones = conn.createArrayOf("VARCHAR", worker.getTel().toArray());
			pst.setArray(3, phones);
			
			pst.setString(4, worker.getIban());
			pst.setString(5, worker.getDescription());
			pst.setInt(6, worker.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(worker.getId(), worker);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
	
	private boolean updateControl(Worker worker) {
		for(Entry<Integer, Worker> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(worker.getFname()) 
					&& obj.getValue().getLname().equals(worker.getLname())
					&& obj.getValue().getId() != worker.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
	
	public boolean delete(Worker worker) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM worker WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, worker.getId());
			result = ps.executeUpdate();
			
			if(result != 0) {
				cache.remove(worker.getId());
			}
			
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
		
	}
	
	
	
	private static class WorkerDAOHelper {
		private static final WorkerDAO instance = new WorkerDAO();
	}
	
	public static WorkerDAO getInstance() {
		return WorkerDAOHelper.instance;
	}

	public boolean isUsingCache() {
		return usingCache;
	}

	public void setUsingCache(boolean usingCache) {
		this.usingCache = usingCache;
	}
	
	private void showEntityException(EntityException e, String msg) {
		String message = msg + " not added" + 
				"\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + e.getCause();
			JOptionPane.showMessageDialog(null, message);
	}
	
	private void showSQLException(SQLException e) {
		String message = e.getErrorCode() + "\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + "\n" + e.getCause();
		JOptionPane.showMessageDialog(null, message);
	}
}
```