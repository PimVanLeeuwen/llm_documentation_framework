`setEmployer`: The function of `setEmployer` is to assign an `Employer` object to the `Job` object. 
**Parameters**:\
`Employer employer`: The `Employer` object to be assigned to the `Job` object. 

**Code Description**: This method sets the `employer` attribute of the `Job` object to the provided `Employer` object. If the provided `employer` is `null`, it throws an `EntityException` with the message "Employer in Job is null".\\
## Code: 
```
void setEmployer(Employer employer) throws EntityException {
		if(employer == null)
			throw new EntityException("Employer in Job is null");
		this.employer = employer;
	}
```