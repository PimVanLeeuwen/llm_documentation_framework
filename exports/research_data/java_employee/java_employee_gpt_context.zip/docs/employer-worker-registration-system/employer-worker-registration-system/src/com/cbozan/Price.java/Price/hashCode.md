`hashCode`: The function of `hashCode` is to generate a hash code for the `Price` object.

**Code Description**: This method generates a hash code for the `Price` object by using the `Objects.hash` method. It combines the hash codes of the `date`, `fulltime`, `halftime`, `id`, and `overtime` fields to produce a single hash code value. This is useful for hash-based collections like `HashMap` or `HashSet` to efficiently store and retrieve objects.\\
## Code: 
```
int hashCode() {
		return Objects.hash(date, fulltime, halftime, id, overtime);
	}
```