`toString`: The function of `toString` is to provide a string representation of the `Price` object, including its `fulltime`, `halftime`, and `overtime` values.

**Code Description**: This `toString` method constructs and returns a string that includes the `fulltime`, `halftime`, and `overtime` values of the `Price` object. It calls the `getFulltime()`, `getHalftime()`, and `getOvertime()` methods to retrieve these values and formats them within parentheses, separated by spaces. The resulting string is in the format: "(fulltime)  (halftime)  (overtime)".\\
## Code: 
```
String toString() {
		return "(" + getFulltime() + ")  " + "(" + getHalftime() + ")  " + "(" + getOvertime() + ")";
	}
```