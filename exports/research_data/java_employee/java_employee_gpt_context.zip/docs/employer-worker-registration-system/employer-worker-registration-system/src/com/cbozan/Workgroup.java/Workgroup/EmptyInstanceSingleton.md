`EmptyInstanceSingleton`: The function of `EmptyInstanceSingleton` is to provide a single, shared instance of the `Workgroup` class.

**Code Description**: The `EmptyInstanceSingleton` class contains a private static final instance of the `Workgroup` class, ensuring that only one instance of `Workgroup` is created and shared across the application. This is a common implementation of the Singleton design pattern, which restricts the instantiation of a class to one "single" instance.\\
## Code: 
```
class EmptyInstanceSingleton{
		private static final Workgroup instance = new Workgroup(); 
	}
```