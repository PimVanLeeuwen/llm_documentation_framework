`build`: The function of `build` is to create and return an `Invoice` object.

**Code Description**: The `build` method in the `InvoiceBuilder` class constructs an `Invoice` object. If the `job` attribute is `null`, it creates an `Invoice` using the current state of the `InvoiceBuilder` instance. If the `job` attribute is not `null`, it creates an `Invoice` using the provided `id`, `job`, `amount`, and `date` attributes. If any required attributes are missing or invalid, an `EntityException` is thrown.\\
## Code: 
```
Invoice build() throws EntityException {
			if(job == null)
				return new Invoice(this);
			return new Invoice(id, job, amount, date);
		}
```