`filterWorktype`: The function of `filterWorktype` is to filter a list of `Work` objects based on a selected work type, removing any `Work` objects that do not match the selected work type.

**Parameters**:\
`List<Work> workList`: A list of `Work` objects that need to be filtered based on the selected work type.

**Code Description**: The `filterWorktype` method iterates through the provided `workList`. If the `selectedWorktype` is `null`, the method returns immediately without making any changes. Otherwise, it uses an `Iterator` to traverse the `workList`. For each `Work` object in the list, it checks if the `Work` object's work type ID matches the `selectedWorktype`'s ID. If there is no match, the `Work` object is removed from the list. This process ensures that only `Work` objects with the specified work type remain in the list.\\
## Code: 
```
void filterWorktype(List<Work> workList) {
		if(selectedWorktype == null) {
			return;
		}
		
		Iterator<Work> work = workList.iterator();
		Work workItem;
		while(work.hasNext()) {
			workItem = work.next();
			if(workItem.getWorktype().getId() != selectedWorktype.getId()) {
				work.remove();
			}
		}
	}
```