`updateControl`: The function of `updateControl` is to check if an employer with the same first name and last name already exists in the cache, excluding the employer with the same ID, to prevent duplicate entries.

**Parameters**:\
`Employer employer`: The employer object that needs to be checked for potential duplicates in the cache.

**Code Description**: The `updateControl` method iterates through the `cache` which is a collection of employer entries. For each entry, it compares the first name and last name of the employer in the cache with the first name and last name of the provided employer object. If a match is found and the IDs are different, it sets an error message indicating that an employer with the same name already exists and returns `false`. If no such duplicate is found, it returns `true`, indicating that the employer can be safely updated without causing a duplicate entry.\\
## Code: 
```
boolean updateControl(Employer employer) {
		for(Entry<Integer, Employer> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(employer.getFname()) 
					&& obj.getValue().getLname().equals(employer.getLname()) 
					&& obj.getValue().getId() != employer.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```