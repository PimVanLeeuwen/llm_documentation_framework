`actionPerformed`: The function of `actionPerformed` is to handle the login process when the user submits their credentials.

**Parameters**:\
`ActionEvent e`: This parameter represents the event triggered by the user's action, such as clicking the login button.

**Code Description**: The `actionPerformed` method first checks if the username or password fields are empty. If either field is empty, it sets an error message in the `label_errorText`. If both fields are filled, it clears any previous error messages and creates an instance of `LoginDAO` to verify the login credentials. If the credentials are correct, it displays a success message and transitions to the main application interface by disposing of the current `Login` frame and initializing a new `MainFrame`. If the credentials are incorrect, it sets an error message in the `label_errorText`.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		
				if(textField_username.getText().equals("") || String.valueOf(passwordField_password.getPassword()).equals("")) {
					
					label_errorText.setText(errorText);
				
				} else {
					
					label_errorText.setText("");
					LoginDAO loginDAO = new LoginDAO();
					if(loginDAO.verifyLogin(textField_username.getText(), 
							String.valueOf(passwordField_password.getPassword()))) {
						JOptionPane.showMessageDialog(contentPane, "Login successful. Welcome", "Login", 
								JOptionPane.INFORMATION_MESSAGE);
						
						EventQueue.invokeLater(new Runnable() {
							@Override
							public void run() {
								Login.this.dispose();
								new MainFrame();
							}
						});
						
					} else {
						label_errorText.setText(errorText);
					}
					
				}
				
			}
```