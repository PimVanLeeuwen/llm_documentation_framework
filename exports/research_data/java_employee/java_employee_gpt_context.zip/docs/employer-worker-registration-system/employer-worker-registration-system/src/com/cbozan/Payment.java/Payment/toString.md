`toString`: The function of `toString` is to provide a string representation of the `Payment` object.

**Code Description**: This `toString` method returns a string that includes the values of the `id`, `worker`, `job`, `paytype`, `amount`, and `date` fields of the `Payment` object. The string is formatted to clearly display each field's name and its corresponding value, making it useful for debugging and logging purposes.\\
## Code: 
```
String toString() {
		return "Payment [id=" + id + ", worker=" + worker + ", job=" + job + ", paytype=" + paytype + ", amount="
				+ amount + ", date=" + date + "]";
	}
```