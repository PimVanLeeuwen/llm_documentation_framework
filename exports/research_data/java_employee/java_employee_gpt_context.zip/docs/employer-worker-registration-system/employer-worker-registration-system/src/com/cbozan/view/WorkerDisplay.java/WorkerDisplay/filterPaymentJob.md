`filterPaymentJob`: The function of `filterPaymentJob` is to filter out payments from a list that do not match the selected worker's job.

**Parameters**:\
`List<Payment> paymentList`: A list of `Payment` objects that need to be filtered based on the selected worker's job.

**Code Description**: The `filterPaymentJob` method iterates through the provided list of `Payment` objects. If the `selectedWorkerPaymentJob` is not set (i.e., it is `null`), the method returns immediately without making any changes. Otherwise, it removes any `Payment` objects from the list whose associated job ID does not match the ID of the `selectedWorkerPaymentJob`. This is done using an iterator to safely remove elements from the list while iterating through it.\\
## Code: 
```
void filterPaymentJob(List<Payment> paymentList) {
		if(selectedWorkerPaymentJob == null)
			return;
		
		Iterator<Payment> payment = paymentList.iterator();
		Payment paymentItem;
		while(payment.hasNext()) {
			paymentItem = payment.next();
			if(paymentItem.getJob().getId() != selectedWorkerPaymentJob.getId()) {
				payment.remove();
			}
		}
	}
```