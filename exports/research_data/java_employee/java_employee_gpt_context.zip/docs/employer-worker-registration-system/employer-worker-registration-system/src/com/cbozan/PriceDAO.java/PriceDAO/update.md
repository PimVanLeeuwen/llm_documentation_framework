`update`: The function of `update` is to update an existing `Price` record in the database with new values for `fulltime`, `halftime`, and `overtime` based on the provided `Price` object.

**Parameters**:\
`Price price`: The `Price` object containing the new values for `fulltime`, `halftime`, `overtime`, and the `id` of the record to be updated.

**Code Description**: The `update` method first checks if the provided `Price` object passes the `updateControl` validation. If it fails, the method returns `false`. If it passes, the method proceeds to update the corresponding record in the database. It establishes a connection to the database using `DB.getConnection()`, prepares an SQL `UPDATE` statement, and sets the new values for `fulltime`, `halftime`, and `overtime` using the `Price` object's getter methods. The `id` of the record to be updated is also set in the SQL statement. The method then executes the update and checks the result. If the update is successful (i.e., `result` is not zero), it updates the cache with the new `Price` object. If an `SQLException` occurs during the process, it is caught and handled by the `showSQLException` method. Finally, the method returns `true` if the update was successful, otherwise `false`.\\
## Code: 
```
boolean update(Price price) {
		
		if(updateControl(price) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE price SET fulltime=?,"
				+ "halftime=?, overtime=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setBigDecimal(1, price.getFulltime());
			pst.setBigDecimal(2, price.getHalftime());
			pst.setBigDecimal(3, price.getOvertime());
			pst.setInt(4, price.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(price.getId(), price);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```