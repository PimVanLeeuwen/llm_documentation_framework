`build`: The function of `build` is to create and return a `Payment` object based on the provided attributes.

**Code Description**: The `build` method in the `PaymentBuilder` class constructs a `Payment` object. If any of the `worker`, `job`, or `paytype` attributes are `null`, it returns a new `Payment` object using the current state of the `PaymentBuilder` instance. Otherwise, it returns a new `Payment` object initialized with the specified `id`, `worker`, `job`, `paytype`, `amount`, and `date` attributes. If the construction fails due to missing required attributes, an `EntityException` is thrown.\\
## Code: 
```
Payment build() throws EntityException{
			if(worker == null || job == null || paytype == null)
				return new Payment(this);
			return new Payment(id, worker, job, paytype, amount, date);
		}
```