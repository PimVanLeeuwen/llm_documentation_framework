`DBHelper`: The function of `DBHelper` is to provide a single, static instance of the `DB` class for database connection management.

**Code Description**: 
- The `DBHelper` class contains a single static final field named `CONNECTION`.
- `CONNECTION` is initialized with a new instance of the `DB` class.
- This design ensures that there is only one instance of the `DB` class used throughout the application, promoting efficient resource usage and consistent database connection management.\\
## Code: 
```
class DBHelper{
		private static final DB CONNECTION = new DB();
	}
```