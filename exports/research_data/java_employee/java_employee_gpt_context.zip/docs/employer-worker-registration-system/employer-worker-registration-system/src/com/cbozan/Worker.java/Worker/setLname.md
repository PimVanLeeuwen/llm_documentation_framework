`setLname`: The function of `setLname` is to set the last name of a worker while ensuring it meets specific length constraints. 
**Parameters**:\
`String lname`: The last name to be set for the worker. It must not be empty and must not exceed the maximum length defined by `DBConst.LNAME_LENGTH`.

**Code Description**: The `setLname` method first checks if the provided `lname` is either empty or exceeds the maximum allowed length specified by `DBConst.LNAME_LENGTH`. If either condition is true, it throws an `EntityException` with an appropriate error message. If the `lname` is valid, it assigns the value to the `lname` attribute of the worker object.\\
## Code: 
```
void setLname(String lname) throws EntityException {
		if(lname.length() == 0 || lname.length() > DBConst.LNAME_LENGTH)
			throw new EntityException("Worker last name empty or too long");
		this.lname = lname;
	}
```