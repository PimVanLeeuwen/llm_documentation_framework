`setHalftime`: The function of `setHalftime` is to set the halftime price for an entity, ensuring it is a positive value.

**Parameters**:\
`BigDecimal halftime`: The halftime price to be set. It must be a positive value greater than zero.

**Code Description**: The `setHalftime` method takes a `BigDecimal` parameter named `halftime`. It first checks if the provided `halftime` value is `null` or less than or equal to zero. If either condition is true, it throws an `EntityException` with the message "Price halftime negative or null or zero". If the `halftime` value is valid (i.e., not `null` and greater than zero), it assigns this value to the instance variable `halftime`.\\
## Code: 
```
void setHalftime(BigDecimal halftime) throws EntityException {
		if(halftime == null || halftime.compareTo(new BigDecimal("0.00")) <= 0)
			throw new EntityException("Price halftime negative or null or zero");
		this.halftime = halftime;
	}
```