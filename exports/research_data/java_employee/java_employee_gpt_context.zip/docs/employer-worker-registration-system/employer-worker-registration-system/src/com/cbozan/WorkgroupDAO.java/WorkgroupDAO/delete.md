`delete`: The function of `delete` is to remove a specified `Workgroup` from the database.

**Parameters**:\
`Workgroup workgroup`: The `Workgroup` object that needs to be deleted from the database. It contains the ID of the workgroup to be removed.

**Code Description**: This method attempts to delete a `Workgroup` from the database using its ID. It establishes a connection to the database and prepares an SQL `DELETE` statement with the workgroup's ID. If the deletion is successful, it removes the workgroup from the cache. If an `SQLException` occurs, it displays the error details. The method returns `true` if the deletion was successful, otherwise it returns `false`.\\
## Code: 
```
boolean delete(Workgroup workgroup) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM workgroup WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, workgroup.getId());
			
			result = ps.executeUpdate();

			if(result != 0) {
				cache.remove(workgroup.getId());
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
		
	}
```