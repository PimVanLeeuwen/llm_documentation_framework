`setLname`: The function of `setLname` is to set the last name of the worker in the `WorkerBuilder` object.
**Parameters**:\
`String lname`: The last name to be set for the worker.

**Code Description**: The `setLname` method assigns the provided `lname` parameter to the `lname` field of the `WorkerBuilder` instance. It then returns the current `WorkerBuilder` instance to allow for method chaining.\\
## Code: 
```
WorkerBuilder setLname(String lname) {
			this.lname = lname;
			return this;
		}
```