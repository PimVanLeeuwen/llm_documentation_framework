`ibanControl`: The function of `ibanControl` is to check if the given IBAN matches the specified pattern.
**Parameters**:\
`String iban`: The IBAN (International Bank Account Number) to be checked.\
`Pattern pattern`: The regular expression pattern used to validate the IBAN.

**Code Description**: The `ibanControl` method takes an IBAN string and a regular expression pattern as inputs. It uses the `matcher` method of the `Pattern` class to create a `Matcher` object for the given IBAN. The `find` method of the `Matcher` object is then called to determine if the IBAN matches the pattern. The method returns `true` if a match is found, and `false` otherwise.\\
## Code: 
```
boolean ibanControl(String iban, Pattern pattern) {
		return pattern.matcher(iban).find();
	}
```