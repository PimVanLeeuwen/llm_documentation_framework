`setLname`: The function of `setLname` is to set the last name of an employer while ensuring it meets specific length requirements.

**Code Description**: The `setLname` method takes a `String` parameter `lname` and checks if its length is either zero or exceeds the maximum allowed length defined by `DBConst.LNAME_LENGTH`. If either condition is true, it throws an `EntityException` with the message "Employer last name empty or too long". If the length is valid, it assigns the `lname` value to the instance variable `this.lname`.\\
## Code: 
```
void setLname(String lname) throws EntityException {
		if(lname.length() == 0 || lname.length() > DBConst.LNAME_LENGTH)
			throw new EntityException("Employer last name empty or too long");
		this.lname = lname;
	}
```