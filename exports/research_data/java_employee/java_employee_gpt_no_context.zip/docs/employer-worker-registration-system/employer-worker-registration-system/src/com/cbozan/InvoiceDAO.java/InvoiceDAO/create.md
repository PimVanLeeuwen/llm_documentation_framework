`create`: The function of `create` is to insert a new invoice into the database and cache the newly created invoice.

**Code Description**: 
- The `create` method takes an `Invoice` object as a parameter.
- It establishes a connection to the database using `DB.getConnection()`.
- It prepares an SQL `INSERT` statement to add the `job_id` and `amount` from the `Invoice` object into the `invoice` table.
- The `executeUpdate` method is called to execute the `INSERT` statement, and the result is stored in the `result` variable.
- If the insertion is successful (`result` is not 0), it executes a `SELECT` query to retrieve the most recently added invoice.
- It iterates through the result set, creating an `InvoiceBuilder` object to build an `Invoice` object with the retrieved data.
- The newly created `Invoice` object is then added to a cache using its ID as the key.
- If an `EntityException` occurs during the building of the `Invoice` object, it is handled by the `showEntityException` method.
- If an `SQLException` occurs at any point, it is handled by the `showSQLException` method.
- The method returns `true` if the insertion was successful, otherwise it returns `false`.\\
## Code: 
```
boolean create(Invoice invoice) {
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO invoice (job_id,amount) VALUES (?,?);";
		String query2 = "SELECT * FROM invoice ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, invoice.getJob().getId());
			pst.setBigDecimal(2, invoice.getAmount());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					InvoiceBuilder builder = new InvoiceBuilder();
					builder.setId(rs.getInt("id"));
					builder.setJob_id(rs.getInt("job_id"));
					builder.setAmount(rs.getBigDecimal("amount"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Invoice inv = builder.build();
						cache.put(inv.getId(), inv);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id"));
					}
					
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```