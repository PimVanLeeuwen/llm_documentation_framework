`WorkDAO`: The function of `WorkDAO` is to manage the CRUD (Create, Read, Update, Delete) operations for `Work` objects in a database, with optional caching for performance optimization.

**Code Description**:
- **Attributes**:
  - `cache`: A `HashMap` that stores `Work` objects with their IDs as keys for quick retrieval.
  - `usingCache`: A boolean flag indicating whether the cache should be used.

- **Constructor**:
  - `WorkDAO()`: Private constructor that initializes the DAO and populates the cache by calling the `list()` method.

- **Methods**:
  - `findById(int id)`: Retrieves a `Work` object by its ID. If caching is disabled, it refreshes the cache by calling `list()`. Returns the `Work` object if found in the cache, otherwise returns `null`.
  - `refresh()`: Clears and repopulates the cache by setting `usingCache` to `false`, calling `list()`, and then setting `usingCache` back to `true`.
  - `list(Worker worker, String dateStrings)`: Retrieves a list of `Work` objects for a specific worker within a date range. Constructs a SQL query based on the provided date range and executes it to fetch the results.
  - `list(Worker worker)`: Retrieves a list of all `Work` objects for a specific worker. Executes a SQL query to fetch the results.
  - `list()`: Retrieves all `Work` objects from the database. If the cache is enabled and not empty, it returns the cached objects. Otherwise, it fetches the data from the database, populates the cache, and returns the list.
  - `create(Work work)`: Inserts a new `Work` object into the database. If the insertion is successful, it fetches the newly created `Work` object and adds it to the cache.
  - `update(Work work)`: Updates an existing `Work` object in the database. If the update is successful, it updates the cache with the new `Work` object.
  - `delete(Work work)`: Deletes a `Work` object from the database. If the deletion is successful, it removes the `Work` object from the cache.
  - `getInstance()`: Returns the singleton instance of `WorkDAO`.
  - `isUsingCache()`: Returns the current state of the `usingCache` flag.
  - `set\\
## Code: 
```
class WorkDAO {
	
	private final HashMap<Integer, Work> cache = new HashMap<>();
	private boolean usingCache = true;
	
	private WorkDAO() {list();}
	
	// Read by id
	public Work findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
	
	public void refresh() {
		setUsingCache(false);
		list();
		setUsingCache(true);
	}
	
	public List<Work> list(Worker worker, String dateStrings){
		List<Work> workList = new ArrayList<>();
		String query = "SELECT * FROM work WHERE worker_id=" + worker.getId();
		String guiDatePattern = "dd/MM/yyyy";
		String dbDatePattern = "yyyy-MM-dd";
		
		StringTokenizer tokenizer = new StringTokenizer(dateStrings, "-");
		
		if(tokenizer.countTokens() == 1) {
			
			Date d1;
			try {
				d1 = new SimpleDateFormat(guiDatePattern).parse(tokenizer.nextToken());
				String date1 = new SimpleDateFormat(dbDatePattern).format(d1);
				d1.setTime(d1.getTime() + 86400000L);
				String date2 = new SimpleDateFormat(dbDatePattern).format(d1);
				query = "SELECT * FROM work WHERE worker_id=" + worker.getId() + " AND date >= '" + date1 + "' AND date <= '" + date2 + "';";
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
		} else if(tokenizer.countTokens() == 2) {
			Date d1;
			try {
				 d1 = new SimpleDateFormat(guiDatePattern).parse(tokenizer.nextToken());
				 String date1 = new SimpleDateFormat(dbDatePattern).format(d1);
				 d1 = new SimpleDateFormat(guiDatePattern).parse(tokenizer.nextToken());
				 d1.setTime(d1.getTime() + 86400000L);
				 String date2 = new SimpleDateFormat(dbDatePattern).format(d1);
				 query = "SELECT * FROM work WHERE worker_id=" + worker.getId() + " AND date >= '" + date1 + "' AND date <= '" + date2 + "';";
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			//query = "SELECT * FROM work WHERE worker_id=" + worker.getId();
			return workList;
		}
		
		System.out.println("query : " + query);
		Connection conn;
		Statement st;
		ResultSet rs;
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorkBuilder builder = new WorkBuilder();
			Work work;
			
			while(rs.next()) {
				
				work = findById(rs.getInt("id"));
				if(work != null) { // cache control
					workList.add(work);
				} else {
					
					builder.setId(rs.getInt("id"));
					builder.setJob_id(rs.getInt("job_id"));
					builder.setWorker_id(rs.getInt("worker_id"));
					builder.setWorktype_id(rs.getInt("worktype_id"));
					builder.setWorkgroup_id(rs.getInt("workgroup_id"));
					builder.setDescription(rs.getString("description"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						work = builder.build();
						workList.add(work);
						cache.put(work.getId(), work);
					} catch (EntityException e) {
						e.printStackTrace();
					}
					
				}
			
			}
			
		} catch(SQLException sqle) {
			
		}
		
		return workList;
		
	}
	
	public List<Work> list(Worker worker){
		
		List<Work> workList = new ArrayList<>();
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM work WHERE worker_id=" + worker.getId();
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorkBuilder builder = new WorkBuilder();
			Work work;
			
			while(rs.next()) {
				
				work = findById(rs.getInt("id"));
				if(work != null) { // cache control
					workList.add(work);
				} else {
					
					builder.setId(rs.getInt("id"));
					builder.setJob_id(rs.getInt("job_id"));
					builder.setWorker_id(rs.getInt("worker_id"));
					builder.setWorktype_id(rs.getInt("worktype_id"));
					builder.setWorkgroup_id(rs.getInt("workgroup_id"));
					builder.setDescription(rs.getString("description"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						work = builder.build();
						workList.add(work);
						cache.put(work.getId(), work);
					} catch (EntityException e) {
						e.printStackTrace();
					}
					
				}
			
			}
			
		} catch(SQLException sqle) {
			sqle.printStackTrace();
		}
		
		return workList;
		
	}
	
	
	
	//Read All
	public List<Work> list(){
		
		List<Work> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Work> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM work;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorkBuilder builder;
			Work work;
			
			while(rs.next()) {
				
				builder = new WorkBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setWorker_id(rs.getInt("worker_id"));
				builder.setWorktype_id(rs.getInt("worktype_id"));
				builder.setWorkgroup_id(rs.getInt("workgroup_id"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					work = builder.build();
					list.add(work);
					cache.put(work.getId(), work);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
	}
	
	
	public boolean create(Work work) {
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO work (job_id,worker_id,worktype_id,workgroup_id,description) VALUES (?,?,?,?,?);";
		String query2 = "SELECT * FROM work ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, work.getJob().getId());
			pst.setInt(2, work.getWorker().getId());
			pst.setInt(3, work.getWorktype().getId());
			pst.setInt(4, work.getWorkgroup().getId());
			pst.setString(5, work.getDescription());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					WorkBuilder builder = new WorkBuilder();
					builder.setId(rs.getInt("id"));
					builder.setJob_id(rs.getInt("job_id"));
					builder.setWorker_id(rs.getInt("worker_id"));
					builder.setWorktype_id(rs.getInt("worktype_id"));
					builder.setWorkgroup_id(rs.getInt("workgroup_id"));
					builder.setDescription(rs.getString("description"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Work w = builder.build();
						cache.put(w.getId(), w);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id"));
					}
					
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
	
	
	public boolean update(Work work) {
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE work SET job_id=?,"
				+ "worker_id=?, worktype_id=?, workgroup_id=?, description=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, work.getJob().getId());
			pst.setInt(2, work.getWorker().getId());
			pst.setInt(3, work.getWorktype().getId());
			pst.setInt(4, work.getWorkgroup().getId());
			pst.setString(5, work.getDescription());
			pst.setInt(6, work.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(work.getId(), work);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
	
	
	public boolean delete(Work work) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM work WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, work.getId());
			
			result = ps.executeUpdate();
			
			if(result != 0) {
				cache.remove(work.getId());
			}

		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
		
	}
	
	
	private static class WorkDAOHelper {
		private static final WorkDAO instance = new WorkDAO();
	}
	
	public static WorkDAO getInstance() {
		return WorkDAOHelper.instance;
	}

	public boolean isUsingCache() { // isUsingCache??
		return usingCache;
	}

	public void setUsingCache(boolean usingCache) {
		this.usingCache = usingCache;
	}
	
	private void showEntityException(EntityException e, String msg) {
		String message = msg + " not added" + 
				"\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + e.getCause();
			JOptionPane.showMessageDialog(null, message);
	}
	
	private void showSQLException(SQLException e) {
		String message = e.getErrorCode() + "\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + "\n" + e.getCause();
		JOptionPane.showMessageDialog(null, message);
	}
	
}
```