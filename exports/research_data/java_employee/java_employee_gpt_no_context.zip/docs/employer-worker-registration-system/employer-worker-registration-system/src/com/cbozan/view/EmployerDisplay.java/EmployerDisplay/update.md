`update`: The function of `update` is to refresh and update the user interface components related to employers, jobs, and invoices.

**Code Description**: 
- `employerSearchBox.setObjectList(EmployerDAO.getInstance().list());`: This line updates the employer search box with the latest list of employers retrieved from the `EmployerDAO`.
- `selectedEmployer = employerCard.getSelectedEmployer();`: This line retrieves the currently selected employer from the employer card.
- `employerSearchBox.setText(selectedEmployer == null ? "" : selectedEmployer.toString());`: This line sets the text of the employer search box to the name of the selected employer, or to an empty string if no employer is selected.
- `JobDAO.getInstance().refresh();`: This line refreshes the job data by calling the `refresh` method on the `JobDAO` instance.
- `InvoiceDAO.getInstance().refresh();`: This line refreshes the invoice data by calling the `refresh` method on the `InvoiceDAO` instance.
- `updateJobTableData();`: This line updates the job table data, presumably by refreshing or reloading the job table with the latest data.
- `updateEmployerPaymentTableData();`: This line updates the employer payment table data, presumably by refreshing or reloading the employer payment table with the latest data.
- `employerCard.reload();`: This line reloads the employer card, presumably to reflect any changes or updates to the employer data.\\
## Code: 
```
void update() {
		employerSearchBox.setObjectList(EmployerDAO.getInstance().list());
		selectedEmployer = employerCard.getSelectedEmployer();
		employerSearchBox.setText(selectedEmployer == null ? "" : selectedEmployer.toString());
		JobDAO.getInstance().refresh();
		InvoiceDAO.getInstance().refresh();
		updateJobTableData();
		updateEmployerPaymentTableData();
		employerCard.reload();
	}
```