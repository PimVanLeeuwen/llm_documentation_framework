`actionPerformed`: The function of `actionPerformed` is to handle the update action for an employer's details when the update button is clicked.

**Code Description**: 
- The method first checks if the source of the action event is the `updateButton` and if `selectedEmployer` is not null.
- It then updates the content of the text fields and text area with the current values.
- The method attempts to update the `selectedEmployer` using the `EmployerDAO`'s `update` method.
- If the update is successful, it displays a success message and notifies the parent component (if it is an instance of `EmployerDisplay`) to update its view.
- If the update fails, it displays an error message indicating the failure.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		
		
		if(e.getSource() == updateButton && selectedEmployer != null) {
			setFnameTextFieldContent(getFnameTextFieldContent());
			setLnameTextFieldContent(getLnameTextFieldContent());
			setTelTextFieldContent(getTelTextFieldContent());
			setDescriptionTextAreaContent(getDescriptionTextAreaContent());
			
			if(true == EmployerDAO.getInstance().update(selectedEmployer)) {
				JOptionPane.showMessageDialog(this, "Update successful", "SUCCESSFUL", JOptionPane.INFORMATION_MESSAGE);
				
				Component component = getParent();
				while(component != null && component.getClass() != EmployerDisplay.class) {
					component = component.getParent();
				}
				
				if(component != null) {
					((Observer)component).update();
				}
				
			} else {
				JOptionPane.showMessageDialog(this, "Update failed", "UNSUCCESSFUL", JOptionPane.ERROR_MESSAGE);
			}
			
			
			
		}
		
	}
```