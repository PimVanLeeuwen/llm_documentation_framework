`run`: The function of `run` is to create a new instance of the `Login` class.

**Code Description**: The `run` method is a simple function that, when called, instantiates a new object of the `Login` class. This means that it triggers the constructor of the `Login` class, potentially initializing any setup or processes defined within that constructor. The method does not take any parameters and does not return any values.\\
## Code: 
```
void run() {
				
				new Login();
				
			}
```