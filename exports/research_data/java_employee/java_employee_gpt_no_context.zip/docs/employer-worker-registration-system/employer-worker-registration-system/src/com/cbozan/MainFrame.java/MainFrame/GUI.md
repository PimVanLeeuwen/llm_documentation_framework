`GUI`: The function of `GUI` is to initialize the graphical user interface by creating menus and components.

**Code Description**: The `GUI` function calls two other functions, `createMenus()` and `createComponents()`, to set up the menus and components of the graphical user interface. The `init()` function is present but commented out, indicating that it might be used for additional initialization steps if uncommented in the future.\\
## Code: 
```
void GUI() {
		createMenus();
		createComponents();
		//init();
		
	}
```