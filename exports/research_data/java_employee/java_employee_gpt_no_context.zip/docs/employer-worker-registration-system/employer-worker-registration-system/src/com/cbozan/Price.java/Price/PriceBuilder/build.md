`build`: The function of `build` is to create and return a new `Price` object.

**Code Description**: The `build` method constructs a new instance of the `Price` class using the current state of the object it is called on. It does this by invoking the `Price` constructor and passing `this` as an argument. If any issues occur during the creation of the `Price` object, an `EntityException` is thrown.\\
## Code: 
```
Price build() throws EntityException{
			return new Price(this);
		}
```