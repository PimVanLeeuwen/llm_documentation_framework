`list`: The function of `list` is to retrieve a list of `Work` objects either from a cache or from a database.

**Code Description**: 
- The `list` method initializes an empty `ArrayList` of `Work` objects.
- It checks if the cache is not empty and if caching is enabled (`usingCache`).
  - If both conditions are met, it iterates through the cache and adds each `Work` object to the list, then returns the list.
- If the cache is empty or caching is not enabled, it clears the cache.
- It establishes a connection to the database and executes a SQL query to retrieve all records from the `work` table.
- For each record in the result set, it uses a `WorkBuilder` to construct a `Work` object with the retrieved data.
- Each successfully built `Work` object is added to the list and the cache.
- If an `EntityException` occurs during the building of a `Work` object, it handles the exception and logs the error with the problematic record's ID.
- If a `SQLException` occurs during the database operations, it handles the exception and logs the error.
- Finally, it returns the list of `Work` objects.\\
## Code: 
```
List<Work> list(){
		
		List<Work> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Work> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM work;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorkBuilder builder;
			Work work;
			
			while(rs.next()) {
				
				builder = new WorkBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setWorker_id(rs.getInt("worker_id"));
				builder.setWorktype_id(rs.getInt("worktype_id"));
				builder.setWorkgroup_id(rs.getInt("workgroup_id"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					work = builder.build();
					list.add(work);
					cache.put(work.getId(), work);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
	}
```