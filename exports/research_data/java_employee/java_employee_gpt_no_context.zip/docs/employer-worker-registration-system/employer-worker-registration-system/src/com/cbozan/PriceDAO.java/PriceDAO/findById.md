`findById`: The function of `findById` is to retrieve a `Price` object by its `id`.

**Code Description**: This method takes an integer `id` as a parameter and attempts to find a `Price` object associated with that `id`. If the `usingCache` flag is `false`, it calls the `list()` method, which presumably populates the cache. It then checks if the cache contains the given `id`. If the `id` is found in the cache, it returns the corresponding `Price` object. If the `id` is not found, it returns `null`.\\
## Code: 
```
Price findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```