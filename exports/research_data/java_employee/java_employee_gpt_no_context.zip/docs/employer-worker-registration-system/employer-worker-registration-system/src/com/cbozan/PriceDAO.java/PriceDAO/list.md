`list`: The function of `list` is to retrieve a list of `Price` objects from a cache or a database.

**Code Description**: 
- The method `list` initializes an empty list of `Price` objects.
- It checks if the cache is not empty and if the `usingCache` flag is true. If both conditions are met, it populates the list with `Price` objects from the cache and returns the list.
- If the cache is empty or `usingCache` is false, it clears the cache and proceeds to fetch data from the database.
- It establishes a connection to the database, creates a statement, and executes a query to retrieve all records from the `price` table.
- For each record in the result set, it uses a `PriceBuilder` to construct a `Price` object with the retrieved data.
- Each successfully built `Price` object is added to the list and the cache.
- If an `EntityException` occurs during the building of a `Price` object, it handles the exception by calling `showEntityException`.
- If an `SQLException` occurs during database operations, it handles the exception by calling `showSQLException`.
- Finally, it returns the list of `Price` objects.\\
## Code: 
```
List<Price> list(){
		
		List<Price> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Price> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM price;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			PriceBuilder builder;
			Price price;
			
			while(rs.next()) {
				
				builder = new PriceBuilder();
				builder.setId(rs.getInt("id"));
				builder.setFulltime(rs.getBigDecimal("fulltime"));
				builder.setHalftime(rs.getBigDecimal("halftime"));
				builder.setOvertime(rs.getBigDecimal("overtime"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					price = builder.build();
					list.add(price);
					cache.put(price.getId(), price);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
		
	}
```