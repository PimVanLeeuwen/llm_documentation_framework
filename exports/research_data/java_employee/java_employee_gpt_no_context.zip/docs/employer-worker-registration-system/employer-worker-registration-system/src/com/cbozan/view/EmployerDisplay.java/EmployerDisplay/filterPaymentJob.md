`filterPaymentJob`: The function of `filterPaymentJob` is to filter out invoices from a list that do not match a selected job.

**Code Description**: 
- The function `filterPaymentJob` takes a list of `Invoice` objects as input.
- It first checks if the `selectedJob` is `null`. If it is, the function returns immediately without making any changes to the list.
- It then iterates through the list of invoices using an `Iterator`.
- For each invoice in the list, it checks if the job associated with the invoice matches the `selectedJob` by comparing their IDs.
- If the job ID of the invoice does not match the job ID of the `selectedJob`, the invoice is removed from the list.
- The result is a filtered list of invoices where all remaining invoices are associated with the `selectedJob`.\\
## Code: 
```
void filterPaymentJob(List<Invoice> invoiceList) {
		
		if(selectedJob == null)
			return;
		
		Iterator<Invoice> invoice = invoiceList.iterator();
		Invoice invoiceItem;
		while(invoice.hasNext()) {
			invoiceItem = invoice.next();
			if(invoiceItem.getJob().getId() != selectedJob.getId()) {
				invoice.remove();
			}
		}
		
	}
```