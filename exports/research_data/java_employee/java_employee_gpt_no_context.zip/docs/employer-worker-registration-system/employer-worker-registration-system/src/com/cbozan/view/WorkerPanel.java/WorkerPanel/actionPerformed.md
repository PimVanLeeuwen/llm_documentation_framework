`actionPerformed`: The function of `actionPerformed` is to handle the event triggered by the `saveButton` and process the input data from various text fields, validate it, and save it if the data is correct.

**Code Description**: 
- The method starts by checking if the event source is the `saveButton`.
- It retrieves and processes the input data from the text fields: `fnameTextField`, `lnameTextField`, `ibanTextField`, `phoneNumberTextField`, and `descriptionTextArea`.
- The input data is trimmed, formatted to uppercase, and spaces are removed where necessary.
- It validates the input data to ensure that the first name, last name are not empty, and the phone number and IBAN are in the correct format using `Control.phoneNumberControl` and `Control.ibanControl`.
- If the validation fails, it shows an error message dialog.
- If the validation passes, it creates non-editable text areas for each input field to display the data in a confirmation dialog.
- The confirmation dialog is displayed with options to "SAVE" or "CANCEL".
- If the user selects "SAVE", it builds a `Worker` object using the `Worker.WorkerBuilder` class, setting the appropriate fields.
- It attempts to save the `Worker` object using `WorkerDAO.getInstance().create(worker)`.
- If the save operation is successful, it shows a success message and notifies all observers.
- If the save operation fails, it shows an error message indicating a database error.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == saveButton) {
			
			String fname, lname, iban, phoneNumber, description;
			
			fname = fnameTextField.getText().trim().toUpperCase();
			lname = lnameTextField.getText().trim().toUpperCase();
			iban = ibanTextField.getText().replaceAll("\\s+",  "").toUpperCase();
			phoneNumber = phoneNumberTextField.getText().replaceAll("\\s+",  "");
			description = descriptionTextArea.getText().trim().toUpperCase();
			
			if( fname.equals("") || lname.equals("") || !Control.phoneNumberControl(phoneNumber) || !Control.ibanControl(iban)) {
				
				String message = "Please fill in required fields or \nEnter the Phone Nu. or Iban format correctly";
				JOptionPane.showMessageDialog(this, message, "ERROR", JOptionPane.ERROR_MESSAGE);
				
			} else {
				
				JTextArea fnameTextArea, lnameTextArea, phoneNumberTextArea, ibanTextArea, descriptionTextArea; 
				
				fnameTextArea = new JTextArea(fname);
				fnameTextArea.setEditable(false);
				
				lnameTextArea = new JTextArea(lname);
				lnameTextArea.setEditable(false);
				
				phoneNumberTextArea = new JTextArea(phoneNumber);
				phoneNumberTextArea.setEditable(false);
				
				ibanTextArea = new JTextArea(iban);
				ibanTextArea.setEditable(false);
				
				descriptionTextArea = new JTextArea(description);
				descriptionTextArea.setEditable(false);
				
				
				
				Object[] pane = {
						new JLabel("Name"),
						fnameTextArea,
						new JLabel("Surname"),
						lnameTextArea,
						new JLabel("Phone Number"),
						phoneNumberTextArea,
						new JLabel("Iban"),
						ibanTextArea,
						new JLabel("Description"),
						new JScrollPane(descriptionTextArea) {
							private static final long serialVersionUID = 1L;
							public Dimension getPreferredSize() {
								return new Dimension(200, TH * 3);
							}
						}
				};
				
				
		
				int result = JOptionPane.showOptionDialog(this, pane, "Confirmation", 1, 1, 
						new ImageIcon("src\\icon\\accounting_icon_1_32.png"), new Object[] {"SAVE", "CANCEL"}, "CANCEL");
				
				
				// System.out.println(result);
				// 0 -> SAVE
				// 1 -> CANCEL
						
				if(result == 0) {
					
					Worker.WorkerBuilder builder = new Worker.WorkerBuilder();
					builder.setId(Integer.MAX_VALUE);
					builder.setFname(fname);
					builder.setLname(lname);
					if(!phoneNumberTextField.getText().trim().equals("")) {
						builder.setTel(Arrays.asList(new String[] {phoneNumber}));
					}
					builder.setIban(iban);
					builder.setDescription(description);
					
					Worker worker = null;
					try {
						worker = builder.build();
					} catch (EntityException e1) {
						System.out.println(e1.getMessage());
					}
					
					
					
					if(WorkerDAO.getInstance().create(worker)) { 
						JOptionPane.showMessageDialog(this, "Registration successful");
						notifyAllObservers();
					} else {
						JOptionPane.showMessageDialog(this, "Not saved", "DataBase Error", JOptionPane.ERROR_MESSAGE);
					}
				}
				
			}
			
		}
		
	}
```