`DBConst`: The function of `DBConst` is to define constants for database field length constraints.

**Code Description**: 
- `DBConst` is a class that contains two public static final integer constants.
- `FNAME_LENGTH` is set to 30, representing the maximum length allowed for a first name field in a database.
- `LNAME_LENGTH` is set to 20, representing the maximum length allowed for a last name field in a database.
- These constants can be used throughout the application to ensure consistency in database field length constraints.\\
## Code: 
```
class DBConst {
	public static final int FNAME_LENGTH = 30;
	public static final int LNAME_LENGTH = 20;
}
```