`setSelectedWorker`: The function of `setSelectedWorker` is to update the UI components with the details of the selected worker or reset them if no worker is selected.

**Code Description**: 
- The method `setSelectedWorker` takes a `Worker` object as a parameter and assigns it to the `selectedWorker` field.
- If the `selectedWorker` is `null`, it resets the text fields (`fnameTextField`, `lnameTextField`, `ibanTextField`, `telTextField`) and the text area (`descriptionTextArea`) to a predefined initial text (`INIT_TEXT`).
- If the `selectedWorker` is not `null`, it updates the text fields and text area with the corresponding details from the `selectedWorker` object:
  - `fnameTextField` is set with the worker's first name.
  - `lnameTextField` is set with the worker's last name.
  - `telTextField` is set with the worker's telephone number (if available, otherwise it is set to an empty string).
  - `ibanTextField` is set with the worker's IBAN.
  - `descriptionTextArea` is set with the worker's description.
- The method then iterates through the components of the current object, starting from the third component and skipping every third component:
  - If the component before the current one is an instance of `RecordTextField` or `TextArea`, it sets the component to be non-editable.
  - It sets the icon of every third component (assumed to be a `JButton`) to an image icon located at `"src\\icon\\text_edit.png"`.\\
## Code: 
```
void setSelectedWorker(Worker selectedWorker) {
		this.selectedWorker = selectedWorker;
		
		if(selectedWorker == null) {
			fnameTextField.setText(INIT_TEXT);
			lnameTextField.setText(INIT_TEXT);
			ibanTextField.setText(INIT_TEXT);
			telTextField.setText(INIT_TEXT);
			descriptionTextArea.setText(INIT_TEXT);
		} else {
			
			setFnameTextFieldContent(selectedWorker.getFname());
			setLnameTextFieldContent(selectedWorker.getLname());
			if(selectedWorker.getTel() == null || selectedWorker.getTel().size() == 0)
				setTelTextFieldContent("");
			else
				setTelTextFieldContent(selectedWorker.getTel().get(0));
			setIbanTextFieldContent(selectedWorker.getIban());
			setDescriptionTextAreaContent(selectedWorker.getDescription());
			
		}
		
		for(int i = 2; i < this.getComponentCount(); i += 3) {
			if(getComponent(i - 1) instanceof RecordTextField)
				((RecordTextField)this.getComponent(i - 1)).setEditable(false);
			else if(getComponent(i - 1) instanceof TextArea)
				((TextArea)getComponent(i - 1)).setEditable(false);
			
			((JButton)this.getComponent(i)).setIcon(new ImageIcon("src\\icon\\text_edit.png"));
		}
		
		
	}
```