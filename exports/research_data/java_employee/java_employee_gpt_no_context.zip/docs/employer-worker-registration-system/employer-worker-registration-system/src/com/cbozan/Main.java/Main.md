`Main`: The function of `Main` is to set the default locale to Turkish (Turkey) and launch the `Login` interface on the Event Dispatch Thread.

**Code Description**: 
- The `main` method sets the default locale to Turkish (Turkey) using `Locale.setDefault(new Locale("tr", "TR"))`. This affects locale-sensitive operations such as date, time, and number formatting.
- The `EventQueue.invokeLater` method schedules a task to be executed on the Event Dispatch Thread, which is the thread responsible for managing GUI events in Java.
- Inside the `run` method of the `Runnable` object, a new instance of the `Login` class is created, presumably to display a login interface to the user.\\
## Code: 
```
class Main {
	
	public static void main(String[] args) {
		
		Locale.setDefault(new Locale("tr", "TR"));
		
		EventQueue.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				
				new Login();
				
			}
		});
			
	}
	
}
```