`list`: The function of `list` is to retrieve a list of `Payment` objects from a database based on specified column names and their corresponding values.

**Code Description**: 
- The `list` method takes two parameters: an array of column names (`columnName`) and an array of corresponding IDs (`id`).
- It initializes an empty list of `Payment` objects.
- It checks if the lengths of `columnName` and `id` arrays are equal. If not, it returns the empty list.
- It constructs an SQL query to select all records from the `payment` table where the specified columns match the given IDs.
- It establishes a database connection and executes the query.
- For each result in the `ResultSet`, it uses a `PaymentBuilder` to create a `Payment` object with the retrieved data.
- If the `Payment` object is successfully built, it is added to the list. If an `EntityException` occurs during the building process, an error message is printed, and the payment is not added to the list.
- If an `SQLException` occurs during the database operations, the error message is printed.
- Finally, the method returns the list of `Payment` objects.\\
## Code: 
```
List<Payment> list(String[] columnName, int[] id){
		
		List<Payment> list = new ArrayList<>();
		if(columnName.length != id.length)
			return list;
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM payment WHERE ";
		
		for(int i = 0; i < columnName.length; i++) {
			query += columnName[i] + "=" + id[i] + " AND ";
		}
		
		query = query.substring(0, query.length() - (" AND ".length()));
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			PaymentBuilder builder;
			Payment payment;
			
			while(rs.next()) {
				
				builder = new PaymentBuilder();
				builder.setId(rs.getInt("id"));
				builder.setWorker_id(rs.getInt("worker_id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setPaytype_id(rs.getInt("paytype_id"));
				builder.setAmount(rs.getBigDecimal("amount"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					payment = builder.build();
					list.add(payment);
				} catch (EntityException e) {
					System.err.println(e.getMessage());
					System.out.println("!! Payment not added list !!");
				}
				
			}
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return list;
	}
```