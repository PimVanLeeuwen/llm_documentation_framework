`delete`: The function of `delete` is to remove a specific price entry from the database based on its ID.

**Code Description**: 
- The method `delete` takes a `Price` object as a parameter.
- It establishes a connection to the database using `DB.getConnection()`.
- It prepares an SQL `DELETE` statement to remove the entry from the `price` table where the `id` matches the ID of the provided `Price` object.
- The ID is set in the prepared statement using `ps.setInt(1, price.getId())`.
- The `executeUpdate` method is called to execute the delete operation, and the result is stored in the `result` variable.
- If the deletion is successful (`result` is not 0), the entry is also removed from the cache using `cache.remove(price.getId())`.
- If an `SQLException` occurs, it is caught and handled by the `showSQLException` method.
- The method returns `true` if the deletion was successful (i.e., `result` is not 0), otherwise it returns `false`.\\
## Code: 
```
boolean delete(Price price) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM price WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, price.getId());
			result = ps.executeUpdate();
			
			if(result != 0) {
				cache.remove(price.getId());
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
		
	}
```