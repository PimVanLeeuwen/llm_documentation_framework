`updateControl`: The function of `updateControl` is to check if a job with the same title but a different ID already exists in the cache.

**Code Description**: The `updateControl` method iterates through a cache of jobs, represented as a map with integer keys and `Job` values. For each entry in the cache, it compares the title of the job in the cache with the title of the job passed as an argument. If a job with the same title but a different ID is found, it sets an error message in the `DB` class indicating that the job title already exists and returns `false`. If no such job is found, it returns `true`.\\
## Code: 
```
boolean updateControl(Job job) {
		for(Entry<Integer, Job> obj : cache.entrySet()) {
			if(obj.getValue().getTitle().equals(job.getTitle()) && obj.getValue().getId() != job.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getTitle() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```