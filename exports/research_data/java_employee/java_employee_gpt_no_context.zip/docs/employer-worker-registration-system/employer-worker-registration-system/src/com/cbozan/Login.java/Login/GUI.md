`GUI`: The function of `GUI` is to create and set up a graphical user interface for a login screen.

**Code Description**: 
- The `GUI` method initializes a `JPanel` named `contentPane` and sets its layout to `null` for absolute positioning.
- It sets the bounds of `contentPane` based on the frame insets and predefined frame dimensions (`W_FRAME` and `H_FRAME`).
- A `JLabel` for "Username" is created, styled with a `Font`, and positioned at specific coordinates. This label is added to `contentPane`.
- A `JLabel` for "Password" is created, styled similarly to the username label, and positioned below the username label. This label is added to `contentPane`.
- A `JTextField` for entering the username is created, positioned next to the username label, and an `ActionListener` is added to move focus to the password field when the Enter key is pressed. This text field is added to `contentPane`.
- A `JPasswordField` for entering the password is created, positioned next to the password label, and an `ActionListener` is added to trigger the login button when the Enter key is pressed. This password field is added to `contentPane`.
- A `JButton` for "Login" is created, positioned below the text fields, and an `ActionListener` is added to handle the login process when clicked. This button is added to `contentPane`.
  - The login process checks if the username or password fields are empty and displays an error message if they are.
  - If both fields are filled, it attempts to verify the login credentials using a `LoginDAO` object.
  - If the login is successful, a success message is displayed, and the current login frame is disposed of, followed by the launch of a `MainFrame`.
  - If the login fails, an error message is displayed.
- A `JLabel` with an icon is created and positioned above the username field. This label is added to `contentPane`.
- A `JLabel` for displaying error messages is created, styled with a red font, and positioned below the login button. This label is added to `contentPane`.
- Finally, `contentPane` is set as the content pane of the frame.\\
## Code: 
```
void GUI() {
		
		contentPane = new JPanel();
		contentPane.setLayout(null);
		contentPane.setBounds(insets.left, insets.top, W_FRAME - insets.left - insets.right, 
				H_FRAME - insets.bottom - insets.top);
	
		label_username = new JLabel("Username");
		label_username.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_username.setBounds(120, 140, 70, 20);
		contentPane.add(label_username);
		
		label_password = new JLabel("Password");
		label_password.setFont(label_username.getFont());
		label_password.setBounds(label_username.getX(), label_username.getY() + 40, 
				label_username.getWidth(), label_username.getHeight());
		contentPane.add(label_password);
		
		textField_username = new JTextField();
		textField_username.setBounds(label_username.getX() + label_username.getWidth() + 30, 
				label_username.getY(), 120, label_username.getHeight());
		textField_username.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				passwordField_password.requestFocus();
			}
		});
		contentPane.add(textField_username);
		
		passwordField_password = new JPasswordField();
		passwordField_password.setBounds(textField_username.getX(), label_password.getY(), 
				120, label_password.getHeight());
		passwordField_password.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				button_login.doClick();
			}
		});
		contentPane.add(passwordField_password);
		
		button_login = new JButton("Login");
		button_login.setBounds(textField_username.getX() + 20, label_username.getY() + 80, 80, 22);
		button_login.setFocusPainted(false);
		button_login.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
		
				if(textField_username.getText().equals("") || String.valueOf(passwordField_password.getPassword()).equals("")) {
					
					label_errorText.setText(errorText);
				
				} else {
					
					label_errorText.setText("");
					LoginDAO loginDAO = new LoginDAO();
					if(loginDAO.verifyLogin(textField_username.getText(), 
							String.valueOf(passwordField_password.getPassword()))) {
						JOptionPane.showMessageDialog(contentPane, "Login successful. Welcome", "Login", 
								JOptionPane.INFORMATION_MESSAGE);
						
						EventQueue.invokeLater(new Runnable() {
							@Override
							public void run() {
								Login.this.dispose();
								new MainFrame();
							}
						});
						
					} else {
						label_errorText.setText(errorText);
					}
					
				}
				
			}
		});
		contentPane.add(button_login);
		
		label_icon = new JLabel(new ImageIcon("src\\icon\\Login_user_72.png"));
		label_icon.setBounds(textField_username.getX() + 20, textField_username.getY() - 100, 72, 72);
		contentPane.add(label_icon);
		
		label_errorText = new JLabel();
		label_errorText.setForeground(Color.RED);
		label_errorText.setBounds(button_login.getX() - 45, button_login.getY() + 30, 
				170, 30);
		label_errorText.setFont(new Font("Tahoma", Font.PLAIN + Font.BOLD, 11));
		contentPane.add(label_errorText);
		
		setContentPane(contentPane);
		
	}
```