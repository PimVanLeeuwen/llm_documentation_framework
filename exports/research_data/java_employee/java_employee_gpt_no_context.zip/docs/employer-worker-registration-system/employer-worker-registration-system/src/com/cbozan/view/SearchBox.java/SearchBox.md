`SearchBox`: The function of `SearchBox` is to provide a text field with an integrated search functionality that dynamically displays search results in a panel as the user types.

**Code Description**: 
- `SearchBox` extends `JTextField` and implements `CaretListener` and `FocusListener` to handle text input and focus events.
- It initializes with a list of objects to search through and a dimension for the result display panel.
- The search box has default colors for when the mouse enters and exits the result items.
- It sets up a `JPanel` to display search results and adds listeners to handle caret updates, focus changes, and mouse events.
- A `DocumentFilter` is applied to convert all input text to uppercase.
- The `caretUpdate` method triggers the search and display of results when the text changes.
- The `resultViewPanel` method filters the object list based on the input text and displays matching results in the panel.
- The `mouseAction` method handles the selection of a search result.
- The `focusLost` method hides the result panel when the search box loses focus, unless the mouse is over the result panel.
- Various getter and setter methods are provided to customize the search box's behavior and appearance.\\
## Code: 
```
class SearchBox extends JTextField implements CaretListener, FocusListener{
	
	private static final long serialVersionUID = 1L;
	public final Color DEFAULT_EXITED_COLOR = new Color(162, 208, 215);
	public final Color DEFAULT_ENTERED_COLOR = new Color(73, 171, 134);
	
	private JPanel resultPanel;
	private List<Object> objectList;
	private List<Object> searchResultList;
	private Dimension resultBoxSize;
	private Color exitedColor, enteredColor;
	private boolean isEntered = false;
	private Object selectedObject;
	
	
	@SuppressWarnings("unchecked")
	public SearchBox(List<?> objectList, Dimension resultBoxSize) {
		this.objectList =  (List<Object>) objectList;
		this.setBorder(new LineBorder(Color.LIGHT_GRAY, 2));
		this.setHorizontalAlignment(SwingConstants.CENTER);
		this.resultBoxSize = resultBoxSize;
		
		resultPanel = new JPanel();
		resultPanel.setVisible(true);
		resultPanel.setLayout(null);
		
		searchResultList = new ArrayList<Object>();
		
		addCaretListener(this);
		addFocusListener(this);
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				SearchBox.this.setEditable(true);
			}
		});
		exitedColor = DEFAULT_EXITED_COLOR;
		enteredColor = DEFAULT_ENTERED_COLOR;
		
		
		DocumentFilter filter = new DocumentFilter() {
			public void insertString(DocumentFilter.FilterBypass fb, int offset,
		            String text, AttributeSet attr) throws BadLocationException {

		        fb.insertString(offset, text.toUpperCase(), attr);
		    }

		    public void replace(DocumentFilter.FilterBypass fb, int offset, int length,
		            String text, AttributeSet attrs) throws BadLocationException {

		        fb.replace(offset, length, text.toUpperCase(), attrs);
		    }
		};
		
		((AbstractDocument)this.getDocument()).setDocumentFilter(filter);
		
		
	}
	
	
	public void setResultBoxSize(Dimension resultBoxSize) {
		this.resultBoxSize = resultBoxSize;
	}
	
	
	public Dimension getResultBoxSize() {
		return resultBoxSize;
	}
	
	public void setPanel(JPanel resultPanel) {
		this.resultPanel = resultPanel;
		
	}
	
	public JPanel getPanel() {
		return resultPanel;
	}
	
	@SuppressWarnings("unchecked")
	public void setObjectList(List<?> objectList) {
		this.objectList = (List<Object>) objectList;
	}
	
	public List<Object> getObjectList(){
		return objectList;
	}
	
	public void setSearchResultList(List<Object> searchResultList) {
		this.searchResultList = searchResultList;
	}
	
	public List<Object> getSearchResultList(){
		return searchResultList;
	}
	

	public void setExitedColor(Color color) {
		this.exitedColor = color;
	}
	
	public Color getEnteredColor() {
		return enteredColor;
	}
	
	public void setEnteredColor(Color color) {
		this.enteredColor = color;
	}
	
	public Color getExitedColor() {
		return exitedColor;
	}
	
	public Object getSelectedObject() {
		return selectedObject;
	}
	
	
	@Override
	public void caretUpdate(CaretEvent e) {
		if(getText().trim().length() > 0) {
			resultViewPanel();
		} else {
			getPanel().setVisible(false);
		}
		
	}
	
	public void resultViewPanel() {
		
		String searchText = getText().trim().toUpperCase();
		getPanel().removeAll();
		getSearchResultList().clear();
		
		for(Object obj : getObjectList()) {
			if(obj.toString().contains(searchText)) {
				getSearchResultList().add(obj);
				if(getSearchResultList().size() >= 10) {
					break;
				}
				
			}
			
		}
		
		int i = 0;
		for(Object searchResultObj : getSearchResultList()) {
			
			JTextField tf = new JTextField(searchResultObj.toString());
			tf.setForeground(new Color(105, 35, 64));
			tf.setName(i + "");
			tf.setHorizontalAlignment(SwingConstants.CENTER);
			tf.setEditable(false);
			tf.setBackground(new Color(162, 208, 215));
			tf.setBorder(new LineBorder(new Color(202, 228, 232)));
			tf.setBounds(0, i * (getResultBoxSize().height + 1) + i, getResultBoxSize().width, getResultBoxSize().height);
			tf.addMouseListener(new MouseAdapter() {
				public void mouseExited(MouseEvent e) {
					tf.setBackground(getExitedColor());
					isEntered = false;
				}
				
				public void mouseEntered(MouseEvent e) {
					tf.setBackground(getEnteredColor());
					isEntered = true;
				}
				
				public void mouseClicked(MouseEvent e) {
					mouseAction(e, searchResultList.get(Integer.parseInt(tf.getName())), Integer.parseInt(tf.getName()));
					//selectedWorkerDefaultListModel.addElement(searchResultList.get(Integer.parseInt(tf.getName())));
					//workerList.remove(searchResultList.get(Integer.parseInt(tf.getName())));
					getPanel().setVisible(false);
					//selectedInfoCountLabel.setText(selectedWorkerDefaultListModel.size() + " kişi");
				}
			});
			
			getPanel().add(tf);
			
			++i;
		}
		
		getPanel().setSize(getPanel().getWidth(), getSearchResultList().size() * (getResultBoxSize().height + 2));
		getPanel().setVisible(true);
		getPanel().revalidate();
		getPanel().repaint();
		
		
	}
	
	public void mouseAction(MouseEvent e, Object searchResultObject, int chooseIndex) {
		selectedObject = searchResultObject;
	}

	@Override
	public void focusGained(FocusEvent e) {}

	@Override
	public void focusLost(FocusEvent e) {
		if(!isEntered) {
			getPanel().setVisible(false);
		}
	}

}
```