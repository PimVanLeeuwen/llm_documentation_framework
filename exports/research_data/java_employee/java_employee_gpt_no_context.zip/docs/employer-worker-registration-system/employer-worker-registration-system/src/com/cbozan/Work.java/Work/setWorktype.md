`setWorktype`: The function of `setWorktype` is to set the `worktype` attribute of an object.

**Code Description**: This method takes a `Worktype` object as a parameter and assigns it to the `worktype` attribute of the current object. If the provided `worktype` is `null`, it throws an `EntityException` with the message "Worktype in Work is null". This ensures that the `worktype` attribute cannot be set to `null`, maintaining the integrity of the object.\\
## Code: 
```
void setWorktype(Worktype worktype) throws EntityException {
		if(worktype == null)
			throw new EntityException("Worktype in Work is null");
		this.worktype = worktype;
	}
```