`addHeight`: The function of `addHeight` is to increase the height of an object by a specified amount.

**Code Description**: The `addHeight` method takes an integer parameter `height` and increases the current height of the object by this value. It does this by calling the `setSize` method with the current width (obtained from `getWidth()`) and the new height (calculated as the current height from `getHeight()` plus the provided `height` parameter).\\
## Code: 
```
void addHeight(int height) {
		setSize(getWidth(), getHeight() + height);
	}
```