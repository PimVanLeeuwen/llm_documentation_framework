`updateControl`: The function of `updateControl` is to check if a given `Paytype` object can be updated without causing a duplicate entry in the cache.

**Code Description**: 
- The method `updateControl` takes a `Paytype` object as an argument.
- It iterates through each entry in the `cache` (which is assumed to be a `Map<Integer, Paytype>`).
- For each entry, it checks if the title of the `Paytype` object in the cache matches the title of the provided `Paytype` object and if their IDs are different.
- If both conditions are met, it sets an error message in the `DB` class indicating that a record with the same title already exists and returns `false`.
- If no such duplicate is found, the method returns `true`, indicating that the update can proceed without causing a duplicate entry.\\
## Code: 
```
boolean updateControl(Paytype paytype) {
		for(Entry<Integer, Paytype> obj : cache.entrySet()) {
			if(obj.getValue().getTitle().equals(paytype.getTitle()) && obj.getValue().getId() != paytype.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getTitle() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```