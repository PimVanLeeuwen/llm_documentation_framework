`actionPerformed`: The function of `actionPerformed` is to handle the login process when an action event occurs, such as clicking a login button.

**Code Description**: 
- The method first checks if the username or password fields are empty. If either field is empty, it sets an error message in `label_errorText`.
- If both fields are filled, it clears any previous error message.
- It then creates an instance of `LoginDAO` and calls its `verifyLogin` method with the entered username and password.
- If the login credentials are verified, it displays a success message using `JOptionPane` and proceeds to dispose of the current login window and open the main application frame (`MainFrame`).
- If the login credentials are not verified, it sets an error message in `label_errorText`.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		
				if(textField_username.getText().equals("") || String.valueOf(passwordField_password.getPassword()).equals("")) {
					
					label_errorText.setText(errorText);
				
				} else {
					
					label_errorText.setText("");
					LoginDAO loginDAO = new LoginDAO();
					if(loginDAO.verifyLogin(textField_username.getText(), 
							String.valueOf(passwordField_password.getPassword()))) {
						JOptionPane.showMessageDialog(contentPane, "Login successful. Welcome", "Login", 
								JOptionPane.INFORMATION_MESSAGE);
						
						EventQueue.invokeLater(new Runnable() {
							@Override
							public void run() {
								Login.this.dispose();
								new MainFrame();
							}
						});
						
					} else {
						label_errorText.setText(errorText);
					}
					
				}
				
			}
```