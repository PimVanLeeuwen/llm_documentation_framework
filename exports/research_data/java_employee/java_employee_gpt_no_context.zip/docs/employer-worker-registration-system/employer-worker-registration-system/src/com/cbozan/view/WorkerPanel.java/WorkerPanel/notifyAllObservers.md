`notifyAllObservers`: The function of `notifyAllObservers` is to notify all registered observers by calling their `update` method.

**Code Description**: The `notifyAllObservers` method iterates through a list of `Observer` objects stored in the `observers` collection. For each `Observer` in the list, it calls the `update` method, which is intended to allow each observer to perform some action in response to a change in state. This method is typically used in the Observer design pattern to ensure that all observers are informed of changes to the subject they are observing.\\
## Code: 
```
void notifyAllObservers() {
		for(Observer observer : observers) {
			observer.update();
		}
	}
```