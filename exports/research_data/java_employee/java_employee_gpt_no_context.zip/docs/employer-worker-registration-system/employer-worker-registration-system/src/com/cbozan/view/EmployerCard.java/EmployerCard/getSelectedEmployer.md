`getSelectedEmployer`: The function of `getSelectedEmployer` is to return the currently selected employer.

**Code Description**: This method, `getSelectedEmployer`, is a getter function that returns the value of the private field `selectedEmployer`. The `selectedEmployer` is presumably an instance of the `Employer` class. This method allows other parts of the program to access the `selectedEmployer` without directly modifying it, adhering to the principles of encapsulation in object-oriented programming.\\
## Code: 
```
Employer getSelectedEmployer() {
		return selectedEmployer;
	}
```