`createControl`: The function of `createControl` is to check if a given `Price` object already exists in the cache.

**Code Description**: The `createControl` method takes a `Price` object as an argument and iterates through the entries in the `cache` map. For each entry, it compares the `fulltime`, `halftime`, and `overtime` values of the `Price` object in the cache with those of the provided `Price` object. If all three values match, it sets an error message in the `DB` class indicating that the price information already exists and returns `false`. If no matching entry is found, it returns `true`, indicating that the price information does not already exist in the cache.\\
## Code: 
```
boolean createControl(Price price) {
		for(Entry<Integer, Price> obj : cache.entrySet()) {
			if(obj.getValue().getFulltime().compareTo(price.getFulltime()) == 0
					&& obj.getValue().getHalftime().compareTo(price.getHalftime()) == 0
					&& obj.getValue().getOvertime().compareTo(price.getOvertime()) == 0) {
				
				DB.ERROR_MESSAGE = "Bu fiyat bilgisi kaydı zaten mevcut.";
				return false;
			}
		}
		
		return true;
	}
```