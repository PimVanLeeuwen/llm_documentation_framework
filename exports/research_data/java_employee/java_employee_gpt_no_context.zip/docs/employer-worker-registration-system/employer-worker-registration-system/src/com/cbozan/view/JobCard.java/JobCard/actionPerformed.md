`actionPerformed`: The function of `actionPerformed` is to handle the update action for a selected job when the update button is pressed.

**Code Description**: 
- The method first checks if the source of the action event is the `updateButton` and if `selectedJob` is not null.
- It then sets the content of the title text field and description text area using the respective getter methods.
- The method attempts to update the `selectedJob` using the `JobDAO`'s `update` method.
- If the update is successful, it displays a success message using `JOptionPane` and notifies the parent component (if it is an instance of `JobDisplay`) to update its state.
- If the update fails, it displays an error message using `JOptionPane`.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == updateButton && selectedJob != null) {
			
			setTitleTextFieldContent(getTitleTextFieldContent());
			setDescriptionTextAreaContent(getDescriptionTextAreaContent());
			
			
			if(true == JobDAO.getInstance().update(selectedJob)) {
				JOptionPane.showMessageDialog(this, "Update successful", "SUCCESSFUL", JOptionPane.INFORMATION_MESSAGE);
				
				Component component = getParent();
				while(component != null && component.getClass() != JobDisplay.class) {
					component = component.getParent();
				}
				
				if(component != null) {
					((Observer)component).update();
				}
			} else {
				JOptionPane.showMessageDialog(this, "Update failed", "UNSUCCESSFUL", JOptionPane.ERROR_MESSAGE);
			}
		}
		
	}
```