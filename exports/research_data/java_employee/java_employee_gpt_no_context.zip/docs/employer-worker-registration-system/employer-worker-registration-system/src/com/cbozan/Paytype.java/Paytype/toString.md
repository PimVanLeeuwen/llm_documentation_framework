`toString`: The function of `toString` is to return the title of the object.

**Code Description**: This `toString` method overrides the default `toString` implementation to return the result of the `getTitle()` method. This means that when the object is converted to a string (e.g., when printed), it will display the title of the object as defined by the `getTitle()` method.\\
## Code: 
```
String toString() {
		return getTitle();
	}
```