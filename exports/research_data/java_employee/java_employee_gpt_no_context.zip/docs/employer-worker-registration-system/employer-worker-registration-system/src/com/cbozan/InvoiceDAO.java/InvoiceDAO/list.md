`list`: The function of `list` is to retrieve a list of `Invoice` objects from a database based on a specified column name and its corresponding integer value.

**Code Description**: 
- The method `list` takes two parameters: `columnName` (a `String`) and `id` (an `int`).
- It initializes an empty `ArrayList` of `Invoice` objects.
- It constructs a SQL query to select all records from the `invoice` table where the value in the specified column matches the provided `id`.
- It establishes a database connection using `DB.getConnection()`.
- It creates a `Statement` object to execute the SQL query.
- It executes the query and retrieves the result set.
- For each row in the result set, it uses an `InvoiceBuilder` to create an `Invoice` object by setting its properties (`id`, `job_id`, `amount`, and `date`) from the result set.
- It attempts to build the `Invoice` object and add it to the list. If an `EntityException` occurs during the build process, it logs the error message and skips adding that invoice to the list.
- If a `SQLException` occurs during database operations, it logs the error message.
- Finally, it returns the list of `Invoice` objects.\\
## Code: 
```
List<Invoice> list(String columnName, int id){
		
		List<Invoice> list = new ArrayList<>();
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM invoice WHERE " + columnName + "=" + id;
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			InvoiceBuilder builder;
			Invoice invoice;
			
			while(rs.next()) {
				
				builder = new InvoiceBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setAmount(rs.getBigDecimal("amount"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					invoice = builder.build();
					list.add(invoice);
				} catch (EntityException e) {
					System.err.println(e.getMessage());
					System.out.println("!! Invoice not added list !!");
				}
				
			}
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return list;
	}
```