`addEditButton`: The function of `addEditButton` is to create and return a JButton that toggles the editability of a given JTextComponent and changes its icon accordingly.

**Code Description**: 
- The function `addEditButton` takes two parameters: a `JTextComponent` named `textField` and a `Component` named `nextFocus`.
- It creates a new `JButton` named `editButton` with an initial icon of "text_edit.png".
- The button's appearance is customized by setting its content area to not be filled, making it non-focusable, and removing its border.
- The button's position is set relative to the `textField` using its bounds.
- A `MouseAdapter` is added to the button to handle mouse click events:
  - If the `textField` is editable, the button's icon is set to "text_edit.png", the `textField` is made non-editable, and focus is requested for the `nextFocus` component or the window if `nextFocus` is null.
  - If the `textField` is not editable and its text is not equal to `INIT_TEXT`, the `textField` is made editable, and the button's icon is set to "check.png".
- The function returns the configured `editButton`.\\
## Code: 
```
JButton addEditButton(JTextComponent textField, Component nextFocus) {
		JButton editButton = new JButton(new ImageIcon("src\\icon\\text_edit.png"));
		editButton.setContentAreaFilled(false);
		editButton.setFocusable(false);
		editButton.setBorderPainted(false);
		editButton.setBounds(textField.getX() + textField.getWidth() + BS, textField.getY(), BW, rowHeight);
		
		editButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(textField.isEditable()) {
					editButton.setIcon(new ImageIcon("src\\icon\\text_edit.png"));
					textField.setEditable(false);
					if(nextFocus != null) {
						nextFocus.requestFocus();
					} else {
						requestFocusInWindow();
					}
					
				} else if(!textField.getText().equals(INIT_TEXT)) {
						textField.setEditable(true);
						editButton.setIcon(new ImageIcon("src\\icon\\check.png"));
				}
				super.mouseClicked(e);
			}
		});
		
		
		
		
		return editButton;
	}
```