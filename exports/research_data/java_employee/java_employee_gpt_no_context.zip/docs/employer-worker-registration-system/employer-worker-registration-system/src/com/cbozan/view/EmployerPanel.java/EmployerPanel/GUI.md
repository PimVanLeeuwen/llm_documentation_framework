`GUI`: The function of `GUI` is to create and set up a graphical user interface for a form that includes fields for name, surname, phone number, and description, along with a save button.

**Code Description**: 
- The `GUI` function initializes and configures various components of a graphical user interface.
- An `imageLabel` is created to display an image centered within its bounds.
- Labels (`fnameLabel`, `lnameLabel`, `phoneNumberLabel`, `descriptionLabel`) and corresponding text fields (`fnameTextField`, `lnameTextField`, `phoneNumberTextField`) are created for user input.
- Each text field has an `ActionListener` that moves the focus to the next field when the current field is filled.
- A `descriptionScrollPane` containing a `JTextArea` is added for multi-line text input.
- A `saveButton` is created and configured to trigger an action when clicked.
- The components are positioned using `setBounds` and added to the container using `add`.\\
## Code: 
```
void GUI() {
		
		imageLabel = new JLabel();
		imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
		imageLabel.setIcon(new ImageIcon("src\\icon\\new_employer.png"));
		imageLabel.setBounds(LX + 155, 40, 128, 130);
		add(imageLabel);

		fnameLabel = new JLabel("Name");
		fnameLabel.setBounds(LX, LY, LW, LH);
		add(fnameLabel);
		
		fnameTextField = new RecordTextField(RecordTextField.REQUIRED_TEXT);
		fnameTextField.setBounds(fnameLabel.getX() + LW + LHS, fnameLabel.getY(), TW, TH);
		fnameTextField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!fnameTextField.getText().replaceAll("\\s+", "").equals("")) {
					lnameTextField.requestFocus();
				}
			}
		});
		add(fnameTextField);
		
		
		lnameLabel = new JLabel("Surname");
		lnameLabel.setBounds(fnameLabel.getX(), fnameLabel.getY() + LVS, LW, LH);
		add(lnameLabel);
		
		lnameTextField = new RecordTextField(RecordTextField.REQUIRED_TEXT);
		lnameTextField.setBounds(lnameLabel.getX() + LW + LHS, lnameLabel.getY(), TW, TH);
		lnameTextField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!lnameTextField.getText().replaceAll("\\s+", "").equals("")) {
					phoneNumberTextField.requestFocus();
				}
			}
		});
		add(lnameTextField);
		
		
		phoneNumberLabel = new JLabel("Phone Nu.");
		phoneNumberLabel.setBounds(lnameLabel.getX(), lnameLabel.getY() + LVS, LW, LH);
		add(phoneNumberLabel);
		
		phoneNumberTextField= new RecordTextField(RecordTextField.PHONE_NUMBER_TEXT + RecordTextField.REQUIRED_TEXT);
		phoneNumberTextField.setBounds(phoneNumberLabel.getX() + LW + LHS, phoneNumberLabel.getY(), TW, TH);
		phoneNumberTextField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Control.phoneNumberControl(phoneNumberTextField.getText())) {
					((JTextArea)((JViewport)descriptionScrollPane.getComponent(0)).getComponent(0)).requestFocus();
				}
			}
		});
		add(phoneNumberTextField);
		
		
		descriptionLabel= new JLabel("Description");
		descriptionLabel.setBounds(phoneNumberLabel.getX(), phoneNumberLabel.getY() + LVS, LW, LH);
		add(descriptionLabel);
		
		descriptionScrollPane = new JScrollPane(new JTextArea());
		descriptionScrollPane.setBounds(descriptionLabel.getX() + LW + LHS, descriptionLabel.getY(), TW, TH * 3);
		add(descriptionScrollPane);
		
		saveButton = new JButton("SAVE");
		saveButton.setBounds(descriptionScrollPane.getX() + ((TW - BW) / 2), descriptionScrollPane.getY() + descriptionScrollPane.getHeight() + 20, BW, BH);
		saveButton.setFocusPainted(false);
		saveButton.addActionListener(this);
		add(saveButton);
		
	}
```