`filterPaymentJob`: The function of `filterPaymentJob` is to filter out payments from a list that do not match a specific job.

**Code Description**: 
The `filterPaymentJob` function takes a list of `Payment` objects as input and removes any payments that do not correspond to the job specified by `selectedWorkerPaymentJob`. If `selectedWorkerPaymentJob` is `null`, the function returns immediately without making any changes to the list. The function iterates through the `paymentList` using an `Iterator`. For each `Payment` object in the list, it checks if the job ID of the payment matches the job ID of `selectedWorkerPaymentJob`. If the IDs do not match, the payment is removed from the list.\\
## Code: 
```
void filterPaymentJob(List<Payment> paymentList) {
		if(selectedWorkerPaymentJob == null)
			return;
		
		Iterator<Payment> payment = paymentList.iterator();
		Payment paymentItem;
		while(payment.hasNext()) {
			paymentItem = payment.next();
			if(paymentItem.getJob().getId() != selectedWorkerPaymentJob.getId()) {
				payment.remove();
			}
		}
	}
```