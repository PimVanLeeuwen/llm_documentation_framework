`clearPanel`: The function of `clearPanel` is to reset the text fields and visual appearance of a panel to their default states.

**Code Description**: 
- `fulltimeTextField.setText("");`, `halftimeTextField.setText("");`, `overtimeTextField.setText("");`: These lines clear the text in the `fulltimeTextField`, `halftimeTextField`, and `overtimeTextField` respectively.
- `fulltimeTextField.setBorder(new LineBorder(Color.white));`, `halftimeTextField.setBorder(new LineBorder(Color.white));`, `overtimeTextField.setBorder(new LineBorder(Color.white));`: These lines set the border color of the `fulltimeTextField`, `halftimeTextField`, and `overtimeTextField` to white.
- `fulltimeLabel.setForeground(defaultColor);`, `halftimeLabel.setForeground(defaultColor);`, `overtimeLabel.setForeground(defaultColor);`: These lines set the text color of the `fulltimeLabel`, `halftimeLabel`, and `overtimeLabel` to the default color.\\
## Code: 
```
void clearPanel() {
		
		fulltimeTextField.setText("");
		halftimeTextField.setText("");
		overtimeTextField.setText("");
		
		fulltimeTextField.setBorder(new LineBorder(Color.white));
		halftimeTextField.setBorder(new LineBorder(Color.white));
		overtimeTextField.setBorder(new LineBorder(Color.white));
		
		fulltimeLabel.setForeground(defaultColor);
		halftimeLabel.setForeground(defaultColor);
		overtimeLabel.setForeground(defaultColor);
		
	}
```