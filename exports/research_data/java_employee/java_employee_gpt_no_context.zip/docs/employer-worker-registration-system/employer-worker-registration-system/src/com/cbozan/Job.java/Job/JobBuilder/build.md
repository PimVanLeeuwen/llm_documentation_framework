`build`: The function of `build` is to create and return a new `Job` object based on the current state of the builder.

**Code Description**: The `build` method checks if the `employer` or `price` fields are `null`. If either is `null`, it creates and returns a new `Job` object using the current builder instance (`this`). If both fields are not `null`, it creates and returns a new `Job` object using the specified fields (`id`, `employer`, `price`, `title`, `description`, `date`). The method throws an `EntityException` if an error occurs during the creation of the `Job` object.\\
## Code: 
```
Job build() throws EntityException{
			if(this.employer == null || this.price == null)
				return new Job(this);
			return new Job(this.id, this.employer, this.price, this.title, this.description, this.date);
		}
```