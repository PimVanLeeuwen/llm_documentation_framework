`createControl`: The function of `createControl` is to check if a given `Paytype` object already exists in the cache.

**Code Description**: The `createControl` method iterates through a cache of `Paytype` objects. For each entry in the cache, it compares the title of the `Paytype` object in the cache with the title of the provided `paytype` parameter. If a match is found, it sets an error message indicating that the record already exists and returns `false`. If no match is found after checking all entries, it returns `true`, indicating that the `paytype` does not already exist in the cache.\\
## Code: 
```
boolean createControl(Paytype paytype) {
		for(Entry<Integer, Paytype> obj : cache.entrySet()) {
			if(obj.getValue().getTitle().equals(paytype.getTitle())) {
				DB.ERROR_MESSAGE = obj.getValue().getTitle() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```