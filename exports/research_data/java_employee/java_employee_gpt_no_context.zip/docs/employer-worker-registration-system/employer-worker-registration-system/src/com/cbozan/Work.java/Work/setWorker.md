`setWorker`: The function of `setWorker` is to assign a `Worker` object to the `worker` attribute of the current object.

**Code Description**: The `setWorker` method takes a `Worker` object as a parameter and assigns it to the `worker` attribute of the current object. If the provided `worker` parameter is `null`, the method throws an `EntityException` with the message "Worker in Work is null". This ensures that the `worker` attribute is never set to `null`.\\
## Code: 
```
void setWorker(Worker worker) throws EntityException {
		if(worker == null)
			throw new EntityException("Worker in Work is null");
		this.worker = worker;
	}
```