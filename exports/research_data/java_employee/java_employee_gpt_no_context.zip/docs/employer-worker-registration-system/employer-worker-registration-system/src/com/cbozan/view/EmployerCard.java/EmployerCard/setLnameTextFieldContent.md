`setLnameTextFieldContent`: The function of `setLnameTextFieldContent` is to set the content of the last name text field and update the last name of the selected employer if one is selected.

**Code Description**: This method takes a string parameter `lnameTextFieldContent` and sets this value to the `lnameTextField`'s text. It then checks if there is a selected employer by calling `getSelectedEmployer()`. If an employer is selected, it updates the employer's last name with the provided text field content. If an `EntityException` occurs during this process, it catches the exception and prints the stack trace.\\
## Code: 
```
void setLnameTextFieldContent(String lnameTextFieldContent) {
		this.lnameTextField.setText(lnameTextFieldContent);
		try {
			if(getSelectedEmployer() != null)
				getSelectedEmployer().setLname(lnameTextFieldContent);
		} catch (EntityException e) {
			e.printStackTrace();
		}
	}
```