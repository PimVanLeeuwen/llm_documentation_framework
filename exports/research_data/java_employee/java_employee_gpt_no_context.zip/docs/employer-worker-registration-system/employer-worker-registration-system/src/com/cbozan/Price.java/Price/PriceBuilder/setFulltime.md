`setFulltime`: The function of `setFulltime` is to set the value of the `fulltime` attribute in the `PriceBuilder` object.

**Code Description**: This method takes a `BigDecimal` parameter named `fulltime` and assigns it to the `fulltime` attribute of the `PriceBuilder` instance. It then returns the current instance of `PriceBuilder`, allowing for method chaining.\\
## Code: 
```
PriceBuilder setFulltime(BigDecimal fulltime) {
			this.fulltime = fulltime;
			return this;
		}
```