`getSelectedJob`: The function of `getSelectedJob` is to return the currently selected job.

**Code Description**: This method, `getSelectedJob`, is a public function that returns an object of type `Job`. It does not take any parameters and simply returns the value of the private field `selectedJob`, which presumably holds the job that is currently selected. This method allows other parts of the program to access the selected job without directly modifying it.\\
## Code: 
```
Job getSelectedJob() {
		return selectedJob;
	}
```