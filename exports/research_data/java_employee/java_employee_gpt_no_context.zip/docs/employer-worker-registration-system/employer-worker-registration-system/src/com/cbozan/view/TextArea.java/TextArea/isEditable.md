`isEditable`: The function of `isEditable` is to check if the text is editable.

**Code Description**: This method `isEditable` returns a boolean value indicating whether the text is editable or not. It calls the `isEditable` method on the `text` object and returns the result. If the `text` object allows editing, it returns `true`; otherwise, it returns `false`.\\
## Code: 
```
boolean isEditable() {
		return text.isEditable();
	}
```