`focusLost`: The function of `focusLost` is to handle the event when a text field loses focus and update the border color of the text field and the foreground color of a specific label based on the validity of the text field's content.

**Code Description**: 
- The `focusLost` method is triggered when a component loses focus.
- It first checks if the source of the event is an instance of `JTextField`.
- It initializes a `Color` variable to white.
- It then calls the `decimalControl` method with the text from the `JTextField` that lost focus. If the method returns `true`, it sets the color to green (`new Color(0, 180, 0)`); otherwise, it sets the color to red.
- The border of the `JTextField` that lost focus is updated to a `LineBorder` with the determined color.
- If the `JTextField` that lost focus is the `amountTextField`, it also updates the foreground color of the `amountLabel` to the determined color.\\
## Code: 
```
void focusLost(FocusEvent e) {
		if(e.getSource() instanceof JTextField) {
			
			Color color = Color.white;
			
			if(decimalControl(((JTextField)e.getSource()).getText())) {
				color = new Color(0, 180, 0);
			} else {
				color = Color.red;
			}
			
			((JTextField)e.getSource()).setBorder(new LineBorder(color));
		
			if(((JTextField)e.getSource()) == amountTextField) {
				amountLabel.setForeground(color);
			}
		}
	}
```