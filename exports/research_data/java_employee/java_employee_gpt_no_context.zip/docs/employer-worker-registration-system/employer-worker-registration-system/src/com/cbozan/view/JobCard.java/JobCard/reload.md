`reload`: The function of `reload` is to reset the selected job to its current value.

**Code Description**: The `reload` function calls the `setSelectedJob` method with the current value of `selectedJob` as its argument. This effectively re-applies the current job selection, potentially triggering any side effects or updates associated with setting the selected job.\\
## Code: 
```
void reload() {
		setSelectedJob(selectedJob);
	}
```