`list`: The function of `list` is to retrieve a list of `Worktype` objects from a database or cache.

**Code Description**: 
- The `list` method initializes an empty list of `Worktype` objects.
- If the cache is not empty and caching is enabled (`usingCache`), it populates the list with `Worktype` objects from the cache and returns the list.
- If the cache is empty or caching is not enabled, it clears the cache and proceeds to fetch data from the database.
- It establishes a database connection, creates a statement, and executes a query to select all records from the `worktype` table.
- For each record in the result set, it uses a `WorktypeBuilder` to construct a `Worktype` object with the retrieved data (id, title, no, date).
- If the `Worktype` object is successfully built, it adds the object to the list and updates the cache with the new `Worktype` object.
- If an `EntityException` occurs during the building of a `Worktype` object, it handles the exception by calling `showEntityException`.
- If an `SQLException` occurs during database operations, it handles the exception by calling `showSQLException`.
- Finally, it returns the list of `Worktype` objects.\\
## Code: 
```
List<Worktype> list(){
		
		List<Worktype> list = new ArrayList<>();
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Worktype> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM worktype;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorktypeBuilder builder;
			Worktype worktype;
			
			while(rs.next()) {
				
				builder = new WorktypeBuilder();
				builder.setId(rs.getInt("id"));
				builder.setTitle(rs.getString("title"));
				builder.setNo(rs.getInt("no"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					worktype = builder.build();
					list.add(worktype);
					cache.put(worktype.getId(), worktype);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id") + ", Title : " + rs.getString("title"));
				}
				
			}
			
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
		
	}
```