`getSelectedWorker`: The function of `getSelectedWorker` is to return the currently selected worker.

**Code Description**: This method, `getSelectedWorker`, is a public function that returns the value of the `selectedWorker` variable. The `selectedWorker` is presumably an instance of the `Worker` class, and this method allows other parts of the program to access the currently selected worker object.\\
## Code: 
```
Worker getSelectedWorker() {
		return selectedWorker;
	}
```