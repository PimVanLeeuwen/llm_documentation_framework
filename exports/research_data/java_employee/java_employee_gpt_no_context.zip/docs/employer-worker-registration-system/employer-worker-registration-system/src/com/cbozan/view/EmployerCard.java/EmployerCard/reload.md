`reload`: The function of `reload` is to reset the selected employer to its current value.

**Code Description**: The `reload` function calls the `setSelectedEmployer` method with the current value of `selectedEmployer`. This effectively refreshes or re-applies the current selection of the employer, ensuring that any changes or updates to the `selectedEmployer` are reprocessed or reinitialized.\\
## Code: 
```
void reload() {
		setSelectedEmployer(selectedEmployer);
	}
```