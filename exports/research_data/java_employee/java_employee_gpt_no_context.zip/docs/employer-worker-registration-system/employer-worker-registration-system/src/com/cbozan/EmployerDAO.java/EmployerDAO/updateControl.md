`updateControl`: The function of `updateControl` is to check if an employer with the same first name and last name but a different ID already exists in the cache.

**Code Description**: The `updateControl` method iterates through a cache of employers. For each entry in the cache, it compares the first name and last name of the employer in the cache with the first name and last name of the given employer. If a match is found and the IDs are different, it sets an error message indicating that the employer already exists and returns `false`. If no such employer is found, it returns `true`.\\
## Code: 
```
boolean updateControl(Employer employer) {
		for(Entry<Integer, Employer> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(employer.getFname()) 
					&& obj.getValue().getLname().equals(employer.getLname()) 
					&& obj.getValue().getId() != employer.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```