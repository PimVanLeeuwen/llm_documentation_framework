`toString`: The function of `toString` is to provide a string representation of the `Invoice` object.

**Code Description**: This `toString` method overrides the default `toString` method from the `Object` class. It returns a string that includes the values of the `id`, `job`, `amount`, and `date` fields of the `Invoice` object, formatted in a readable way. The returned string follows the pattern: "Invoice [id=ID_VALUE, job=JOB_VALUE, amount=AMOUNT_VALUE, date=DATE_VALUE]". This is useful for debugging and logging purposes, as it allows for easy inspection of the object's state.\\
## Code: 
```
String toString() {
		return "Invoice [id=" + id + ", job=" + job + ", amount=" + amount + ", date=" + date + "]";
	}
```