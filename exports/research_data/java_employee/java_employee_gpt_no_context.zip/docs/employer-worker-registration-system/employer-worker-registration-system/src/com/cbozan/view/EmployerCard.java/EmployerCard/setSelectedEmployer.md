`setSelectedEmployer`: The function of `setSelectedEmployer` is to update the UI components based on the provided `Employer` object.

**Code Description**: 
- The method `setSelectedEmployer` takes an `Employer` object as a parameter and assigns it to the `selectedEmployer` field.
- If the `selectedEmployer` is `null`, it sets the text fields (`fnameTextField`, `lnameTextField`, `telTextField`, `descriptionTextArea`) to a default initial text (`INIT_TEXT`).
- If the `selectedEmployer` is not `null`, it updates the text fields with the corresponding values from the `selectedEmployer` object:
  - `fnameTextField` is set with the first name.
  - `lnameTextField` is set with the last name.
  - `telTextField` is set with the first telephone number if available, otherwise, it is set to an empty string.
  - `descriptionTextArea` is set with the description.
- The method then iterates through the components of the current object starting from the third component, setting the editability of `RecordTextField` and `TextArea` components to `false` and updating the icon of `JButton` components to a text edit icon.\\
## Code: 
```
void setSelectedEmployer(Employer selectedEmployer) {
		this.selectedEmployer = selectedEmployer;
		
		if(selectedEmployer == null) {
			fnameTextField.setText(INIT_TEXT);
			lnameTextField.setText(INIT_TEXT);
			telTextField.setText(INIT_TEXT);
			descriptionTextArea.setText(INIT_TEXT);
		} else {
			
			setFnameTextFieldContent(selectedEmployer.getFname());
			setLnameTextFieldContent(selectedEmployer.getLname());
			if(selectedEmployer.getTel() == null || selectedEmployer.getTel().size() == 0)
				setTelTextFieldContent("");
			else
				setTelTextFieldContent(selectedEmployer.getTel().get(0));
			setDescriptionTextAreaContent(selectedEmployer.getDescription());
			
		}
		
		for(int i = 2; i < this.getComponentCount(); i += 3) {
			if(getComponent(i - 1) instanceof RecordTextField)
				((RecordTextField)this.getComponent(i - 1)).setEditable(false);
			else if(getComponent(i - 1) instanceof TextArea)
				((TextArea)getComponent(i - 1)).setEditable(false);
			
			((JButton)this.getComponent(i)).setIcon(new ImageIcon("src\\icon\\text_edit.png"));
		}
		
		
	}
```