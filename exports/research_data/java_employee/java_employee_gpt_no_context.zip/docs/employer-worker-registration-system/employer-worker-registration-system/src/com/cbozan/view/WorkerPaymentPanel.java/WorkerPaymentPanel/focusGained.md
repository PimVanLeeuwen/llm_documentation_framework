`focusGained`: The function of `focusGained` is to change the visual appearance of a `JTextField` and its associated label when the text field gains focus.

**Code Description**: When a `JTextField` gains focus, this method sets its border to a blue line. If the focused text field is specifically `amountTextField`, it also changes the color of the `amountLabel` text to blue. This enhances the user interface by providing visual feedback to the user about which text field is currently active.\\
## Code: 
```
void focusGained(FocusEvent e) {
		if(e.getSource() instanceof JTextField) {
			
			((JTextField)e.getSource()).setBorder(new LineBorder(Color.blue));
			
			if(((JTextField)e.getSource()) == amountTextField) {
				amountLabel.setForeground(Color.blue);
			}
			
		}
		
	}
```