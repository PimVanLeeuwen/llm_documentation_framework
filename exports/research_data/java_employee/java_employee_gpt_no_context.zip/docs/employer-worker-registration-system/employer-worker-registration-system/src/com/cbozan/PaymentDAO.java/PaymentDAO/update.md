`update`: The function of `update` is to update an existing payment record in the database with new values provided in the `Payment` object.

**Code Description**: 
- The method `update` takes a `Payment` object as a parameter.
- It establishes a connection to the database using `DB.getConnection()`.
- It prepares an SQL `UPDATE` statement to modify the `payment` table, setting new values for `worker_id`, `job_id`, `paytype_id`, and `amount` where the `id` matches the `Payment` object's ID.
- The method sets the parameters of the prepared statement using the values from the `Payment` object.
- It executes the update statement and stores the result.
- If the update is successful (i.e., `result` is not 0), it updates a cache with the new `Payment` object.
- If an `SQLException` occurs, it is caught and handled by the `showSQLException` method.
- The method returns `true` if the update was successful, otherwise it returns `false`.\\
## Code: 
```
boolean update(Payment payment) {
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE payment SET worker_id=?,"
				+ "job_id=?, paytype_id=?, amount=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, payment.getWorker().getId());
			pst.setInt(2, payment.getJob().getId());
			pst.setInt(3, payment.getPaytype().getId());
			pst.setBigDecimal(4, payment.getAmount());
			pst.setInt(5, payment.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(payment.getId(), payment);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```