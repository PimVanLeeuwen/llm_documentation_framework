`EmptyInstanceSingleton`: The function of `EmptyInstanceSingleton` is to provide a singleton instance of the `Price` class.

**Code Description**: The `EmptyInstanceSingleton` class contains a private static final instance of the `Price` class, ensuring that only one instance of `Price` is created and used throughout the application. This is achieved by declaring the `instance` variable as `static` and `final`, which means it is initialized once and cannot be changed. The `Price` instance is created when the class is loaded, providing a globally accessible and consistent instance of `Price`.\\
## Code: 
```
class EmptyInstanceSingleton{
		private static final Price instance = new Price(); 
	}
```