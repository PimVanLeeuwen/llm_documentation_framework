`EmptyInstanceSingleton`: The function of `EmptyInstanceSingleton` is to provide a singleton instance of the `Invoice` class.

**Code Description**: The `EmptyInstanceSingleton` class contains a private static final instance of the `Invoice` class, ensuring that only one instance of `Invoice` is created and used throughout the application. This is achieved by initializing the `instance` variable at the time of class loading, making it thread-safe and ensuring that the same instance is returned every time it is accessed.\\
## Code: 
```
class EmptyInstanceSingleton{
		private static final Invoice instance = new Invoice(); 
	}
```