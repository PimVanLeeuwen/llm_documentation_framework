`update`: The function of `update` is to update an existing invoice record in the database with new values provided in the `Invoice` object.

**Code Description**: 
- The method `update` takes an `Invoice` object as a parameter.
- It establishes a connection to the database using `DB.getConnection()`.
- It prepares an SQL `UPDATE` statement to modify the `job_id` and `amount` fields of the `invoice` table where the `id` matches the `id` of the provided `Invoice` object.
- The `job_id` and `amount` values are set using the `Invoice` object's `getJob().getId()` and `getAmount()` methods, respectively.
- The `id` value is set using the `Invoice` object's `getId()` method.
- The prepared statement is executed, and the number of affected rows is stored in the `result` variable.
- If the update is successful (i.e., `result` is not 0), the updated `Invoice` object is stored in a cache using `cache.put(invoice.getId(), invoice)`.
- If an `SQLException` occurs, it is caught and handled by the `showSQLException(e)` method.
- The method returns `true` if the update was successful (i.e., `result` is not 0), otherwise it returns `false`.\\
## Code: 
```
boolean update(Invoice invoice) {
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE invoice SET job_id=?,"
				+ "amount=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, invoice.getJob().getId());
			pst.setBigDecimal(2, invoice.getAmount());
			pst.setInt(5, invoice.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(invoice.getId(), invoice);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```