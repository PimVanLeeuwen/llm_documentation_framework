`setEditable`: The function of `setEditable` is to enable or disable the editability of a text component.

**Code Description**: The `setEditable` method takes a boolean parameter `bool` and sets the editability of the `text` component to the value of `bool`. If `bool` is `true`, the `text` component becomes editable; if `bool` is `false`, the `text` component becomes non-editable.\\
## Code: 
```
void setEditable(boolean bool) {
		text.setEditable(bool);
	}
```