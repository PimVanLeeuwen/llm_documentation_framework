`getEmployerSearchBoxObject`: The function of `getEmployerSearchBoxObject` is to retrieve the selected `Employer` object from the `employerSearchBox`.

**Code Description**: This method, `getEmployerSearchBoxObject`, returns an `Employer` object that is currently selected in the `employerSearchBox`. It does this by calling the `getSelectedObject` method on the `employerSearchBox` and casting the result to an `Employer` type. This allows other parts of the program to access the selected `Employer` object for further processing or display.\\
## Code: 
```
Employer getEmployerSearchBoxObject() {
		return (Employer) employerSearchBox.getSelectedObject();
	}
```