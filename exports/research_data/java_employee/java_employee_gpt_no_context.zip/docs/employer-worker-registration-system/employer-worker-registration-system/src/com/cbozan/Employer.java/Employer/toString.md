`toString`: The function of `toString` is to return a string representation of an object by concatenating the first name and last name with a space in between.

**Code Description**: This method overrides the `toString` method to provide a custom string representation of an object. It calls the `getFname()` method to retrieve the first name and the `getLname()` method to retrieve the last name, then concatenates these two strings with a space in between and returns the resulting string. This is useful for displaying the full name of an object in a readable format.\\
## Code: 
```
String toString() {
		return getFname() + " " + getLname();
	}
```