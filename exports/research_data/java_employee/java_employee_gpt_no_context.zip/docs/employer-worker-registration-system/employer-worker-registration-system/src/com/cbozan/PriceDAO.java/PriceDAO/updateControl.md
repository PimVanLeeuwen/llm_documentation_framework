`updateControl`: The function of `updateControl` is to check if a given `Price` object already exists in the cache with the same full-time, half-time, and overtime values but a different ID.

**Code Description**: The `updateControl` method iterates through a cache of `Price` objects. For each entry in the cache, it compares the full-time, half-time, and overtime values of the cached `Price` object with those of the provided `Price` object. If all these values match but the IDs are different, it sets an error message in the `DB` class indicating that the price information already exists and returns `false`. If no such match is found, it returns `true`.\\
## Code: 
```
boolean updateControl(Price price) {
		for(Entry<Integer, Price> obj : cache.entrySet()) {
			if(obj.getValue().getFulltime().compareTo(price.getFulltime()) == 0
					&& obj.getValue().getHalftime().compareTo(price.getHalftime()) == 0
					&& obj.getValue().getOvertime().compareTo(price.getOvertime()) == 0
					&& obj.getValue().getId() != price.getId()) {
				
				DB.ERROR_MESSAGE = "Bu fiyat bilgisi kaydı zaten mevcut.";
				return false;
			}
		}
		
		return true;
	}
```