`findById`: The function of `findById` is to retrieve a `Worker` object by its ID from a cache.

**Code Description**: The `findById` method takes an integer `id` as a parameter and attempts to find a `Worker` object with that ID in a cache. If the cache is not being used (`usingCache == false`), it calls the `list()` method to presumably populate the cache. It then checks if the cache contains the given `id`. If the `id` is found in the cache, it returns the corresponding `Worker` object. If the `id` is not found, it returns `null`.\\
## Code: 
```
Worker findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```