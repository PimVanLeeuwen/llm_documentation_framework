`showEntityException`: The function of `showEntityException` is to display an error message dialog when an `EntityException` occurs.

**Code Description**: 
The `showEntityException` method takes two parameters: an `EntityException` object `e` and a `String` `msg`. It constructs an error message by concatenating the provided `msg` with the string " not added", followed by the exception's message, localized message, and cause. This constructed message is then displayed in a dialog box using `JOptionPane.showMessageDialog`, with `null` as the parent component, meaning the dialog will be centered on the screen.\\
## Code: 
```
void showEntityException(EntityException e, String msg) {
		String message = msg + " not added" + 
				"\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + e.getCause();
			JOptionPane.showMessageDialog(null, message);
	}
```