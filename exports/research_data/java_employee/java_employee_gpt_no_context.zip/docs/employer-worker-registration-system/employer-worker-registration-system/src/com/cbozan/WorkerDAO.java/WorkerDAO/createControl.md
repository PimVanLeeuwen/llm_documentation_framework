`createControl`: The function of `createControl` is to check if a worker with the same first name and last name already exists in the cache.

**Code Description**: The `createControl` method takes a `Worker` object as an argument and iterates through the `cache` entries. For each entry, it compares the first name (`Fname`) and last name (`Lname`) of the worker in the cache with those of the provided `Worker` object. If a match is found, it sets an error message in the `DB` class indicating that the worker already exists and returns `false`. If no match is found after checking all entries, it returns `true`, indicating that the worker does not already exist in the cache.\\
## Code: 
```
boolean createControl(Worker worker) {
		for(Entry<Integer, Worker> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(worker.getFname()) && obj.getValue().getLname().equals(worker.getLname())) {
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```