`setJob`: The function of `setJob` is to assign a `Job` object to the `job` attribute of an `Invoice` object, ensuring that the `Job` object is not null.

**Code Description**: The `setJob` method takes a `Job` object as a parameter and assigns it to the `job` attribute of the `Invoice` object. Before assignment, it checks if the provided `Job` object is null. If it is null, the method throws an `EntityException` with the message "Job in Invoice is null". If the `Job` object is not null, it assigns the `Job` object to the `job` attribute.\\
## Code: 
```
void setJob(Job job) throws EntityException {
		if(job == null)
			throw new EntityException("Job in Invoice is null");
		this.job = job;
	}
```