`createComponents`: The function of `createComponents` is to initialize and organize various UI components into a list and set the initial content pane for the application.

**Code Description**: 
- The `createComponents` method initializes several UI components, including `JobPanel`, `WorkerPanel`, `EmployerPanel`, `PricePanel`, `WorkerPaymentPanel`, `WorkPanel`, `JobPaymentPanel`, `JobDisplay`, `WorkerDisplay`, and `EmployerDisplay`.
- These components are categorized into three groups: record menu panels, additional menu panels, and display menu panels.
- All initialized components are added to an `ArrayList` named `components`.
- The method sets the content pane of the application to the component at the index specified by `activePage` in the `components` list.\\
## Code: 
```
void createComponents() {
		
		// record menu panels
		JobPanel job = new JobPanel();
		WorkerPanel worker = new WorkerPanel();
		EmployerPanel employer = new EmployerPanel();
		PricePanel price = new PricePanel();
		
		// add menu panels
		WorkerPaymentPanel workerPayment = new WorkerPaymentPanel();
		WorkPanel work = new WorkPanel();
		JobPaymentPanel jobPayment = new JobPaymentPanel();
		
		// display menu panels
		JobDisplay jobDisplay = new JobDisplay();
		WorkerDisplay workerDisplay = new WorkerDisplay();
		EmployerDisplay employerDisplay = new EmployerDisplay();
		
		components = new ArrayList<>();
		components.add(job);
		components.add(worker);
		components.add(employer);
		components.add(price);
		components.add(workerPayment);
		components.add(work);
		components.add(jobPayment);
		components.add(jobDisplay);
		components.add(workerDisplay);
		components.add(employerDisplay);
		
		setContentPane((JPanel) components.get(activePage));
		
	}
```