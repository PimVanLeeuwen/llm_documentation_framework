`mouseAction`: The function of `mouseAction` is to handle mouse events for selecting an employer from a search result.

**Code Description**: This method takes a `MouseEvent`, an `Object` representing a search result, and an integer `chooseIndex` as parameters. It casts the `searchResultObject` to an `Employer` and assigns it to the `selectedEmployer` variable. It then sets the text of the `employerSearchBox` to the string representation of the selected employer and makes the search box non-editable. Afterward, it requests focus for the `priceComboBox` component. Finally, it calls the `mouseAction` method of its superclass with the same parameters.\\
## Code: 
```
void mouseAction(MouseEvent e, Object searchResultObject, int chooseIndex) {
				selectedEmployer = (Employer) searchResultObject;
				employerSearchBox.setText(selectedEmployer.toString());
				employerSearchBox.setEditable(false);
				priceComboBox.requestFocus();
				super.mouseAction(e, searchResultObject, chooseIndex);
			}
```