`toString`: The function of `toString` is to generate a string representation of an object by concatenating the results of three methods: `getFulltime()`, `getHalftime()`, and `getOvertime()`.

**Code Description**: This method constructs and returns a string that includes the outputs of the `getFulltime()`, `getHalftime()`, and `getOvertime()` methods, each enclosed in parentheses and separated by two spaces. The resulting string follows the format: "(fulltime)  (halftime)  (overtime)". This can be useful for displaying the state of an object in a readable format.\\
## Code: 
```
String toString() {
		return "(" + getFulltime() + ")  " + "(" + getHalftime() + ")  " + "(" + getOvertime() + ")";
	}
```