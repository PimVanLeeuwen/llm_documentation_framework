`mouseAction`: The function of `mouseAction` is to handle mouse events and update the selected job's price based on the search result object.

**Code Description**: 
- The `mouseAction` method takes three parameters: a `MouseEvent` object `e`, an `Object` `searchResultObject`, and an `int` `chooseIndex`.
- If the `selectedJob` is not null, it attempts to set the price of the `selectedJob` using the `searchResultObject` cast to a `Price` object.
- If the `priceSearchBox` has a selected object, it updates the text of the `priceSearchBox` to the string representation of the selected object.
- If an `EntityException` is thrown during the price setting, it catches the exception and prints the stack trace.
- Finally, it calls the `mouseAction` method of the superclass with the same parameters.\\
## Code: 
```
void mouseAction(MouseEvent e, Object searchResultObject, int chooseIndex) {
				if(selectedJob != null) {
					try {
						selectedJob.setPrice((Price)searchResultObject);
						if(priceSearchBox.getSelectedObject() != null)
							priceSearchBox.setText(priceSearchBox.getSelectedObject().toString());
					} catch (EntityException e1) {
						e1.printStackTrace();
					}
				}
				super.mouseAction(e, searchResultObject, chooseIndex);
			}
```