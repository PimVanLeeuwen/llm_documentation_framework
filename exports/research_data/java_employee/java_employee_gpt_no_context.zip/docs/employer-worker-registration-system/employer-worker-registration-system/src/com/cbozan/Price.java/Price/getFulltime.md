`getFulltime`: The function of `getFulltime` is to return the value of the `fulltime` variable.

**Code Description**: This method, `getFulltime`, is a getter that returns the value of the `fulltime` variable, which is of type `BigDecimal`. This method does not take any parameters and simply provides access to the `fulltime` variable's value, allowing other parts of the program to retrieve this value without directly accessing the variable.\\
## Code: 
```
BigDecimal getFulltime() {
		return fulltime;
	}
```