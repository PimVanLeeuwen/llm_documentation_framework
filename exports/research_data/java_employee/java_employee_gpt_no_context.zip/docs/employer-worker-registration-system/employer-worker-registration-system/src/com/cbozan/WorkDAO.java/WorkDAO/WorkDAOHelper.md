`WorkDAOHelper`: The function of `WorkDAOHelper` is to provide a singleton instance of the `WorkDAO` class.

**Code Description**: The `WorkDAOHelper` class contains a private static final field named `instance` which holds a single instance of the `WorkDAO` class. This ensures that only one instance of `WorkDAO` is created and used throughout the application, following the singleton design pattern.\\
## Code: 
```
class WorkDAOHelper {
		private static final WorkDAO instance = new WorkDAO();
	}
```