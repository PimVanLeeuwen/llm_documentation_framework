`createControl`: The function of `createControl` is to determine if a payment can be processed.

**Code Description**: The `createControl` method takes a `Payment` object as an argument and returns a boolean value. Currently, the method always returns `true`, indicating that the payment can be processed. The commented-out code suggests that there was an intention to check if sufficient payment can be made by iterating through a cache of payments, but this logic has not been implemented.\\
## Code: 
```
boolean createControl(Payment payment) {
//		for(Entry<Integer, Payment> obj : cache.entrySet()) {
//			// yeteri kadar �deme alabilir mi? kontrol etme kodu buraya gelecek
//		}
		return true;
	}
```