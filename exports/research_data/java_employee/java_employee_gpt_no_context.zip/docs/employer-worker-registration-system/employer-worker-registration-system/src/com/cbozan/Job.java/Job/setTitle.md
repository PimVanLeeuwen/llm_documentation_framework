`setTitle`: The function of `setTitle` is to set the title of a job entity.

**Code Description**: The `setTitle` method takes a `String` parameter `title` and assigns it to the instance variable `title` of the object. Before setting the title, it checks if the provided `title` is `null` or has a length of 0. If either condition is true, it throws an `EntityException` with the message "Job title null or empty". If the `title` is valid, it assigns the provided `title` to the instance variable `title`.\\
## Code: 
```
void setTitle(String title) throws EntityException {
		if(title == null || title.length() == 0)
			throw new EntityException("Job title null or empty");
		this.title = title;
	}
```