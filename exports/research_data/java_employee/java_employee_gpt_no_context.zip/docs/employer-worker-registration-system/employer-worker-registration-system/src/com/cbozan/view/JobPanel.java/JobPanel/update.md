`update`: The function of `update` is to refresh the user interface components with the latest data from the database.

**Code Description**: 
- The `update` method starts by calling `clearPanel()`, which likely clears or resets the user interface panel to a default state.
- It then updates the `priceComboBox` by setting its model to a new `DefaultComboBoxModel` containing the latest list of `Price` objects retrieved from the `PriceDAO`.
- Finally, it updates the `employerSearchBox` by setting its object list to the latest list of `Employer` objects retrieved from the `EmployerDAO`.\\
## Code: 
```
void update() {
		clearPanel();
		
		priceComboBox.setModel(new DefaultComboBoxModel<>(PriceDAO.getInstance().list().toArray(new Price[0])));
		employerSearchBox.setObjectList(EmployerDAO.getInstance().list());
		
	}
```