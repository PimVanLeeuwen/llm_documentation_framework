`addEditButton`: The function of `addEditButton` is to create and return a JButton that toggles the editability of a given JTextComponent and changes its icon accordingly.

**Code Description**: 
- The function `addEditButton` takes two parameters: a `JTextComponent` (`textField`) and a `Component` (`nextFocus`).
- It creates a new `JButton` with an initial icon of "text_edit.png".
- The button's appearance is customized to have no content area, not be focusable, and have no border painted.
- The button's position is set relative to the `textField` using its coordinates and dimensions.
- A `MouseListener` is added to the button to handle mouse click events:
  - If the `textField` is editable, clicking the button will:
    - Change the button's icon back to "text_edit.png".
    - Make the `textField` non-editable.
    - Shift focus to the `nextFocus` component if it is not null, otherwise, request focus in the window.
  - If the `textField` is not editable and its text is not equal to `INIT_TEXT`, clicking the button will:
    - Make the `textField` editable.
    - Change the button's icon to "check.png".
- The function returns the configured `JButton`.\\
## Code: 
```
JButton addEditButton(JTextComponent textField, Component nextFocus) {
		JButton editButton = new JButton(new ImageIcon("src\\icon\\text_edit.png"));
		editButton.setContentAreaFilled(false);
		editButton.setFocusable(false);
		editButton.setBorderPainted(false);
		editButton.setBounds(textField.getX() + textField.getWidth() + BS, textField.getY(), BW, rowHeight);
		
		editButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(textField.isEditable()) {
					editButton.setIcon(new ImageIcon("src\\icon\\text_edit.png"));
					textField.setEditable(false);
					if(nextFocus != null) {
						nextFocus.requestFocus();
					} else {
						requestFocusInWindow();
					}
					
				} else if(!textField.getText().equals(INIT_TEXT)) {
						textField.setEditable(true);
						editButton.setIcon(new ImageIcon("src\\icon\\check.png"));
				}
				super.mouseClicked(e);
			}
		});
		
		
		
		
		return editButton;
	}
```