`findById`: The function of `findById` is to retrieve an `Invoice` object by its ID from a cache, or return `null` if the ID is not found.

**Code Description**: The `findById` method takes an integer `id` as a parameter and attempts to find the corresponding `Invoice` object in a cache. If the `usingCache` flag is set to `false`, it calls the `list()` method to presumably populate the cache. It then checks if the cache contains the given `id`. If the `id` is found in the cache, it returns the associated `Invoice` object. If the `id` is not found, it returns `null`.\\
## Code: 
```
Invoice findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
	}
```