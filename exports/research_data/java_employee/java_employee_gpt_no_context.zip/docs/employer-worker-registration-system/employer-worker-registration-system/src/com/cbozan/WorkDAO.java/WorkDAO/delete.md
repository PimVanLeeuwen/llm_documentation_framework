`delete`: The function of `delete` is to remove a specific `Work` object from the database and cache.

**Code Description**: 
- The `delete` method takes a `Work` object as a parameter.
- It establishes a connection to the database using `DB.getConnection()`.
- It prepares an SQL `DELETE` statement to remove the record from the `work` table where the `id` matches the `id` of the provided `Work` object.
- The `id` of the `Work` object is set as a parameter in the prepared statement.
- The `executeUpdate` method is called to execute the `DELETE` statement, which returns the number of affected rows.
- If the deletion is successful (i.e., the number of affected rows is not zero), the `id` of the `Work` object is removed from the cache.
- If an `SQLException` occurs during the process, it is caught and handled by the `showSQLException` method.
- The method returns `true` if the deletion was successful (i.e., at least one row was affected), otherwise it returns `false`.\\
## Code: 
```
boolean delete(Work work) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM work WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, work.getId());
			
			result = ps.executeUpdate();
			
			if(result != 0) {
				cache.remove(work.getId());
			}

		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
		
	}
```