`DBHelper`: The function of `DBHelper` is to provide a helper class for database operations.

**Code Description**: The `DBHelper` class contains a single static final instance of a `DB` object named `CONNECTION`. This means that `CONNECTION` is a constant and will be initialized only once when the class is loaded. The `DB` object can be used for database operations throughout the application, ensuring a single point of access to the database connection.\\
## Code: 
```
class DBHelper{
		private static final DB CONNECTION = new DB();
	}
```