`updateControl`: The function of `updateControl` is to check if a worker with the same first name and last name but a different ID already exists in the cache.

**Code Description**: 
- The method `updateControl` takes a `Worker` object as a parameter.
- It iterates through all entries in the `cache`, which is assumed to be a map with `Integer` keys and `Worker` values.
- For each entry, it compares the first name and last name of the worker in the cache with the first name and last name of the provided `worker` object.
- If a match is found and the IDs are different, it sets an error message in the `DB` class indicating that a record with the same name already exists.
- The method returns `false` if such a duplicate is found.
- If no duplicates are found, the method returns `true`.\\
## Code: 
```
boolean updateControl(Worker worker) {
		for(Entry<Integer, Worker> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(worker.getFname()) 
					&& obj.getValue().getLname().equals(worker.getLname())
					&& obj.getValue().getId() != worker.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```