`setFname`: The function of `setFname` is to set the first name of an employer.

**Code Description**: The `setFname` method takes a string parameter `fname` and sets it as the first name of an employer. It first checks if the length of `fname` is either zero or exceeds a predefined maximum length (`DBConst.FNAME_LENGTH`). If either condition is true, it throws an `EntityException` with the message "Employer name empty or too long". If the length is valid, it assigns the value of `fname` to the instance variable `this.fname`.\\
## Code: 
```
void setFname(String fname) throws EntityException {
		if(fname.length() == 0 || fname.length() > DBConst.FNAME_LENGTH)
			throw new EntityException("Employer name empty or too long");
		this.fname = fname;
	}
```