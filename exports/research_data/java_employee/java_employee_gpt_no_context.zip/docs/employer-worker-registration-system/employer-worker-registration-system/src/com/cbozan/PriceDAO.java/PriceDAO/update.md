`update`: The function of `update` is to update the price details in the database for a given `Price` object.

**Code Description**: 
- The `update` method takes a `Price` object as a parameter.
- It first calls the `updateControl` method with the `Price` object. If `updateControl` returns `false`, the method returns `false` immediately.
- It then prepares a SQL `UPDATE` query to update the `fulltime`, `halftime`, and `overtime` fields in the `price` table where the `id` matches the `id` of the `Price` object.
- A database connection is established using `DB.getConnection()`.
- A `PreparedStatement` is created with the SQL query.
- The `fulltime`, `halftime`, and `overtime` values from the `Price` object are set in the `PreparedStatement`.
- The `id` of the `Price` object is set in the `PreparedStatement`.
- The `executeUpdate` method is called on the `PreparedStatement` to execute the update query.
- If the update is successful (i.e., `result` is not 0), the `Price` object is cached using `cache.put`.
- If an `SQLException` occurs, it is caught and handled by the `showSQLException` method.
- The method returns `true` if the update was successful, otherwise it returns `false`.\\
## Code: 
```
boolean update(Price price) {
		
		if(updateControl(price) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE price SET fulltime=?,"
				+ "halftime=?, overtime=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setBigDecimal(1, price.getFulltime());
			pst.setBigDecimal(2, price.getHalftime());
			pst.setBigDecimal(3, price.getOvertime());
			pst.setInt(4, price.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(price.getId(), price);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```