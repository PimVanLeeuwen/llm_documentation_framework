`delete`: The function of `delete` is to remove a specified invoice from the database and cache.

**Code Description**: 
- The `delete` method takes an `Invoice` object as a parameter.
- It establishes a connection to the database using `DB.getConnection()`.
- It prepares an SQL `DELETE` statement to remove the invoice with the specified `id`.
- The `id` of the invoice is set in the prepared statement.
- The statement is executed, and the number of affected rows is stored in the `result` variable.
- If the deletion is successful (i.e., `result` is not 0), the invoice is also removed from the cache using `cache.remove(invoice.getId())`.
- If an `SQLException` occurs, the error message is printed to the console.
- The method returns `true` if the deletion was successful, otherwise it returns `false`.\\
## Code: 
```
boolean delete(Invoice invoice) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM invoice WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, invoice.getId());
			
			result = ps.executeUpdate();
			
			if(result != 0) {
				cache.remove(invoice.getId());
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return result == 0 ? false : true;
		
	}
```