`setId`: The function of `setId` is to set the ID of an invoice.

**Code Description**: The `setId` method takes an integer parameter `id` and assigns it to the instance variable `id` of the object. Before assigning, it checks if the provided `id` is less than or equal to zero. If the `id` is invalid (negative or zero), it throws an `EntityException` with the message "Invoice ID negative or zero". This ensures that only positive, non-zero IDs are set for the invoice.\\
## Code: 
```
void setId(int id) throws EntityException {
		if(id <= 0)
			throw new EntityException("Invoice ID negative or zero");
		this.id = id;
	}
```