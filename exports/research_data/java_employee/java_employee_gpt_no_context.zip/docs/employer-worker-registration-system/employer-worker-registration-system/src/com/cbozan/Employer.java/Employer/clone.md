`clone`: The function of `clone` is to create and return a copy of the current `Employer` object.

**Code Description**: This method attempts to create a clone of the current `Employer` object by calling the `clone` method from the superclass. It uses a try-catch block to handle the `CloneNotSupportedException` that might be thrown if the `Employer` class does not implement the `Cloneable` interface. If cloning is successful, it returns the cloned `Employer` object. If an exception occurs, it prints the stack trace and returns `null`.\\
## Code: 
```
Employer clone(){
		// TODO Auto-generated method stub
		try {
			return (Employer) super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
			return null;
		}
	}
```