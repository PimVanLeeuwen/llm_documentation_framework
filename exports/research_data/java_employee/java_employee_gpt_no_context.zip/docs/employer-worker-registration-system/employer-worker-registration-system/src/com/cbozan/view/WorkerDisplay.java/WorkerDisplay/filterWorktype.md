`filterWorktype`: The function of `filterWorktype` is to filter a list of `Work` objects based on a selected work type.

**Code Description**: 
The `filterWorktype` function takes a list of `Work` objects (`workList`) and removes any `Work` objects from the list that do not match the `selectedWorktype`. If `selectedWorktype` is `null`, the function returns immediately without making any changes to the list. The function uses an iterator to traverse the list and checks each `Work` object's work type ID against the `selectedWorktype` ID. If they do not match, the `Work` object is removed from the list.\\
## Code: 
```
void filterWorktype(List<Work> workList) {
		if(selectedWorktype == null) {
			return;
		}
		
		Iterator<Work> work = workList.iterator();
		Work workItem;
		while(work.hasNext()) {
			workItem = work.next();
			if(workItem.getWorktype().getId() != selectedWorktype.getId()) {
				work.remove();
			}
		}
	}
```