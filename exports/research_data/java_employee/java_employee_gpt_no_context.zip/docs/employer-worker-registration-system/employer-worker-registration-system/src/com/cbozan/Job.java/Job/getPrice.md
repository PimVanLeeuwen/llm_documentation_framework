`getPrice`: The function of `getPrice` is to return the value of the `price` attribute.

**Code Description**: This method, `getPrice`, is a getter function that retrieves and returns the current value of the `price` attribute from the object in which it is defined. It does not take any parameters and simply returns the `price` when called. This is typically used to access the value of `price` from outside the object while keeping the `price` attribute encapsulated.\\
## Code: 
```
Price getPrice() {
		return price;
	}
```