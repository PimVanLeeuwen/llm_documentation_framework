`actionPerformed`: The function of `actionPerformed` is to handle the event triggered by the `takePaymentButton` and process the payment for a selected job.

**Code Description**: 
- The method first checks if the event source is the `takePaymentButton`.
- It retrieves the selected job and the amount entered in the `amountTextField`, removing any whitespace from the amount.
- It validates the amount format using the `decimalControl` method and checks if a job is selected.
- If the validation fails, it displays an error message using a `JOptionPane`.
- If the validation passes, it creates a confirmation dialog displaying the job details and the payment amount.
- If the user confirms the action (chooses "SAVE"), it builds an `Invoice` object using the `Invoice.InvoiceBuilder`.
- It attempts to save the invoice using `InvoiceDAO.getInstance().create(invoice)`.
- If the invoice is saved successfully, it shows a success message and notifies all observers.
- If the save operation fails, it shows a database error message.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		if(e.getSource() == takePaymentButton) {
			
			Job job;
			String amount;
			
			job = selectedJob;
			amount = amountTextField.getText().replaceAll("\\s+", "");

			if(!decimalControl(amount) || job == null) {
				
				String message;
				message = "Please enter job selection section or format correctly (max 2 floating point)";
				JOptionPane.showMessageDialog(this, message, "ERROR", JOptionPane.ERROR_MESSAGE);
				
			} else {
				
				JTextArea jobTextArea, amountTextArea;
				
				jobTextArea = new JTextArea(job.toString());
				jobTextArea.setEditable(false);
				
				amountTextArea = new JTextArea(amount + " ₺");
				amountTextArea.setEditable(false);
				
				Object[] pane = {
						new JLabel("Job"),
						jobTextArea,
						new JLabel("Amount of payment"),
						amountTextArea
				};
		
				int result = JOptionPane.showOptionDialog(this, pane, "Confirmation", 1, 1, 
						new ImageIcon("src\\icon\\accounting_icon_1_32.png"), new Object[] {"SAVE", "CANCEL"}, "CANCEL");
				
				
				// System.out.println(result);
				// 0 -> SAVE
				// 1 -> CANCEL
				
				if(result == 0) {
					
					Invoice.InvoiceBuilder builder = new Invoice.InvoiceBuilder();
					builder.setId(Integer.MAX_VALUE);
					builder.setJob(selectedJob);
					builder.setAmount(new BigDecimal(amount));
					
					Invoice invoice = null;
					try {
						invoice = builder.build();
					} catch (EntityException e1) {
						System.out.println(e1.getMessage());
					}
					
					if(InvoiceDAO.getInstance().create(invoice)) { 
						JOptionPane.showMessageDialog(this, "Registration successful");
						notifyAllObservers();
					} else {
						JOptionPane.showMessageDialog(this, "Not saved", "DataBase error", JOptionPane.ERROR_MESSAGE);
					}
				}
				
			}
			
		}
		
	}
```