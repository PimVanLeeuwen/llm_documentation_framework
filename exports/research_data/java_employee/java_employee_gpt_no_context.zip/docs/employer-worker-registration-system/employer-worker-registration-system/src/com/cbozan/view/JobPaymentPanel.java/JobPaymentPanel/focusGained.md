`focusGained`: The function of `focusGained` is to change the appearance of a `JTextField` and its associated label when the text field gains focus.

**Code Description**: When a `JTextField` gains focus, this method sets its border to a blue line. If the focused text field is specifically `amountTextField`, it also changes the color of the `amountLabel` text to blue. This provides a visual indication to the user that the text field is active and ready for input.\\
## Code: 
```
void focusGained(FocusEvent e) {
		if(e.getSource() instanceof JTextField) {
			
			((JTextField)e.getSource()).setBorder(new LineBorder(Color.blue));
			
			if(((JTextField)e.getSource()) == amountTextField) {
				amountLabel.setForeground(Color.blue);
			}
			
		}
		
	}
```