`create`: The function of `create` is to insert a new payment record into the database and cache the newly created payment object.

**Code Description**: 
- The `create` method takes a `Payment` object as an argument.
- It first calls the `createControl` method with the `payment` object to perform some validation or control checks. If this check fails (returns `false`), the method returns `false`.
- It establishes a connection to the database using `DB.getConnection()`.
- It prepares an SQL `INSERT` statement to add the payment details (worker ID, job ID, pay type ID, and amount) into the `payment` table.
- The `executeUpdate` method is called to execute the `INSERT` statement. If the insertion is successful (`result` is not 0), it proceeds to retrieve the most recently added payment record.
- It executes a `SELECT` query to fetch the latest payment record ordered by ID in descending order and limited to one result.
- It iterates through the result set, constructs a `Payment` object using the `PaymentBuilder` class, and sets its properties based on the retrieved data.
- The newly created `Payment` object is then added to a cache using its ID as the key.
- If any exceptions occur during the database operations, they are caught and handled by `showSQLException` and `showEntityException` methods.
- Finally, the method returns `true` if the insertion was successful, otherwise `false`.\\
## Code: 
```
boolean create(Payment payment) {
		
		if(createControl(payment) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO payment (worker_id,job_id,paytype_id,amount) VALUES (?,?,?,?);";
		String query2 = "SELECT * FROM payment ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, payment.getWorker().getId());
			pst.setInt(2, payment.getJob().getId());
			pst.setInt(3, payment.getPaytype().getId());
			pst.setBigDecimal(4, payment.getAmount());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					PaymentBuilder builder = new PaymentBuilder();
					builder.setId(rs.getInt("id"));
					builder.setWorker_id(rs.getInt("worker_id"));
					builder.setJob_id(rs.getInt("job_id"));
					builder.setPaytype_id(rs.getInt("paytype_id"));
					builder.setAmount(rs.getBigDecimal("amount"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Payment py = builder.build();
						cache.put(py.getId(), py);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id"));
					}
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```