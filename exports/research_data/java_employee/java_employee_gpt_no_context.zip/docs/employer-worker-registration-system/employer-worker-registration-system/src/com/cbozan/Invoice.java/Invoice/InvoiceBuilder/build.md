`build`: The function of `build` is to create and return an `Invoice` object.

**Code Description**: The `build` method constructs an `Invoice` object. If the `job` attribute is `null`, it creates a new `Invoice` using the current instance (`this`). If the `job` attribute is not `null`, it creates a new `Invoice` using the provided `id`, `job`, `amount`, and `date` attributes. The method may throw an `EntityException` if an error occurs during the creation of the `Invoice` object.\\
## Code: 
```
Invoice build() throws EntityException {
			if(job == null)
				return new Invoice(this);
			return new Invoice(id, job, amount, date);
		}
```