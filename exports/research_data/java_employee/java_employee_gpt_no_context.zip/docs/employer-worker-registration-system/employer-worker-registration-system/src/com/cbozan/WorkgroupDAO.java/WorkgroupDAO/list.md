`list`: The function of `list` is to retrieve a list of `Workgroup` objects from a cache or a database.

**Code Description**: 
- The `list` method initializes an empty list of `Workgroup` objects.
- It checks if the cache is not empty and if caching is enabled (`usingCache`). If both conditions are met, it populates the list with `Workgroup` objects from the cache and returns the list.
- If the cache is empty or caching is not enabled, it clears the cache and proceeds to fetch data from the database.
- It establishes a database connection, creates a statement, and executes a query to select all records from the `workgroup` table.
- For each record in the result set, it uses a `WorkgroupBuilder` to construct a `Workgroup` object with the retrieved data.
- Each successfully built `Workgroup` object is added to the list and the cache.
- If an `EntityException` occurs during the building of a `Workgroup`, it is handled by the `showEntityException` method.
- If an `SQLException` occurs during database operations, it is handled by the `showSQLException` method.
- Finally, the method returns the list of `Workgroup` objects.\\
## Code: 
```
List<Workgroup> list(){
		
		List<Workgroup> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Workgroup> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM workgroup;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorkgroupBuilder builder;
			Workgroup workgroup;
			
			while(rs.next()) {
				
				builder = new WorkgroupBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setWorktype_id(rs.getInt("worktype_id"));
				builder.setWorkCount(rs.getInt("workcount"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					workgroup = builder.build();
					list.add(workgroup);
					cache.put(workgroup.getId(), workgroup);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
	}
```