`list`: The function of `list` is to retrieve a list of `Paytype` objects either from a cache or from a database.

**Code Description**: 
- The method `list` initializes an empty list of `Paytype` objects.
- It checks if the cache is not empty and if caching is enabled (`usingCache` is true). If both conditions are met, it populates the list with `Paytype` objects from the cache and returns the list.
- If the cache is empty or caching is not enabled, it clears the cache and proceeds to fetch data from the database.
- It establishes a connection to the database, creates a statement, and executes a query to retrieve all records from the `paytype` table.
- For each record in the result set, it uses a `PaytypeBuilder` to construct a `Paytype` object, adds it to the list, and updates the cache with the new `Paytype` object.
- If an `EntityException` occurs during the building of a `Paytype` object, it handles the exception by calling `showEntityException` with relevant details.
- If an `SQLException` occurs during database operations, it handles the exception by calling `showSQLException`.
- Finally, it returns the list of `Paytype` objects.\\
## Code: 
```
List<Paytype> list(){
		
		List<Paytype> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Paytype> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM paytype;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			PaytypeBuilder builder;
			Paytype paytype;
			
			while(rs.next()) {
				
				builder = new PaytypeBuilder();
				builder.setId(rs.getInt("id"));
				builder.setTitle(rs.getString("title"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					paytype = builder.build();
					list.add(paytype);
					cache.put(paytype.getId(), paytype);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id") + " Title : " + rs.getString("title"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
	}
```