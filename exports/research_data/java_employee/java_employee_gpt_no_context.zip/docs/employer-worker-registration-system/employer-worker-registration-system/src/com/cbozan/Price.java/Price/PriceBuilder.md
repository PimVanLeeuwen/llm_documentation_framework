`PriceBuilder`: The function of `PriceBuilder` is to provide a flexible and convenient way to construct `Price` objects with various attributes.

**Code Description**: 
- The `PriceBuilder` class contains private fields for `id`, `fulltime`, `halftime`, `overtime`, and `date`, which are attributes of a `Price` object.
- It provides a no-argument constructor and a parameterized constructor to initialize these fields.
- The class includes setter methods (`setId`, `setFulltime`, `setHalftime`, `setOvertime`, `setDate`) for each field. These methods return the `PriceBuilder` instance, allowing for method chaining.
- The `build` method constructs and returns a new `Price` object using the current state of the `PriceBuilder` instance. If any required fields are missing or invalid, it throws an `EntityException`.\\
## Code: 
```
class PriceBuilder{
		
		private int id;
		private BigDecimal fulltime;
		private BigDecimal halftime;
		private BigDecimal overtime;
		private Timestamp date;
		
		public PriceBuilder() {}

		public PriceBuilder(int id, BigDecimal fulltime, BigDecimal halftime, BigDecimal overtime, Timestamp date) {
			super();
			this.id = id;
			this.fulltime = fulltime;
			this.halftime = halftime;
			this.overtime = overtime;
			this.date = date;
		}

		public PriceBuilder setId(int id) {
			this.id = id;
			return this;
		}

		public PriceBuilder setFulltime(BigDecimal fulltime) {
			this.fulltime = fulltime;
			return this;
		}

		public PriceBuilder setHalftime(BigDecimal halftime) {
			this.halftime = halftime;
			return this;
		}

		public PriceBuilder setOvertime(BigDecimal overtime) {
			this.overtime = overtime;
			return this;
		}

		public PriceBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Price build() throws EntityException{
			return new Price(this);
		}
		
	}
```