`setPrice_id`: The function of `setPrice_id` is to set the `price_id` attribute of the `JobBuilder` object.

**Code Description**: This method, `setPrice_id`, takes an integer parameter `price_id` and assigns it to the `price_id` field of the `JobBuilder` instance. It then returns the current instance of `JobBuilder`, allowing for method chaining.\\
## Code: 
```
JobBuilder setPrice_id(int price_id) {
			this.price_id = price_id;
			return this;
		}
```