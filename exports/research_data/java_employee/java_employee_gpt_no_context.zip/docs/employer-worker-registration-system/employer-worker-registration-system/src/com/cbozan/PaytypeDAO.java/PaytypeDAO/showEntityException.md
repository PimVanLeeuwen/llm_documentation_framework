`showEntityException`: The function of `showEntityException` is to display an error message dialog when an `EntityException` occurs.

**Code Description**: The `showEntityException` method takes an `EntityException` object `e` and a `String` message `msg` as parameters. It constructs a detailed error message by appending " not added" to the provided `msg`, followed by the exception's message, localized message, and cause. This constructed message is then displayed in a dialog box using `JOptionPane.showMessageDialog`.\\
## Code: 
```
void showEntityException(EntityException e, String msg) {
		String message = msg + " not added" + 
				"\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + e.getCause();
			JOptionPane.showMessageDialog(null, message);
	}
```