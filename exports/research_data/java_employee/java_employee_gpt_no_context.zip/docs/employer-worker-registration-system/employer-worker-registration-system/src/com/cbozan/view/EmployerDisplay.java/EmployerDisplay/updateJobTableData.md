`updateJobTableData`: The function of `updateJobTableData` is to update the job table with data related to the selected employer.

**Code Description**: 
- The function first checks if `selectedEmployer` is not null.
- It retrieves a list of jobs associated with the `selectedEmployer` using `JobDAO.getInstance().list(selectedEmployer)`.
- It initializes a 2D array `tableData` to hold the job data, with the number of rows equal to the size of `jobList` and the number of columns equal to the length of `jobTableColumns`.
- It iterates over the `jobList` and populates the `tableData` array with job details such as job ID, employer, title, and description.
- It updates the `JTable` within `jobScrollPane` with the new `tableData` and `jobTableColumns` using `DefaultTableModel`.
- It sets the preferred width of the first column to 5 and enables auto-resize mode for the last column.
- It centers the text in the first column using `DefaultTableCellRenderer`.
- Finally, it updates the `jobCountLabel` to display the number of jobs in the list.\\
## Code: 
```
void updateJobTableData() {
		
		if(selectedEmployer != null) {
			
			List<Job> jobList = JobDAO.getInstance().list(selectedEmployer);
			
			String[][] tableData = new String[jobList.size()][jobTableColumns.length];
			
			int i = 0;
			for(Job j : jobList) {
				
				tableData[i][0] = j.getId() + "";
				tableData[i][1] = j.getEmployer().toString();
				tableData[i][2] = j.getTitle();
				tableData[i][3] = j.getDescription();
				++i;
			}
			
			((JTable)jobScrollPane.getViewport().getComponent(0)).setModel(new DefaultTableModel(tableData, jobTableColumns));
			((JTable)jobScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setPreferredWidth(5);
			((JTable)jobScrollPane.getViewport().getComponent(0)).setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
			
			DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
			centerRenderer.setHorizontalAlignment( SwingConstants.CENTER );
			((JTable)jobScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
			
			jobCountLabel.setText(jobList.size() + " Kayıt");
		}
		
	}
```