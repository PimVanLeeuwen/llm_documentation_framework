`setLname`: The function of `setLname` is to set the last name of an employer.

**Code Description**: The `setLname` method is part of the `EmployerBuilder` class. It takes a single parameter, `lname`, which is a `String` representing the last name. The method assigns this value to the instance variable `lname` of the `EmployerBuilder` object. After setting the last name, the method returns the current instance of `EmployerBuilder` to allow for method chaining.\\
## Code: 
```
EmployerBuilder setLname(String lname) {
			this.lname = lname;
			return this;
		}
```