`createControl`: The function of `createControl` is to check if a job with the same title already exists in the cache.

**Code Description**: The `createControl` method takes a `Job` object as an argument and iterates through the entries in the `cache` map. For each entry, it compares the title of the job in the cache with the title of the provided job. If a job with the same title is found, it sets an error message in the `DB` class indicating that the job already exists and returns `false`. If no job with the same title is found, it returns `true`.\\
## Code: 
```
boolean createControl(Job job) {
		
		for(Entry<Integer, Job> obj : cache.entrySet()) {
			if(obj.getValue().getTitle().equals(job.getTitle())) {
				DB.ERROR_MESSAGE = obj.getValue().getTitle() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```