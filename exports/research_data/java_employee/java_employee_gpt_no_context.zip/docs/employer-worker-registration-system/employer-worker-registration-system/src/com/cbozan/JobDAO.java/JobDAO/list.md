`list`: The function of `list` is to retrieve a list of `Job` objects either from a cache or from a database.

**Code Description**: 
- The `list` method returns a list of `Job` objects.
- It first checks if the cache is not empty and if caching is enabled (`usingCache`).
  - If both conditions are met, it retrieves all `Job` objects from the cache and returns them.
- If the cache is empty or caching is not enabled, it clears the cache and proceeds to fetch data from the database.
- It establishes a connection to the database and executes a query to select all records from the `job` table.
- For each record in the result set, it uses a `JobBuilder` to create a `Job` object with the data from the database.
- Each successfully built `Job` object is added to the list and also stored in the cache.
- If an `EntityException` occurs during the building of a `Job` object, it logs the exception with details of the job.
- If an `SQLException` occurs during database operations, it logs the SQL exception.
- Finally, it returns the list of `Job` objects.\\
## Code: 
```
List<Job> list(){
		
		List<Job> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Job> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM job;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			JobBuilder builder;
			Job job;
			
			while(rs.next()) {
				
				builder = new JobBuilder();
				builder.setId(rs.getInt("id"));
				builder.setEmployer_id(rs.getInt("employer_id"));
				builder.setPrice_id(rs.getInt("price_id"));
				builder.setTitle(rs.getString("title"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					job = builder.build();
					list.add(job);
					cache.put(job.getId(), job);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id") + " Title : " + rs.getString("title"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
	}
```