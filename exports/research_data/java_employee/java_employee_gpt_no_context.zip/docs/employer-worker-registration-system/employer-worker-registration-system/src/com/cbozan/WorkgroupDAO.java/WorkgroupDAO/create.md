`create`: The function of `create` is to insert a new workgroup record into the database and update the cache with the newly created workgroup.

**Code Description**: 
- The `create` method takes a `Workgroup` object as a parameter.
- It establishes a connection to the database using `DB.getConnection()`.
- It prepares an SQL `INSERT` statement to add a new record to the `workgroup` table with the provided job ID, work type ID, work count, and description from the `Workgroup` object.
- The `executeUpdate` method is called to execute the insert operation, and the result is stored in the `result` variable.
- If the insert operation is successful (`result` is not 0), it executes a second query to retrieve the most recently added workgroup record.
- It iterates through the result set of the second query, using a `WorkgroupBuilder` to construct a `Workgroup` object from the retrieved data.
- The newly created `Workgroup` object is then added to a cache.
- If any exceptions occur during the process, they are caught and handled by `showSQLException` or `showEntityException` methods.
- The method returns `true` if the insert operation was successful, otherwise it returns `false`.\\
## Code: 
```
boolean create(Workgroup workgroup) {
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO workgroup (job_id,worktype_id,workcount,description) VALUES (?,?,?,?);";
		String query2 = "SELECT * FROM workgroup ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, workgroup.getJob().getId());
			pst.setInt(2, workgroup.getWorktype().getId());
			pst.setInt(3, workgroup.getWorkCount());
			pst.setString(4, workgroup.getDescription());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					WorkgroupBuilder builder = new WorkgroupBuilder();
					builder.setId(rs.getInt("id"));
					builder.setJob_id(rs.getInt("job_id"));
					builder.setWorktype_id(rs.getInt("worktype_id"));
					builder.setWorkCount(rs.getInt("workcount"));
					builder.setDescription(rs.getString("description"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Workgroup wg = builder.build();
						cache.put(wg.getId(), wg);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id"));
					}
					
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```