`findById`: The function of `findById` is to retrieve a `Workgroup` object by its ID from a cache, or return `null` if the ID is not found.

**Code Description**: The `findById` method takes an integer `id` as a parameter and attempts to find a `Workgroup` object with that ID. If the `usingCache` flag is `false`, it calls the `list()` method to presumably populate the cache. It then checks if the cache contains the given `id`. If the `id` is found in the cache, it returns the corresponding `Workgroup` object. If the `id` is not found, it returns `null`.\\
## Code: 
```
Workgroup findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```