`findById`: The function of `findById` is to retrieve an `Employer` object by its `id`.

**Code Description**: The `findById` method first checks if caching is enabled by evaluating the `usingCache` boolean. If caching is not enabled (`usingCache == false`), it calls the `list()` method, which presumably populates the cache. Then, it checks if the cache contains the specified `id`. If the `id` is found in the cache, it returns the corresponding `Employer` object. If the `id` is not found, it returns `null`.\\
## Code: 
```
Employer findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
	}
```