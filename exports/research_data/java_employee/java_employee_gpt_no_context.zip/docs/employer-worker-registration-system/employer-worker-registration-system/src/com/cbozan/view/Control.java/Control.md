`Control`: The function of `Control` is to provide utility methods for validating phone numbers, IBANs, and decimal numbers using regular expressions.

**Code Description**:
- `phoneNumberControl(String phoneNumber)`: Validates a Turkish phone number. It checks if the phone number matches the pattern `^((((\+90)?|(0)?)\d{10})|())$`, which allows for optional country code `+90` or `0` followed by 10 digits.
- `phoneNumberControl(String phoneNumber, String regex)`: Validates a phone number using a custom regular expression provided as a string.
- `phoneNumberControl(String phoneNumber, Pattern pattern)`: Validates a phone number using a custom regular expression provided as a `Pattern` object.

- `ibanControl(String iban)`: Validates a Turkish IBAN. It checks if the IBAN matches the pattern `^((TR\d{24})|())$`, which allows for the country code `TR` followed by 24 digits.
- `ibanControl(String iban, String regex)`: Validates an IBAN using a custom regular expression provided as a string.
- `ibanControl(String iban, Pattern pattern)`: Validates an IBAN using a custom regular expression provided as a `Pattern` object.

- `decimalControl(String ...args)`: Validates one or more decimal numbers. It checks if each number matches the pattern `^((\d+(\.\d{1,2})?)|())$`, which allows for integers or decimals with up to two decimal places.
- `decimalControl(Pattern pattern, String ...args)`: Validates one or more decimal numbers using a custom regular expression provided as a `Pattern` object.\\
## Code: 
```
class Control {

	public static boolean phoneNumberControl(String phoneNumber) {
		return Pattern.compile("^((((\\+90)?|(0)?)\\d{10})|())$").matcher(phoneNumber.replaceAll("\\s+", "")).find();
	}
	public static boolean phoneNumberControl(String phoneNumber, String regex) {
		return Pattern.compile(regex).matcher(phoneNumber.replaceAll("\\s+", "")).find();
	}
	public static boolean phoneNumberControl(String phoneNumber, Pattern pattern) {
		return pattern.matcher(phoneNumber).find();
	}
	
	
	public static boolean ibanControl(String iban) {
		return Pattern.compile("^((TR\\d{24})|())$", Pattern.CASE_INSENSITIVE).matcher(iban).find();
	}
	public static boolean ibanControl(String iban, String regex) {
		return Pattern.compile(regex).matcher(iban).find();
	}
	public static boolean ibanControl(String iban, Pattern pattern) {
		return pattern.matcher(iban).find();
	}
	
	
	public static boolean decimalControl(String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= Pattern.compile("^((\\d+(\\.\\d{1,2})?)|())$").matcher(arg).find();
		}
		return rValue;
	}
	public static boolean decimalControl(Pattern pattern, String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= pattern.matcher(arg).find();
		}
		return rValue;
	}
	
}
```