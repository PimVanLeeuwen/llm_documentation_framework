`decimalControl`: The function of `decimalControl` is to check if all provided string arguments are valid decimal numbers with up to two decimal places.

**Code Description**: 
- The method `decimalControl` accepts a variable number of string arguments.
- It uses a regular expression pattern `^\\d+(\\.\\d{1,2})?$` to match valid decimal numbers. This pattern ensures that the string starts with one or more digits (`\\d+`), optionally followed by a period and one or two digits (`(\\.\\d{1,2})?`).
- The method initializes a boolean variable `result` to `true`.
- It iterates over each string argument, removes any whitespace using `replaceAll("\\s+", "")`, and checks if the cleaned string matches the decimal pattern.
- The `result` variable is updated using a logical AND operation with the current match result.
- Finally, the method returns `true` if all arguments match the decimal pattern, otherwise it returns `false`.\\
## Code: 
```
boolean decimalControl(String ...args) {
		Pattern pattern = Pattern.compile("^\\d+(\\.\\d{1,2})?$"); // decimal pattern xxx.xx
		boolean result = true;
		
		for(String arg : args)
			result = result && pattern.matcher(arg.replaceAll("\\s+", "")).find();
		
		return result;
	}
```