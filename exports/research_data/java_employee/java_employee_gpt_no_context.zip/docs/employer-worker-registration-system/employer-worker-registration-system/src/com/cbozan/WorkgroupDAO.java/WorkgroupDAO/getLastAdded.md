`getLastAdded`: The function of `getLastAdded` is to retrieve the most recently added workgroup from the database.

**Code Description**: 
- The method `getLastAdded` initializes a `Workgroup` object to `null`.
- It establishes a connection to the database using `DB.getConnection()`.
- It creates a `Statement` object and executes a SQL query to select the most recent entry from the `workgroup` table, ordered by `id` in descending order and limited to one result.
- It iterates through the result set, creating a `WorkgroupBuilder` object and setting its properties using the data retrieved from the result set.
- The `WorkgroupBuilder` object is then used to build a `Workgroup` object.
- If an `EntityException` occurs during the building process, the error message is printed to the standard error stream.
- If a `SQLException` occurs during the database operations, the error message is printed to the standard output stream.
- Finally, the method returns the `Workgroup` object representing the most recently added workgroup. If no workgroup is found or an error occurs, it returns `null`.\\
## Code: 
```
Workgroup getLastAdded() {
		
		Workgroup workgroup = null;
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM workgroup ORDER BY id DESC LIMIT 1";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			WorkgroupBuilder builder; 
			
			while(rs.next()) {
				
				builder = new WorkgroupBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setWorktype_id(rs.getInt("worktype_id"));
				builder.setWorkCount(rs.getInt("workcount"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					workgroup = builder.build();
				} catch (EntityException e) {
					System.err.println(e.getMessage());
				}
				
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return workgroup;
	}
```