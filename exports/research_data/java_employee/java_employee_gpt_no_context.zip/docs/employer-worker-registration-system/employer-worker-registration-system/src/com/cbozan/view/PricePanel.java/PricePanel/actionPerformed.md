`actionPerformed`: The function of `actionPerformed` is to handle the event triggered by the `saveButton` and process the input data from text fields, validate it, and save it to the database if valid.

**Code Description**: 
- The method starts by checking if the event source is the `saveButton`.
- It retrieves and trims the text from `fulltimeTextField`, `halftimeTextField`, and `overtimeTextField`.
- It validates the input data using the `Control.decimalControl` method to ensure the data is in the correct format (max 2 decimal points).
- If the validation fails, it displays an error message using `JOptionPane`.
- If the validation passes, it creates non-editable `JTextArea` components for each price and displays them in a confirmation dialog.
- The confirmation dialog presents the user with "SAVE" and "CANCEL" options.
- If the user selects "SAVE", it builds a `Price` object using the `Price.PriceBuilder` class.
- It attempts to save the `Price` object to the database using `PriceDAO`.
- If the save operation is successful, it shows a success message and notifies all observers.
- If the save operation fails, it shows an error message indicating a database error.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == saveButton) {
			
			String fulltime, halftime, overtime;
			
			fulltime = fulltimeTextField.getText().replaceAll("\\s+", "");
			halftime = halftimeTextField.getText().replaceAll("\\s+", "");
			overtime = overtimeTextField.getText().replaceAll("\\s+", "");
			
			if(!Control.decimalControl(fulltime, halftime, overtime)) {
				
				String message = "Please fill in the required fields or enter correctly format (max 2 floatpoint)";
				JOptionPane.showMessageDialog(this, message, "ERROR", JOptionPane.ERROR_MESSAGE);
				
			} else {
				
				JTextArea fulltimeTextArea, halftimeTextArea, overtimeTextArea;
				
				fulltimeTextArea = new JTextArea(fulltime + " ₺");
				fulltimeTextArea.setEditable(false);
				
				halftimeTextArea = new JTextArea(halftime + " ₺");
				halftimeTextArea.setEditable(false);
				
				overtimeTextArea = new JTextArea(overtime + " ₺");
				overtimeTextArea.setEditable(false);
				
				Object[] pane = {
						new JLabel("Fulltime Price"),
						fulltimeTextArea,
						new JLabel("Halftime Price"),
						halftimeTextArea,
						new JLabel("Overtime Price"),
						overtimeTextArea
				};
				
				
		
				int result = JOptionPane.showOptionDialog(this, pane, "Confirmation", 1, 1, 
						new ImageIcon("src\\icon\\accounting_icon_1_32.png"), new Object[] {"SAVE", "CANCEL"}, "CANCEL");
				
				
				// System.out.println(result);
				// 0 -> SAVE
				// 1 -> CANCEL
				
				if(result == 0) {
					
					Price.PriceBuilder builder = new Price.PriceBuilder();
					builder.setId(Integer.MAX_VALUE);
					builder.setFulltime(new BigDecimal(fulltime));
					builder.setHalftime(new BigDecimal(halftime));
					builder.setOvertime(new BigDecimal(overtime));
					
					Price price = null;
					try {
						price = builder.build();
					} catch (EntityException e1) {
						System.out.println(e1.getMessage());
					}
					
					if(PriceDAO.getInstance().create(price)) { 
						JOptionPane.showMessageDialog(this, "Registration Successful");
						notifyAllObservers();
					} else {
						JOptionPane.showMessageDialog(this, "Not saved", "DataBase error", JOptionPane.ERROR_MESSAGE);
					}
				}
				
			}
			
			
		}
		
	}
```