`actionPerformed`: The function of `actionPerformed` is to handle an action event triggered by a user interaction, such as a button click, and update the displayed content accordingly.

**Code Description**: This method first checks if the action command (a string representing a number) is within the valid range of component indices. If the action command corresponds to the currently active page, it updates the content of that page. If the action command corresponds to a different page, it sets the active page to the new page index. The content pane is then updated to display the new active page, and the layout is revalidated to reflect the changes.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		if(Integer.parseInt(e.getActionCommand())>= 0 && Integer.parseInt(e.getActionCommand()) < components.size()) {
			if(Integer.parseInt(e.getActionCommand()) == activePage) {
				components.get(activePage).update();
			} else {
				activePage = (byte) Integer.parseInt(e.getActionCommand());
			}
			setContentPane((JPanel)components.get(activePage));
			
			revalidate();
		}
		
	}
```