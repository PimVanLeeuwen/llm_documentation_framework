`InvoiceBuilder`: The function of `InvoiceBuilder` is to provide a flexible and convenient way to construct `Invoice` objects using the builder pattern.

**Code Description**: 
- The `InvoiceBuilder` class contains private fields for `id`, `job_id`, `job`, `amount`, and `date`, which represent the attributes of an invoice.
- It provides two constructors: a default constructor and a parameterized constructor that initializes `id`, `job_id`, `amount`, and `date`.
- Another constructor initializes `id`, `job`, `amount`, and `date`, setting `job_id` to 0.
- The class includes setter methods (`setId`, `setJob_id`, `setJob`, `setAmount`, `setDate`) for each field, which return the `InvoiceBuilder` instance to allow method chaining.
- The `build` method constructs and returns an `Invoice` object. If the `job` field is null, it creates an `Invoice` using the `InvoiceBuilder` instance; otherwise, it uses the `id`, `job`, `amount`, and `date` fields directly.
- The `build` method throws an `EntityException` if there is an issue during the construction of the `Invoice` object.\\
## Code: 
```
class InvoiceBuilder{
		
		private int id;
		private int job_id;
		private Job job;
		private BigDecimal amount;
		private Timestamp date;
		
		public InvoiceBuilder() {}
		public InvoiceBuilder(int id, int job_id, BigDecimal amount, Timestamp date) {
			this.id = id;
			this.job_id = job_id;
			this.amount = amount;
			this.date = date;
		}
		
		public InvoiceBuilder(int id, Job job, BigDecimal amount, Timestamp date) {
			this(id, 0, amount, date);
			this.job = job;
		}
		
		public InvoiceBuilder setId(int id) {
			this.id = id;
			return this;
		}
		
		public InvoiceBuilder setJob_id(int job_id) {
			this.job_id = job_id;
			return this;
		}
		
		public InvoiceBuilder setJob(Job job) {
			this.job = job;
			return this;
		}
		
		public InvoiceBuilder setAmount(BigDecimal amount) {
			this.amount = amount;
			return this;
		}
		
		public InvoiceBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Invoice build() throws EntityException {
			if(job == null)
				return new Invoice(this);
			return new Invoice(id, job, amount, date);
		}
		
	}
```