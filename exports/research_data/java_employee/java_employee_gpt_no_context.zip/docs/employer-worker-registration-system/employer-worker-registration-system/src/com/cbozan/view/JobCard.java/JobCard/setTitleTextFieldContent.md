`setTitleTextFieldContent`: The function of `setTitleTextFieldContent` is to set the text of a title text field and update the title of the selected job if one is selected.

**Code Description**: The `setTitleTextFieldContent` method takes a `String` parameter `title` and sets this value as the text of the `titleTextField`. It then attempts to update the title of the currently selected job (if any) by calling `setTitle` on the selected job object. If an `EntityException` is thrown during this process, the exception is caught and its stack trace is printed.\\
## Code: 
```
void setTitleTextFieldContent(String title) {
		this.titleTextField.setText(title);
		
		try {
			if(getSelectedJob() != null)
				getSelectedJob().setTitle(title);
		} catch (EntityException e) {
			e.printStackTrace();
		}
	}
```