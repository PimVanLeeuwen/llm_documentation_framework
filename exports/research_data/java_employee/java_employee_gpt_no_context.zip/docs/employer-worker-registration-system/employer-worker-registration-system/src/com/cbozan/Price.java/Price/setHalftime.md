`setHalftime`: The function of `setHalftime` is to set the value of the `halftime` property.

**Code Description**: 
- The method `setHalftime` takes a `BigDecimal` parameter named `halftime`.
- It checks if the `halftime` parameter is `null` or less than or equal to zero.
- If the `halftime` parameter is `null` or less than or equal to zero, it throws an `EntityException` with the message "Price halftime negative or null or zero".
- If the `halftime` parameter is valid (i.e., not `null` and greater than zero), it assigns the value of `halftime` to the instance variable `this.halftime`.\\
## Code: 
```
void setHalftime(BigDecimal halftime) throws EntityException {
		if(halftime == null || halftime.compareTo(new BigDecimal("0.00")) <= 0)
			throw new EntityException("Price halftime negative or null or zero");
		this.halftime = halftime;
	}
```