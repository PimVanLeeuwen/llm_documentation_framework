`focusLost`: The function of `focusLost` is to handle the event when a text field loses focus and update its border color based on the validity of its content.

**Code Description**: 
- The `focusLost` method is triggered when a component loses focus.
- It first checks if the source of the event is an instance of `JTextField`.
- It initializes a `Color` object to white.
- It then calls the `decimalControl` method with the text from the `JTextField` to check if the text is a valid decimal number.
- If the text is valid, it sets the color to green (`new Color(0, 180, 0)`); otherwise, it sets the color to red.
- It updates the border of the `JTextField` with a `LineBorder` of the determined color.
- If the `JTextField` is the `amountTextField`, it also updates the foreground color of the `amountLabel` to match the determined color.\\
## Code: 
```
void focusLost(FocusEvent e) {
		if(e.getSource() instanceof JTextField) {
			
			Color color = Color.white;
			
			if(decimalControl(((JTextField)e.getSource()).getText())) {
				color = new Color(0, 180, 0);
			} else {
				color = Color.red;
			}
			
			((JTextField)e.getSource()).setBorder(new LineBorder(color));
		
			if(((JTextField)e.getSource()) == amountTextField) {
				amountLabel.setForeground(color);
			}
		}
	}
```