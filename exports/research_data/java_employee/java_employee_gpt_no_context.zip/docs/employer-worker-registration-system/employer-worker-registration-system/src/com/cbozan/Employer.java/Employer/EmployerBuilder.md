`EmployerBuilder`: The function of `EmployerBuilder` is to provide a flexible and convenient way to construct `Employer` objects using the builder pattern.

**Code Description**: 
- The `EmployerBuilder` class contains private fields for `id`, `fname` (first name), `lname` (last name), `tel` (a list of telephone numbers), `description`, and `date` (a timestamp).
- It provides two constructors: a no-argument constructor and a parameterized constructor that initializes all fields.
- The class includes setter methods (`setId`, `setFname`, `setLname`, `setTel`, `setDescription`, `setDate`) for each field. These methods return the `EmployerBuilder` instance, allowing for method chaining.
- The `build` method constructs and returns an `Employer` object using the current state of the `EmployerBuilder` instance. If any required fields are missing or invalid, it throws an `EntityException`.\\
## Code: 
```
class EmployerBuilder{
		
		private int id;
		private String fname;
		private String lname;
		private List<String> tel;
		private String description;
		private Timestamp date;

		public EmployerBuilder() {}
		public EmployerBuilder(int id, String fname, String lname, List<String> tel, String description, Timestamp date) {
			super();
			this.id = id;
			this.fname = fname;
			this.lname = lname;
			this.tel = tel;
			this.description = description;
			this.date = date;
		}

		public EmployerBuilder setId(int id) {
			this.id = id;
			return this;
		}

		public EmployerBuilder setFname(String fname) {
			this.fname = fname;
			return this;
		}

		public EmployerBuilder setLname(String lname) {
			this.lname = lname;
			return this;
		}

		public EmployerBuilder setTel(List<String> tel) {
			this.tel = tel;
			return this;
		}

		public EmployerBuilder setDescription(String description) {
			this.description = description;
			return this;
		}

		public EmployerBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Employer build() throws EntityException {
			return new Employer(this);
		}		
		
	}
```