`list`: The function of `list` is to retrieve a list of `Worker` objects either from a cache or from a database.

**Code Description**: 
- The `list` method initializes an empty list of `Worker` objects.
- It checks if the cache is not empty and if the `usingCache` flag is true. If both conditions are met, it populates the list with `Worker` objects from the cache and returns the list.
- If the cache is empty or `usingCache` is false, it clears the cache and proceeds to fetch data from the database.
- It establishes a database connection, creates a statement, and executes a query to select all records from the `worker` table.
- For each record in the result set, it uses a `WorkerBuilder` to construct a `Worker` object, setting its properties from the database fields.
- If the `tel` field is not null, it converts it to a list of strings.
- It adds each successfully built `Worker` object to the list and updates the cache with the new `Worker` object.
- If an `EntityException` occurs during the building of a `Worker` object, it handles the exception by calling `showEntityException`.
- If an `SQLException` occurs during database operations, it handles the exception by calling `showSQLException`.
- Finally, it returns the list of `Worker` objects.\\
## Code: 
```
List<Worker> list(){
		
		List<Worker> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Worker> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM worker;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorkerBuilder builder;
			Worker worker;
			
			while(rs.next()) {
				
				builder = new WorkerBuilder();
				builder.setId(rs.getInt("id"));
				builder.setFname(rs.getString("fname"));
				builder.setLname(rs.getString("lname"));
				
				if(rs.getArray("tel") == null)
					builder.setTel(null);
				else
					builder.setTel(Arrays.asList((String [])rs.getArray("tel").getArray()));
				
				builder.setIban(rs.getString("iban"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					worker = builder.build();
					list.add(worker);
					cache.put(worker.getId(), worker);
				} catch (EntityException e) {
					showEntityException(e, rs.getString("fname") + " " + rs.getShort("lname"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
		
	}
```