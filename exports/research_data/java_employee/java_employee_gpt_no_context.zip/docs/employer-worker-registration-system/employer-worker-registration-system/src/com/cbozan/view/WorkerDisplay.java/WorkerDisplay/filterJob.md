`filterJob`: The function of `filterJob` is to filter out elements from a list of `Work` objects based on a specific job criterion.

**Code Description**: The `filterJob` method takes a list of `Work` objects as input and removes any `Work` object from the list whose associated job's ID does not match the ID of the `selectedWorkTableJob`. If `selectedWorkTableJob` is `null`, the method returns immediately without making any changes to the list. The method uses an iterator to traverse the list and remove elements that do not meet the specified condition.\\
## Code: 
```
void filterJob(List<Work> workList) {
		if(selectedWorkTableJob == null) {
			return;
		}
		
		Iterator<Work> work = workList.iterator();
		Work workItem;
		while(work.hasNext()) {
			workItem = work.next();
			if(workItem.getJob().getId() != selectedWorkTableJob.getId()) {
				work.remove();
			}
		}
		
	}
```