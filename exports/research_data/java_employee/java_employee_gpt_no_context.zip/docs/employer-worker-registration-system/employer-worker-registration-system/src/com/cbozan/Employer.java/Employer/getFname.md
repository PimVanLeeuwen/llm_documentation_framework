`getFname`: The function of `getFname` is to return the value of the `fname` variable.

**Code Description**: This method, `getFname`, is a getter function that retrieves and returns the value stored in the instance variable `fname`. It does not take any parameters and returns a `String` type value. This method is typically used to access the private `fname` variable from outside the class, adhering to the principles of encapsulation in object-oriented programming.\\
## Code: 
```
String getFname() {
		return fname;
	}
```