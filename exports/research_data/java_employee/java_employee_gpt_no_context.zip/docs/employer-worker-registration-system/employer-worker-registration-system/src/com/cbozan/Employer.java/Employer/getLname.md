`getLname`: The function of `getLname` is to return the value of the `lname` variable.

**Code Description**: This method, `getLname`, is a getter function that retrieves the value stored in the private instance variable `lname`. When called, it returns the current value of `lname` to the caller. This is typically used in object-oriented programming to provide controlled access to the private fields of a class.\\
## Code: 
```
String getLname() {
		return lname;
	}
```