`decimalControl`: The function of `decimalControl` is to check if all provided strings match a given regular expression pattern.

**Code Description**: The `decimalControl` method takes a `Pattern` object and a variable number of `String` arguments. It initializes a boolean variable `rValue` to `true`. It then iterates over each string in the `args` array, updating `rValue` to the result of a logical AND operation between the current value of `rValue` and the result of checking if the pattern matches the current string. If all strings match the pattern, the method returns `true`; otherwise, it returns `false`.\\
## Code: 
```
boolean decimalControl(Pattern pattern, String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= pattern.matcher(arg).find();
		}
		return rValue;
	}
```