`updateEmployerPaymentTableData`: The function of `updateEmployerPaymentTableData` is to update the employer payment table with the latest invoice data for the selected employer.

**Code Description**: 
- The function first checks if `selectedEmployer` is not null.
- It retrieves a list of invoices for the `selectedEmployer` using `InvoiceDAO.getInstance().list(selectedEmployer)`.
- The `filterPaymentJob` method is called to filter the invoice list.
- It initializes a 2D array `tableData` to store the invoice details and a `BigDecimal` variable `totalAmount` to calculate the total payment amount.
- It iterates over the `invoiceList`, populating `tableData` with invoice details (ID, job, amount, and date) and updating the `totalAmount`.
- The table model of the `JTable` within `employerPaymentScrollPane` is updated with the new `tableData` and column headers `employerPaymentTableColumns`.
- The first column's width is set to 5, and the table is set to auto-resize the last column.
- A `DefaultTableCellRenderer` is used to center-align the cells in the first column.
- The `employerPaymentTotalLabel` is updated to display the total payment amount.
- The `employerPaymentCountLabel` is updated to display the number of records in the `invoiceList`.\\
## Code: 
```
void updateEmployerPaymentTableData() {
		
		if(selectedEmployer != null) {
			
			List<Invoice> invoiceList = InvoiceDAO.getInstance().list(selectedEmployer);
			filterPaymentJob(invoiceList);
			
			String[][] tableData = new String[invoiceList.size()][employerPaymentTableColumns.length];
			BigDecimal totalAmount = new BigDecimal("0.00");
			int i = 0;
			for(Invoice invoice : invoiceList) {
				tableData[i][0] = invoice.getId() + "";
				tableData[i][1] = invoice.getJob().toString();
				tableData[i][2] = invoice.getAmount() + " ₺";
				tableData[i][3] = new SimpleDateFormat("dd.MM.yyyy").format(invoice.getDate());
				totalAmount = totalAmount.add(invoice.getAmount());
				++i;
			}
			
			((JTable)employerPaymentScrollPane.getViewport().getComponent(0)).setModel(new DefaultTableModel(tableData, employerPaymentTableColumns));
			((JTable)employerPaymentScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setPreferredWidth(5);
			((JTable)employerPaymentScrollPane.getViewport().getComponent(0)).setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
			
			DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
			centerRenderer.setHorizontalAlignment( SwingConstants.CENTER );
			((JTable)employerPaymentScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
			
			employerPaymentTotalLabel.setText("Total " + totalAmount + " ₺");
			employerPaymentCountLabel.setText(invoiceList.size() + " Record");
			
		}
		
	}
```