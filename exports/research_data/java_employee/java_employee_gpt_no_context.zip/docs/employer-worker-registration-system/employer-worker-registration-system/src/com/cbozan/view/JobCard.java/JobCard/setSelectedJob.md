`setSelectedJob`: The function of `setSelectedJob` is to update the UI components based on the selected job.

**Code Description**: 
- The method `setSelectedJob` takes a `Job` object as a parameter and assigns it to the instance variable `selectedJob`.
- If the `selectedJob` is `null`, it sets the text of `titleTextField`, `employerSearchBox`, `priceSearchBox`, and `descriptionTextArea` to a constant `INIT_TEXT`.
- If the `selectedJob` is not `null`, it updates the `titleTextField` and `descriptionTextArea` with the title and description of the `selectedJob` respectively using helper methods `setTitleTextFieldContent` and `setDescriptionTextAreaContent`.
- The method then iterates through all components of the current object:
  - If a component is an instance of `RecordTextField` or `TextArea`, it sets the component to be non-editable.
  - If a component is an instance of `JButton` and is not the `updateButton`, it sets the button's icon to a specific image ("src\\icon\\text_edit.png").\\
## Code: 
```
void setSelectedJob(Job selectedJob) {
		this.selectedJob = selectedJob;
		
		if(selectedJob == null) {
			titleTextField.setText(INIT_TEXT);
			employerSearchBox.setText(INIT_TEXT);
			priceSearchBox.setText(INIT_TEXT);
			descriptionTextArea.setText(INIT_TEXT);
		} else {
			
			setTitleTextFieldContent(selectedJob.getTitle());
			setDescriptionTextAreaContent(selectedJob.getDescription());
			
		}
		
		for(int i = 0; i < this.getComponentCount(); i++) {
			if(getComponent(i) instanceof RecordTextField)
				((RecordTextField)this.getComponent(i)).setEditable(false);
			else if(getComponent(i) instanceof TextArea)
				((TextArea)getComponent(i)).setEditable(false);
			else if(getComponent(i) instanceof JButton && (this.getComponent(i) != updateButton))
				((JButton)this.getComponent(i)).setIcon(new ImageIcon("src\\icon\\text_edit.png"));
		}
	}
```