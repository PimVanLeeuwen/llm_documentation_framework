`equals`: The function of `equals` is to determine whether the current `Price` object is equal to another object.

**Code Description**: This `equals` method overrides the default `equals` method to provide a custom equality check for `Price` objects. It first checks if the current object (`this`) is the same as the object being compared (`obj`). If they are the same, it returns `true`. If the object being compared is `null`, it returns `false`. It then checks if the classes of the two objects are the same; if not, it returns `false`. If the classes are the same, it casts the object to a `Price` type and compares the `date`, `fulltime`, `halftime`, `id`, and `overtime` fields of both objects using the `Objects.equals` method for object fields and a direct comparison for the `id` field. If all these fields are equal, it returns `true`; otherwise, it returns `false`.\\
## Code: 
```
boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Price other = (Price) obj;
		return Objects.equals(date, other.date) && Objects.equals(fulltime, other.fulltime)
				&& Objects.equals(halftime, other.halftime) && id == other.id
				&& Objects.equals(overtime, other.overtime);
	}
```