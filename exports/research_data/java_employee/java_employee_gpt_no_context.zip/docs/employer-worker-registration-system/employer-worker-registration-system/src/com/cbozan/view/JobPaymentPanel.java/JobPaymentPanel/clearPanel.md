`clearPanel`: The function of `clearPanel` is to reset the user interface elements related to invoice data and update the invoice table with the latest data for a selected job.

**Code Description**: 
- The `clearPanel` method first clears the text and border of the `amountTextField` and resets the `amountLabel` color to its default.
- If a job is selected (`selectedJob` is not null), it retrieves a list of invoices associated with the selected job using `InvoiceDAO`.
- It then formats the invoice data into a 2D array (`tableData`) suitable for display in a table.
- The method updates the table model of a `JTable` contained within `lastPaymentsScroll` with the new invoice data.
- It sets the preferred width for the first column and adjusts the table to auto-resize the last column.
- Finally, it centers the text in all columns of the table using a `DefaultTableCellRenderer`.\\
## Code: 
```
void clearPanel() {
		
		amountTextField.setText("");
		amountTextField.setBorder(new LineBorder(Color.white));
		amountLabel.setForeground(defaultColor);
		
		
		if(selectedJob != null) {
			
			List<Invoice> invoiceList = InvoiceDAO.getInstance().list("job_id", selectedJob.getId());
			String[][] tableData = new String[invoiceList.size()][invoiceTableColumns.length];
			int i = 0;
			for(Invoice invoice : invoiceList) {
				tableData[i][0] = invoice.getId() + "";
				tableData[i][1] = NumberFormat.getInstance().format(invoice.getAmount()) + " ₺";
				tableData[i][2] = new SimpleDateFormat("dd.MM.yyyy").format(invoice.getDate()); 
				++i;
			}
			
			((JTable)lastPaymentsScroll.getViewport().getComponent(0)).setModel(new DefaultTableModel(tableData, invoiceTableColumns));
			((JTable)lastPaymentsScroll.getViewport().getComponent(0)).getColumnModel().getColumn(0).setPreferredWidth(5);
			((JTable)lastPaymentsScroll.getViewport().getComponent(0)).setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
			
			DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
			centerRenderer.setHorizontalAlignment( SwingConstants.CENTER );
			((JTable)lastPaymentsScroll.getViewport().getComponent(0)).getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
			((JTable)lastPaymentsScroll.getViewport().getComponent(0)).getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
			((JTable)lastPaymentsScroll.getViewport().getComponent(0)).getColumnModel().getColumn(2).setCellRenderer(centerRenderer);
		}
		
		
	}
```