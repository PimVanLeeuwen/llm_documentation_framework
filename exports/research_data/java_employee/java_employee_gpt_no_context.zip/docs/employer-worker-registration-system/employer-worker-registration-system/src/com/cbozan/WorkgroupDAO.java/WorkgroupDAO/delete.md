`delete`: The function of `delete` is to remove a specified workgroup from the database.

**Code Description**: 
- The `delete` method takes a `Workgroup` object as a parameter.
- It establishes a connection to the database using `DB.getConnection()`.
- It prepares an SQL `DELETE` statement to remove the workgroup with the specified ID from the `workgroup` table.
- The ID of the workgroup to be deleted is set in the prepared statement.
- The `executeUpdate` method is called to execute the delete operation.
- If the deletion is successful (i.e., `result` is not zero), the workgroup ID is removed from the cache.
- If an `SQLException` occurs during the process, it is caught and handled by the `showSQLException` method.
- The method returns `true` if the deletion was successful, otherwise it returns `false`.\\
## Code: 
```
boolean delete(Workgroup workgroup) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM workgroup WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, workgroup.getId());
			
			result = ps.executeUpdate();

			if(result != 0) {
				cache.remove(workgroup.getId());
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
		
	}
```