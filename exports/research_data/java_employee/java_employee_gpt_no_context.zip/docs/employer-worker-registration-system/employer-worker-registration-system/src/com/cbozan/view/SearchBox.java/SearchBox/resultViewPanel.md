`resultViewPanel`: The function of `resultViewPanel` is to update a panel with search results based on a given search text.

**Code Description**: 
- The function retrieves the search text, converts it to uppercase, and trims any leading or trailing whitespace.
- It clears the current panel and the search result list.
- It iterates through a list of objects, adding those that contain the search text to the search result list, up to a maximum of 10 results.
- For each search result, it creates a non-editable `JTextField` with specific styling and adds it to the panel.
- Each `JTextField` has mouse listeners to handle mouse events such as entering, exiting, and clicking.
- When a `JTextField` is clicked, it triggers a `mouseAction` function and hides the panel.
- Finally, the panel's size is adjusted based on the number of search results, and it is made visible and repainted.\\
## Code: 
```
void resultViewPanel() {
		
		String searchText = getText().trim().toUpperCase();
		getPanel().removeAll();
		getSearchResultList().clear();
		
		for(Object obj : getObjectList()) {
			if(obj.toString().contains(searchText)) {
				getSearchResultList().add(obj);
				if(getSearchResultList().size() >= 10) {
					break;
				}
				
			}
			
		}
		
		int i = 0;
		for(Object searchResultObj : getSearchResultList()) {
			
			JTextField tf = new JTextField(searchResultObj.toString());
			tf.setForeground(new Color(105, 35, 64));
			tf.setName(i + "");
			tf.setHorizontalAlignment(SwingConstants.CENTER);
			tf.setEditable(false);
			tf.setBackground(new Color(162, 208, 215));
			tf.setBorder(new LineBorder(new Color(202, 228, 232)));
			tf.setBounds(0, i * (getResultBoxSize().height + 1) + i, getResultBoxSize().width, getResultBoxSize().height);
			tf.addMouseListener(new MouseAdapter() {
				public void mouseExited(MouseEvent e) {
					tf.setBackground(getExitedColor());
					isEntered = false;
				}
				
				public void mouseEntered(MouseEvent e) {
					tf.setBackground(getEnteredColor());
					isEntered = true;
				}
				
				public void mouseClicked(MouseEvent e) {
					mouseAction(e, searchResultList.get(Integer.parseInt(tf.getName())), Integer.parseInt(tf.getName()));
					//selectedWorkerDefaultListModel.addElement(searchResultList.get(Integer.parseInt(tf.getName())));
					//workerList.remove(searchResultList.get(Integer.parseInt(tf.getName())));
					getPanel().setVisible(false);
					//selectedInfoCountLabel.setText(selectedWorkerDefaultListModel.size() + " kişi");
				}
			});
			
			getPanel().add(tf);
			
			++i;
		}
		
		getPanel().setSize(getPanel().getWidth(), getSearchResultList().size() * (getResultBoxSize().height + 2));
		getPanel().setVisible(true);
		getPanel().revalidate();
		getPanel().repaint();
		
		
	}
```