`addHeight`: The function of `addHeight` is to increase the height of an object by a specified amount.

**Code Description**: The `addHeight` method takes an integer parameter `height` and adds this value to the current height of the object. It does this by calling the `setSize` method with the current width (obtained from `getWidth()`) and the new height (calculated as the current height from `getHeight()` plus the `height` parameter). This effectively increases the height of the object while keeping its width unchanged.\\
## Code: 
```
void addHeight(int height) {
		setSize(getWidth(), getHeight() + height);
	}
```