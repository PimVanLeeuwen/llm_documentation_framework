`getSelectedObject`: The function of `getSelectedObject` is to return the currently selected object.

**Code Description**: This method, `getSelectedObject`, is a getter function that returns the value of the private field `selectedObject`. It does not take any parameters and simply provides access to the `selectedObject` from outside the class. This is useful for retrieving the current state or value of `selectedObject` without directly accessing the private field.\\
## Code: 
```
Object getSelectedObject() {
		return selectedObject;
	}
```