`equals`: The function of `equals` is to compare the current `Invoice` object with another object to determine if they are equal.

**Code Description**: This `equals` method first checks if the current object (`this`) is the same as the object being compared (`obj`). If they are the same, it returns `true`. If the object being compared is `null`, it returns `false`. It then checks if the classes of the two objects are different; if they are, it returns `false`. If the classes are the same, it casts the object being compared to an `Invoice` object and compares their `amount`, `date`, `id`, and `job` fields. If all these fields are equal, it returns `true`; otherwise, it returns `false`.\\
## Code: 
```
boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Invoice other = (Invoice) obj;
		return Objects.equals(amount, other.amount) && Objects.equals(date, other.date) && id == other.id
				&& Objects.equals(job, other.job);
	}
```