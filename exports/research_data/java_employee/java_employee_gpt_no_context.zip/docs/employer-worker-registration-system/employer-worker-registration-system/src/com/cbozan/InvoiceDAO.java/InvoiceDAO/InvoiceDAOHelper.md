`InvoiceDAOHelper`: The function of `InvoiceDAOHelper` is to provide a singleton instance of the `InvoiceDAO` class.

**Code Description**: The `InvoiceDAOHelper` class contains a private static final field named `instance`, which holds a single instance of the `InvoiceDAO` class. This ensures that only one instance of `InvoiceDAO` is created and used throughout the application, following the singleton design pattern.\\
## Code: 
```
class InvoiceDAOHelper {
		private static final InvoiceDAO instance = new InvoiceDAO();
	}
```