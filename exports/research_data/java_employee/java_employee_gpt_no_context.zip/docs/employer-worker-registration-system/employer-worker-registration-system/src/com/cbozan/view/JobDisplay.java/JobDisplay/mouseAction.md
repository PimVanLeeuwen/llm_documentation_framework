`mouseAction`: The function of `mouseAction` is to handle mouse events and update the UI components based on the selected job.

**Code Description**: 
- The `mouseAction` method takes three parameters: a `MouseEvent` object `e`, an `Object` `searchResultObject`, and an `int` `chooseIndex`.
- It casts the `searchResultObject` to a `Job` object and assigns it to the `selectedJob` variable.
- It sets the `selectedJob` in the `jobCard` by cloning the `selectedJob`.
- It updates the `jobSearchBox` text to the string representation of the `selectedJob` and makes the `jobSearchBox` non-editable.
- It calls `updateWorkgroupTableData()` and `updateJobPaymentTableData()` to refresh the relevant tables with the new job data.
- Finally, it calls the superclass's `mouseAction` method with the same parameters to ensure any additional behavior defined in the superclass is executed.\\
## Code: 
```
void mouseAction(MouseEvent e, Object searchResultObject, int chooseIndex) {
				selectedJob = (Job) searchResultObject;
				jobCard.setSelectedJob(selectedJob.clone());
				
				jobSearchBox.setText(selectedJob.toString());
				jobSearchBox.setEditable(false);
				
				updateWorkgroupTableData();
				updateJobPaymentTableData();
				
				super.mouseAction(e, searchResultObject, chooseIndex);
			}
```