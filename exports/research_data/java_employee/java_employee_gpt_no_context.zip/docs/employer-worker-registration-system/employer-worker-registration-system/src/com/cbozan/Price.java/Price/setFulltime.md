`setFulltime`: The function of `setFulltime` is to set the value of the `fulltime` attribute if the provided value is valid.

**Code Description**: The `setFulltime` method takes a `BigDecimal` parameter named `fulltime`. It first checks if the provided `fulltime` value is `null` or less than or equal to zero. If either condition is true, it throws an `EntityException` with the message "Price fulltime negative or null or zero". If the provided value is valid (i.e., not `null` and greater than zero), it assigns the value to the `fulltime` attribute of the object.\\
## Code: 
```
void setFulltime(BigDecimal fulltime) throws EntityException {
		if(fulltime == null || fulltime.compareTo(new BigDecimal("0.00")) <= 0)
			throw new EntityException("Price fulltime negative or null or zero");
		this.fulltime = fulltime;
	}
```