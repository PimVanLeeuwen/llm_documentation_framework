`setId`: The function of `setId` is to set the ID of an entity.

**Code Description**: The `setId` method takes an integer parameter `id` and sets it as the ID of the entity. If the provided `id` is less than or equal to zero, it throws an `EntityException` with the message "Work ID negative or zero". This ensures that the ID is always a positive integer.\\
## Code: 
```
void setId(int id) throws EntityException{
		if(id <= 0)
			throw new EntityException("Work ID negative or zero");
		this.id = id;
	}
```