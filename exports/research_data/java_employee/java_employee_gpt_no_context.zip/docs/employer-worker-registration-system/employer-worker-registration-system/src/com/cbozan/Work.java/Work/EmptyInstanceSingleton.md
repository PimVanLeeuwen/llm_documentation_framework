`EmptyInstanceSingleton`: The function of `EmptyInstanceSingleton` is to provide a singleton instance of the `Work` class.

**Code Description**: The `EmptyInstanceSingleton` class contains a private static final field named `instance` which holds a single instance of the `Work` class. This ensures that only one instance of `Work` is created and used throughout the application, following the singleton design pattern.\\
## Code: 
```
class EmptyInstanceSingleton{
		private static final Work instance = new Work(); 
	}
```