`update`: The function of `update` is to update the details of an existing employer in the database.

**Code Description**: 
- The `update` method takes an `Employer` object as a parameter and returns a boolean indicating the success of the update operation.
- It first calls the `updateControl` method with the `employer` object to perform some validation. If this validation fails (returns `false`), the method returns `false`.
- It establishes a connection to the database using `DB.getConnection()`.
- It prepares an SQL `UPDATE` statement to update the employer's first name (`fname`), last name (`lname`), telephone numbers (`tel`), and description (`description`) based on the employer's ID (`id`).
- The method sets the parameters of the prepared statement using the values from the `employer` object.
- It executes the update statement and stores the result.
- If the update is successful (i.e., `result` is not 0), it updates the cache with the new employer details.
- If an `SQLException` occurs during the process, it calls the `showSQLException` method to handle the exception.
- Finally, it returns `true` if the update was successful, otherwise `false`.\\
## Code: 
```
boolean update(Employer employer) {
		
		if(updateControl(employer) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE employer SET fname=?,"
				+ "lname=?, tel=?, description=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1, employer.getFname());
			pst.setString(2, employer.getLname());
			
			Array phones = conn.createArrayOf("VARCHAR", employer.getTel().toArray());
			pst.setArray(3, phones);
			
			pst.setString(4, employer.getDescription());
			pst.setInt(5, employer.getId());
			
			result = pst.executeUpdate();
			
			// update cache
			if(result != 0) {
				cache.put(employer.getId(), employer);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```