`JobDAO`: The function of `JobDAO` is to manage job records in a database, including creating, reading, updating, and deleting job entries, with optional caching for performance optimization.

**Code Description**: 
- `JobDAO` is a singleton class that provides methods to interact with job records in a database.
- It uses a `HashMap` named `cache` to store job objects for quick access, controlled by the `usingCache` boolean flag.
- The constructor `JobDAO()` initializes the cache by calling the `list()` method.
- `findById(int id)`: Retrieves a job by its ID, using the cache if enabled.
- `refresh()`: Clears the cache and reloads all job records from the database.
- `list(Employer employer)`: Returns a list of jobs for a specific employer, querying the database and updating the cache as needed.
- `list()`: Retrieves all job records from the database, either from the cache or by querying the database.
- `create(Job job)`: Adds a new job to the database and updates the cache if the job is successfully created.
- `createControl(Job job)`: Checks if a job with the same title already exists in the cache to prevent duplicates.
- `update(Job job)`: Updates an existing job in the database and the cache.
- `updateControl(Job job)`: Ensures that the updated job's title does not conflict with other jobs in the cache.
- `delete(Job job)`: Removes a job from the database and the cache.
- `isUsingCache()`: Returns the current state of the cache usage flag.
- `setUsingCache(boolean usingCache)`: Sets the cache usage flag.
- `JobDAOHelper`: A static inner class that holds the singleton instance of `JobDAO`.
- `getInstance()`: Provides access to the singleton instance of `JobDAO`.
- `showEntityException(EntityException e, String msg)`: Displays an error message for entity-related exceptions.
- `showSQLException(SQLException e)`: Displays an error message for SQL-related exceptions.\\
## Code: 
```
class JobDAO {
	
	private final HashMap<Integer, Job> cache = new HashMap<>();
	private boolean usingCache = true;
	
	private JobDAO() {list();}
	
	// Read by id
	public Job findById(int id) {
		
		if(usingCache == false)
			list();
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
	
	public void refresh() {
		setUsingCache(false);
		list();
		setUsingCache(true);
	}
	
	public List<Job> list(Employer employer){

		List<Job> jobList = new ArrayList<>();
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM job WHERE employer_id=" + employer.getId();
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			JobBuilder builder = new JobBuilder();
			Job job;
			
			while(rs.next()) {
				
				job = findById(rs.getInt("id"));
				if(job != null) { // cache control
					jobList.add(job);
				} else {
					
					builder.setId(rs.getInt("id"));
					builder.setEmployer_id(rs.getInt("employer_id"));
					builder.setPrice_id(rs.getInt("price_id"));
					builder.setTitle(rs.getString("title"));
					builder.setDescription(rs.getString("description"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						job = builder.build();
						jobList.add(job);
						cache.put(job.getId(), job);
					} catch (EntityException e) {
						showEntityException(e, "İŞ EKLEME HATASI");
					}
					
				}
			
			}
			
		} catch(SQLException sqle) {
			showSQLException(sqle);
		}
		
		return jobList;
		
	}
	
	
	//Read All
	public List<Job> list(){
		
		List<Job> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Job> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM job;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			JobBuilder builder;
			Job job;
			
			while(rs.next()) {
				
				builder = new JobBuilder();
				builder.setId(rs.getInt("id"));
				builder.setEmployer_id(rs.getInt("employer_id"));
				builder.setPrice_id(rs.getInt("price_id"));
				builder.setTitle(rs.getString("title"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					job = builder.build();
					list.add(job);
					cache.put(job.getId(), job);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id") + " Title : " + rs.getString("title"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
	}
	
	
	public boolean create(Job job) {
		
		if(createControl(job) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO job (employer_id,price_id,title,description) VALUES (?,?,?,?);";
		String query2 = "SELECT * FROM job ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, job.getEmployer().getId());
			pst.setInt(2, job.getPrice().getId());
			pst.setString(3, job.getTitle());
			pst.setString(4, job.getDescription());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					JobBuilder builder = new JobBuilder();
					builder.setId(rs.getInt("id"));
					builder.setEmployer_id(rs.getInt("employer_id"));
					builder.setPrice_id(rs.getInt("price_id"));
					builder.setTitle(rs.getString("title"));
					builder.setDescription(rs.getString("description"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Job obj = builder.build();
						cache.put(obj.getId(), obj);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id") + " Title : " + rs.getString("title"));
					}
				}
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
	
	private boolean createControl(Job job) {
		
		for(Entry<Integer, Job> obj : cache.entrySet()) {
			if(obj.getValue().getTitle().equals(job.getTitle())) {
				DB.ERROR_MESSAGE = obj.getValue().getTitle() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
	
	
	public boolean update(Job job) {
		
		if(updateControl(job) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE job SET employer_id=?,"
				+ "price_id=?, title=?, description=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, job.getEmployer().getId());
			pst.setInt(2, job.getPrice().getId());
			pst.setString(3, job.getTitle());
			pst.setString(4, job.getDescription());
			pst.setInt(5, job.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(job.getId(), job);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
	
	private boolean updateControl(Job job) {
		for(Entry<Integer, Job> obj : cache.entrySet()) {
			if(obj.getValue().getTitle().equals(job.getTitle()) && obj.getValue().getId() != job.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getTitle() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
	
	
	public boolean delete(Job job) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM job WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, job.getId());
			
			result = ps.executeUpdate();
			
			if(result != 0) {
				cache.remove(job.getId());
			}

		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
		
	}
	
	public boolean isUsingCache() {
		return this.usingCache;
	}
	
	public void setUsingCache(boolean usingCache) {
		this.usingCache = usingCache;
	}

	
	private static class JobDAOHelper {
		private static final JobDAO instance = new JobDAO();
	}
	
	public static JobDAO getInstance() {
		return JobDAOHelper.instance;
	}
	
	private void showEntityException(EntityException e, String msg) {
		String message = msg + " not added" + 
				"\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + e.getCause();
			JOptionPane.showMessageDialog(null, message);
	}
	
	private void showSQLException(SQLException e) {
		String message = e.getErrorCode() + "\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + "\n" + e.getCause();
		JOptionPane.showMessageDialog(null, message);
	}
}
```