`save`: The function of `save` is to validate user input from text fields, display a confirmation dialog, and save the data to a database if confirmed.

**Code Description**: 
The `save` method is triggered by an `ActionEvent`. It retrieves and processes user input from several text fields (`fnameTextField`, `lnameTextField`, `phoneNumberTextField`) and a text area within a scroll pane (`descriptionScrollPane`). The first name and last name are trimmed and converted to uppercase, while the phone number is stripped of whitespace. The description is also trimmed and converted to uppercase.

The method then checks if the first name or last name fields are empty or if the phone number is invalid using the `Control.phoneNumberControl` method. If any of these conditions are met, an error message is displayed using `JOptionPane.showMessageDialog`.

If the input is valid, the method creates non-editable `JTextArea` components for each piece of data and displays them in a confirmation dialog using `JOptionPane.showOptionDialog`. If the user confirms the save operation (result equals 0), an `Employer` object is built using the `Employer.EmployerBuilder` class. The builder sets the ID to `Integer.MAX_VALUE`, assigns the first name, last name, phone number (if provided), and description to the `Employer` object.

The method then attempts to save the `Employer` object to the database using `EmployerDAO.getInstance().create`. If the save operation is successful, a success message is displayed, and `notifyAllObservers` is called. If the save operation fails, an error message is displayed indicating a database error.\\
## Code: 
```
void save(ActionEvent e) {
		String fname, lname, phoneNumber, description;
		
		fname = fnameTextField.getText().trim().toUpperCase();
		lname = lnameTextField.getText().trim().toUpperCase();
		phoneNumber = phoneNumberTextField.getText().replaceAll("\\s+", "");
		description = ((JTextArea)((JViewport)descriptionScrollPane.getComponent(0)).getComponent(0)).getText().trim().toUpperCase();
		
		if( fname.equals("") || lname.equals("") || !Control.phoneNumberControl(phoneNumber) ) {
			
			String message = "Please fill in required fields or \\nEnter the Phone Number format correctly";
			JOptionPane.showMessageDialog(this, message, "ERROR", JOptionPane.ERROR_MESSAGE);
			
		} else {
			
			JTextArea fnameTextArea, lnameTextArea, phoneNumberTextArea, descriptionTextArea; 
			
			fnameTextArea = new JTextArea(fname);
			fnameTextArea.setEditable(false);
			
			lnameTextArea = new JTextArea(lname);
			lnameTextArea.setEditable(false);
			
			phoneNumberTextArea = new JTextArea(phoneNumber);
			phoneNumberTextArea.setEditable(false);
			
			descriptionTextArea = new JTextArea(description);
			descriptionTextArea.setEditable(false);
			
			Object[] pane = {
					new JLabel("Name"),
					fnameTextArea,
					new JLabel("Surname"),
					lnameTextArea,
					new JLabel("Phone Number"),
					phoneNumberTextArea,
					new JLabel("Description"),
					new JScrollPane(descriptionTextArea) {
						private static final long serialVersionUID = 1L;
						public Dimension getPreferredSize() {
							return new Dimension(200, TH * 3);
						}
					}
			};
			

			int result = JOptionPane.showOptionDialog(this, pane, "Confirmation", 1, 1, 
					new ImageIcon("src\\icon\\accounting_icon_1_32.png"), new Object[] {"SAVE", "CANCEL"}, "CANCEL");
			
			// System.out.println(result);
			// 0 -> SAVE
			// 1 -> CANCEL
					
			if(result == 0) {
				
				Employer.EmployerBuilder builder = new Employer.EmployerBuilder();
				builder.setId(Integer.MAX_VALUE);
				builder.setFname(fname);
				builder.setLname(lname);
				if(!phoneNumberTextField.getText().trim().equals("")) {
					builder.setTel(Arrays.asList(new String[] {phoneNumber}));
				}
				builder.setDescription(description);
				
				Employer employer = null;
				try {
					employer = builder.build();
				} catch (EntityException e1) {
					System.out.println(e1.getMessage());
				}
				
				if(EmployerDAO.getInstance().create(employer)) { 
					JOptionPane.showMessageDialog(this, "Registration Successful");
					notifyAllObservers();
				} else {
					JOptionPane.showMessageDialog(this, "Not saved", "DataBase error", JOptionPane.ERROR_MESSAGE);
				}
				
			}
			
		} 
	}
```