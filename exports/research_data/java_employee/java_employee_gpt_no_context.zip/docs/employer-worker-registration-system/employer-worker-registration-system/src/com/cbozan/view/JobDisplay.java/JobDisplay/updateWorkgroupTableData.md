`updateWorkgroupTableData`: The function of `updateWorkgroupTableData` is to update the data displayed in a JTable with information about workgroups associated with a selected job.

**Code Description**: 
- The function first checks if `selectedJob` is not null.
- It retrieves a list of `Workgroup` objects associated with the `selectedJob` using `WorkgroupDAO`.
- It initializes a 2D array `tableData` to hold the data for the JTable, with dimensions based on the size of the `workgroupList` and the number of columns (`jobWorkTableColumns`).
- It iterates over the `workgroupList`, populating `tableData` with the workgroup details such as ID, job, work type, work count, description, and date (formatted as "dd.MM.yyyy").
- It calculates the total work count by summing up the work counts of all workgroups.
- It updates the JTable model with the new `tableData` and sets the preferred width for the first column.
- It sets the auto-resize mode of the JTable to resize the last column.
- It creates a `DefaultTableCellRenderer` to center-align the text in the first, fourth, and sixth columns.
- It updates the labels `jobWorkTotalCountLabel` and `jobWorkCountLabel` with the total work count and the number of records, respectively.\\
## Code: 
```
void updateWorkgroupTableData() {
		
		if(selectedJob != null) {
			
			List<Workgroup> workgroupList = WorkgroupDAO.getInstance().list(selectedJob);
			
			String[][] tableData = new String[workgroupList.size()][jobWorkTableColumns.length];
			
			int i = 0;
			int totalCount = 0;
			for(Workgroup w : workgroupList) {
				
				tableData[i][0] = w.getId() + "";
				tableData[i][1] = w.getJob().toString();
				tableData[i][2] = w.getWorktype().toString();
				tableData[i][3] = w.getWorkCount() + "";
				tableData[i][4] = w.getDescription();
				tableData[i][5] = new SimpleDateFormat("dd.MM.yyyy").format(w.getDate());
				
				totalCount += w.getWorkCount();
				++i;	
			}
			
			((JTable)jobWorkScrollPane.getViewport().getComponent(0)).setModel(new DefaultTableModel(tableData, jobWorkTableColumns));
			((JTable)jobWorkScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setPreferredWidth(5);
			((JTable)jobWorkScrollPane.getViewport().getComponent(0)).setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
			
			DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
			centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
			((JTable)jobWorkScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
			((JTable)jobWorkScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
			((JTable)jobWorkScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(5).setCellRenderer(centerRenderer);
			
			//jobWorkCount 
			jobWorkTotalCountLabel.setText(totalCount + " daily wages");
			jobWorkCountLabel.setText(workgroupList.size() + " Record");
		}
		
	}
```