`createControl`: The function of `createControl` is to check if an employer with the same first name and last name already exists in the cache.

**Code Description**: 
- The method `createControl` takes an `Employer` object as a parameter.
- It iterates through the entries in the `cache`, which is assumed to be a `Map<Integer, Employer>`.
- For each entry in the cache, it compares the first name (`fname`) and last name (`lname`) of the `Employer` object in the cache with those of the provided `employer` object.
- If a match is found (i.e., an employer with the same first name and last name already exists in the cache), it sets an error message in `DB.ERROR_MESSAGE` indicating that the record already exists and returns `false`.
- If no match is found after checking all entries, the method returns `true`, indicating that the employer does not already exist in the cache.\\
## Code: 
```
boolean createControl(Employer employer) {
		
		for(Entry<Integer, Employer> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(employer.getFname())
					&& obj.getValue().getLname().equals(employer.getLname())) {
				
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		
		return true;
	}
```