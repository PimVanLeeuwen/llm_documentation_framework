`mouseAction`: The function of `mouseAction` is to handle mouse events for selecting a job from a search result.

**Code Description**: This method processes a mouse event by casting the `searchResultObject` to a `Job` object and setting it as the `selectedJob`. It updates the `searchJobSearchBox` with the string representation of the `searchResultObject` and makes it non-editable. It then updates the `jobTitleTextField` and `employerTextField` with the job title and employer information from the `selectedJob`. The `clearPanel` method is called to presumably clear or reset some UI components. Finally, it calls the superclass's `mouseAction` method with the same parameters.\\
## Code: 
```
void mouseAction(MouseEvent e, Object searchResultObject, int chooseIndex) {
				selectedJob = (Job) searchResultObject;
				searchJobSearchBox.setText(searchResultObject.toString());
				searchJobSearchBox.setEditable(false);
				jobTitleTextField.setText(selectedJob.toString());
				employerTextField.setText(selectedJob.getEmployer().toString());
				clearPanel();
				super.mouseAction(e, searchResultObject, chooseIndex);
			}
```