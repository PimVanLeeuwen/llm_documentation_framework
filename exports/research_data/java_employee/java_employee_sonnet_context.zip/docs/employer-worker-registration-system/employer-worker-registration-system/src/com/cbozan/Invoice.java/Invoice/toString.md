`toString`: The function of `toString` is to provide a string representation of the Invoice object.

**Code Description**: This method overrides the default `toString()` method from the Object class. It returns a string that contains the values of the Invoice object's attributes: id, job, amount, and date. The returned string is formatted in a readable manner, with each attribute name followed by its corresponding value, enclosed in square brackets. This representation is useful for debugging, logging, or displaying the Invoice object's state in a human-readable format.\\
## Code: 
```
String toString() {
		return "Invoice [id=" + id + ", job=" + job + ", amount=" + amount + ", date=" + date + "]";
	}
```