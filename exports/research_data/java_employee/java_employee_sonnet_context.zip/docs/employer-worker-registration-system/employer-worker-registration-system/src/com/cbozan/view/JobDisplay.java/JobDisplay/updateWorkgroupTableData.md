`updateWorkgroupTableData`: The function of `updateWorkgroupTableData` is to update the workgroup table data for a selected job.

**Code Description**: This method populates a JTable with workgroup data related to a selected job. It retrieves a list of workgroups associated with the selected job from the WorkgroupDAO. For each workgroup, it creates a row in the table with details such as ID, job, worktype, work count, description, and date. The method also calculates the total work count across all workgroups.

The table model is updated with the new data, and column widths and alignments are adjusted for better presentation. Specifically, the ID, work count, and date columns are center-aligned. The last column is set to auto-resize.

Finally, the method updates two labels: one showing the total number of daily wages (sum of all work counts) and another displaying the total number of workgroup records. This provides a summary of the workgroup data for the selected job.\\
## Code: 
```
void updateWorkgroupTableData() {
		
		if(selectedJob != null) {
			
			List<Workgroup> workgroupList = WorkgroupDAO.getInstance().list(selectedJob);
			
			String[][] tableData = new String[workgroupList.size()][jobWorkTableColumns.length];
			
			int i = 0;
			int totalCount = 0;
			for(Workgroup w : workgroupList) {
				
				tableData[i][0] = w.getId() + "";
				tableData[i][1] = w.getJob().toString();
				tableData[i][2] = w.getWorktype().toString();
				tableData[i][3] = w.getWorkCount() + "";
				tableData[i][4] = w.getDescription();
				tableData[i][5] = new SimpleDateFormat("dd.MM.yyyy").format(w.getDate());
				
				totalCount += w.getWorkCount();
				++i;	
			}
			
			((JTable)jobWorkScrollPane.getViewport().getComponent(0)).setModel(new DefaultTableModel(tableData, jobWorkTableColumns));
			((JTable)jobWorkScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setPreferredWidth(5);
			((JTable)jobWorkScrollPane.getViewport().getComponent(0)).setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
			
			DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
			centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
			((JTable)jobWorkScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
			((JTable)jobWorkScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
			((JTable)jobWorkScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(5).setCellRenderer(centerRenderer);
			
			//jobWorkCount 
			jobWorkTotalCountLabel.setText(totalCount + " daily wages");
			jobWorkCountLabel.setText(workgroupList.size() + " Record");
		}
		
	}
```