`list`: The function of `list` is to retrieve all Paytype objects from the database or cache and return them as a List.

**Code Description**: This method first checks if there are cached Paytype objects and if cache usage is enabled. If so, it returns the cached objects. Otherwise, it clears the cache and queries the database for all Paytype records. It uses a SQL SELECT statement to fetch all rows from the paytype table. For each row, it creates a PaytypeBuilder object, sets its properties using the retrieved data, and builds a Paytype object. These objects are added to both the return list and the cache. If any EntityException occurs during object creation, it's displayed using the showEntityException method. SQL exceptions are handled by the showSQLException method. The method uses the DB.getConnection() to obtain a database connection. Finally, it returns the list of Paytype objects.\\
## Code: 
```
List<Paytype> list(){
		
		List<Paytype> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Paytype> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM paytype;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			PaytypeBuilder builder;
			Paytype paytype;
			
			while(rs.next()) {
				
				builder = new PaytypeBuilder();
				builder.setId(rs.getInt("id"));
				builder.setTitle(rs.getString("title"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					paytype = builder.build();
					list.add(paytype);
					cache.put(paytype.getId(), paytype);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id") + " Title : " + rs.getString("title"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
	}
```