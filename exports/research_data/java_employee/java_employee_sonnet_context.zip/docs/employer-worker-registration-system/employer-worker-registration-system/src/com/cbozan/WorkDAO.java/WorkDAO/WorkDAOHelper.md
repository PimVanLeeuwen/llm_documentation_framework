`WorkDAOHelper`: The function of `WorkDAOHelper` is to provide a single instance of the WorkDAO class.

**Code Description**: This class implements the Singleton pattern for the WorkDAO class. It contains a single private static final field named 'instance' of type WorkDAO, which is initialized with a new WorkDAO object. This ensures that only one instance of WorkDAO is created and used throughout the application, providing a global point of access to that instance.\\
## Code: 
```
class WorkDAOHelper {
		private static final WorkDAO instance = new WorkDAO();
	}
```