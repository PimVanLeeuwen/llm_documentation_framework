`decimalControl`: The function of `decimalControl` is to validate if all input strings represent valid decimal numbers with up to two decimal places.

**Code Description**: This method takes a variable number of string arguments and checks if each of them matches a specific decimal number pattern. It uses a regular expression pattern "^\\d+(\\.\\d{1,2})?$" which allows for whole numbers or numbers with up to two decimal places. The method iterates through all input strings, removes any whitespace, and checks if each string matches the pattern. It returns true only if all input strings match the pattern, otherwise it returns false. This method is useful for validating user input in forms or other scenarios where decimal numbers need to be validated.\\
## Code: 
```
boolean decimalControl(String ...args) {
		Pattern pattern = Pattern.compile("^\\d+(\\.\\d{1,2})?$"); // decimal pattern xxx.xx
		boolean result = true;
		
		for(String arg : args)
			result = result && pattern.matcher(arg.replaceAll("\\s+", "")).find();
		
		return result;
	}
```