`create`: The function of `create` is to insert a new workgroup record into the database and update the local cache.

**Parameters**:
`Workgroup workgroup`: An object representing the workgroup to be created in the database.

**Code Description**: This method inserts a new workgroup record into the database using the provided Workgroup object. It first establishes a database connection and prepares an SQL INSERT statement with the workgroup's details. After executing the insert, if successful, it retrieves the newly created record using a SELECT query. The retrieved data is then used to create a new Workgroup object, which is added to the local cache. The method handles potential SQL and entity exceptions, displaying them using dedicated methods. It returns a boolean indicating whether the insertion was successful.\\
## Code: 
```
boolean create(Workgroup workgroup) {
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO workgroup (job_id,worktype_id,workcount,description) VALUES (?,?,?,?);";
		String query2 = "SELECT * FROM workgroup ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, workgroup.getJob().getId());
			pst.setInt(2, workgroup.getWorktype().getId());
			pst.setInt(3, workgroup.getWorkCount());
			pst.setString(4, workgroup.getDescription());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					WorkgroupBuilder builder = new WorkgroupBuilder();
					builder.setId(rs.getInt("id"));
					builder.setJob_id(rs.getInt("job_id"));
					builder.setWorktype_id(rs.getInt("worktype_id"));
					builder.setWorkCount(rs.getInt("workcount"));
					builder.setDescription(rs.getString("description"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Workgroup wg = builder.build();
						cache.put(wg.getId(), wg);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id"));
					}
					
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```