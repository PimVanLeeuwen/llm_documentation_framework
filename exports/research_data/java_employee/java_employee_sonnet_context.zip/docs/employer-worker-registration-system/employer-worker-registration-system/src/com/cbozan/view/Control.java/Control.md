`Control`: The function of `Control` is to provide utility methods for validating various types of input data.

**Code Description**: The Control class contains static methods for validating phone numbers, IBAN (International Bank Account Numbers), and decimal numbers. It uses regular expressions to perform pattern matching on the input strings. The class offers multiple overloaded versions of each validation method, allowing for custom regex patterns or Pattern objects to be used. The phone number validation is tailored for Turkish phone numbers, while the IBAN validation is specific to Turkish IBAN format. The decimal validation checks for numbers with up to two decimal places. All methods are designed to handle empty strings as valid input. The class provides a centralized way to perform common input validations, which can be useful in form processing or data validation scenarios within the employer-worker registration system.\\
## Code: 
```
class Control {

	public static boolean phoneNumberControl(String phoneNumber) {
		return Pattern.compile("^((((\\+90)?|(0)?)\\d{10})|())$").matcher(phoneNumber.replaceAll("\\s+", "")).find();
	}
	public static boolean phoneNumberControl(String phoneNumber, String regex) {
		return Pattern.compile(regex).matcher(phoneNumber.replaceAll("\\s+", "")).find();
	}
	public static boolean phoneNumberControl(String phoneNumber, Pattern pattern) {
		return pattern.matcher(phoneNumber).find();
	}
	
	
	public static boolean ibanControl(String iban) {
		return Pattern.compile("^((TR\\d{24})|())$", Pattern.CASE_INSENSITIVE).matcher(iban).find();
	}
	public static boolean ibanControl(String iban, String regex) {
		return Pattern.compile(regex).matcher(iban).find();
	}
	public static boolean ibanControl(String iban, Pattern pattern) {
		return pattern.matcher(iban).find();
	}
	
	
	public static boolean decimalControl(String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= Pattern.compile("^((\\d+(\\.\\d{1,2})?)|())$").matcher(arg).find();
		}
		return rValue;
	}
	public static boolean decimalControl(Pattern pattern, String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= pattern.matcher(arg).find();
		}
		return rValue;
	}
	
}
```