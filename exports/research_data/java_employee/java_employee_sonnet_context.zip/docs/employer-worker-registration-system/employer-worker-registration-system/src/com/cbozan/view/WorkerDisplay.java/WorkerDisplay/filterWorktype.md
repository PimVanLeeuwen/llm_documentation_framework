`filterWorktype`: The function of `filterWorktype` is to filter a list of Work objects based on a selected worktype.

**Parameters**:
`List<Work> workList`: A list of Work objects to be filtered.

**Code Description**: This method filters a given list of Work objects based on a previously selected worktype. It first checks if a worktype has been selected; if not, it returns without modifying the list. If a worktype is selected, it iterates through the workList using an Iterator. For each Work object, it compares the ID of its worktype with the ID of the selected worktype. If they don't match, the Work object is removed from the list. This process effectively removes all Work objects from the list that don't belong to the selected worktype category.\\
## Code: 
```
void filterWorktype(List<Work> workList) {
		if(selectedWorktype == null) {
			return;
		}
		
		Iterator<Work> work = workList.iterator();
		Work workItem;
		while(work.hasNext()) {
			workItem = work.next();
			if(workItem.getWorktype().getId() != selectedWorktype.getId()) {
				work.remove();
			}
		}
	}
```