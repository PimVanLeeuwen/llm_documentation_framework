`getSelectedEmployer`: The function of `getSelectedEmployer` is to return the currently selected Employer object.

**Code Description**: This method is a simple getter that returns the value of the `selectedEmployer` instance variable. It doesn't perform any calculations or modifications; it simply provides access to the `selectedEmployer` object, which likely represents the currently selected employer in the employer-worker registration system. This method allows other parts of the program to retrieve the selected employer's information when needed, without directly accessing the private `selectedEmployer` variable.\\
## Code: 
```
Employer getSelectedEmployer() {
		return selectedEmployer;
	}
```