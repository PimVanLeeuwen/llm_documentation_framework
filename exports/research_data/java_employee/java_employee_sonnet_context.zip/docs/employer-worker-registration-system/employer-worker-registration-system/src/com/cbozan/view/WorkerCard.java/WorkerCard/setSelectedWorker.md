`setSelectedWorker`: The function of `setSelectedWorker` is to update the worker information displayed in the user interface based on the selected worker.

**Parameters**:
`Worker selectedWorker`: The Worker object containing the information to be displayed. If null, the fields are reset to their initial state.

**Code Description**: This method updates the UI components with the selected worker's information. If the selectedWorker is null, it resets all text fields and text area to an initial text value (INIT_TEXT). Otherwise, it populates the fields with the worker's data: first name, last name, telephone number (if available), IBAN, and description. After updating the fields, it iterates through the components of the WorkerCard, setting text fields and text areas to non-editable and updating the icon of associated buttons. This method ensures that the UI reflects the current selected worker's information and sets the appropriate edit state for the fields.\\
## Code: 
```
void setSelectedWorker(Worker selectedWorker) {
		this.selectedWorker = selectedWorker;
		
		if(selectedWorker == null) {
			fnameTextField.setText(INIT_TEXT);
			lnameTextField.setText(INIT_TEXT);
			ibanTextField.setText(INIT_TEXT);
			telTextField.setText(INIT_TEXT);
			descriptionTextArea.setText(INIT_TEXT);
		} else {
			
			setFnameTextFieldContent(selectedWorker.getFname());
			setLnameTextFieldContent(selectedWorker.getLname());
			if(selectedWorker.getTel() == null || selectedWorker.getTel().size() == 0)
				setTelTextFieldContent("");
			else
				setTelTextFieldContent(selectedWorker.getTel().get(0));
			setIbanTextFieldContent(selectedWorker.getIban());
			setDescriptionTextAreaContent(selectedWorker.getDescription());
			
		}
		
		for(int i = 2; i < this.getComponentCount(); i += 3) {
			if(getComponent(i - 1) instanceof RecordTextField)
				((RecordTextField)this.getComponent(i - 1)).setEditable(false);
			else if(getComponent(i - 1) instanceof TextArea)
				((TextArea)getComponent(i - 1)).setEditable(false);
			
			((JButton)this.getComponent(i)).setIcon(new ImageIcon("src\\icon\\text_edit.png"));
		}
		
		
	}
```