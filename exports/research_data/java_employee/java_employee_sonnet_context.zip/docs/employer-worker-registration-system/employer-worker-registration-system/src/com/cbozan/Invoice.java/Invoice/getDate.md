`getDate`: The function of `getDate` is to retrieve the date value of the Invoice object.

**Code Description**: This is a simple getter method that returns the `date` field of the Invoice class. The method has no parameters and returns a `Timestamp` object, which represents the date and time associated with the invoice. This method provides read-only access to the `date` attribute, allowing other parts of the program to obtain the invoice's date information without directly accessing the private field.\\
## Code: 
```
Timestamp getDate() {
		return date;
	}
```