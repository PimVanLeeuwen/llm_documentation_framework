`getLname`: The function of `getLname` is to return the last name of the employer.

**Code Description**: This is a simple getter method that returns the value of the private field `lname`. It takes no parameters and returns a String representing the last name of the employer. The method provides read-only access to the `lname` field, allowing other parts of the program to retrieve the last name without directly accessing the private field.\\
## Code: 
```
String getLname() {
		return lname;
	}
```