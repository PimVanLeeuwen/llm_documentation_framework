`list`: The function of `list` is to retrieve all worktype records from the database and return them as a List of Worktype objects.

**Code Description**: This method first checks if there's cached data available and if cache usage is enabled. If so, it returns the cached list of Worktype objects. Otherwise, it clears the cache and proceeds to fetch data from the database.

The method establishes a database connection, executes a SQL query to select all records from the worktype table, and iterates through the result set. For each record, it creates a WorktypeBuilder object, sets its properties using data from the result set, and attempts to build a Worktype object. Successfully built Worktype objects are added to the list and cached.

If any EntityException occurs during object creation, it's handled by displaying an error message. SQL exceptions are also caught and displayed. Finally, the method returns the list of Worktype objects, whether from cache or freshly fetched from the database.\\
## Code: 
```
List<Worktype> list(){
		
		List<Worktype> list = new ArrayList<>();
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Worktype> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM worktype;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorktypeBuilder builder;
			Worktype worktype;
			
			while(rs.next()) {
				
				builder = new WorktypeBuilder();
				builder.setId(rs.getInt("id"));
				builder.setTitle(rs.getString("title"));
				builder.setNo(rs.getInt("no"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					worktype = builder.build();
					list.add(worktype);
					cache.put(worktype.getId(), worktype);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id") + ", Title : " + rs.getString("title"));
				}
				
			}
			
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
		
	}
```