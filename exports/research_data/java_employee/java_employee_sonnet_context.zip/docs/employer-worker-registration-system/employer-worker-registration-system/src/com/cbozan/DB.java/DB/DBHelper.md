`DBHelper`: The function of `DBHelper` is to provide a single, static instance of the DB class.

**Code Description**: This class implements the Singleton design pattern for database connection management. It contains a single private static final field named CONNECTION of type DB. This ensures that only one instance of the DB class is created and shared throughout the application, promoting efficient resource usage and consistent database access. The class is marked as package-private (default access modifier), indicating it's intended for use within the same package only.\\
## Code: 
```
class DBHelper{
		private static final DB CONNECTION = new DB();
	}
```