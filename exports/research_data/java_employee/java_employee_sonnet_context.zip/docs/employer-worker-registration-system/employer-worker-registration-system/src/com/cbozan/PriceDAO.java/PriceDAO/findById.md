`findById`: The function of `findById` is to retrieve a Price object by its ID from a cache or database.

**Parameters**:
`int id`: The unique identifier of the Price object to be retrieved.

**Code Description**: This method first checks if caching is enabled by examining the `usingCache` flag. If caching is not in use, it calls the `list()` method to populate the cache. Then, it checks if the cache contains an entry with the given `id`. If found, it returns the corresponding Price object from the cache. If not found, it returns null. This approach prioritizes cache lookup for efficiency, falling back to a potential database query (via the `list()` method) only when necessary.\\
## Code: 
```
Price findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```