`getAmount`: The function of `getAmount` is to retrieve the amount value stored in the Invoice object.

**Code Description**: This is a simple getter method that returns the `amount` field of the Invoice class. The `amount` is of type `BigDecimal`, which is commonly used for precise decimal arithmetic, often in financial calculations. The method doesn't perform any calculations or modifications; it simply returns the current value of the `amount` field.\\
## Code: 
```
BigDecimal getAmount() {
		return amount;
	}
```