`TextArea`: The function of `TextArea` is to create a scrollable text area component with focus-related visual feedback.

**Code Description**: This class extends JScrollPane and implements FocusListener to create a custom text area component. It encapsulates a JTextArea within a scrollable pane and adds focus listeners to both the text area and the scroll pane. The class provides methods to get and set the text content, check and set the editable state of the text area. When the component gains focus, it sets a blue border around the text area, and when it loses focus, it sets a white border, providing visual feedback to the user. This custom component can be useful in applications where a scrollable, editable text area with focus indication is needed.\\
## Code: 
```
class TextArea extends JScrollPane implements FocusListener{

	private static final long serialVersionUID = 8546529312909157181L;
	JTextArea text;
	
	public TextArea() {
		text = new JTextArea();
		setViewportView(text);
		text.addFocusListener(this);
		this.addFocusListener(this);
	}
	
	public String getText(){
		return text.getText();
	}
	
	public void setText(String strText) {
		text.setText(strText);
	}
	
	public boolean isEditable() {
		return text.isEditable();
	}
	
	public void setEditable(boolean bool) {
		text.setEditable(bool);
	}
	
	@Override
	public void focusGained(FocusEvent e) {
		text.setBorder(new LineBorder(Color.BLUE));
		
	}

	@Override
	public void focusLost(FocusEvent e) {
		text.setBorder(new LineBorder(Color.WHITE));
	}
	
	

}
```