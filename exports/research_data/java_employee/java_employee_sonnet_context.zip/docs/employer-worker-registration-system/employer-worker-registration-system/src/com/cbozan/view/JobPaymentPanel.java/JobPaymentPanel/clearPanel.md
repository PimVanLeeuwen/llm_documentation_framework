`clearPanel`: The function of `clearPanel` is to reset and update the job payment panel's user interface elements.

**Code Description**: This method clears and updates various components of the job payment panel. It resets the amount text field by clearing its text and resetting its border color. The amount label's color is set to the default color. If a job is selected, it retrieves the list of invoices for that job from the InvoiceDAO. It then populates a table with invoice data, including ID, formatted amount, and formatted date. The table's model is updated with this data, and column widths are adjusted. Finally, it sets the cell renderer for all columns to center-align the content. This method essentially refreshes the panel's display with the latest invoice information for the selected job.\\
## Code: 
```
void clearPanel() {
		
		amountTextField.setText("");
		amountTextField.setBorder(new LineBorder(Color.white));
		amountLabel.setForeground(defaultColor);
		
		
		if(selectedJob != null) {
			
			List<Invoice> invoiceList = InvoiceDAO.getInstance().list("job_id", selectedJob.getId());
			String[][] tableData = new String[invoiceList.size()][invoiceTableColumns.length];
			int i = 0;
			for(Invoice invoice : invoiceList) {
				tableData[i][0] = invoice.getId() + "";
				tableData[i][1] = NumberFormat.getInstance().format(invoice.getAmount()) + " ₺";
				tableData[i][2] = new SimpleDateFormat("dd.MM.yyyy").format(invoice.getDate()); 
				++i;
			}
			
			((JTable)lastPaymentsScroll.getViewport().getComponent(0)).setModel(new DefaultTableModel(tableData, invoiceTableColumns));
			((JTable)lastPaymentsScroll.getViewport().getComponent(0)).getColumnModel().getColumn(0).setPreferredWidth(5);
			((JTable)lastPaymentsScroll.getViewport().getComponent(0)).setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
			
			DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
			centerRenderer.setHorizontalAlignment( SwingConstants.CENTER );
			((JTable)lastPaymentsScroll.getViewport().getComponent(0)).getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
			((JTable)lastPaymentsScroll.getViewport().getComponent(0)).getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
			((JTable)lastPaymentsScroll.getViewport().getComponent(0)).getColumnModel().getColumn(2).setCellRenderer(centerRenderer);
		}
		
		
	}
```