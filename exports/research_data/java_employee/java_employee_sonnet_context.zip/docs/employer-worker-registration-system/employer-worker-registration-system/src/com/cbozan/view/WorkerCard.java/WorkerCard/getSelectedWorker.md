`getSelectedWorker`: The function of `getSelectedWorker` is to return the currently selected Worker object.

**Code Description**: This method is a simple getter that returns the value of the `selectedWorker` instance variable. It doesn't perform any calculations or modifications; it simply provides access to the `selectedWorker` object, which is likely set elsewhere in the class. This method allows other parts of the program to retrieve the currently selected Worker, enabling operations or display of information related to that specific worker.\\
## Code: 
```
Worker getSelectedWorker() {
		return selectedWorker;
	}
```