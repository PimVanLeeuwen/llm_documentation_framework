`toString`: The function of `toString` is to provide a string representation of the Price object.

**Code Description**: This method overrides the default `toString()` method to create a custom string representation of the Price object. It concatenates the values of fulltime, halftime, and overtime prices, each enclosed in parentheses and separated by two spaces. The method calls `getFulltime()`, `getHalftime()`, and `getOvertime()` to retrieve the respective values. The resulting string format is "(fulltime)  (halftime)  (overtime)", where each value is the result of its corresponding getter method. This representation allows for a quick and formatted view of the three price components associated with the Price object.\\
## Code: 
```
String toString() {
		return "(" + getFulltime() + ")  " + "(" + getHalftime() + ")  " + "(" + getOvertime() + ")";
	}
```