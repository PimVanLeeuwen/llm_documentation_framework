`InvoiceBuilder`: The function of `InvoiceBuilder` is to facilitate the creation of Invoice objects using the Builder pattern.

**Code Description**: This class implements the Builder pattern for constructing Invoice objects. It contains private fields for id, job_id, job, amount, and date, which correspond to the properties of an Invoice. The class provides multiple constructors for flexibility in object creation. It offers setter methods for each field that return the builder instance, enabling method chaining. The build() method constructs and returns an Invoice object based on the set properties. If a Job object is set, it creates an Invoice with that Job; otherwise, it uses the builder's current state to create the Invoice. This pattern allows for more readable and flexible object creation, especially when dealing with objects that have many optional parameters.\\
## Code: 
```
class InvoiceBuilder{
		
		private int id;
		private int job_id;
		private Job job;
		private BigDecimal amount;
		private Timestamp date;
		
		public InvoiceBuilder() {}
		public InvoiceBuilder(int id, int job_id, BigDecimal amount, Timestamp date) {
			this.id = id;
			this.job_id = job_id;
			this.amount = amount;
			this.date = date;
		}
		
		public InvoiceBuilder(int id, Job job, BigDecimal amount, Timestamp date) {
			this(id, 0, amount, date);
			this.job = job;
		}
		
		public InvoiceBuilder setId(int id) {
			this.id = id;
			return this;
		}
		
		public InvoiceBuilder setJob_id(int job_id) {
			this.job_id = job_id;
			return this;
		}
		
		public InvoiceBuilder setJob(Job job) {
			this.job = job;
			return this;
		}
		
		public InvoiceBuilder setAmount(BigDecimal amount) {
			this.amount = amount;
			return this;
		}
		
		public InvoiceBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Invoice build() throws EntityException {
			if(job == null)
				return new Invoice(this);
			return new Invoice(id, job, amount, date);
		}
		
	}
```