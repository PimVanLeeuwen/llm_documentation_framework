`setId`: The function of `setId` is to set the ID of a Work object.

**Parameters**:
`int id`: The integer value to be set as the Work object's ID.

**Code Description**: This method sets the ID of a Work object after validating the input. It first checks if the provided ID is less than or equal to zero. If so, it throws an EntityException with the message "Work ID negative or zero". This ensures that only positive integers are accepted as valid IDs. If the ID passes the validation, it is assigned to the object's `id` field. The method is declared with a void return type, indicating it doesn't return a value but modifies the object's state.\\
## Code: 
```
void setId(int id) throws EntityException{
		if(id <= 0)
			throw new EntityException("Work ID negative or zero");
		this.id = id;
	}
```