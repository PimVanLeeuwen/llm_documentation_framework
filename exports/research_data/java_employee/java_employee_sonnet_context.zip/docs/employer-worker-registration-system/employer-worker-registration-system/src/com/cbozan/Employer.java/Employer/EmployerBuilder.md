`EmployerBuilder`: The function of `EmployerBuilder` is to facilitate the creation of Employer objects using the Builder pattern.

**Code Description**: This class implements the Builder pattern for constructing Employer objects. It contains private fields corresponding to the attributes of an Employer: id, fname (first name), lname (last name), tel (telephone numbers), description, and date. The class provides two constructors: a default no-argument constructor and a parameterized constructor that initializes all fields. It offers setter methods for each field, which return the EmployerBuilder instance itself, allowing for method chaining. The build() method creates and returns a new Employer object based on the current state of the builder. This pattern provides a flexible and readable way to create Employer objects with varying combinations of attributes, especially useful when dealing with objects that have many optional parameters.\\
## Code: 
```
class EmployerBuilder{
		
		private int id;
		private String fname;
		private String lname;
		private List<String> tel;
		private String description;
		private Timestamp date;

		public EmployerBuilder() {}
		public EmployerBuilder(int id, String fname, String lname, List<String> tel, String description, Timestamp date) {
			super();
			this.id = id;
			this.fname = fname;
			this.lname = lname;
			this.tel = tel;
			this.description = description;
			this.date = date;
		}

		public EmployerBuilder setId(int id) {
			this.id = id;
			return this;
		}

		public EmployerBuilder setFname(String fname) {
			this.fname = fname;
			return this;
		}

		public EmployerBuilder setLname(String lname) {
			this.lname = lname;
			return this;
		}

		public EmployerBuilder setTel(List<String> tel) {
			this.tel = tel;
			return this;
		}

		public EmployerBuilder setDescription(String description) {
			this.description = description;
			return this;
		}

		public EmployerBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Employer build() throws EntityException {
			return new Employer(this);
		}		
		
	}
```