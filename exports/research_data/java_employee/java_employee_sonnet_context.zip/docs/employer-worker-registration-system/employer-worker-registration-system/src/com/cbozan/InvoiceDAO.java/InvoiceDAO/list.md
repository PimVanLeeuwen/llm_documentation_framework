`list`: The function of `list` is to retrieve a list of Invoice objects from the database based on a specified column name and ID.

**Parameters**:
`String columnName`: The name of the column to filter the query by.
`int id`: The specific ID value to match in the specified column.

**Code Description**: This method queries the database for Invoice records matching the given column name and ID. It establishes a database connection, executes a SELECT query, and processes the result set. For each row returned, it creates an InvoiceBuilder object, sets its properties using data from the result set, and attempts to build an Invoice object. Successfully built Invoice objects are added to a list. The method handles potential SQLException and EntityException, logging errors when they occur. Finally, it returns the list of retrieved Invoice objects.\\
## Code: 
```
List<Invoice> list(String columnName, int id){
		
		List<Invoice> list = new ArrayList<>();
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM invoice WHERE " + columnName + "=" + id;
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			InvoiceBuilder builder;
			Invoice invoice;
			
			while(rs.next()) {
				
				builder = new InvoiceBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setAmount(rs.getBigDecimal("amount"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					invoice = builder.build();
					list.add(invoice);
				} catch (EntityException e) {
					System.err.println(e.getMessage());
					System.out.println("!! Invoice not added list !!");
				}
				
			}
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return list;
	}
```