`list`: The function of `list` is to retrieve all Work records from the database or cache and return them as a List<Work>.

**Code Description**: This method first checks if there are cached Work objects and if cache usage is enabled. If so, it returns the cached objects. Otherwise, it clears the cache and queries the database for all Work records. It uses a SQL SELECT statement to fetch all columns from the work table. For each row in the result set, it creates a WorkBuilder object, sets its properties using the retrieved data, and then builds a Work object. Each Work object is added to the list and also cached using its ID as the key. If any EntityException occurs during object creation, it's displayed using the showEntityException method. Any SQLException is handled by the showSQLException method. Finally, the method returns the list of Work objects. This approach allows for efficient retrieval of Work data, utilizing caching when possible to reduce database queries.\\
## Code: 
```
List<Work> list(){
		
		List<Work> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Work> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM work;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorkBuilder builder;
			Work work;
			
			while(rs.next()) {
				
				builder = new WorkBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setWorker_id(rs.getInt("worker_id"));
				builder.setWorktype_id(rs.getInt("worktype_id"));
				builder.setWorkgroup_id(rs.getInt("workgroup_id"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					work = builder.build();
					list.add(work);
					cache.put(work.getId(), work);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
	}
```