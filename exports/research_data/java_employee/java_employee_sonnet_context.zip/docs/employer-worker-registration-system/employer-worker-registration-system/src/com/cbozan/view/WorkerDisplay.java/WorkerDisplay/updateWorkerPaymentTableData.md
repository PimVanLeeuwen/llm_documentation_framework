`updateWorkerPaymentTableData`: The function of `updateWorkerPaymentTableData` is to update the payment table data for a selected worker.

**Code Description**: This method retrieves payment data for a selected worker, filters it, and updates a JTable with the information. It first checks if a worker is selected. If so, it fetches a list of payments either based on selected dates or for all dates. The payment list is then filtered using the `filterPaymentJob` method. The method creates a 2D array to hold the table data, populating it with payment details including ID, job, worker, payment type, amount, and date. It calculates the total payment amount as it processes each payment. The JTable model is updated with this new data, and column widths and alignments are adjusted for better presentation. Finally, it updates labels showing the total payment amount and the number of records displayed.\\
## Code: 
```
void updateWorkerPaymentTableData() {
		
		if(selectedWorker != null) {
			
			List<Payment> paymentList;
			
			if(selectedWorkerPaymentDateStrings != null) {
				paymentList = PaymentDAO.getInstance().list(selectedWorker, selectedWorkerPaymentDateStrings);
			} else {
				paymentList = PaymentDAO.getInstance().list(selectedWorker);
			}
			
			filterPaymentJob(paymentList);
			
			String[][] tableData = new String[paymentList.size()][workerPaymentTableColumns.length];
			BigDecimal totalAmount = new BigDecimal("0.00");
			int i = 0;
			for(Payment p : paymentList) {
				tableData[i][0] = p.getId() + "";
				tableData[i][1] = p.getJob().toString();
				tableData[i][2] = p.getWorker().toString();
				tableData[i][3] = p.getPaytype().toString();
				tableData[i][4] = p.getAmount() + " ₺";
				tableData[i][5] = new SimpleDateFormat("dd.MM.yyyy").format(p.getDate());
				totalAmount = totalAmount.add(p.getAmount());
				++i;
			}
			
			((JTable)workerPaymentScrollPane.getViewport().getComponent(0)).setModel(new DefaultTableModel(tableData, workerPaymentTableColumns));
			((JTable)workerPaymentScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setPreferredWidth(5);
			((JTable)workerPaymentScrollPane.getViewport().getComponent(0)).setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
			
			DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
			centerRenderer.setHorizontalAlignment( SwingConstants.CENTER );
			((JTable)workerPaymentScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
			((JTable)workerPaymentScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
			((JTable)workerPaymentScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(4).setCellRenderer(centerRenderer);
			((JTable)workerPaymentScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(5).setCellRenderer(centerRenderer);
			
			workerPaymentTotalLabel.setText("Total " + totalAmount + " ₺");
			workerPaymentCountLabel.setText(paymentList.size() + " Record");
			
		}
		
	}
```