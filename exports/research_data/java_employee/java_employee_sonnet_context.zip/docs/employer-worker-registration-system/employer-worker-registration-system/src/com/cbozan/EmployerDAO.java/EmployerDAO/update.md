`update`: The function of `update` is to modify an existing employer's information in the database.

**Parameters**:
`Employer employer`: An object containing the updated employer information to be stored in the database.

**Code Description**: This method updates an employer's record in the database. It first checks if the update is valid using the `updateControl` method. If valid, it prepares an SQL UPDATE statement with the new employer details. The method establishes a database connection, sets the prepared statement parameters with the employer's updated information (first name, last name, telephone numbers as an array, description, and ID), and executes the update. If successful, it also updates the cache with the new employer information. The method returns true if the update was successful, and false otherwise. Any SQL exceptions are caught and displayed using the `showSQLException` method.\\
## Code: 
```
boolean update(Employer employer) {
		
		if(updateControl(employer) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE employer SET fname=?,"
				+ "lname=?, tel=?, description=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1, employer.getFname());
			pst.setString(2, employer.getLname());
			
			Array phones = conn.createArrayOf("VARCHAR", employer.getTel().toArray());
			pst.setArray(3, phones);
			
			pst.setString(4, employer.getDescription());
			pst.setInt(5, employer.getId());
			
			result = pst.executeUpdate();
			
			// update cache
			if(result != 0) {
				cache.put(employer.getId(), employer);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```