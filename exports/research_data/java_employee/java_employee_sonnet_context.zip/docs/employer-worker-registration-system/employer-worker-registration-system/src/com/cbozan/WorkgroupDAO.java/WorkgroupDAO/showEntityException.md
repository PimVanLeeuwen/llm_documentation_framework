`showEntityException`: The function of `showEntityException` is to display an error message dialog when an entity fails to be added.

**Parameters**:
`EntityException e`: The exception object containing details about the entity-related error.
`String msg`: A custom message describing the entity that failed to be added.

**Code Description**: This method constructs an error message by combining the provided custom message with details from the EntityException. It appends "not added" to the custom message, followed by the exception's message, localized message, and cause. The resulting error message is then displayed to the user through a JOptionPane message dialog. This method is likely used to provide user-friendly feedback when an attempt to add an entity to the system fails due to an exception.\\
## Code: 
```
void showEntityException(EntityException e, String msg) {
		String message = msg + " not added" + 
				"\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + e.getCause();
			JOptionPane.showMessageDialog(null, message);
	}
```