`getFulltime`: The function of `getFulltime` is to retrieve the value of the `fulltime` field.

**Code Description**: This is a simple getter method that returns the `fulltime` instance variable of the `Price` class. The method has no parameters and returns a `BigDecimal` value. It provides read-only access to the `fulltime` field, allowing other parts of the program to obtain the current value of `fulltime` without directly accessing the private field. This method follows the standard Java convention for getter methods, using the 'get' prefix followed by the capitalized field name.\\
## Code: 
```
BigDecimal getFulltime() {
		return fulltime;
	}
```