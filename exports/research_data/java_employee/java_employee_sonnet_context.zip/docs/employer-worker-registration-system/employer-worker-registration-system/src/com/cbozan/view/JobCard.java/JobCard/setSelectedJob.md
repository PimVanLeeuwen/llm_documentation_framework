`setSelectedJob`: The function of `setSelectedJob` is to update the JobCard UI components based on the selected job.

**Parameters**:
`Job selectedJob`: The Job object to be displayed in the JobCard. If null, the UI is reset to initial values.

**Code Description**: This method updates the JobCard's UI components with the details of the selected job. If the selectedJob parameter is null, it resets all text fields and areas to an initial text value (INIT_TEXT). Otherwise, it populates the title and description fields with the corresponding data from the selected job. The method then iterates through all components of the JobCard, disabling editing for RecordTextField and TextArea components, and updating the icon for JButton components (except for the updateButton). This ensures that the job details are displayed but not editable by default, with an option to enable editing through the update button.\\
## Code: 
```
void setSelectedJob(Job selectedJob) {
		this.selectedJob = selectedJob;
		
		if(selectedJob == null) {
			titleTextField.setText(INIT_TEXT);
			employerSearchBox.setText(INIT_TEXT);
			priceSearchBox.setText(INIT_TEXT);
			descriptionTextArea.setText(INIT_TEXT);
		} else {
			
			setTitleTextFieldContent(selectedJob.getTitle());
			setDescriptionTextAreaContent(selectedJob.getDescription());
			
		}
		
		for(int i = 0; i < this.getComponentCount(); i++) {
			if(getComponent(i) instanceof RecordTextField)
				((RecordTextField)this.getComponent(i)).setEditable(false);
			else if(getComponent(i) instanceof TextArea)
				((TextArea)getComponent(i)).setEditable(false);
			else if(getComponent(i) instanceof JButton && (this.getComponent(i) != updateButton))
				((JButton)this.getComponent(i)).setIcon(new ImageIcon("src\\icon\\text_edit.png"));
		}
	}
```