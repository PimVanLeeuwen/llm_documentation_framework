`setIbanTextFieldContent`: The function of `setIbanTextFieldContent` is to update the IBAN text field and the selected worker's IBAN information.

**Parameters**:
`String ibanTextFieldContent`: The IBAN (International Bank Account Number) content to be set in the text field and for the selected worker.

**Code Description**: This method performs two main actions. First, it sets the text of the `ibanTextField` component to the provided `ibanTextFieldContent` using the `setText` method. Then, it updates the IBAN of the currently selected worker by calling `getSelectedWorker().setIban()`. The IBAN string is trimmed of leading and trailing whitespace and converted to uppercase before being set. This ensures that the displayed IBAN in the UI and the stored IBAN for the worker are synchronized and properly formatted.\\
## Code: 
```
void setIbanTextFieldContent(String ibanTextFieldContent) {
		this.ibanTextField.setText(ibanTextFieldContent);
		getSelectedWorker().setIban(ibanTextFieldContent.trim().toUpperCase());
	}
```