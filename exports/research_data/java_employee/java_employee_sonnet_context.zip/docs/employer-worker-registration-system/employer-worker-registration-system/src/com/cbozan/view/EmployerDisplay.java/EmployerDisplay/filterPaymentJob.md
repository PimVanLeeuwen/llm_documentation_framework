`filterPaymentJob`: The function of `filterPaymentJob` is to filter a list of invoices based on a selected job.

**Parameters**:
`List<Invoice> invoiceList`: A list of Invoice objects to be filtered.

**Code Description**: This method filters the provided `invoiceList` to keep only the invoices associated with a previously selected job. It first checks if a job has been selected (`selectedJob` is not null). If no job is selected, the method returns without modifying the list. If a job is selected, it iterates through the `invoiceList` using an Iterator. For each invoice, it compares the job ID of the invoice with the ID of the selected job. If the IDs don't match, the invoice is removed from the list. This process effectively removes all invoices that are not associated with the selected job, leaving only the relevant invoices in the list.\\
## Code: 
```
void filterPaymentJob(List<Invoice> invoiceList) {
		
		if(selectedJob == null)
			return;
		
		Iterator<Invoice> invoice = invoiceList.iterator();
		Invoice invoiceItem;
		while(invoice.hasNext()) {
			invoiceItem = invoice.next();
			if(invoiceItem.getJob().getId() != selectedJob.getId()) {
				invoice.remove();
			}
		}
		
	}
```