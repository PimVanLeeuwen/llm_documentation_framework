`build`: The function of `build` is to create and return a new Price object using the current state of the PriceBuilder.

**Code Description**: This method is part of the Builder pattern implementation for the Price class. It constructs a new Price object by passing the current PriceBuilder instance (represented by `this`) to the Price constructor. The method throws an EntityException, which suggests that there might be validation or constraint checks during the Price object creation process. This approach allows for a more flexible and readable way of creating Price objects, especially when there are many optional parameters or complex initialization logic involved.\\
## Code: 
```
Price build() throws EntityException{
			return new Price(this);
		}
```