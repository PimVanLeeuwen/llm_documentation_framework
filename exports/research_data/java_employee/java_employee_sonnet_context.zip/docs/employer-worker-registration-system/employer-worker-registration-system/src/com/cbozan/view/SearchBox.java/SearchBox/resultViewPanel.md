`resultViewPanel`: The function of `resultViewPanel` is to update and display search results based on user input.

**Code Description**: This method performs a search operation and displays the results in a panel. It first retrieves the search text from the input field, clears the existing panel and search result list. It then iterates through the object list, adding matching items to the search result list up to a maximum of 10 results. For each search result, it creates a JTextField displaying the result, sets its appearance (color, alignment, editability), and adds mouse listeners for hover and click effects. The mouse click listener triggers a custom action when a result is selected. Finally, it adjusts the panel size based on the number of results and makes the panel visible. The method uses several getter methods to access various components and properties of the SearchBox class.\\
## Code: 
```
void resultViewPanel() {
		
		String searchText = getText().trim().toUpperCase();
		getPanel().removeAll();
		getSearchResultList().clear();
		
		for(Object obj : getObjectList()) {
			if(obj.toString().contains(searchText)) {
				getSearchResultList().add(obj);
				if(getSearchResultList().size() >= 10) {
					break;
				}
				
			}
			
		}
		
		int i = 0;
		for(Object searchResultObj : getSearchResultList()) {
			
			JTextField tf = new JTextField(searchResultObj.toString());
			tf.setForeground(new Color(105, 35, 64));
			tf.setName(i + "");
			tf.setHorizontalAlignment(SwingConstants.CENTER);
			tf.setEditable(false);
			tf.setBackground(new Color(162, 208, 215));
			tf.setBorder(new LineBorder(new Color(202, 228, 232)));
			tf.setBounds(0, i * (getResultBoxSize().height + 1) + i, getResultBoxSize().width, getResultBoxSize().height);
			tf.addMouseListener(new MouseAdapter() {
				public void mouseExited(MouseEvent e) {
					tf.setBackground(getExitedColor());
					isEntered = false;
				}
				
				public void mouseEntered(MouseEvent e) {
					tf.setBackground(getEnteredColor());
					isEntered = true;
				}
				
				public void mouseClicked(MouseEvent e) {
					mouseAction(e, searchResultList.get(Integer.parseInt(tf.getName())), Integer.parseInt(tf.getName()));
					//selectedWorkerDefaultListModel.addElement(searchResultList.get(Integer.parseInt(tf.getName())));
					//workerList.remove(searchResultList.get(Integer.parseInt(tf.getName())));
					getPanel().setVisible(false);
					//selectedInfoCountLabel.setText(selectedWorkerDefaultListModel.size() + " kişi");
				}
			});
			
			getPanel().add(tf);
			
			++i;
		}
		
		getPanel().setSize(getPanel().getWidth(), getSearchResultList().size() * (getResultBoxSize().height + 2));
		getPanel().setVisible(true);
		getPanel().revalidate();
		getPanel().repaint();
		
		
	}
```