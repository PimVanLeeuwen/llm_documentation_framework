`getLastAdded`: The function of `getLastAdded` is to retrieve the most recently added Workgroup record from the database.

**Code Description**: This method queries the database to fetch the last inserted Workgroup record. It establishes a database connection, executes a SQL query to select all columns from the 'workgroup' table, ordered by 'id' in descending order and limited to 1 result. The retrieved data is then used to construct a Workgroup object using the WorkgroupBuilder. If successful, it returns the Workgroup object; otherwise, it returns null. The method handles potential SQLException and EntityException, printing error messages to the console if they occur.\\
## Code: 
```
Workgroup getLastAdded() {
		
		Workgroup workgroup = null;
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM workgroup ORDER BY id DESC LIMIT 1";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			WorkgroupBuilder builder; 
			
			while(rs.next()) {
				
				builder = new WorkgroupBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setWorktype_id(rs.getInt("worktype_id"));
				builder.setWorkCount(rs.getInt("workcount"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					workgroup = builder.build();
				} catch (EntityException e) {
					System.err.println(e.getMessage());
				}
				
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return workgroup;
	}
```