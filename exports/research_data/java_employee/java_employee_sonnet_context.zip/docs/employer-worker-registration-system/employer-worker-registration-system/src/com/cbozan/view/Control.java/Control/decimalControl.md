`decimalControl`: The function of `decimalControl` is to validate if all given strings match a specified decimal pattern.

**Parameters**:
`Pattern pattern`: A regex pattern used to match against the input strings.
`String ...args`: A variable number of string arguments to be checked against the pattern.

**Code Description**: This method takes a Pattern object and a variable number of string arguments. It iterates through each string argument, using the pattern's matcher to check if the string matches the pattern. The method uses a logical AND operation to ensure all strings match the pattern. If any string fails to match, the result becomes false. The method returns true only if all strings match the pattern, otherwise it returns false. This can be useful for validating that multiple string inputs conform to a specific decimal format.\\
## Code: 
```
boolean decimalControl(Pattern pattern, String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= pattern.matcher(arg).find();
		}
		return rValue;
	}
```