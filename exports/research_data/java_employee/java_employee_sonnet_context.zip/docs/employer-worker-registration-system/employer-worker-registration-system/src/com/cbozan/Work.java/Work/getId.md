`getId`: The function of `getId` is to return the id value of the Work object.

**Code Description**: This is a simple getter method that returns the integer value stored in the private field 'id' of the Work class. It provides read-only access to the 'id' attribute, allowing other parts of the program to retrieve the unique identifier of a Work object without directly accessing the private field.\\
## Code: 
```
int getId() {
		return id;
	}
```