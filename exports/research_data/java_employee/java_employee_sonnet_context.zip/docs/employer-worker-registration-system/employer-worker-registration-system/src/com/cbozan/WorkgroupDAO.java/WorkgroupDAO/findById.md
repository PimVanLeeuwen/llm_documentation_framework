`findById`: The function of `findById` is to retrieve a Workgroup object by its ID from a cache or return null if not found.

**Parameters**:
`int id`: The unique identifier of the Workgroup object to be retrieved.

**Code Description**: This method first checks if caching is enabled by examining the `usingCache` flag. If caching is not in use, it calls the `list()` method to populate the cache. Then, it checks if the cache contains an entry with the given `id`. If found, it returns the corresponding Workgroup object from the cache. If not found, it returns null. This approach prioritizes cache lookup for efficiency, falling back to potentially refreshing the cache via the `list()` method if necessary, before concluding that the requested Workgroup does not exist in the system.\\
## Code: 
```
Workgroup findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```