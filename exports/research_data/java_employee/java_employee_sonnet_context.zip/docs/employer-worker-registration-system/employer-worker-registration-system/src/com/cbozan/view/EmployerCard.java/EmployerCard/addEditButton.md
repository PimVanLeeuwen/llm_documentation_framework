`addEditButton`: The function of `addEditButton` is to create and return a JButton that toggles the editability of a text field and changes its icon accordingly.

**Parameters**:
`JTextComponent textField`: The text field associated with the edit button.
`Component nextFocus`: The component to receive focus after editing is complete.

**Code Description**: This method creates a JButton with an edit icon and sets its appearance properties. It positions the button next to the provided text field. The button's functionality is implemented through a MouseListener:

1. When clicked, it toggles the editability of the associated text field.
2. If the text field becomes editable, the button's icon changes to a check mark.
3. If the text field becomes non-editable, the icon reverts to the edit icon.
4. When making the field non-editable, it shifts focus to the nextFocus component if provided, or to the window itself.
5. The button only allows editing if the text field's content is not equal to INIT_TEXT.

The method returns the configured JButton for use in the user interface.\\
## Code: 
```
JButton addEditButton(JTextComponent textField, Component nextFocus) {
		JButton editButton = new JButton(new ImageIcon("src\\icon\\text_edit.png"));
		editButton.setContentAreaFilled(false);
		editButton.setFocusable(false);
		editButton.setBorderPainted(false);
		editButton.setBounds(textField.getX() + textField.getWidth() + BS, textField.getY(), BW, rowHeight);
		
		editButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(textField.isEditable()) {
					editButton.setIcon(new ImageIcon("src\\icon\\text_edit.png"));
					textField.setEditable(false);
					if(nextFocus != null) {
						nextFocus.requestFocus();
					} else {
						requestFocusInWindow();
					}
					
				} else if(!textField.getText().equals(INIT_TEXT)) {
						textField.setEditable(true);
						editButton.setIcon(new ImageIcon("src\\icon\\check.png"));
				}
				super.mouseClicked(e);
			}
		});
		
		
		
		
		return editButton;
	}
```