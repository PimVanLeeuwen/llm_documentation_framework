`createControl`: The function of `createControl` is to validate if a payment can be created.

**Parameters**:
`Payment payment`: An object representing the payment to be validated.

**Code Description**: The method is currently incomplete and always returns true. It contains commented-out code that suggests a future implementation to check if enough payments can be received. The method is likely intended to iterate through existing payments in a cache and perform some validation logic, but this functionality is not yet implemented. In its current state, the method does not perform any actual validation and simply allows all payments to be created.\\
## Code: 
```
boolean createControl(Payment payment) {
//		for(Entry<Integer, Payment> obj : cache.entrySet()) {
//			// yeteri kadar �deme alabilir mi? kontrol etme kodu buraya gelecek
//		}
		return true;
	}
```