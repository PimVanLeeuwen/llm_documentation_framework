`getSelectedJob`: The function of `getSelectedJob` is to return the currently selected Job object.

**Code Description**: This method is a simple getter that returns the value of the `selectedJob` instance variable. It doesn't take any parameters and directly returns the `Job` object that is currently stored in `selectedJob`. This method allows other parts of the program to access the currently selected job without directly accessing the private `selectedJob` variable, maintaining encapsulation.\\
## Code: 
```
Job getSelectedJob() {
		return selectedJob;
	}
```