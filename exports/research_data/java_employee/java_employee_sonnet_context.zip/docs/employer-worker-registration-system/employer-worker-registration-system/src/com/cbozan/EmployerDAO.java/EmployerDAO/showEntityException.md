`showEntityException`: The function of `showEntityException` is to display an error message dialog when an entity fails to be added.

**Parameters**:
`EntityException e`: The exception object containing error details
`String msg`: A custom message to be included in the error dialog

**Code Description**: This method constructs an error message by combining the provided custom message with details from the EntityException. It appends "not added" to the custom message, followed by the exception's message, localized message, and cause. The resulting error message is then displayed to the user through a JOptionPane message dialog. This method is likely used to inform users about failures in adding entities to the system, providing them with detailed error information for troubleshooting or reporting purposes.\\
## Code: 
```
void showEntityException(EntityException e, String msg) {
		String message = msg + " not added" + 
				"\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + e.getCause();
			JOptionPane.showMessageDialog(null, message);
	}
```