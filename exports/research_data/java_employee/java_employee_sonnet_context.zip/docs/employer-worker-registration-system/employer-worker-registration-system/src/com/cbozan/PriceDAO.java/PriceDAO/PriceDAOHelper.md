`PriceDAOHelper`: The function of `PriceDAOHelper` is to provide a single instance of the PriceDAO class.

**Code Description**: This class implements the Singleton design pattern for the PriceDAO class. It contains a single private static final field named 'instance' which is initialized with a new PriceDAO object. This ensures that only one instance of PriceDAO is created and used throughout the application, providing global access to this single instance.\\
## Code: 
```
class PriceDAOHelper {
		private static final PriceDAO instance = new PriceDAO();
	}
```