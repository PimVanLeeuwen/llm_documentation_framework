`update`: The function of `update` is to modify an existing invoice record in the database.

**Parameters**:
`Invoice invoice`: An Invoice object containing the updated information to be stored in the database.

**Code Description**: This method updates an invoice record in the database using the provided Invoice object. It prepares an SQL UPDATE statement with placeholders for job_id and amount, then sets these values using the data from the invoice parameter. The method executes the update query and checks if any rows were affected. If the update is successful, it also updates the cache with the new invoice information. The method returns a boolean value indicating whether the update was successful (true) or not (false). In case of any SQL exceptions, it calls the showSQLException method to display the error details.\\
## Code: 
```
boolean update(Invoice invoice) {
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE invoice SET job_id=?,"
				+ "amount=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, invoice.getJob().getId());
			pst.setBigDecimal(2, invoice.getAmount());
			pst.setInt(5, invoice.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(invoice.getId(), invoice);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```