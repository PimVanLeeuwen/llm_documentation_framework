`DB`: The function of `DB` is to manage database connections using a singleton pattern.

**Code Description**: This class implements a thread-safe singleton pattern for database connection management. It provides static methods for obtaining and destroying database connections. The class uses a private constructor to prevent direct instantiation and a nested static class `DBHelper` to hold the single instance of `DB`. The `getConnection()` method returns a database connection, while `destroyConnection()` closes it. The actual connection is established in the `connect()` method, which creates a new connection to a PostgreSQL database if one doesn't exist or is closed. The `disconnect()` method handles closing the connection. An `ERROR_MESSAGE` static variable is provided for error handling. This design ensures that only one database connection is used throughout the application, promoting efficient resource management.\\
## Code: 
```
class DB {

	public static String ERROR_MESSAGE = "";
	
	private DB() {}
	private Connection conn = null;
	
	private static class DBHelper{
		private static final DB CONNECTION = new DB();
	}
	
	public static Connection getConnection() {
		return DBHelper.CONNECTION.connect();
	}
	
	public static void destroyConnection() {
		DBHelper.CONNECTION.disconnect();
	}

	private Connection connect() {
		
		try {
			if(conn == null || conn.isClosed()) {
				try {
					conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Hesap-eProject", "Hesap-eProject", ".hesap-eProject.");
				} catch (SQLException e) {
					System.err.println(e.getMessage());
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return conn;
	}
	
	private void disconnect() {
		if(conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				System.err.println(e.getMessage());
			}
		}
	}

	
}
```