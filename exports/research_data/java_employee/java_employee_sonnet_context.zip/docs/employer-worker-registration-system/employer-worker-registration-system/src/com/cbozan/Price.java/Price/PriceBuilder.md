`PriceBuilder`: The function of `PriceBuilder` is to facilitate the creation of Price objects using the Builder pattern.

**Code Description**: PriceBuilder is an inner class within the Price class that implements the Builder pattern. It contains private fields corresponding to the attributes of a Price object: id, fulltime, halftime, overtime, and date. The class provides two constructors: a default no-argument constructor and a parameterized constructor that initializes all fields. It offers setter methods for each field, which return the builder instance to allow method chaining. The build() method creates and returns a new Price object based on the current state of the builder, potentially throwing an EntityException if there are issues during construction. This pattern allows for flexible and readable object creation, especially when dealing with multiple optional parameters.\\
## Code: 
```
class PriceBuilder{
		
		private int id;
		private BigDecimal fulltime;
		private BigDecimal halftime;
		private BigDecimal overtime;
		private Timestamp date;
		
		public PriceBuilder() {}

		public PriceBuilder(int id, BigDecimal fulltime, BigDecimal halftime, BigDecimal overtime, Timestamp date) {
			super();
			this.id = id;
			this.fulltime = fulltime;
			this.halftime = halftime;
			this.overtime = overtime;
			this.date = date;
		}

		public PriceBuilder setId(int id) {
			this.id = id;
			return this;
		}

		public PriceBuilder setFulltime(BigDecimal fulltime) {
			this.fulltime = fulltime;
			return this;
		}

		public PriceBuilder setHalftime(BigDecimal halftime) {
			this.halftime = halftime;
			return this;
		}

		public PriceBuilder setOvertime(BigDecimal overtime) {
			this.overtime = overtime;
			return this;
		}

		public PriceBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Price build() throws EntityException{
			return new Price(this);
		}
		
	}
```