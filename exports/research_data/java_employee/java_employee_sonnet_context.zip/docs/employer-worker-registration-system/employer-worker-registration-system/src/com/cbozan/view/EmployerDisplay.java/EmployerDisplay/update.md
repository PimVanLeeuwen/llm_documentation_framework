`update`: The function of `update` is to refresh and synchronize various components of the employer display interface.

**Code Description**: This method performs several key actions to update the employer display:

1. It refreshes the employer search box with the latest list of employers from the database.
2. It updates the selected employer based on the current selection in the employer card.
3. It sets the text in the employer search box to either an empty string or the string representation of the selected employer.
4. It refreshes the Job and Invoice data from their respective DAOs.
5. It calls methods to update the job table data and employer payment table data.
6. Finally, it reloads the employer card to reflect any changes.

This method ensures that all components of the employer display are synchronized with the most current data from the database and user selections. It's likely called when there are changes to the employer data or when the user interface needs to be refreshed.\\
## Code: 
```
void update() {
		employerSearchBox.setObjectList(EmployerDAO.getInstance().list());
		selectedEmployer = employerCard.getSelectedEmployer();
		employerSearchBox.setText(selectedEmployer == null ? "" : selectedEmployer.toString());
		JobDAO.getInstance().refresh();
		InvoiceDAO.getInstance().refresh();
		updateJobTableData();
		updateEmployerPaymentTableData();
		employerCard.reload();
	}
```