`GUI`: The function of `GUI` is to create and set up the graphical user interface for the employer registration panel.

**Code Description**: This method initializes and configures various GUI components for an employer registration form. It creates labels, text fields, and a button for entering employer information. The components include:

1. An image label with an employer icon.
2. Name and surname fields with corresponding labels.
3. A phone number field with a label.
4. A description text area with a scroll pane and label.
5. A save button.

The method sets the position and size of each component using absolute positioning (setBounds). It also adds action listeners to the text fields for basic input validation and focus management. For example, when the user presses enter in the name field, focus moves to the surname field. The phone number field has a specific action listener that checks if the entered number is valid before moving focus to the description area. The save button is added with an action listener, though its specific functionality is not defined in this method. All components are added to the panel (presumably the class extends JPanel or a similar container).\\
## Code: 
```
void GUI() {
		
		imageLabel = new JLabel();
		imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
		imageLabel.setIcon(new ImageIcon("src\\icon\\new_employer.png"));
		imageLabel.setBounds(LX + 155, 40, 128, 130);
		add(imageLabel);

		fnameLabel = new JLabel("Name");
		fnameLabel.setBounds(LX, LY, LW, LH);
		add(fnameLabel);
		
		fnameTextField = new RecordTextField(RecordTextField.REQUIRED_TEXT);
		fnameTextField.setBounds(fnameLabel.getX() + LW + LHS, fnameLabel.getY(), TW, TH);
		fnameTextField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!fnameTextField.getText().replaceAll("\\s+", "").equals("")) {
					lnameTextField.requestFocus();
				}
			}
		});
		add(fnameTextField);
		
		
		lnameLabel = new JLabel("Surname");
		lnameLabel.setBounds(fnameLabel.getX(), fnameLabel.getY() + LVS, LW, LH);
		add(lnameLabel);
		
		lnameTextField = new RecordTextField(RecordTextField.REQUIRED_TEXT);
		lnameTextField.setBounds(lnameLabel.getX() + LW + LHS, lnameLabel.getY(), TW, TH);
		lnameTextField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!lnameTextField.getText().replaceAll("\\s+", "").equals("")) {
					phoneNumberTextField.requestFocus();
				}
			}
		});
		add(lnameTextField);
		
		
		phoneNumberLabel = new JLabel("Phone Nu.");
		phoneNumberLabel.setBounds(lnameLabel.getX(), lnameLabel.getY() + LVS, LW, LH);
		add(phoneNumberLabel);
		
		phoneNumberTextField= new RecordTextField(RecordTextField.PHONE_NUMBER_TEXT + RecordTextField.REQUIRED_TEXT);
		phoneNumberTextField.setBounds(phoneNumberLabel.getX() + LW + LHS, phoneNumberLabel.getY(), TW, TH);
		phoneNumberTextField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Control.phoneNumberControl(phoneNumberTextField.getText())) {
					((JTextArea)((JViewport)descriptionScrollPane.getComponent(0)).getComponent(0)).requestFocus();
				}
			}
		});
		add(phoneNumberTextField);
		
		
		descriptionLabel= new JLabel("Description");
		descriptionLabel.setBounds(phoneNumberLabel.getX(), phoneNumberLabel.getY() + LVS, LW, LH);
		add(descriptionLabel);
		
		descriptionScrollPane = new JScrollPane(new JTextArea());
		descriptionScrollPane.setBounds(descriptionLabel.getX() + LW + LHS, descriptionLabel.getY(), TW, TH * 3);
		add(descriptionScrollPane);
		
		saveButton = new JButton("SAVE");
		saveButton.setBounds(descriptionScrollPane.getX() + ((TW - BW) / 2), descriptionScrollPane.getY() + descriptionScrollPane.getHeight() + 20, BW, BH);
		saveButton.setFocusPainted(false);
		saveButton.addActionListener(this);
		add(saveButton);
		
	}
```