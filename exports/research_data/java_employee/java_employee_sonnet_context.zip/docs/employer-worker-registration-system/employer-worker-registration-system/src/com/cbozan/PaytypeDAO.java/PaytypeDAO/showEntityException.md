`showEntityException`: The function of `showEntityException` is to display an error message dialog when an entity exception occurs.

**Parameters**:
`EntityException e`: The EntityException object that was thrown
`String msg`: A custom message to be displayed in the error dialog

**Code Description**: This method creates an error message by combining the provided custom message with details from the EntityException. It appends " not added" to the custom message, followed by the exception's message, localized message, and cause. The resulting error message is then displayed in a dialog box using JOptionPane.showMessageDialog(). This method is likely used to inform users or developers about failures in adding entities to the system, providing detailed information about the exception for debugging purposes.\\
## Code: 
```
void showEntityException(EntityException e, String msg) {
		String message = msg + " not added" + 
				"\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + e.getCause();
			JOptionPane.showMessageDialog(null, message);
	}
```