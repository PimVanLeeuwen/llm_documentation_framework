`findById`: The function of `findById` is to retrieve an Invoice object from the cache based on its ID.

**Parameters**:
`int id`: The unique identifier of the Invoice to be retrieved.

**Code Description**: This method first checks if caching is enabled by examining the `usingCache` flag. If caching is not in use, it calls the `list()` method to populate the cache. Then, it checks if the cache contains an Invoice with the given ID. If found, it returns the corresponding Invoice object; otherwise, it returns null. This approach allows for efficient retrieval of Invoice objects from memory when available, falling back to database queries only when necessary.\\
## Code: 
```
Invoice findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
	}
```