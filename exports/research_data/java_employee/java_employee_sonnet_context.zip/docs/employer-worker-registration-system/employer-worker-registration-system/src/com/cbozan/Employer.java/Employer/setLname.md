`setLname`: The function of `setLname` is to set the last name of an Employer object.

**Parameters**:
`String lname`: The last name to be set for the Employer.

**Code Description**: This method sets the last name (lname) of an Employer object. It first checks if the provided last name is valid by ensuring it's not empty and doesn't exceed the maximum length defined in DBConst.LNAME_LENGTH. If the last name is invalid, it throws an EntityException with the message "Employer last name empty or too long". If the last name passes the validation, it is assigned to the lname field of the Employer object.\\
## Code: 
```
void setLname(String lname) throws EntityException {
		if(lname.length() == 0 || lname.length() > DBConst.LNAME_LENGTH)
			throw new EntityException("Employer last name empty or too long");
		this.lname = lname;
	}
```