`updateEmployerPaymentTableData`: The function of `updateEmployerPaymentTableData` is to update and display payment information for a selected employer in a table format.

**Code Description**: This method retrieves a list of invoices for the selected employer, filters them based on a specific job, and populates a table with the invoice data. It calculates the total amount of all invoices and displays it along with the invoice count. The method performs the following steps:

1. Checks if an employer is selected.
2. Retrieves the list of invoices for the selected employer using InvoiceDAO.
3. Filters the invoice list using the `filterPaymentJob` method.
4. Creates a 2D array to hold the table data, with columns for invoice ID, job description, amount, and date.
5. Iterates through the filtered invoices, populating the table data array and calculating the total amount.
6. Updates the JTable model with the new data and sets column properties.
7. Applies center alignment to the first column.
8. Updates labels to show the total amount and number of records.

The method uses SimpleDateFormat for date formatting and BigDecimal for precise monetary calculations. It also customizes the table appearance by setting column widths and cell renderers.\\
## Code: 
```
void updateEmployerPaymentTableData() {
		
		if(selectedEmployer != null) {
			
			List<Invoice> invoiceList = InvoiceDAO.getInstance().list(selectedEmployer);
			filterPaymentJob(invoiceList);
			
			String[][] tableData = new String[invoiceList.size()][employerPaymentTableColumns.length];
			BigDecimal totalAmount = new BigDecimal("0.00");
			int i = 0;
			for(Invoice invoice : invoiceList) {
				tableData[i][0] = invoice.getId() + "";
				tableData[i][1] = invoice.getJob().toString();
				tableData[i][2] = invoice.getAmount() + " ₺";
				tableData[i][3] = new SimpleDateFormat("dd.MM.yyyy").format(invoice.getDate());
				totalAmount = totalAmount.add(invoice.getAmount());
				++i;
			}
			
			((JTable)employerPaymentScrollPane.getViewport().getComponent(0)).setModel(new DefaultTableModel(tableData, employerPaymentTableColumns));
			((JTable)employerPaymentScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setPreferredWidth(5);
			((JTable)employerPaymentScrollPane.getViewport().getComponent(0)).setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
			
			DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
			centerRenderer.setHorizontalAlignment( SwingConstants.CENTER );
			((JTable)employerPaymentScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
			
			employerPaymentTotalLabel.setText("Total " + totalAmount + " ₺");
			employerPaymentCountLabel.setText(invoiceList.size() + " Record");
			
		}
		
	}
```