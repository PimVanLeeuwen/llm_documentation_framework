`list`: The function of `list` is to retrieve a list of Payment objects from the database based on specified column names and their corresponding ID values.

**Parameters**:
`String[] columnName`: An array of column names to be used in the WHERE clause of the SQL query.
`int[] id`: An array of ID values corresponding to the column names, used to filter the query results.

**Code Description**: This method constructs and executes a SQL query to fetch Payment records from the database. It first checks if the lengths of `columnName` and `id` arrays match. If not, it returns an empty list. The method then builds a dynamic SQL query using the provided column names and IDs. It establishes a database connection, executes the query, and iterates through the result set. For each row, it creates a Payment object using the PaymentBuilder pattern, setting various attributes from the result set. If the Payment object is successfully built, it's added to the list. The method handles potential SQLException and EntityException, logging errors when they occur. Finally, it returns the list of Payment objects that match the specified criteria.\\
## Code: 
```
List<Payment> list(String[] columnName, int[] id){
		
		List<Payment> list = new ArrayList<>();
		if(columnName.length != id.length)
			return list;
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM payment WHERE ";
		
		for(int i = 0; i < columnName.length; i++) {
			query += columnName[i] + "=" + id[i] + " AND ";
		}
		
		query = query.substring(0, query.length() - (" AND ".length()));
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			PaymentBuilder builder;
			Payment payment;
			
			while(rs.next()) {
				
				builder = new PaymentBuilder();
				builder.setId(rs.getInt("id"));
				builder.setWorker_id(rs.getInt("worker_id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setPaytype_id(rs.getInt("paytype_id"));
				builder.setAmount(rs.getBigDecimal("amount"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					payment = builder.build();
					list.add(payment);
				} catch (EntityException e) {
					System.err.println(e.getMessage());
					System.out.println("!! Payment not added list !!");
				}
				
			}
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return list;
	}
```