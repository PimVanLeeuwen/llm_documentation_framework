`EmptyInstanceSingleton`: The function of `EmptyInstanceSingleton` is to provide a single, shared instance of the Work class.

**Code Description**: This class implements the Singleton design pattern for the Work class. It contains a private static final field named 'instance' which is initialized with a new Work object. The class is designed to ensure that only one instance of the Work class is created and used throughout the application. By making the constructor private (implied by the absence of a public constructor) and providing a static instance, it prevents multiple instantiations of the Work class and allows global access to this single instance.\\
## Code: 
```
class EmptyInstanceSingleton{
		private static final Work instance = new Work(); 
	}
```