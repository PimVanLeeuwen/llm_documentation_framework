`setHalftime`: The function of `setHalftime` is to set the halftime price value while validating the input.

**Parameters**:
`BigDecimal halftime`: The halftime price value to be set.

**Code Description**: This method sets the halftime price for the Price object. It first checks if the provided halftime value is valid. The method throws an EntityException if the halftime parameter is null, negative, or zero. It compares the input value with BigDecimal("0.00") to ensure it's greater than zero. If the input passes the validation, the method assigns the new value to the halftime instance variable. This approach ensures that only positive, non-zero values are accepted for the halftime price.\\
## Code: 
```
void setHalftime(BigDecimal halftime) throws EntityException {
		if(halftime == null || halftime.compareTo(new BigDecimal("0.00")) <= 0)
			throw new EntityException("Price halftime negative or null or zero");
		this.halftime = halftime;
	}
```