`create`: The function of `create` is to insert a new invoice record into the database and update the local cache.

**Parameters**:
`Invoice invoice`: An Invoice object containing the details of the invoice to be created.

**Code Description**: This method attempts to insert a new invoice record into the database using the provided Invoice object. It first establishes a database connection and prepares an SQL INSERT statement with the job ID and amount from the invoice. After executing the insert, if successful, it retrieves the newly created invoice's full details using a SELECT query. The retrieved data is used to create a new Invoice object, which is then added to the local cache. The method handles potential SQL exceptions and entity creation errors. It returns true if the insert was successful, and false otherwise. This approach ensures that the database and local cache remain synchronized after creating a new invoice.\\
## Code: 
```
boolean create(Invoice invoice) {
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO invoice (job_id,amount) VALUES (?,?);";
		String query2 = "SELECT * FROM invoice ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, invoice.getJob().getId());
			pst.setBigDecimal(2, invoice.getAmount());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					InvoiceBuilder builder = new InvoiceBuilder();
					builder.setId(rs.getInt("id"));
					builder.setJob_id(rs.getInt("job_id"));
					builder.setAmount(rs.getBigDecimal("amount"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Invoice inv = builder.build();
						cache.put(inv.getId(), inv);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id"));
					}
					
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```