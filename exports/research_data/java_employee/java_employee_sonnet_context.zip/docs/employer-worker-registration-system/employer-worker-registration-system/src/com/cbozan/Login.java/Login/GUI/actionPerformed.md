`actionPerformed`: The function of `actionPerformed` is to handle the login process when a user attempts to log in.

**Parameters**:
`ActionEvent e`: The event object representing the action performed, typically a button click.

**Code Description**: This method first checks if the username and password fields are empty. If either is empty, it displays an error message. If both fields have content, it attempts to verify the login credentials using a LoginDAO object. On successful login, it shows a welcome message and opens the main application frame (MainFrame) while closing the current login window. If login fails, it displays an error message. The method uses JOptionPane for messages, EventQueue for UI updates, and interacts with text fields, password fields, and labels in the login interface.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		
				if(textField_username.getText().equals("") || String.valueOf(passwordField_password.getPassword()).equals("")) {
					
					label_errorText.setText(errorText);
				
				} else {
					
					label_errorText.setText("");
					LoginDAO loginDAO = new LoginDAO();
					if(loginDAO.verifyLogin(textField_username.getText(), 
							String.valueOf(passwordField_password.getPassword()))) {
						JOptionPane.showMessageDialog(contentPane, "Login successful. Welcome", "Login", 
								JOptionPane.INFORMATION_MESSAGE);
						
						EventQueue.invokeLater(new Runnable() {
							@Override
							public void run() {
								Login.this.dispose();
								new MainFrame();
							}
						});
						
					} else {
						label_errorText.setText(errorText);
					}
					
				}
				
			}
```