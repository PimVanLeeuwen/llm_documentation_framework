`setFname`: The function of `setFname` is to set the first name of an Employer object.

**Parameters**:
`String fname`: The first name to be set for the Employer.

**Code Description**: This method sets the first name (fname) of an Employer object. It first checks if the provided name is valid by ensuring it's not empty and doesn't exceed the maximum length defined in DBConst.FNAME_LENGTH. If the name is invalid, it throws an EntityException with the message "Employer name empty or too long". If the name passes the validation, it is assigned to the fname field of the Employer object.\\
## Code: 
```
void setFname(String fname) throws EntityException {
		if(fname.length() == 0 || fname.length() > DBConst.FNAME_LENGTH)
			throw new EntityException("Employer name empty or too long");
		this.fname = fname;
	}
```