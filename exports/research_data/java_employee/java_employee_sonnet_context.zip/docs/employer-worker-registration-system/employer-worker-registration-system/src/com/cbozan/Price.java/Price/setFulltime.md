`setFulltime`: The function of `setFulltime` is to set the fulltime price value while validating the input.

**Parameters**:
`BigDecimal fulltime`: The new fulltime price value to be set.

**Code Description**: This method sets the fulltime price for an entity. It first checks if the provided `fulltime` parameter is valid. The validation ensures that the value is not null, not negative, and not zero. If the input fails these checks, an `EntityException` is thrown with a descriptive error message. If the input passes validation, the method assigns the new value to the `fulltime` instance variable. This approach ensures that only valid, positive price values are stored, maintaining data integrity for the fulltime price attribute.\\
## Code: 
```
void setFulltime(BigDecimal fulltime) throws EntityException {
		if(fulltime == null || fulltime.compareTo(new BigDecimal("0.00")) <= 0)
			throw new EntityException("Price fulltime negative or null or zero");
		this.fulltime = fulltime;
	}
```