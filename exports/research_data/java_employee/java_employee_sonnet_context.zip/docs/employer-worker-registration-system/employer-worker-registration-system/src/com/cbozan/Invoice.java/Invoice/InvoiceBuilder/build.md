`build`: The function of `build` is to create and return an Invoice object based on the provided parameters.

**Code Description**: This method is part of the InvoiceBuilder class, implementing the Builder pattern for creating Invoice objects. It has two possible execution paths:

1. If the `job` field is null, it creates a new Invoice using the current InvoiceBuilder instance (this), passing all the builder's fields to the Invoice constructor.

2. If the `job` field is not null, it creates a new Invoice using the individual fields (id, job, amount, and date) directly.

The method throws an EntityException, which likely handles validation or construction errors. This approach allows for flexible Invoice object creation, supporting both partial and complete data scenarios.\\
## Code: 
```
Invoice build() throws EntityException {
			if(job == null)
				return new Invoice(this);
			return new Invoice(id, job, amount, date);
		}
```