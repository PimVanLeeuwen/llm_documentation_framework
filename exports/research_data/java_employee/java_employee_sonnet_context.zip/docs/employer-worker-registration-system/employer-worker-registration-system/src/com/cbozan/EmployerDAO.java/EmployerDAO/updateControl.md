`updateControl`: The function of `updateControl` is to check if an employer with the same first name and last name already exists in the cache, excluding the employer with the same ID.

**Parameters**:
`Employer employer`: An Employer object containing the details of the employer to be checked.

**Code Description**: This method iterates through the cache (a Map of Integer keys and Employer values) using an entry set. For each entry, it compares the first name and last name of the cached employer with the provided employer. If a match is found and the IDs are different, it sets an error message in the DB class and returns false, indicating that an update should not proceed. If no match is found after checking all entries, the method returns true, allowing the update to continue. This prevents duplicate entries based on name while allowing updates to existing records.\\
## Code: 
```
boolean updateControl(Employer employer) {
		for(Entry<Integer, Employer> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(employer.getFname()) 
					&& obj.getValue().getLname().equals(employer.getLname()) 
					&& obj.getValue().getId() != employer.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```