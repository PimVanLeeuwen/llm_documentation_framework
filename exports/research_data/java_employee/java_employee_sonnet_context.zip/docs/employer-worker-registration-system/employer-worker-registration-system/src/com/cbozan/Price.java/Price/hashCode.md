`hashCode`: The function of `hashCode` is to generate a unique integer hash code for a Price object.

**Code Description**: This method overrides the default `hashCode()` method from the Object class. It uses the `Objects.hash()` utility method to create a hash code based on the values of the object's fields: date, fulltime, halftime, id, and overtime. The `Objects.hash()` method combines the hash codes of these fields into a single integer value, ensuring that objects with the same field values will have the same hash code. This implementation is consistent with the equals() method, which is crucial for proper functioning in hash-based collections like HashSet or HashMap.\\
## Code: 
```
int hashCode() {
		return Objects.hash(date, fulltime, halftime, id, overtime);
	}
```