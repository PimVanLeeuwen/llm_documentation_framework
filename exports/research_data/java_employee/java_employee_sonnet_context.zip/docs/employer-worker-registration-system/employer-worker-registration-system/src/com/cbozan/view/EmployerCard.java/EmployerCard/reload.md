`reload`: The function of `reload` is to refresh the EmployerCard with the currently selected employer's information.

**Code Description**: This method is a simple wrapper that calls the `setSelectedEmployer` method with the current value of `selectedEmployer`. It effectively triggers a refresh of the EmployerCard's UI components, updating them with the latest data of the selected employer. This method is useful for ensuring the displayed information is up-to-date, especially after any changes have been made to the employer data.\\
## Code: 
```
void reload() {
		setSelectedEmployer(selectedEmployer);
	}
```