`findById`: The function of `findById` is to retrieve an Employer object by its ID from the cache or return null if not found.

**Parameters**:
`int id`: The unique identifier of the Employer to be retrieved.

**Code Description**: This method first checks if the cache is being used by examining the `usingCache` flag. If caching is not active, it calls the `list()` method to populate the cache. Then, it checks if the cache contains an Employer with the given ID using the `containsKey()` method. If found, it returns the corresponding Employer object from the cache. If not found, it returns null. This approach ensures efficient retrieval of Employer objects by leveraging a caching mechanism to minimize database queries.\\
## Code: 
```
Employer findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
	}
```