`keyPressed`: The function of `keyPressed` is to handle key input for a date filter search box, formatting the input as a date range.

**Parameters**:
`KeyEvent e`: The key event object containing information about the key that was pressed.

**Code Description**: This method manages user input for a date range filter in a search box. It allows only numeric input and automatically formats the date range by adding separators (/ and -) at specific positions. The method limits the input to 21 characters and prevents non-numeric input except for the backspace key. If a non-numeric key is pressed (excluding backspace), or if the maximum length is reached, the search box becomes non-editable. The date format enforced is DD/MM/YYYY-DD/MM/YYYY, representing a start and end date range.\\
## Code: 
```
void keyPressed(KeyEvent e) {
				if((e.getKeyChar() >= '0' && e.getKeyChar() <= '9')) {
					
					if(workerPaymentDateFilterSearchBox.getText().length() >= 21) {
						workerPaymentDateFilterSearchBox.setEditable(false);
					} else {
						
						switch(workerPaymentDateFilterSearchBox.getText().length()) {
							case 2:case 5:case 13:case 16:
								workerPaymentDateFilterSearchBox.setText(workerPaymentDateFilterSearchBox.getText() + "/");
								break;
							case 10:
								workerPaymentDateFilterSearchBox.setText(workerPaymentDateFilterSearchBox.getText() + "-");
								break;
						}
						
					}
				} else if(e.getKeyCode() == KeyEvent.VK_BACK_SPACE);
				  else {
					  workerPaymentDateFilterSearchBox.setEditable(false);
				}
			}
```