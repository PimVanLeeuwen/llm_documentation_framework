`filterPaymentJob`: The function of `filterPaymentJob` is to filter a list of payments based on a selected job.

**Parameters**:
`List<Payment> paymentList`: A list of Payment objects to be filtered.

**Code Description**: This method filters a list of Payment objects based on a previously selected job (selectedWorkerPaymentJob). It first checks if a job has been selected; if not, it returns without modifying the list. If a job is selected, it iterates through the payment list using an Iterator. For each Payment object, it compares the job ID associated with the payment to the ID of the selected job. If the IDs don't match, the payment is removed from the list. This process effectively removes all payments that are not associated with the selected job, leaving only the payments for the chosen job in the list.\\
## Code: 
```
void filterPaymentJob(List<Payment> paymentList) {
		if(selectedWorkerPaymentJob == null)
			return;
		
		Iterator<Payment> payment = paymentList.iterator();
		Payment paymentItem;
		while(payment.hasNext()) {
			paymentItem = payment.next();
			if(paymentItem.getJob().getId() != selectedWorkerPaymentJob.getId()) {
				payment.remove();
			}
		}
	}
```