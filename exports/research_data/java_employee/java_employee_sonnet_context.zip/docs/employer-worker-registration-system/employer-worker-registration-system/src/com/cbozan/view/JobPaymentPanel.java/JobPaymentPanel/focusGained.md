`focusGained`: The function of `focusGained` is to visually highlight a text field when it gains focus.

**Parameters**:
`FocusEvent e`: The focus event that triggered this method.

**Code Description**: This method is called when a component gains focus. It specifically handles focus events for JTextField components. When a JTextField gains focus, the method changes its border color to blue, providing a visual cue to the user. Additionally, if the focused text field is the `amountTextField`, the method also changes the color of the associated `amountLabel` to blue. This creates a cohesive visual feedback system, helping users identify which field is currently active in the interface.\\
## Code: 
```
void focusGained(FocusEvent e) {
		if(e.getSource() instanceof JTextField) {
			
			((JTextField)e.getSource()).setBorder(new LineBorder(Color.blue));
			
			if(((JTextField)e.getSource()) == amountTextField) {
				amountLabel.setForeground(Color.blue);
			}
			
		}
		
	}
```