`delete`: The function of `delete` is to remove a specific invoice record from the database.

**Parameters**:
`Invoice invoice`: An Invoice object representing the invoice to be deleted from the database.

**Code Description**: This method attempts to delete an invoice record from the database based on the provided Invoice object. It establishes a database connection using the DB.getConnection() method and prepares a DELETE SQL statement. The invoice's ID is set as a parameter in the prepared statement. The method then executes the delete operation and checks the result. If the deletion is successful (result != 0), the invoice is also removed from the cache. The method returns true if the deletion was successful, and false otherwise. Any SQLException that occurs during the process is caught and its message is printed to the console.\\
## Code: 
```
boolean delete(Invoice invoice) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM invoice WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, invoice.getId());
			
			result = ps.executeUpdate();
			
			if(result != 0) {
				cache.remove(invoice.getId());
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return result == 0 ? false : true;
		
	}
```