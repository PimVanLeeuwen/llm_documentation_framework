`showEntityException`: The function of `showEntityException` is to display an error message dialog when an entity fails to be added.

**Parameters**:
`EntityException e`: The exception object containing details about the entity-related error.
`String msg`: A custom message describing the entity that failed to be added.

**Code Description**: This method constructs an error message by combining the provided custom message with additional details from the EntityException. It then displays this message in a dialog box using JOptionPane. The error message includes the custom message followed by "not added", the exception's message, localized message, and cause. This method is likely used to inform users or developers about failures in adding entities to the system, providing detailed information about the error for debugging or user feedback purposes.\\
## Code: 
```
void showEntityException(EntityException e, String msg) {
		String message = msg + " not added" + 
				"\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + e.getCause();
			JOptionPane.showMessageDialog(null, message);
	}
```