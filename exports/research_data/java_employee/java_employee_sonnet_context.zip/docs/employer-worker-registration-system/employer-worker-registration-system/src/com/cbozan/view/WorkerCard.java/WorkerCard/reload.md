`reload`: The function of `reload` is to refresh the WorkerCard display with the currently selected worker's information.

**Code Description**: This method is a simple wrapper that calls the `setSelectedWorker` method with the current `selectedWorker` as its argument. It effectively triggers a refresh of the WorkerCard's UI, updating all fields and components to reflect the current state of the selected worker. This method is useful for ensuring the display is synchronized with the underlying data, especially after changes have been made to the worker's information elsewhere in the application.\\
## Code: 
```
void reload() {
		setSelectedWorker(selectedWorker);
	}
```