`filterJob`: The function of `filterJob` is to filter a list of Work objects based on a selected job.

**Parameters**:
`List<Work> workList`: A list of Work objects to be filtered.

**Code Description**: This method filters the provided `workList` based on a previously selected job (`selectedWorkTableJob`). If no job is selected, the method returns without making any changes. Otherwise, it iterates through the `workList` using an Iterator. For each Work object, it checks if the associated Job's ID matches the ID of the selected job. If there's no match, the Work object is removed from the list. This process effectively removes all Work objects from the list that are not associated with the selected job, leaving only the Work items related to the chosen job.\\
## Code: 
```
void filterJob(List<Work> workList) {
		if(selectedWorkTableJob == null) {
			return;
		}
		
		Iterator<Work> work = workList.iterator();
		Work workItem;
		while(work.hasNext()) {
			workItem = work.next();
			if(workItem.getJob().getId() != selectedWorkTableJob.getId()) {
				work.remove();
			}
		}
		
	}
```