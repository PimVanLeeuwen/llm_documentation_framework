`list`: The function of `list` is to retrieve all workgroup records from the database or cache and return them as a List of Workgroup objects.

**Code Description**: This method first checks if there are cached workgroup objects and if cache usage is enabled. If so, it returns the cached objects. Otherwise, it clears the cache and queries the database for all workgroup records. For each record, it creates a WorkgroupBuilder, sets its properties using data from the ResultSet, builds a Workgroup object, adds it to the list, and caches it. The method handles potential SQL and EntityExceptions, displaying error messages when they occur. Finally, it returns the list of Workgroup objects. This approach optimizes performance by using cached data when available and ensures the cache is updated with the latest database records when queried.\\
## Code: 
```
List<Workgroup> list(){
		
		List<Workgroup> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Workgroup> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM workgroup;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorkgroupBuilder builder;
			Workgroup workgroup;
			
			while(rs.next()) {
				
				builder = new WorkgroupBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setWorktype_id(rs.getInt("worktype_id"));
				builder.setWorkCount(rs.getInt("workcount"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					workgroup = builder.build();
					list.add(workgroup);
					cache.put(workgroup.getId(), workgroup);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
	}
```