`getInstance`: The function of `getInstance` is to return the singleton instance of the InvoiceDAO class.

**Code Description**: This method implements the Singleton design pattern using a nested static helper class. It returns the single instance of InvoiceDAO stored in the InvoiceDAOHelper.instance field. The use of a static nested class (InvoiceDAOHelper) ensures thread-safe lazy initialization without the need for synchronization. This approach is known as the initialization-on-demand holder idiom. When getInstance() is called for the first time, it triggers the loading and initialization of the InvoiceDAOHelper class, which in turn creates the single InvoiceDAO instance. Subsequent calls to getInstance() simply return this already created instance, ensuring that only one instance of InvoiceDAO exists throughout the application's lifecycle.\\
## Code: 
```
InvoiceDAO getInstance() {
		return InvoiceDAOHelper.instance;
	}
```