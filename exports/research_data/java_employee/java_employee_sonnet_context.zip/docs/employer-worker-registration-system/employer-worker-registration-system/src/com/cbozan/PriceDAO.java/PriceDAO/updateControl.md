`updateControl`: The function of `updateControl` is to check if a given Price object already exists in the cache.

**Parameters**:
`Price price`: A Price object to be checked against existing entries in the cache.

**Code Description**: This method iterates through all entries in the cache, comparing the fulltime, halftime, and overtime values of the given price object with those of each cached Price object. If an exact match is found (excluding the ID), it sets an error message and returns false, indicating that the price information already exists. If no match is found, it returns true, allowing the update to proceed. This prevents duplicate price entries in the system while allowing updates to existing entries (since it excludes matching IDs).\\
## Code: 
```
boolean updateControl(Price price) {
		for(Entry<Integer, Price> obj : cache.entrySet()) {
			if(obj.getValue().getFulltime().compareTo(price.getFulltime()) == 0
					&& obj.getValue().getHalftime().compareTo(price.getHalftime()) == 0
					&& obj.getValue().getOvertime().compareTo(price.getOvertime()) == 0
					&& obj.getValue().getId() != price.getId()) {
				
				DB.ERROR_MESSAGE = "Bu fiyat bilgisi kaydı zaten mevcut.";
				return false;
			}
		}
		
		return true;
	}
```