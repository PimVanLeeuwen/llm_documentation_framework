`WorkBuilder`: The function of `WorkBuilder` is to facilitate the creation of Work objects using the Builder pattern.

**Code Description**: This inner class implements the Builder pattern for constructing Work objects. It contains private fields corresponding to the attributes of a Work object, including id, job_id, job, worker_id, worker, worktype_id, worktype, workgroup_id, workgroup, description, and date. The class provides two constructors: a default no-argument constructor and a parameterized constructor that initializes most fields. It also includes setter methods for each field, which return the WorkBuilder instance to allow method chaining. The build() method creates and returns a Work object based on the set fields, with error handling for null required fields. This pattern allows for flexible and readable object creation, especially when dealing with many optional parameters.\\
## Code: 
```
class WorkBuilder {
		
		private int id;
		private int job_id;
		private Job job;
		private int worker_id;
		private Worker worker;
		private int worktype_id;
		private Worktype worktype;
		private int workgroup_id;
		private Workgroup workgroup;
		private String description;
		private Timestamp date;
		
		public WorkBuilder() {}
		public WorkBuilder(int id, int job_id, int worker_id, int worktype_id, int workgroup_id, String description, Timestamp date) {
			this.id = id;
			this.job_id = job_id;
			this.worker_id = worker_id;
			this.worktype_id = worktype_id;
			this.description = description;
			this.date = date;
		}
		
		public WorkBuilder(int id, Job job, Worker worker, Worktype worktype, Workgroup workgroup, String description, Timestamp date) {
			this(id, 0, 0, 0, 0, description, date);
			this.job = job;
			this.worker = worker;
			this.worktype = worktype;
			this.workgroup = workgroup;
		}
		
		public WorkBuilder setId(int id) {
			this.id = id;
			return this;
		}
		
		public WorkBuilder setJob_id(int job_id) {
			this.job_id = job_id;
			return this;
		}
		
		public WorkBuilder setJob(Job job) {
			this.job = job;
			return this;
		}
		
		public WorkBuilder setWorker_id(int worker_id) {
			this.worker_id = worker_id;
			return this;
		}
		
		public WorkBuilder setWorker(Worker worker) {
			this.worker = worker;
			return this;
		}
		
		public WorkBuilder setWorktype_id(int worktype_id) {
			this.worktype_id = worktype_id;
			return this;
		}
		
		public WorkBuilder setWorktype(Worktype worktype) {
			this.worktype = worktype;
			return this;
		}
		
		public WorkBuilder setWorkgroup_id(int workgroup_id) {
			this.workgroup_id = workgroup_id;
			return this;
		}
		
		public WorkBuilder setWorkgroup(Workgroup workgroup) {
			this.workgroup = workgroup;
			return this;
		}
		
		public WorkBuilder setDescription(String description) {
			this.description = description;
			return this;
		}
		
		public WorkBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Work build() throws EntityException {
			if(job == null || worker == null || worktype == null || workgroup == null)
				return new Work(this);
			return new Work(id, job, worker, worktype, workgroup, description, date);
		}
		
	}
```