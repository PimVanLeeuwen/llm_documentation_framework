`getObjectList`: The function of `getObjectList` is to return the list of objects stored in the objectList field.

**Code Description**: This method is a simple getter that returns the objectList, which is likely a private field of the class. It provides read-only access to the list of objects stored in the SearchBox instance. The method has no parameters and returns a List<Object>, suggesting that the objectList can contain various types of objects. This getter allows other parts of the program to access the stored objects without directly exposing the internal list, maintaining encapsulation.\\
## Code: 
```
List<Object> getObjectList(){
		return objectList;
	}
```