`getSelectedObject`: The function of `getSelectedObject` is to return the currently selected object.

**Code Description**: This method is a simple getter that returns the value of the `selectedObject` instance variable. It doesn't perform any operations or modifications on the object; it merely provides access to the currently selected object stored in the class. This method is likely used to retrieve the object that has been selected through some user interaction or internal process within the SearchBox class.\\
## Code: 
```
Object getSelectedObject() {
		return selectedObject;
	}
```