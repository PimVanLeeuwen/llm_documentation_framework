`setId`: The function of `setId` is to set the ID of an Invoice object.

**Parameters**:
`int id`: The integer value to be set as the Invoice ID.

**Code Description**: This method sets the ID of an Invoice object. It first checks if the provided ID is valid by ensuring it's greater than zero. If the ID is less than or equal to zero, it throws an EntityException with the message "Invoice ID negative or zero". If the ID is valid, it assigns the value to the `id` field of the Invoice object. This method helps maintain data integrity by preventing invalid IDs from being set.\\
## Code: 
```
void setId(int id) throws EntityException {
		if(id <= 0)
			throw new EntityException("Invoice ID negative or zero");
		this.id = id;
	}
```