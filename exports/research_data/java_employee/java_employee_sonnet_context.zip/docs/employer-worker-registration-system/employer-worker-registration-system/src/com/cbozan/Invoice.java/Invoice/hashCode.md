`hashCode`: The function of `hashCode` is to generate a hash code for the Invoice object.

**Code Description**: This method overrides the default `hashCode()` method from the Object class. It uses the `Objects.hash()` utility method to create a hash code based on the values of four fields: `amount`, `date`, `id`, and `job`. The `Objects.hash()` method combines the hash codes of these fields to produce a single integer hash code for the Invoice object. This implementation ensures that two Invoice objects with the same values for these fields will have the same hash code, which is important for correct behavior when using hash-based collections like HashSet or HashMap.\\
## Code: 
```
int hashCode() {
		return Objects.hash(amount, date, id, job);
	}
```