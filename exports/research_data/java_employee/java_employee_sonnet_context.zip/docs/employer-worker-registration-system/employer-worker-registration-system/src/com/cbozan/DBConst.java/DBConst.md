`DBConst`: The function of `DBConst` is to define constant values for database field lengths.

**Code Description**: This class contains two public static final integer constants: FNAME_LENGTH and LNAME_LENGTH. FNAME_LENGTH is set to 30, likely representing the maximum length for a first name field in a database. LNAME_LENGTH is set to 20, probably indicating the maximum length for a last name field. These constants can be used throughout the application to ensure consistent field lengths when working with database operations or form validations related to names.\\
## Code: 
```
class DBConst {
	public static final int FNAME_LENGTH = 30;
	public static final int LNAME_LENGTH = 20;
}
```