`createComponents`: The function of `createComponents` is to initialize and organize various UI components for an employer-worker registration system.

**Code Description**: This method creates and organizes different panels for the user interface of an employer-worker registration system. It initializes three types of panels: record menu panels (JobPanel, WorkerPanel, EmployerPanel, PricePanel), add menu panels (WorkerPaymentPanel, WorkPanel, JobPaymentPanel), and display menu panels (JobDisplay, WorkerDisplay, EmployerDisplay). These panels are then added to an ArrayList called 'components'. The method sets the content pane of the main frame to the panel at the index specified by 'activePage' in the components list. This structure allows for easy switching between different panels in the user interface.\\
## Code: 
```
void createComponents() {
		
		// record menu panels
		JobPanel job = new JobPanel();
		WorkerPanel worker = new WorkerPanel();
		EmployerPanel employer = new EmployerPanel();
		PricePanel price = new PricePanel();
		
		// add menu panels
		WorkerPaymentPanel workerPayment = new WorkerPaymentPanel();
		WorkPanel work = new WorkPanel();
		JobPaymentPanel jobPayment = new JobPaymentPanel();
		
		// display menu panels
		JobDisplay jobDisplay = new JobDisplay();
		WorkerDisplay workerDisplay = new WorkerDisplay();
		EmployerDisplay employerDisplay = new EmployerDisplay();
		
		components = new ArrayList<>();
		components.add(job);
		components.add(worker);
		components.add(employer);
		components.add(price);
		components.add(workerPayment);
		components.add(work);
		components.add(jobPayment);
		components.add(jobDisplay);
		components.add(workerDisplay);
		components.add(employerDisplay);
		
		setContentPane((JPanel) components.get(activePage));
		
	}
```