`equals`: The function of `equals` is to compare this Invoice object with another object for equality.

**Parameters**:
`Object obj`: The object to compare with this Invoice object.

**Code Description**: This method overrides the default `equals` method to provide a custom equality comparison for Invoice objects. It first checks if the passed object is the same instance as the current object using reference equality. If not, it checks if the passed object is null or if it's not an instance of the Invoice class. If these checks pass, it casts the object to an Invoice and compares the `amount`, `date`, `id`, and `job` fields of both objects using `Objects.equals()` for non-primitive types and `==` for the primitive `id` field. The method returns true if all fields are equal, false otherwise.\\
## Code: 
```
boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Invoice other = (Invoice) obj;
		return Objects.equals(amount, other.amount) && Objects.equals(date, other.date) && id == other.id
				&& Objects.equals(job, other.job);
	}
```