`list`: The function of `list` is to retrieve all job records from the database or cache and return them as a List of Job objects.

**Code Description**: This method first checks if there are cached job records and if cache usage is enabled. If so, it returns the cached jobs. Otherwise, it clears the cache and queries the database for all job records. For each record, it creates a JobBuilder, sets the job properties from the ResultSet, builds a Job object, adds it to the list, and caches it. The method handles potential EntityExceptions when building Job objects and SQLExceptions during database operations. Finally, it returns the list of Job objects. The code uses a cache mechanism to improve performance for subsequent calls and implements error handling for database and entity creation issues.\\
## Code: 
```
List<Job> list(){
		
		List<Job> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Job> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM job;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			JobBuilder builder;
			Job job;
			
			while(rs.next()) {
				
				builder = new JobBuilder();
				builder.setId(rs.getInt("id"));
				builder.setEmployer_id(rs.getInt("employer_id"));
				builder.setPrice_id(rs.getInt("price_id"));
				builder.setTitle(rs.getString("title"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					job = builder.build();
					list.add(job);
					cache.put(job.getId(), job);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id") + " Title : " + rs.getString("title"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
	}
```