`list`: The function of `list` is to retrieve all Price objects from the database or cache and return them as a List.

**Code Description**: This method first checks if there are cached Price objects and if cache usage is enabled. If so, it returns the cached objects. Otherwise, it clears the cache and queries the database for all price records. For each record, it creates a PriceBuilder object, sets its properties from the database result, builds a Price object, adds it to the list and cache, and handles any EntityExceptions. The method uses a database connection, executes a SQL query to select all prices, and processes the result set. It catches and displays any SQLExceptions that occur during database operations. Finally, it returns the list of Price objects.\\
## Code: 
```
List<Price> list(){
		
		List<Price> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Price> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM price;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			PriceBuilder builder;
			Price price;
			
			while(rs.next()) {
				
				builder = new PriceBuilder();
				builder.setId(rs.getInt("id"));
				builder.setFulltime(rs.getBigDecimal("fulltime"));
				builder.setHalftime(rs.getBigDecimal("halftime"));
				builder.setOvertime(rs.getBigDecimal("overtime"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					price = builder.build();
					list.add(price);
					cache.put(price.getId(), price);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
		
	}
```