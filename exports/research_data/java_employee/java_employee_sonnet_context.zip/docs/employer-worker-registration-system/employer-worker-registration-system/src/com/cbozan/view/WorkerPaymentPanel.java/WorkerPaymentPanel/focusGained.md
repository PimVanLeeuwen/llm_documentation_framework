`focusGained`: The function of `focusGained` is to visually highlight a text field when it gains focus.

**Parameters**:
`FocusEvent e`: The focus event that triggered this method.

**Code Description**: This method is called when a component gains focus. It specifically handles JTextField components. When a JTextField gains focus, its border is changed to blue. Additionally, if the focused text field is the `amountTextField`, the corresponding `amountLabel` is also changed to blue. This provides visual feedback to the user, indicating which field is currently active or selected.\\
## Code: 
```
void focusGained(FocusEvent e) {
		if(e.getSource() instanceof JTextField) {
			
			((JTextField)e.getSource()).setBorder(new LineBorder(Color.blue));
			
			if(((JTextField)e.getSource()) == amountTextField) {
				amountLabel.setForeground(Color.blue);
			}
			
		}
		
	}
```