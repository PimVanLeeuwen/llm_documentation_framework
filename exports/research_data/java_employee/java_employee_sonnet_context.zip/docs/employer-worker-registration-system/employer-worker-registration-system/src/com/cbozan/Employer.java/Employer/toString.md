`toString`: The function of `toString` is to return a string representation of the Employer object.

**Code Description**: This method overrides the default `toString()` method to provide a custom string representation of the Employer object. It concatenates the first name and last name of the employer, separated by a space. The method calls `getFname()` to retrieve the first name and `getLname()` to retrieve the last name, then combines them into a single string. This representation allows for a simple and human-readable output of the employer's full name when the object is converted to a string.\\
## Code: 
```
String toString() {
		return getFname() + " " + getLname();
	}
```