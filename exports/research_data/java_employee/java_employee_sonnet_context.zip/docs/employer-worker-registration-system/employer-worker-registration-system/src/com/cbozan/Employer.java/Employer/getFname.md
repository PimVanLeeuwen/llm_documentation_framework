`getFname`: The function of `getFname` is to return the first name of the employer.

**Code Description**: This is a simple getter method that returns the value of the private field `fname`. It takes no parameters and returns a String, which represents the first name of the employer object. This method provides read-only access to the `fname` attribute, allowing other parts of the program to retrieve the first name of an employer without directly accessing the private field.\\
## Code: 
```
String getFname() {
		return fname;
	}
```