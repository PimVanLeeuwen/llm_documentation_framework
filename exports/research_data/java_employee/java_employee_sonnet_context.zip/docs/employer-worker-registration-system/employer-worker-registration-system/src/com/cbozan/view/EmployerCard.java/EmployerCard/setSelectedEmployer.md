`setSelectedEmployer`: The function of `setSelectedEmployer` is to update the EmployerCard with the details of a selected employer or reset it to initial values if no employer is selected.

**Parameters**:
`Employer selectedEmployer`: The Employer object whose details are to be displayed in the EmployerCard. If null, the card is reset to initial values.

**Code Description**: This method updates the EmployerCard based on the provided selectedEmployer. If selectedEmployer is null, it resets all text fields and text area to an initial text value (INIT_TEXT). If an employer is selected, it populates the fields with the employer's details: first name, last name, telephone number (if available), and description. The method then iterates through the components of the EmployerCard, setting RecordTextField and TextArea components to non-editable and updating the icon of associated buttons. This ensures that the displayed information is read-only until explicitly edited.\\
## Code: 
```
void setSelectedEmployer(Employer selectedEmployer) {
		this.selectedEmployer = selectedEmployer;
		
		if(selectedEmployer == null) {
			fnameTextField.setText(INIT_TEXT);
			lnameTextField.setText(INIT_TEXT);
			telTextField.setText(INIT_TEXT);
			descriptionTextArea.setText(INIT_TEXT);
		} else {
			
			setFnameTextFieldContent(selectedEmployer.getFname());
			setLnameTextFieldContent(selectedEmployer.getLname());
			if(selectedEmployer.getTel() == null || selectedEmployer.getTel().size() == 0)
				setTelTextFieldContent("");
			else
				setTelTextFieldContent(selectedEmployer.getTel().get(0));
			setDescriptionTextAreaContent(selectedEmployer.getDescription());
			
		}
		
		for(int i = 2; i < this.getComponentCount(); i += 3) {
			if(getComponent(i - 1) instanceof RecordTextField)
				((RecordTextField)this.getComponent(i - 1)).setEditable(false);
			else if(getComponent(i - 1) instanceof TextArea)
				((TextArea)getComponent(i - 1)).setEditable(false);
			
			((JButton)this.getComponent(i)).setIcon(new ImageIcon("src\\icon\\text_edit.png"));
		}
		
		
	}
```