`clearPanel`: The function of `clearPanel` is to reset the input fields and visual elements of the price panel to their default state.

**Code Description**: This method clears the content of three text fields: `fulltimeTextField`, `halftimeTextField`, and `overtimeTextField` by setting their text to an empty string. It then resets the border color of these text fields to white using a `LineBorder`. Finally, it changes the foreground color of three labels (`fulltimeLabel`, `halftimeLabel`, and `overtimeLabel`) to a default color, which is likely defined elsewhere in the class. This method is typically used to clear user inputs and reset the visual state of the panel, possibly after submitting data or when the user wants to start over with new inputs.\\
## Code: 
```
void clearPanel() {
		
		fulltimeTextField.setText("");
		halftimeTextField.setText("");
		overtimeTextField.setText("");
		
		fulltimeTextField.setBorder(new LineBorder(Color.white));
		halftimeTextField.setBorder(new LineBorder(Color.white));
		overtimeTextField.setBorder(new LineBorder(Color.white));
		
		fulltimeLabel.setForeground(defaultColor);
		halftimeLabel.setForeground(defaultColor);
		overtimeLabel.setForeground(defaultColor);
		
	}
```