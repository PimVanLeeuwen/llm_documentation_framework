`setFname`: The function of `setFname` is to set the first name of an employer.

**Parameters**:
`String fname`: This parameter represents the first name of the employer that needs to be set.

**Code Description**: The `setFname` method takes a `String` parameter `fname` and performs the following operations:

1. It checks if the length of the `fname` string is either 0 (empty) or greater than the constant `DBConst.FNAME_LENGTH`. This constant likely represents the maximum allowed length for the employer's first name.
2. If the length of `fname` is invalid (either empty or too long), the method throws an `EntityException` with the message "Employer name empty or too long".
3. If the length of `fname` is valid, the method sets the `fname` field of the `Employer` object to the provided value.

The purpose of this method is to ensure that the first name of the employer is within the specified length requirements. If the provided first name is invalid, an exception is thrown to notify the caller of the issue.\\
## Code: 
```
void setFname(String fname) throws EntityException {
		if(fname.length() == 0 || fname.length() > DBConst.FNAME_LENGTH)
			throw new EntityException("Employer name empty or too long");
		this.fname = fname;
	}
```