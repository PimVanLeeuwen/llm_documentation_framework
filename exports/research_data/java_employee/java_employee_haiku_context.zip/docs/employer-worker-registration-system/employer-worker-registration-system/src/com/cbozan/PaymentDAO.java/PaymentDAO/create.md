`create`: The function of `create` is to insert a new payment record into the database.

**Parameters**:
`Payment payment`: This parameter represents the payment object that contains the details of the payment to be inserted into the database, such as the worker ID, job ID, payment type ID, and payment amount.

**Code Description**:
1. The method first calls the `createControl` method to perform a check on the `payment` object. If the check fails, the method returns `false`.
2. The method then establishes a connection to the database using the `DB.getConnection()` method.
3. It prepares an SQL `INSERT` statement to insert the payment details into the `payment` table. The statement includes placeholders for the worker ID, job ID, payment type ID, and payment amount.
4. The method sets the values of the placeholders using the corresponding getter methods of the `payment` object.
5. The method executes the SQL statement using the `executeUpdate()` method, which returns the number of rows affected.
6. If the SQL statement is executed successfully (i.e., the number of rows affected is not 0), the method executes another SQL statement to retrieve the most recently inserted payment record.
7. The method then creates a `PaymentBuilder` object and sets the properties of the payment record using the retrieved data. It then creates a `Payment` object using the `PaymentBuilder` and adds it to a cache.
8. If any exceptions occur during the process, the method calls the `showSQLException` method to display the error message.
9. Finally, the method returns `true` if the payment record was inserted successfully, and `false` otherwise.

Overall, the `create` method is responsible for inserting a new payment record into the database and updating a cache with the newly inserted record.\\
## Code: 
```
boolean create(Payment payment) {
		
		if(createControl(payment) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO payment (worker_id,job_id,paytype_id,amount) VALUES (?,?,?,?);";
		String query2 = "SELECT * FROM payment ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, payment.getWorker().getId());
			pst.setInt(2, payment.getJob().getId());
			pst.setInt(3, payment.getPaytype().getId());
			pst.setBigDecimal(4, payment.getAmount());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					PaymentBuilder builder = new PaymentBuilder();
					builder.setId(rs.getInt("id"));
					builder.setWorker_id(rs.getInt("worker_id"));
					builder.setJob_id(rs.getInt("job_id"));
					builder.setPaytype_id(rs.getInt("paytype_id"));
					builder.setAmount(rs.getBigDecimal("amount"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Payment py = builder.build();
						cache.put(py.getId(), py);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id"));
					}
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```