`actionPerformed`: The function of `actionPerformed` is to handle the user's action when they click the "Take Payment" button in the JobPaymentPanel.

**Parameters**:
`ActionEvent e`: This parameter represents the action event that triggered the `actionPerformed` method, such as a button click.

**Code Description**:
The `actionPerformed` method first checks if the source of the event is the "Take Payment" button. If so, it proceeds to process the payment.

1. It retrieves the selected job and the amount entered in the text field.
2. It checks if the amount entered is a valid decimal number and if a job is selected. If not, it displays an error message using a `JOptionPane`.
3. If the input is valid, it creates two `JTextArea` components to display the job details and the payment amount.
4. It then displays a confirmation dialog using `JOptionPane.showOptionDialog`, allowing the user to either save the payment or cancel the operation.
5. If the user chooses to save the payment, the method creates an `Invoice` object using the `Invoice.InvoiceBuilder` and sets its properties (ID, job, and amount).
6. It then attempts to create the invoice in the database using the `InvoiceDAO.create` method.
7. If the invoice is successfully created, it displays a success message and notifies all observers by calling the `notifyAllObservers` method.
8. If there is a database error, it displays an error message.

The `decimalControl` method is a helper method that checks if the input string matches a decimal pattern (up to two decimal places). It is used to validate the payment amount entered by the user.

Overall, the `actionPerformed` method is responsible for handling the user's payment submission, validating the input, creating an invoice, and updating the database and observers accordingly.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		if(e.getSource() == takePaymentButton) {
			
			Job job;
			String amount;
			
			job = selectedJob;
			amount = amountTextField.getText().replaceAll("\\s+", "");

			if(!decimalControl(amount) || job == null) {
				
				String message;
				message = "Please enter job selection section or format correctly (max 2 floating point)";
				JOptionPane.showMessageDialog(this, message, "ERROR", JOptionPane.ERROR_MESSAGE);
				
			} else {
				
				JTextArea jobTextArea, amountTextArea;
				
				jobTextArea = new JTextArea(job.toString());
				jobTextArea.setEditable(false);
				
				amountTextArea = new JTextArea(amount + " ₺");
				amountTextArea.setEditable(false);
				
				Object[] pane = {
						new JLabel("Job"),
						jobTextArea,
						new JLabel("Amount of payment"),
						amountTextArea
				};
		
				int result = JOptionPane.showOptionDialog(this, pane, "Confirmation", 1, 1, 
						new ImageIcon("src\\icon\\accounting_icon_1_32.png"), new Object[] {"SAVE", "CANCEL"}, "CANCEL");
				
				
				// System.out.println(result);
				// 0 -> SAVE
				// 1 -> CANCEL
				
				if(result == 0) {
					
					Invoice.InvoiceBuilder builder = new Invoice.InvoiceBuilder();
					builder.setId(Integer.MAX_VALUE);
					builder.setJob(selectedJob);
					builder.setAmount(new BigDecimal(amount));
					
					Invoice invoice = null;
					try {
						invoice = builder.build();
					} catch (EntityException e1) {
						System.out.println(e1.getMessage());
					}
					
					if(InvoiceDAO.getInstance().create(invoice)) { 
						JOptionPane.showMessageDialog(this, "Registration successful");
						notifyAllObservers();
					} else {
						JOptionPane.showMessageDialog(this, "Not saved", "DataBase error", JOptionPane.ERROR_MESSAGE);
					}
				}
				
			}
			
		}
		
	}
```