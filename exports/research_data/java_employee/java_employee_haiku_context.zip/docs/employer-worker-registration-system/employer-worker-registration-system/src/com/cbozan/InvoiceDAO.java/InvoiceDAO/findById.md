`findById`: The function of `findById` is to retrieve an `Invoice` object from a cache or, if the cache is not being used, from a list of `Invoice` objects.

**Parameters**:
`int id`: The unique identifier of the `Invoice` object to be retrieved.

**Code Description**: The `findById` method first checks if the cache is being used (`usingCache == false`). If the cache is not being used, it calls the `list()` method to populate the list of `Invoice` objects. Then, it checks if the cache contains the `Invoice` object with the given `id`. If the cache contains the `Invoice` object, it returns the object from the cache. If the cache does not contain the `Invoice` object, it returns `null`.

The purpose of this code is to provide a way to efficiently retrieve an `Invoice` object by its unique identifier. If the cache is being used, the method can quickly retrieve the `Invoice` object from the cache, which can improve performance. If the cache is not being used, the method falls back to retrieving the `Invoice` object from the list, which may be slower but ensures that the data is up-to-date.\\
## Code: 
```
Invoice findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
	}
```