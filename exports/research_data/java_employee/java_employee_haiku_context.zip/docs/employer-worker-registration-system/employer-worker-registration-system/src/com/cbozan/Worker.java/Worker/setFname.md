`setFname`: The function of `setFname` is to set the first name of a worker.

**Parameters**:
`String fname`: This parameter represents the first name of the worker that needs to be set.

**Code Description**: The `setFname` method takes a `String` parameter `fname` and performs the following operations:

1. It checks if the length of the `fname` string is either 0 (empty) or greater than the constant `DBConst.FNAME_LENGTH`. This constant likely represents the maximum allowed length for a worker's first name.
2. If the length of `fname` is invalid (either empty or too long), the method throws an `EntityException` with the message "Worker name empty or too long".
3. If the length of `fname` is valid, the method sets the `fname` field of the current `Worker` object to the provided `fname` value.

The purpose of this method is to ensure that the first name of a worker is not empty and does not exceed the maximum allowed length. If the provided first name is invalid, an exception is thrown to indicate the error.\\
## Code: 
```
void setFname(String fname) throws EntityException {
		if(fname.length() == 0 || fname.length() > DBConst.FNAME_LENGTH)
			throw new EntityException("Worker name empty or too long");
		this.fname = fname;
	}
```