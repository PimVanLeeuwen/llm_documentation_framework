`equals`: The function of `equals` is to compare the current `Invoice` object with another `Object` to determine if they are equal.

**Parameters**:
`Object obj`: The `Object` to be compared with the current `Invoice` object.

**Code Description**:
The `equals` method first checks if the current `Invoice` object is the same as the `Object` being compared (`this == obj`). If they are the same object, the method returns `true`.

Next, the method checks if the `Object` being compared is `null`. If it is, the method returns `false` because a `null` object cannot be equal to the current `Invoice` object.

The method then checks if the class of the `Object` being compared is the same as the class of the current `Invoice` object (`getClass() != obj.getClass()`). If the classes are not the same, the method returns `false` because the objects are not of the same type.

If the above checks pass, the method casts the `Object` being compared to an `Invoice` object (`Invoice other = (Invoice) obj;`) and compares the following properties of the two `Invoice` objects:
- `amount`: Compares the `amount` property of the two `Invoice` objects using `Objects.equals()`.
- `date`: Compares the `date` property of the two `Invoice` objects using `Objects.equals()`.
- `id`: Compares the `id` property of the two `Invoice` objects using the `==` operator.
- `job`: Compares the `job` property of the two `Invoice` objects using `Objects.equals()`.

If all of these properties are equal, the method returns `true`, indicating that the two `Invoice` objects are equal. Otherwise, it returns `false`.\\
## Code: 
```
boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Invoice other = (Invoice) obj;
		return Objects.equals(amount, other.amount) && Objects.equals(date, other.date) && id == other.id
				&& Objects.equals(job, other.job);
	}
```