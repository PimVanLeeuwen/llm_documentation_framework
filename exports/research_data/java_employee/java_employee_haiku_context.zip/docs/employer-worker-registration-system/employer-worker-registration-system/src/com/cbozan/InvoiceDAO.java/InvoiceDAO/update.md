`update`: The function of `update` is to update an existing invoice in the database.

**Parameters**:
`Invoice invoice`: This parameter represents the invoice object that needs to be updated in the database. It contains the updated information for the invoice, such as the job ID and the amount.

**Code Description**:
The `update` method takes an `Invoice` object as a parameter and updates the corresponding record in the `invoice` table in the database. It performs the following steps:

1. It establishes a connection to the database using the `DB.getConnection()` method.
2. It prepares a SQL `UPDATE` statement with the following parameters:
   - `job_id`: The ID of the job associated with the invoice, obtained from the `invoice.getJob().getId()` method.
   - `amount`: The updated amount of the invoice, obtained from the `invoice.getAmount()` method.
   - `id`: The ID of the invoice to be updated, obtained from the `invoice.getId()` method.
3. It executes the prepared SQL statement using the `pst.executeUpdate()` method, which returns the number of rows affected.
4. If the update is successful (i.e., the number of rows affected is not 0), the updated `Invoice` object is added to the `cache` using the `cache.put(invoice.getId(), invoice)` method.
5. If an `SQLException` occurs during the update process, the `showSQLException(e)` method is called to display the error message to the user.
6. Finally, the method returns `true` if the update was successful (i.e., the number of rows affected is not 0), and `false` otherwise.

The `update` method is responsible for updating an existing invoice in the database. It takes the updated information from the `Invoice` object and applies the changes to the corresponding record in the `invoice` table. The method also updates the cache with the modified `Invoice` object to ensure that the cached data is consistent with the database.\\
## Code: 
```
boolean update(Invoice invoice) {
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE invoice SET job_id=?,"
				+ "amount=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, invoice.getJob().getId());
			pst.setBigDecimal(2, invoice.getAmount());
			pst.setInt(5, invoice.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(invoice.getId(), invoice);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```