`actionPerformed`: The function of `actionPerformed` is to handle user actions performed within the Login GUI.

**Parameters**:
`ActionEvent e`: This parameter represents the action event that triggered the `actionPerformed` method, such as a button click or a key press.

**Code Description**:
The `actionPerformed` method is responsible for validating the user's login credentials and either displaying an error message or proceeding to the main application window.

The code first checks if the username and password fields are empty. If either field is empty, it sets an error message in the `label_errorText` component.

If both the username and password fields are filled, the code clears the error message and creates an instance of the `LoginDAO` class. It then calls the `verifyLogin` method of the `LoginDAO` class, passing the entered username and password as arguments.

If the `verifyLogin` method returns `true`, indicating that the login credentials are valid, the code displays a success message using `JOptionPane.showMessageDialog` and then creates a new instance of the `MainFrame` class, effectively closing the current Login window and opening the main application window.

If the `verifyLogin` method returns `false`, indicating that the login credentials are invalid, the code sets the error message in the `label_errorText` component.

Overall, the `actionPerformed` method is responsible for handling the user's login attempt, validating the credentials, and either displaying an error message or transitioning to the main application window.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		
				if(textField_username.getText().equals("") || String.valueOf(passwordField_password.getPassword()).equals("")) {
					
					label_errorText.setText(errorText);
				
				} else {
					
					label_errorText.setText("");
					LoginDAO loginDAO = new LoginDAO();
					if(loginDAO.verifyLogin(textField_username.getText(), 
							String.valueOf(passwordField_password.getPassword()))) {
						JOptionPane.showMessageDialog(contentPane, "Login successful. Welcome", "Login", 
								JOptionPane.INFORMATION_MESSAGE);
						
						EventQueue.invokeLater(new Runnable() {
							@Override
							public void run() {
								Login.this.dispose();
								new MainFrame();
							}
						});
						
					} else {
						label_errorText.setText(errorText);
					}
					
				}
				
			}
```