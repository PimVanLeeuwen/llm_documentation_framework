`decimalControl`: The function of `decimalControl` is to check if a given set of strings match a specified regular expression pattern.

**Parameters**:
`Pattern pattern`: This parameter represents a regular expression pattern that will be used to match the input strings.
`String ...args`: This is a variable-length argument list that contains the strings to be checked against the regular expression pattern.

**Code Description**:
The `decimalControl` method takes a `Pattern` object and a variable number of `String` arguments. It then iterates through each of the input strings and checks if the string matches the provided regular expression pattern using the `matcher()` method of the `Pattern` object. The method returns `true` if all the input strings match the pattern, and `false` otherwise.

The method uses the logical AND (`&=`) operator to accumulate the result of the pattern matching for each input string. If any of the input strings do not match the pattern, the final result will be `false`.

This method can be useful in scenarios where you need to validate that a set of input strings conform to a specific pattern, such as checking if they represent valid decimal numbers or other types of data.\\
## Code: 
```
boolean decimalControl(Pattern pattern, String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= pattern.matcher(arg).find();
		}
		return rValue;
	}
```