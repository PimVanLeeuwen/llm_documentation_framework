`getLname`: The function of `getLname` is to return the value of the `lname` instance variable.

**Code Description**: The `getLname()` method is a simple getter method that returns the value of the `lname` instance variable. This method is commonly used in object-oriented programming to provide controlled access to the private instance variables of a class. By encapsulating the data within the class and providing getter and setter methods, the class can maintain data integrity and control how the data is accessed and modified.

In this case, the `getLname()` method allows other parts of the code to retrieve the last name of the `Employer` object without directly accessing the `lname` instance variable. This promotes better code organization, maintainability, and data encapsulation.\\
## Code: 
```
String getLname() {
		return lname;
	}
```