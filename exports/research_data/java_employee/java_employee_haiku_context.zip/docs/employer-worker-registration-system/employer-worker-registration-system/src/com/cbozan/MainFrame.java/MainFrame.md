`MainFrame`: The function of `MainFrame` is to serve as the main window and entry point for the employer-worker registration system application.

**Code Description**:

1. The `MainFrame` class extends the `JFrame` class and implements the `ActionListener` interface. It represents the main window of the application.

2. The class defines several constants, including the frame name, dimensions, and button sizes, as well as action command IDs for various menu items.

3. The `MainFrame` constructor initializes the frame, sets its layout, size, and other properties, and calls the `GUI()` method to set up the graphical user interface.

4. The `GUI()` method is responsible for creating the menu bar, menus, and menu items, as well as initializing the various panels and displays that make up the application's user interface.

5. The `createMenus()` method sets up the menu bar with three main menus: "Record", "Add", and "Display". Each menu contains several menu items that allow the user to perform actions such as creating new jobs, workers, employers, and prices, as well as managing worker payments, work, and job payments.

6. The `createComponents()` method initializes the various panels and displays that make up the application's user interface, including panels for jobs, workers, employers, prices, worker payments, work, job payments, and displays for jobs, workers, and employers. These components are added to an `ArrayList` called `components`.

7. The `actionPerformed()` method is called when a menu item is selected. It checks the action command of the event and updates the active page of the application accordingly, setting the content pane to the corresponding component from the `components` list.

8. The `setComponent()` method allows the application to set the content pane to a specific component based on its class. It iterates through the `components` list and sets the content pane to the first component that matches the specified class.

Overall, the `MainFrame` class serves as the main entry point and coordinator for the employer-worker registration system application, managing the user interface and handling user interactions through the menu system.\\
## Code: 
```
class MainFrame extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;

	public static final String FRAME_NAME = "Hesap-eProject";
	
	public static final int W_FRAME = 1080;
	public static final int H_FRAME = (int) (W_FRAME / ((Math.sqrt(5) + 1) / 2));
	public static final int MENU_BUTTON_WIDTH = 120;
	public static final int MENU_BUTTON_HEIGHT = 60;
	public static Insets INSETS;
	
	public final int NEW_EMPLOYER_ACTION_COMMAND = 0;
	public final int NEW_WORKER_ACTION_COMMAND = 1;
	
	private byte activePage = 0;
	
	private JMenuBar menuBar;
	private JMenu newRecordMenu, addMenu, displayMenu;
	private JMenuItem newEmployerItem, newWorkerItem, newJobItem, newPriceItem;
	private JMenuItem newWorkItem, newWorkerPaymentItem, newEmployerPaymentItem;
	private JMenuItem displayWorkerItem, displayEmployerItem, displayJobItem;
	private List<Observer> components;
	
	public MainFrame() {
		this(0);
	}
	
	public MainFrame(int component) {
		super(FRAME_NAME);
		super.setName("MYFRAME");
		setLayout(null);
		setSize(W_FRAME, H_FRAME);
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
		
		activePage = (byte) component;
		
		INSETS = getInsets();
		
		GUI();
		
	}
	
	
	private void GUI() {
		createMenus();
		createComponents();
		//init();
		
	}
	
	
	
	private void createMenus() {
		
		menuBar = new JMenuBar();
		
		newRecordMenu = new JMenu("Record");
		addMenu = new JMenu("Add");
		displayMenu = new JMenu("Display");
		
		
		newJobItem = new JMenuItem("New Job");
		newJobItem.setActionCommand("0");
		newJobItem.addActionListener(this);
		
		newWorkerItem = new JMenuItem("New worker");
		newWorkerItem.setActionCommand("1");
		newWorkerItem.addActionListener(this);
		
		newEmployerItem = new JMenuItem("New employer");
		newEmployerItem.setActionCommand("2");
		newEmployerItem.addActionListener(this);
		
		newPriceItem = new JMenuItem("New price");
		newPriceItem.setActionCommand("3");
		newPriceItem.addActionListener(this);
		
		newRecordMenu.add(newJobItem);
		newRecordMenu.add(newWorkerItem);
		newRecordMenu.add(newEmployerItem);
		newRecordMenu.add(newPriceItem);
		
		
		newWorkerPaymentItem = new JMenuItem("Worker payment");
		newWorkerPaymentItem.setActionCommand("4");
		newWorkerPaymentItem.addActionListener(this);
		
		newWorkItem = new JMenuItem("Work");
		newWorkItem.setActionCommand("5");
		newWorkItem.addActionListener(this);
		
		newEmployerPaymentItem = new JMenuItem("Job payment");
		newEmployerPaymentItem.setActionCommand("6");
		newEmployerPaymentItem.addActionListener(this);
		
		addMenu.add(newWorkerPaymentItem);
		addMenu.add(newWorkItem);
		addMenu.add(newEmployerPaymentItem);
		
		
		displayJobItem = new JMenuItem("Display job");
		displayJobItem.setActionCommand("7");
		displayJobItem.addActionListener(this);
		
		displayWorkerItem = new JMenuItem("Display worker");
		displayWorkerItem.setActionCommand("8");
		displayWorkerItem.addActionListener(this);
		
		displayEmployerItem = new JMenuItem("Display employer");
		displayEmployerItem.setActionCommand("9");
		displayEmployerItem.addActionListener(this);
		
		
		displayMenu.add(displayJobItem);
		displayMenu.add(displayWorkerItem);
		displayMenu.add(displayEmployerItem);
		
		menuBar.add(newRecordMenu);
		menuBar.add(addMenu);
		menuBar.add(displayMenu);
		
		
		this.setJMenuBar(menuBar);
		
		
	}
	
	
	private void createComponents() {
		
		// record menu panels
		JobPanel job = new JobPanel();
		WorkerPanel worker = new WorkerPanel();
		EmployerPanel employer = new EmployerPanel();
		PricePanel price = new PricePanel();
		
		// add menu panels
		WorkerPaymentPanel workerPayment = new WorkerPaymentPanel();
		WorkPanel work = new WorkPanel();
		JobPaymentPanel jobPayment = new JobPaymentPanel();
		
		// display menu panels
		JobDisplay jobDisplay = new JobDisplay();
		WorkerDisplay workerDisplay = new WorkerDisplay();
		EmployerDisplay employerDisplay = new EmployerDisplay();
		
		components = new ArrayList<>();
		components.add(job);
		components.add(worker);
		components.add(employer);
		components.add(price);
		components.add(workerPayment);
		components.add(work);
		components.add(jobPayment);
		components.add(jobDisplay);
		components.add(workerDisplay);
		components.add(employerDisplay);
		
		setContentPane((JPanel) components.get(activePage));
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(Integer.parseInt(e.getActionCommand())>= 0 && Integer.parseInt(e.getActionCommand()) < components.size()) {
			if(Integer.parseInt(e.getActionCommand()) == activePage) {
				components.get(activePage).update();
			} else {
				activePage = (byte) Integer.parseInt(e.getActionCommand());
			}
			setContentPane((JPanel)components.get(activePage));
			
			revalidate();
		}
		
	}
	
	public <C> void setComponent(Class<C> class1) {
		
		for(Observer obj : components) {
			if(obj.getClass() == class1) {
				setContentPane((JPanel)obj);
				revalidate();
				break;
			}
		}
		
	}

}
```