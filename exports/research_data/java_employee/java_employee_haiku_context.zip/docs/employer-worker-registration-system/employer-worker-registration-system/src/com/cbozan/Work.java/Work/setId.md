`setId`: The function of `setId` is to set the `id` property of the `Work` object.

**Parameters**:
`int id`: This parameter represents the new ID value that will be assigned to the `id` property of the `Work` object.

**Code Description**:
The `setId` method takes an integer `id` as a parameter and sets the `id` property of the `Work` object to the provided value. However, before setting the `id`, the method checks if the provided `id` is less than or equal to 0. If the `id` is negative or zero, the method throws an `EntityException` with the message "Work ID negative or zero". This exception is used to handle the case where an invalid ID value is provided, ensuring that the `id` property of the `Work` object is always a positive, non-zero integer.\\
## Code: 
```
void setId(int id) throws EntityException{
		if(id <= 0)
			throw new EntityException("Work ID negative or zero");
		this.id = id;
	}
```