`EmployerDAO`: The function of `EmployerDAO` is to provide an interface for interacting with employer data stored in a database. It handles the retrieval, creation, update, and deletion of employer records, as well as caching the data in memory for improved performance.

**Code Description**:

1. **Caching**: The `EmployerDAO` class maintains a cache of `Employer` objects in a `HashMap`. This cache is used to improve the performance of retrieving employer data, as it avoids the need to query the database for every request.

2. **Retrieval**: The `findById` method retrieves an `Employer` object from the cache if it exists, or queries the database and adds the result to the cache if the cache is empty or caching is disabled.

3. **Listing**: The `list` method retrieves a list of all `Employer` objects from the database and adds them to the cache. If the cache is not empty and caching is enabled, the method returns the cached list instead of querying the database.

4. **Creation**: The `create` method inserts a new `Employer` record into the database and adds the new employer to the cache. It first checks if an employer with the same first and last name already exists in the cache using the `createControl` method.

5. **Update**: The `update` method updates an existing `Employer` record in the database and updates the corresponding entry in the cache. It first checks if an employer with the same first and last name already exists in the cache, excluding the current employer being updated, using the `updateControl` method.

6. **Deletion**: The `delete` method deletes an `Employer` record from the database and removes the corresponding entry from the cache.

7. **Cache Control**: The `isUsingCache` and `setUsingCache` methods provide a way to control whether the `EmployerDAO` class should use caching or not.

8. **Error Handling**: The `showEntityException` and `showSQLException` methods are used to display error messages in a JOptionPane dialog when an `EntityException` or `SQLException` occurs, respectively.

9. **Singleton Pattern**: The `EmployerDAOHelper` class is a utility class that provides a singleton instance of the `Employer\\
## Code: 
```
class EmployerDAO {
	
	private final HashMap<Integer, Employer> cache = new HashMap<>();
	private boolean usingCache = true;
	
	private EmployerDAO() {list();}

	public Employer findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
	}
	
	
	public List<Employer> list(){
		
		List<Employer> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Employer> employer : cache.entrySet()) {
				list.add(employer.getValue());
			}
			
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM employer;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			EmployerBuilder builder;
			Employer employer;
			
			while(rs.next()) {
				
				builder = new EmployerBuilder();
				builder.setId(rs.getInt("id"));
				builder.setFname(rs.getString("fname"));
				builder.setLname(rs.getString("lname"));
				
				if(rs.getArray("tel") == null)
					builder.setTel(null);
				else
					builder.setTel(Arrays.asList((String [])rs.getArray("tel").getArray()));
				
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					
					employer = builder.build();
					list.add(employer);
					cache.put(employer.getId(), employer);
					
				} catch (EntityException e) {
					showEntityException(e, rs.getString("fname") + " " + rs.getString("lname"));
				}
				
			}
			
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
	}
	
	
	public boolean create(Employer employer) {
		
		if(createControl(employer) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO employer (fname,lname,tel,description) VALUES (?,?,?,?);";
		String query2 = "SELECT * FROM employer ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1, employer.getFname());
			pst.setString(2, employer.getLname());
			
			if(employer.getTel() == null)
				pst.setArray(3, null);
			else {
				java.sql.Array phones = conn.createArrayOf("VARCHAR", employer.getTel().toArray());
				pst.setArray(3, phones);
			}
			
			pst.setString(4, employer.getDescription());
			result = pst.executeUpdate();
			
			// adding cache
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					EmployerBuilder builder = new EmployerBuilder();
					builder.setId(rs.getInt("id"));
					builder.setFname(rs.getString("fname"));
					builder.setLname(rs.getString("lname"));
					
					if(rs.getArray("tel") == null)
						builder.setTel(null);
					else
						builder.setTel(Arrays.asList((String [])rs.getArray("tel").getArray()));
					
					builder.setDescription(rs.getString("description"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						
						Employer emp = builder.build();
						cache.put(emp.getId(), emp);
						
					} catch (EntityException e) {
						showEntityException(e, rs.getString("fname") + " " + rs.getString("lname"));
					}
					
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
	
	private boolean createControl(Employer employer) {
		
		for(Entry<Integer, Employer> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(employer.getFname())
					&& obj.getValue().getLname().equals(employer.getLname())) {
				
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		
		return true;
	}
	
	
	public boolean update(Employer employer) {
		
		if(updateControl(employer) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE employer SET fname=?,"
				+ "lname=?, tel=?, description=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1, employer.getFname());
			pst.setString(2, employer.getLname());
			
			Array phones = conn.createArrayOf("VARCHAR", employer.getTel().toArray());
			pst.setArray(3, phones);
			
			pst.setString(4, employer.getDescription());
			pst.setInt(5, employer.getId());
			
			result = pst.executeUpdate();
			
			// update cache
			if(result != 0) {
				cache.put(employer.getId(), employer);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
	
	private boolean updateControl(Employer employer) {
		for(Entry<Integer, Employer> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(employer.getFname()) 
					&& obj.getValue().getLname().equals(employer.getLname()) 
					&& obj.getValue().getId() != employer.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
	
	public boolean delete(Employer employer) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM employer WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, employer.getId());
			result = ps.executeUpdate();
			
			if(result != 0) {
				cache.remove(employer.getId());
			}

			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
		
	}
	
	
	public boolean isUsingCache() {
		return this.usingCache;
	}
	
	public void setUsingCache(boolean usingCache) {
		this.usingCache = usingCache;
	}
	
	private static class EmployerDAOHelper{
		private static final EmployerDAO instance = new EmployerDAO();
	}
	
	public static EmployerDAO getInstance() {
		return EmployerDAOHelper.instance;
	}
	
	private void showEntityException(EntityException e, String msg) {
		String message = msg + " not added" + 
				"\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + e.getCause();
			JOptionPane.showMessageDialog(null, message);
	}
	
	private void showSQLException(SQLException e) {
		String message = e.getErrorCode() + "\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + "\n" + e.getCause();
		JOptionPane.showMessageDialog(null, message);
	}
	
}
```