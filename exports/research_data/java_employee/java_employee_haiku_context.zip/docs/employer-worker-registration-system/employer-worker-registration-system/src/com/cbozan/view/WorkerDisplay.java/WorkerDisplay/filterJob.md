`filterJob`: The function of `filterJob` is to filter a list of `Work` objects based on the selected job in the work table.

**Parameters**:
`List<Work> workList`: This parameter represents the list of `Work` objects that need to be filtered.

**Code Description**:
The `filterJob` method first checks if the `selectedWorkTableJob` variable is `null`. If it is, the method simply returns without performing any filtering.

If `selectedWorkTableJob` is not `null`, the method creates an `Iterator` to iterate through the `workList`. For each `Work` object in the list, the method checks if the `id` of the `Job` associated with the `Work` object is different from the `id` of the `selectedWorkTableJob`. If the `ids` are different, the method removes the `Work` object from the list using the `Iterator`'s `remove()` method.

This effectively filters the `workList` to only include `Work` objects that have a `Job` with an `id` matching the `id` of the `selectedWorkTableJob`.\\
## Code: 
```
void filterJob(List<Work> workList) {
		if(selectedWorkTableJob == null) {
			return;
		}
		
		Iterator<Work> work = workList.iterator();
		Work workItem;
		while(work.hasNext()) {
			workItem = work.next();
			if(workItem.getJob().getId() != selectedWorkTableJob.getId()) {
				work.remove();
			}
		}
		
	}
```