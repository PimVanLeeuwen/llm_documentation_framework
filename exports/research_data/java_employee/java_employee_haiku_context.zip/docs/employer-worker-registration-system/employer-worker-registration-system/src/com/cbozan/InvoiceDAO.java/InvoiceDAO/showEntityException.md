`showEntityException`: The function of `showEntityException` is to display an error message to the user when an `EntityException` occurs.

**Parameters**:
`EntityException e`: This parameter represents the `EntityException` object that was thrown, containing information about the error that occurred.
`String msg`: This parameter represents a message that provides context about the error, such as what operation was being performed when the exception was thrown.

**Code Description**: The `showEntityException` method takes an `EntityException` object and a message string as input parameters. It then constructs a detailed error message by concatenating the provided message, the exception message, the localized exception message, and the exception cause. This error message is then displayed to the user using a `JOptionPane.showMessageDialog` call, which will present a pop-up window with the error information.

The purpose of this method is to provide a user-friendly way to handle and display exceptions that occur during the application's execution, making it easier for users to understand what went wrong and potentially take appropriate action.\\
## Code: 
```
void showEntityException(EntityException e, String msg) {
		String message = msg + " not added" + 
				"\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + e.getCause();
			JOptionPane.showMessageDialog(null, message);
	}
```