`findById`: The function of `findById` is to retrieve a `Work` object from a cache or, if the cache is empty, from a database based on the provided `id` parameter.

**Parameters**:
`int id`: The unique identifier of the `Work` object to be retrieved.

**Code Description**:
The `findById` method first checks if the `usingCache` flag is set to `false`. If it is, the method calls the `list()` method to populate the cache with all available `Work` objects.

Next, the method checks if the cache (`cache`) contains a `Work` object with the provided `id`. If the cache contains the object, the method returns the cached object.

If the cache does not contain the object with the provided `id`, the method returns `null`, indicating that the object was not found.

This implementation allows for efficient retrieval of `Work` objects by first checking the in-memory cache before querying the database. This can improve performance, especially if the same `Work` objects are accessed multiple times.\\
## Code: 
```
Work findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```