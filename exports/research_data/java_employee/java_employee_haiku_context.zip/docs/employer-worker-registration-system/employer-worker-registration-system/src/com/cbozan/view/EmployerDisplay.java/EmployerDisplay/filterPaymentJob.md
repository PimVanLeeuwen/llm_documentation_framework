`filterPaymentJob`: The function of `filterPaymentJob` is to filter a list of `Invoice` objects based on the selected job.

**Parameters**:
`List<Invoice> invoiceList`: This parameter represents a list of `Invoice` objects that need to be filtered.

**Code Description**:
The `filterPaymentJob` method first checks if a `selectedJob` variable is not null. If it is null, the method simply returns without performing any filtering.

If `selectedJob` is not null, the method creates an iterator for the `invoiceList` and iterates through each `Invoice` object in the list. For each `Invoice` object, the method checks if the job ID of the `Invoice` object is different from the job ID of the `selectedJob`. If the job IDs do not match, the method removes the `Invoice` object from the list using the iterator's `remove()` method.

This filtering process ensures that only the `Invoice` objects associated with the `selectedJob` are left in the `invoiceList` after the method has finished executing.\\
## Code: 
```
void filterPaymentJob(List<Invoice> invoiceList) {
		
		if(selectedJob == null)
			return;
		
		Iterator<Invoice> invoice = invoiceList.iterator();
		Invoice invoiceItem;
		while(invoice.hasNext()) {
			invoiceItem = invoice.next();
			if(invoiceItem.getJob().getId() != selectedJob.getId()) {
				invoice.remove();
			}
		}
		
	}
```