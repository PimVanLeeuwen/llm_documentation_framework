`setAmount`: The function of `setAmount` is to set the amount of an invoice.

**Parameters**:
`BigDecimal amount`: This parameter represents the amount to be set for the invoice. It is a `BigDecimal` object, which is a class in Java that provides support for arbitrary-precision decimal numbers.

**Code Description**:
The `setAmount` method takes a `BigDecimal` object as a parameter, which represents the amount to be set for the invoice. The method first checks if the provided `amount` is less than or equal to 0.00. If the condition is true, it throws an `EntityException` with the message "Invoice amount negative or zero". This is to ensure that the invoice amount cannot be set to a negative or zero value.

If the `amount` is greater than 0.00, the method sets the `amount` field of the `Invoice` object to the provided `amount` value.

The purpose of this method is to maintain the integrity of the invoice data by enforcing a business rule that the invoice amount cannot be negative or zero. This helps to ensure that the invoice information is accurate and consistent.\\
## Code: 
```
void setAmount(BigDecimal amount) throws EntityException {
		if(amount.compareTo(new BigDecimal("0.00")) <= 0)
			throw new EntityException("Invoice amount negative or zero");
		this.amount = amount;
	}
```