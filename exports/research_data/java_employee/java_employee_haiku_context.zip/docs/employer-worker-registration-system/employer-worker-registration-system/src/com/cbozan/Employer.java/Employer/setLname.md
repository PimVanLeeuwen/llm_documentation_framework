`setLname`: The function of `setLname` is to set the last name of an Employer object.

**Parameters**:
`String lname`: This parameter represents the new last name to be set for the Employer object.

**Code Description**:
The `setLname` method takes a `String` parameter `lname` and sets the `lname` field of the Employer object to the provided value. However, before setting the new last name, the method performs a validation check on the input.

The method first checks if the length of the `lname` string is either 0 (empty) or greater than the constant `DBConst.LNAME_LENGTH`. If either of these conditions is true, the method throws an `EntityException` with the message "Employer last name empty or too long". This exception is likely used to handle invalid input and provide meaningful error messages to the caller.

If the `lname` string passes the validation check, the method sets the `lname` field of the Employer object to the provided value.\\
## Code: 
```
void setLname(String lname) throws EntityException {
		if(lname.length() == 0 || lname.length() > DBConst.LNAME_LENGTH)
			throw new EntityException("Employer last name empty or too long");
		this.lname = lname;
	}
```