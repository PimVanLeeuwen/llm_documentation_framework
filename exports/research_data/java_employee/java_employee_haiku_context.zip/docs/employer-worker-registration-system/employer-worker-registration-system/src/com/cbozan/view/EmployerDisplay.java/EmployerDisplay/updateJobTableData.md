`updateJobTableData`: The function of `updateJobTableData` is to update the data displayed in a job table based on the selected employer.

**Code Description**:

The `updateJobTableData` method is responsible for updating the data displayed in a job table. It performs the following steps:

1. Checks if a `selectedEmployer` is not null. This indicates that an employer has been selected.

2. Retrieves a list of `Job` objects associated with the `selectedEmployer` using the `JobDAO.getInstance().list(selectedEmployer)` method.

3. Creates a 2D array of strings called `tableData` with a size based on the number of jobs in the `jobList`.

4. Iterates through the `jobList` and populates the `tableData` array with the relevant information for each job, including the job ID, employer, title, and description.

5. Sets the `tableData` and `jobTableColumns` (an array of column names) as the model for the job table component inside the `jobScrollPane`.

6. Adjusts the column widths and resizing behavior of the job table:
   - Sets the preferred width of the first column (job ID) to 5.
   - Sets the auto-resize mode of the table to resize the last column.
   - Centers the alignment of the values in the first column using a `DefaultTableCellRenderer`.

7. Updates the `jobCountLabel` to display the number of job records.

The purpose of this method is to ensure that the job table displays the correct data based on the selected employer. It retrieves the relevant job information, formats it into a tabular format, and updates the table's model and appearance accordingly.\\
## Code: 
```
void updateJobTableData() {
		
		if(selectedEmployer != null) {
			
			List<Job> jobList = JobDAO.getInstance().list(selectedEmployer);
			
			String[][] tableData = new String[jobList.size()][jobTableColumns.length];
			
			int i = 0;
			for(Job j : jobList) {
				
				tableData[i][0] = j.getId() + "";
				tableData[i][1] = j.getEmployer().toString();
				tableData[i][2] = j.getTitle();
				tableData[i][3] = j.getDescription();
				++i;
			}
			
			((JTable)jobScrollPane.getViewport().getComponent(0)).setModel(new DefaultTableModel(tableData, jobTableColumns));
			((JTable)jobScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setPreferredWidth(5);
			((JTable)jobScrollPane.getViewport().getComponent(0)).setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
			
			DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
			centerRenderer.setHorizontalAlignment( SwingConstants.CENTER );
			((JTable)jobScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
			
			jobCountLabel.setText(jobList.size() + " Kayıt");
		}
		
	}
```