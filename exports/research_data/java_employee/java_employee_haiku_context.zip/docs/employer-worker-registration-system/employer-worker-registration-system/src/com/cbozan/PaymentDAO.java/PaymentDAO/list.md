`list`: The function of `list` is to retrieve a list of `Payment` objects from a database based on the provided column names and their corresponding IDs.

**Parameters**:
`String[] columnName`: This parameter is an array of column names that will be used to filter the results from the database.
`int[] id`: This parameter is an array of IDs that correspond to the column names in the `columnName` array. The function will retrieve records where the column values match the provided IDs.

**Code Description**:
The `list` method first checks if the `columnName` and `id` arrays have the same length. If not, it returns an empty `List<Payment>`.

Next, the method constructs a SQL query to select all rows from the `payment` table where the column values match the provided IDs. The query is built by iterating over the `columnName` and `id` arrays and appending the conditions to the `WHERE` clause of the query.

The method then establishes a connection to the database using the `DB.getConnection()` method, creates a `Statement` object, and executes the query using `st.executeQuery(query)`. The resulting `ResultSet` is then processed, and for each row, a `PaymentBuilder` is used to create a `Payment` object. The `Payment` objects are added to the `list` and returned.

If any exceptions occur during the process, such as SQL exceptions or `EntityException` (which is likely a custom exception related to the `Payment` entity), the method will print the error messages to the console but continue to return the list of `Payment` objects that were successfully created.\\
## Code: 
```
List<Payment> list(String[] columnName, int[] id){
		
		List<Payment> list = new ArrayList<>();
		if(columnName.length != id.length)
			return list;
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM payment WHERE ";
		
		for(int i = 0; i < columnName.length; i++) {
			query += columnName[i] + "=" + id[i] + " AND ";
		}
		
		query = query.substring(0, query.length() - (" AND ".length()));
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			PaymentBuilder builder;
			Payment payment;
			
			while(rs.next()) {
				
				builder = new PaymentBuilder();
				builder.setId(rs.getInt("id"));
				builder.setWorker_id(rs.getInt("worker_id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setPaytype_id(rs.getInt("paytype_id"));
				builder.setAmount(rs.getBigDecimal("amount"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					payment = builder.build();
					list.add(payment);
				} catch (EntityException e) {
					System.err.println(e.getMessage());
					System.out.println("!! Payment not added list !!");
				}
				
			}
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return list;
	}
```