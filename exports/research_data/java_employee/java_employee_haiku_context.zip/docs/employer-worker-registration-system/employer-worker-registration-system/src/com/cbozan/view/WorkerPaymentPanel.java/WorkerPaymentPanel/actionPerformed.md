`actionPerformed`: The function of `actionPerformed` is to handle the user's action when the "Pay" button is clicked in the "Worker Payment Panel" of the application.

**Parameters**:
`ActionEvent e`: This parameter represents the action event that triggered the `actionPerformed` method, such as the user clicking the "Pay" button.

**Code Description**:
The `actionPerformed` method performs the following tasks:

1. It retrieves the selected worker, job, and payment type from the corresponding UI components.
2. It checks if the entered payment amount is in the correct decimal format (using the `decimalControl` method) and if the required fields (worker, job, and payment type) are selected.
3. If any of the required fields are missing or the payment amount is not in the correct format, it displays an error message to the user using a `JOptionPane`.
4. If all the required fields are filled correctly, it creates a confirmation dialog box that displays the details of the payment, including the worker, job, payment method, and payment amount.
5. If the user confirms the payment by clicking the "SAVE" button in the confirmation dialog, it creates a new `Payment` object using the `Payment.PaymentBuilder` and saves it to the database using the `PaymentDAO.create` method.
6. If the payment is successfully saved, it notifies all observers of the `WorkerPaymentPanel` class using the `notifyAllObservers` method.
7. If there is an error saving the payment, it displays an error message to the user using a `JOptionPane`.

Overall, the `actionPerformed` method is responsible for handling the user's payment submission, validating the input, displaying a confirmation dialog, and saving the payment to the database if the user confirms the transaction.\\
## Code: 
```
void actionPerformed(ActionEvent e) {
		if(e.getSource() == payButton) {
			
			Worker worker;
			Job job;
			Paytype paytype;
			String amount;
			
			worker = selectedWorker;
			job = selectedJob;
			paytype = (Paytype) paytypeComboBox.getSelectedItem();
			amount = amountTextField.getText().replaceAll("\\s+", "");

			if(!decimalControl(amount) || worker == null || job == null || paytype == null) {
				
				String message;
				message = "Please enter selection parts or format correctly (max 2 floating point)";
				JOptionPane.showMessageDialog(this, message, "ERROR", JOptionPane.ERROR_MESSAGE);
				
			} else {
				
				JTextArea workerTextArea, jobTextArea, paytypeTextArea, amountTextArea;
				
				workerTextArea = new JTextArea(worker.toString());
				workerTextArea.setEditable(false);
				
				jobTextArea = new JTextArea(job.toString());
				jobTextArea.setEditable(false);
				
				paytypeTextArea = new JTextArea(paytype.toString());
				paytypeTextArea.setEditable(false);
				
				amountTextArea = new JTextArea(amount + " ₺");
				amountTextArea.setEditable(false);
				
				Object[] pane = {
						new JLabel("Worker"),
						workerTextArea,
						new JLabel("Job"),
						jobTextArea,
						new JLabel("Payment method"),
						paytypeTextArea,
						new JLabel("Amount of payment"),
						amountTextArea
				};
		
				int result = JOptionPane.showOptionDialog(this, pane, "Confirmation", 1, 1, 
						new ImageIcon("src\\icon\\accounting_icon_1_32.png"), new Object[] {"SAVE", "CANCEL"}, "CANCEL");
				
				
				// System.out.println(result);
				// 0 -> SAVE
				// 1 -> CANCEL
				
				if(result == 0) {
					
					Payment.PaymentBuilder builder = new Payment.PaymentBuilder();
					builder.setId(Integer.MAX_VALUE);
					builder.setWorker(worker);
					builder.setJob(job);
					builder.setPaytype(paytype);
					builder.setAmount(new BigDecimal(amount));
					
					Payment payment = null;
					try {
						payment = builder.build();
					} catch (EntityException e1) {
						System.out.println(e1.getMessage());
					}
					
					if(PaymentDAO.getInstance().create(payment)) { 
						JOptionPane.showMessageDialog(this, "Registraion successful");
						notifyAllObservers();
					} else {
						JOptionPane.showMessageDialog(this, "Not saved", "Database error", JOptionPane.ERROR_MESSAGE);
					}
				}
				
			}
			
			
		}
		
	}
```