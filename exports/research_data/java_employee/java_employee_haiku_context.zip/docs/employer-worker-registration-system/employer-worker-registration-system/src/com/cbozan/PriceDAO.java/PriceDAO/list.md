`list`: The function of `list` is to retrieve a list of `Price` objects from a database and cache them in memory.

**Code Description**:

1. The method first checks if there are any `Price` objects cached in the `cache` map and if the `usingCache` flag is set to `true`. If so, it iterates over the `cache` map and adds all the `Price` objects to a new `List` object, which is then returned.

2. If the `cache` is empty or the `usingCache` flag is set to `false`, the method clears the `cache` map and proceeds to fetch the `Price` objects from the database.

3. The method establishes a connection to the database using the `DB.getConnection()` method, and then executes a SQL query to retrieve all the `Price` objects from the `price` table.

4. For each row returned by the SQL query, the method creates a `PriceBuilder` object, sets the various properties of the `Price` object (such as `id`, `fulltime`, `halftime`, `overtime`, and `date`), and then builds the `Price` object using the `build()` method of the `PriceBuilder`.

5. The built `Price` object is then added to the `List` object, and also stored in the `cache` map using the `id` of the `Price` object as the key.

6. If any `EntityException` is thrown during the process of building the `Price` object, the method calls the `showEntityException()` method to display an error message.

7. Finally, the method returns the `List` of `Price` objects.

Overall, the `list()` method is responsible for fetching and caching `Price` objects from a database, and providing a way to retrieve these objects as a `List`.\\
## Code: 
```
List<Price> list(){
		
		List<Price> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Price> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM price;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			PriceBuilder builder;
			Price price;
			
			while(rs.next()) {
				
				builder = new PriceBuilder();
				builder.setId(rs.getInt("id"));
				builder.setFulltime(rs.getBigDecimal("fulltime"));
				builder.setHalftime(rs.getBigDecimal("halftime"));
				builder.setOvertime(rs.getBigDecimal("overtime"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					price = builder.build();
					list.add(price);
					cache.put(price.getId(), price);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
		
	}
```