`create`: The function of `create` is to insert a new price record into the database.

**Parameters**:
`Price price`: This parameter represents the price information to be inserted into the database. It contains the fulltime, halftime, and overtime pay rates.

**Code Description**:
The `create` method first checks if the price information already exists in a cache using the `createControl` method. If the price information already exists, the method returns `false` to indicate that the record cannot be created.

If the price information does not exist, the method proceeds to insert the new record into the database. It constructs an SQL `INSERT` query with placeholders for the fulltime, halftime, and overtime values. The method then sets the corresponding values from the `Price` object using the `setBigDecimal` method and executes the query.

After the insert operation, the method retrieves the newly inserted record from the database using an SQL `SELECT` query. It then creates a `PriceBuilder` object, sets the retrieved values (id, fulltime, halftime, overtime, and date), and builds a new `Price` object. This new `Price` object is then added to a cache using the `cache.put` method.

Finally, the method returns `true` if the insert operation was successful, and `false` otherwise.\\
## Code: 
```
boolean create(Price price) {
		
		if(createControl(price) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO price (fulltime,halftime,overtime) VALUES (?,?,?);";
		String query2 = "SELECT * FROM price ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			
			pst.setBigDecimal(1, price.getFulltime());
			pst.setBigDecimal(2, price.getHalftime());
			pst.setBigDecimal(3, price.getOvertime());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					PriceBuilder builder = new PriceBuilder();
					builder.setId(rs.getInt("id"));
					builder.setFulltime(rs.getBigDecimal("fulltime"));
					builder.setHalftime(rs.getBigDecimal("halftime"));
					builder.setOvertime(rs.getBigDecimal("overtime"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Price prc = builder.build();
						cache.put(prc.getId(), prc);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id"));
					}
					
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```