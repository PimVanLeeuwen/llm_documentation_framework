`toString`: The function of `toString` is to provide a string representation of the object.

**Code Description**: The `toString()` method in the `Price` class returns a string that represents the object's state. The string is formatted as follows:

```
"(fulltime)  (halftime)  (overtime)"
```

Where:
- `fulltime` is the value returned by the `getFulltime()` method
- `halftime` is the value returned by the `getHalftime()` method
- `overtime` is the value returned by the `getOvertime()` method

This string representation can be useful for debugging, logging, or displaying the object's information in a user interface.

The `toString()` method is a common practice in Java to provide a human-readable representation of an object, which can be helpful when working with the object in various contexts.\\
## Code: 
```
String toString() {
		return "(" + getFulltime() + ")  " + "(" + getHalftime() + ")  " + "(" + getOvertime() + ")";
	}
```