`create`: The function of `create` is to insert a new invoice record into the database and retrieve the newly created invoice object.

**Parameters**:
`Invoice invoice`: This parameter represents the invoice object that contains the job ID and the amount to be inserted into the database.

**Code Description**:
The `create` method first establishes a connection to the database using the `DB.getConnection()` method. It then prepares an SQL query to insert the invoice data into the `invoice` table, setting the `job_id` and `amount` columns with the values from the `invoice` object.

The method then executes the insert query using the `pst.executeUpdate()` method, which returns the number of rows affected. If the insert is successful (i.e., the result is not 0), the method proceeds to retrieve the newly created invoice record from the database.

To retrieve the newly created invoice, the method executes another SQL query to select the last inserted record from the `invoice` table, ordered by the `id` column in descending order and limiting the result to 1 row. The method then creates an `InvoiceBuilder` object and sets the retrieved values (ID, job ID, amount, and date) on the builder. Finally, the method builds the `Invoice` object from the builder and stores it in a cache.

If any exceptions occur during the process, the method calls the `showSQLException` method to display the error message to the user.

The method returns `true` if the insert operation was successful, and `false` otherwise.\\
## Code: 
```
boolean create(Invoice invoice) {
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO invoice (job_id,amount) VALUES (?,?);";
		String query2 = "SELECT * FROM invoice ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, invoice.getJob().getId());
			pst.setBigDecimal(2, invoice.getAmount());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					InvoiceBuilder builder = new InvoiceBuilder();
					builder.setId(rs.getInt("id"));
					builder.setJob_id(rs.getInt("job_id"));
					builder.setAmount(rs.getBigDecimal("amount"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Invoice inv = builder.build();
						cache.put(inv.getId(), inv);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id"));
					}
					
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```