`DBConst`: The function of `DBConst` is to define constant values related to the database schema.

**Code Description**: The `DBConst` class defines two constant integer values:

1. `FNAME_LENGTH`: This constant represents the maximum length of the first name field in the database. It is set to 30 characters.

2. `LNAME_LENGTH`: This constant represents the maximum length of the last name field in the database. It is set to 20 characters.

These constants are likely used throughout the application to ensure that the data entered for first and last names adheres to the defined database schema. By using these constants, the application can enforce data validation and consistency, preventing the storage of names that exceed the maximum allowed lengths.

The purpose of this class is to centralize and manage the database-related constants, making it easier to update or reference these values across the application. This approach promotes maintainability and consistency, as changes to the database schema can be easily reflected in the `DBConst` class without having to update the values in multiple places throughout the codebase.\\
## Code: 
```
class DBConst {
	public static final int FNAME_LENGTH = 30;
	public static final int LNAME_LENGTH = 20;
}
```