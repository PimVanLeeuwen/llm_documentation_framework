`WorkerDAO`: The function of `WorkerDAO` is to provide an interface for interacting with a database table of worker records.

**Code Description**:

1. The `WorkerDAO` class is responsible for managing the CRUD (Create, Read, Update, Delete) operations for `Worker` objects in a database.

2. The class maintains a cache of `Worker` objects in a `HashMap` called `cache`. The `usingCache` flag determines whether the cache is used or if the data is fetched directly from the database.

3. The `findById` method retrieves a `Worker` object from the cache by its ID. If the cache is empty or the `usingCache` flag is set to `false`, it calls the `list` method to populate the cache before searching for the object.

4. The `refresh` method sets the `usingCache` flag to `false`, calls the `list` method to fetch the latest data from the database, and then sets the `usingCache` flag back to `true`.

5. The `list` method retrieves all `Worker` objects from the database and stores them in the `cache`. If the cache is not empty and the `usingCache` flag is set, it returns the cached list instead of querying the database.

6. The `create` method inserts a new `Worker` object into the database. It first checks if a worker with the same first and last name already exists in the cache using the `createControl` method. If the worker does not exist, it inserts the new record and adds the new `Worker` object to the cache.

7. The `update` method updates an existing `Worker` object in the database. It first checks if a worker with the same first and last name already exists in the cache, excluding the current worker being updated, using the `updateControl` method. If the worker does not exist, it updates the record and updates the cache.

8. The `delete` method removes a `Worker` object from the database and the cache.

9. The `WorkerDAOHelper` class is a singleton that provides a single instance of the `WorkerDAO` class.

10. The `isUsingCache` and `setUsingCache` methods allow for controlling the usage of the cache.

11. The `showEntityException` and `showS\\
## Code: 
```
class WorkerDAO {
	
	private final HashMap<Integer, Worker> cache = new HashMap<>();
	private boolean usingCache = true;
	
	private WorkerDAO() {list();}
	
	// Read by id
	public Worker findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
	
	public void refresh() {
		setUsingCache(false);
		list();
		setUsingCache(true);
	}
	
	
	//Read All
	public List<Worker> list(){
		
		List<Worker> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Worker> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM worker;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorkerBuilder builder;
			Worker worker;
			
			while(rs.next()) {
				
				builder = new WorkerBuilder();
				builder.setId(rs.getInt("id"));
				builder.setFname(rs.getString("fname"));
				builder.setLname(rs.getString("lname"));
				
				if(rs.getArray("tel") == null)
					builder.setTel(null);
				else
					builder.setTel(Arrays.asList((String [])rs.getArray("tel").getArray()));
				
				builder.setIban(rs.getString("iban"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					worker = builder.build();
					list.add(worker);
					cache.put(worker.getId(), worker);
				} catch (EntityException e) {
					showEntityException(e, rs.getString("fname") + " " + rs.getShort("lname"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
		
	}
	
	
	public boolean create(Worker worker) {
		
		if(createControl(worker) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO worker (fname,lname,tel,iban,description) VALUES (?,?,?,?,?);";
		String query2 = "SELECT * FROM worker ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1, worker.getFname());
			pst.setString(2, worker.getLname());
			
			if(worker.getTel() == null)
				pst.setArray(3, null);
			else {
				java.sql.Array phones = conn.createArrayOf("VARCHAR", worker.getTel().toArray());
				pst.setArray(3, phones);
			}
			
			pst.setString(4, worker.getIban());
			pst.setString(5, worker.getDescription());
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					WorkerBuilder builder = new WorkerBuilder();
					builder = new WorkerBuilder();
					builder.setId(rs.getInt("id"));
					builder.setFname(rs.getString("fname"));
					builder.setLname(rs.getString("lname"));
					
					if(rs.getArray("tel") == null)
						builder.setTel(null);
					else
						builder.setTel(Arrays.asList((String [])rs.getArray("tel").getArray()));
					
					builder.setIban(rs.getString("iban"));
					builder.setDescription(rs.getString("description"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Worker wor = builder.build();
						cache.put(wor.getId(), wor);
					} catch (EntityException e) {
						showEntityException(e, rs.getString("fname") + " " + rs.getShort("lname"));
					}
					
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
	
	private boolean createControl(Worker worker) {
		for(Entry<Integer, Worker> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(worker.getFname()) && obj.getValue().getLname().equals(worker.getLname())) {
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
	
	public boolean update(Worker worker) {
		if(updateControl(worker) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE worker SET fname=?,"
				+ "lname=?, tel=?, iban=?, description=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1, worker.getFname());
			pst.setString(2, worker.getLname());
			
			java.sql.Array phones = conn.createArrayOf("VARCHAR", worker.getTel().toArray());
			pst.setArray(3, phones);
			
			pst.setString(4, worker.getIban());
			pst.setString(5, worker.getDescription());
			pst.setInt(6, worker.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(worker.getId(), worker);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
	
	private boolean updateControl(Worker worker) {
		for(Entry<Integer, Worker> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(worker.getFname()) 
					&& obj.getValue().getLname().equals(worker.getLname())
					&& obj.getValue().getId() != worker.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
	
	public boolean delete(Worker worker) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM worker WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, worker.getId());
			result = ps.executeUpdate();
			
			if(result != 0) {
				cache.remove(worker.getId());
			}
			
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
		
	}
	
	
	
	private static class WorkerDAOHelper {
		private static final WorkerDAO instance = new WorkerDAO();
	}
	
	public static WorkerDAO getInstance() {
		return WorkerDAOHelper.instance;
	}

	public boolean isUsingCache() {
		return usingCache;
	}

	public void setUsingCache(boolean usingCache) {
		this.usingCache = usingCache;
	}
	
	private void showEntityException(EntityException e, String msg) {
		String message = msg + " not added" + 
				"\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + e.getCause();
			JOptionPane.showMessageDialog(null, message);
	}
	
	private void showSQLException(SQLException e) {
		String message = e.getErrorCode() + "\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + "\n" + e.getCause();
		JOptionPane.showMessageDialog(null, message);
	}
}
```