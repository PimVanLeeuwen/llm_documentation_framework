`setPrice_id`: The function of `setPrice_id` is to set the `price_id` property of the `JobBuilder` object and return the `JobBuilder` object itself.

**Parameters**:
`int price_id`: This parameter represents the new value to be assigned to the `price_id` property of the `JobBuilder` object.

**Code Description**: The `setPrice_id` method takes an `int` parameter `price_id` and assigns it to the `price_id` property of the `JobBuilder` object. After setting the `price_id` property, the method returns the `JobBuilder` object itself, allowing for method chaining. This is a common pattern in builder-style object creation, where multiple setter methods can be called in succession to configure the object before building it.\\
## Code: 
```
JobBuilder setPrice_id(int price_id) {
			this.price_id = price_id;
			return this;
		}
```