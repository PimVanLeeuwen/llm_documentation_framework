`build`: The function of `build` is to create and return a new `Price` object.

**Code Description**: The `build()` method is part of the `PriceBuilder` class, which is likely used to construct `Price` objects in a more structured and controlled way. The `build()` method is responsible for creating and returning a new `Price` object.

The implementation of the `build()` method is very simple - it creates a new `Price` object by calling the constructor of the `Price` class, passing in the current instance of the `PriceBuilder` object as the argument. This allows the `Price` class to access and use the data that has been set on the `PriceBuilder` object to initialize the new `Price` object.

The `build()` method also includes a `throws EntityException` declaration, which suggests that the creation of the `Price` object may potentially throw an `EntityException` if there is an issue during the construction process. This exception handling mechanism ensures that any errors that occur during the creation of the `Price` object can be properly handled and communicated to the calling code.

Overall, the `build()` method provides a convenient way to create `Price` objects by encapsulating the construction logic within the `PriceBuilder` class, making it easier to ensure the consistency and validity of the `Price` objects being created.\\
## Code: 
```
Price build() throws EntityException{
			return new Price(this);
		}
```