`findById`: The function of `findById` is to retrieve a `Workgroup` object from a cache or, if the cache is not available, from a database based on the provided `id` parameter.

**Parameters**:
`int id`: The unique identifier of the `Workgroup` object to be retrieved.

**Code Description**:
The `findById` method first checks if the cache is being used (`usingCache` flag). If the cache is not being used, it calls the `list()` method to populate the cache. Then, it checks if the cache contains the `Workgroup` object with the given `id`. If the object is found in the cache, it returns the cached object. If the object is not found in the cache, it returns `null`.

This method is designed to provide efficient retrieval of `Workgroup` objects by first checking the in-memory cache before querying the database. This can improve performance, especially if the same `Workgroup` objects are accessed multiple times. The method also ensures that the cache is populated before attempting to retrieve an object from it, to handle cases where the cache may be empty.\\
## Code: 
```
Workgroup findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```