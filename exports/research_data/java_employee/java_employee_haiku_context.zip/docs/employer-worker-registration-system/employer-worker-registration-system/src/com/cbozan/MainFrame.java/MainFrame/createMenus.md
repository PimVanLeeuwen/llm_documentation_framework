`createMenus`: The function of `createMenus` is to create and set up the menu bar and its associated menus and menu items for the application.

**Code Description**:
The `createMenus()` method is responsible for creating the main menu bar and its submenus for the application. It performs the following tasks:

1. Creates a new `JMenuBar` object and assigns it to the `menuBar` variable.

2. Creates three main menus: "Record", "Add", and "Display", and assigns them to the `newRecordMenu`, `addMenu`, and `displayMenu` variables, respectively.

3. Adds the following menu items to the "Record" menu:
   - "New Job"
   - "New worker"
   - "New employer"
   - "New price"
   Each menu item is associated with an action command (0, 1, 2, or 3) and an `ActionListener` that will handle the corresponding user action.

4. Adds the following menu items to the "Add" menu:
   - "Worker payment"
   - "Work"
   - "Job payment"
   Each menu item is associated with an action command (4, 5, or 6) and an `ActionListener` that will handle the corresponding user action.

5. Adds the following menu items to the "Display" menu:
   - "Display job"
   - "Display worker"
   - "Display employer"
   Each menu item is associated with an action command (7, 8, or 9) and an `ActionListener` that will handle the corresponding user action.

6. Adds the three main menus to the `menuBar`.

7. Sets the `menuBar` as the menu bar for the application using the `setJMenuBar()` method.

The purpose of this code is to create a user interface with a menu bar that provides access to various functionalities of the application, such as creating new records, adding new data, and displaying existing data. The menu items are associated with action commands and `ActionListener`s, which will be used to handle the corresponding user actions when the menu items are selected.\\
## Code: 
```
void createMenus() {
		
		menuBar = new JMenuBar();
		
		newRecordMenu = new JMenu("Record");
		addMenu = new JMenu("Add");
		displayMenu = new JMenu("Display");
		
		
		newJobItem = new JMenuItem("New Job");
		newJobItem.setActionCommand("0");
		newJobItem.addActionListener(this);
		
		newWorkerItem = new JMenuItem("New worker");
		newWorkerItem.setActionCommand("1");
		newWorkerItem.addActionListener(this);
		
		newEmployerItem = new JMenuItem("New employer");
		newEmployerItem.setActionCommand("2");
		newEmployerItem.addActionListener(this);
		
		newPriceItem = new JMenuItem("New price");
		newPriceItem.setActionCommand("3");
		newPriceItem.addActionListener(this);
		
		newRecordMenu.add(newJobItem);
		newRecordMenu.add(newWorkerItem);
		newRecordMenu.add(newEmployerItem);
		newRecordMenu.add(newPriceItem);
		
		
		newWorkerPaymentItem = new JMenuItem("Worker payment");
		newWorkerPaymentItem.setActionCommand("4");
		newWorkerPaymentItem.addActionListener(this);
		
		newWorkItem = new JMenuItem("Work");
		newWorkItem.setActionCommand("5");
		newWorkItem.addActionListener(this);
		
		newEmployerPaymentItem = new JMenuItem("Job payment");
		newEmployerPaymentItem.setActionCommand("6");
		newEmployerPaymentItem.addActionListener(this);
		
		addMenu.add(newWorkerPaymentItem);
		addMenu.add(newWorkItem);
		addMenu.add(newEmployerPaymentItem);
		
		
		displayJobItem = new JMenuItem("Display job");
		displayJobItem.setActionCommand("7");
		displayJobItem.addActionListener(this);
		
		displayWorkerItem = new JMenuItem("Display worker");
		displayWorkerItem.setActionCommand("8");
		displayWorkerItem.addActionListener(this);
		
		displayEmployerItem = new JMenuItem("Display employer");
		displayEmployerItem.setActionCommand("9");
		displayEmployerItem.addActionListener(this);
		
		
		displayMenu.add(displayJobItem);
		displayMenu.add(displayWorkerItem);
		displayMenu.add(displayEmployerItem);
		
		menuBar.add(newRecordMenu);
		menuBar.add(addMenu);
		menuBar.add(displayMenu);
		
		
		this.setJMenuBar(menuBar);
		
		
	}
```