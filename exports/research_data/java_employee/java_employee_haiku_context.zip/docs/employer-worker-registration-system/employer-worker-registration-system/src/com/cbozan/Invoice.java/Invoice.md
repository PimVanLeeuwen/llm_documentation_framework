`Invoice`: The function of `Invoice` is to represent an invoice object, which contains information about a job, the amount of the invoice, and the date of the invoice.

**Code Description**:

1. The `Invoice` class implements the `Serializable` interface, which allows the object to be serialized and deserialized for storage or transmission purposes.

2. The class has several private fields: `id` (an integer representing the unique identifier of the invoice), `job` (a `Job` object representing the job associated with the invoice), `amount` (a `BigDecimal` representing the amount of the invoice), and `date` (a `Timestamp` representing the date of the invoice).

3. The class has a private constructor that initializes the fields to default values (0 for `id`, `null` for `job`, `amount`, and `date`).

4. The class also has a private constructor that takes an `InvoiceBuilder` object as a parameter and initializes the fields based on the values in the builder.

5. The `InvoiceBuilder` class is a builder pattern implementation that allows for the creation of `Invoice` objects with different combinations of the fields. It provides methods to set the individual fields and a `build()` method to create the final `Invoice` instance.

6. The `EmptyInstanceSingleton` class is a private static inner class that creates a single instance of the `Invoice` class with the default field values. The `getEmptyInstance()` method provides a way to retrieve this singleton instance.

7. The `Invoice` class has various getter and setter methods for the individual fields, which perform input validation and throw `EntityException` exceptions if the input is invalid (e.g., negative or zero `id` or `amount`).

8. The class also overrides the `toString()`, `hashCode()`, and `equals()` methods to provide string representation, hash code, and equality comparison for `Invoice` objects, respectively.

Overall, the `Invoice` class provides a way to represent and manage invoice information, with a focus on input validation and the use of the builder pattern to simplify the creation of `Invoice` objects.\\
## Code: 
```
class Invoice implements Serializable {
	
	private static final long serialVersionUID = -7032103783419199929L;
	
	private int id;
	private Job job;
	private BigDecimal amount;
	private Timestamp date;
	
	private Invoice() {
		this.id = 0;
		this.job = null;
		this.amount = null;
		this.date = null;
	}
	
	private Invoice(Invoice.InvoiceBuilder builder) throws EntityException {
		this(builder.id,
				JobDAO.getInstance().findById(builder.job_id),
				builder.amount,
				builder.date);
	}
	
	private Invoice(int id, Job job, BigDecimal amount, Timestamp date) throws EntityException {
		setId(id);
		setJob(job);
		setAmount(amount);
		setDate(date);
	}
	
	
	public static class InvoiceBuilder{
		
		private int id;
		private int job_id;
		private Job job;
		private BigDecimal amount;
		private Timestamp date;
		
		public InvoiceBuilder() {}
		public InvoiceBuilder(int id, int job_id, BigDecimal amount, Timestamp date) {
			this.id = id;
			this.job_id = job_id;
			this.amount = amount;
			this.date = date;
		}
		
		public InvoiceBuilder(int id, Job job, BigDecimal amount, Timestamp date) {
			this(id, 0, amount, date);
			this.job = job;
		}
		
		public InvoiceBuilder setId(int id) {
			this.id = id;
			return this;
		}
		
		public InvoiceBuilder setJob_id(int job_id) {
			this.job_id = job_id;
			return this;
		}
		
		public InvoiceBuilder setJob(Job job) {
			this.job = job;
			return this;
		}
		
		public InvoiceBuilder setAmount(BigDecimal amount) {
			this.amount = amount;
			return this;
		}
		
		public InvoiceBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Invoice build() throws EntityException {
			if(job == null)
				return new Invoice(this);
			return new Invoice(id, job, amount, date);
		}
		
	}

	private static class EmptyInstanceSingleton{
		private static final Invoice instance = new Invoice(); 
	}
	
	public static final Invoice getEmptyInstance() {
		return EmptyInstanceSingleton.instance;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) throws EntityException {
		if(id <= 0)
			throw new EntityException("Invoice ID negative or zero");
		this.id = id;
	}

	public Job getJob() {
		return job;
	}

	public void setJob(Job job) throws EntityException {
		if(job == null)
			throw new EntityException("Job in Invoice is null");
		this.job = job;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) throws EntityException {
		if(amount.compareTo(new BigDecimal("0.00")) <= 0)
			throw new EntityException("Invoice amount negative or zero");
		this.amount = amount;
	}

	public Timestamp getDate() {
		return date;
	}

	public void setDate(Timestamp date) {
		this.date = date;
	}

	
	@Override
	public String toString() {
		return "Invoice [id=" + id + ", job=" + job + ", amount=" + amount + ", date=" + date + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(amount, date, id, job);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Invoice other = (Invoice) obj;
		return Objects.equals(amount, other.amount) && Objects.equals(date, other.date) && id == other.id
				&& Objects.equals(job, other.job);
	}
	
	
}
```