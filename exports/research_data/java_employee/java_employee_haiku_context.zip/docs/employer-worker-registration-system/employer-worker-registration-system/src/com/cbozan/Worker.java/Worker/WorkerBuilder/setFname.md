`setFname`: The function of `setFname` is to set the first name of a worker in the `WorkerBuilder` class.

**Parameters**:
`String fname`: This parameter represents the first name of the worker that needs to be set.

**Code Description**: The `setFname` method takes a `String` parameter `fname` and assigns it to the `fname` field of the `WorkerBuilder` class. After setting the `fname` field, the method returns the current instance of the `WorkerBuilder` class, allowing for method chaining. This allows developers to easily set multiple properties of the `Worker` object by calling multiple setter methods in a fluent style.\\
## Code: 
```
WorkerBuilder setFname(String fname) {
			this.fname = fname;
			return this;
		}
```