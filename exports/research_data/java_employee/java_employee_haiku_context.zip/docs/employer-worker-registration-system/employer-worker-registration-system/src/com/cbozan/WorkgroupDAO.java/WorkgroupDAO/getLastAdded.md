`getLastAdded`: The function of `getLastAdded` is to retrieve the most recently added `Workgroup` object from the database.

**Code Description**: The `getLastAdded()` method is responsible for fetching the most recently added `Workgroup` object from the database. It does this by executing a SQL query that selects all rows from the `workgroup` table, orders them by the `id` column in descending order, and limits the result to the first (most recent) row.

The method first initializes a `Workgroup` object to `null`. It then establishes a connection to the database using the `DB.getConnection()` method, creates a `Statement` object, and executes the SQL query to retrieve the most recent `Workgroup` record.

The method then iterates through the `ResultSet` obtained from the query execution. For each row, it creates a `WorkgroupBuilder` object and sets the various properties of the `Workgroup` object (such as `id`, `job_id`, `worktype_id`, `workcount`, `description`, and `date`) using the values from the database. Finally, it attempts to build the `Workgroup` object using the `WorkgroupBuilder` and returns it.

If any exceptions occur during the process, such as SQL exceptions or `EntityException` (which is likely a custom exception related to the `Workgroup` entity), the method will print the error message to the console but still return the `Workgroup` object (which may be `null` if an error occurred during the building process).\\
## Code: 
```
Workgroup getLastAdded() {
		
		Workgroup workgroup = null;
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM workgroup ORDER BY id DESC LIMIT 1";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			WorkgroupBuilder builder; 
			
			while(rs.next()) {
				
				builder = new WorkgroupBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setWorktype_id(rs.getInt("worktype_id"));
				builder.setWorkCount(rs.getInt("workcount"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					workgroup = builder.build();
				} catch (EntityException e) {
					System.err.println(e.getMessage());
				}
				
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return workgroup;
	}
```