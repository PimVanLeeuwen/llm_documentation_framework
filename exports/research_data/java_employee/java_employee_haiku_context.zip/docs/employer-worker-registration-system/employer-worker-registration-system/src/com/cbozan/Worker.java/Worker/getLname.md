`getLname`: The function of `getLname` is to return the last name of the worker.

**Code Description**: The `getLname()` method is a simple getter method that returns the value of the `lname` instance variable of the `Worker` class. This method does not take any parameters and simply returns the last name of the worker. The implementation of this method is a single line of code that returns the value of the `lname` variable.

This method is likely used in other parts of the `Worker` class or the larger application to access the last name of a worker. Getter methods like this are commonly used in object-oriented programming to provide a way to access the private or protected instance variables of a class, while encapsulating the implementation details.\\
## Code: 
```
String getLname() {
		return lname;
	}
```