`getSelectedJob`: The function of `getSelectedJob` is to return the currently selected job.

**Code Description**: The `getSelectedJob` method is a simple getter method that returns the value of the `selectedJob` instance variable. This method is likely used in other parts of the application to access the currently selected job, which could be used for various purposes such as displaying job details, processing job-related actions, or storing the selected job in a data structure.

The method does not take any parameters and simply returns the value of the `selectedJob` variable, which is likely set elsewhere in the code. This method provides a way to encapsulate and abstract the access to the `selectedJob` variable, making the code more modular and easier to maintain.\\
## Code: 
```
Job getSelectedJob() {
		return selectedJob;
	}
```