`update`: The function of `update` is to update the information of an existing employer in the database.

**Parameters**:
`Employer employer`: This parameter represents the updated information of the employer, including the first name, last name, telephone number, and description.

**Code Description**:
1. The method first calls the `updateControl` method to check if an employer with the same first and last name already exists in the cache, excluding the current employer being updated. If the `updateControl` method returns `false`, the `update` method also returns `false`.
2. The method then creates a SQL `UPDATE` query to update the `fname`, `lname`, `tel`, and `description` columns of the `employer` table, where the `id` column matches the `id` of the `employer` parameter.
3. The method uses a `PreparedStatement` to execute the SQL query, setting the appropriate values for the query parameters using the `employer` object.
4. If the `executeUpdate` method returns a non-zero value, indicating that the update was successful, the method updates the cache by putting the updated `employer` object in the cache, using the `employer.getId()` as the key.
5. If an SQL exception occurs during the update process, the method calls the `showSQLException` method to display a message dialog box with information about the exception.
6. Finally, the method returns `true` if the update was successful, and `false` otherwise.

The `update` method is responsible for updating the information of an existing employer in the database. It first checks if the update is valid by calling the `updateControl` method, and then executes the SQL `UPDATE` query to update the employer's information. If the update is successful, the method also updates the cache to ensure that the updated information is available for future use.\\
## Code: 
```
boolean update(Employer employer) {
		
		if(updateControl(employer) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE employer SET fname=?,"
				+ "lname=?, tel=?, description=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1, employer.getFname());
			pst.setString(2, employer.getLname());
			
			Array phones = conn.createArrayOf("VARCHAR", employer.getTel().toArray());
			pst.setArray(3, phones);
			
			pst.setString(4, employer.getDescription());
			pst.setInt(5, employer.getId());
			
			result = pst.executeUpdate();
			
			// update cache
			if(result != 0) {
				cache.put(employer.getId(), employer);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```