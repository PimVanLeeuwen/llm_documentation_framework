`list`: The function of `list` is to retrieve a list of `Invoice` objects from a database based on a specified column name and ID.

**Parameters**:
`String columnName`: The name of the column in the `invoice` table to filter the results by.
`int id`: The ID value to use for the filter on the specified column.

**Code Description**:
The `list` method first creates an empty `ArrayList` called `list` to store the retrieved `Invoice` objects. It then establishes a connection to the database using the `DB.getConnection()` method, which returns a `Connection` object.

Next, the method constructs a SQL query string that selects all rows from the `invoice` table where the specified `columnName` column matches the provided `id` value. This query is then executed using a `Statement` object, and the results are stored in a `ResultSet` object.

The method then iterates through the `ResultSet`, creating an `InvoiceBuilder` object for each row and using it to build an `Invoice` object. The `Invoice` object is then added to the `list` `ArrayList`. If any errors occur during the building of the `Invoice` object, an error message is printed, and the `Invoice` is not added to the list.

Finally, the method returns the `list` `ArrayList` containing the retrieved `Invoice` objects.\\
## Code: 
```
List<Invoice> list(String columnName, int id){
		
		List<Invoice> list = new ArrayList<>();
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM invoice WHERE " + columnName + "=" + id;
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			InvoiceBuilder builder;
			Invoice invoice;
			
			while(rs.next()) {
				
				builder = new InvoiceBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setAmount(rs.getBigDecimal("amount"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					invoice = builder.build();
					list.add(invoice);
				} catch (EntityException e) {
					System.err.println(e.getMessage());
					System.out.println("!! Invoice not added list !!");
				}
				
			}
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return list;
	}
```