`updateControl`: The function of `updateControl` is to check if an employer with the same first and last name already exists in the cache, excluding the current employer being updated.

**Parameters**:
`Employer employer`: This parameter represents the employer object that is being updated.

**Code Description**:
The `updateControl` method takes an `Employer` object as a parameter and checks if there is an existing employer in the `cache` with the same first and last name, but a different ID. 

The method iterates through the `cache`, which is a map of `Integer` (employer ID) and `Employer` objects. For each entry in the cache, it checks if the first and last name of the current employer in the cache matches the first and last name of the `employer` parameter, and if the ID of the current employer in the cache is different from the ID of the `employer` parameter.

If a match is found, it sets the `DB.ERROR_MESSAGE` to a string indicating that the record for the first and last name already exists, and returns `false` to indicate that the update should not proceed.

If no match is found, the method returns `true`, indicating that the update can proceed.

This function is likely used to ensure that there are no duplicate employer records in the system based on the first and last name, except for the current employer being updated.\\
## Code: 
```
boolean updateControl(Employer employer) {
		for(Entry<Integer, Employer> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(employer.getFname()) 
					&& obj.getValue().getLname().equals(employer.getLname()) 
					&& obj.getValue().getId() != employer.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```