`GUI`: The function of `GUI` is to create and configure the graphical user interface (GUI) for a login screen.

**Code Description**:

The `GUI` method sets up the layout and components of the login screen. It creates a `JPanel` called `contentPane` and sets its layout to `null` to allow manual positioning of the components. The panel is then positioned within the frame using the `setBounds` method.

The method then adds the following components to the `contentPane`:

1. `label_username`: A label for the username field.
2. `label_password`: A label for the password field.
3. `textField_username`: A text field for the user to enter their username.
4. `passwordField_password`: A password field for the user to enter their password.
5. `button_login`: A button labeled "Login" that triggers the login process.
6. `label_icon`: An icon image representing a user.
7. `label_errorText`: A label that displays an error message if the login fails.

The method also adds event listeners to the `textField_username` and `passwordField_password` components. When the user presses the Enter key in the username field, the focus is shifted to the password field. When the user presses the Enter key in the password field, the `button_login` is clicked, triggering the login process.

The login process is handled by the `button_login`'s `ActionListener`. If the username or password field is empty, an error message is displayed in the `label_errorText`. Otherwise, the `LoginDAO` class is used to verify the login credentials. If the login is successful, a success message is displayed, and a new `MainFrame` is created. If the login fails, the error message is displayed in the `label_errorText`.

Overall, the `GUI` method sets up the visual components and event handling for the login screen, providing a user-friendly interface for the application.\\
## Code: 
```
void GUI() {
		
		contentPane = new JPanel();
		contentPane.setLayout(null);
		contentPane.setBounds(insets.left, insets.top, W_FRAME - insets.left - insets.right, 
				H_FRAME - insets.bottom - insets.top);
	
		label_username = new JLabel("Username");
		label_username.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_username.setBounds(120, 140, 70, 20);
		contentPane.add(label_username);
		
		label_password = new JLabel("Password");
		label_password.setFont(label_username.getFont());
		label_password.setBounds(label_username.getX(), label_username.getY() + 40, 
				label_username.getWidth(), label_username.getHeight());
		contentPane.add(label_password);
		
		textField_username = new JTextField();
		textField_username.setBounds(label_username.getX() + label_username.getWidth() + 30, 
				label_username.getY(), 120, label_username.getHeight());
		textField_username.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				passwordField_password.requestFocus();
			}
		});
		contentPane.add(textField_username);
		
		passwordField_password = new JPasswordField();
		passwordField_password.setBounds(textField_username.getX(), label_password.getY(), 
				120, label_password.getHeight());
		passwordField_password.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				button_login.doClick();
			}
		});
		contentPane.add(passwordField_password);
		
		button_login = new JButton("Login");
		button_login.setBounds(textField_username.getX() + 20, label_username.getY() + 80, 80, 22);
		button_login.setFocusPainted(false);
		button_login.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
		
				if(textField_username.getText().equals("") || String.valueOf(passwordField_password.getPassword()).equals("")) {
					
					label_errorText.setText(errorText);
				
				} else {
					
					label_errorText.setText("");
					LoginDAO loginDAO = new LoginDAO();
					if(loginDAO.verifyLogin(textField_username.getText(), 
							String.valueOf(passwordField_password.getPassword()))) {
						JOptionPane.showMessageDialog(contentPane, "Login successful. Welcome", "Login", 
								JOptionPane.INFORMATION_MESSAGE);
						
						EventQueue.invokeLater(new Runnable() {
							@Override
							public void run() {
								Login.this.dispose();
								new MainFrame();
							}
						});
						
					} else {
						label_errorText.setText(errorText);
					}
					
				}
				
			}
		});
		contentPane.add(button_login);
		
		label_icon = new JLabel(new ImageIcon("src\\icon\\Login_user_72.png"));
		label_icon.setBounds(textField_username.getX() + 20, textField_username.getY() - 100, 72, 72);
		contentPane.add(label_icon);
		
		label_errorText = new JLabel();
		label_errorText.setForeground(Color.RED);
		label_errorText.setBounds(button_login.getX() - 45, button_login.getY() + 30, 
				170, 30);
		label_errorText.setFont(new Font("Tahoma", Font.PLAIN + Font.BOLD, 11));
		contentPane.add(label_errorText);
		
		setContentPane(contentPane);
		
	}
```