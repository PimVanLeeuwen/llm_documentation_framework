`setId`: The function of `setId` is to set the ID of an Invoice object.

**Parameters**:
`int id`: The ID value to be set for the Invoice object.

**Code Description**: The `setId` method is responsible for setting the ID of an Invoice object. It takes an integer `id` as a parameter and performs a simple validation check to ensure that the provided `id` is greater than 0. If the `id` is less than or equal to 0, the method throws an `EntityException` with the message "Invoice ID negative or zero". This is to prevent the creation of an Invoice object with an invalid or negative ID. If the `id` value is valid, the method assigns it to the `id` field of the Invoice object.\\
## Code: 
```
void setId(int id) throws EntityException {
		if(id <= 0)
			throw new EntityException("Invoice ID negative or zero");
		this.id = id;
	}
```