`setFulltime`: The function of `setFulltime` is to set the `fulltime` property of the class to the provided `BigDecimal` value, but only if the value is greater than 0.00.

**Parameters**:
`BigDecimal fulltime`: This parameter represents the new value to be set for the `fulltime` property of the class. It must be a non-null and positive `BigDecimal` value.

**Code Description**:
The `setFulltime` method first checks if the `fulltime` parameter is null or less than or equal to 0.00. If either of these conditions is true, the method throws an `EntityException` with the message "Price fulltime negative or null or zero". This ensures that the `fulltime` property is not set to an invalid value.

If the `fulltime` parameter is valid (non-null and greater than 0.00), the method sets the `fulltime` property of the class to the provided value.

This method is likely part of a larger class that represents a "Price" entity, and the `fulltime` property is likely used to store the full-time price or rate associated with that entity.\\
## Code: 
```
void setFulltime(BigDecimal fulltime) throws EntityException {
		if(fulltime == null || fulltime.compareTo(new BigDecimal("0.00")) <= 0)
			throw new EntityException("Price fulltime negative or null or zero");
		this.fulltime = fulltime;
	}
```