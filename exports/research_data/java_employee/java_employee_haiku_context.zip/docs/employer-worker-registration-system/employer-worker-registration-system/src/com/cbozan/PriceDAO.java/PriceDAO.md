`PriceDAO`: The function of `PriceDAO` is to manage the storage and retrieval of `Price` objects in a database.

**Code Description**:

The `PriceDAO` class is responsible for interacting with a database to perform CRUD (Create, Read, Update, Delete) operations on `Price` objects. It provides the following functionality:

1. **Caching**: The class maintains a cache of `Price` objects in a `HashMap` called `cache`. This cache is used to improve performance by avoiding repeated database queries.

2. **Read by ID**: The `findById` method retrieves a `Price` object from the cache or, if the cache is empty, calls the `list` method to populate the cache and then returns the requested `Price` object.

3. **Read All**: The `list` method retrieves all `Price` objects from the database and stores them in the cache. If the cache is not empty and caching is enabled, the method returns the cached prices instead of querying the database.

4. **Create**: The `create` method inserts a new `Price` object into the database and updates the cache with the newly inserted data. It first checks if the price information already exists in the cache using the `createControl` method.

5. **Update**: The `update` method updates the price information for an existing `Price` object in the database and updates the cache with the new information. It first checks if the price information has changed using the `updateControl` method.

6. **Delete**: The `delete` method deletes a `Price` object from the database and removes it from the cache.

7. **Caching Control**: The class provides methods to control the caching behavior, such as `isUsingCache` and `setUsingCache`.

8. **Error Handling**: The class includes methods `showEntityException` and `showSQLException` to display error messages in a JOptionPane dialog when exceptions occur.

9. **Singleton Pattern**: The `PriceDAOHelper` class is a singleton that provides a single instance of the `PriceDAO` class.

Overall, the `PriceDAO` class is responsible for managing the storage and retrieval of `Price` objects in a database, with a focus on performance optimization through caching and error handling.\\
## Code: 
```
class PriceDAO {

	private final HashMap<Integer, Price> cache = new HashMap<>();
	private boolean usingCache = true;
	
	private PriceDAO() {list();}
	
	// Read by id
	public Price findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
	
	
	//Read All
	public List<Price> list(){
		
		List<Price> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Price> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM price;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			PriceBuilder builder;
			Price price;
			
			while(rs.next()) {
				
				builder = new PriceBuilder();
				builder.setId(rs.getInt("id"));
				builder.setFulltime(rs.getBigDecimal("fulltime"));
				builder.setHalftime(rs.getBigDecimal("halftime"));
				builder.setOvertime(rs.getBigDecimal("overtime"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					price = builder.build();
					list.add(price);
					cache.put(price.getId(), price);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
		
	}
	
	
	public boolean create(Price price) {
		
		if(createControl(price) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO price (fulltime,halftime,overtime) VALUES (?,?,?);";
		String query2 = "SELECT * FROM price ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			
			pst.setBigDecimal(1, price.getFulltime());
			pst.setBigDecimal(2, price.getHalftime());
			pst.setBigDecimal(3, price.getOvertime());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					PriceBuilder builder = new PriceBuilder();
					builder.setId(rs.getInt("id"));
					builder.setFulltime(rs.getBigDecimal("fulltime"));
					builder.setHalftime(rs.getBigDecimal("halftime"));
					builder.setOvertime(rs.getBigDecimal("overtime"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Price prc = builder.build();
						cache.put(prc.getId(), prc);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id"));
					}
					
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
	
	private boolean createControl(Price price) {
		for(Entry<Integer, Price> obj : cache.entrySet()) {
			if(obj.getValue().getFulltime().compareTo(price.getFulltime()) == 0
					&& obj.getValue().getHalftime().compareTo(price.getHalftime()) == 0
					&& obj.getValue().getOvertime().compareTo(price.getOvertime()) == 0) {
				
				DB.ERROR_MESSAGE = "Bu fiyat bilgisi kaydı zaten mevcut.";
				return false;
			}
		}
		
		return true;
	}
	
	
	public boolean update(Price price) {
		
		if(updateControl(price) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE price SET fulltime=?,"
				+ "halftime=?, overtime=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setBigDecimal(1, price.getFulltime());
			pst.setBigDecimal(2, price.getHalftime());
			pst.setBigDecimal(3, price.getOvertime());
			pst.setInt(4, price.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(price.getId(), price);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
	
	private boolean updateControl(Price price) {
		for(Entry<Integer, Price> obj : cache.entrySet()) {
			if(obj.getValue().getFulltime().compareTo(price.getFulltime()) == 0
					&& obj.getValue().getHalftime().compareTo(price.getHalftime()) == 0
					&& obj.getValue().getOvertime().compareTo(price.getOvertime()) == 0
					&& obj.getValue().getId() != price.getId()) {
				
				DB.ERROR_MESSAGE = "Bu fiyat bilgisi kaydı zaten mevcut.";
				return false;
			}
		}
		
		return true;
	}
	
	public boolean delete(Price price) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM price WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, price.getId());
			result = ps.executeUpdate();
			
			if(result != 0) {
				cache.remove(price.getId());
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
		
	}
	
	
	private static class PriceDAOHelper {
		private static final PriceDAO instance = new PriceDAO();
	}
	
	public static PriceDAO getInstance() {
		return PriceDAOHelper.instance;
	}

	public boolean isUsingCache() {
		return usingCache;
	}

	public void setUsingCache(boolean usingCache) {
		this.usingCache = usingCache;
	}
	
	private void showEntityException(EntityException e, String msg) {
		String message = msg + " not added" + 
				"\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + e.getCause();
			JOptionPane.showMessageDialog(null, message);
	}
	
	private void showSQLException(SQLException e) {
		String message = e.getErrorCode() + "\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + "\n" + e.getCause();
		JOptionPane.showMessageDialog(null, message);
	}
	
}
```