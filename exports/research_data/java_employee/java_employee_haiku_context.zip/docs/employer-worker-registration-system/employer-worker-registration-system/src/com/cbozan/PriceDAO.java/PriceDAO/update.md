`update`: The function of `update` is to update an existing `Price` object in the database.

**Parameters**:
`Price price`: This parameter represents the `Price` object that needs to be updated in the database. It contains the new values for the `fulltime`, `halftime`, and `overtime` fields.

**Code Description**:
1. The method first calls the `updateControl()` method to check if the `Price` object being updated already exists in a cache. If it does not exist, the method returns `false`.
2. The method then creates a SQL `UPDATE` query to update the `price` table in the database. The query updates the `fulltime`, `halftime`, and `overtime` columns for the row with the matching `id`.
3. The method uses a `PreparedStatement` to execute the SQL query and set the values for the `fulltime`, `halftime`, and `overtime` parameters.
4. If the `executeUpdate()` method returns a non-zero value, indicating that the update was successful, the method adds the updated `Price` object to a cache using the `cache.put()` method.
5. If an `SQLException` occurs during the update process, the method calls the `showSQLException()` method to display an error message dialog box.
6. Finally, the method returns `true` if the update was successful, and `false` otherwise.

Overall, the `update()` method is responsible for updating an existing `Price` object in the database and maintaining a cache of the updated objects.\\
## Code: 
```
boolean update(Price price) {
		
		if(updateControl(price) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE price SET fulltime=?,"
				+ "halftime=?, overtime=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setBigDecimal(1, price.getFulltime());
			pst.setBigDecimal(2, price.getHalftime());
			pst.setBigDecimal(3, price.getOvertime());
			pst.setInt(4, price.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(price.getId(), price);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```