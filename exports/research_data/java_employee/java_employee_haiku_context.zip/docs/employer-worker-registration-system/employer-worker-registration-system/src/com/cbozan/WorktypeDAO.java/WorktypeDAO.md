`WorktypeDAO`: The function of `WorktypeDAO` is to manage the CRUD (Create, Read, Update, Delete) operations for `Worktype` objects in a database.

**Code Description**:

1. **Caching**: The `WorktypeDAO` class maintains a cache of `Worktype` objects in a `HashMap` called `cache`. This cache is used to improve performance by avoiding repeated database queries.

2. **Read Operations**:
   - `findById(int id)`: This method retrieves a `Worktype` object from the cache by its ID. If the cache is empty or caching is disabled, it calls the `list()` method to populate the cache.
   - `list()`: This method retrieves all `Worktype` objects from the database and stores them in the cache. If the cache is not empty and caching is enabled, it returns the cached list instead of querying the database.

3. **Create Operation**:
   - `create(Worktype worktype)`: This method inserts a new `Worktype` object into the database and updates the cache with the newly created object. It first checks if the `Worktype` already exists in the cache using the `createControl()` method.

4. **Update Operation**:
   - `update(Worktype worktype)`: This method updates an existing `Worktype` object in the database. It first checks if the update is allowed using the `updateControl()` method, which ensures that the `title` of the `Worktype` is unique within the cache.

5. **Delete Operation**:
   - `delete(Worktype worktype)`: This method deletes a `Worktype` object from the database and removes it from the cache.

6. **Utility Methods**:
   - `createControl(Worktype worktype)`: This method checks if a `Worktype` with the same `title` already exists in the cache.
   - `updateControl(Worktype worktype)`: This method checks if a `Worktype` with the same `title` but a different `id` already exists in the cache.
   - `showEntityException(EntityException e, String msg)`: This method displays an error message in a JOptionPane dialog when an `\\
## Code: 
```
class WorktypeDAO {
	
	private final HashMap<Integer, Worktype> cache = new HashMap<>();
	private boolean usingCache = true;
	
	
	private WorktypeDAO() {list();}
	
	// Read by id
	public Worktype findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
	
	
	//Read All
	public List<Worktype> list(){
		
		List<Worktype> list = new ArrayList<>();
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Worktype> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM worktype;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorktypeBuilder builder;
			Worktype worktype;
			
			while(rs.next()) {
				
				builder = new WorktypeBuilder();
				builder.setId(rs.getInt("id"));
				builder.setTitle(rs.getString("title"));
				builder.setNo(rs.getInt("no"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					worktype = builder.build();
					list.add(worktype);
					cache.put(worktype.getId(), worktype);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id") + ", Title : " + rs.getString("title"));
				}
				
			}
			
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
		
	}
	
	
	public boolean create(Worktype worktype) {
		
		if(createControl(worktype) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO worktype (title,no) VALUES (?,?);";
		String query2 = "SELECT * FROM worktype ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1, worktype.getTitle());
			pst.setInt(2, worktype.getNo());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					WorktypeBuilder builder = new WorktypeBuilder();
					builder = new WorktypeBuilder();
					builder.setId(rs.getInt("id"));
					builder.setTitle(rs.getString("title"));
					builder.setNo(rs.getInt("no"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Worktype wt = builder.build();
						cache.put(wt.getId(), wt);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id") + ", Title : " + rs.getString("title"));
					}
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
	
	private boolean createControl(Worktype worktype) {
		for(Entry<Integer, Worktype> obj : cache.entrySet()) {
			if(obj.getValue().getTitle().equals(worktype.getTitle())) {
				return false;
			}
		}
		return true;
	}
	
	
	public boolean update(Worktype worktype) {
		
		if(updateControl(worktype) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE worktype SET title=?,"
				+ "no=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1, worktype.getTitle());
			pst.setInt(2, worktype.getNo());
			pst.setInt(3, worktype.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(worktype.getId(), worktype);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
	
	private boolean updateControl(Worktype worktype) {
		for(Entry<Integer, Worktype> obj : cache.entrySet()) {
			if(obj.getValue().getTitle().equals(worktype.getTitle()) && obj.getValue().getId() != worktype.getId()) {
				return false;
			}
		}
		return true;
	}
	
	public boolean delete(Worktype worktype) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM worktype WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, worktype.getId());

			result = ps.executeUpdate();
			
			if(result != 0) {
				cache.remove(worktype.getId());
			}

		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
		
	}
	
	
	private static class WorktypeDAOHelper {
		private static final WorktypeDAO instance = new WorktypeDAO();
	}
	
	public static WorktypeDAO getInstance() {
		return WorktypeDAOHelper.instance;
	}

	public boolean isUsingCache() {
		return usingCache;
	}

	public void setUsingCache(boolean usingCache) {
		this.usingCache = usingCache;
	}
	
	private void showEntityException(EntityException e, String msg) {
		String message = msg + " not added" + 
				"\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + e.getCause();
			JOptionPane.showMessageDialog(null, message);
	}
	
	private void showSQLException(SQLException e) {
		String message = e.getErrorCode() + "\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + "\n" + e.getCause();
		JOptionPane.showMessageDialog(null, message);
	}

}
```