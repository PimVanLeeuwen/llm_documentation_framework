`Control`: The function of `Control` is to provide utility methods for validating various types of input data, such as phone numbers, IBAN (International Bank Account Number), and decimal numbers.

**Code Description**:

1. `phoneNumberControl` methods:
   - These methods take a phone number string as input and check if it matches a specific regular expression pattern.
   - The first `phoneNumberControl` method uses a predefined regular expression pattern to validate the phone number. The pattern checks if the phone number is a 10-digit number, optionally preceded by a "+" and the country code "90" or a "0".
   - The other two `phoneNumberControl` methods allow the caller to provide a custom regular expression pattern or a `Pattern` object to perform the phone number validation.

2. `ibanControl` methods:
   - These methods take an IBAN string as input and check if it matches a specific regular expression pattern.
   - The first `ibanControl` method uses a predefined regular expression pattern to validate the IBAN. The pattern checks if the IBAN is in the format of a 24-digit number starting with "TR".
   - The other two `ibanControl` methods allow the caller to provide a custom regular expression pattern or a `Pattern` object to perform the IBAN validation.

3. `decimalControl` methods:
   - These methods take one or more string arguments and check if they represent valid decimal numbers with up to two decimal places.
   - The first `decimalControl` method uses a predefined regular expression pattern to validate the decimal numbers.
   - The second `decimalControl` method allows the caller to provide a custom `Pattern` object to perform the decimal number validation.

Overall, the `Control` class provides a set of utility methods that can be used to validate various types of input data, such as phone numbers, IBANs, and decimal numbers. These methods can be useful in applications that require input validation, such as user registration or data processing systems.\\
## Code: 
```
class Control {

	public static boolean phoneNumberControl(String phoneNumber) {
		return Pattern.compile("^((((\\+90)?|(0)?)\\d{10})|())$").matcher(phoneNumber.replaceAll("\\s+", "")).find();
	}
	public static boolean phoneNumberControl(String phoneNumber, String regex) {
		return Pattern.compile(regex).matcher(phoneNumber.replaceAll("\\s+", "")).find();
	}
	public static boolean phoneNumberControl(String phoneNumber, Pattern pattern) {
		return pattern.matcher(phoneNumber).find();
	}
	
	
	public static boolean ibanControl(String iban) {
		return Pattern.compile("^((TR\\d{24})|())$", Pattern.CASE_INSENSITIVE).matcher(iban).find();
	}
	public static boolean ibanControl(String iban, String regex) {
		return Pattern.compile(regex).matcher(iban).find();
	}
	public static boolean ibanControl(String iban, Pattern pattern) {
		return pattern.matcher(iban).find();
	}
	
	
	public static boolean decimalControl(String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= Pattern.compile("^((\\d+(\\.\\d{1,2})?)|())$").matcher(arg).find();
		}
		return rValue;
	}
	public static boolean decimalControl(Pattern pattern, String ...args) {
		boolean rValue = true;
		for(String arg : args) {
			rValue &= pattern.matcher(arg).find();
		}
		return rValue;
	}
	
}
```