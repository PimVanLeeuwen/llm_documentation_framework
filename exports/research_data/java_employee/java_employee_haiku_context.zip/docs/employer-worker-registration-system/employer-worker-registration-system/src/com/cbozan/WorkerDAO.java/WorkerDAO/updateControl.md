`updateControl`: The function of `updateControl` is to check if a worker with the same first and last name already exists in the cache, excluding the current worker being updated.

**Parameters**:
`Worker worker`: The worker object containing the updated information to be checked against the existing workers in the cache.

**Code Description**:
The `updateControl` method takes a `Worker` object as a parameter and checks if there is already a worker with the same first and last name in the `cache` map, excluding the current worker being updated.

The method iterates through the `cache` map using a for-each loop. For each `Worker` object in the `cache`, it checks if the first and last name of the current worker in the loop matches the `worker` parameter, and if the ID of the current worker in the loop is different from the ID of the `worker` parameter.

If a match is found, it sets the `DB.ERROR_MESSAGE` to a string indicating that the record for the first and last name already exists, and returns `false` to indicate that the update should not proceed.

If no matching worker is found, the method returns `true`, indicating that the update can proceed.

This function is likely used to ensure that there are no duplicate worker records in the system based on the first and last name combination, except for the current worker being updated.\\
## Code: 
```
boolean updateControl(Worker worker) {
		for(Entry<Integer, Worker> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(worker.getFname()) 
					&& obj.getValue().getLname().equals(worker.getLname())
					&& obj.getValue().getId() != worker.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```