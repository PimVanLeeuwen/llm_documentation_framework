`InvoiceBuilder`: The function of `InvoiceBuilder` is to create and configure `Invoice` objects.

**Code Description**:

The `InvoiceBuilder` class is responsible for constructing `Invoice` objects. It provides several constructors and methods to set the various properties of an `Invoice` object, such as `id`, `job_id`, `job`, `amount`, and `date`.

The class has two constructors:
1. `InvoiceBuilder(int id, int job_id, BigDecimal amount, Timestamp date)`: This constructor initializes the `id`, `job_id`, `amount`, and `date` fields of the `InvoiceBuilder` object.
2. `InvoiceBuilder(int id, Job job, BigDecimal amount, Timestamp date)`: This constructor initializes the `id`, `job`, `amount`, and `date` fields of the `InvoiceBuilder` object.

The class also provides the following methods:
1. `setId(int id)`: This method sets the `id` field of the `InvoiceBuilder` object and returns the `InvoiceBuilder` instance, allowing for method chaining.
2. `setJob_id(int job_id)`: This method sets the `job_id` field of the `InvoiceBuilder` object and returns the `InvoiceBuilder` instance, allowing for method chaining.
3. `setJob(Job job)`: This method sets the `job` field of the `InvoiceBuilder` object and returns the `InvoiceBuilder` instance, allowing for method chaining.
4. `setAmount(BigDecimal amount)`: This method sets the `amount` field of the `InvoiceBuilder` object and returns the `InvoiceBuilder` instance, allowing for method chaining.
5. `setDate(Timestamp date)`: This method sets the `date` field of the `InvoiceBuilder` object and returns the `InvoiceBuilder` instance, allowing for method chaining.
6. `build()`: This method creates an `Invoice` object based on the configured properties of the `InvoiceBuilder` object. If the `job` field is `null`, it creates a new `Invoice` object using the `this` instance of the `Invoice\\
## Code: 
```
class InvoiceBuilder{
		
		private int id;
		private int job_id;
		private Job job;
		private BigDecimal amount;
		private Timestamp date;
		
		public InvoiceBuilder() {}
		public InvoiceBuilder(int id, int job_id, BigDecimal amount, Timestamp date) {
			this.id = id;
			this.job_id = job_id;
			this.amount = amount;
			this.date = date;
		}
		
		public InvoiceBuilder(int id, Job job, BigDecimal amount, Timestamp date) {
			this(id, 0, amount, date);
			this.job = job;
		}
		
		public InvoiceBuilder setId(int id) {
			this.id = id;
			return this;
		}
		
		public InvoiceBuilder setJob_id(int job_id) {
			this.job_id = job_id;
			return this;
		}
		
		public InvoiceBuilder setJob(Job job) {
			this.job = job;
			return this;
		}
		
		public InvoiceBuilder setAmount(BigDecimal amount) {
			this.amount = amount;
			return this;
		}
		
		public InvoiceBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Invoice build() throws EntityException {
			if(job == null)
				return new Invoice(this);
			return new Invoice(id, job, amount, date);
		}
		
	}
```