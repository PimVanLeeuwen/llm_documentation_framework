`filterWorktype`: The function of `filterWorktype` is to filter a list of `Work` objects based on the selected `Worktype`.

**Parameters**:
`List<Work> workList`: This parameter represents the list of `Work` objects that need to be filtered.

**Code Description**:
The `filterWorktype` method first checks if the `selectedWorktype` is `null`. If it is, the method simply returns without performing any filtering.

If the `selectedWorktype` is not `null`, the method iterates through the `workList` using an `Iterator`. For each `Work` object in the list, it checks if the `Worktype` ID of the `Work` object matches the `Worktype` ID of the `selectedWorktype`. If the IDs do not match, the method removes the `Work` object from the list using the `Iterator.remove()` method.

This filtering process ensures that the `workList` only contains `Work` objects that have a `Worktype` matching the `selectedWorktype`.\\
## Code: 
```
void filterWorktype(List<Work> workList) {
		if(selectedWorktype == null) {
			return;
		}
		
		Iterator<Work> work = workList.iterator();
		Work workItem;
		while(work.hasNext()) {
			workItem = work.next();
			if(workItem.getWorktype().getId() != selectedWorktype.getId()) {
				work.remove();
			}
		}
	}
```