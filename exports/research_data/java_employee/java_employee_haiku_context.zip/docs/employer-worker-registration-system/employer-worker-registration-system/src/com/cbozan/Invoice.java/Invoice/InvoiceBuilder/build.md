`build`: The function of `build` is to create and return an `Invoice` object.

**Code Description**: The `build()` method is part of the `InvoiceBuilder` class, which is likely used to construct `Invoice` objects in a more structured and organized way. The method checks if the `job` field is `null`. If it is, the method returns a new `Invoice` object created using the current instance of the `InvoiceBuilder`. If the `job` field is not `null`, the method returns a new `Invoice` object created using the `id`, `job`, `amount`, and `date` fields of the `InvoiceBuilder` instance.

This approach allows for the creation of `Invoice` objects with different sets of data, depending on the state of the `InvoiceBuilder` instance. The `build()` method ensures that the `Invoice` object is properly constructed and returns it, handling any potential `EntityException` that may be thrown during the creation process.\\
## Code: 
```
Invoice build() throws EntityException {
			if(job == null)
				return new Invoice(this);
			return new Invoice(id, job, amount, date);
		}
```