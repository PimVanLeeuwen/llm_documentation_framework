`list`: The function of `list` is to retrieve a list of all jobs stored in the database.

**Code Description**: The `list()` method in the `JobDAO` class is responsible for fetching all the job records from the database and returning them as a list of `Job` objects.

The method first checks if there is any cached data available and if the cache is being used. If so, it simply returns the cached data without querying the database.

If the cache is empty or not being used, the method clears the cache and proceeds to fetch the data from the database. It establishes a connection to the database using the `DB.getConnection()` method, creates a SQL statement, and executes a query to select all records from the `job` table.

For each record returned by the query, the method creates a `JobBuilder` object, sets the various properties of the job (such as ID, employer ID, price ID, title, description, and date), and then builds a `Job` object. The built `Job` object is added to the result list and also stored in the cache.

If any `EntityException` is thrown during the process of building the `Job` object, the method calls the `showEntityException()` method to display an error message.

Finally, the method returns the list of `Job` objects.

The key aspects of the `list()` method are:

1. Checking and using cached data if available to improve performance.
2. Fetching all job records from the database using a SQL query.
3. Creating `Job` objects from the retrieved data using the `JobBuilder` class.
4. Handling any `EntityException` that may occur during the object creation process.
5. Storing the retrieved `Job` objects in a cache for future use.

Overall, the `list()` method provides a way to retrieve all the job records from the database and return them as a list of `Job` objects, with the added benefit of caching the data to improve performance for subsequent calls.\\
## Code: 
```
List<Job> list(){
		
		List<Job> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Job> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM job;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			JobBuilder builder;
			Job job;
			
			while(rs.next()) {
				
				builder = new JobBuilder();
				builder.setId(rs.getInt("id"));
				builder.setEmployer_id(rs.getInt("employer_id"));
				builder.setPrice_id(rs.getInt("price_id"));
				builder.setTitle(rs.getString("title"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					job = builder.build();
					list.add(job);
					cache.put(job.getId(), job);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id") + " Title : " + rs.getString("title"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
	}
```