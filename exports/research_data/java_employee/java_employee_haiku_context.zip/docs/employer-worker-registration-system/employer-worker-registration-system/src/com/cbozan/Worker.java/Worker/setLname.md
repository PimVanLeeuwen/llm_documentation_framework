`setLname`: The function of `setLname` is to set the last name of a worker object.

**Parameters**:
`String lname`: This parameter represents the new last name to be set for the worker object.

**Code Description**:
The `setLname` method takes a `String` parameter `lname` and sets the `lname` property of the worker object to the provided value. However, before setting the new last name, the method performs a validation check on the input `lname` parameter.

The validation check ensures that the length of the `lname` string is not empty (0 characters) and does not exceed the maximum length defined by the `DBConst.LNAME_LENGTH` constant. If the `lname` string does not meet these criteria, the method throws an `EntityException` with the message "Worker last name empty or too long".

If the `lname` string passes the validation check, the method sets the `lname` property of the worker object to the provided value.\\
## Code: 
```
void setLname(String lname) throws EntityException {
		if(lname.length() == 0 || lname.length() > DBConst.LNAME_LENGTH)
			throw new EntityException("Worker last name empty or too long");
		this.lname = lname;
	}
```