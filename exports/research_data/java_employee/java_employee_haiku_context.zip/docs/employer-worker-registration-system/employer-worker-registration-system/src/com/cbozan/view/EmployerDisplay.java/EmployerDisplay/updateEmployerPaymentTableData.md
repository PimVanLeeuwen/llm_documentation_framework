`updateEmployerPaymentTableData`: The function of `updateEmployerPaymentTableData` is to update the data displayed in the employer payment table.

**Code Description**: The `updateEmployerPaymentTableData` method is responsible for updating the data displayed in the employer payment table. It performs the following tasks:

1. Checks if a `selectedEmployer` has been set. If so, it proceeds to update the table data.
2. Retrieves a list of `Invoice` objects associated with the `selectedEmployer` using the `InvoiceDAO.getInstance().list(selectedEmployer)` method.
3. Filters the `invoiceList` by calling the `filterPaymentJob` method, which likely filters the invoices based on the selected job.
4. Iterates through the filtered `invoiceList` and populates a 2D string array (`tableData`) with the relevant invoice data, including the invoice ID, job, amount, and date.
5. Calculates the total amount of all the invoices by iterating through the `invoiceList` and summing the invoice amounts.
6. Sets the table model of the `employerPaymentScrollPane` to the `tableData` array, using the `employerPaymentTableColumns` as the column headers.
7. Adjusts the column widths and alignment of the table, setting the first column (invoice ID) to a fixed width and centering the alignment.
8. Updates the `employerPaymentTotalLabel` with the total amount and the `employerPaymentCountLabel` with the number of records in the table.

The purpose of this method is to provide a comprehensive view of the employer's payment history, including the individual invoices, their details, and the total amount owed. This information is crucial for the employer to manage their financial obligations and track their payments.\\
## Code: 
```
void updateEmployerPaymentTableData() {
		
		if(selectedEmployer != null) {
			
			List<Invoice> invoiceList = InvoiceDAO.getInstance().list(selectedEmployer);
			filterPaymentJob(invoiceList);
			
			String[][] tableData = new String[invoiceList.size()][employerPaymentTableColumns.length];
			BigDecimal totalAmount = new BigDecimal("0.00");
			int i = 0;
			for(Invoice invoice : invoiceList) {
				tableData[i][0] = invoice.getId() + "";
				tableData[i][1] = invoice.getJob().toString();
				tableData[i][2] = invoice.getAmount() + " ₺";
				tableData[i][3] = new SimpleDateFormat("dd.MM.yyyy").format(invoice.getDate());
				totalAmount = totalAmount.add(invoice.getAmount());
				++i;
			}
			
			((JTable)employerPaymentScrollPane.getViewport().getComponent(0)).setModel(new DefaultTableModel(tableData, employerPaymentTableColumns));
			((JTable)employerPaymentScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setPreferredWidth(5);
			((JTable)employerPaymentScrollPane.getViewport().getComponent(0)).setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
			
			DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
			centerRenderer.setHorizontalAlignment( SwingConstants.CENTER );
			((JTable)employerPaymentScrollPane.getViewport().getComponent(0)).getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
			
			employerPaymentTotalLabel.setText("Total " + totalAmount + " ₺");
			employerPaymentCountLabel.setText(invoiceList.size() + " Record");
			
		}
		
	}
```