`decimalControl`: The function of `decimalControl` is to validate that the input string(s) provided follow a specific decimal pattern.

**Code Description**: The `decimalControl` method takes a variable number of string arguments (`String ...args`) and checks if each of them matches a specific decimal pattern. The decimal pattern is defined using a regular expression `"^\\d+(\\.\\d{1,2})?$"`, which matches strings that:

1. Start with one or more digits (`\\d+`)
2. Optionally have a decimal point (`.`) followed by one or two digits (`\\.\\d{1,2}`)
3. End with the end of the string (`$`)

The method initializes a `boolean` variable `result` to `true`. It then iterates through each of the input strings (`args`) and checks if the string matches the decimal pattern using the `Pattern.matcher(arg.replaceAll("\\s+", "")).find()` method. This removes any whitespace characters from the input string before checking the pattern.

The `result` variable is updated to be the logical AND of the current `result` and the match result for the current string. This ensures that the final `result` is `true` only if all the input strings match the decimal pattern.

Finally, the method returns the `result` boolean value, indicating whether all the input strings matched the decimal pattern or not.\\
## Code: 
```
boolean decimalControl(String ...args) {
		Pattern pattern = Pattern.compile("^\\d+(\\.\\d{1,2})?$"); // decimal pattern xxx.xx
		boolean result = true;
		
		for(String arg : args)
			result = result && pattern.matcher(arg.replaceAll("\\s+", "")).find();
		
		return result;
	}
```