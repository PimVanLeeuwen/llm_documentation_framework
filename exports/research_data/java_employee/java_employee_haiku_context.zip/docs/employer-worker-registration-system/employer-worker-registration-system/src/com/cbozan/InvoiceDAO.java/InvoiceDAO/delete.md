`delete`: The function of `delete` is to remove an `Invoice` object from the database.

**Parameters**:
`Invoice invoice`: This parameter represents the `Invoice` object that needs to be deleted from the database.

**Code Description**:
The `delete` method takes an `Invoice` object as a parameter and deletes the corresponding record from the `invoice` table in the database. Here's a breakdown of the code:

1. The method starts by establishing a connection to the database using the `DB.getConnection()` method.
2. It then creates a `PreparedStatement` object with the SQL query `"DELETE FROM invoice WHERE id=?;"`. This query will delete the record from the `invoice` table where the `id` column matches the `id` of the `Invoice` object passed as a parameter.
3. The `setInt(1, invoice.getId())` method is used to set the value of the first parameter (the `?` in the SQL query) to the `id` of the `Invoice` object.
4. The `ps.executeUpdate()` method is called to execute the SQL query and delete the record. The result of the operation is stored in the `result` variable.
5. If the `result` variable is not zero (i.e., the record was successfully deleted), the method removes the `Invoice` object from the `cache` using the `cache.remove(invoice.getId())` method.
6. If an exception occurs during the deletion process, the method prints the error message using `System.out.println(e.getMessage())`.
7. Finally, the method returns `true` if the deletion was successful (i.e., `result` is not zero), and `false` otherwise.

The purpose of this method is to provide a way to delete an `Invoice` object from the database. It ensures that the corresponding record is removed from the database and that the `cache` is updated accordingly.\\
## Code: 
```
boolean delete(Invoice invoice) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM invoice WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, invoice.getId());
			
			result = ps.executeUpdate();
			
			if(result != 0) {
				cache.remove(invoice.getId());
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return result == 0 ? false : true;
		
	}
```