`filterPaymentJob`: The function of `filterPaymentJob` is to filter a list of `Payment` objects based on the `Job` associated with each payment.

**Parameters**:
`List<Payment> paymentList`: This parameter represents a list of `Payment` objects that need to be filtered.

**Code Description**:
The `filterPaymentJob` method takes a `List<Payment> paymentList` as input and filters the list based on the `Job` associated with each `Payment` object. 

The method first checks if the `selectedWorkerPaymentJob` variable is `null`. If it is, the method simply returns without performing any filtering.

If `selectedWorkerPaymentJob` is not `null`, the method creates an `Iterator` to iterate through the `paymentList`. For each `Payment` object in the list, the method checks if the `Job` ID associated with the `Payment` object is different from the `Job` ID of the `selectedWorkerPaymentJob`. If the IDs are different, the method removes the `Payment` object from the list using the `Iterator.remove()` method.

This filtering process ensures that the `paymentList` only contains `Payment` objects that are associated with the `selectedWorkerPaymentJob`.\\
## Code: 
```
void filterPaymentJob(List<Payment> paymentList) {
		if(selectedWorkerPaymentJob == null)
			return;
		
		Iterator<Payment> payment = paymentList.iterator();
		Payment paymentItem;
		while(payment.hasNext()) {
			paymentItem = payment.next();
			if(paymentItem.getJob().getId() != selectedWorkerPaymentJob.getId()) {
				payment.remove();
			}
		}
	}
```