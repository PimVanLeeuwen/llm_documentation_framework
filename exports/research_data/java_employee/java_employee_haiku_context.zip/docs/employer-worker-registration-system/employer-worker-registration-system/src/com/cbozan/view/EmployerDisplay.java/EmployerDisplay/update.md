`update`: The function of `update` is to refresh and update the user interface with the latest data related to the selected employer.

**Code Description**: The `update()` method is responsible for updating various components of the user interface to reflect the current state of the selected employer. Here's a breakdown of what the method does:

1. It sets the object list of the `employerSearchBox` to the list of employers retrieved from the `EmployerDAO` singleton instance.
2. It retrieves the currently selected employer from the `employerCard` and assigns it to the `selectedEmployer` variable.
3. It updates the text of the `employerSearchBox` to display the selected employer's string representation, or an empty string if no employer is selected.
4. It refreshes the data from the `JobDAO` and `InvoiceDAO` singletons.
5. It calls the `updateJobTableData()` method to update the job table data based on the selected employer.
6. It calls the `updateEmployerPaymentTableData()` method to update the employer payment table data based on the selected employer.
7. Finally, it calls the `reload()` method of the `employerCard` to refresh the employer card display.

The purpose of this method is to ensure that the user interface is up-to-date with the latest data related to the selected employer. It retrieves and updates the relevant data from the data access objects (DAOs) and then propagates those changes to the various UI components, such as the job table, employer payment table, and the employer card.

This method is likely called whenever the user interacts with the employer-related functionality, such as selecting a different employer or when new data is added or updated in the system.\\
## Code: 
```
void update() {
		employerSearchBox.setObjectList(EmployerDAO.getInstance().list());
		selectedEmployer = employerCard.getSelectedEmployer();
		employerSearchBox.setText(selectedEmployer == null ? "" : selectedEmployer.toString());
		JobDAO.getInstance().refresh();
		InvoiceDAO.getInstance().refresh();
		updateJobTableData();
		updateEmployerPaymentTableData();
		employerCard.reload();
	}
```