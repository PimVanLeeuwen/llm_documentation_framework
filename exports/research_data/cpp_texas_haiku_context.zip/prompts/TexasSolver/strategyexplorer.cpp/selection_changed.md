# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/strategyexplorer.cpp` \
**Type:** `Method` \
**Method Name:** `selection_changed` \
**Code Content:** \
`void StrategyExplorer::selection_changed(const QItemSelection &selected,
                                         const QItemSelection &deselected){
}`






## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`selection_changed`: The function of `selection_changed` is *FILL IN* 
**Parameters**:\
`const QItemSelection &selected`: *FILL IN* \
`const QItemSelection &deselected`: *FILL IN* \

**Code Description**: *FILL IN*
