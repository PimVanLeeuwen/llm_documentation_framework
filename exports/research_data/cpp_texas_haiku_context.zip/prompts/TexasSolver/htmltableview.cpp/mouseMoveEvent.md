# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/htmltableview.cpp` \
**Type:** `Method` \
**Method Name:** `mouseMoveEvent` \
**Code Content:** \
`void HtmlTableView::mouseMoveEvent(QMouseEvent *event) {
    auto anchor = anchorAt(event->pos());

    if (_mousePressAnchor != anchor) {
        _mousePressAnchor.clear();
    }

    if (_lastHoveredAnchor != anchor) {
        _lastHoveredAnchor = anchor;
        if (!_lastHoveredAnchor.isEmpty()) {
            QApplication::setOverrideCursor(QCursor(Qt::PointingHandCursor));
            emit linkHovered(_lastHoveredAnchor);
        } else {
            QApplication::restoreOverrideCursor();
            emit linkUnhovered();
        }
    }
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/htmltableview.cpp.anchorAt 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`mouseMoveEvent`: The function of `mouseMoveEvent` is *FILL IN* 
**Parameters**:\
`QMouseEvent *event`: *FILL IN* \

**Code Description**: *FILL IN*
