# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/PokerSolver.cpp` \
**Type:** `Method` \
**Method Name:** `PokerSolver` \
**Code Content:** \
`PokerSolver::PokerSolver(string ranks, string suits, string compairer_file,int compairer_file_lines, string compairer_file_bin) {
    vector<string> ranks_vector = string_split(ranks,',');
    vector<string> suits_vector = string_split(suits,',');
    this->deck = Deck(ranks_vector,suits_vector);
    this->compairer = make_shared<Dic5Compairer>(compairer_file,compairer_file_lines,compairer_file_bin);
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/Dic5Compairer.cpp.Dic5Compairer 
 - Explanation:  _This code loads poker hand data from a file into memory, checks its consistency using a hash function, and converts it to two separate maps for flush and non-flush hands. It uses various helper functions to split strings, convert card representations, and perform bitwise operations on the data._ 
### TexasSolver/TexasSolver/Deck.cpp.Deck 
 - Explanation:  _This code defines a constructor for a class named `Deck` that initializes a deck of cards based on provided ranks and suits. It populates a vector of card strings and a collection of card objects with unique identifiers._ 
### TexasSolver/TexasSolver/library.cpp.string_split 
 - Explanation:  _This code splits a given string into substrings based on a specified delimiter character, storing each substring in a vector.
The function iterates through the input string, adding each sequence of characters between delimiters to the output vector._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`PokerSolver`: The function of `PokerSolver` is *FILL IN* 
**Parameters**:\
`string ranks`: *FILL IN* \
`string suits`: *FILL IN* \
`string compairer_file`: *FILL IN* \
`int compairer_file_lines`: *FILL IN* \
`string compairer_file_bin`: *FILL IN* \

**Code Description**: *FILL IN*
