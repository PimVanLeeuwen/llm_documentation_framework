# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/PokerSolver.cpp` \
**Type:** `Method` \
**Method Name:** `build_game_tree` \
**Code Content:** \
`void PokerSolver::build_game_tree(
        float oop_commit,
        float ip_commit,
        int current_round,
        int raise_limit,
        float small_blind,
        float big_blind,
        float stack,
        GameTreeBuildingSettings buildingSettings,
        float allin_threshold
){
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(
            this->deck,
            oop_commit,
            ip_commit,
            current_round,
            raise_limit,
            small_blind,
            big_blind,
            stack,
            buildingSettings,
            allin_threshold
    );
    this->game_tree = game_tree;
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/GameTree.cpp.GameTree 
 - Explanation:  _This code defines a constructor for the `GameTree` class, which initializes its member variables from input parameters to build a game tree data structure in Texas Hold'em poker. The constructor creates a root node and recursively builds the game tree based on the provided settings and rules._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`build_game_tree`: The function of `build_game_tree` is *FILL IN* 
**Parameters**:\
`float oop_commit`: *FILL IN* \
`float ip_commit`: *FILL IN* \
`int current_round`: *FILL IN* \
`int raise_limit`: *FILL IN* \
`float small_blind`: *FILL IN* \
`float big_blind`: *FILL IN* \
`float stack`: *FILL IN* \
`GameTreeBuildingSettings buildingSettings`: *FILL IN* \
`float allin_threshold`: *FILL IN* \

**Code Description**: *FILL IN*
