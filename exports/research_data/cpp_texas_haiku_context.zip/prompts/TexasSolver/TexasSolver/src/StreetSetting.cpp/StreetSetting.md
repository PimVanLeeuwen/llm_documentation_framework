# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/StreetSetting.cpp` \
**Type:** `Method` \
**Method Name:** `StreetSetting` \
**Code Content:** \
`StreetSetting::StreetSetting(vector<float> bet_sizes, vector<float> raise_sizes, vector<float> donk_sizes,
                             bool allin) {
    this->bet_sizes = bet_sizes;
    this->raise_sizes = raise_sizes;
    this->donk_sizes = donk_sizes;
    this->allin = allin;
}`






## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`StreetSetting`: The function of `StreetSetting` is *FILL IN* 
**Parameters**:\
`vector<float> bet_sizes`: *FILL IN* \
`vector<float> raise_sizes`: *FILL IN* \
`vector<float> donk_sizes`: *FILL IN* \
`bool allin`: *FILL IN* \

**Code Description**: *FILL IN*
