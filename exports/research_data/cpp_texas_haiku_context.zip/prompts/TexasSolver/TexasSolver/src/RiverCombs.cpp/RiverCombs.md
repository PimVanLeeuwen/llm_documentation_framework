# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/RiverCombs.cpp` \
**Type:** `Method` \
**Method Name:** `RiverCombs` \
**Code Content:** \
`RiverCombs::RiverCombs(vector<int> board, PrivateCards private_cards, int rank, int reach_prob_index) {
    this->board = board;
    this->rank = rank;
    this->private_cards = private_cards;
    this->reach_prob_index = reach_prob_index;
}`






## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`RiverCombs`: The function of `RiverCombs` is *FILL IN* 
**Parameters**:\
`vector<int> board`: *FILL IN* \
`PrivateCards private_cards`: *FILL IN* \
`int rank`: *FILL IN* \
`int reach_prob_index`: *FILL IN* \

**Code Description**: *FILL IN*
