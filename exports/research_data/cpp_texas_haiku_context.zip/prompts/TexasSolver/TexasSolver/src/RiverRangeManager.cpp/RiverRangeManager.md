# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/RiverRangeManager.cpp` \
**Type:** `Method` \
**Method Name:** `RiverRangeManager` \
**Code Content:** \
`RiverRangeManager::RiverRangeManager(shared_ptr<Compairer> handEvaluator) {
    this->handEvaluator = std::move(handEvaluator);
    this->maplock = std::make_shared<std::mutex>();
}`






## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`RiverRangeManager`: The function of `RiverRangeManager` is *FILL IN* 
**Parameters**:\
`shared_ptr<Compairer> handEvaluator`: *FILL IN* \

**Code Description**: *FILL IN*
