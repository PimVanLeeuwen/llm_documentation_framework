# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/src/qsolverjob.cpp` \
**Type:** `Method` \
**Method Name:** `estimate_tree_memory` \
**Code Content:** \
`long long QSolverJob::estimate_tree_memory(QString range1,QString range2,QString board){
    qDebug().noquote() << tr("Estimating tree memory..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        return ps_holdem.estimate_tree_memory(range1,range2,board);
    }else if(this->mode == Mode::SHORTDECK){
        return ps_shortdeck.estimate_tree_memory(range1,range2,board);
    }
    return 0;
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/qsolverjob.cpp.estimate_tree_memory 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`estimate_tree_memory`: The function of `estimate_tree_memory` is *FILL IN* 
**Parameters**:\
`QString range1`: *FILL IN* \
`QString range2`: *FILL IN* \
`QString board`: *FILL IN* \

**Code Description**: *FILL IN*
