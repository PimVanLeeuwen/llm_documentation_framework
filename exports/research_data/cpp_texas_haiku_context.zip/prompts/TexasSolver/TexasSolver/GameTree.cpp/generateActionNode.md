# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/GameTree.cpp` \
**Type:** `Method` \
**Method Name:** `generateActionNode` \
**Code Content:** \
`shared_ptr<ActionNode>
GameTree::generateActionNode(json meta, vector<string> childrens_actions, vector<json> childrens_nodes, const string& round,
                             shared_ptr<GameTreeNode> parent) {
    if(childrens_actions.size() != childrens_nodes.size()){
        throw runtime_error(
                tfm::format(
                        "mismatch when generate ActionNode, childrens_action length %s children_nodes length %s",
                        childrens_actions.size(),
                        childrens_nodes.size()
                ));
    }

    if(! (   round == "preflop"
          || round == "flop"
          || round == "turn"
          || round == "river"
          )
            ){
        throw runtime_error(tfm::format("round %s not found",round));
    }

    vector<GameActions> actions;
    vector<shared_ptr<GameTreeNode>> childrens;

    // 遍历所有children actions 来生成GameAction 的list，用于初始化ActionNode
    for(std::size_t i = 0;i < childrens_actions.size();i++){
        string one_action = childrens_actions[i];
        json one_children_map = childrens_nodes[i];
        if(one_action.empty()) throw runtime_error("action is null");

        GameTreeNode::PokerActions action;
        double amount = -1;
        if(one_action == "check"){
            action = GameTreeNode::PokerActions::CHECK;
        }
        else if(one_action == "fold"){
            action = GameTreeNode::PokerActions::FOLD;
        }
        else if(one_action == "call"){
            action = GameTreeNode::PokerActions::CALL;
        }
        else{
            if(one_action.find("bet")  != string::npos){
                vector<string> action_sp = string_split(one_action,'_');
                if(action_sp.size() != 2)
                    throw runtime_error(tfm::format("bet action sp length %s",action_sp.size()));
                string action_str = action_sp[0];
                action = GameTreeNode::PokerActions::BET;
                if(!(action_str == "bet")) throw runtime_error(tfm::format("Action %s not found",action_str));
                amount = stod(action_sp[1]);

            }else if (one_action.find("raise") != string::npos){
                vector<string> action_sp = string_split(one_action,'_');
                if(action_sp.size() != 2)
                    throw runtime_error(tfm::format("raise action sp length %s",action_sp.size()));
                string action_str = action_sp[0];
                action = GameTreeNode::PokerActions::RAISE;
                if(!(action_str == "raise"))
                    throw runtime_error(tfm::format("Action %s not found",action_str));
                amount = stod(action_sp[1]);
            }else{
                throw runtime_error(tfm::format("%s action not found",one_action));
            }
        }
        shared_ptr<GameTreeNode> one_children_node = recurrentGenerateTreeNode(one_children_map,parent);
        childrens.push_back(one_children_node);

        GameActions game_action = GameActions(action,amount);
        actions.push_back(game_action);
    }
    int player = meta["player"];
    double pot = meta["pot"];
    if(childrens.size() != actions.size()){
        throw runtime_error(tfm::format("childrens length %s, actions length %s"
                ,childrens.size()
                ,actions.size()));
    }
    GameTreeNode::GameRound game_round = strToGameRound(round);
    shared_ptr<ActionNode> actionNode = make_shared<ActionNode>(actions,childrens,player,game_round,pot,parent);
    for(const shared_ptr<GameTreeNode>& one_node: childrens){
        one_node->setParent(std::dynamic_pointer_cast<GameTreeNode>(actionNode));
    }
    return actionNode;

}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/GameTree.cpp.strToGameRound 
 - Explanation:  _This code defines a method `strToGameRound` that converts a string representation of a game round to its corresponding enum value in the `GameTreeNode::GameRound` type. The method throws an exception if the input string does not match any known game round._ 
### TexasSolver/TexasSolver/library.cpp.string_split 
 - Explanation:  _This code splits a given string into substrings based on a specified delimiter character, storing each substring in a vector.
The function iterates through the input string, adding each sequence of characters between delimiters to the output vector._ 
### TexasSolver/TexasSolver/src/ActionNode.cpp.ActionNode 
 - Explanation:  _This code defines a constructor for the `ActionNode` class, which initializes its member variables from input parameters. The constructor takes several inputs and assigns them to corresponding member variables in the object being constructed._ 
### TexasSolver/TexasSolver/src/GameActions.cpp.GameActions 
 - Explanation:  _This code defines a constructor for the `GameActions` class, which initializes its member variables based on input parameters related to poker game actions and betting amounts. The constructor enforces specific rules regarding valid action and amount combinations._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.setParent 
 - Explanation:  _This code sets the parent node in a game tree data structure. It assigns a shared pointer to another GameTreeNode instance as the parent of the current node._ 
### TexasSolver/TexasSolver/GameTree.cpp.recurrentGenerateTreeNode 
 - Explanation:  _This code generates game tree nodes based on provided metadata and round information, utilizing a recursive approach to construct various types of nodes such as action, showdown, terminal, and chance nodes. The method `recurrentGenerateTreeNode` serves as an entry point for this process, handling different node types and their respective generation methods._ 
### TexasSolver/TexasSolver/Card.cpp.empty 
 - Explanation:  _This code defines a method `empty` in the `Card` class that checks if a card is empty or not based on its value. The method returns true if the card is empty and false otherwise._ 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.GameTreeNode 
 - Explanation:  _This code defines a constructor for a `GameTreeNode` class, which initializes its properties based on input parameters. The constructor takes three inputs: a game round, a pot value, and a parent node reference._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`generateActionNode`: The function of `generateActionNode` is *FILL IN* 
**Parameters**:\
`json meta`: *FILL IN* \
`vector<string> childrens_actions`: *FILL IN* \
`vector<json> childrens_nodes`: *FILL IN* \
`const string& round`: *FILL IN* \
`shared_ptr<GameTreeNode> parent`: *FILL IN* \

**Code Description**: *FILL IN*
