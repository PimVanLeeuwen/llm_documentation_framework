# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/GameTree.cpp` \
**Type:** `Method` \
**Method Name:** `get_possible_bets` \
**Code Content:** \
`vector<double> GameTree::get_possible_bets(shared_ptr<ActionNode> root, int player, int next_player, Rule rule,
                                           GameTree::BetType betType) {
    if(player != 1 - next_player)throw runtime_error("player error, player and next player not match");
    StreetSetting streetSetting = this->getSettings(root->getRound(),player,rule.build_settings);
    vector<double> bets_ratios;
    bool all_in = streetSetting.allin;
    vector<float> bets_from_rule;
    if(betType == BetType::BET)bets_from_rule = streetSetting.bet_sizes;
    else if(betType == BetType::DONK)bets_from_rule = streetSetting.donk_sizes;
    else if(betType == BetType::RAISE)bets_from_rule = streetSetting.raise_sizes;
    else throw runtime_error("bet type unknown");
    for(float one_bet:bets_from_rule){
        bets_ratios.push_back((double) one_bet / 100);
    }
    float pot = max(rule.ip_commit,rule.oop_commit) * 2;
    vector<double> possible_amounts;
    for(double one_bet: bets_ratios){
        double amount;
        if(rule.oop_commit == rule.small_blind){
            // 当德州扑克开始时，在第一个玩家动作时（sb位置玩家）,视作对手先下注一个bb,这个时候下注要扣除自己的sb
            amount = one_bet * rule.big_blind  - rule.small_blind;
            amount = this->round_nearest(amount, (double) rule.small_blind);
        }else if(rule.ip_commit == rule.big_blind && rule.oop_commit == rule.big_blind){
            // 当德州扑克开始时，在第一个玩家call 的时候第二个玩家要 raise的时候,需要特殊处理
            amount = one_bet * rule.big_blind;
            amount = this->round_nearest(amount, (double) rule.small_blind);
        }else{
            amount = one_bet * pot;
            amount = this->round_nearest(amount, (double) rule.big_blind);
        }
        if(betType == BetType::RAISE)amount += (rule.get_commit(next_player) - rule.get_commit(player));
        if(amount + rule.get_commit(player) > rule.initial_effective_stack * rule.allin_threshold)amount = (double) (rule.stack - rule.get_commit(player)); // if larget than allin thres then allin
        if(amount < rule.stack - rule.get_commit(player) && amount > 0) {
            possible_amounts.push_back(amount);
        }else if(amount == rule.stack - rule.get_commit(player)){
            possible_amounts.push_back(amount);
        }
        else if(amount > rule.stack - rule.get_commit(player)){
            possible_amounts.push_back(rule.stack - rule.get_commit(player));
        }
    }
    if(all_in) possible_amounts.push_back((double) (rule.stack - rule.get_commit(player)));

    if (rule.get_commit(player) != rule.small_blind){
        // 一开始的possible bet amount不能简单取整
        vector<double> tmp_vector;
        for(double val:possible_amounts){
            if(val > 0)tmp_vector.push_back(int(val));
        }
        possible_amounts = tmp_vector;
    }
    if (rule.get_commit(player) == rule.small_blind){
        vector<double> tmp_vector;
        for(double val:possible_amounts){
            if(val >= rule.big_blind)tmp_vector.push_back(val);
        }
        possible_amounts = tmp_vector;
    }else if (rule.get_commit(player) == rule.big_blind && rule.get_commit(next_player) == rule.big_blind){
        vector<double> tmp_vector;
        for(double val:possible_amounts){
            if(val >= rule.big_blind)tmp_vector.push_back(val);
        }
        possible_amounts = tmp_vector;
    }else{
        float gap = rule.get_commit(next_player) - rule.get_commit(player);
        vector<double> tmp_vector;
        for(double val:possible_amounts){
            if(val >= gap * 2)tmp_vector.push_back(val);
        }
        possible_amounts = tmp_vector;
    }
    vector<double> tmp_vector;
    for(double val:possible_amounts){
        if(
                (val > rule.get_commit(next_player) - rule.get_commit(player)) &&
                (val <= rule.stack - rule.get_commit(player)) &&
                find(tmp_vector.begin(),tmp_vector.end(), val) == tmp_vector.end()
        )tmp_vector.push_back(val);
    }
    possible_amounts = tmp_vector;
    return possible_amounts;
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/src/GameTreeNode.cpp.getRound 
 - Explanation:  _This code retrieves the current round number from a GameTreeNode object. The getRound method returns the round value stored in the object._ 
### TexasSolver/TexasSolver/GameTree.cpp.getSettings 
 - Explanation:  _This code defines a method `getSettings` in the `GameTree` class that returns specific settings based on the game round and player. The method uses enum values to determine the correct settings to return._ 
### TexasSolver/TexasSolver/GameTree.cpp.round_nearest 
 - Explanation:  _This code defines a method called `round_nearest` in the `GameTree` class, which rounds a given number to the nearest multiple of another specified number. The method takes two parameters: `number` and `round_num`._ 
### TexasSolver/TexasSolver/src/Rule.cpp.get_commit 
 - Explanation:  _This code defines a method `get_commit` in the `Rule` class that returns a float value based on the input player number. The method throws an exception if the player number is unknown._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`get_possible_bets`: The function of `get_possible_bets` is *FILL IN* 
**Parameters**:\
`shared_ptr<ActionNode> root`: *FILL IN* \
`int player`: *FILL IN* \
`int next_player`: *FILL IN* \
`Rule rule`: *FILL IN* \
`GameTree::BetType betType`: *FILL IN* \

**Code Description**: *FILL IN*
