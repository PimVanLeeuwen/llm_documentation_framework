# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/library.cpp` \
**Type:** `Method` \
**Method Name:** `random` \
**Code Content:** \
`int random(int min, int max) //range : [min, max)
{
    return min + rand() % (( max ) - min);
}`






## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`random`: The function of `random` is *FILL IN* 
**Parameters**:\
`int min`: *FILL IN* \
`int max`: *FILL IN* \

**Code Description**: *FILL IN*
