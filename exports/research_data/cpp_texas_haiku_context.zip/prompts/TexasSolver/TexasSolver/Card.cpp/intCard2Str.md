# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/Card.cpp` \
**Type:** `Method` \
**Method Name:** `intCard2Str` \
**Code Content:** \
`string Card::intCard2Str(int card){
    int rank = card / 4 + 2;
    int suit = card - (rank-2)*4;
    return Card::rankToString(rank) + Card::suitToString(suit);
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/Card.cpp.suitToString 
 - Explanation:  _This code defines a method `suitToString` in the `Card` class that converts an integer suit value to its corresponding string representation. The method uses a switch statement to determine which string to return based on the input suit value._ 
### TexasSolver/TexasSolver/Card.cpp.rankToString 
 - Explanation:  _This code defines a method `rankToString` in the `Card` class that converts a card rank integer to its corresponding string representation. The method uses a switch statement to map each rank value to its respective string._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`intCard2Str`: The function of `intCard2Str` is *FILL IN* 
**Parameters**:\
`int card`: *FILL IN* \

**Code Description**: *FILL IN*
