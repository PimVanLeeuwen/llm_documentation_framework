# PROMPT
## Information
**Project Structure:** `TexasSolver` \
**File Path:** `TexasSolver/TexasSolver/Card.cpp` \
**Type:** `Method` \
**Method Name:** `Card` \
**Code Content:** \
`Card::Card(string card){
    this->card = card;
    this->card_int = Card::strCard2int(this->card);
    this->card_number_in_deck = -1;
}`

## Calls 
 This code calls the following methods within the repository: 
### TexasSolver/TexasSolver/Card.cpp.strCard2int 
 - Explanation:  _This code defines a method `strCard2int` in the `Card` class that converts a string representation of a card to its corresponding integer value. The conversion involves mapping rank and suit characters to their respective integer values using helper methods `rankToInt` and `suitToInt`._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`Card`: The function of `Card` is *FILL IN* 
**Parameters**:\
`string card`: *FILL IN* \

**Code Description**: *FILL IN*
