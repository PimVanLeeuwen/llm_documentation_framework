`getNumberInDeckInt`: The function returns the card number in deck as an integer.

**Code Description**: This method retrieves and returns the card's position within a deck, represented by an integer. It checks if the `card_number_in_deck` member variable is set to -1, which indicates an invalid or uninitialized value. If this condition is met, it throws a runtime error with a descriptive message. Otherwise, it returns the stored card number in deck as an integer.\\
## Code: 
```
int Card::getNumberInDeckInt(){
    if(this->card_number_in_deck == -1)throw runtime_error("card number in deck cannot be -1");
    return this->card_number_in_deck;
}
```