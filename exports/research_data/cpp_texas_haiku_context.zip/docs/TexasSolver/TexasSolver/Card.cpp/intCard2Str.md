`intCard2Str`: The function of `intCard2Str` is to convert an integer representation of a playing card into its string equivalent.

**Parameters**:
`int card`: This parameter represents the integer value of a playing card, where the first digit (0-3) corresponds to the suit and the second digit (1-13) corresponds to the rank.

**Code Description**: The function uses bitwise operations to extract the suit and rank from the input integer. It then calls the `rankToString` and `suitToString` methods to convert these values into their string representations, which are concatenated together to form the final output string.\\
## Code: 
```
string Card::intCard2Str(int card){
    int rank = card / 4 + 2;
    int suit = card - (rank-2)*4;
    return Card::rankToString(rank) + Card::suitToString(suit);
}
```