`long2boardCards`: The function of `long2boardCards` is to convert a 64-bit unsigned integer representing a long into a vector of Card objects, where each Card object represents a card in the board.

**Parameters**:\
`uint64_t board_long`: This parameter is a 64-bit unsigned integer that represents the long value to be converted into a vector of Card objects.

**Code Description**: The function `long2boardCards` first calls the method `long2board` to convert the input long value into a vector of integers, where each integer represents a card in the deck. It then creates a new vector of Card objects and populates it with Card objects created from the corresponding integers using the method `intCard2Str`. The function checks if the size of the resulting vector is within the valid range (1 to 7) and throws an exception if not. Finally, it returns the vector of Card objects.\\
## Code: 
```
vector<Card> Card::long2boardCards(uint64_t board_long){
        vector<int> board = long2board(board_long);
        vector<Card> board_cards(board.size());
        for(std::size_t i = 0;i < board.size();i ++){
            int one_board = board[i];
            board_cards[i] = Card(intCard2Str(one_board));
        }
        if (board_cards.size() < 1 || board_cards.size() > 7){
            throw runtime_error(tfm::format("board length not correct, board length %s",board_cards.size()));
        }
        vector<Card> retval(board_cards.size());
        for(std::size_t i = 0;i < board_cards.size();i ++){
            retval[i] = board_cards[i];
        }
        return retval;
}
```