`card2int`: The function of `card2int` is to convert a Card object into its corresponding integer value.
**Parameters**: 
`Card card`: A Card object that contains the rank and suit information.
**Code Description**: This method calls the `getCard` method on the input `Card` object, which returns the string representation of the card. The returned string is then passed to the `strCard2int` method, which converts it into an integer value representing the card's position in a standard deck ordering.\\
## Code: 
```
int Card::card2int(Card card) {
    return strCard2int(card.getCard());
}
```