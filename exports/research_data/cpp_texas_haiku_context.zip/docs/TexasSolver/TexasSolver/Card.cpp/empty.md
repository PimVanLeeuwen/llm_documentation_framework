## Expected output
`empty`: The function of `empty` is to check if a card is empty or not. 

**Code Description**: This method checks the state of a Card object, returning true if it represents an "empty" card and false otherwise. It does this by comparing the card's value (stored in the `card` member variable) with the string "empty". If they match, the function returns true; otherwise, it returns false.\\
## Code: 
```
bool Card::empty(){
    if(this->card == "empty")return true;
    else return false;
}
```