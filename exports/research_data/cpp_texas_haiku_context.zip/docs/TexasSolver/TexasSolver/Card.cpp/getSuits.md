## getSuits: 
The function of `getSuits` is to return a vector containing the suits of a card in a standard deck.

## Code Description:
The `getSuits` method returns a vector of strings, each representing one of the four suits in a standard deck of cards: "c" for clubs, "d" for diamonds, "h" for hearts, and "s" for spades.\\
## Code: 
```
vector<string> Card::getSuits(){
    return {"c","d","h","s"};
}
```