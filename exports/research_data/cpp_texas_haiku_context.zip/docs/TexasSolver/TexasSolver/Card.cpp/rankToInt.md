**Functionality:**

`rankToInt`: Converts a card rank from a character to an integer value.

**Parameters**:

`char rank`: The character representation of the card rank (e.g., '2', '3', ..., 'A').

**Code Description**: This function uses a switch statement to map each possible card rank character to its corresponding integer value. If the input character is not recognized, it returns 2 as a default value.\\
## Code: 
```
int Card::rankToInt(char rank)
{
    switch(rank)
    {
        case '2': return 2;
        case '3': return 3;
        case '4': return 4;
        case '5': return 5;
        case '6': return 6;
        case '7': return 7;
        case '8': return 8;
        case '9': return 9;
        case 'T': return 10;
        case 'J': return 11;
        case 'Q': return 12;
        case 'K': return 13;
        case 'A': return 14;
        default: return 2;
    }
}
```