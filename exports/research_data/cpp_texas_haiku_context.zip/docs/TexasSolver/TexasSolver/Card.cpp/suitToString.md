`suitToString`: The function of `suitToString` is to convert an integer representing a card suit into its corresponding string representation.

**Parameters**:\
`int suit`: This parameter represents the integer value of a card suit, where 0 corresponds to "c" (clubs), 1 corresponds to "d" (diamonds), 2 corresponds to "h" (hearts), and 3 corresponds to "s" (spades). If any other value is passed, it defaults to "c".

**Code Description**: The `suitToString` function uses a switch statement to determine which string representation of the suit to return based on the input integer. It then returns this string representation.\\
## Code: 
```
string Card::suitToString(int suit)
{
    switch(suit)
    {
        case 0: return "c";
        case 1: return "d";
        case 2: return "h";
        case 3: return "s";
        default: return "c";
    }
}
```