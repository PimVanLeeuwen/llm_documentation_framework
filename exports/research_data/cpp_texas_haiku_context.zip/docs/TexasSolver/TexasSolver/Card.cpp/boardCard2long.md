`boardCard2long`: The function of `boardCard2long` is to convert a 0-based index representing a card in a standard 52-card deck to a unique long integer value.

**Parameters**: 
`Card& card`: This parameter is an input reference to the Card object, which contains the card's information.

**Code Description**: The function uses the `boardInt2long` method from the Card class to perform the conversion. It takes the result of calling `getCardInt` on the provided Card object and passes it to `boardInt2long`, returning the resulting long integer value.\\
## Code: 
```
uint64_t Card::boardCard2long(Card& card){
    return Card::boardInt2long(card.getCardInt());
}
```