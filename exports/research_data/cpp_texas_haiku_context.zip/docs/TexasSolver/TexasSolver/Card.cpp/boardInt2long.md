**Functionality:** 

The function `boardInt2long` converts a given integer representing a card in a poker game to its corresponding long integer value.

**Parameters:**

*   `int board`: The input parameter is an integer representing the card's position in a 52-card deck, where each card has a unique ID from 0 to 51.

**Code Description:** 

The function takes an integer `board` as input and returns its corresponding long integer value. It first checks if the input `board` is within the valid range of 0 to 51 (inclusive). If it's not, it throws a runtime error with a message indicating that the card with the given ID was not found.

If the input is valid, it uses bitwise left shift operation to return a long integer value corresponding to the input `board`. The result is a unique long integer for each card in the deck.\\
## Code: 
```
uint64_t Card::boardInt2long(int board){
    // 这里hard code了一副扑克牌是52张
    if(board < 0 || board >= 52){
        throw runtime_error(tfm::format("Card with id %s not found",board));
    }
    // uint64_7 的range 在0 ~ + 2^ 64之间,所以不用太担心溢出问题
    return ((uint64_t)(1) << board);
}
```