## toFormattedString: 
The function of `toFormattedString` is to convert a card's string representation into a formatted string with suit symbols.

## Code Description:
This method, `Card::toFormattedString`, takes the card's string representation and replaces specific characters with their corresponding suit symbols. The replacements are as follows:

- "c" is replaced with ♣️ (club symbol)
- "d" is replaced with ♦️ (diamond symbol)
- "h" is replaced with ♥️ (heart symbol)
- "s" is replaced with ♠️ (spade symbol)

The function then returns the modified string as a `std::string`.\\
## Code: 
```
string Card::toFormattedString() {
    QString qString = QString::fromStdString(this->card);
    qString = qString.replace("c", "♣️");
    qString = qString.replace("d", "♦️");
    qString = qString.replace("h", "♥️");
    qString = qString.replace("s", "♠️");
    return qString.toStdString();
}
```