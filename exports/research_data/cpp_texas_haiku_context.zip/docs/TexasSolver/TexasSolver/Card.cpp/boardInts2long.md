`boardInts2long`: The function of `boardInts2long` is to convert a vector of integers representing a poker hand into a single 64-bit unsigned integer.

**Parameters**:\
`const vector<int>& board`: This parameter represents the input vector of integers, where each integer corresponds to a card in the poker hand. The size of the vector must be between 1 and 7 (inclusive), as indicated by the function's error handling.

**Code Description**: 
The `boardInts2long` function takes a vector of integers representing a poker hand and returns a single 64-bit unsigned integer. It first checks if the input vector has a valid size, throwing an exception if it does not. Then, for each card in the vector, it calculates its contribution to the final result by shifting the value 1 to the left by the number of bits corresponding to that card's ID (0-51). The contributions are summed up and returned as the final result.\\
## Code: 
```
uint64_t Card::boardInts2long(const vector<int>& board){
    if(board.size() < 1 || board.size() > 7){
        throw runtime_error(tfm::format("Card length incorrect: %s",board.size()));
    }
    uint64_t board_long = 0;
    for(int one_card: board){
        // 这里hard code了一副扑克牌是52张
        if(one_card < 0 || one_card >= 52){
            throw runtime_error(tfm::format("Card with id %s not found",one_card));
        }
        // uint64_7 的range 在0 ~ + 2^ 64之间,所以不用太担心溢出问题
        board_long += ((uint64_t)(1) << one_card);
    }
    return board_long;
}
```