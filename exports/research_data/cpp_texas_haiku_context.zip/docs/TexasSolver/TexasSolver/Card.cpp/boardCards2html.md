The function of `boardCards2html` is to convert a list of card objects into an HTML string.

**Parameters**:\
`vector<Card>& cards`: A reference to a vector of Card objects, where each Card object represents a playing card with its suit and value.

**Code Description**: The method iterates over the input vector of Card objects, checks if each card is empty (i.e., has no value), and if not, appends the card's HTML representation to a string. The resulting HTML string is then returned.\\
## Code: 
```
QString Card::boardCards2html(vector<Card>& cards){
    QString ret_html = "";
    for(auto one_card:cards){
        if(one_card.empty())continue;
        ret_html += one_card.toFormattedHtml();
    }
    return ret_html;
}
```