`Card`: The function of `Card` is to initialize a new Card object with the given string representation of a card.
**Parameters**: 
`string card`: This parameter represents the string representation of a card, which can be in the format "Ace of Hearts", "King of Diamonds", etc.

**Code Description**: The code initializes a new Card object by setting its `card` attribute to the input string and converting it to an integer value using the `strCard2int` method. The `card_int` attribute is set to this integer value, representing the card's rank and suit in a numerical format.\\
## Code: 
```
Card::Card(string card){
    this->card = card;
    this->card_int = Card::strCard2int(this->card);
    this->card_number_in_deck = -1;
}
```