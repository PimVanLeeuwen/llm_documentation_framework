`rankToString`: The function of `rankToString` is to convert a given card rank into its corresponding string representation.

**Parameters**:\
`int rank`: This parameter represents the numerical value of a card's rank, ranging from 2 to 14 (inclusive), where each integer corresponds to a specific card rank in a standard deck of cards.

**Code Description**: The `rankToString` function utilizes a switch statement to map the input `rank` value to its corresponding string representation. It returns a string that matches the numerical rank, such as "2", "3", "4", and so on up to "A" for Ace (rank 14). If an invalid or out-of-range value is provided, it defaults to returning "2".\\
## Code: 
```
string Card::rankToString(int rank)
{
    switch(rank)
    {
        case 2: return "2";
        case 3: return "3";
        case 4: return "4";
        case 5: return "5";
        case 6: return "6";
        case 7: return "7";
        case 8: return "8";
        case 9: return "9";
        case 10: return "T";
        case 11: return "J";
        case 12: return "Q";
        case 13: return "K";
        case 14: return "A";
        default: return "2";
    }
}
```