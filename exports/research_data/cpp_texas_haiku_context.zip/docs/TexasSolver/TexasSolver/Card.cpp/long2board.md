`long2board`: The function of `long2board` is to convert a 64-bit unsigned integer (`uint64_t`) representing a binary long value into a vector of integers, where each integer represents the index of a card in a standard deck.

**Parameters**:\
`uint64_t board_long`: This parameter is a 64-bit unsigned integer that contains the binary representation of the long value to be converted. The bits are processed from right to left (i.e., least significant bit first).

**Code Description**: 
The function iterates over each bit in the `board_long` integer, starting from the least significant bit. If the current bit is 1, it adds the corresponding card index (0-51) to a vector called `board`. The process continues until all bits have been processed. After that, it checks if the size of the `board` vector is within the expected range (1-7). If not, it throws an exception with a message indicating that the board length is incorrect. Finally, it returns the populated `board` vector.\\
## Code: 
```
vector<int> Card::long2board(uint64_t board_long) {
    vector<int> board;
    board.reserve(7);
    for(int i = 0;i < 52;i ++){
        // 看二进制最后一位是否为1
        if((board_long & 1) == 1){
            board.push_back(i);
        }
        board_long = board_long >> 1;
    }
    if (board.size() < 1 || board.size() > 7){
        throw runtime_error(tfm::format("board length not correct, board length %s",board.size()));
    }
    return board;
}
```