## toFormattedHtml: 
The function of `toFormattedHtml` is to format a card's value as HTML, replacing the first letter with a corresponding suit symbol.

## Code Description:
This method takes no arguments and returns a QString. It appears to be part of a class called Card, which likely represents a playing card in a deck. The code iterates over the possible values of a card (c, d, h, s) and replaces each one with an HTML span element containing a Unicode character representing the corresponding suit symbol.\\
## Code: 
```
QString Card::toFormattedHtml() {
    QString qString = QString::fromStdString(this->card);
    if(qString.contains("c"))
        qString = qString.replace("c", QString::fromLocal8Bit("<span style=\"color:black;\">&#9827;<\/span>"));
    else if(qString.contains("d"))
        qString = qString.replace("d", QString::fromLocal8Bit("<span style=\"color:red;\">&#9830;<\/span>"));
    else if(qString.contains("h"))
        qString = qString.replace("h", QString::fromLocal8Bit("<span style=\"color:red;\">&#9829;<\/span>"));
    else if(qString.contains("s"))
        qString = qString.replace("s", QString::fromLocal8Bit("<span style=\"color:black;\">&#9824;<\/span>"));
    return qString;
}
```