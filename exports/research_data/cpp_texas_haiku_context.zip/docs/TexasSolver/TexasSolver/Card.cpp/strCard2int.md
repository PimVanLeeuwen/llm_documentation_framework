`strCard2int`: Converts a string representation of a playing card to its corresponding integer value.

**Parameters**:
`string card`: A string containing the rank and suit of a playing card, e.g., "A" or "K".

**Code Description**: The function takes a string `card` as input, extracts the rank and suit characters from it, and returns an integer value representing the card's position in a standard deck. It uses two helper functions, `rankToInt` and `suitToInt`, to convert the rank and suit characters to their respective integer values. If the input string is not of length 2, the function throws a runtime error.\\
## Code: 
```
int Card::strCard2int(string card) {
    char rank = card.at(0);
    char suit = card.at(1);
    if(card.length() != 2){
        throw runtime_error( tfm::format("card %s not found",card));
    }
    return (rankToInt(rank) - 2) * 4 + suitToInt(suit);
}
```