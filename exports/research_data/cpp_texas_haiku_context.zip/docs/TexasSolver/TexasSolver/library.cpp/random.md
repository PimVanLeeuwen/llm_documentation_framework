`random`: The function generates a random integer within a specified range.
**Parameters**:
`int min`: The minimum value (inclusive) of the desired range.
`int max`: The maximum value (exclusive) of the desired range.

**Code Description**: This function uses the `rand()` function to generate a random number, and then adds it to the minimum value (`min`) to ensure that the generated number falls within the specified range. The `% ((max) - min)` operation is used to prevent the generated number from exceeding the maximum value (`max`).\\
## Code: 
```
int random(int min, int max) //range : [min, max)
{
    return min + rand() % (( max ) - min);
}
```