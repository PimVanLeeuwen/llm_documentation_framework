**Expected Output**

`string_split`: The function of `string_split` is to split a given string into substrings based on a specified delimiter character.
**Parameters**:
`string strin`: This parameter represents the input string that needs to be split.
`char split`: This parameter specifies the delimiter character used for splitting the input string.

**Code Description**: The function uses a stringstream to iterate through the input string, adding each sequence of characters between delimiters to a vector.\\
## Code: 
```
vector<string> string_split(string strin,char split){
    vector<string> retval;
    stringstream ss(strin);
    string token;
    while (getline(ss,token, split))
    {
        retval.push_back(token);
    }
    return retval;
}
```