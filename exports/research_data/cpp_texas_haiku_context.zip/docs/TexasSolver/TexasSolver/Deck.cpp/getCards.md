`getCards`: The function of `getCards` is to return a reference to the vector of cards in the deck.

**Code Description**: This method, `getCards`, is part of the `Deck` class and serves as an accessor for the internal data structure representing the collection of cards. It returns a reference to the `cards` vector, allowing external access to the contents of the deck without modifying it. The function does not perform any operations on the data; it simply provides a view into the existing set of cards.\\
## Code: 
```
vector<Card>& Deck::getCards() {
    return this->cards;
}
```