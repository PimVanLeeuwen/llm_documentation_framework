**Deck**: The function of `Deck` is to initialize a deck of cards with the given ranks and suits.

**Parameters**:
`const vector<string>& ranks`: A list of card ranks.
`const vector<string>& suits`: A list of card suits.

**Code Description**: This method populates a deck of cards by iterating over the provided ranks and suits, creating a string representation of each card (e.g., "Ace of Hearts"), and storing it in a `cards_str` vector. It also creates a `Card` object for each combination of rank and suit, storing its string representation and an incrementing card number in a `cards` vector.\\
## Code: 
```
Deck::Deck(const vector<string>& ranks, const vector<string>& suits) {
    this->ranks = ranks;
    this->suits = suits;
    int card_num = 0;
    for(const string& one_rank : ranks){
        for(const string& one_suit: suits){
            string one_card = one_rank + one_suit;
            cards_str.push_back(one_card);
            cards.emplace_back(one_card,card_num);
            card_num += 1;
        }
    }
}
```