The function of `printTree` is to print a game tree structure to the console.

**Parameters**:
`int depth`: The depth level at which to start printing the game tree. A value of -1 indicates that the entire tree should be printed, while positive values indicate the maximum depth to reach.

**Code Description**: 
The `printTree` function is responsible for initiating the recursive process of printing a game tree structure. It takes an integer parameter `depth`, which determines how deep into the tree to print. The function first checks if the provided depth value is valid (not less than -1 or equal to 0), and if not, it throws a runtime error. If the depth is valid, it calls the `recurrentPrintTree` method on the root node of the game tree, passing in the current depth level as an argument. This recursive call will continue until the specified depth is reached, printing out the relevant information for each node in the process.\\
## Code: 
```
void GameTree::printTree(int depth) {
    if(depth < -1 || depth == 0){
        throw runtime_error("depth can only be -1 or positive");
    }
    vector<string> prefix;
    this->recurrentPrintTree(this->root,0,depth);
}
```