`recurrentSetDepth`: The function of `recurrentSetDepth` is to recursively set the depth and subtree size of a game tree node.

**Parameters**:
`shared_ptr<GameTreeNode> node`: This parameter represents the current game tree node being processed.
`int depth`: This parameter represents the current depth level in the game tree, which starts at 0 for the root node.

**Code Description**: The `recurrentSetDepth` function recursively traverses the game tree, starting from a given node. It sets the depth of each node to its corresponding depth value and calculates the subtree size based on the number of children it has. If the node is an action node, it recursively calls itself for each child node, incrementing the depth by 1. If the node is a chance node, it recursively calls itself for all child nodes and multiplies the result by the number of cards in the chance node's deck. The function returns the subtree size of the current node.\\
## Code: 
```
int GameTree::recurrentSetDepth(shared_ptr<GameTreeNode> node, int depth) {
    node->depth = depth;
    if(node->getType() == GameTreeNode::ACTION) {
        shared_ptr<ActionNode> actionNode = std::dynamic_pointer_cast<ActionNode>(node);
        int subtree_size = 1;
        for(shared_ptr<GameTreeNode> one_child:actionNode->getChildrens()){
            subtree_size += this->recurrentSetDepth(one_child,depth + 1);
        }
        node->subtree_size = subtree_size;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chanceNode = std::dynamic_pointer_cast<ChanceNode>(node);
        int subtree_size = 1;
        subtree_size += this->recurrentSetDepth(chanceNode->getChildren(),depth + 1) * chanceNode->getCards().size();
        node->subtree_size = subtree_size;
    }else{
        node->subtree_size = 1;
    }
    return node->subtree_size;
}
```