buildAction: The function of `buildAction` is to build an action node in the game tree based on the provided parameters.

**Parameters**:
- `shared_ptr<ActionNode> root`: A shared pointer to the root node of the game tree.
- `Rule rule`: An object representing the rules of the game, including betting settings and odds calculations.
- `string last_action`: The type of action taken by the player in the previous round (e.g., "call", "raise", etc.).
- `int check_times`: The number of times the player has checked in the current round.
- `int raise_times`: The number of times the player has raised in the current round.

**Code Description**: 
The `buildAction` function appears to be part of a game tree data structure, specifically designed for a poker-related project. It takes into account various factors such as the game rules, the player's previous action, and their betting behavior to determine the next possible actions in the game tree. The function likely uses these parameters to update or create an `ActionNode` object, which represents a node in the game tree that corresponds to a specific action taken by the player.\\
## Code: 
```
void GameTree::buildAction(shared_ptr<ActionNode> root,Rule rule,string last_action,int check_times,int raise_times){
    // current player
    int player = root->getPlayer();

    vector<string> possible_actions;
    if(last_action == "roundbegin") {
        possible_actions = vector<string>{"check", "bet"};
    }else if(last_action == "begin") {
        possible_actions = vector<string>{"check", "bet"};
    }else if(last_action == "bet") {
        possible_actions = vector<string>{"call", "raise", "fold"};
    }else if(last_action == "raise") {
        possible_actions = vector<string>{"call", "raise", "fold"};
    }else if(last_action == "check") {
        possible_actions = vector<string>{"check", "raise", "bet"};
    }else if(last_action == "fold") {
        possible_actions = vector<string>{};
    }else if(last_action == "call") {
        possible_actions = vector<string>{"check", "raise"};
    }else{
        throw runtime_error(tfm::format("last action %s not found", last_action));
    }
    int nextplayer = 1 - player;

    vector<GameActions> actions;
    vector<shared_ptr<GameTreeNode>> childrens;

    if (possible_actions.empty()) return;
    for (string action : possible_actions) {
        if (action == "check") {
            // 当不是第一轮的时候 call后面是不能跟check的
            shared_ptr<GameTreeNode> nextnode;
            Rule nextrule = Rule(rule);
            if ((last_action == "call" && root->getParent() != nullptr && root->getParent()->getParent() == nullptr) || check_times >= 1) {
                // 在river check 导致游戏进入showdown
                if(rule.current_round == 3){
                    double p1_commit = rule.ip_commit;
                    double p2_commit = rule.oop_commit;
                    double peace_getback = (p1_commit + p2_commit) / 2;
                    vector<vector<double>> payoffs(2);
                    payoffs[0] = {p2_commit, -p2_commit};
                    payoffs[1] = {-p1_commit, p1_commit};
                    vector<double> peace_getback_vec = {peace_getback - p1_commit, peace_getback - p2_commit};
                    nextnode = make_shared<ShowdownNode>(peace_getback_vec,payoffs,GameTreeNode::intToGameRound(rule.current_round),(double)rule.get_pot(),root);
                }else {
                    // 在preflop/flop/turn check 导致游戏进入下一轮
                    nextrule.current_round += 1;
                    nextnode = make_shared<ChanceNode>(nullptr,GameTreeNode::intToGameRound(rule.current_round + 1), rule.get_pot(), root, this->deck.getCards());
                }
            }else if (root->getParent() == nullptr) {
                nextnode = make_shared<ActionNode>(vector<GameActions>(),vector<shared_ptr<GameTreeNode>>() , nextplayer, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
            } else {
                nextnode = make_shared<ActionNode>(vector<GameActions>(),vector<shared_ptr<GameTreeNode>>() , nextplayer, GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(), root);
            }
            this->__build(nextnode, nextrule,"check",check_times + 1,0);
            actions.push_back(GameActions(GameTreeNode::PokerActions::CHECK,-1));
            childrens.push_back(nextnode);
        }else if (action == "bet"){
            BetType betType = BetType::BET;
            // if it's a donk bet
            if(root->getPlayer() == 1 && root->getParent() != nullptr && root->getParent()->getType() == GameTreeNode::GameTreeNodeType::CHANCE){
                shared_ptr<ChanceNode> chanceNodeBeforeThis = std::dynamic_pointer_cast<ChanceNode>(root->getParent());
                if(chanceNodeBeforeThis->isDonk()) betType = BetType::DONK;
            }
            vector<double> bet_sizes = this->get_possible_bets(root,player,nextplayer,rule,betType);
            for(double one_betting_size:bet_sizes){
                Rule nextrule = Rule(rule);
                if (player == 0) nextrule.ip_commit += one_betting_size;
                else if (player == 1) nextrule.oop_commit += one_betting_size;
                else throw runtime_error("unknown player");
                shared_ptr<GameTreeNode> nextnode = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(),nextplayer,GameTreeNode::intToGameRound(rule.current_round),(double) rule.get_pot(),root);
                this->__build(nextnode,nextrule,"bet",0,1);
                actions.push_back(GameActions(GameTreeNode::PokerActions::BET,one_betting_size));
                childrens.push_back(nextnode);
            }
        }else if (action == "call"){
            Rule nextrule = Rule(rule);
            if (player == 0) nextrule.ip_commit += (rule.oop_commit - rule.ip_commit);
            else if (player == 1) nextrule.oop_commit += (rule.ip_commit - rule.oop_commit);
            else throw runtime_error("unknown player");

            shared_ptr<GameTreeNode> nextnode;
            if(root->getParent() == nullptr) {
                nextnode = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(), nextplayer, GameTreeNode::intToGameRound(rule.current_round), (double) nextrule.get_pot(), root);
            }else if (rule.current_round == 3 ){ // at river
                double p1_commit = nextrule.ip_commit;
                double p2_commit = nextrule.oop_commit;
                double peace_getback = (p1_commit + p2_commit) / 2;

                vector<vector<double>> payoffs(2);
                payoffs[0] = {p2_commit, -p2_commit};
                payoffs[1] = {-p1_commit, p1_commit};
                vector<double> tie_payoffs = {peace_getback - p1_commit, peace_getback - p2_commit};
                nextnode = make_shared<ShowdownNode>(tie_payoffs,payoffs,GameTreeNode::intToGameRound(rule.current_round),(double) nextrule.get_pot(),root);
            }else{
                nextrule.current_round += 1;
                bool donk = false;
                if(player == 1) donk = true;
                nextnode = make_shared<ChanceNode>(nullptr,GameTreeNode::intToGameRound(rule.current_round + 1),(double) nextrule.get_pot(),root,this->deck.getCards(),donk);
            }
            if(nextrule.current_round > 3)throw runtime_error(tfm::format("round %d exceed 3",nextrule.current_round));
            this->__build(nextnode,nextrule,"call",0,0);
            actions.push_back(GameActions(GameTreeNode::PokerActions::CALL, -1));
            childrens.push_back(nextnode);
        }else if (action == "raise"){
            if(last_action == "call"){
                if(!(root->getParent() != nullptr && root->getParent()->getParent() == nullptr)) continue;
            }else if(last_action == "check"){
                // 第二轮之后的check后面只能跟 bet
                if(!(root->getParent() != nullptr && root->getParent()->getParent() == nullptr && rule.current_round == 0)) continue;
            }
            // 如果raise次数超出限制，则不可以继续raise
            if(raise_times >= rule.raise_limit) continue;
            vector<double> bet_sizes = this->get_possible_bets(root,player,nextplayer,rule,BetType::RAISE);
            for(double one_betting_size:bet_sizes){
                Rule nextrule = Rule(rule);
                if (player == 0) nextrule.ip_commit += one_betting_size;
                else if (player == 1) nextrule.oop_commit += one_betting_size;
                else runtime_error("unknown player");
                shared_ptr<GameTreeNode> nextnode = make_shared<ActionNode>(vector<GameActions>(), vector<shared_ptr<GameTreeNode>>(),nextplayer,GameTreeNode::intToGameRound(rule.current_round),(double) rule.get_pot(),root);
                // Calculate the raise size rather than amount being
                // added to the pot. Do this by ascending the tree until
                // reach a CHANCE node (or no parent) and extract the pot
                // size from it. This can then be used to calculate raise
                shared_ptr<GameTreeNode> roundroot = nextnode;
                while(roundroot->getParent() && roundroot->getType() != GameTreeNode::GameTreeNodeType::CHANCE) {
                    roundroot = roundroot->getParent();
                }
                double raiseto;
                double commit = player == 0 ? nextrule.ip_commit : nextrule.oop_commit;
                if(roundroot) {
                    raiseto = commit - roundroot->getPot()/2;
                } else {
                    raiseto = one_betting_size;
                }
                this->__build(nextnode,nextrule,"raise",0,raise_times + 1);
                actions.push_back(GameActions(GameTreeNode::PokerActions::RAISE,raiseto));
                childrens.push_back(nextnode);
            }

        }else if (action == "fold"){
            Rule nextrule = Rule(rule);
            vector<double> payoffs;
            if (player == 0) {
                payoffs = {-rule.ip_commit, rule.ip_commit};
            }else if(player == 1){
                payoffs = {rule.oop_commit, -rule.oop_commit};
            }else throw runtime_error("unknown player");
            shared_ptr<GameTreeNode> nextnode = make_shared<TerminalNode>(payoffs,nextplayer,GameTreeNode::intToGameRound(rule.current_round), (double) rule.get_pot(),root);
            this->__build(nextnode,nextrule,"fold",0,0);
            actions.push_back(GameActions(GameTreeNode::PokerActions::FOLD,-1));
            childrens.push_back(nextnode);
        }
    }
    if(actions.size() == 0)throw runtime_error("action size is 0");
    root->setActions(actions);
    root->setChildrens(childrens);
}
```