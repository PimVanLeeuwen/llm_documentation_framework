`strToGameRound`: The function of `strToGameRound` is to convert a given string representing a game round into an enumeration value of type `GameTreeNode::GameRound`.

**Parameters**: 
`const string& round`: This parameter is the input string that represents the game round, which can be one of the following: "preflop", "flop", "turn", or "river".

**Code Description**: The function uses a series of if-else statements to match the input string with the corresponding `GameTreeNode::GameRound` enumeration value. If the input string does not match any of the expected values, it throws a runtime error with a message indicating that the game round was not found.\\
## Code: 
```
GameTreeNode::GameRound GameTree::strToGameRound(const string& round) {
    GameTreeNode::GameRound game_round;
    if(round == "preflop"){
        game_round = GameTreeNode::GameRound::PREFLOP;
    }
    else if (round == "flop"){
        game_round = GameTreeNode::GameRound::FLOP;
    }
    else if(round == "turn"){
        game_round = GameTreeNode::GameRound::TURN;
    }
    else if(round == "river"){
        game_round = GameTreeNode::GameRound::RIVER;
    }
    else{
        throw runtime_error(tfm::format("game round not found: %s",round));
    }
    return game_round;
}
```