`getSettings`: The function of `getSettings` is to retrieve the settings for a specific game round and player in the Texas Hold'em poker game.

**Parameters**:
- `int int_round`: This parameter represents the current game round, which can be one of the following: RIVER, TURN, or FLOP.
- `int player`: This parameter specifies the player whose settings are being retrieved, either 0 (for the first player) or 1 (for the second player).
- `GameTreeBuildingSettings& gameTreeBuildingSettings`: This is a reference to an object containing the building settings for the game tree.

**Code Description**: The function uses the provided parameters to determine which settings to return from the `gameTreeBuildingSettings` object. It first converts the integer game round number to its corresponding enum value using the `intToGameRound` method. Then, it checks the player and game round combination to decide which settings to return. If an invalid player or game round is provided, it throws a runtime error with a descriptive message.\\
## Code: 
```
StreetSetting GameTree::getSettings(int int_round, int player,GameTreeBuildingSettings& gameTreeBuildingSettings){
    GameTreeNode::GameRound round = GameTreeNode::intToGameRound(int_round);
    if(!(player == 0 || player == 1)) throw runtime_error(tfm::format("player %s not known",player));
    if(round == GameTreeNode::GameRound::RIVER && player == 0) return gameTreeBuildingSettings.river_ip;
    else if(round == GameTreeNode::GameRound::TURN && player == 0) return gameTreeBuildingSettings.turn_ip;
    else if(round == GameTreeNode::GameRound::FLOP && player == 0) return gameTreeBuildingSettings.flop_ip;
    else if(round == GameTreeNode::GameRound::RIVER && player == 1) return gameTreeBuildingSettings.river_oop;
    else if(round == GameTreeNode::GameRound::TURN && player == 1) return gameTreeBuildingSettings.turn_oop;
    else if(round == GameTreeNode::GameRound::FLOP && player == 1) return gameTreeBuildingSettings.flop_oop;
    else throw new runtime_error(tfm::format("player %s and round not known",player));
}
```