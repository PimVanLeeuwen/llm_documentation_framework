`round_nearest`: The function rounds a given number to the nearest multiple of another number.

**Parameters**:
`double number`: The input number that needs to be rounded.
`double round_num`: The number to which the input number should be rounded.

**Code Description**: 
The `round_nearest` function takes two parameters, `number` and `round_num`. It first calculates the reciprocal of `round_num`, then multiplies this value with the `number`. The result is rounded using the `round()` function. Finally, the result is divided by the original `round_num` to obtain the final rounded number.\\
## Code: 
```
double GameTree::round_nearest(double number, double round_num) {
    round_num = 1 / round_num;
    return round((number * round_num)) / round_num;

}
```