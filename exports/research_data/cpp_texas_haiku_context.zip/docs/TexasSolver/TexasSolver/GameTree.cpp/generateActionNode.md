`generateActionNode`: The function of `generateActionNode` is to generate an action node in the game tree based on provided metadata and children actions.

**Parameters**:
- `json meta`: A JSON object containing information about the current player and pot.
- `vector<string> childrens_actions`: A vector of strings representing the possible actions that can be taken by the players.
- `vector<json> childrens_nodes`: A vector of JSON objects representing the child nodes in the game tree.
- `const string& round`: A string indicating the current round of the game (e.g., "preflop", "flop", etc.).
- `shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node in the game tree.

**Code Description**: The function first checks if the number of children actions matches the number of child nodes, and if the round is valid. It then iterates through each pair of children action and child node, generating a GameActions object based on the action and amount information. A shared pointer to a new GameTreeNode is created for each child node using the `recurrentGenerateTreeNode` function. The generated ActionNode is initialized with the list of GameActions objects, the vector of child nodes, player information, game round, pot value, and parent node reference. Finally, the parent node of each child node is set to the newly created ActionNode.\\
## Code: 
```
shared_ptr<ActionNode>
GameTree::generateActionNode(json meta, vector<string> childrens_actions, vector<json> childrens_nodes, const string& round,
                             shared_ptr<GameTreeNode> parent) {
    if(childrens_actions.size() != childrens_nodes.size()){
        throw runtime_error(
                tfm::format(
                        "mismatch when generate ActionNode, childrens_action length %s children_nodes length %s",
                        childrens_actions.size(),
                        childrens_nodes.size()
                ));
    }

    if(! (   round == "preflop"
          || round == "flop"
          || round == "turn"
          || round == "river"
          )
            ){
        throw runtime_error(tfm::format("round %s not found",round));
    }

    vector<GameActions> actions;
    vector<shared_ptr<GameTreeNode>> childrens;

    // 遍历所有children actions 来生成GameAction 的list，用于初始化ActionNode
    for(std::size_t i = 0;i < childrens_actions.size();i++){
        string one_action = childrens_actions[i];
        json one_children_map = childrens_nodes[i];
        if(one_action.empty()) throw runtime_error("action is null");

        GameTreeNode::PokerActions action;
        double amount = -1;
        if(one_action == "check"){
            action = GameTreeNode::PokerActions::CHECK;
        }
        else if(one_action == "fold"){
            action = GameTreeNode::PokerActions::FOLD;
        }
        else if(one_action == "call"){
            action = GameTreeNode::PokerActions::CALL;
        }
        else{
            if(one_action.find("bet")  != string::npos){
                vector<string> action_sp = string_split(one_action,'_');
                if(action_sp.size() != 2)
                    throw runtime_error(tfm::format("bet action sp length %s",action_sp.size()));
                string action_str = action_sp[0];
                action = GameTreeNode::PokerActions::BET;
                if(!(action_str == "bet")) throw runtime_error(tfm::format("Action %s not found",action_str));
                amount = stod(action_sp[1]);

            }else if (one_action.find("raise") != string::npos){
                vector<string> action_sp = string_split(one_action,'_');
                if(action_sp.size() != 2)
                    throw runtime_error(tfm::format("raise action sp length %s",action_sp.size()));
                string action_str = action_sp[0];
                action = GameTreeNode::PokerActions::RAISE;
                if(!(action_str == "raise"))
                    throw runtime_error(tfm::format("Action %s not found",action_str));
                amount = stod(action_sp[1]);
            }else{
                throw runtime_error(tfm::format("%s action not found",one_action));
            }
        }
        shared_ptr<GameTreeNode> one_children_node = recurrentGenerateTreeNode(one_children_map,parent);
        childrens.push_back(one_children_node);

        GameActions game_action = GameActions(action,amount);
        actions.push_back(game_action);
    }
    int player = meta["player"];
    double pot = meta["pot"];
    if(childrens.size() != actions.size()){
        throw runtime_error(tfm::format("childrens length %s, actions length %s"
                ,childrens.size()
                ,actions.size()));
    }
    GameTreeNode::GameRound game_round = strToGameRound(round);
    shared_ptr<ActionNode> actionNode = make_shared<ActionNode>(actions,childrens,player,game_round,pot,parent);
    for(const shared_ptr<GameTreeNode>& one_node: childrens){
        one_node->setParent(std::dynamic_pointer_cast<GameTreeNode>(actionNode));
    }
    return actionNode;

}
```