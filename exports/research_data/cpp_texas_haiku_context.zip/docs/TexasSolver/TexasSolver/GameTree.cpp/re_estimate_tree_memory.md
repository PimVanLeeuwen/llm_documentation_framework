`re_estimate_tree_memory`: The function of `re_estimate_tree_memory` is to estimate the memory required for a game tree.

**Parameters**:
`const shared_ptr<GameTreeNode>& node`: A pointer to a GameTreeNode object, representing a node in the game tree.
`int deck_num`: The number of decks used in the game.
`int p1range_num`: The number of possible ranges for player 1's hand.
`int p2range_num`: The number of possible ranges for player 2's hand.
`int num_current_deal`: The current deal number.

**Code Description**: This function recursively estimates the memory required for a game tree by traversing the tree and calculating the memory needed for each node. It takes into account the type of node (ACTION or CHANCE), the deck size, player range numbers, and the current deal number to estimate the total memory required.\\
## Code: 
```
long long GameTree::re_estimate_tree_memory(const shared_ptr<GameTreeNode>& node,int deck_num,int p1range_num,int p2range_num,int num_current_deal){
    if(node->getType() == GameTreeNode::ACTION){
        shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
        vector<shared_ptr<GameTreeNode>> childrens = action_node->getChildrens();
        vector<GameActions> actions = action_node->getActions();

        long long retnum = 0;
        for(std::size_t i = 0;i < childrens.size();i++){
            shared_ptr<GameTreeNode> one_child = childrens[i];
            retnum += re_estimate_tree_memory(one_child,deck_num, p1range_num, p2range_num, num_current_deal);
        }
        if(action_node->getPlayer() == 0){
            retnum += num_current_deal * p1range_num * (childrens.size() + 1) * 3;
        }else{
            retnum += num_current_deal * p2range_num * (childrens.size() + 1) * 3;
        }
        return retnum;
    }else if(node->getType() == GameTreeNode::CHANCE){
        shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
        shared_ptr<GameTreeNode> children = chance_node->getChildren();
        return re_estimate_tree_memory(children,deck_num, p1range_num, p2range_num, num_current_deal * (deck_num));
    }
    return 0;
}
```