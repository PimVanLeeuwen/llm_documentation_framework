## Expected output
`estimate_tree_memory`: The function of `estimate_tree_memory` is to estimate the memory required for a game tree.
**Parameters**:\
`int deck_num`: The number of decks in use. \
`int p1range_num`: The number of possible ranges for player 1's hand. \
`int p2range_num`: The number of possible ranges for player 2's hand. \
`int num_current_deal`: The current deal number.

**Code Description**: This function calls the `re_estimate_tree_memory` method to estimate the memory required for a game tree, passing in the root node and other parameters.\\
## Code: 
```
long long GameTree::estimate_tree_memory(int deck_num,int p1range_num,int p2range_num,int num_current_deal){
    return this->re_estimate_tree_memory(this->root,deck_num, p1range_num, p2range_num, num_current_deal);
}
```