`generateChanceNode`: The function of `generateChanceNode` is to generate a chance node in the game tree.

**Parameters**:
- `json meta`: A JSON object containing metadata for the chance node.
- `const json& child`: A reference to a JSON object representing the child node.
- `string round`: A string indicating the current game round.
- `shared_ptr<GameTreeNode> parent`: A shared pointer to the parent game tree node.

**Code Description**: The function generates a chance node with the provided metadata, child node, and game round. It uses the `recurrentGenerateTreeNode` method to generate the child node and then creates a new `ChanceNode` instance with the generated child node, current game round, and pot amount. The parent game tree node is also set for the newly created chance node.\\
## Code: 
```
shared_ptr<ChanceNode>
GameTree::generateChanceNode(json meta, const json& child, string round, shared_ptr<GameTreeNode> parent) {
    //节点上的下注额度
    double pot = meta["pot"];
    shared_ptr<GameTreeNode> one_child = recurrentGenerateTreeNode(child, nullptr);
    GameTreeNode::GameRound game_round = strToGameRound(std::move(round));
    shared_ptr<ChanceNode> chanceNode = make_shared<ChanceNode>(one_child,game_round,pot,parent,this->deck.getCards());
    shared_ptr<GameTreeNode> gameTreeNode = chanceNode->getChildren();
    gameTreeNode->setParent(chanceNode);
    return chanceNode;
}
```