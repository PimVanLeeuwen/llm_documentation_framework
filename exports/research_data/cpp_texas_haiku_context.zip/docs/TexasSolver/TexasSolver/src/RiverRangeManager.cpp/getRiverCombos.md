`getRiverCombos`: The function of `getRiverCombos` is to retrieve a list of river combinations for a given player, preflop hand combinations, and board state.

**Parameters**:
`int player`: The ID of the player (0 or 1) for whom to retrieve river combinations.
`const vector<PrivateCards> &preflopCombos`: A vector of preflop hand combinations to consider when generating river combinations.
`uint64_t board_long`: The long representation of the current board state.

**Code Description**: 
The `getRiverCombos` function first determines which set of river ranges to use based on the player ID. It then checks if a cache entry for the given board state exists in the corresponding map. If it does, the cached result is returned. Otherwise, the function iterates over the preflop hand combinations and generates river combinations by checking if each combination has an intercept with the current board state using the `Card::boardsHasIntercept` method. The generated river combinations are stored in a vector and sorted based on their rank. Finally, the vector of river combinations is cached for future use and returned.\\
## Code: 
```
const vector<RiverCombs> &
RiverRangeManager::getRiverCombos(int player, const vector<PrivateCards> &preflopCombos, uint64_t board_long) {
    unordered_map<uint64_t , vector<RiverCombs>>* riverRanges;

    if (player == 0)
        riverRanges = &p1RiverRanges;
    else if (player == 1)
        riverRanges = &p2RiverRanges;
    else
        throw runtime_error(tfm::format("player %s not found",player));

    uint64_t key = board_long;

    this->maplock->lock();
    if (riverRanges->find(key) != riverRanges->end()) {
        const vector<RiverCombs> &retval = (*riverRanges)[key];
        this->maplock->unlock();
        return retval;
    }
    this->maplock->unlock();

    int count = 0;

    for (auto one_hand : preflopCombos) {
        if (!Card::boardsHasIntercept(
                one_hand.toBoardLong(), board_long
        ))
            count++;
    }

    int index = 0;
    vector<RiverCombs> riverCombos = vector<RiverCombs>(count);

    for (std::size_t hand = 0; hand < preflopCombos.size(); hand++)
    {
        PrivateCards preflopCombo = preflopCombos[hand];


        if (Card::boardsHasIntercept(
                preflopCombo.toBoardLong(), board_long
        )){
            continue;
        }

        int rank = this->handEvaluator->get_rank(preflopCombo.toBoardLong(),board_long);
        RiverCombs riverCombo = RiverCombs(Card::long2board(board_long),preflopCombo,rank, hand);
        riverCombos[index++] = riverCombo;
    }

    std::sort(riverCombos.begin(),riverCombos.end(),[ ]( const RiverCombs& lhs, const RiverCombs& rhs )
    {
        return lhs.rank > rhs.rank;
    });

    this->maplock->lock();
    (*riverRanges)[key] =  std::move(riverCombos);
    this->maplock->unlock();

    return (*riverRanges)[key];
}
```