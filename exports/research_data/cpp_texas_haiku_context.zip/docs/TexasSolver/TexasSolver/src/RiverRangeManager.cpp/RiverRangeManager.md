`RiverRangeManager`: The function of `RiverRangeManager` is to manage the river range in a Texas Hold'em game.

**Parameters**: 
`shared_ptr<Compairer> handEvaluator`: This parameter is an instance of a hand evaluator, which is used to evaluate the strength of hands in the game.

**Code Description**: 
The code initializes the `RiverRangeManager` object by setting up its internal state. It takes a shared pointer to a `Compairer` object as input and stores it in the `handEvaluator` member variable. Additionally, it creates a new shared pointer to a mutex (a synchronization primitive) and assigns it to the `maplock` member variable. This suggests that the `RiverRangeManager` class will be used to manage access to some internal data structure or resource, and the mutex is used to synchronize access to this resource.\\
## Code: 
```
RiverRangeManager::RiverRangeManager(shared_ptr<Compairer> handEvaluator) {
    this->handEvaluator = std::move(handEvaluator);
    this->maplock = std::make_shared<std::mutex>();
}
```