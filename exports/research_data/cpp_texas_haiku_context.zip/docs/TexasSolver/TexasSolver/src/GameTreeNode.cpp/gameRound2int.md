`gameRound2int`: The function of `gameRound2int` is to convert a `GameRound` enum value into an integer representation.

**Parameters**: 
`GameTreeNode::GameRound gameRound`: This parameter takes in a `GameRound` enum value, which represents the current round of a poker game.

**Code Description**: 
The function uses if-else statements to check the input `gameRound` and returns a corresponding integer value. If the input is not recognized, it throws a runtime error with the message "round not found". The returned integers seem to represent the order of the rounds in a poker game: PREFLOP (0), FLOP (1), TURN (2), and RIVER (3).\\
## Code: 
```
int GameTreeNode::gameRound2int(GameTreeNode::GameRound gameRound) {
    if(gameRound == GameRound::PREFLOP) {
        return 0;
    }else if(gameRound == GameRound::FLOP){
        return 1;
    } else if(gameRound == GameRound::TURN) {
        return 2;
    } else if(gameRound == GameRound::RIVER) {
        return 3;
    }
    throw runtime_error("round not found");
}
```