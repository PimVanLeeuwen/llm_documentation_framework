`intToGameRound`: The function of `intToGameRound` is to convert an integer game round value into a GameTreeNode::GameRound enumeration.

**Parameters**: 
`int round`: This parameter represents the integer game round value that needs to be converted.

**Code Description**: 
The function uses a switch statement to match the input integer value with one of the predefined game rounds (PREFLOP, FLOP, TURN, RIVER). If the input value does not match any of these cases, it throws a runtime_error exception with an error message indicating that the round was not found.\\
## Code: 
```
GameTreeNode::GameRound GameTreeNode::intToGameRound(int round){
    GameTreeNode::GameRound game_round;
    switch(round){
        case 0:{
            game_round = GameTreeNode::GameRound::PREFLOP;
            break;
        }
        case 1:{
            game_round = GameTreeNode::GameRound::FLOP;
            break;
        }
        case 2:{
            game_round = GameTreeNode::GameRound::TURN;
            break;
        }
        case 3:{
            game_round = GameTreeNode::GameRound::RIVER;
            break;
        }
        default:{
            throw runtime_error(tfm::format("round %s not found",round));
        }
    }
    return game_round;
}
```