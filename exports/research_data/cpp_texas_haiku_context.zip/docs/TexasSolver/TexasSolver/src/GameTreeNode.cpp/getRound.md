`getRound`: The function of `getRound` is to return the current round number in a game.

**Code Description**: This method, `getRound`, is part of the `GameTreeNode` class and is used to retrieve the current round number. It simply returns the value stored in the `round` member variable of the class instance.\\
## Code: 
```
GameTreeNode::GameRound GameTreeNode::getRound() {
    return this->round;
}
```