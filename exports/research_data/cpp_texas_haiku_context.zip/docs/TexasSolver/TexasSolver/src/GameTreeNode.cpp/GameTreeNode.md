`GameTreeNode`: The function of `GameTreeNode` is to create a new game tree node with the specified round, pot value, and parent node.

**Parameters**:
- `GameTreeNode::GameRound round`: This parameter specifies the current round in the game.
- `double pot`: This parameter represents the current pot value in the game.
- `shared_ptr<GameTreeNode> parent`: This parameter points to the parent node of the newly created game tree node.

**Code Description**: The code snippet provided defines a constructor for the `GameTreeNode` class. It initializes the round, pot, and parent attributes of the new node with the values passed as parameters. The `std::move` function is used to transfer ownership of the parent node from the original shared pointer to the new node, ensuring that the parent node is properly updated in the game tree structure.\\
## Code: 
```
GameTreeNode::GameTreeNode(GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent) {
    this->round = round;
    this->pot = pot;
    this->parent = std::move(parent);
}
```