`getPot`: The function of `getPot` is to return the current potential value stored in the game tree node.

**Code Description**: This method, `getPot`, simply retrieves and returns the `pot` member variable of the `GameTreeNode` class. It does not modify or calculate any values; it merely provides access to the existing `pot` value.\\
## Code: 
```
double GameTreeNode::getPot() {
    return this->pot;
}
```