`get_rank`: The function of `get_rank` is to return the rank of a poker hand given a private hand and a public board.

**Parameters**:
`uint64_t private_hand`: A 64-bit unsigned integer representing a long that contains information about the player's private cards.
`uint64_t public_board`: A 64-bit unsigned integer representing a long that contains information about the community cards on the table.

**Code Description**: The `get_rank` function first converts the `private_hand` and `public_board` integers into vectors of integers using the `long2board` method from the `Card` class. It then calls another `get_rank` function (not shown in this code snippet) with these converted vectors as arguments, passing the results back to the caller.\\
## Code: 
```
int Dic5Compairer::get_rank(uint64_t private_hand, uint64_t public_board) {
    return this->get_rank(Card::long2board(private_hand),Card::long2board(public_board));
}
```