`compairRanks`: The function of `compairRanks` is to compare the ranks of two cards.

**Parameters**:
`int rank_former`: The rank of the former card.
`int rank_latter`: The rank of the latter card.

**Code Description**: This function compares the ranks of two cards and returns a result indicating whether the former card's rank is larger, smaller, or equal to the latter card's rank. If the former card's rank is less than the latter card's rank, it returns `CompairResult::LARGER`. If the former card's rank is greater than the latter card's rank, it returns `CompairResult::SMALLER`. If both cards have the same rank, it returns `CompairResult::EQUAL`.\\
## Code: 
```
Compairer::CompairResult Dic5Compairer::compairRanks(int rank_former, int rank_latter) {
    if (rank_former < rank_latter) {
        // rank更小的牌更大，0是同花顺
        return CompairResult::LARGER;
    } else if (rank_former > rank_latter) {
        return CompairResult::SMALLER;
    } else {
        // rank_former == rank_latter
        return CompairResult::EQUAL;
    }
}
```