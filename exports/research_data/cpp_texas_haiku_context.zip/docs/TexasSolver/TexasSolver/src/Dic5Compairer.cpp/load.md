**load**: The function loads a comparison file into memory, allowing for the retrieval of card strength values.

**Parameters**:
`const char* file_path`: A pointer to a character array containing the path to the file to be loaded.

**Code Description**: This function reads data from a binary file specified by `file_path`. It first attempts to open the file in read-only mode, throwing an exception if it fails. The function then clears two maps (`flush_map` and `other_map`) that will store card strength values. It proceeds to read the number of key-value pairs from the file, followed by each pair itself (a 64-bit integer key and a 32-bit integer value). The keys are stored in `flush_map`, while the values are associated with these keys. This process is repeated for another set of key-value pairs, which are stored in `other_map`. Finally, the function closes the file and returns true to indicate successful loading.\\
## Code: 
```
bool FiveCardsStrength::load(const char* file_path) {
    //ifstream file(file_path, ios::binary);
    /*if (!file) {
        file.close();
        return false;
    }*/

    QFile file(QString::fromStdString(file_path));
    if (!file.open(QIODevice::ReadOnly)){
        throw runtime_error("unable to load compairer file");
    }
    flush_map.clear(); other_map.clear();
    int size_key = sizeof(uint64_t), size_int = sizeof(int), val, cnt = 0;
    uint64_t key = 0;
    char* p_key = (char*)&key, * p_val = (char*)&val, * p_cnt = (char*)&cnt;
    file.read(p_cnt, size_int);// 读取行数
    for (int i = 0; i < cnt; i++) {
        file.read(p_key, size_key);
        file.read(p_val, size_int);
        flush_map[key] = val;
    }
    assert(flush_map.size() == cnt);
    file.read(p_cnt, size_int);// 读取行数
    for (int i = 0; i < cnt; i++) {
        file.read(p_key, size_key);
        file.read(p_val, size_int);
        other_map[key] = val;
    }
    assert(other_map.size() == cnt);
    file.close();
    return true;
}
```