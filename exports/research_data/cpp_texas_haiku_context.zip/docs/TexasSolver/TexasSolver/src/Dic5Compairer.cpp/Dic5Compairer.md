`Dic5Compairer`: The function of `Dic5Compairer` is to load a dictionary from a file and convert it into a format that can be used for comparison.

**Parameters**:
`string dic_dir`: This parameter represents the directory path where the dictionary file is located.
`int lines`: This parameter specifies the number of lines in the dictionary file.
`string dic_dir_bin`: This parameter represents the binary directory path where the converted dictionary will be saved.

**Code Description**: The code loads a dictionary from a file, converts it into a format that can be used for comparison, and checks its consistency. It uses bitwise operations to categorize the hands based on their ranks and suits. If the dictionary is consistent, it saves the converted dictionary in binary format; otherwise, it throws an exception.\\
## Code: 
```
Dic5Compairer::Dic5Compairer(string dic_dir,int lines,string dic_dir_bin):Compairer(std::move(dic_dir),lines){
    if(fcs.load(dic_dir_bin.c_str())) return;
    QFile infile(QString::fromStdString(this->dic_dir));
    if (!infile.open(QIODevice::ReadOnly)){
        throw runtime_error("unable to load compairer file");
    }
    QTextStream in(&infile);
    //progressbar bar(lines / 1000);
    int i = 0;
    //while (std::getline(infile, line))
    while (!in.atEnd())
    {
        string line = in.readLine().toStdString();
        vector<string> linesp = string_split(line,',');
        if(linesp.size() != 2){
           throw runtime_error(tfm::format("linesp not correct: %s",line));
        }
        string cards_str = linesp[0];
        int rank = stoi(linesp[1]);
        vector<string> cards = string_split(cards_str,'-');

        if(cards.size() != 5)
            throw runtime_error(
                    tfm::format(
                            "cards not correct: %s length %s",cards_str,cards.size()));

        //set<string> cards_set;
        //for(string one_card:cards) cards_set.insert(one_card);
        //this->card2rank[cards_set] = rank;

        if(this->cardslong2rank.find(Card::boardCards2long(cards)) != this->cardslong2rank.end()){
            throw runtime_error(
                    tfm::format("key repeated: %s",cards_str)
                    );
        }

        this->cardslong2rank[Card::boardCards2long(cards)] = rank;

        i ++;
        if(i % 1000 == 0) {
            //bar.update();
        }
    }
    //cout << endl;
    fcs.convert(this->cardslong2rank);
    if(!fcs.check(this->cardslong2rank)){
        //fcs.save(dic_dir_bin.c_str());
        throw runtime_error("check consistency failed");
    }
    this->cardslong2rank.clear();
}
```