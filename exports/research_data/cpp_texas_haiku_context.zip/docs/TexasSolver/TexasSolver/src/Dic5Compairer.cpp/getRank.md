`getRank`: The function of `getRank` is to calculate the minimum rank of a given set of 5 cards in poker.

**Parameters**: 
`vector<Card> cards`: A vector of Card objects representing the 5 cards to be ranked.

**Code Description**: The code first converts each Card object into an integer value using the getCardInt method, and stores these values in a new vector called cards_int. It then calls another instance of the getRank method, passing in the cards_int vector as an argument. This suggests that the getRank method is overloaded to accept either a vector of Card objects or a vector of integers.\\
## Code: 
```
int Dic5Compairer::getRank(vector<Card> cards) {
    vector<int> cards_int(cards.size());
    for(std::size_t i = 0;i < cards.size();i++){
        cards_int[i] = cards[i].getCardInt();
    }
    return this->getRank(cards_int);
}
```