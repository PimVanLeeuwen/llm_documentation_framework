`setBoardText`: The function of `setBoardText` is to update the grid of floating-point values associated with a BoardSelectorTableModel object based on the provided string representation of boards.

**Parameters**:\
`QString input_board`: This parameter represents the string containing comma-separated board representations, where each board is identified by its coordinates and value.

**Code Description**: The `setBoardText` function iterates over each board in the input string, checks for format errors, and updates the corresponding grid values. If a board has an invalid format or no spaces (indicating it's empty), it skips that board. Otherwise, it retrieves the board's coordinates from the `string2ij` map, sets the grid value at those coordinates to 1.0, effectively marking the board as occupied.\\
## Code: 
```
void BoardSelectorTableModel::setBoardText(QString input_board){
    this->clear_board();
    for(QString one_board:input_board.split(",")){
        float board_float = 1.0;


        if(one_board.count(" ") == one_board.length() || one_board == "")continue;
        if(!this->string2ij.count(one_board)){
            qDebug().noquote() << QString(tr("skipping board %1, format error")).arg(one_board);
            continue;
        }
        pair<int,int> cord = this->string2ij[one_board];
        this->grids_float[cord.first][cord.second] = board_float;
    }
}
```