`getBoardAt`: The function of `getBoardAt` is to retrieve the value at a specific position on a grid.

**Parameters**:
`int i`: The row index of the grid.
`int j`: The column index of the grid.

**Code Description**: This function checks if the provided indices are within valid ranges. If not, it logs an error message and returns 0. Otherwise, it returns the value at the specified position on the grid, which is stored in a 2D array called `grids_float`.\\
## Code: 
```
float BoardSelectorTableModel::getBoardAt(int i, int j){
    if(i < 0 || i >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::getBoardAt i not valid: " << i;
        return 0;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::getBoardAt j not valid: " << j;
        return 0;
    }
    else{
        return this->grids_float[i][j];
    }
}
```