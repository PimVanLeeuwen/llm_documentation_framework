`setBoardAt`: The function of `setBoardAt` is to set the value at a specific position on a table model.

**Parameters**:
`int i`: The row index where the value will be set.
`int j`: The column index where the value will be set.
`float value`: The actual value that will be set at the specified position.

**Code Description**: This function checks if the provided indices are within valid ranges for the table model's rows and columns. If they are, it sets the corresponding grid cell to the given float value. Otherwise, it logs an error message indicating that the indices are not valid.\\
## Code: 
```
void BoardSelectorTableModel::setBoardAt(int i, int j,float value){
    if(i < 0 || i >= this->suitlist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::setBoardAt i not valid: " << i;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "BoardSelectorTableModel::setBoardAt j not valid: " << j;
    }
    else{
        this->grids_float[i][j] = value;
    }
}
```