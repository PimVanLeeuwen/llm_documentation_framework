`getBoardText`: The function of `getBoardText` is to generate a string representation of the board, where each cell in the grid that has a value (i.e., `grids_float[i][j] == 0`) is converted into a string and appended to the result.

**Code Description**: This method iterates over two lists (`suitlist` and `ranklist`) which are presumably used to index the grid. For each cell in the grid that has a value, it constructs a string representation of the board by concatenating the values from the `grids_string` array. The resulting strings are then appended to a single result string with commas separating each entry. If the result string is empty initially, the first board string is used as the initial value; otherwise, subsequent board strings are prepended with a comma before being added to the result.\\
## Code: 
```
QString BoardSelectorTableModel::getBoardText(){
    QString retval = "";
    for(int i = 0;i < this->suitlist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            if(this->grids_float[i][j] == 0)continue;
            QString one_board_str = QString("%1").arg(this->grids_string[i][j]);
            if(retval == ""){
                retval = one_board_str;
            }else{
                retval = retval + "," + one_board_str;
            }
        }
    }
    return retval;
}
```