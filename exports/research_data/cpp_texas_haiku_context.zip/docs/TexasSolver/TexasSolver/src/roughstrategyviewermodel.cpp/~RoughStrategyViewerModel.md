`~RoughStrategyViewerModel`: The function of `~RoughStrategyViewerModel` is to perform the destructor operation for the RoughStrategyViewerModel class.

**Code Description**: This method, which is a destructor, does not contain any code that performs specific actions. It simply exists as an empty block, indicating that it does not have any functionality beyond being a placeholder for potential cleanup or release of resources when an instance of the RoughStrategyViewerModel class is destroyed.\\
## Code: 
```
RoughStrategyViewerModel::~RoughStrategyViewerModel()
{
}
```