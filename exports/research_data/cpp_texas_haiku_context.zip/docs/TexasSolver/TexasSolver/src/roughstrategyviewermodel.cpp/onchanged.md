`onchanged`: The function of `onchanged` is to emit a signal indicating that the header data has changed, triggering an update in the table view.

**Code Description**: This code defines a method `onchanged` in the class `RoughStrategyViewerModel`. When called, it emits a signal using the `emit` keyword, which notifies any connected slots (functions) that the header data has been updated. The `headerDataChanged` function is used to specify the type of change and the affected columns. In this case, the horizontal orientation (`Qt::Horizontal`) and all columns from 0 to the total number of columns (`columnCount()`) are specified. This ensures that any connected slots will be notified to update their display accordingly.\\
## Code: 
```
void RoughStrategyViewerModel::onchanged(){
    emit headerDataChanged(Qt::Horizontal, 0 , columnCount());
}
```