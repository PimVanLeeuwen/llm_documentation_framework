**columnCount**: The function of `columnCount` is to return the total number of columns in a table.

**Parameters**: 
`const QModelIndex &parent`: This parameter represents the parent index, which is used to determine if the model has children. However, in this case, it seems that the parent index is not being utilized as the column count is determined by `this->tableStrategyModel->total_strategy.size();`.

**Code Description**: The function `columnCount` returns the size of the `total_strategy` vector from the `tableStrategyModel`. This suggests that the model's data structure consists of a table with columns represented by the elements in the `total_strategy` vector.\\
## Code: 
```
int RoughStrategyViewerModel::columnCount(const QModelIndex &parent) const
{
    return this->tableStrategyModel->total_strategy.size();
}
```