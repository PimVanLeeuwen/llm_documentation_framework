`index`: The function of `index` is to return a QModelIndex object representing the item in the model at the specified row and column, with the given parent index.

**Parameters**:
`int row`: The row number of the item in the model.
`int column`: The column number of the item in the model.
`const QModelIndex &parent`: The parent index of the item, which is used to indicate the hierarchical structure of the model.

**Code Description**: This function checks if the specified row and column have an index in the model using the `hasIndex` method. If they do not, it returns an invalid QModelIndex object. Otherwise, it creates a new QModelIndex object with the given row, column, and parent indices, and returns it.\\
## Code: 
```
QModelIndex RoughStrategyViewerModel::index(int row, int column, const QModelIndex &parent) const
{
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    return createIndex(row, column, nullptr);
}
```