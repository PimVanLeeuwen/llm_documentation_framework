`data`: The function of `data` is to return the data for a given index and role in the model.

**Parameters**:
`const QModelIndex &index`: This parameter represents the index of the item in the model that the data should be retrieved from.
`int role`: This parameter specifies the type of data that should be returned, such as display text or background color.

**Code Description**: The `data` function checks if the column index is within the bounds of the total strategy size. If it is, it retrieves a pair of game actions and a float pair from the table strategy model at the specified column index. It then returns the second value of the float pair as a string using QString::number(). If the column index is out of bounds, it returns the string "Rough Strategy".\\
## Code: 
```
QVariant RoughStrategyViewerModel::data(const QModelIndex &index, int role) const
{
    std::size_t col = index.column();
    if(col < this->tableStrategyModel->total_strategy.size()){
        pair<GameActions,pair<float,float>> one_strategy = this->tableStrategyModel->total_strategy[col];
        return QString::number(one_strategy.second.second);
    }else{
        return "Rough Strategy";
    }
}
```