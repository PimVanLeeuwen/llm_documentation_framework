`parent`: The function of `parent` is to return the parent index model for a given child index.

**Parameters**: 
`const QModelIndex &child`: A reference to a child index in the model.

**Code Description**: This method returns an empty QModelIndex, indicating that there is no parent index for the given child index. In other words, it suggests that the child index is a root item and does not have any parent.\\
## Code: 
```
QModelIndex RoughStrategyViewerModel::parent(const QModelIndex &child) const{
    return QModelIndex();
}
```