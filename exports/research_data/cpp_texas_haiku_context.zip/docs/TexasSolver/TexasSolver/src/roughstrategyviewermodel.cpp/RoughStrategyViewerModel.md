`RoughStrategyViewerModel`: The function of `RoughStrategyViewerModel` is to initialize a new instance of the model with a given `TableStrategyModel` and parent object.

**Parameters**:
`TableStrategyModel* tableStrategyModel`: This parameter represents the table strategy model that will be used by the viewer model.
`QObject *parent`: This parameter represents the parent object for the viewer model, which is typically used in Qt's signal-slot mechanism to establish relationships between objects.

**Code Description**: The code initializes a new instance of `RoughStrategyViewerModel` and sets its `tableStrategyModel` member variable to the provided `TableStrategyModel`. The constructor also takes an optional parent object, which is passed directly to the base class `QAbstractItemModel` constructor.\\
## Code: 
```
RoughStrategyViewerModel::RoughStrategyViewerModel(TableStrategyModel* tableStrategyModel, QObject *parent):QAbstractItemModel(parent){
    this->tableStrategyModel = tableStrategyModel;
}
```