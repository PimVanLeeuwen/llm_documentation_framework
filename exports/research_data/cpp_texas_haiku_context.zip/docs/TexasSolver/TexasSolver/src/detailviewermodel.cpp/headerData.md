## Expected output
`headerData`: The function of `headerData` is to return the header data for a given section, orientation, and role.
**Parameters**:\
`int section`: This parameter represents the index of the section in the model.
`Qt::Orientation orientation`: This parameter specifies whether the header data is requested for horizontal or vertical orientation.
`int role`: This parameter indicates the type of header data being requested (e.g., display text, tooltip).
**Code Description**: The `headerData` function returns a QVariant object containing the header data as a QString. In this implementation, an empty string is returned regardless of the input parameters.\\
## Code: 
```
QVariant DetailViewerModel::headerData(int section, Qt::Orientation orientation, int role){
    return QString::fromStdString("");
}
```