`get_commit`: The function of `get_commit` is to return the commit value for a given player.

**Parameters**:
`int player`: This parameter specifies which player's commit value should be returned. It can take values 0 or 1, representing players 0 and 1 respectively.

**Code Description**: 
The `get_commit` function takes an integer `player` as input and returns the corresponding commit value. If `player` is 0, it returns the value of `this->ip_commit`. If `player` is 1, it returns the value of `this->oop_commit`. If `player` has any other value, it throws a runtime error with the message "unknown player".\\
## Code: 
```
float Rule::get_commit(int player) {
    if (player == 0) return this->ip_commit;
    else if(player == 1) return this->oop_commit;
    else throw runtime_error("unknown player");
}
```