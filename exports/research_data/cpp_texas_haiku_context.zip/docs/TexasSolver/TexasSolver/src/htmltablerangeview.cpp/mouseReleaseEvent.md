**mouseReleaseEvent**: The function of `mouseReleaseEvent` is to handle the release event of a mouse button in the HtmlTableRangeView class.

**Parameters**: 
`QMouseEvent *event`: This parameter represents the mouse event that triggered the release event, containing information about the mouse button released and its position on the screen.

**Code Description**: The function `mouseReleaseEvent` calls the parent class's `mouseReleaseEvent` method to handle the mouse release event.\\
## Code: 
```
void HtmlTableRangeView::mouseReleaseEvent(QMouseEvent *event) {
    HtmlTableView::mouseReleaseEvent(event);
}
```