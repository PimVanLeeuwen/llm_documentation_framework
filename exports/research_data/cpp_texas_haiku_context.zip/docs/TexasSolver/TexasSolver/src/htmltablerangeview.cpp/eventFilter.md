`eventFilter`: The function of `eventFilter` is to filter events in the HtmlTableRangeView class and perform specific actions based on the type of event.

**Parameters**:
`QObject *watched`: The object being watched for events, which is the viewport of the HtmlTableRangeView.
`QEvent *event`: The event that occurred, such as a mouse button press or release.

**Code Description**: 
The `eventFilter` function checks if the viewed object is the same as the watched object. If it is, it then checks the type of event and performs specific actions based on that type. For example, when a mouse button is pressed, it gets the index of the item at the mouse position and sets up tracking for that item. When the mouse is moved while tracking an item, it updates the last bearing indices and emits a signal to view the item area if necessary. When the mouse button is released or the user leaves the viewport, it stops tracking the item and emits another signal to release the item. If the event type does not match any of these conditions, it simply calls the parent class's `eventFilter` function.\\
## Code: 
```
bool HtmlTableRangeView::eventFilter(QObject *watched, QEvent *event){
    if(viewport() == watched){
        if(event->type() == QEvent::MouseButtonPress){
            QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
            QModelIndex index = indexAt(mouseEvent->pos());
            if(index.isValid()){
                int i = index.row();
                int j = index.column();
                mouseTracker.tracking = true;
                mouseTracker.pressed_i = i;
                mouseTracker.pressed_j = j;
            }
        }
        else if(event->type() == QEvent::MouseMove){
            QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
            QModelIndex index = indexAt(mouseEvent->pos());
            if(index.isValid()){
                int i = index.row();
                int j = index.column();
                if(i != this->last_bearing_i || j != last_bearing_j){
                    this->last_bearing_i = i;
                    this->last_bearing_j = j;
                    if(mouseTracker.tracking == true){
                        emit view_item_area(mouseTracker.pressed_i,mouseTracker.pressed_j,i,j);
                    }
                }
            }
        }
        else if(event->type() == QEvent::MouseButtonRelease){
            QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
            QModelIndex index = indexAt(mouseEvent->pos());
            if(index.isValid()){
                int i = index.row();
                int j = index.column();
                mouseTracker.tracking = false;
                emit item_release(i,j);
            }
        }
        else if(event->type() == QEvent::Leave){
                mouseTracker.tracking = false;
        }else{

        }
    }
    return QTableView::eventFilter(watched, event);
}
```