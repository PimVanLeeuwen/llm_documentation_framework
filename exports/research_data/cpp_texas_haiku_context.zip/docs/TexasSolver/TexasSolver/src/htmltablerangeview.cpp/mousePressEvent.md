`mousePressEvent`: The function of `mousePressEvent` is to handle mouse press events in the HtmlTableRangeView class.

**Parameters**: 
`QMouseEvent *event`: This parameter represents a pointer to a QMouseEvent object, which contains information about the mouse event that occurred.

**Code Description**: 
The code calls the `mousePressEvent` method from its parent class `HtmlTableView`, and then gets the index of the item at the position where the mouse was pressed. It emits a signal `view_item_pressed` with the row and column indices of the item as parameters.\\
## Code: 
```
void HtmlTableRangeView::mousePressEvent(QMouseEvent *event) {
    HtmlTableView::mousePressEvent(event);
    QModelIndex index = indexAt(event->pos());
    emit view_item_pressed(index.row(),index.column());
}
```