`run`: The function of `run` is to execute a specific mission type based on the current_mission attribute of the QSolverJob object, handling different tasks such as solving, loading, building a game tree, or saving data.

**Code Description**: The run method in the QSolverJob class serves as a central control point for executing various poker solver-related tasks. It uses a series of if-else statements to determine which mission type is currently active and then calls the corresponding method (solving, loading, build_tree, or saving) to perform the specific task. If an unsupported mission type is encountered, it throws a runtime_error with an appropriate message. The catch block logs any errors that occur during execution using qDebug().\\
## Code: 
```
void QSolverJob::run()
{
    //QDebugStream qout(qDebug().noquote(), this->textEdit);
    try{
        if(this->current_mission == MissionType::SOLVING){
            this->solving();
        }else if(this->current_mission == MissionType::LOADING){
            this->loading();
        }else if(this->current_mission == MissionType::BUILDTREE){
            this->build_tree();
        }else if(this->current_mission == MissionType::SAVING){
            this->saving();
        }else{
            throw runtime_error("unsupported mission type");
        }
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```