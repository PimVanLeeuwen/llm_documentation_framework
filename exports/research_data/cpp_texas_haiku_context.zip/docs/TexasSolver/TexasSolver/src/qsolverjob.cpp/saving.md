`saving`: The function of `saving` is to save a JSON file with strategy data for a poker game.

**Code Description**: This function, `saving`, appears to be part of the QSolverJob class in the TexasSolver project. It saves a JSON file containing strategy data for a poker game based on the current mode and dump rounds settings. The function retrieves the dump rounds setting from the application's settings, checks if it is equal to 3, and then calls the `dump_strategy` method of either the Holdem or Shortdeck poker strategy object (ps_holdem or ps_shortdeck) depending on the game mode.\\
## Code: 
```
void QSolverJob::saving(){
    qDebug().noquote() << tr("Saving json file..");//.toStdString() << std::endl;

    QSettings setting("TexasSolver", "Setting");
    setting.beginGroup("solver");
    this->dump_rounds = setting.value("dump_round").toInt();

    qDebug().noquote() << tr("Dump round: ") << this->dump_rounds;
    if(this->dump_rounds == 3){
        qDebug().noquote() << tr("This could be slow, or even blow your RAM, dump to river is not well optimized :(");
    }
    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.dump_strategy(this->savefile,this->dump_rounds);
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.dump_strategy(this->savefile,this->dump_rounds);
    }
    qDebug().noquote() << tr("Saving done.");//.toStdString() << std::endl;
}
```