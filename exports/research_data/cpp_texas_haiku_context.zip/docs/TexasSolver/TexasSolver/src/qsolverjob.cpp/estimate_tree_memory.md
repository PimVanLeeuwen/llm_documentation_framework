`estimate_tree_memory`: The function of `estimate_tree_memory` is to estimate the memory required for a tree in a poker solver job.

**Parameters**:
- `QString range1`: This parameter represents the first betting range.
- `QString range2`: This parameter represents the second betting range.
- `QString board`: This parameter represents the current state of the board.

**Code Description**: The function takes three parameters: two betting ranges (`range1` and `range2`) and a board string (`board`). It checks the mode of the poker solver job and calls the corresponding method to estimate the tree memory. If the mode is HOLDEM, it calls `ps_holdem.estimate_tree_memory`, if the mode is SHORTDECK, it calls `ps_shortdeck.estimate_tree_memory`. If neither condition is met, it returns 0. The function also logs a message indicating that it's estimating the tree memory using qDebug().\\
## Code: 
```
long long QSolverJob::estimate_tree_memory(QString range1,QString range2,QString board){
    qDebug().noquote() << tr("Estimating tree memory..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        return ps_holdem.estimate_tree_memory(range1,range2,board);
    }else if(this->mode == Mode::SHORTDECK){
        return ps_shortdeck.estimate_tree_memory(range1,range2,board);
    }
    return 0;
}
```