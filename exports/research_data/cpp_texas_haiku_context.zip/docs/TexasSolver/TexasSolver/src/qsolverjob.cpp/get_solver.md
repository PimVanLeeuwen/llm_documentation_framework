`get_solver`: The function of `get_solver` is to return a pointer to the appropriate PokerSolver object based on the current mode of the QSolverJob.

**Code Description**: This method, `get_solver`, appears to be part of a class called `QSolverJob`. It takes no arguments and returns a pointer to a `PokerSolver` object. The function uses an if-else statement to determine which PokerSolver object to return based on the current mode of the QSolverJob. If the mode is HOLDEM, it returns a reference to the `ps_holdem` member variable. If the mode is SHORTDECK, it returns a reference to the `ps_shortdeck` member variable. If the mode is neither of these, it throws a runtime_error with the message "unknown mode in get_solver".\\
## Code: 
```
PokerSolver* QSolverJob::get_solver(){
    if(this->mode == Mode::HOLDEM){
        return &this->ps_holdem;
    }else if(this->mode == Mode::SHORTDECK){
        return &this->ps_shortdeck;
    }else throw runtime_error("unknown mode in get_solver");
}
```