`stop`: The function of `stop` is to stop a solver job, specifically designed for Hold'em and ShortDeck poker variants.

**Code Description**: 
The `stop` method in the QSolverJob class is responsible for terminating a solver job. It checks the current mode of the solver, which can be either Hold'em or ShortDeck, and calls the corresponding stop method on the respective poker strategy (ps_holdem or ps_shortdeck) object. This ensures that the solver job is properly halted, regardless of the variant being used.\\
## Code: 
```
void QSolverJob::stop(){
    qDebug().noquote() << tr("Trying to stop solver.");
    if(this->mode == Mode::HOLDEM){
        this->ps_holdem.stop();
    }else if(this->mode == Mode::SHORTDECK){
        this->ps_shortdeck.stop();
    }
}
```