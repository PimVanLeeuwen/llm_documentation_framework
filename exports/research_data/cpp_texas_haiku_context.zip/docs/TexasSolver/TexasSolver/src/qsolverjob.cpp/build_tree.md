`build_tree`: The function of `build_tree` is to build a game tree data structure for Texas Hold'em poker or Shortdeck poker based on the provided settings and rules.

**Code Description**: This code snippet defines a method called `build_tree` within the `QSolverJob` class. It appears to be part of a larger system responsible for solving poker games, specifically Texas Hold'em and Shortdeck variants. The method takes various parameters such as game mode (Hold'em or Shortdeck), player commitments, current round, raise limit, small and big blinds, stack size, and all-in threshold. Based on these inputs, it calls the `build_game_tree` method from the `PokerSolver` class to construct a game tree data structure. The process involves initializing a `GameTree` object with the given parameters and recursively adding child nodes according to the rules of the respective poker variant.\\
## Code: 
```
void QSolverJob::build_tree(){
    qDebug().noquote() << tr("building tree..");//.toStdString() << endl;
    if(this->mode == Mode::HOLDEM){
        ps_holdem.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }else if(this->mode == Mode::SHORTDECK){
        ps_shortdeck.build_game_tree(oop_commit,ip_commit,current_round,raise_limit,small_blind,big_blind,stack,*gtbs.get(),allin_threshold);
    }
    qDebug().noquote() << tr("build tree finished");//.toStdString() << endl;
}
```