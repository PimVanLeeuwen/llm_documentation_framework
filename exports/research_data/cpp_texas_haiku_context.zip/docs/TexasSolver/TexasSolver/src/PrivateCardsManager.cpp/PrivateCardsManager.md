`PrivateCardsManager`: The function of `PrivateCardsManager` is to initialize and set up the private cards manager for a poker game, considering interactions between players' hands and the initial board state.

**Parameters**:
`vector<vector<PrivateCards>> private_cards`: A 2D vector containing each player's private cards.
`int player_number`: The number of players in the game.
`uint64_t initialboard`: The initial state of the board, represented as a 64-bit unsigned integer.

**Code Description**: 
The `PrivateCardsManager` constructor initializes the object with the provided parameters. It sets up a data structure to store the relative probabilities for each player's private cards, considering interactions between players' hands and the initial board state. The method also calls `setRelativeProbs` to calculate these relative probabilities.\\
## Code: 
```
PrivateCardsManager::PrivateCardsManager(vector<vector<PrivateCards>> private_cards, int player_number,
                                         uint64_t initialboard) {
    this->private_cards = private_cards;
    this->player_number = player_number;
    this->card_player_index = vector<vector<int>>(52 * 52);
    for(int i = 0;i < 52 * 52;i ++){
        this->card_player_index[i] = vector<int>(this->player_number,-1);
    }

    // 用一个二维数组记录每个Private Combo的对应index,方便从一方的手牌找对方的同名卡牌的index
    for(int player_id = 0;player_id < player_number;player_id ++){
        vector<PrivateCards> privateCombos = private_cards[player_id];
        for(std::size_t i = 0;i < privateCombos.size();i ++){
            PrivateCards one_private_combo = privateCombos[i];
            this->card_player_index[one_private_combo.hashCode()][player_id] = i;
        }
    }

    this->initialboard = initialboard;
    this->setRelativeProbs();
}
```