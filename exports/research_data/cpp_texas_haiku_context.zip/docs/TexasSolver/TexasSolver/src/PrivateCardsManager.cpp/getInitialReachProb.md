`getInitialReachProb`: The function calculates the initial reach probability for a given player and initial board state.

**Parameters**:
`int player`: The index of the player for whom to calculate the reach probability.
`uint64_t initialboard`: The current state of the poker board as a 64-bit unsigned integer.

**Code Description**: 
The `getInitialReachProb` function iterates over the private cards of the specified player and calculates their reach probabilities based on whether they intersect with the given initial board state. If an intersection is detected, the probability for that card is set to 0; otherwise, it is set to the weight of the card as defined in the `PrivateCards` class. The function returns a vector of these calculated probabilities.\\
## Code: 
```
vector<float> PrivateCardsManager::getInitialReachProb(int player, uint64_t initialboard) {
    int cards_len =  this->private_cards[player].size();
    vector<float> probs = vector<float>(cards_len);
    for(int i = 0;i < cards_len;i ++){
        PrivateCards pc = this->private_cards[player][i];
        if(Card::boardsHasIntercept(initialboard,Card::boardInts2long(pc.get_hands()))) {
            probs[i] = 0;
        }else{
            probs[i] = this->private_cards[player][i].weight;
        }
    }
    return probs;
}
```