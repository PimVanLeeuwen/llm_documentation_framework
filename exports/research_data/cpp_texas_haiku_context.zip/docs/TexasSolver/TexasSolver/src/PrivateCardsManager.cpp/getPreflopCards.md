`getPreflopCards`: The function returns the private cards of a specific player for the preflop stage.

**Parameters**:\
`int player`: The index of the player's private cards to be retrieved. 

**Code Description**: This method retrieves and returns the private cards of a specified player from the `private_cards` vector, which stores the private cards for each player in the game.\\
## Code: 
```
vector<PrivateCards>& PrivateCardsManager::getPreflopCards(int player) {
    return this->private_cards[player];
}
```