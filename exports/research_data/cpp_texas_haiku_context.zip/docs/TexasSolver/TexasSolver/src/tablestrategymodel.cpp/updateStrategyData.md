`updateStrategyData`: The function of `updateStrategyData` is to update the strategy data for a given game tree node by iterating through its children nodes and updating their strategy data accordingly.

**Code Description**: This code snippet appears to be part of a poker game solver, specifically designed to update strategy data for a game tree node. It iterates through the children nodes of the current node, updates their strategy data, and then recursively calls itself on each child node's children. The function also checks if the solver job is valid and if the node has a parent before proceeding with the updates.\\
## Code: 
```
void TableStrategyModel::updateStrategyData(){
    if(this->treeItem != NULL){
        shared_ptr<GameTreeNode> node = this->treeItem->m_treedata.lock();
        this->setupModelData();
        if(node != nullptr && node->getType() == GameTreeNode::GameTreeNode::ACTION){
            shared_ptr<ActionNode> actionNode = dynamic_pointer_cast<ActionNode>(node);
            //actionNode->getTrainable();
            // create a vector card and input it to solver and get the result
            vector<Card> deal_cards;
            GameTreeNode::GameRound root_round = this->qSolverJob->get_solver()->getGameTree()->getRoot()->getRound();
            GameTreeNode::GameRound current_round = actionNode->getRound();
            this->current_player = actionNode->getPlayer();
            if(root_round == GameTreeNode::GameRound::FLOP){
                if(current_round == GameTreeNode::GameRound::TURN){deal_cards.push_back(this->turn_card);}
                if(current_round == GameTreeNode::GameRound::RIVER){deal_cards.push_back(this->turn_card);deal_cards.push_back(this->river_card);}
            }
            else if(root_round == GameTreeNode::GameRound::TURN){
                if(current_round == GameTreeNode::GameRound::RIVER){deal_cards.push_back(this->river_card);}
            }
            if(this->qSolverJob->get_solver() != NULL && this->qSolverJob->get_solver()->get_solver() != NULL){
                vector<vector<vector<float>>> current_strategy = this->qSolverJob->get_solver()->get_solver()->get_strategy(actionNode,deal_cards);
                this->current_strategy = current_strategy;

                vector<vector<vector<float>>> current_evs = this->qSolverJob->get_solver()->get_solver()->get_evs(actionNode,deal_cards);
                this->current_evs = current_evs;

                for(int i = 0;i < 52;i ++){
                    for(int j = 0;j < 52;j ++){
                        const vector<float>& one_strategy = this->current_strategy[i][j];
                        if(one_strategy.empty())continue;
                        Card card1 = this->cardint2card[i];
                        Card card2 = this->cardint2card[j];

                        int rank1 = card1.getCardInt() / 4;
                        int suit1 = card1.getCardInt() - (rank1)*4;
                        int index1 = 12 - rank1; // this index is the index of the actal ui, so AKQ would be the lower index and 234 would be high

                        int rank2 = card2.getCardInt() / 4;
                        int suit2 = card2.getCardInt() - (rank2)*4;
                        int index2 = 12 - rank2;

                        if(index1 == index2){
                            this->ui_strategy_table[index1][index2].push_back(std::pair<int,int>(i,j));
                        }
                        else if(suit1 == suit2){
                            this->ui_strategy_table[min(index1,index2)][max(index1,index2)].push_back(std::pair<int,int>(i,j));
                        }else{
                            this->ui_strategy_table[max(index1,index2)][min(index1,index2)].push_back(std::pair<int,int>(i,j));
                        }
                    }
                }
            }
        }
        if(this->qSolverJob->get_solver() != NULL  && this->qSolverJob->get_solver()->get_solver() != NULL && node != nullptr){
            vector<PrivateCards>& p1range = this->qSolverJob->get_solver()->player1Range;
            vector<PrivateCards>& p2range = this->qSolverJob->get_solver()->player2Range;

            for(auto one_private:p1range)this->p1_range[one_private.card1][one_private.card2] = one_private.weight;
            for(auto one_private:p2range)this->p2_range[one_private.card1][one_private.card2] = one_private.weight;

            shared_ptr<GameTreeNode> iter_node = node->getParent();
            shared_ptr<GameTreeNode> last_node = node;
            while(iter_node != nullptr){
                if(iter_node->getType() == GameTreeNode::GameTreeNode::ACTION){
                    shared_ptr<ActionNode> iterActionNode = dynamic_pointer_cast<ActionNode>(iter_node);
                    vector<Card> deal_cards;
                    GameTreeNode::GameRound root_round = this->qSolverJob->get_solver()->getGameTree()->getRoot()->getRound();
                    GameTreeNode::GameRound current_round = iterActionNode->getRound();
                    if(root_round == GameTreeNode::GameRound::FLOP){
                        if(current_round == GameTreeNode::GameRound::TURN){deal_cards.push_back(this->turn_card);}
                        if(current_round == GameTreeNode::GameRound::RIVER){deal_cards.push_back(this->turn_card);deal_cards.push_back(this->river_card);}
                    }
                    else if(root_round == GameTreeNode::GameRound::TURN){
                        if(current_round == GameTreeNode::GameRound::RIVER){deal_cards.push_back(this->river_card);}
                    }

                    vector<vector<vector<float>>> current_strategy = this->qSolverJob->get_solver()->get_solver()->get_strategy(iterActionNode,deal_cards);

                    int child_chosen = -1;
                    for(std::size_t i = 0;i < iterActionNode->getChildrens().size();i ++){
                        if(iterActionNode->getChildrens()[i] == last_node){
                            child_chosen = i;
                            break;
                        }
                    }
                    if(child_chosen == -1)throw runtime_error("no child chosen");
                    for(std::size_t i = 0;i < 52;i ++){
                        for(std::size_t j = 0;j < 52;j ++){
                            if(current_strategy[i][j].size() == 0)continue;
                            if(iterActionNode->getPlayer() == 0){ // p1, IP
                                this->p1_range[i][j] *= current_strategy[i][j][child_chosen];
                            }
                            else if(iterActionNode->getPlayer() == 1){ // p2, OOP
                                this->p2_range[i][j] *= current_strategy[i][j][child_chosen];
                            }else throw runtime_error("player not exist in tablestrategymodel");
                        }
                    }
                }

                iter_node = iter_node->getParent();
                last_node = last_node->getParent();
            }
        }
        if(this->qSolverJob->get_solver() != NULL  && this->qSolverJob->get_solver()->get_solver() != NULL && node != nullptr){
            this->total_strategy = this->get_total_strategy();
        }
    }
}
```