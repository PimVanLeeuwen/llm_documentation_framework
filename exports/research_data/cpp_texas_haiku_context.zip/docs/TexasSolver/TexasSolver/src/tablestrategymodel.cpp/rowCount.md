`rowCount`: The function of `rowCount` is to return the number of rows in a table.

**Parameters**: 
`const QModelIndex &parent`: This parameter represents the parent index, which is used to determine the scope of the row count. In this case, it's not explicitly used within the method, but it's still required as part of the `rowCount` function signature.

**Code Description**: The code calls the `get_solver` method on an instance of `QSolverJob`, which returns a pointer to a specific poker solver based on the job mode. It then calls the `get_deck` method on this solver, and subsequently the `getRanks` method on the deck object. Finally, it returns the size of the ranks vector as the row count.\\
## Code: 
```
int TableStrategyModel::rowCount(const QModelIndex &parent) const
{
    return this->qSolverJob->get_solver()->get_deck()->getRanks().size();
}
```