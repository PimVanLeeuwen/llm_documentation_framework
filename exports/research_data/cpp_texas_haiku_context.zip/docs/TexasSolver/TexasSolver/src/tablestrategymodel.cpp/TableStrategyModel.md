`TableStrategyModel`: The function of `TableStrategyModel` is to initialize a table strategy model for displaying poker solver data in a table format.

**Parameters**:
`QSolverJob * data`: This parameter represents the poker solver job data that will be used to populate the table.
`QObject *parent`: This parameter specifies the parent object of the table strategy model, which can be used to access other objects or functionality within the application.

**Code Description**: The `TableStrategyModel` class initializes a new instance by calling its constructor with the provided `QSolverJob` data and `QObject` parent. The `setupModelData()` method is then called to set up the model's internal data structure, which will be used to display the poker solver data in a table format.\\
## Code: 
```
TableStrategyModel::TableStrategyModel(QSolverJob * data, QObject *parent)
    : QAbstractItemModel(parent)
{
    this->qSolverJob = data;
    setupModelData();
}
```