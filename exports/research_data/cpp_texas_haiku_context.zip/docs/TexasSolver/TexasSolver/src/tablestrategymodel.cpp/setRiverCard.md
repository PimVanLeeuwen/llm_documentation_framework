`setRiverCard`: The function of `setRiverCard` is to set the river card in the TableStrategyModel.

**Parameters**:
`Card river_card`: This parameter represents the Card object that will be assigned as the river card.

**Code Description**: 
The `setRiverCard` method takes a `Card` object as input and assigns it to the instance variable `river_card`.\\
## Code: 
```
void TableStrategyModel::setRiverCard(Card river_card){
    this->river_card = river_card;
}
```