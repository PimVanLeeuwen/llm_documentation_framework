`setTrunCard`: The function of `setTrunCard` is to set the current turn card in the game.

**Parameters**:
`Card turn_card`: This parameter represents the Card object that will be set as the current turn card.

**Code Description**: 
The `setTrunCard` method takes a `Card` object as input and assigns it to the instance variable `turn_card`. This allows the model to keep track of the current turn card in the game.\\
## Code: 
```
void TableStrategyModel::setTrunCard(Card turn_card){
    this->turn_card = turn_card;
}
```