**columnCount**: The function of `columnCount` is to return the number of columns in a table.

**Parameters**: 
`const QModelIndex &parent`: This parameter represents the parent index, which is used to determine the scope of the column count. It's likely used to specify whether the column count should be calculated for a specific section or the entire table.

**Code Description**: The `columnCount` function in the `TableStrategyModel` class returns the number of columns by calling the `get_solver()` method on the `qSolverJob` object, which then calls the `get_deck()` method to retrieve the deck. Finally, it retrieves the ranks from the deck and returns their size as the column count.\\
## Code: 
```
int TableStrategyModel::columnCount(const QModelIndex &parent) const
{
    return this->qSolverJob->get_solver()->get_deck()->getRanks().size();
}
```