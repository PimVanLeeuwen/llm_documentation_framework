`getCards`: The function of `getCards` is to return a reference to the vector of cards stored in the ChanceNode object.

**Code Description**: This method, `getCards`, is a simple getter function that returns a constant reference to the internal vector of cards (`this->cards`) stored within the ChanceNode class. It does not modify or create any new data; it merely provides access to the existing collection of cards associated with this particular node in the TexasSolver's chance-based calculations.\\
## Code: 
```
const vector<Card>& ChanceNode::getCards() {
    return this->cards;
}
```