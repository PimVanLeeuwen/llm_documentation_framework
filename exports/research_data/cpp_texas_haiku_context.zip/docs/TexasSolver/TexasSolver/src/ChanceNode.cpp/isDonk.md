`isDonk`: The function of `isDonk` is to check if the current chance node represents a "donk" action.

**Code Description**: This method, `isDonk`, is a simple getter that returns the value of the `donk` member variable. It does not perform any calculations or operations; it merely returns the existing state of the `donk` flag. The purpose of this function appears to be related to poker strategy, specifically in the context of Texas Hold'em, where "donking" refers to a particular type of action taken by a player.\\
## Code: 
```
bool ChanceNode::isDonk(){
    return this->donk;
}
```