`ChanceNode`: The function of `ChanceNode` is to create a new node in the game tree that represents a chance event, such as drawing a card or shuffling the deck.

**Parameters**:
`const shared_ptr<GameTreeNode> children`: This parameter represents the child nodes of the current chance node.
`GameTreeNode::GameRound round`: This parameter specifies the current round of the game.
`double pot`: This parameter represents the current pot size.
`shared_ptr<GameTreeNode> parent`: This parameter points to the parent node of the current chance node.
`const vector<Card>& cards`: This parameter contains a reference to a vector of cards that are relevant to the chance event.
`bool donk`: This boolean parameter indicates whether the chance event is related to a "donk" action, which is a specific type of play in Texas Hold'em.

**Code Description**: The `ChanceNode` constructor initializes a new game tree node with the specified parameters. It sets up the node's properties, such as its round number, pot size, and parent node, while also storing the child nodes, cards relevant to the chance event, and donk status.\\
## Code: 
```
ChanceNode::ChanceNode(const shared_ptr<GameTreeNode> children, GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent,
                       const vector<Card>& cards,bool donk): GameTreeNode(round,pot,std::move(parent)),cards(cards) {
    this->children = children;
    this->donk = donk;
}
```