`getType`: The function of `getType` is to return the type of a ChanceNode in the TexasSolver project structure.

**Code Description**: This method, `getType`, is part of the `ChanceNode` class within the `TexasSolver` project. It returns the type of the current node as `CHANCE`.\\
## Code: 
```
GameTreeNode::GameTreeNodeType ChanceNode::getType() {
    return CHANCE;
}
```