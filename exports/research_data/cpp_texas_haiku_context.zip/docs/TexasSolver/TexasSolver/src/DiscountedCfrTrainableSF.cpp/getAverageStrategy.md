`getAverageStrategy`: The function calculates the average strategy for a given set of actions and cards in a Texas Hold'em game, specifically designed for the Discounted CFR Trainable SF algorithm.

**Code Description**: This method iterates over each private card (hand) and for each action, it sums up the cumulative regret plus values (`cum_r_plus`) across all possible public cards. It then calculates the average strategy by dividing the cumulative regret plus value for a specific action by the total sum of regret plus values for that private card. If the total sum is zero, it assigns an equal probability to each action (1.0 / `action_number`). The resulting average strategy is returned as a vector of floats.\\
## Code: 
```
const vector<float> DiscountedCfrTrainableSF::getAverageStrategy() {
    vector<float> average_strategy;
    average_strategy = vector<float>(this->action_number * this->card_number);
    for (int private_id = 0; private_id < this->card_number; private_id++) {
        float r_plus_sum = 0;
        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            r_plus_sum += this->cum_r_plus[index];
        }

        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            if(r_plus_sum) {
                average_strategy[index] = this->cum_r_plus[index] / r_plus_sum;
            }else{
                average_strategy[index] = 1.0 / this->action_number;
            }
        }
    }
    return average_strategy;
}
```