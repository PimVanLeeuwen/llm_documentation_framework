`getcurrentStrategy`: The function of `getcurrentStrategy` is to return the current strategy in a game, calculated based on maximum regressed values for each action-private card pair.

**Code Description**: This code snippet defines a method called `getcurrentStrategy` within the class `DiscountedCfrTrainableSF`. It simply calls another method named `getcurrentStrategyNoCache` and returns its result. The purpose of this method is to retrieve the current strategy in a game, which represents the optimal action to take for each possible private card combination. The strategy values are calculated based on the maximum regressed value for each action-private card pair divided by the sum of these values across all private cards for that action.\\
## Code: 
```
const vector<float> DiscountedCfrTrainableSF::getcurrentStrategy() {
    return this->getcurrentStrategyNoCache();
}
```