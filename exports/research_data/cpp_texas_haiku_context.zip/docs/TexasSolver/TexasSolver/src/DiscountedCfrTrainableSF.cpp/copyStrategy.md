`copyStrategy`: The function of `copyStrategy` is to copy the strategy from another trainable object.

**Parameters**:\
`shared_ptr<Trainable> other_trainable`: A shared pointer to a Trainable object, which contains the strategy to be copied.

**Code Description**: 
The code first casts the `other_trainable` object to a `DiscountedCfrTrainableSF` object using `dynamic_pointer_cast`. This is necessary because the `copyStrategy` function is defined in the `DiscountedCfrTrainableSF` class, and it needs access to its own member variables. 

Once the cast is successful, the code copies the `r_plus` and `cum_r_plus` vectors from the other trainable object into this object's corresponding vectors using the `assign` method. This effectively copies the strategy from the other trainable object into this one.\\
## Code: 
```
void DiscountedCfrTrainableSF::copyStrategy(shared_ptr<Trainable> other_trainable){
    shared_ptr<DiscountedCfrTrainableSF> trainable = dynamic_pointer_cast<DiscountedCfrTrainableSF>(other_trainable);
    this->r_plus.assign(trainable->r_plus.begin(),trainable->r_plus.end());
    this->cum_r_plus.assign(trainable->cum_r_plus.begin(),trainable->cum_r_plus.end());
}
```