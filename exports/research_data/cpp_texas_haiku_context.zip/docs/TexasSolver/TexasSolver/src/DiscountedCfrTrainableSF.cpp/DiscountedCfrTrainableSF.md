`DiscountedCfrTrainableSF`: The function of `DiscountedCfrTrainableSF` is to initialize the necessary data structures for computing discounted CFR values in a Texas Hold'em game.

**Parameters**:
`vector<PrivateCards> *privateCards`: This parameter represents the private cards held by each player, which are used to compute the expected values.
`ActionNode &actionNode`: This parameter represents the current action node in the game tree, from which the children nodes can be retrieved.

**Code Description**: The code initializes several data structures:
- `evs`, `r_plus`, and `cum_r_plus` vectors of size `action_number * card_number`, which are used to store the expected values, R+ values, and cumulative R+ values respectively.
- It also sets up the `privateCards` pointer and retrieves the number of actions and cards from the `actionNode` and `privateCards` objects.\\
## Code: 
```
DiscountedCfrTrainableSF::DiscountedCfrTrainableSF(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();
    this->evs = vector<EvsStorage>(this->action_number * this->card_number, (EvsStorage) 0.0);
    this->r_plus = vector<RplusStorage>(this->action_number * this->card_number, (RplusStorage) 0.0);
    this->cum_r_plus = vector<CumRplusStorage>(this->action_number * this->card_number, (CumRplusStorage) 0.0);
}
```