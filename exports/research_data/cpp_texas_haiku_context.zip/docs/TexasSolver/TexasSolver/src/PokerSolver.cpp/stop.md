`stop`: The function of `stop` is to stop the solver if it exists.

**Code Description**: This method checks if a solver object has been initialized. If so, it calls the `stop` method on that solver object, effectively stopping its execution.\\
## Code: 
```
void PokerSolver::stop(){
    if(this->solver != nullptr){
        this->solver->stop();
    }
}
```