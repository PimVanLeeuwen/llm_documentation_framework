`PokerSolver`: The function of `PokerSolver` is to initialize a poker solver object with the given parameters.

**Parameters**:
- `string ranks`: A string containing comma-separated card ranks.
- `string suits`: A string containing comma-separated card suits.
- `string compairer_file`: A file path for the poker hand data comparison file.
- `int compairer_file_lines`: The number of lines in the poker hand data comparison file.
- `string compairer_file_bin`: A binary representation of the poker hand data comparison file.

**Code Description**: 
The code initializes a `PokerSolver` object by splitting the input strings into vectors of ranks and suits, creating a deck of cards from these vectors, and loading a poker hand data comparison file. It then creates an instance of the `Dic5Compairer` class with the loaded data and stores it in the solver object.\\
## Code: 
```
PokerSolver::PokerSolver(string ranks, string suits, string compairer_file,int compairer_file_lines, string compairer_file_bin) {
    vector<string> ranks_vector = string_split(ranks,',');
    vector<string> suits_vector = string_split(suits,',');
    this->deck = Deck(ranks_vector,suits_vector);
    this->compairer = make_shared<Dic5Compairer>(compairer_file,compairer_file_lines,compairer_file_bin);
}
```