`getGameTree`: The function of `getGameTree` is to return a reference to the game tree object, which represents the entire game structure.

**Code Description**: This method returns a shared pointer to a GameTree object, indicating that it provides access to the game's overall structure. The returned object likely contains information about all possible game states, moves, and outcomes, allowing for the simulation or analysis of the game in its entirety.\\
## Code: 
```
const shared_ptr<GameTree> &PokerSolver::getGameTree() const {
    return game_tree;
}
```