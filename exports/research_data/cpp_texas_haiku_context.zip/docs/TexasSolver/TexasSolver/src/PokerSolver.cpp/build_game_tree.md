`build_game_tree`: The function of `build_game_tree` is to build a game tree data structure for Texas Hold'em poker based on the provided settings and rules.

**Parameters**:
`float oop_commit`: The out-of-position commitment, representing the amount committed by an opponent.
`float ip_commit`: The in-position commitment, representing the amount committed by the player themselves.
`int current_round`: The current round number of the game.
`int raise_limit`: The maximum number of raises allowed in a hand.
`float small_blind`: The size of the small blind bet.
`float big_blind`: The size of the big blind bet.
`float stack`: The total stack size of the player.
`GameTreeBuildingSettings buildingSettings`: A settings object containing parameters for building the game tree, such as recursion depth and node count limits.
`float allin_threshold`: The threshold at which an all-in action is considered.

**Code Description**: This function creates a new `GameTree` instance with the provided parameters and assigns it to the `game_tree` member variable of the `PokerSolver` class. The `GameTree` constructor recursively builds the game tree based on the input settings and rules, creating a data structure representing possible game outcomes and their associated probabilities.\\
## Code: 
```
void PokerSolver::build_game_tree(
        float oop_commit,
        float ip_commit,
        int current_round,
        int raise_limit,
        float small_blind,
        float big_blind,
        float stack,
        GameTreeBuildingSettings buildingSettings,
        float allin_threshold
){
    shared_ptr<GameTree> game_tree = make_shared<GameTree>(
            this->deck,
            oop_commit,
            ip_commit,
            current_round,
            raise_limit,
            small_blind,
            big_blind,
            stack,
            buildingSettings,
            allin_threshold
    );
    this->game_tree = game_tree;
}
```