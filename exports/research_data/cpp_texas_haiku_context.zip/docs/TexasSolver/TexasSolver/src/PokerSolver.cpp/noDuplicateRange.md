`noDuplicateRange`: The function of `noDuplicateRange` is to remove duplicate private card ranges and filter out those that do not intersect with the given board.

**Parameters**:
`const vector<PrivateCards> &private_range`: This parameter is a reference to a vector of PrivateCards objects, which represents a collection of private card ranges.
`uint64_t board_long`: This parameter is an unsigned 64-bit integer representing the board's state in a compact binary format.

**Code Description**: The `noDuplicateRange` function iterates over each PrivateCards object in the input vector. It checks if the current range has been seen before by looking up its hash code in an unordered map. If it has, the function throws a runtime error indicating a duplicate key. Otherwise, it adds the range to the map and checks if the board intersects with the current hand using the `boardsHasIntercept` method from the Card class. If there is no intersection, the range is added to the output vector. The function returns this filtered and deduplicated vector of PrivateCards objects.\\
## Code: 
```
vector<PrivateCards> noDuplicateRange(const vector<PrivateCards> &private_range, uint64_t board_long) {
    vector<PrivateCards> range_array;
    unordered_map<int,bool> rangekv;
    for(PrivateCards one_range:private_range){
        if(rangekv.find(one_range.hashCode()) != rangekv.end())
            throw runtime_error(tfm::format("duplicated key %s",one_range.toString()));
        rangekv[one_range.hashCode()] = true;
        uint64_t hand_long = Card::boardInts2long(one_range.get_hands());
        if(!Card::boardsHasIntercept(hand_long,board_long)){
            range_array.push_back(one_range);
        }
    }
    return range_array;
}
```