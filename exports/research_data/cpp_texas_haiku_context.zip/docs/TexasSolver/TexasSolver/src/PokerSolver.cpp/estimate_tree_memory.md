`estimate_tree_memory`: The function of `estimate_tree_memory` is to estimate the memory required by the game tree.

**Parameters**:
`QString range1`: This parameter represents the poker range for player 1.
`QString range2`: This parameter represents the poker range for player 2.
`QString board`: This parameter represents the current state of the board, which is a string containing comma-separated card values.

**Code Description**: The function first checks if the game tree has been built. If not, it prints an error message and returns 0. Otherwise, it converts the input strings to vectors of PrivateCards objects using the `PrivateRangeConverter::rangeStr2Cards` method. It then estimates the memory required by the game tree based on the number of cards in the deck (excluding those already on the board), the size of player 1's range, and the size of player 2's range. The estimated memory is returned as a long long integer value.\\
## Code: 
```
long long PokerSolver::estimate_tree_memory(QString range1,QString range2,QString board){
    if(this->game_tree == nullptr){
        qDebug().noquote() << QObject::tr("Please buld tree first.");
        return 0;
    }
    else{
        string player1RangeStr = range1.toStdString();
        string player2RangeStr = range2.toStdString();

        vector<string> board_str_arr = string_split(board.toStdString(),',');
        vector<int> initialBoard;
        for(string one_board_str:board_str_arr){
            initialBoard.push_back(Card::strCard2int(one_board_str));
        }

        vector<PrivateCards> range1 = PrivateRangeConverter::rangeStr2Cards(player1RangeStr,initialBoard);
        vector<PrivateCards> range2 = PrivateRangeConverter::rangeStr2Cards(player2RangeStr,initialBoard);
        return this->game_tree->estimate_tree_memory(this->deck.getCards().size() - initialBoard.size(),range1.size(),range2.size());
    }
}
```