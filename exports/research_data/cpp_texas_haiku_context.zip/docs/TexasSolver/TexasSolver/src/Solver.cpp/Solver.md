**Solver**: The function of `Solver` is to initialize the solver object with a shared pointer to a game tree.

**Parameters**:
`shared_ptr<GameTree> tree`: A shared pointer to an instance of the `GameTree` class, which represents the game tree that the solver will operate on.

**Code Description**: The `Solver` constructor takes a shared pointer to a `GameTree` object as input and assigns it to the `tree` member variable of the solver object. This allows the solver to access and manipulate the game tree data structure.\\
## Code: 
```
Solver::Solver(shared_ptr<GameTree> tree) {
    this->tree = tree;
}
```