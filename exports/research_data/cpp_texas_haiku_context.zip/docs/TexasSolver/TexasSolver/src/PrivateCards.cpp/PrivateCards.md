`PrivateCards`: The function of `PrivateCards` is to initialize a PrivateCards object with two private cards and their corresponding weight.

**Parameters**:
`int card1`: The first private card, represented as an integer.
`int card2`: The second private card, represented as an integer.
`float weight`: The weight associated with the two private cards.

**Code Description**: This function initializes a PrivateCards object by setting its member variables: `card1`, `card2`, `weight`, `relative_prob`, `card_vec`, and `hash_code`. It also calculates the board long value using the Card::boardInts2long method.\\
## Code: 
```
PrivateCards::PrivateCards(int card1, int card2, float weight) {
    this->card1 = card1;
    this->card2 = card2;
    this->weight = weight;
    this->relative_prob = 0;
    this->card_vec = vector<int>{this->card1,this->card2};
    if (card1 > card2){
        this->hash_code = card1 * 52 + card2;
    }else{
        this->hash_code = card2 * 52 + card1;
    }
    this->board_long = Card::boardInts2long(this->card_vec);
}
```