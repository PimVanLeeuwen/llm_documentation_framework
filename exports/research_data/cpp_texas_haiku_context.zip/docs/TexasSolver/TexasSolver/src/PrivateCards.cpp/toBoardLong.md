## toBoardLong: 
The function of `toBoardLong` is to convert the private cards into a long integer representation for the board.

## Code Description:
The `toBoardLong` method in the `PrivateCards` class returns the value stored in the `board_long` variable. This suggests that the `board_long` variable has been previously set with a long integer representation of the board, possibly through another method like `Card::boardInts2long`. The function does not perform any calculations or transformations on the input data; it simply retrieves and returns the stored value.\\
## Code: 
```
uint64_t PrivateCards::toBoardLong() {
    return this->board_long;
    //return Card::boardInts2long(this->card_vec);
}
```