`RoughStrategyItemDelegate`: The function of `RoughStrategyItemDelegate` is to initialize the object with a DetailWindowSetting and a parent QObject.

**Parameters**:
`DetailWindowSetting* detailWindowSetting`: This parameter represents the settings for a detail window, which will be used by the RoughStrategyItemDelegate.
`QObject *parent`: This parameter represents the parent object of the RoughStrategyItemDelegate, which is typically used in Qt to establish an ownership relationship between objects.

**Code Description**: The code initializes the RoughStrategyItemDelegate object with the provided DetailWindowSetting and sets its parent to the specified QObject.\\
## Code: 
```
RoughStrategyItemDelegate::RoughStrategyItemDelegate(DetailWindowSetting* detailWindowSetting,QObject *parent) :
    WordItemDelegate(parent)
{
    this->detailWindowSetting = detailWindowSetting;
}
```