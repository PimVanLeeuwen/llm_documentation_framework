`paint`: The function of `paint` is to draw a gray rectangle and then call the `paint_strategy` method to display the strategy data.

**Parameters**:
- `QPainter *painter`: A pointer to a QPainter object used for drawing.
- `const QStyleOptionViewItem &option`: A reference to a QStyleOptionViewItem object containing information about the item being painted.
- `const QModelIndex &index`: A reference to a QModelIndex object representing the index of the item in the model.

**Code Description**: The code saves the current painter state, draws a gray rectangle over the entire option rect, calls the `paint_strategy` method to paint the strategy data, and then restores the original painter state.\\
## Code: 
```
void RoughStrategyItemDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    painter->save();

    QRect rect(option.rect.left(), option.rect.top(),\
             option.rect.width(), option.rect.height());
    QBrush brush(Qt::gray);
    painter->fillRect(rect, brush);

    this->paint_strategy(painter,option,index);

    painter->restore();
}
```