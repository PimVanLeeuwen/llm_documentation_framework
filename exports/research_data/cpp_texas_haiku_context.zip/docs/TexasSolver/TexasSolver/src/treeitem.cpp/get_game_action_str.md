`get_game_action_str`: The function of `get_game_action_str` is to convert a game action and an amount into a human-readable string.

**Parameters**:
`GameTreeNode::PokerActions action`: This parameter represents the type of poker action being performed, such as checking, betting, raising, folding, or calling.
`float amount`: This parameter represents the amount associated with the poker action, if applicable (e.g., for bets, raises).

**Code Description**: The function uses a series of if-else statements to determine which string representation of the game action and amount to return. If the action is unknown, it throws a runtime error.\\
## Code: 
```
QString TreeItem::get_game_action_str(GameTreeNode::PokerActions action,float amount) const{
    if(action == GameTreeNode::PokerActions::CHECK){
        return QObject::tr("CHECK");
    }
    else if(action == GameTreeNode::PokerActions::BET){
        return QObject::tr("BET ") + QString::number(amount);
    }
    else if(action == GameTreeNode::PokerActions::RAISE){
        return QObject::tr("RAISE ") + QString::number(amount);
    }
    else if(action == GameTreeNode::PokerActions::FOLD){
        return QObject::tr("FOLD ");
    }
    else if(action == GameTreeNode::PokerActions::CALL){
        return QObject::tr("CALL");
    }else{
        throw runtime_error("unknown action when converting in get_game_action_str");
    }

}
```