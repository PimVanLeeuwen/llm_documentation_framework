`get_round_str`: The function of `get_round_str` is to return a string representation of the given game round.

**Parameters**: 
`GameTreeNode::GameRound round`: This parameter represents the current game round in a poker game, which can be either FLOP, TURN, or RIVER.

**Code Description**: 
The `get_round_str` function takes a `GameTreeNode::GameRound` enum value as input and returns a corresponding string representation. It uses if-else statements to check the value of the `round` parameter and returns the appropriate string for each game round (FLOP, TURN, or RIVER). If the input `round` is not recognized, it throws a runtime error with a message indicating that the round must be one of FLOP, TURN, or RIVER.\\
## Code: 
```
QString TreeItem::get_round_str(GameTreeNode::GameRound round) const{
    if(round == GameTreeNode::GameRound::FLOP){
        return QObject::tr("FLOP");
    }
    else if(round == GameTreeNode::GameRound::TURN){
        return QObject::tr("TURN");
    }
    else if(round == GameTreeNode::GameRound::RIVER){
        return QObject::tr("RIVER");
    }
    else throw runtime_error("round not recognized, must be in flop,turn,river");
}
```