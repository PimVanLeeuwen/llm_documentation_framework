`RangeSelectorTableDelegate`: The function of `RangeSelectorTableDelegate` is to act as a delegate for a table model, specifically designed for range selection.

**Parameters**:
`QStringList ranks`: This parameter represents a list of ranks that will be used in the range selector.
`RangeSelectorTableModel *rangeSelectorTableModel`: This parameter points to an instance of the `RangeSelectorTableModel`, which is likely responsible for managing the data displayed in the table.
`QObject *parent`: This parameter indicates the parent object of the delegate, which can be used to establish a hierarchy between objects.

**Code Description**: The code initializes the `RangeSelectorTableDelegate` by setting its internal state based on the provided parameters. It stores the list of ranks and sets up a reference to the `RangeSelectorTableModel`.\\
## Code: 
```
RangeSelectorTableDelegate::RangeSelectorTableDelegate(QStringList ranks,RangeSelectorTableModel *rangeSelectorTableModel,QObject *parent):WordItemDelegate(parent){
    this->rank_list = ranks;
    this->rangeSelectorTableModel = rangeSelectorTableModel;
}
```