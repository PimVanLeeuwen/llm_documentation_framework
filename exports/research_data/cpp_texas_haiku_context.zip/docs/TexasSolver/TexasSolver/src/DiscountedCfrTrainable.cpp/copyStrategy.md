`copyStrategy`: The function of `copyStrategy` is to copy the strategy from another trainable object.

**Parameters**: shared_ptr<Trainable> other_trainable: A pointer to a Trainable object that contains the strategy to be copied.

**Code Description**: The code dynamically casts the other_trainable object to a DiscountedCfrTrainable object, and then copies its r_plus and cum_r_plus data structures into the current object's corresponding data structures.\\
## Code: 
```
void DiscountedCfrTrainable::copyStrategy(shared_ptr<Trainable> other_trainable){
    shared_ptr<DiscountedCfrTrainable> trainable = dynamic_pointer_cast<DiscountedCfrTrainable>(other_trainable);
    this->r_plus.assign(trainable->r_plus.begin(),trainable->r_plus.end());
    this->cum_r_plus.assign(trainable->cum_r_plus.begin(),trainable->cum_r_plus.end());
}
```