`getAverageStrategy`: The function calculates the average strategy for a given game state, where the average strategy is a vector of probabilities representing the expected action to take at each possible private card combination.

**Code Description**: This function iterates over all possible private card combinations and for each combination, it sums up the cumulative regret plus values (r_plus) for all possible actions. It then divides the r_plus value for each action by this sum to get the average strategy probability for that action at that private card combination. If the sum of r_plus values is zero, it assigns a uniform probability (1/action_number) to all actions. The function returns a vector containing these probabilities for all possible private card combinations and actions.\\
## Code: 
```
const vector<float> DiscountedCfrTrainable::getAverageStrategy() {
    vector<float> average_strategy;
    average_strategy = vector<float>(this->action_number * this->card_number);
    for (int private_id = 0; private_id < this->card_number; private_id++) {
        float r_plus_sum = 0;
        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            r_plus_sum += this->cum_r_plus[index];
        }

        for (int action_id = 0; action_id < action_number; action_id++) {
            int index = action_id * this->card_number + private_id;
            if(r_plus_sum) {
                average_strategy[index] = this->cum_r_plus[index] / r_plus_sum;
            }else{
                average_strategy[index] = 1.0 / this->action_number;
            }
        }
    }
    return average_strategy;
}
```