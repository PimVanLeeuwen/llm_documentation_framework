`DiscountedCfrTrainable`: The function of `DiscountedCfrTrainable` is to initialize and set up the necessary data structures for computing discounted CFR values.

**Parameters**:
`vector<PrivateCards> *privateCards`: This parameter represents a vector of private cards, which are used to determine the possible actions in the game.
`ActionNode &actionNode`: This parameter references an ActionNode object, which contains information about the current game state and its children nodes.

**Code Description**: The code initializes several vectors to store the discounted CFR values (`evs`, `r_plus`, `r_plus_sum`, and `cum_r_plus`) based on the number of actions and private cards. It also sets up the `action_number` and `card_number` variables, which represent the total number of possible actions and private cards, respectively. The code then allocates memory for these vectors with the specified sizes.\\
## Code: 
```
DiscountedCfrTrainable::DiscountedCfrTrainable(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();

    this->evs = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus = vector<float>(this->action_number * this->card_number,0.0);
    this->r_plus_sum = vector<float>(this->card_number,0.0);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number,0.0);
    //this->cum_r_plus_sum = vector<float>(this->card_number);
}
```