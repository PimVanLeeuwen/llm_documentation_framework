`DiscountedCfrTrainableHF`: The function of `DiscountedCfrTrainableHF` is to initialize the necessary data structures for a discounted CFR (Counterfactual Regret Minimization) algorithm in a Texas Hold'em game.

**Parameters**:
`vector<PrivateCards> *privateCards`: This parameter represents the private cards held by each player, which are used to calculate the expected values and regrets.
`ActionNode &actionNode`: This parameter is an ActionNode object that contains information about the current game state, including the available actions and their corresponding children nodes.

**Code Description**: The code initializes several data structures:
- `privateCards`: A pointer to a vector of PrivateCards objects, which represents the private cards held by each player.
- `action_node`: An ActionNode object that contains information about the current game state.
- `action_number` and `card_number`: These variables store the number of available actions and private cards, respectively.
- `evs`, `r_plus`, and `cum_r_plus`: Vectors to store the expected values, regrets, and cumulative regrets for each action and card combination.\\
## Code: 
```
DiscountedCfrTrainableHF::DiscountedCfrTrainableHF(vector<PrivateCards> *privateCards,
                                               ActionNode &actionNode) : action_node(actionNode) {
    this->privateCards = privateCards;
    this->action_number = action_node.getChildrens().size();
    this->card_number = privateCards->size();
    this->evs = vector<EvsStorage>(this->action_number * this->card_number, (EvsStorage) 0.0);
    this->r_plus = vector<RplusStorage>(this->action_number * this->card_number, (RplusStorage) 0.0);
    this->cum_r_plus = vector<CumRplusStorage>(this->action_number * this->card_number, (CumRplusStorage) 0.0);
}
```