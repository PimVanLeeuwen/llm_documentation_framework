`getcurrentStrategy`: The function of `getcurrentStrategy` is to return the current strategy in a game, specifically for a Texas Solver project.

**Code Description**: This code snippet is part of a class called `DiscountedCfrTrainableHF`, which appears to be responsible for calculating and returning strategies based on discounted CFR (Counterfactual Regret) values. The `getcurrentStrategy` method simply calls another method called `getcurrentStrategyNoCache` and returns its result, indicating that the current strategy is calculated without using any caching mechanism.\\
## Code: 
```
const vector<float> DiscountedCfrTrainableHF::getcurrentStrategy() {
    return this->getcurrentStrategyNoCache();
}
```