`isAllZeros`: The function of `isAllZeros` is to check if all elements in the given array are zero.

**Parameters**: 
`const vector<float>& input_array`: This parameter is a reference to a vector of floating-point numbers, which represents the array to be checked for zeros.

**Code Description**: 
The code iterates over each element `i` in the input array using a range-based for loop. If any element `i` is not equal to zero (`i != 0`), it immediately returns `false`, indicating that not all elements are zero. If the loop completes without finding a non-zero element, it returns `true`, indicating that all elements are indeed zero.\\
## Code: 
```
bool DiscountedCfrTrainableHF::isAllZeros(const vector<float>& input_array) {
    for(float i:input_array){
        if (i != 0)return false;
    }
    return true;
}
```