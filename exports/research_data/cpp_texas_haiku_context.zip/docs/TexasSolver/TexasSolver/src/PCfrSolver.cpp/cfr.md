`cfr`: The function of `cfr` is to calculate the Counterfactual Regret Minimization (CFR) value for a given game state.

**Parameters**:
`int player`: The index of the player whose CFR value is being calculated.
`shared_ptr<GameTreeNode> node`: A pointer to the current game tree node.
`const vector<float> &reach_probs`: A reference to a vector containing reach probabilities for each possible card deal.
`int iter`: The number of iterations to perform in the Monte Carlo simulation.
`uint64_t current_board`: The current state of the board, represented as a 64-bit unsigned integer.
`int deal`: The index of the current card deal.

**Code Description**: The `cfr` function uses a switch statement to determine the type of the game tree node and calls the corresponding utility function (e.g., `actionUtility`, `showdownUtility`, etc.) to calculate the CFR value. If the node type is unknown, it throws a runtime error.\\
## Code: 
```
vector<float> PCfrSolver::cfr(int player, shared_ptr<GameTreeNode> node, const vector<float> &reach_probs, int iter,
                                    uint64_t current_board,int deal) {
    switch(node->getType()) {
        case GameTreeNode::ACTION: {
            shared_ptr<ActionNode> action_node = std::dynamic_pointer_cast<ActionNode>(node);
            return actionUtility(player, action_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::SHOWDOWN: {
            shared_ptr<ShowdownNode> showdown_node = std::dynamic_pointer_cast<ShowdownNode>(node);
            return showdownUtility(player, showdown_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::TERMINAL: {
            shared_ptr<TerminalNode> terminal_node = std::dynamic_pointer_cast<TerminalNode>(node);
            return terminalUtility(player, terminal_node, reach_probs, iter, current_board,deal);
        }case GameTreeNode::CHANCE: {
            shared_ptr<ChanceNode> chance_node = std::dynamic_pointer_cast<ChanceNode>(node);
            return chanceUtility(player, chance_node, reach_probs, iter, current_board,deal);
        }default:
            throw runtime_error("node type unknown");
    }
}
```