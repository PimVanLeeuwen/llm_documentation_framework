`PCfrSolver`: The function of `PCfrSolver` is to initialize a PCFR solver object with the given parameters and set up its internal data structures.

**Parameters**:

`shared_ptr<GameTree> tree`: A shared pointer to a GameTree object, which represents the game tree structure.
`vector<PrivateCards> range1`: A vector of PrivateCards objects representing the private cards of player 1.
`vector<PrivateCards> range2`: A vector of PrivateCards objects representing the private cards of player 2.
`vector<int> initial_board`: A vector of integers representing the initial board state.
`shared_ptr<Compairer> compairer`: A shared pointer to a Compairer object, which is used for comparing card values.
`Deck deck`: A Deck object representing the deck of cards.
`int iteration_number`: An integer representing the number of iterations for the solver.
`bool debug`: A boolean indicating whether the solver should run in debug mode.
`int print_interval`: An integer representing the interval at which to print progress updates.
`string logfile`: A string representing the path to a log file.
`string trainer`: A string representing the name of a trainer model.
`Solver::MonteCarolAlg monteCarolAlg`: An enumeration value representing the Monte Carlo algorithm to use.
`int warmup`: An integer representing the number of warm-up iterations.
`float accuracy`: A float representing the desired accuracy level.
`bool use_isomorphism`: A boolean indicating whether to use isomorphism in the solver.
`int use_halffloats`: An integer representing the number of half-floats to use.
`int num_threads`: An integer representing the number of threads to use for parallel computation.

**Code Description**: The code initializes a PCFR solver object by setting up its internal data structures, including the game tree, private cards, and deck. It also sets various parameters such as iteration number, debug mode, print interval, log file path, trainer model name, Monte Carlo algorithm, warm-up iterations, accuracy level, isomorphism usage, half-float count, and thread count. The code uses several helper functions to perform tasks such as filtering duplicate private card ranges, converting board integers to a long value, and retrieving the root node of the game tree.\\
## Code: 
```
PCfrSolver::PCfrSolver(shared_ptr<GameTree> tree, vector<PrivateCards> range1, vector<PrivateCards> range2,
                     vector<int> initial_board, shared_ptr<Compairer> compairer, Deck deck, int iteration_number, bool debug,
                     int print_interval, string logfile, string trainer, Solver::MonteCarolAlg monteCarolAlg,int warmup,float accuracy,bool use_isomorphism,int use_halffloats,int num_threads) :Solver(tree){
    this->initial_board = initial_board;
    this->initial_board_long = Card::boardInts2long(initial_board);
    this->logfile = logfile;
    this->trainer = trainer;
    this->warmup = warmup;

    range1 = this->noDuplicateRange(range1,initial_board_long);
    range2 = this->noDuplicateRange(range2,initial_board_long);

    this->range1 = range1;
    this->range2 = range2;
    this->player_number = 2;
    this->ranges = vector<vector<PrivateCards>>(this->player_number);
    this->ranges[0] = range1;
    this->ranges[1] = range2;

    this->compairer = compairer;

    this->deck = deck;
    this->use_isomorphism = use_isomorphism;
    this->use_halffloats = use_halffloats;

    this->rrm = RiverRangeManager(compairer);
    this->iteration_number = iteration_number;

    vector<vector<PrivateCards>> private_cards(this->player_number);
    private_cards[0] = range1;
    private_cards[1] = range2;
    pcm = PrivateCardsManager(private_cards,this->player_number,Card::boardInts2long(this->initial_board));
    this->debug = debug;
    this->print_interval = print_interval;
    this->monteCarolAlg = monteCarolAlg;
    this->accuracy = accuracy;
    if(num_threads == -1){
        num_threads = omp_get_num_procs();
    }
    qDebug().noquote() << QString::fromStdString(tfm::format(QObject::tr("Using %s threads").toStdString().c_str(),num_threads));
    this->num_threads = num_threads;
    this->distributing_task = false;
    omp_set_num_threads(this->num_threads);
    setTrainable(this->tree->getRoot());
    this->root_round = this->tree->getRoot()->getRound();
    if(this->root_round == GameTreeNode::GameRound::PREFLOP){
        this->split_round = GameTreeNode::GameRound::FLOP;
    }else if(this->root_round == GameTreeNode::GameRound::FLOP){
        this->split_round = GameTreeNode::GameRound::TURN;
    }else if(this->root_round == GameTreeNode::GameRound::TURN){
        this->split_round = GameTreeNode::GameRound::RIVER;
    }else{
        // do not use multithread in river, really not necessary
        this->split_round = GameTreeNode::GameRound::PREFLOP;
    }
}
```