`getReachProbs`: The function of `getReachProbs` is to calculate and return the reach probabilities for each player in a Texas Hold'em game.

**Code Description**: This method, `getReachProbs`, is part of the `PCfrSolver` class. It calculates the reach probabilities for each player by calling the `playerHands` method to retrieve their private cards, then it populates a vector with these probabilities based on the weights of the private cards. The result is a 2D vector where each inner vector represents the reach probabilities for one player.\\
## Code: 
```
vector<vector<float>> PCfrSolver::getReachProbs() {
    vector<vector<float>> retval(this->player_number);
    for(int player = 0;player < this->player_number;player ++){
        vector<PrivateCards> player_cards = this->playerHands(player);
        vector<float> reach_prob(player_cards.size());
        for(std::size_t i = 0;i < player_cards.size();i ++){
            reach_prob[i] = player_cards[i].weight;
        }
        retval[player] = reach_prob;
    }
    return retval;
}
```