`playerHands`: The function of `playerHands` is to return the private cards of a specific player in a Texas Hold'em game.

**Parameters**:
`int player`: This parameter specifies which player's hands are being requested, with 0 representing the first player and 1 representing the second player.

**Code Description**: 
The `playerHands` function takes an integer `player` as input and returns a reference to a vector of `PrivateCards`. It uses if-else statements to determine which player's hands to return based on the value of `player`. If `player` is 0, it returns the private cards of the first player stored in `range1`. If `player` is 1, it returns the private cards of the second player stored in `range2`. If `player` is neither 0 nor 1, it throws a runtime error indicating that the player was not found.\\
## Code: 
```
const vector<PrivateCards> &PCfrSolver::playerHands(int player) {
    if(player == 0){
        return range1;
    }else if (player == 1){
        return range2;
    }else{
        throw runtime_error("player not found");
    }
}
```