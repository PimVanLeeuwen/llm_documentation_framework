`TerminalNode`: The function of `TerminalNode` is to represent a terminal node in the game tree, where the game has reached its final outcome.

**Parameters**:
`vector<double> payoffs`: A vector of double values representing the payoffs for each player at this terminal state.
`int winner`: An integer indicating which player won the game (e.g., 0 for player 1, 1 for player 2).
`GameTreeNode::GameRound round`: An object representing the current game round.
`double pot`: A double value representing the total pot size at this terminal state.
`shared_ptr<GameTreeNode> parent`: A shared pointer to the parent node in the game tree.

**Code Description**: The `TerminalNode` constructor initializes a new terminal node with the given payoffs, winner, game round, pot size, and parent node. It sets up the internal state of the terminal node by copying the provided values into its member variables.\\
## Code: 
```
TerminalNode::TerminalNode(vector<double> payoffs, int winner, GameTreeNode::GameRound round, double pot,
                           shared_ptr<GameTreeNode> parent):GameTreeNode(round,pot,parent){
    this->payoffs = payoffs;
    this->winner = winner;
}
```