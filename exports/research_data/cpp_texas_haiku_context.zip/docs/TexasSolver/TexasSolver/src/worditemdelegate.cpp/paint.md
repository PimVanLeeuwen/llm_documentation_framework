`paint`: The function of `paint` is to draw a visual representation of the item in the view.

**Parameters**:
- `QPainter *painter`: A pointer to a QPainter object, which is used for drawing graphics.
- `const QStyleOptionViewItem &option`: A reference to a QStyleOptionViewItem object, which contains information about the item being painted.
- `const QModelIndex &index`: A reference to an QModelIndex object, which represents the index of the item in the view.

**Code Description**: The function initializes a new QStyleOptionViewItem object with the provided option and index. It then saves the current state of the painter, sets up a QTextDocument to draw the text of the item, draws the background of the item using the style's drawControl method, translates the painter to the position of the item, clips the painter to the size of the item, and finally restores the original state of the painter.\\
## Code: 
```
void WordItemDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);

    painter->save();

    QTextDocument doc;
    doc.setHtml(options.text);

    options.text = "";
    options.widget->style()->drawControl(QStyle::CE_ItemViewItem, &option, painter);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);

    painter->restore();
}
```