**Expected Output**

`anchorAt`: The function of `anchorAt` is to return the anchor for a given point in a QTextDocument.

**Parameters**:

`QString html`: A string containing HTML code that will be used to create a QTextDocument.

`const QPoint &point`: A point in the document where the anchor should be determined.

**Code Description**: The function creates a QTextDocument from the provided HTML, and then uses the document's layout to determine the anchor at the specified point.\\
## Code: 
```
QString WordItemDelegate::anchorAt(QString html, const QPoint &point) const {
    QTextDocument doc;
    doc.setHtml(html);

    auto textLayout = doc.documentLayout();
    Q_ASSERT(textLayout != 0);
    return textLayout->anchorAt(point);
}
```