`progressbar`: The function of `progressbar` is to initialize a progress bar with the specified number of cycles and display option.

**Parameters**:
`int n`: This parameter specifies the total number of cycles for the progress bar.
`bool showbar`: This boolean parameter determines whether the progress bar should be displayed or not.

**Code Description**: The code initializes an object of class `progressbar` with the given parameters. It sets up various attributes such as the current progress, total number of cycles, last percentage shown, display option, and characters for displaying done and todo tasks.\\
## Code: 
```
progressbar::progressbar(int n, bool showbar) :
        progress(0),
        n_cycles(n),
        last_perc(0),
        do_show_bar(showbar),
        update_is_called(false),
        done_char("#"),
        todo_char(" "),
        opening_bracket_char("["),
        closing_bracket_char("]") {}
```