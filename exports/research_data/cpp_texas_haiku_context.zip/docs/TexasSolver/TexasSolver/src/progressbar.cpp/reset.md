`reset`: The function of `reset` is to reset the progress bar's state, including setting the progress to 0, indicating that no updates have been called since the last reset, and resetting the last percentage displayed.

**Code Description**: 
The `reset` method resets the internal state of a progress bar object. It sets the `progress` variable to 0, which likely represents the current completion percentage or value. The `update_is_called` flag is set to false, indicating that no updates have been made to the progress bar since the last reset. Finally, the `last_perc` variable, which stores the last displayed percentage, is also reset to 0. This method appears to be used to restart or reinitialize the progress bar's state, possibly when a new task or process begins.\\
## Code: 
```
void progressbar::reset() {
    progress = 0,
            update_is_called = false;
    last_perc = 0;
    return;
}
```