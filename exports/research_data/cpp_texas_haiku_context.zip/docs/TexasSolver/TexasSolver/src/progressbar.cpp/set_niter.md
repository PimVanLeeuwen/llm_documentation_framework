`set_niter`: The function of `set_niter` is to set the number of iterations for a progress bar.

**Parameters**:
`int niter`: This parameter represents the total number of iterations that the progress bar will display. It must be a positive integer, as indicated by the error handling in the code.

**Code Description**: The `set_niter` function checks if the input `niter` is less than or equal to 0 and throws an exception if it is not a valid value. If the input is valid, it sets the internal variable `n_cycles` to the specified number of iterations. This suggests that the progress bar will display its progress based on this set number of cycles.\\
## Code: 
```
void progressbar::set_niter(int niter) {
    if (niter <= 0) throw std::invalid_argument(
                "progressbar::set_niter: number of iterations null or negative");
    n_cycles = niter;
    return;
}
```