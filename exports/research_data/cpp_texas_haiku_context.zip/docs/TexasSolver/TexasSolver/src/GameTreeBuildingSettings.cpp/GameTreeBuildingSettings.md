`GameTreeBuildingSettings`: The function of `GameTreeBuildingSettings` is to initialize and set up the settings for building a game tree in Texas Hold'em poker.

**Parameters**:
`StreetSetting flop_ip`: This parameter represents the street setting for the pre-flop phase, where "ip" stands for "in position", meaning the player's action is determined by their position at the table.
`StreetSetting turn_ip`: This parameter represents the street setting for the turn phase, also in position.
`StreetSetting river_ip`: This parameter represents the street setting for the river phase, again in position.
`StreetSetting flop_oop`: This parameter represents the street setting for the pre-flop phase, where "oop" stands for "out of position", meaning the player's action is determined by their position at the table.
`StreetSetting turn_oop`: This parameter represents the street setting for the turn phase, out of position.
`StreetSetting river_oop`: This parameter represents the street setting for the river phase, out of position.

**Code Description**: The `GameTreeBuildingSettings` function is a constructor that initializes an object with the given parameters. It takes six StreetSetting objects as input and assigns them to corresponding member variables (flop_ip, turn_ip, river_ip, flop_oop, turn_oop, river_oop) in the class. This allows for the creation of a GameTreeBuildingSettings object with specific settings for each street phase, both in position and out of position.\\
## Code: 
```
GameTreeBuildingSettings::GameTreeBuildingSettings(
        StreetSetting flop_ip,
        StreetSetting turn_ip,
        StreetSetting river_ip,
        StreetSetting flop_oop,
        StreetSetting turn_oop,
        StreetSetting river_oop):flop_ip(flop_ip),turn_ip(turn_ip),river_ip(river_ip),flop_oop(flop_oop),turn_oop(turn_oop),river_oop(river_oop) {
}
```