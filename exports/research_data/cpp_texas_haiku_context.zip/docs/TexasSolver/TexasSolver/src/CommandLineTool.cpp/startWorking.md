`startWorking`: The function of `startWorking` is to continuously read input from the standard input (cin) and process each line as a command.

**Code Description**: This code snippet defines a method called `startWorking` within the `CommandLineTool` class. It uses an infinite loop to repeatedly read lines from the standard input using the `getline` function, and for each line, it calls the `processCommand` method with the input line as an argument. The purpose of this method is to continuously process commands entered by the user through the command line interface.\\
## Code: 
```
void CommandLineTool::startWorking() {
    string input_line;
    while(cin) {
        getline(cin, input_line);
        this->processCommand(input_line);
    };
}
```