`split`: The function of `split` is to split a given input string into substrings based on a specified delimiter character.

**Parameters**:
`const string& s`: This parameter represents the input string that needs to be split.
`char c`: This parameter specifies the delimiter character used for splitting the input string.
`vector<string>& v`: This parameter is a reference to a vector of strings where the split substrings will be stored.

**Code Description**: The `split` function iterates through the input string, finding occurrences of the specified delimiter character. When a delimiter is found, it extracts the substring between the previous delimiter and the current one, adds it to the vector of strings, and then updates the starting position for the next iteration. If no more delimiters are found in the remaining part of the string, the entire remaining part is added as the last substring to the vector.\\
## Code: 
```
void split(const string& s, char c,
           vector<string>& v) {
    string::size_type i = 0;
    string::size_type j = s.find(c);

    while (j != string::npos) {
        v.push_back(s.substr(i, j-i));
        i = ++j;
        j = s.find(c, j);

        if (j == string::npos)
            v.push_back(s.substr(i, s.length()));
    }
}
```