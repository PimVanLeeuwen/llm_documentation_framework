`execFromFile`: The function of `execFromFile` is to execute a series of commands from a file.

**Parameters**: 
`string input_file`: This parameter specifies the path to the file containing the commands to be executed.

**Code Description**: 
The code reads a file line by line, processes each command using the `processCommand` method, and executes the corresponding action based on the command type.\\
## Code: 
```
void CommandLineTool::execFromFile(string input_file){
    std::ifstream infile(input_file);
    std::string input_line;
    while (std::getline(infile, input_line))
    {
        this->processCommand(input_line);
    }

}
```