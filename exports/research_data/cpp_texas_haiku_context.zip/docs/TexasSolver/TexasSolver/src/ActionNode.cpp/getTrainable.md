`getTrainable`: The function of `getTrainable` is to retrieve a trainable object from the trainables vector at index i.

**Parameters**:
`int i`: This parameter represents the index of the trainable object in the trainables vector.
`bool create_on_site`: This boolean parameter determines whether to create a new trainable object on site if it does not exist at the specified index.
`int use_halffloats`: This integer parameter specifies which type of trainable object to create when creating on site, with options 0 for DiscountedCfrTrainable, 1 for DiscountedCfrTrainableSF, and 2 for DiscountedCfrTrainableHF.

**Code Description**: The `getTrainable` function checks if the index i is within bounds of the trainables vector. If it is not, a runtime error is thrown. If the trainable object at index i does not exist and create_on_site is true, the function creates a new trainable object based on the value of use_halffloats. The created trainable object is then returned. If the trainable object already exists or create_on_site is false, the existing trainable object at index i is returned.\\
## Code: 
```
shared_ptr<Trainable> ActionNode::getTrainable(int i,bool create_on_site, int use_halffloats) {
    if(i > this->trainables.size()){
        throw runtime_error(tfm::format("size unacceptable %s > %s ",i,this->trainables.size()));
    }
    if(this->trainables[i] == nullptr && create_on_site){
        switch ((this->getRound() == GameTreeNode::RIVER) ? use_halffloats : 0 ){
        case 0:
            this->trainables[i] = make_shared<DiscountedCfrTrainable>(player_privates,*this);
            break;
        case 1:
            this->trainables[i] = make_shared<DiscountedCfrTrainableSF>(player_privates,*this);
            break;
        case 2:
            this->trainables[i] = make_shared<DiscountedCfrTrainableHF>(player_privates,*this);
            break;
        }
    }
    return this->trainables[i];
}
```