`ActionNode`: The function of `ActionNode` is to create a new node in the game tree that represents an action taken by a player.

**Parameters**:
`vector<GameActions> actions`: A vector of possible actions that can be taken at this point in the game.
`vector<shared_ptr<GameTreeNode>> childrens`: A vector of child nodes, representing the possible outcomes of the current action.
`int player`: The ID of the player who is taking the action.
`GameTreeNode::GameRound round`: The current round number in the game.
`double pot`: The current size of the pot (the amount of money at stake).
`shared_ptr<GameTreeNode> parent`: A pointer to the parent node, representing the previous state of the game.

**Code Description**: This function initializes a new `ActionNode` object by copying the provided parameters and setting up its internal data structures. It takes ownership of the `actions`, `childrens`, and `parent` vectors, and sets the `player`, `round`, and `pot` values accordingly. The `GameTreeNode` constructor is called to initialize the node's game state and parent pointer.\\
## Code: 
```
ActionNode::ActionNode(vector<GameActions> actions, vector<shared_ptr<GameTreeNode>> childrens, int player,
                       GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode> parent) :GameTreeNode(round,pot,std::move(parent)){
    this->actions = std::move(actions);
    this->player = player;
    this->childrens = std::move(childrens);
    //cout << "ActionNode created" << endl;
}
```