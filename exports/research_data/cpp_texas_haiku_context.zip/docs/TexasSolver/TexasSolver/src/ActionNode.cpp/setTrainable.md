`setTrainable`: The function of `setTrainable` is to set the trainable attributes of an ActionNode object.

**Parameters**:
`vector<shared_ptr<Trainable>> trainables`: A vector of shared pointers to Trainable objects, which represents the trainable elements associated with the ActionNode.
`vector<PrivateCards>* player_privates`: A pointer to a vector of PrivateCards objects, representing the private cards held by the player.

**Code Description**: The `setTrainable` function takes two parameters: `trainables` and `player_privates`. It assigns the provided `trainables` vector to the `trainables` member variable of the ActionNode object, effectively setting its trainable attributes. Similarly, it sets the `player_privates` member variable to the provided `player_privates` pointer. This function is used to configure an ActionNode with the necessary trainable elements and player private cards for a specific scenario or game state.\\
## Code: 
```
void ActionNode::setTrainable(vector<shared_ptr<Trainable>> trainables,vector<PrivateCards>* player_privates) {
    this->trainables = trainables;
    this->player_privates = player_privates;
}
```