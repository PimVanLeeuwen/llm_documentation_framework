`paint_range`: The function of `paint_range` is to paint a range of values in a table view item.

**Parameters**:
`QPainter *painter`: A pointer to a QPainter object used for painting.
`const QStyleOptionViewItem &option`: A reference to a QStyleOptionViewItem object containing information about the item being painted.
`const QModelIndex &index`: A reference to a QModelIndex object representing the index of the item in the model.

**Code Description**: The `paint_range` function is responsible for painting a range of values in a table view item. It first checks if the model at the given index is a TableStrategyModel and if it has valid data for the current row and column. If not, it returns without doing anything. It then determines which set of ranges to use based on the mode setting and retrieves the corresponding card coordinates from the model. If there are no card coordinates or if the ranges in the model are empty, it returns. Otherwise, it calculates a range number by summing up the values at each coordinate and dividing by the number of coordinates. It then uses this range number to calculate a fold probability and determine how much height to disable for folding. It draws a yellow background for the folded area and paints the text in the item using a QTextDocument object.\\
## Code: 
```
void StrategyItemDelegate::paint_range(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    auto options = option;
    initStyleOption(&options, index);
    const TableStrategyModel * tableStrategyModel = qobject_cast<const TableStrategyModel*>(index.model());

    vector<pair<int,int>> card_cords;
    if(tableStrategyModel == NULL
            || tableStrategyModel->ui_p1_range.size() <= index.row()
            || tableStrategyModel->ui_p1_range.size() <= index.column()
            || tableStrategyModel->ui_p2_range.size() <= index.row()
            || tableStrategyModel->ui_p2_range.size() <= index.column()
            ){
        return;
    }
    if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP){
        card_cords = tableStrategyModel->ui_p1_range[index.row()][index.column()];
    }else{
        card_cords = tableStrategyModel->ui_p2_range[index.row()][index.column()];
    }

    if(tableStrategyModel->p1_range.empty() || tableStrategyModel->p2_range.empty()){
        return;
    }

    if(!card_cords.empty()){
        float range_number = 0;
        for(auto one_cord:card_cords){
            if(this->detailWindowSetting->mode == DetailWindowSetting::DetailWindowMode::RANGE_IP){
                range_number += tableStrategyModel->p1_range[one_cord.first][one_cord.second];
            }else{
                // when it's oop, which is p1
                range_number += tableStrategyModel->p2_range[one_cord.first][one_cord.second];
            }
        }
        range_number = range_number / card_cords.size();

        if(range_number < 0 || range_number > 1) throw runtime_error("range number incorrect in strategyitemdeletage");

        float fold_prob = 1 - range_number;
        int disable_height = (int)(fold_prob * option.rect.height());
        int remain_height = option.rect.height() - disable_height;

        // draw background for flod
        QRect rect(option.rect.left(), option.rect.top() + disable_height,\
         option.rect.width(), remain_height);
        QBrush brush(Qt::yellow);
        painter->fillRect(rect, brush);
    }
    QTextDocument doc;
    doc.setHtml(options.text);

    options.text = "";
    //options.widget->style()->drawControl(QStyle::CE_ItemViewItem, &option, painter);

    painter->translate(options.rect.left(), options.rect.top());
    QRect clip(0, 0, options.rect.width(), options.rect.height());
    doc.drawContents(painter, clip);
}
```