`setupModelData`: The function of `setupModelData` is to set up the model data for a tree structure, specifically by initializing the root item and regenerating the tree items based on the game round.

**Code Description**: This code snippet defines the `setupModelData` method in the `TreeModel` class. It first determines which poker solver to use based on the mode specified in the QSolverJob object. If the mode is HOLDEM or SHORTDECK, it sets up the corresponding poker solver and retrieves its game tree. If the game tree is empty or has no root node, the method returns without doing anything. Otherwise, it creates a new TreeItem for the root node of the game tree and inserts it into the tree structure. Finally, it calls the `reGenerateTreeItem` method to regenerate the tree items based on the current round number.\\
## Code: 
```
void TreeModel::setupModelData()
{
    PokerSolver * solver;
    if(this->qSolverJob->mode == QSolverJob::Mode::HOLDEM){
        solver = &(this->qSolverJob->ps_holdem);
    }else if(this->qSolverJob->mode == QSolverJob::Mode::SHORTDECK){
        solver = &(this->qSolverJob->ps_shortdeck);
    }else{
        throw runtime_error("holdem mode incorrect");
    }

    if(solver->get_game_tree() == nullptr || solver->get_game_tree()->getRoot() == nullptr){
        return;
    }

    GameTreeNode::GameRound round =	solver->get_game_tree()->getRoot()->getRound();

    this->rootItem = new TreeItem(solver->get_game_tree()->getRoot());
    TreeItem* ti = new TreeItem(solver->get_game_tree()->getRoot(),this->rootItem);
    rootItem->insertChild(ti);
    this->reGenerateTreeItem(round,ti);
}
```