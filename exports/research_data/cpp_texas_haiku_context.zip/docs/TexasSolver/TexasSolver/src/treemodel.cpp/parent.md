`parent`: The function of `parent` is to return the parent index of a given child index in the tree model.

**Parameters**:
`const QModelIndex &index`: This parameter represents the child index for which the parent index needs to be determined.

**Code Description**: 
The `parent` method takes a `QModelIndex` object as input and returns another `QModelIndex` representing the parent of the given child. It first checks if the provided index is valid, and if not, it returns an invalid QModelIndex. If the index is valid, it casts the internal pointer to a TreeItem object and retrieves its parent item. If the parent item is the root item, it returns an invalid QModelIndex; otherwise, it creates a new QModelIndex for the parent item using the `createIndex` method and returns it.\\
## Code: 
```
QModelIndex TreeModel::parent(const QModelIndex &index) const
{
    if (!index.isValid())
        return QModelIndex();

    TreeItem *childItem = static_cast<TreeItem*>(index.internalPointer());
    TreeItem *parentItem = childItem->parentItem();

    if (parentItem == rootItem)
        return QModelIndex();

    return createIndex(parentItem->row(), 0, parentItem);
}
```