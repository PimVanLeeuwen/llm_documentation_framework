`index`: The function of `index` is to return a QModelIndex that represents the item at the specified row and column within the tree model, under the parent index if provided.

**Parameters**:
`int row`: The row number of the item in the tree model.
`int column`: The column number of the item in the tree model.
`const QModelIndex &parent`: The parent index of the item, or an invalid index if it's a top-level item.

**Code Description**: This function checks if the specified row and column are valid within the tree model. If they are, it retrieves the parent TreeItem from the internal pointer of the parent index, or uses the root item as the parent if no index is provided. It then retrieves the child item at the specified row from the parent's child items list. If the child item exists, it creates a QModelIndex for that item and returns it; otherwise, it returns an invalid index.\\
## Code: 
```
QModelIndex TreeModel::index(int row, int column, const QModelIndex &parent) const
{
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    TreeItem *parentItem;

    if (!parent.isValid())
        parentItem = rootItem;
    else
        parentItem = static_cast<TreeItem*>(parent.internalPointer());

    TreeItem *childItem = parentItem->child(row);
    if (childItem)
        return createIndex(row, column, childItem);
    return QModelIndex();
}
```