`clear_range`: The function of `clear_range` is to reset all values in the grids_float array to zero, effectively clearing any previously calculated or stored data.

**Code Description**: This method iterates over a 2D grid (grids_float) and sets each value to zero. The grid's dimensions are determined by the size of the ranklist vector.\\
## Code: 
```
void RangeSelectorTableModel::clear_range(){
    for(int i = 0;i < this->ranklist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_float[i][j] = 0;
        }
    }
}
```