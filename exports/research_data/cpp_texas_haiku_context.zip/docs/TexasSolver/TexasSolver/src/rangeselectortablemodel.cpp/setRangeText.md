`setRangeText`: The function of `setRangeText` is to set the text for a range in a table model.

**Parameters**:\
`QString input_range`: A string containing one or more ranges, where each range is separated by a comma and consists of two parts separated by a colon. For example: "1:2,3:4".

**Code Description**: The function `setRangeText` takes a string `input_range` as input and clears any existing ranges in the table model using the `clear_range` method. It then iterates over each range in the input string, splits it into two parts (key and value), and updates the corresponding grid values in the table model based on the key-value pair. If a range has an invalid format or if the key is not found in the `string2ij` map, it prints an error message using `qDebug`.\\
## Code: 
```
void RangeSelectorTableModel::setRangeText(QString input_range){
    this->clear_range();
    for(QString one_range:input_range.split(",")){
        if(one_range.trimmed() == "")continue;
        QStringList one_range_list = one_range.split(":");

        if(one_range_list.size() > 2 || one_range_list.size() < 1){
            qDebug().noquote() << QString(tr("skipping range %1, format error, range list should contain two part seperate by ':'")).arg(one_range);
        }

        float range_float = 1.0;
        QString key_range = one_range_list[0];
        QStringList keys;
        if(this->string2ij.count(one_range_list[0])){
            keys.append(key_range);
        }else{
            keys.append(key_range + "o");
            keys.append(key_range + "s");
        }

        for(QString one_key: keys){
            if(one_key.count(" ") == one_key.length() || one_key == "")continue;
            if(!this->string2ij.count(one_key)){
                qDebug().noquote() << QString(tr("skipping range %1, format error")).arg(one_range);
                continue;
            }
            pair<int,int> cord = this->string2ij[one_key];
            if(one_range_list.size() > 1)range_float = one_range_list[1].toFloat();
            this->grids_float[cord.first][cord.second] = range_float;
        }
    }
}
```