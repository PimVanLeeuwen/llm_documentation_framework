`RangeSelectorTableModel`: The function of `RangeSelectorTableModel` is to initialize and configure a table model for range selection, handling ranks, initial board settings, parent object, and thumbnail display.

**Parameters**:
`QStringList ranks`: A list of rank values used in the table model.
`QString initial_board`: An input string representing the initial state of the board.
`QObject *parent`: The parent object of the table model.
`bool thumbnail`: A boolean flag indicating whether to display a thumbnail or not.

**Code Description**: 
The code initializes the `RangeSelectorTableModel` class by setting up internal data structures and calling other methods. It creates 2D grids for string and float values, populates them with initial data based on the provided ranks and initial board input, and sets the range text accordingly. The method also takes into account the thumbnail display flag when initializing the model.\\
## Code: 
```
RangeSelectorTableModel::RangeSelectorTableModel(QStringList ranks,QString initial_board,QObject *parent,bool thumbnail):QAbstractItemModel(parent){
    this->ranklist = ranks;
    this->thumbnail = thumbnail;

    this->grids_string = vector<vector<QString>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_string[i] = vector<QString>(this->ranklist.size());
        for(int j = 0;j < this->ranklist.size();j ++){
            this->grids_string[i][j] = this->get_ij_text(i,j);
            this->string2ij[this->get_ij_text(i,j)] = pair<int,int>(i,j);
        }
    }

    this->grids_float = vector<vector<float>>(this->ranklist.size());
    for(int i = 0;i < this->ranklist.size();i ++){
        this->grids_float[i] = vector<float>(this->ranklist.size(),0.0);
    }
    this->setRangeText(initial_board);
}
```