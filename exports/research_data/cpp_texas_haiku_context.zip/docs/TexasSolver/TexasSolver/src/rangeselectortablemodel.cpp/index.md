`index`: The function of `index` is to return a QModelIndex object representing the item at the specified row and column within the table model, or an invalid QModelIndex if the index does not exist.

**Parameters**:
`int row`: The row number of the item in the table model.
`int column`: The column number of the item in the table model.
`const QModelIndex &parent`: A reference to a QModelIndex object representing the parent item of the specified item, or an empty QModelIndex if it is a top-level item.

**Code Description**: This function checks if the index exists using the `hasIndex` method. If the index does not exist, it returns an invalid QModelIndex. Otherwise, it creates and returns a new QModelIndex object with the specified row, column, and parent indices.\\
## Code: 
```
QModelIndex RangeSelectorTableModel::index(int row, int column,
          const QModelIndex &parent) const  {
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    return createIndex(row, column, nullptr);
}
```