`get_ij_text`: The function of `get_ij_text` is to generate a string representation of the ranklist indices `i` and `j`, with the larger index first, separated by an "o" if `i` is greater than `j`, an "s" if `i` is less than `j`, or no separator if `i` equals `j`.

**Parameters**:\
`int i`: The row index in the ranklist.
`int j`: The column index in the ranklist.

**Code Description**: This function takes two integer parameters, `i` and `j`, representing the indices of a cell in a table. It calculates which index is larger and smaller, then constructs a string by concatenating the ranklist values at these indices with an "o" or "s" separator as appropriate. The resulting string is returned.\\
## Code: 
```
QString RangeSelectorTableModel::get_ij_text(int i,int j){
    int row = i;
    int col = j;
    int larger = row > col?row:col;
    int smaller = row > col?col:row;
    QString  retval = QString("%1%2%3")\
            .arg(QString(this->ranklist[smaller]))\
            .arg(QString(this->ranklist[larger]));
    if(row > col){
        retval = retval.arg("o");
    }else if(row < col){
        retval = retval.arg("s");
    }else{
        retval = retval.arg("");
    }
    return retval;
}
```