`getRangeAt`: The function of `getRangeAt` is to retrieve the value at a specific position in a 2D grid.

**Parameters**:
`int i`: The row index of the desired value.
`int j`: The column index of the desired value.

**Code Description**: 
The function checks if the provided indices are within valid ranges. If not, it logs an error message and returns 0. Otherwise, it returns the value at the specified position in the `grids_float` 2D array.\\
## Code: 
```
float RangeSelectorTableModel::getRangeAt(int i, int j){
    if(i < 0 || i >= this->ranklist.size()){
        qDebug().noquote() << "RangeSelectorTableModel::getRangeAt i not valid: " << i;
        return 0;
    }
    else if(j < 0 || j >= this->ranklist.size()){
        qDebug().noquote() << "RangeSelectorTableModel::getRangeAt j not valid: " << j;
        return 0;
    }
    else{
        return this->grids_float[i][j];
    }
}
```