`data`: The function of `data` is to return a QVariant containing formatted data for the specified index and role.

**Parameters**:
`const QModelIndex &index`: This parameter represents the index of the item in the table model.
`int role`: This parameter specifies the type of data to be returned, such as display or edit roles.

**Code Description**: The `data` function retrieves the row and column indices from the input `index`, determines which ranklist value to use based on whether the row is greater than or less than the column, formats a QString with the ranklist values and a grid value, and returns this string as a QVariant.\\
## Code: 
```
QVariant RangeSelectorTableModel::data(const QModelIndex &index, int role) const {
    int row = index.row();
    int col = index.column();
    int larger = row > col?row:col;
    int smaller = row > col?col:row;
    QString  retval = QString("<h4>%1%2<b>%3</b></h4>")\
            .arg(QString(this->ranklist[smaller]))\
            .arg(QString(this->ranklist[larger]));
    if(row > col){
        retval = retval.arg(tr("o"));
    }else if(row < col){
        retval = retval.arg(tr("s"));
    }else{
        retval = retval.arg(tr(" "));
    }
    retval += QString("%1").arg(QString::number(this->grids_float[row][col],'f',3));
    return retval;
}
```