`getRangeText`: The function of `getRangeText` is to generate a string representation of the ranges in the grid, where each range is defined by its minimum and maximum values.

**Code Description**: This method iterates over the 2D array `grids_float` and constructs a string for each non-zero value. The string format is "minimum_value:maximum_value", where minimum_value and maximum_value are formatted to three decimal places using `QString::number`. If the current range's minimum value is equal to its maximum value, only the single value is included in the string. The strings representing all ranges are then concatenated with commas to form the final output string.\\
## Code: 
```
QString RangeSelectorTableModel::getRangeText(){
    QString retval = "";
    for(int i = 0;i < this->ranklist.size();i ++){
        for(int j = 0;j < this->ranklist.size();j ++){
            if(this->grids_float[i][j] == 0)continue;
            QString one_range_str = QString("%1:%2").arg(this->grids_string[i][j],QString::number(this->grids_float[i][j],'f',3));
            if(retval == ""){
                retval = one_range_str;
            }else{
                retval = retval + "," + one_range_str;
            }
        }
    }
    return retval;
}
```