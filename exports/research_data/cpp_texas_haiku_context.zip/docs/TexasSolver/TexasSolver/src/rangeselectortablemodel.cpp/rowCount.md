`rowCount`: The function of `rowCount` is to return the total number of rows in the table model.

**Parameters**: 
`const QModelIndex &parent`: This parameter represents the parent index, which is used to determine if the row count should be calculated for a specific subtree or the entire tree.

**Code Description**: 
The code returns the size of the `ranklist` vector, indicating that the number of rows in the table model is directly related to the number of elements in this vector.\\
## Code: 
```
int RangeSelectorTableModel::rowCount(const QModelIndex &parent) const {
    return this->ranklist.size();
}
```