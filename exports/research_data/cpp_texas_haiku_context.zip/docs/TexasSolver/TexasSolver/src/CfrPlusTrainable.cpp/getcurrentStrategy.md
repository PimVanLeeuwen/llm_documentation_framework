## Expected output
`getcurrentStrategy`: The function of `getcurrentStrategy` is to return the current strategy vector, which represents the probability distribution over all possible actions.

**Code Description**: This method calculates and returns the current strategy vector based on the values stored in the `r_plus_sum` and `r_plus` vectors. If the `r_plus_sum` vector is empty, it initializes the strategy vector with equal probabilities for each action. Otherwise, it iterates over all possible actions and private card combinations, calculating the probability of each action given its corresponding regret value and sum of regrets. The method also checks for NaN values in the `r_plus` vector and throws an exception if found.\\
## Code: 
```
const vector<float> CfrPlusTrainable::getcurrentStrategy() {
    if(this->r_plus_sum.empty()){
        fill(retval.begin(),retval.end(),1.0 / this->action_number);
    }else {
        for (int action_id = 0; action_id < action_number; action_id++) {
            for (int private_id = 0; private_id < this->card_number; private_id++) {
                int index = action_id * this->card_number + private_id;
                if(this->r_plus_sum[private_id] != 0) {
                    retval[index] = this->r_plus[index] / this->r_plus_sum[private_id];
                }else{
                    retval[index] = 1.0 / this->action_number;
                }
                if(this->r_plus[index] != this->r_plus[index]) throw runtime_error("nan found");
                /*
                if(this.r_plus_sum[private_id] == 0)
                {
                    System.out.println("Exception regret status, r_plus_sum == 0:");
                    System.out.println(String.format("r plus length %s , card num %s",r_plus.length,this.card_number));
                    for(int i = index % this.card_number;i < this.r_plus.length;i += this.card_number){
                        System.out.print(String.format("%s:%s ",i,this.r_plus[i]));
                        if(i == index){
                            System.out.print("[current]");
                        }
                    }
                    System.out.println();
                    System.out.println();
                    throw new RuntimeException();
                }
                 */
            }
        }
    }
    return retval;
}
```