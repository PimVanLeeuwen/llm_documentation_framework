`updateRegrets`: The function of `updateRegrets` is to update the regrets and cumulative regrets for each action and private card combination in a Texas Hold'em game.

**Parameters**:
`const vector<float>& regrets`: This parameter represents the updated regrets values for each action and private card combination.
`int iteration_number`: This parameter represents the current iteration number, used to calculate the cumulative regrets.
`const vector<float>& reach_probs`: This parameter is not used in this function (commented out code suggests it was intended to be used but has been removed).

**Code Description**: The `updateRegrets` function updates the regrets and cumulative regrets for each action and private card combination. It first checks if the size of the regrets vector matches the expected length, throwing an error if not. Then, it initializes two arrays (r_plus_sum and cum_r_plus_sum) to zero. It iterates over each action and private card combination, updating the regrets and cumulative regrets values based on the provided regrets values and iteration number. The updated values are stored in the r_plus and cum_r_plus arrays, respectively.\\
## Code: 
```
void CfrPlusTrainable::updateRegrets(const vector<float>& regrets, int iteration_number, const vector<float>& reach_probs) {
    this->regrets = regrets;
    if(regrets.size() != this->action_number * this->card_number) throw runtime_error("length not match");

    //Arrays.fill(this.r_plus_sum,0);
    fill(r_plus_sum.begin(),r_plus_sum.end(),0);
    fill(cum_r_plus_sum.begin(),cum_r_plus_sum.end(),0);
    for (int action_id = 0;action_id < action_number;action_id ++) {
        for(int private_id = 0;private_id < this->card_number;private_id ++){
            int index = action_id * this->card_number + private_id;
            float one_reg = regrets[index];

            // 更新 R+
            this->r_plus[index] = max((float)0.0,one_reg + this->r_plus[index]);
            this->r_plus_sum[private_id] += this->r_plus[index];

            // 更新累计策略
            this->cum_r_plus[index] += this->r_plus[index] * iteration_number;
            this->cum_r_plus_sum[private_id] += this->cum_r_plus[index];
        }
    }
}
```