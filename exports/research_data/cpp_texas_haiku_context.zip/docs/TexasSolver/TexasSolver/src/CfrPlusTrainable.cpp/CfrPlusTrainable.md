`CfrPlusTrainable`: The function of `CfrPlusTrainable` is to initialize a trainable CFR+ object with the given action node and private cards.

**Parameters**:
`shared_ptr<ActionNode> action_node`: This parameter represents the current state of the game, which includes information about the available actions.
`vector<PrivateCards> privateCards`: This parameter represents the private cards held by the player, which are used to determine the best course of action.

**Code Description**: The `CfrPlusTrainable` function initializes various member variables, including `r_plus`, `r_plus_sum`, `cum_r_plus`, `cum_r_plus_sum`, and `retval`. These variables are likely used to store values related to the CFR+ algorithm. The function also retrieves a vector of children nodes from the `action_node` using the `getChildrens()` method.\\
## Code: 
```
CfrPlusTrainable::CfrPlusTrainable(shared_ptr<ActionNode> action_node, vector<PrivateCards> privateCards) {
    this->action_node = action_node;
    this->privateCards = privateCards;
    this->action_number = action_node->getChildrens().size();
    this->card_number = privateCards.size();

    this->r_plus = vector<float>(this->action_number * this->card_number);
    this->r_plus_sum = vector<float>(this->card_number);

    this->cum_r_plus = vector<float>(this->action_number * this->card_number);
    this->cum_r_plus_sum = vector<float>(this->card_number);
    this->retval = vector<float>(this->action_number * this->card_number);
}
```