`isAllZeros`: The function of `isAllZeros` is to check if all elements in the given array are zero.

**Parameters**: 
`vector<float> input_array`: This parameter represents a vector (a collection) of floating-point numbers that will be checked for containing only zeros.

**Code Description**: 
The code iterates over each element in the `input_array`. If any element is not equal to zero, it immediately returns `false`, indicating that not all elements are zero. If the loop completes without finding a non-zero element, it returns `true`, signifying that all elements in the array are indeed zero.\\
## Code: 
```
bool CfrPlusTrainable::isAllZeros(vector<float> input_array) {
    for(float i:input_array){
        if (i != 0)return false;
    }
    return true;
}
```