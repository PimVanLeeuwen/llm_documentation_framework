`GameActions`: The function of `GameActions` is to initialize a game action with the given poker action and amount.

**Parameters**:
`GameTreeNode::PokerActions action`: This parameter specifies the type of poker action, which can be RAISE, BET, CHECK, FOLD, or CALL.
`double amount`: This parameter represents the amount associated with the poker action. A value of -1 indicates that no specific amount is specified.

**Code Description**: The `GameActions` function initializes a game action by setting the `action` and `amount` member variables based on the input parameters. It checks if the `amount` is valid for the given `action`, throwing an exception if it's not. If the `action` is RAISE or BET, it expects a non-negative amount; otherwise, it expects -1 as the amount.\\
## Code: 
```
GameActions::GameActions(GameTreeNode::PokerActions action, double amount) {
    this->action = action;
    if (action == GameTreeNode::PokerActions::RAISE || action == GameTreeNode::PokerActions::BET ) {
        if (amount == -1) throw runtime_error(tfm::format("raise/bet amount should not be -1, find %s",amount));
    } else {
        if (amount != -1) throw runtime_error(tfm::format("check/fold/call amount should be -1, find %s",amount));
    }
    this->amount = amount;
}
```