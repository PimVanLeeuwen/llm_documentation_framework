`toString`: The function of `toString` is to return a string representation of the game action, including the poker action and the amount (if applicable).

**Code Description**: This method, `toString`, appears to be part of a class called `GameActions`. It seems to be responsible for converting the game's current state into a human-readable format. The method checks if an "amount" variable is set to -1; if so, it calls another method, `pokerActionToString`, to convert the action into a string and returns this result. If the amount is not -1, it concatenates the string representation of the poker action with the amount (converted to a string) and returns this combined string.\\
## Code: 
```
string GameActions::toString() {
    if(this->amount == -1) {
        return this->pokerActionToString(this->action);
    }else{
        return this->pokerActionToString(this->action) + " " + to_string(amount);
    }
}
```