`getAmount`: The function of `getAmount` is to return the current amount value stored in the object.

**Code Description**: This method, `getAmount`, is a simple getter function that retrieves and returns the `amount` member variable of the `GameActions` class. It does not modify or calculate any values; it merely provides access to the existing `amount` data.\\
## Code: 
```
double GameActions::getAmount() {
    return this->amount;
}
```