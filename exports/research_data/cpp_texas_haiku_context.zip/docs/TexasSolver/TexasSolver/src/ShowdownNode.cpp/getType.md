`getType`: The function of `getType` is to return the type of a ShowdownNode in the TexasSolver project structure.

**Code Description**: This method, `getType`, is part of the `ShowdownNode` class within the `TexasSolver` project. It specifically returns the type of a node that represents a showdown situation in a game tree. The returned value is of type `GameTreeNode::GameTreeNodeType`.\\
## Code: 
```
GameTreeNode::GameTreeNodeType ShowdownNode::getType() {
    return SHOWDOWN;
}
```