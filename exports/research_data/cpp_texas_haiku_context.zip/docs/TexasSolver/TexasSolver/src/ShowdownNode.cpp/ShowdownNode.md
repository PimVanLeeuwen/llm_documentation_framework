`ShowdownNode`: The function of `ShowdownNode` is to initialize a new node in the game tree for a showdown scenario, where multiple players are tied and their payoffs need to be determined.

**Parameters**:
`vector<double> tie_payoffs`: This parameter represents the payoffs that all tied players will receive.
`vector<vector<double>> player_payoffs`: This parameter contains the individual payoffs of each player in the game.
`GameTreeNode::GameRound round`: This parameter specifies the current round of the game.
`double pot`: This parameter represents the total pot size for the game.
`shared_ptr<GameTreeNode>parent`: This parameter points to the parent node in the game tree.

**Code Description**: The `ShowdownNode` constructor initializes a new node in the game tree by calling the base class constructor (`GameTreeNode`) with the provided parameters. It then sets the tie payoffs and player payoffs for this specific showdown scenario, using the moved-from versions of the input vectors to avoid unnecessary copies.\\
## Code: 
```
ShowdownNode::ShowdownNode(vector<double> tie_payoffs, vector<vector<double>> player_payoffs,
                           GameTreeNode::GameRound round, double pot, shared_ptr<GameTreeNode>parent):
                           GameTreeNode(round,pot,std::move(parent)) {
    this->tie_payoffs = std::move(tie_payoffs);
    this->player_payoffs = std::move(player_payoffs);
}
```