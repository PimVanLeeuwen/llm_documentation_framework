`get_payoffs`: The function of `get_payoffs` is to return the payoffs for a given showdown outcome.

**Parameters**:
`ShowdownNode::ShowDownResult result`: This parameter specifies the result of the showdown, which can be either a tie or not a tie.
`int winner`: This parameter indicates the winner of the showdown, where -1 represents a tie and a non-negative integer represents the player who won.

**Code Description**: The `get_payoffs` function checks if the showdown is a tie by checking the value of `result`. If it's not a tie, it returns the payoffs for the specified winner. If it is a tie, it returns the tie payoffs. If the input parameters are invalid (i.e., `winner == -1` in a non-tie or `winner != -1` in a tie), it throws a runtime error.\\
## Code: 
```
vector<double> ShowdownNode::get_payoffs(ShowdownNode::ShowDownResult result, int winner) {
    if(result == ShowDownResult::NOTTIE){
        if(winner == -1) throw runtime_error("winner == -1 in tie");
        vector<double> retval = player_payoffs[winner];
        return retval;
    }else{
        // if the showdown is a tie
        if(winner != -1) throw runtime_error("winner != -1 in not tie");
        return this->tie_payoffs;
    }
}
```