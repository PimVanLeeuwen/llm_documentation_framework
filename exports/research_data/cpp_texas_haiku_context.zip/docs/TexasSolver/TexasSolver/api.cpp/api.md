## Expected output
`api`: The function of `api` is to execute the TexasSolver poker solver based on input parameters.
**Parameters**:\
`const char * input_file`: This parameter specifies the file from which to read input data for the solver. If empty, it defaults to executing a command-line tool.
`const char * resource_dir = "./resources"`: This parameter specifies the directory where resources such as card images and game settings are stored.
`const char * mode = "holdem"`: This parameter specifies the poker variant being played, which can be either "holdem" or "shortdeck".

**Code Description**: The `api` function initializes a `CommandLineTool` object with the specified mode and resource directory. If an input file is provided, it executes the solver from that file; otherwise, it starts a command-line tool for interactive use. It also checks if the mode is valid and throws an error if not.\\
## Code: 
```
EXPORT
int api(const char * input_file, const char * resource_dir = "./resources", const char * mode = "holdem") {
    string input_file_ = input_file;
    string resource_dir_ = resource_dir;
    string mode_ = mode;

    if(mode_ != "holdem" && mode_ != "shortdeck")
        throw runtime_error(tfm::format("mode %s error, not in ['holdem','shortdeck']", mode_));

    if(input_file_.empty()) {
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.startWorking();
    }else{
        cout << "EXEC FROM FILE" << endl;
        CommandLineTool clt = CommandLineTool(mode_, resource_dir_);
        clt.execFromFile(input_file_);
    }
}
```