## on_cancelButton_clicked: 
The function of `on_cancelButton_clicked` is to close the current window when the cancel button is clicked.

## Code Description:
When the cancel button is clicked, this function closes the current window. This implies that the cancel button is used to exit or cancel a currently active operation or selection process in the application. The `close()` method is likely inherited from a base class and is responsible for closing the window, effectively ending any ongoing activity within it.\\
## Code: 
```
void boardselector::on_cancelButton_clicked()
{
    this->close();
}
```