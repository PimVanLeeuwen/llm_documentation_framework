`on_clearBoardButton_clicked`: The function of `on_clearBoardButton_clicked` is to clear the board by resetting all elements in the grid associated with a BoardSelectorTableModel object and updating the UI.

**Code Description**: When the "Clear Board" button is clicked, this function clears the 2D grid of floating-point values associated with a BoardSelectorTableModel object by setting all elements to zero. It also updates the UI by clearing the board edit field, updating the board selector table, and setting focus on both the board selector table and the board edit field.\\
## Code: 
```
void boardselector::on_clearBoardButton_clicked()
{
    this->boardSelectorTableModel->clear_board();
    this->ui->boardEdit->clear();
    this->ui->boardSelectorTable->update();
    this->ui->boardSelectorTable->setFocus();
    this->ui->boardEdit->setFocus();
}
```