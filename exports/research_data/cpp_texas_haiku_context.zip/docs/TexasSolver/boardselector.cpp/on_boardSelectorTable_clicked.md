`on_boardSelectorTable_clicked`: When the user clicks on a cell in the boardSelectorTable, this function toggles the state of the corresponding board at the specified row and column indices.

**Parameters**: 
`const QModelIndex &index`: The index of the clicked cell in the table view.

**Code Description**: This function retrieves the row and column indices from the clicked QModelIndex. It then updates the BoardSelectorTableModel by setting the value at the specified row and column to its opposite (i.e., 1 - currentValue). If the text in the boardEdit field does not match the new state of the board, it updates the boardEdit field with the string representation of the updated board. Finally, it sets focus on both the boardEdit field and the boardSelectorTable.\\
## Code: 
```
void boardselector::on_boardSelectorTable_clicked(const QModelIndex &index)
{
    int row = index.row();
    int col = index.column();
    this->boardSelectorTableModel->setBoardAt(row,col,1 - this->boardSelectorTableModel->getBoardAt(row,col));
    if(this->ui->boardEdit->text() != this->boardSelectorTableModel->getBoardText()){
        this->ui->boardEdit->setText(this->boardSelectorTableModel->getBoardText());
    }
    this->ui->boardEdit->setFocus();
    this->ui->boardSelectorTable->setFocus();
}
```