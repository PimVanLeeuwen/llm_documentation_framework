`item_expanded`: The function of `item_expanded` is to regenerate the tree item for each child of a given TreeItem when it is expanded.

**Parameters**: 
`const QModelIndex& index`: This parameter represents the index of the TreeItem that has been expanded, allowing the function to access its children and regenerate their tree items if necessary.

**Code Description**: The `item_expanded` function retrieves the TreeItem associated with the given index, counts its child items, and then iterates over each child item. If a child item has no further children of its own (i.e., its child count is 0), it calls the `reGenerateTreeItem` method on the tree model to regenerate the tree item for that child based on the round number retrieved from the GameTreeNode object associated with the child's data. This process effectively updates the display of the tree view by regenerating the tree items for any children of the expanded TreeItem that do not have their own further children.\\
## Code: 
```
void StrategyExplorer::item_expanded(const QModelIndex& index){
    TreeItem *item = static_cast<TreeItem*>(index.internalPointer());
    int num_child = item->childCount();
    for (int i = 0;i < num_child;i ++){
        TreeItem* one_child = item->child(i);
        if(one_child->childCount() != 0)continue;
        this->ui->gameTreeView->tree_model->reGenerateTreeItem(one_child->m_treedata.lock()->getRound(),one_child);
    }
}
```