`on_evModeButtom_clicked`: The function of `on_evModeButtom_clicked` is to update the mode of the detail window setting to EV (Electric Vehicle) and refresh the views.

**Code Description**: This code snippet updates the mode of the detail window setting to EV when the "evModeButton" is clicked. It also refreshes the strategy table view, detail view, and rough strategy view by calling their respective update methods on their viewport objects.\\
## Code: 
```
void StrategyExplorer::on_evModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::EV;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->ui->roughStrategyView->viewport()->update();
}
```