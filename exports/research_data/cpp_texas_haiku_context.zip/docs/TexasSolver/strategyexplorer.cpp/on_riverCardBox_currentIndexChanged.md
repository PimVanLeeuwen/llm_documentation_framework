`on_riverCardBox_currentIndexChanged`: The function of `on_riverCardBox_currentIndexChanged` is to update the table strategy model and process the poker board when a new river card is selected.

**Parameters**:\
`int index`: This parameter represents the index of the selected river card in the cards list.

**Code Description**: When a new river card is selected, this function updates the table strategy model by setting the current river card and updating its strategy data. It then processes the poker board based on the updated table strategy model, including adding relevant table strategy cards and displaying the resulting card list in HTML format on a user interface label.\\
## Code: 
```
void StrategyExplorer::on_riverCardBox_currentIndexChanged(int index)
{
    if(this->cards.size() > 0  && index < this->cards.size()){
        this->tableStrategyModel->setRiverCard(this->cards[index]);
        this->tableStrategyModel->updateStrategyData();
        //this->roughStrategyViewerModel->onchanged();
        //this->ui->roughStrategyView->viewport()->update();
        this->process_board(this->tableStrategyModel->treeItem);
    }
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
}
```