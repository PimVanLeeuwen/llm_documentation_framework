`onMouseMoveEvent`: The function of `onMouseMoveEvent` is to update the grid coordinates and refresh the views when the mouse is moved over a grid.

**Parameters**:
`int i`: The row index of the grid where the mouse is currently located.
`int j`: The column index of the grid where the mouse is currently located.

**Code Description**: This function updates the `grid_i` and `grid_j` settings in the `detailWindowSetting` object to reflect the current grid coordinates. It then calls the `update()` method on both the `detailView` and `strategyTableView` views, which likely refreshes their contents based on the updated grid coordinates.\\
## Code: 
```
void StrategyExplorer::onMouseMoveEvent(int i,int j){
    this->detailWindowSetting.grid_i = i;
    this->detailWindowSetting.grid_j = j;
    this->ui->detailView->viewport()->update();
    this->ui->strategyTableView->viewport()->update();
}
```