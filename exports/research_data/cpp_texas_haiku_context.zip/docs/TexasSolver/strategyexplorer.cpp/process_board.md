`process_board`: The function of `process_board` is to process the current state of a poker game board.

**Parameters**: 
`TreeItem* treeitem`: This parameter represents a pointer to a TreeItem object, which contains data about the current game state.

**Code Description**: 
The code splits the string representation of the game board into individual card strings using the `string_split` function. It then creates a vector of Card objects from these strings and adds any additional cards that may be present in the table strategy model to this vector. Finally, it formats the list of cards as an HTML string using the `boardCards2html` method and displays this string on a label widget.\\
## Code: 
```
void StrategyExplorer::process_board(TreeItem* treeitem){
    vector<string> board_str_arr = string_split(this->qSolverJob->board,',');
    vector<Card> cards;
    for(string one_board_str:board_str_arr){
        cards.push_back(Card(one_board_str));
    }
    if(treeitem != NULL){
        if(treeitem->m_treedata.lock()->getRound() == GameTreeNode::GameRound::TURN && !this->tableStrategyModel->getTrunCard().empty()){
            cards.push_back(Card(this->tableStrategyModel->getTrunCard()));
        }
        else if(treeitem->m_treedata.lock()->getRound() == GameTreeNode::GameRound::RIVER){
            if(!this->tableStrategyModel->getTrunCard().empty())
                cards.push_back(Card(this->tableStrategyModel->getTrunCard()));
            if(!this->tableStrategyModel->getRiverCard().empty())
                cards.push_back(Card(this->tableStrategyModel->getRiverCard()));
        }
    }
    this->ui->boardLabel->setText(QString("<b>%1: </b>").arg(tr("board")) + Card::boardCards2html(cards));
}
```