`on_ipRangeButtom_clicked`: The function of `on_ipRangeButtom_clicked` is to update the detail window setting mode to RANGE_IP and refresh the views.

**Code Description**: When the ipRangeButtom button is clicked, this method updates the detailWindowSetting.mode to DetailWindowMode::RANGE_IP. It then triggers an update on the strategyTableView, detailView, roughStrategyViewerModel, and roughStrategyView by calling their respective viewport()->update() methods. This suggests that the views are being refreshed or updated with new data when the button is clicked. The roughStrategyViewerModel->onchanged() method is also called to notify any listeners of changes in the model's contents.\\
## Code: 
```
void StrategyExplorer::on_ipRangeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::RANGE_IP;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```