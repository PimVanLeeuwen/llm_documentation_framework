`item_clicked`: The function of `item_clicked` is to process a tree click event in the strategy explorer, updating the UI accordingly.

**Parameters**: 
`const QModelIndex& index`: This parameter represents the index of the item that was clicked in the tree view.

**Code Description**: When an item is clicked in the tree view, this function retrieves the corresponding TreeItem object and processes it by calling `process_treeclick`, `process_board`, and updating the table strategy model. It also updates the rough strategy viewer model and triggers a resize event for the rough strategy view. If any errors occur during processing, an error message is printed to the console.\\
## Code: 
```
void StrategyExplorer::item_clicked(const QModelIndex& index){
    try{
        TreeItem * treeNode = static_cast<TreeItem*>(index.internalPointer());
        this->process_treeclick(treeNode);
        this->process_board(treeNode);
        this->tableStrategyModel->setGameTreeNode(treeNode);
        this->tableStrategyModel->updateStrategyData();
        this->ui->strategyTableView->viewport()->update();
        this->roughStrategyViewerModel->onchanged();
        this->ui->roughStrategyView->triger_resize();
        this->ui->roughStrategyView->viewport()->update();
    }
    catch (const runtime_error& error)
    {
        qDebug().noquote() << tr("Encountering error:");//.toStdString() << endl;
        qDebug().noquote() << error.what() << "\n";
    }
}
```