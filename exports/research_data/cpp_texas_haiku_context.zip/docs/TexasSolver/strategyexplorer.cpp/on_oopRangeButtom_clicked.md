`on_oopRangeButtom_clicked`: The function of `on_oopRangeButtom_clicked` is to update the detail window setting mode to RANGE_OOP and refresh the views.

**Code Description**: When the oopRangeButton is clicked, this method updates the detailWindowSetting.mode to DetailWindowMode::RANGE_OOP. It then calls the update method on the viewport of the strategyTableView, detailView, roughStrategyViewerModel, and roughStrategyView to refresh their contents. The onchanged method of the roughStrategyViewerModel is also called to emit a signal for updating the header data of its associated table.\\
## Code: 
```
void StrategyExplorer::on_oopRangeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::RANGE_OOP;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```