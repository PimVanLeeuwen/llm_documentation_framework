`on_evOnlyModeButtom_clicked`: The function of `on_evOnlyModeButtom_clicked` is to update the detail window setting to EV_ONLY mode and refresh the strategy table view, detail view, rough strategy viewer model, and rough strategy view.

**Code Description**: When the evOnlyModeButton is clicked, this method updates the detailWindowSetting.mode to DetailWindowMode::EV_ONLY. It then triggers an update of the strategyTableView, detailView, roughStrategyViewerModel, and roughStrategyView by calling their respective viewport()->update() methods. The onchanged() method of the roughStrategyViewerModel is also called to notify any listeners that the model's contents have changed.\\
## Code: 
```
void StrategyExplorer::on_evOnlyModeButtom_clicked()
{
    this->detailWindowSetting.mode = DetailWindowSetting::DetailWindowMode::EV_ONLY;
    this->ui->strategyTableView->viewport()->update();
    this->ui->detailView->viewport()->update();
    this->roughStrategyViewerModel->onchanged();
    this->ui->roughStrategyView->viewport()->update();
}
```