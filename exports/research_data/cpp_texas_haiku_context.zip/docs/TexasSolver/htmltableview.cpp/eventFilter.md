`eventFilter`: The function of `eventFilter` is to filter events for a specific object, in this case, the viewport of an HtmlTableView.

**Parameters**:
`QObject *watched`: The object being watched for events.
`QEvent *event`: The event that occurred on the watched object.

**Code Description**: This code defines a method `eventFilter` in the `HtmlTableView` class. It checks if the event is related to mouse movement or leaving the viewport, and if so, it updates the last bearing indices and emits an itemMouseChange signal with the new indices. If the event is not related to mouse movement or leaving, it simply calls the parent's eventFilter method.\\
## Code: 
```
bool HtmlTableView::eventFilter(QObject *watched, QEvent *event){
    if(viewport() == watched){
        if(event->type() == QEvent::MouseMove){
        QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
        QModelIndex index = indexAt(mouseEvent->pos());
        if(index.isValid()){
            int i = index.row();
            int j = index.column();
            if(i != this->last_bearing_i || j != last_bearing_j){
                this->last_bearing_i = i;
                this->last_bearing_j = j;
                emit itemMouseChange(i,j);
            }
        }
        else{
        }
        }
        else if(event->type() == QEvent::Leave){
        }
    }
    return QTableView::eventFilter(watched, event);
}
```