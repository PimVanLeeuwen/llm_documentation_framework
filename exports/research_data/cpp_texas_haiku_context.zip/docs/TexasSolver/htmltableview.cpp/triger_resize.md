`triger_resize`: The function of `triger_resize` is to trigger a resize event in the HtmlTableView class, resizing its columns and rows proportionally among them.

**Code Description**: This code snippet appears to be part of a GUI application built with Qt. It defines a method called `triger_resize` within the `HtmlTableView` class. The purpose of this method is to handle changes in the size of the table view by triggering a resize event, which then adjusts the columns and rows accordingly.\\
## Code: 
```
void HtmlTableView::triger_resize(){
    QResizeEvent* ev = new QResizeEvent(this->size(),this->size());
    this->resizeEvent(ev);
    //this->resize(this->parentWidget()->size());
    delete ev;
}
```