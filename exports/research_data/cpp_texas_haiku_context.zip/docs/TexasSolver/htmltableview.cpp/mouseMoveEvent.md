**mouseMoveEvent**: The function of `mouseMoveEvent` is to handle mouse movement events in the HtmlTableView class.

**Parameters**: 
`QMouseEvent *event`: This parameter represents the mouse event that triggered the function call, containing information about the position and type of the event.

**Code Description**: 
The `mouseMoveEvent` function updates the anchor at the current mouse position and checks if it has changed since the last hover event. If the anchor has changed, it emits a `linkHovered` signal with the new anchor, or a `linkUnhovered` signal if the anchor is empty. The cursor is also updated to a pointing hand cursor while hovering over an anchor.\\
## Code: 
```
void HtmlTableView::mouseMoveEvent(QMouseEvent *event) {
    auto anchor = anchorAt(event->pos());

    if (_mousePressAnchor != anchor) {
        _mousePressAnchor.clear();
    }

    if (_lastHoveredAnchor != anchor) {
        _lastHoveredAnchor = anchor;
        if (!_lastHoveredAnchor.isEmpty()) {
            QApplication::setOverrideCursor(QCursor(Qt::PointingHandCursor));
            emit linkHovered(_lastHoveredAnchor);
        } else {
            QApplication::restoreOverrideCursor();
            emit linkUnhovered();
        }
    }
}
```