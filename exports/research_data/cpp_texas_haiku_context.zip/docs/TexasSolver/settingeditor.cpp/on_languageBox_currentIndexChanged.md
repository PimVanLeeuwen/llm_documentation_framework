`on_languageBox_currentIndexChanged`: The function of `on_languageBox_currentIndexChanged` is to display a message box when the language selection in the program changes.

**Parameters**: 
`int index`: This parameter represents the new index selected in the language box, indicating which language has been chosen by the user.

**Code Description**: When the language selection changes, this function checks if the program has already been initialized. If it has not, the function does nothing and returns. Otherwise, it displays a message box with a restart prompt to inform the user that they need to restart the program for the language change to take effect.\\
## Code: 
```
void SettingEditor::on_languageBox_currentIndexChanged(int index)
{
    if(!initized)return;
    QString message = tr("Restart program to make language selection effective.");
    qDebug().noquote() << message;
    QMessageBox msgBox;
    msgBox.setText(message);
    msgBox.exec();
}
```