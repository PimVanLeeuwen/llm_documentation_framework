`on_confirmBox_accepted`: The function of `on_confirmBox_accepted` is to save the user's settings when they click "OK" on a confirmation box.

**Code Description**: This method retrieves the current language and round values from the UI elements, converts them into a format suitable for storage, and then saves these values using QSettings.\\
## Code: 
```
void SettingEditor::on_confirmBox_accepted()
{
    QSettings setting("TexasSolver", "Setting");
    setting.beginGroup("solver");
    QString lang = this->ui->languageBox->currentText();
    QString language_str;
    if(lang == "English"){
        language_str = "EN";
    }else if(lang == "Chinese"){
        language_str = "CN";
    }else{
        qDebug().noquote() << tr("Unknown language: ") << lang << tr("Setting fail");
    }
    setting.setValue("language",language_str);

    int round = this->ui->roundBox->currentText().toInt();
    setting.setValue("dump_round",round);
}
```