**Expected Output**

`log_with_signal`: The function of `log_with_signal` is to emit a signal with the given message.
**Parameters**: 
`QString message`: This parameter holds the message that will be emitted as a signal.
**Code Description**: The `log_with_signal` method takes a QString (a string in Qt) as input, and it emits a signal named `message_signal` with this string.\\
## Code: 
```
void QSTextEdit::log_with_signal(QString message){
    emit message_signal(message);
}
```