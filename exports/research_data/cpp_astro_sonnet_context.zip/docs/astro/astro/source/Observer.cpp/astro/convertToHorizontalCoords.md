`convertToHorizontalCoords`: The function of `convertToHorizontalCoords` is to convert equatorial coordinates into horizontal coordinates.

**Parameters**:\
`const EquatorialCoords &ec`: This parameter represents the input equatorial coordinates, which include right ascension and declination.

**Code Description**: 
The code calculates the hour angle from the input right ascension using the `convertToHourAngle` method. It then uses the `Trigonometry::azimuth` and `Trigonometry::altitude` methods to calculate the azimuth and altitude angles, respectively, based on the hour angle, declination, and latitude. The calculated horizontal coordinates are returned as a `HorizontalCoords` object.\\
## Code: 
```
HorizontalCoords Observer<PLANET>::convertToHorizontalCoords(const EquatorialCoords &ec) const {
    HorizontalCoords hc;
    auto hourAngle = convertToHourAngle(ec.rightAscension);
    hc.azimuth = Trigonometry::azimuth(hourAngle, ec.declination, _position.latitude);
    hc.altitude = Trigonometry::altitude(hourAngle, ec.declination, _position.latitude);
    return hc;
  }
```