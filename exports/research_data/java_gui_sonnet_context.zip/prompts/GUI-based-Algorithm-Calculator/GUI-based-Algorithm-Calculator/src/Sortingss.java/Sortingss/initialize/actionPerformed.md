# PROMPT
## Information
**Project Structure:** `GUI-based-Algorithm-Calculator` \
**File Path:** `GUI-based-Algorithm-Calculator/GUI-based-Algorithm-Calculator/src/Sortingss.java/Sortingss/initialize` \
**Type:** `Method` \
**Method Name:** `actionPerformed` \
**Code Content:** \
`void actionPerformed(ActionEvent e){
				
				String fin = new String();
				String str=new String();
				str = textField.getText();
				
				String [] tok = str.split(" ");
				int [] num = new int[tok.length];
				
				for(int i=0;i<tok.length;i++){
					num[i]=Integer.parseInt(tok[i]);
				}
				if(key==1)
				{
					int j;
			        boolean flag = true;   // set flag to true to begin first pass
			        int temp;   //holding variable

			        while ( flag )
			        {
			            flag= false;    //set flag to false awaiting a possible swap
			            for( j=0;  j < num.length -1;  j++ )
			            {
			                if ( num[ j ] > num[j+1] )   // change to > for ascending sort
			                {
			                    temp = num[ j ];                //swap elements
			                    num[ j ] = num[ j+1 ];
			                    num[ j+1 ] = temp;
			                    flag = true;              //shows a swap occurred
			                }
			            }
			        }
			        fin = "Bubble Sort =";
				}
				if(key==2){
			        int n = num.length;

			        // One by one move boundary of unsorted subarray
			        for (int i = 0; i < n-1; i++)
			        {
			            // Find the minimum element in unsorted array
			            int min_idx = i;
			            for (int j = i+1; j < n; j++)
			                if (num[j] < num[min_idx])
			                    min_idx = j;

			            // Swap the found minimum element with the first
			            // element
			            int temp = num[min_idx];
			            num[min_idx] = num[i];
			            num[i] = temp;
			        }
			        tname="SELECTION SORT";
			        fin = "Selection Sort =";
				}
				if(key==3){
				
					
					quiks obj2 =new quiks();
					int size=num.length;
					obj2.quickSort(num,0,size-1);
					fin="Quick Sort =";
					tname="QUICK SORT";
				}
				
				if(key==4){
					int i, ke, j;
			        for (i = 1; i < tok.length; i++)
			        {
			            ke = num[i];
			            j = i - 1;

			        /* Move elements of arr[0..i-1], that are
			        greater than key, to one position ahead
			        of their current position */
			            while (j >= 0 && num[j] > ke)
			            {
			                num[j + 1] = num[j];
			                j = j - 1;
			            }
			            num[j + 1] = ke;
			        }
			        tname="INSERTION SORT";
			        fin = "Insertion Sort =";
				}
				if(key==5){
					merg obj3=new merg();
					int size =num.length-1;
					obj3.mergeSort(num, 0, size);
					fin ="Merge Sort =";
					tname="MERGE SORT";
				}
				
				if(key==6){
					heaps obj4=new heaps();
					int size;
					size=tok.length;
					obj4.heapSort(num,size);
					fin ="Heap Sort =";
					tname="HEAP SORT";
				}
				
				String str1[] =new String[tok.length];
				for(int i=0;i<tok.length;i++){
					str1[i]=Integer.toString(num[i]);
					fin=fin+" "+str1[i];
				}
				textArea.setText(fin);
				textArea_1.setText(tname);
			}`

## Calls 
 This code calls the following methods within the repository: 
### GUI-based-Algorithm-Calculator/GUI-based-Algorithm-Calculator/src/Sortingss.java/quiks.quickSort 
 - Explanation:  _This code implements the quickSort algorithm, which sorts an array by recursively partitioning it around a pivot element. The quickSort method calls itself to sort sub-arrays on either side of the pivot._ 
### GUI-based-Algorithm-Calculator/GUI-based-Algorithm-Calculator/src/Sortingss.java/merg.mergeSort 
 - Explanation:  _This code implements the merge step in the Merge Sort algorithm, which combines two sorted subarrays into a single sorted array. The `mergeSort` method recursively divides the input array until it can be merged back together in sorted order._ 
### GUI-based-Algorithm-Calculator/GUI-based-Algorithm-Calculator/src/Sortingss.java/heaps.heapSort 
 - Explanation:  _This code implements the heap sort algorithm, which sorts an array in ascending order using a binary heap data structure. The `heapSort` method uses the `heapify` function to rearrange the array and maintain the heap property._ 





## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output. 
Do not start with an introduction of your answer (so not "here's the completed template" first), just give what is asked. 
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`actionPerformed`: The function of `actionPerformed` is *FILL IN* 
**Parameters**:\
`ActionEvent e`: *FILL IN* \

**Code Description**: *FILL IN*
