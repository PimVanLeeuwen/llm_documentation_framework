The `setAmount` method sets the amount of an invoice to a specified value, allowing for customization of the invoice total.

This method returns the updated `InvoiceBuilder` instance, enabling method chaining for fluent API usage.