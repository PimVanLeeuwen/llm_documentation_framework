`setJob_id`: The function of `setJob_id` is to set the job ID for an invoice.

**Parameters**:
`int job_id`: This parameter represents the unique identifier of a job, which will be assigned to the invoice.

**Code Description**:
The `setJob_id` method is used in conjunction with the `InvoiceBuilder` class to construct an `Invoice` object. It takes an integer value representing the job ID as input and assigns it to the corresponding field within the builder. The method returns the updated `InvoiceBuilder` instance, allowing for a fluent API where multiple settings can be chained together. This approach enables developers to create invoices with specific attributes in a concise and readable manner.