`setAmount`: The function of `setAmount` is to set the amount of an invoice.

**Parameters**:
`BigDecimal amount`: This parameter represents the new amount to be set for the invoice. It must be a valid BigDecimal value, representing a monetary amount.

**Code Description**: 
The `setAmount` method takes a `BigDecimal` object as input and sets it as the amount of the current invoice. However, before setting the amount, it checks if the provided amount is less than or equal to zero (0.00). If this condition is met, it throws an `EntityException` with a message indicating that the invoice amount cannot be negative or zero. This ensures that the invoice amount is always a positive value. Once validated, the method sets the provided amount as the new value for the invoice's amount property.