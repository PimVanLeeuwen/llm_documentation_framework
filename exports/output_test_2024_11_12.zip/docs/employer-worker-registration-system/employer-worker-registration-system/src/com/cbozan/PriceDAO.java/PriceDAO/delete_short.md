This method deletes a price record from the database based on its ID.
It returns true if the deletion was successful, false otherwise.