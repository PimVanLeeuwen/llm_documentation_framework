`setPaytype`: The function of `setPaytype` is to set the payment type for a payment object.

**Parameters**:
`Paytype paytype`: This parameter represents the new payment type that will be assigned to the payment object. It must not be null, otherwise an EntityException will be thrown.

**Code Description**: 
The `setPaytype` method takes a `Paytype` object as a parameter and assigns it to the `paytype` field of the current payment object. If the provided `paytype` is null, it throws an `EntityException` with the message "Paytype in Payment is null". This ensures that the payment type cannot be set to a null value, maintaining data integrity.