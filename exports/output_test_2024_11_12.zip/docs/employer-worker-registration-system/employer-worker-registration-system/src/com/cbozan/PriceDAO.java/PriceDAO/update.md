`update`: The function of `update` is to update a Price object in the database.

**Parameters**:
`Price price`: A Price object containing updated fulltime, halftime, and overtime values, along with its unique id.

**Code Description**:

The `update` method updates a Price object in the database. It first calls the `updateControl` method to check if the update is successful and if the price record already exists in the cache. If the update control fails, it returns false. 

If the update control succeeds, it establishes a connection to the database using the `DB.getConnection()` method. Then, it prepares a SQL statement using a PreparedStatement object to update the fulltime, halftime, and overtime values of the Price object with the given id.

The method sets the updated values for fulltime, halftime, and overtime using the `setBigDecimal` and `setInt` methods of the PreparedStatement object. It then executes the SQL statement using the `executeUpdate` method and stores the result in a variable named 'result'.

If the update is successful (i.e., the result is not zero), it updates the cache by putting the updated Price object into the cache with its id as the key.

The method catches any SQLException that may occur during the execution of the SQL statement and displays an error message to the user using the `showSQLException` method. Finally, it returns true if the update is successful (i.e., the result is not zero), and false otherwise.