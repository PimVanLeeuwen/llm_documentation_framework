This method creates a new work entry in the database by executing an INSERT query, and if successful, retrieves the newly created work ID to build a Work object.

The create method returns true if the insertion was successful, false otherwise.