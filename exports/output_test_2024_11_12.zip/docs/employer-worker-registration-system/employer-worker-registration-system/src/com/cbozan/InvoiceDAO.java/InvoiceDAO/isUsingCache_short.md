This method checks if the InvoiceDAO object is using a cache.
It returns a boolean value indicating whether caching is enabled or disabled.