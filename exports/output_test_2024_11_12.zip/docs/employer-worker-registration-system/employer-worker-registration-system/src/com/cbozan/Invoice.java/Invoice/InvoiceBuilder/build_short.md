This method creates an `Invoice` object, either with default values if no job is provided or with specified details including ID, job, amount, and date.

The `build()` method throws an `EntityException` if any errors occur during the creation process.