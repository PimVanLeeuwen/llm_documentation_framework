**toString**: The function of `toString` is to return a string representation of an employer's name, combining their first and last names.

**Code Description**: 
The `toString` method in the Employer class returns a string value that represents the full name of an employer. This method calls two other methods within the same class: `getFname()` and `getLname()`. The `getFname()` method retrieves the first name of the employer, while the `getLname()` method retrieves the last name.

The `toString` method concatenates the results of these two method calls with a space in between, effectively creating a string that says "first name" + "last name". This allows for easy display or logging of an employer's full name.