**Invoice**: The function of `Invoice` is to represent a financial transaction between an employer and a worker in the employer-worker registration system, encapsulating details such as ID, job, amount, and date.

**Code Description**: 
The `Invoice` class serves as a data model for representing invoices within the employer-worker registration system. It implements the `Serializable` interface, allowing its instances to be serialized and deserialized. The class has four private fields: `id`, `job`, `amount`, and `date`, which are used to store the invoice's unique identifier, associated job, total amount, and date of issuance, respectively.

The `Invoice` class provides several constructors for creating new instances:

*   A default constructor that initializes an invoice with default values (ID = 0, job = null, amount = null, date = null).
*   A constructor that takes an `InvoiceBuilder` object as a parameter and uses its properties to initialize the invoice.
*   A constructor that directly sets the ID, job, amount, and date of the invoice.

The class also includes getter and setter methods for each field, which allow accessing and modifying the invoice's attributes. These methods throw an `EntityException` if invalid values are provided (e.g., a negative or zero ID, a null job, or a non-positive amount).

Additionally, the `Invoice` class provides a static method called `getEmptyInstance()`, which returns an empty instance of the invoice with default values.

The `InvoiceBuilder` class is used to construct new invoices by setting their properties in a fluent manner. It allows chaining method calls to set the ID, job, amount, and date of the invoice before building it.

The `toString()` method provides a human-readable representation of the invoice as a string, while the `hashCode()` and `equals()` methods are used for comparing and hashing invoices, respectively.

Overall, the `Invoice` class serves as a fundamental data structure in the employer-worker registration system, enabling the creation, manipulation, and storage of financial transactions between employers and workers.