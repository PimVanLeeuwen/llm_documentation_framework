`createControl`: The function of `createControl` is to validate the creation of a new employer record by checking if an existing employer with the same first and last name already exists in the cache.

**Parameters**:
`Employer employer`: This method takes an instance of the Employer class as input, containing the first name (fname) and last name (lname) of the employer to be created.

**Code Description**: 
The `createControl` method iterates through a cache of existing employers. For each entry in the cache, it checks if the first name and last name of the current employer match those of an existing employer in the cache. If a matching employer is found, an error message is set indicating that the employer already exists, and the method returns false to prevent the creation of a duplicate record. If no matching employer is found after iterating through the entire cache, the method returns true, allowing the creation of a new employer record.