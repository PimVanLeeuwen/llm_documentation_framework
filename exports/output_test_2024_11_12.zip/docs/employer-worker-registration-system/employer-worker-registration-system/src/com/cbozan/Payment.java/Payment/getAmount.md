`getAmount`: The function of `getAmount` is to return the total amount associated with a payment.

**Code Description**: 
The `getAmount` method in the Payment class returns the total amount of a payment. It simply retrieves and returns the value of the `amount` field, which represents the monetary value of the payment. This method does not perform any calculations or modifications to the amount; it merely provides access to the existing amount value. The return type is BigDecimal, indicating that the amount is represented as a decimal number with precise arithmetic capabilities.