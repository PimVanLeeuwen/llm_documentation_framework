**toString**: The function of `toString` is to return a string representation of an Invoice object, including its id, job, amount, and date.

**Code Description**: 
The `toString()` method in the Invoice class returns a string that contains the details of the invoice. This string includes the invoice's id, the job it was created for, the total amount, and the date it was issued. The method is used to provide a human-readable representation of an Invoice object when it needs to be displayed or logged.

The `toString()` method takes no arguments and returns a String value. It uses the `+` operator to concatenate the values of the id, job, amount, and date fields into a single string, which is then returned by the method.

This method is typically used in debugging or logging scenarios where the details of an Invoice object need to be displayed or recorded. For example:

```java
Invoice invoice = new Invoice(1, "Job A", 1000.00, "2022-01-01");
System.out.println(invoice.toString()); // Output: Invoice [id=1, job=Job A, amount=1000.0, date=2022-01-01]
```