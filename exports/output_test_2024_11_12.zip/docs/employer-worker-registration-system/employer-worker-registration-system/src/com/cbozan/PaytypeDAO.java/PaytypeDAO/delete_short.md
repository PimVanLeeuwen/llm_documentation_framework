This method deletes a paytype from the database based on its ID.
It returns true if the deletion was successful, false otherwise.