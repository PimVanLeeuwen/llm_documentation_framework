This method checks if it's possible to update a work type in the system without conflicting with an existing one.
It returns true if no conflict exists, false otherwise.