`setAmount`: The function of `setAmount` is to set the amount of an invoice.

**Parameters**:
`BigDecimal amount`: This parameter represents the monetary value of the invoice, which can be a decimal number with precision up to 28 digits and scale up to 100 digits.

**Code Description**: 
The `setAmount` method takes a `BigDecimal` object as input and assigns it to the `amount` field of the current instance. It returns the same instance (`this`) for method chaining purposes, allowing multiple settings to be performed in a single statement.