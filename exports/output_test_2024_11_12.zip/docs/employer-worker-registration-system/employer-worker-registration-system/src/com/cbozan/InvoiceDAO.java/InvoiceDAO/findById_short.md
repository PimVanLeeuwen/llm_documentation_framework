The `findById` method in the InvoiceDAO class retrieves an invoice by its ID from a cache or database, depending on the caching configuration.

If caching is disabled, it fetches all invoices and then checks the cache for the requested ID; if found, it returns the cached invoice, otherwise it returns null.