`getId`: The function of `getId` is to return the unique identifier associated with an invoice.

**Code Description**: 
The `getId` method is a simple getter function that returns the value of the `id` field. It takes no arguments and returns an integer representing the unique identifier of the invoice. This method can be used by other parts of the system to retrieve the ID of an invoice, allowing for identification and management of invoices based on their unique identifiers.