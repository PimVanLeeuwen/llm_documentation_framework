`createControl`: The function of `createControl` is to create a control for the given payment.

**Parameters**:
`Payment payment`: A Payment object that contains information about the payment to be controlled.

**Code Description**:
The `createControl` method takes a Payment object as input and returns a boolean value. It simply returns true, indicating that the creation of the control was successful. The method does not perform any complex operations or data transformations; it merely indicates that the control has been created.