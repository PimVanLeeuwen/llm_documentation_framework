**InvoiceBuilder**: The function of `InvoiceBuilder` is to create an invoice object by setting its properties and then building the actual invoice instance.

**Code Description**: 
The `InvoiceBuilder` class is a utility class used to construct an `Invoice` object. It provides a fluent API for setting various properties of the invoice, such as ID, job ID, job details, amount, and date. The builder pattern allows for a step-by-step construction of the invoice object, making it easier to create invoices with specific characteristics.

**Method Analysis**: 

### setID(int id)
Sets the ID property of the invoice.
*   **Purpose:** Sets the unique identifier for the invoice.
*   **Parameters:** An integer representing the ID value.
*   **Return Value:** The `InvoiceBuilder` instance itself, allowing method chaining.

### setJob_id(int job_id)
Sets the job ID property of the invoice.
*   **Purpose:** Associates the invoice with a specific job.
*   **Parameters:** An integer representing the job ID value.
*   **Return Value:** The `InvoiceBuilder` instance itself, enabling method chaining.

### setJob(Job job)
Sets the job details property of the invoice.
*   **Purpose:** Links the invoice to a particular job, including its attributes.
*   **Parameters:** A `Job` object containing the job details.
*   **Return Value:** The `InvoiceBuilder` instance itself, facilitating method chaining.

### setAmount(BigDecimal amount)
Sets the amount property of the invoice.
*   **Purpose:** Specifies the total cost or value associated with the invoice.
*   **Parameters:** A `BigDecimal` representing the amount value.
*   **Return Value:** The `InvoiceBuilder` instance itself, allowing for method chaining.

### setDate(Timestamp date)
Sets the date property of the invoice.
*   **Purpose:** Records the timestamp when the invoice was created or is due.
*   **Parameters:** A `Timestamp` object representing the date value.
*   **Return Value:** The `InvoiceBuilder` instance itself, enabling method chaining.

### build() throws EntityException
Constructs and returns an `Invoice` object based on the properties set using the builder.
*   **Purpose:** Finalizes the invoice creation process by generating a new `Invoice` instance.
*   **Parameters:** None.
*   **Return Value:** A fully constructed `Invoice` object, or null if the job is null.
*   **Throws:** An `EntityException` if any errors occur during the construction process.