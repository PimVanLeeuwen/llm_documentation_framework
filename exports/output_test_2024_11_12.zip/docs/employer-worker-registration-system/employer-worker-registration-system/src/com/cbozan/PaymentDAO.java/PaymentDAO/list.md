**list**: Retrieves a list of payments based on the provided column names and IDs.

**Parameters**:
- `String[] columnName`: An array of column names to filter payments by.
- `int[] id`: An array of IDs corresponding to the column names in `columnName`.

**Code Description**:
The `list` method takes two parameters, `columnName` and `id`, both of which are arrays. It iterates through each element in `columnName` and its corresponding ID in `id`. For each pair, it constructs a SQL query to select payments from the database where the specified column matches the provided ID.

The method then executes this query using a `Statement` object obtained from a database connection. The results are stored in a `ResultSet`, which is iterated through to create `Payment` objects using a `PaymentBuilder`. Each payment object is added to a list, which is returned at the end of the method.

If any errors occur during the execution of the query or while building payments, error messages are printed to the console. If the lengths of `columnName` and `id` do not match, an empty list is returned.