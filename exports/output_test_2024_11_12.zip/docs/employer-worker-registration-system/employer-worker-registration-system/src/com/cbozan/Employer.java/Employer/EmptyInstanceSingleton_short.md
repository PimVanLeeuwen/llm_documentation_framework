This code defines a singleton class that instantiates an `Employer` object only once, storing it in a private static field.

The instance can be accessed globally through this singleton class, ensuring only one instance of the `Employer` class exists throughout the application.