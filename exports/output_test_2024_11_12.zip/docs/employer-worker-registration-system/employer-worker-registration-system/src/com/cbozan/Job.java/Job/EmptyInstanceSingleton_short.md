This code defines a singleton class that instantiates a `Job` object only once, storing it in a private static field.

The instance can be accessed globally through this singleton class.