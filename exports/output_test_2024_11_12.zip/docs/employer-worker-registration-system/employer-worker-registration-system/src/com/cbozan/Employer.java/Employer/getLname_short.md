This method retrieves the last name of an employer.
It returns a string value representing the employer's last name.