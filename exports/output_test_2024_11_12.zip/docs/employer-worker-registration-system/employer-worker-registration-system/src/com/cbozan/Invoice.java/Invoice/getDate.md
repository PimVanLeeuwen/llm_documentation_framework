`getDate`: The function of `getDate` is to return the current date.

**Code Description**: 
The `getDate` method returns the current date. It uses a Timestamp object to get the current date and time, but only returns the date part. This suggests that it might be used in scenarios where the exact time is not necessary, such as displaying a due date or invoice date on an invoice (Invoice.java). The method does not take any parameters and simply returns the date value.