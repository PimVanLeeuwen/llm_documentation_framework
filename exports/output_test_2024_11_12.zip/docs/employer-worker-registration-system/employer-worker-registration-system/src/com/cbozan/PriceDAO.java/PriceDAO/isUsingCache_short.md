This method checks if cache is being used in a system.
It returns a boolean value indicating whether cache is enabled or not.