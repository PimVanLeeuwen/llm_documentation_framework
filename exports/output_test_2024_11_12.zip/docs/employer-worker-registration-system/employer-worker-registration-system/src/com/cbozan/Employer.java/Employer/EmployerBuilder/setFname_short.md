This method sets the first name of an Employer object.
It returns the same EmployerBuilder instance to enable method chaining.