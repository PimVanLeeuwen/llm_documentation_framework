This method sets the last name of an Employer object.
It returns the same EmployerBuilder instance to enable method chaining.