This method displays an error message to the user when a SQL exception occurs.
It takes a SQLException object as input, extracts relevant information from it, and shows a dialog box with the details.