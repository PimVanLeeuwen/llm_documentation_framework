This method returns the total amount associated with an invoice.
It uses a BigDecimal to represent the monetary value, ensuring precision in financial calculations.