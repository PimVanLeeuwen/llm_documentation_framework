This method, `list`, retrieves a list of invoices from a database based on a specified column name and ID.
It uses JDBC to execute a SQL query and returns a list of Invoice objects.