This method checks if a work type already exists in the cache before creating a new control.
It returns true if the work type does not exist, and false otherwise.