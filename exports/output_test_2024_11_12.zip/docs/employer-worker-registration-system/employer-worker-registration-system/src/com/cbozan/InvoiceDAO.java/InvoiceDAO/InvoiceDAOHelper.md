**InvoiceDAOHelper**: The function of `InvoiceDAOHelper` is to provide a singleton instance of the `InvoiceDAO` class.

**Code Description**: 
The `InvoiceDAOHelper` class serves as a helper for managing instances of the `InvoiceDAO` class. It contains a private static final field named `instance`, which holds a reference to an instance of `InvoiceDAO`. The instance is created only once, when the class is loaded, and subsequent requests for the instance are satisfied by returning the same object.

This implementation follows the singleton design pattern, ensuring that only one instance of `InvoiceDAO` exists throughout the application. This can be useful in scenarios where a shared resource or data access object needs to be managed centrally.