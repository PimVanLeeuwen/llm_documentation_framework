This method, `verifyLogin`, checks if a given username and password combination exists in the database.
It returns true if a match is found, false otherwise.