`list`: The function of `list` is to retrieve a list of work objects from the database or cache, depending on the system's configuration.

**Code Description**: 
The `list` method in the WorkDAO class retrieves a list of work objects from either the cache or the database. If the cache is not empty and the system is configured to use it, the method returns the cached work objects. Otherwise, it clears the cache, establishes a connection to the database, executes a SQL query to select all work records, and populates a list with Work objects built from each record. The populated list is then returned. If any errors occur during this process, the method catches and handles them by displaying error messages to the user. \\
## Code: 
```
List<Work> list(){
		
		List<Work> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Work> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM work;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorkBuilder builder;
			Work work;
			
			while(rs.next()) {
				
				builder = new WorkBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setWorker_id(rs.getInt("worker_id"));
				builder.setWorktype_id(rs.getInt("worktype_id"));
				builder.setWorkgroup_id(rs.getInt("workgroup_id"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					work = builder.build();
					list.add(work);
					cache.put(work.getId(), work);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
	}
```