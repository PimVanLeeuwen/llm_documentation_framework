`list`: The function of `list` is to retrieve a list of prices from the database or cache, depending on the system's configuration.

**Code Description**: 
The `list` method in the PriceDAO class retrieves a list of prices from either the cache or the database. If the cache is not empty and the system is configured to use the cache, it returns the cached prices. Otherwise, it clears the cache, establishes a connection to the database, executes a SQL query to select all prices, and populates the list with the retrieved prices. The method also handles any SQL exceptions that may occur during the database operation. If an entity exception occurs while building a price object, it displays an error message to the user. Finally, it returns the populated list of prices. \\
## Code: 
```
List<Price> list(){
		
		List<Price> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Price> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM price;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			PriceBuilder builder;
			Price price;
			
			while(rs.next()) {
				
				builder = new PriceBuilder();
				builder.setId(rs.getInt("id"));
				builder.setFulltime(rs.getBigDecimal("fulltime"));
				builder.setHalftime(rs.getBigDecimal("halftime"));
				builder.setOvertime(rs.getBigDecimal("overtime"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					price = builder.build();
					list.add(price);
					cache.put(price.getId(), price);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
		
	}
```