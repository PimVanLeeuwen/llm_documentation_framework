This method updates control for a given price object by checking if it already exists in the cache.
It returns true if the price can be updated, false otherwise with an error message.