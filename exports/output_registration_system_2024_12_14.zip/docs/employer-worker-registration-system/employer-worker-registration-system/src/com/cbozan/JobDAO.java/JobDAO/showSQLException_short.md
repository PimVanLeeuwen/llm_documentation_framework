This method displays a Java exception as a message dialog box to the user.
It takes a SQLException object as input, extracts its error details, and presents them in a GUI alert.