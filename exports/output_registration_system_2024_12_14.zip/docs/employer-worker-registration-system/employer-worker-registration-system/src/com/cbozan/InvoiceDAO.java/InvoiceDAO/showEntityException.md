**showEntityException**: The function of `showEntityException` is to display an error message to the user when there's an issue with adding a new entity.

**Parameters**:
- **EntityException e**: This parameter represents the exception that occurred while trying to add a new entity. It contains information about the error, such as its message and cause.
- **String msg**: This parameter is a custom message provided by the user or the system to be displayed along with the exception details.

**Code Description**:
The `showEntityException` method takes an `EntityException` object (`e`) and a custom message string (`msg`) as parameters. It constructs a comprehensive error message by concatenating the custom message, the exception's message, localized message, and cause. This constructed message is then displayed to the user using a `JOptionPane.showMessageDialog`. The method does not return any value; it simply shows the error message to the user. \\
## Code: 
```
void showEntityException(EntityException e, String msg) {
		String message = msg + " not added" + 
				"\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + e.getCause();
			JOptionPane.showMessageDialog(null, message);
	}
```