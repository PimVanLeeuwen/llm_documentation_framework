This method returns the last name of an employer.
It provides a getter function to access the lname field directly.