`create`: Creates a new invoice in the database and updates the cache with the newly created invoice.

**Parameters**:
`Invoice invoice`: The invoice object to be created, containing job ID and amount information.

**Code Description**:

The `create` method takes an `Invoice` object as input and performs the following operations:

1. It establishes a connection to the database using the `DB.getConnection()` method.
2. It prepares a SQL statement to insert the new invoice into the database, using the job ID and amount from the input `Invoice` object.
3. It executes the SQL statement and retrieves the result of the insertion operation.
4. If the insertion is successful (i.e., the result is not zero), it retrieves the newly created invoice from the database by executing a SELECT query with an ORDER BY clause to get the latest invoice ID.
5. It creates a new `Invoice` object using the retrieved data and adds it to the cache using the `cache.put()` method.

The method returns `true` if the creation of the invoice is successful (i.e., the result is not zero), and `false` otherwise. If any SQL exceptions occur during the execution, they are caught and handled by calling the `showSQLException()` method. \\
## Code: 
```
boolean create(Invoice invoice) {
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO invoice (job_id,amount) VALUES (?,?);";
		String query2 = "SELECT * FROM invoice ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, invoice.getJob().getId());
			pst.setBigDecimal(2, invoice.getAmount());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					InvoiceBuilder builder = new InvoiceBuilder();
					builder.setId(rs.getInt("id"));
					builder.setJob_id(rs.getInt("job_id"));
					builder.setAmount(rs.getBigDecimal("amount"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Invoice inv = builder.build();
						cache.put(inv.getId(), inv);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id"));
					}
					
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```