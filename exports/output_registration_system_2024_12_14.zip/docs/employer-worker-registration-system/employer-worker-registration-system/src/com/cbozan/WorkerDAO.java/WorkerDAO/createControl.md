`createControl`: The function of `createControl` is to validate the creation of a new worker control.

**Parameters**:
`Worker worker`: A Worker object containing the first name and last name of the worker to be validated.

**Code Description**:

The `createControl` method checks if a worker with the same first name and last name already exists in the cache. If such a worker is found, it returns false and sets an error message indicating that the worker's record already exists. If no duplicate worker is found, it returns true, allowing the creation of a new worker control.

This method iterates through each entry in the cache using a for-each loop. For each entry, it checks if the first name and last name of the current worker match those of the worker being validated. If a match is found, it sets an error message and returns false. If no match is found after iterating through all entries, it returns true, indicating that the new worker control can be created. \\
## Code: 
```
boolean createControl(Worker worker) {
		for(Entry<Integer, Worker> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(worker.getFname()) && obj.getValue().getLname().equals(worker.getLname())) {
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```