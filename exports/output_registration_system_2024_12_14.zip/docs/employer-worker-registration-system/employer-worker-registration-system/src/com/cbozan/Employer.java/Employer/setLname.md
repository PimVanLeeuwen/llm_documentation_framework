`setLname`: The function of `setLname` is to set the last name of an employer.

**Parameters**:
`String lname`: The last name of the employer to be set, which must not be empty and should not exceed a certain length (`DBConst.LNAME_LENGTH`).

**Code Description**: 
The `setLname` method takes a string parameter `lname` representing the last name of an employer. It checks if the provided last name is valid by ensuring it's not empty and does not exceed the maximum allowed length defined in `DBConst.LNAME_LENGTH`. If the validation fails, it throws an `EntityException` with a descriptive message. Otherwise, it updates the `lname` field of the current employer object with the provided value. \\
## Code: 
```
void setLname(String lname) throws EntityException {
		if(lname.length() == 0 || lname.length() > DBConst.LNAME_LENGTH)
			throw new EntityException("Employer last name empty or too long");
		this.lname = lname;
	}
```