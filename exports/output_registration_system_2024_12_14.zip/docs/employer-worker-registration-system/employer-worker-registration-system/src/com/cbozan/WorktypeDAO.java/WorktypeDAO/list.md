`list`: The function of `list` is to retrieve a list of worktypes from the database or cache, depending on the system's configuration.

**Code Description**: 
The `list` method in the WorktypeDAO class retrieves a list of worktypes from either the cache or the database. If the cache is not empty and the system is configured to use the cache, it returns the cached worktypes. Otherwise, it clears the cache, establishes a connection to the database, executes a SQL query to select all worktypes, and populates the list with the retrieved worktypes. The method also caches each worktype as it is added to the list. If any SQL exceptions occur during this process, they are caught and handled by displaying an error message. Finally, the populated list of worktypes is returned. \\
## Code: 
```
List<Worktype> list(){
		
		List<Worktype> list = new ArrayList<>();
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Worktype> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM worktype;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorktypeBuilder builder;
			Worktype worktype;
			
			while(rs.next()) {
				
				builder = new WorktypeBuilder();
				builder.setId(rs.getInt("id"));
				builder.setTitle(rs.getString("title"));
				builder.setNo(rs.getInt("no"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					worktype = builder.build();
					list.add(worktype);
					cache.put(worktype.getId(), worktype);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id") + ", Title : " + rs.getString("title"));
				}
				
			}
			
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
		
	}
```