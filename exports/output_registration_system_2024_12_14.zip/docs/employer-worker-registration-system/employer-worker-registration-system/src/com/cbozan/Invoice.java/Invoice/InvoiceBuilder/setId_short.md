This method sets the ID for an invoice in a registration system.
It returns the builder instance to allow chaining method calls.