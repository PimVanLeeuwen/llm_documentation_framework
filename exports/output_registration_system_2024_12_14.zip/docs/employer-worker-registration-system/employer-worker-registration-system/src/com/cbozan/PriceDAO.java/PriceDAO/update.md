`update`: The function of `update` is to update a price record in the database.

**Parameters**:
`Price price`: A Price object containing the updated fulltime, halftime, and overtime values, as well as the ID of the price record to be updated.

**Code Description**: 
The `update` method updates a price record in the database by executing an SQL UPDATE query. It first checks if the update control is successful using the `updateControl` method. If it is, the method establishes a connection to the database using the `DB.getConnection` method and prepares a PreparedStatement with the UPDATE query. The updated fulltime, halftime, and overtime values are set in the PreparedStatement using the corresponding getter methods of the Price object. The method then executes the UPDATE query and checks if any rows were affected. If so, it updates the cache by putting the updated Price object into the cache with its ID as the key. Finally, the method returns true if the update was successful (i.e., at least one row was affected), and false otherwise. \\
## Code: 
```
boolean update(Price price) {
		
		if(updateControl(price) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE price SET fulltime=?,"
				+ "halftime=?, overtime=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setBigDecimal(1, price.getFulltime());
			pst.setBigDecimal(2, price.getHalftime());
			pst.setBigDecimal(3, price.getOvertime());
			pst.setInt(4, price.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(price.getId(), price);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```