This method returns a singleton instance of the PriceDAO class.
It provides a global point of access to the PriceDAO object, ensuring only one instance exists throughout the application.