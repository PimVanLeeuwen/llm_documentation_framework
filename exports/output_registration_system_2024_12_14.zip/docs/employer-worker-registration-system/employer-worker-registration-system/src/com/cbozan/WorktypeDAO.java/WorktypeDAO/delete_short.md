This method deletes a worktype from the database based on its ID, updating the cache if successful.
It returns true if the deletion was successful and false otherwise.