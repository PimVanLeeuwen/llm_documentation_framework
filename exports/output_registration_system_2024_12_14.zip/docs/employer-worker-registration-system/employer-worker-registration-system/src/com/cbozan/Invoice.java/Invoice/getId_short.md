This method returns the unique identifier assigned to an invoice.
It provides a way to access and retrieve the ID value.