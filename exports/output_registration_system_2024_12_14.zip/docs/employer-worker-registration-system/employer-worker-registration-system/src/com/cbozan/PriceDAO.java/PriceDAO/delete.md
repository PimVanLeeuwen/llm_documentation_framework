`delete`: The function of `delete` is to delete a specific Price object from the database.

**Parameters**:
`Price price`: A Price object that contains the ID of the record to be deleted.

**Code Description**:

The `delete` method takes a `Price` object as input and deletes the corresponding record from the database. It uses a PreparedStatement to execute a DELETE query on the "price" table, where the id is matched with the one provided in the Price object. If the deletion is successful (i.e., the result is not zero), it also removes the cached price with the same ID.

The method catches any SQL exceptions that may occur during the execution of the query and calls the `showSQLException` method to display an error message to the user. The method returns a boolean value indicating whether the deletion was successful (true) or not (false). \\
## Code: 
```
boolean delete(Price price) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM price WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, price.getId());
			result = ps.executeUpdate();
			
			if(result != 0) {
				cache.remove(price.getId());
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
		
	}
```