`setFname`: The function of `setFname` is to set the first name of an employer.

**Parameters**:
`String fname`: The first name of the employer, which must be within a certain length limit.

**Code Description**:
The `setFname` method sets the first name (`fname`) of an employer. It checks if the provided first name is not empty and does not exceed the maximum allowed length as defined in `DBConst.FNAME_LENGTH`. If either condition is met, it throws an `EntityException` with a message indicating that the employer's name is either empty or too long. Otherwise, it assigns the provided first name to the instance variable `fname`. \\
## Code: 
```
void setFname(String fname) throws EntityException {
		if(fname.length() == 0 || fname.length() > DBConst.FNAME_LENGTH)
			throw new EntityException("Employer name empty or too long");
		this.fname = fname;
	}
```