This method creates a new invoice in the database by executing an INSERT query, and then retrieves the newly created invoice ID to populate an Invoice object.

The create method returns true if the insertion was successful, false otherwise.