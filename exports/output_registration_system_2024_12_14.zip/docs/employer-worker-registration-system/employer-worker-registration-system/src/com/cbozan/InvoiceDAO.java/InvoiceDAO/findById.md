`findById`: The function of `findById` is to retrieve an Invoice object from the cache or database based on its unique identifier.

**Parameters**:
`int id`: The unique identifier of the Invoice object to be retrieved.

**Code Description**:

The `findById` method takes an integer `id` as input and returns an Invoice object. If the `usingCache` flag is set to false, it calls the `list()` method to populate the cache with all invoices. Then, it checks if the cache contains an invoice with the given `id`. If it does, it returns the cached invoice; otherwise, it returns null.

This implementation suggests that the cache is used to store previously retrieved invoices, and the `findById` method first checks the cache before querying the database or performing any other operations. This approach can improve performance by reducing the number of database queries and minimizing the time spent on retrieving data. \\
## Code: 
```
Invoice findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
	}
```