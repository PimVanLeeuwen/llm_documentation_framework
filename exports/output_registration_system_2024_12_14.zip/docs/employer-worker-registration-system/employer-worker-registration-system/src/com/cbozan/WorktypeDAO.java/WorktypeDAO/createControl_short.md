This method checks if a worktype already exists in the cache before creating a new control.
It returns true if the worktype does not exist, and false otherwise.