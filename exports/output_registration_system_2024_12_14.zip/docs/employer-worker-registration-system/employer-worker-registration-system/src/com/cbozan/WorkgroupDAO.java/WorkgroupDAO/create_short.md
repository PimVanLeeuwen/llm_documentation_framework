This method creates a new workgroup in the database by executing an INSERT query, and updates a cache with existing workgroups if a new one is created successfully.

The create method returns true if a new workgroup is created, false otherwise.