This method returns the total amount associated with an invoice.
It provides a read-only access to the calculated or set amount value.