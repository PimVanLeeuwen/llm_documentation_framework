This method sets the first name of an employer in a registration system.
It returns the builder instance to allow for chaining method calls.