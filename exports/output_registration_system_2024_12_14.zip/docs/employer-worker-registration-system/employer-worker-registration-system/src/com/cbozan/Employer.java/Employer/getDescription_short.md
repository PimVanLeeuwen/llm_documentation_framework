This method returns a string representing a description.
The description is likely stored as a field in the Employer class, which this method accesses and returns.