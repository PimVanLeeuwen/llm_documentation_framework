`list`: The function of `list` is to retrieve a list of all workgroups from the database or cache, if available.

**Code Description**: 
The `list` method in the WorkgroupDAO class retrieves a list of all workgroups from either the database or the cache. If the cache is not empty and the usingCache flag is true, it returns the cached workgroups. Otherwise, it clears the cache, establishes a connection to the database, executes a SQL query to select all workgroups, and populates the list with the retrieved workgroups. The method also caches each workgroup in the cache for future use. If any SQL exceptions occur during this process, it displays an error message using the `showSQLException` method. \\
## Code: 
```
List<Workgroup> list(){
		
		List<Workgroup> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Workgroup> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM workgroup;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			WorkgroupBuilder builder;
			Workgroup workgroup;
			
			while(rs.next()) {
				
				builder = new WorkgroupBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setWorktype_id(rs.getInt("worktype_id"));
				builder.setWorkCount(rs.getInt("workcount"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					workgroup = builder.build();
					list.add(workgroup);
					cache.put(workgroup.getId(), workgroup);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
	}
```