This class provides a helper for interacting with payment-related data access operations.
It holds a singleton instance of PaymentDAO, which is used to perform database operations related to payments.