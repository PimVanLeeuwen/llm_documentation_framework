`updateControl`: The function of `updateControl` is to check if a job with the same title already exists in the cache, but with a different ID.

**Parameters**:
`Job job`: A Job object that needs to be updated.

**Code Description**:
The `updateControl` method iterates through the entries in the cache. If it finds an entry where the job title matches the provided job's title and the IDs are not equal, it sets a custom error message and returns false, indicating that the update is not allowed due to a duplicate job title. If no such entry is found, it returns true, allowing the update to proceed. \\
## Code: 
```
boolean updateControl(Job job) {
		for(Entry<Integer, Job> obj : cache.entrySet()) {
			if(obj.getValue().getTitle().equals(job.getTitle()) && obj.getValue().getId() != job.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getTitle() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```