This method sets the amount for an invoice in a builder pattern, allowing for fluent API usage.
It returns the same instance to enable chaining multiple method calls.