`updateControl`: The function of `updateControl` is to update the control for a given Employer object.

**Parameters**:
`Employer employer`: This method takes an instance of the Employer class as input, representing the employer whose control needs to be updated.

**Code Description**: 
The `updateControl` method checks if there is already an existing record in the cache with the same first name (`fname`) and last name (`lname`) but a different ID. If such a record exists, it sets an error message indicating that the employer's record already exists and returns false to indicate failure. Otherwise, it returns true to indicate success. The method iterates over each entry in the cache using a for-each loop and checks the conditions specified above. \\
## Code: 
```
boolean updateControl(Employer employer) {
		for(Entry<Integer, Employer> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(employer.getFname()) 
					&& obj.getValue().getLname().equals(employer.getLname()) 
					&& obj.getValue().getId() != employer.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```