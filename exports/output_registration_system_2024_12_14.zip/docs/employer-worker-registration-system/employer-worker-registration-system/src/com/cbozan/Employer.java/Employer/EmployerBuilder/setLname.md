`setLname`: The function of `setLname` is to set the last name of an employer.

**Parameters**:
`String lname`: This parameter represents the last name of the employer, which can be any string value.

**Code Description**:
The `setLname` method is a part of the `EmployerBuilder` class and is used to specify the last name of an employer. It takes a `String` parameter `lname`, assigns it to the instance variable `lname` within the same object, and returns the same builder instance (`this`). This allows for method chaining, enabling multiple settings to be made in a single statement. \\
## Code: 
```
EmployerBuilder setLname(String lname) {
			this.lname = lname;
			return this;
		}
```