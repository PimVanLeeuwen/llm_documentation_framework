**toString**: The function of `toString` is to return a string representation of an employer's name, combining their first and last names.

**Code Description**: 
The `toString()` method in the Employer class returns a string that contains the first name and last name of an employer. This method calls two other methods: `getFname()` and `getLname()`, which are used to retrieve the first name and last name of the employer, respectively. The retrieved names are then concatenated with a space in between to form the final string representation of the employer's name.

The `toString()` method is typically used when an object needs to be converted into a human-readable format, such as for logging or display purposes. In this case, it allows the Employer object to provide a concise and meaningful string representation of itself, which can be useful in various contexts within the application. \\
## Code: 
```
String toString() {
		return getFname() + " " + getLname();
	}
```