This method returns the amount associated with a payment.
It provides read-only access to the payment amount, allowing it to be retrieved but not modified.