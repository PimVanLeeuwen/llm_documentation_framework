`update`: The function of `update` is to update an existing employer's information in the database.

**Parameters**:
`Employer employer`: This method takes an instance of the Employer class as a parameter, which contains the updated information for the employer.

**Code Description**: 
This method updates an existing employer's information in the database. It first checks if there are any duplicate records using the `updateControl` method. If no duplicates are found, it proceeds to update the employer's information in the database using a prepared statement. The updated information includes the first name, last name, phone numbers, description, and ID of the employer. After updating the database, it also updates the cache by putting the updated employer instance into the cache with its ID as the key. If an SQL exception occurs during the update process, it displays the error message using the `showSQLException` method. The method returns true if the update is successful (i.e., a row is updated), and false otherwise. \\
## Code: 
```
boolean update(Employer employer) {
		
		if(updateControl(employer) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE employer SET fname=?,"
				+ "lname=?, tel=?, description=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1, employer.getFname());
			pst.setString(2, employer.getLname());
			
			Array phones = conn.createArrayOf("VARCHAR", employer.getTel().toArray());
			pst.setArray(3, phones);
			
			pst.setString(4, employer.getDescription());
			pst.setInt(5, employer.getId());
			
			result = pst.executeUpdate();
			
			// update cache
			if(result != 0) {
				cache.put(employer.getId(), employer);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```