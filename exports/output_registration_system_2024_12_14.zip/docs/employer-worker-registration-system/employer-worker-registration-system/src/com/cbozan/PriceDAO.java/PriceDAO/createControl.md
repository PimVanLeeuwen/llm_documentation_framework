**createControl**: The function of `createControl` is to determine whether a new price record can be created based on the provided price information.

**Parameters**:
`Price price`: This method takes an instance of the `Price` class as input, which contains details such as fulltime, halftime, and overtime values.

**Code Description**: The `createControl` method iterates through a cache of existing price records. It checks if a record with identical fulltime, halftime, and overtime values already exists in the cache. If a matching record is found, it returns false to indicate that the new price record cannot be created due to duplication. Otherwise, it returns true to allow the creation of the new price record. \\
## Code: 
```
boolean createControl(Price price) {
		for(Entry<Integer, Price> obj : cache.entrySet()) {
			if(obj.getValue().getFulltime().compareTo(price.getFulltime()) == 0
					&& obj.getValue().getHalftime().compareTo(price.getHalftime()) == 0
					&& obj.getValue().getOvertime().compareTo(price.getOvertime()) == 0) {
				
				DB.ERROR_MESSAGE = "Bu fiyat bilgisi kaydı zaten mevcut.";
				return false;
			}
		}
		
		return true;
	}
```