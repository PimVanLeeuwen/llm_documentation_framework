This code defines a class that implements the Singleton design pattern, ensuring only one instance of itself exists across its lifetime.

The `EmptyInstanceSingleton` class holds a static reference to an instance of another class (`Invoice`) from the moment it's initialized.