`verifyLogin`: The function of `verifyLogin` is to verify the login credentials of a user.

**Parameters**:
- `String username`: This parameter represents the username entered by the user.
- `String pass`: This parameter represents the password entered by the user.

**Code Description**: 
The `verifyLogin` method takes in two parameters, `username` and `pass`, which are used to query a database for an existing user with matching credentials. It establishes a connection to the database using JDBC, executes a SQL query to select the id from the auth table where the username and password match the provided input, and returns true if a match is found (indicating a successful login), or false otherwise. If any SQLException occurs during this process, it prints the error message but continues execution. \\
## Code: 
```
boolean verifyLogin(String username, String pass) {
		
		Connection conn;
		Statement st;
		ResultSet rs;
	
		String query = "SELECT id FROM auth WHERE username='" + username + "' AND pass='" + pass + "';";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			if(rs.next())
				return true;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
```