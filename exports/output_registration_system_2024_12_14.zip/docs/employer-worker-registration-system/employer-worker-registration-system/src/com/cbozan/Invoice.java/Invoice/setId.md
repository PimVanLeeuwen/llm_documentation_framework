`setId`: The function of `setId` is to set the ID of an invoice object.

**Parameters**:
`int id`: This parameter represents the new ID that will be assigned to the invoice object. It must be a positive integer, as any negative or zero value will result in an EntityException being thrown.

**Code Description**: The `setId` method takes an integer `id` as input and checks if it is less than or equal to 0. If so, it throws an EntityException with the message "Invoice ID negative or zero". Otherwise, it sets the `id` field of the invoice object to the provided value. This ensures that the ID of the invoice is always a valid positive integer. \\
## Code: 
```
void setId(int id) throws EntityException {
		if(id <= 0)
			throw new EntityException("Invoice ID negative or zero");
		this.id = id;
	}
```