`getLastAdded`: The function of `getLastAdded` is to retrieve the most recently added workgroup from the database.

**Code Description**: 
The `getLastAdded` method in the WorkgroupDAO class retrieves the last workgroup that was added to the system. It does this by executing a SQL query that selects all columns from the workgroup table, orders them by their id in descending order (newest first), and limits the result to one row (the most recent addition). The method then uses a WorkgroupBuilder object to construct a Workgroup object from the query results. If any errors occur during this process, they are caught and printed to the console. Finally, the method returns the constructed Workgroup object, or null if no workgroups were found in the database. 

This method calls the `getConnection` method of the DB class to establish a connection to the database, which is then used to execute the SQL query. The result set from this query is iterated over, and for each row, a new Workgroup object is constructed using the WorkgroupBuilder object. If any errors occur during this process, they are caught and printed to the console. 

The `getLastAdded` method provides a way to retrieve the most recently added workgroup in the system, which can be useful for various purposes such as displaying the latest updates or notifications. \\
## Code: 
```
Workgroup getLastAdded() {
		
		Workgroup workgroup = null;
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM workgroup ORDER BY id DESC LIMIT 1";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			WorkgroupBuilder builder; 
			
			while(rs.next()) {
				
				builder = new WorkgroupBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setWorktype_id(rs.getInt("worktype_id"));
				builder.setWorkCount(rs.getInt("workcount"));
				builder.setDescription(rs.getString("description"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					workgroup = builder.build();
				} catch (EntityException e) {
					System.err.println(e.getMessage());
				}
				
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return workgroup;
	}
```