`getLname`: The function of `getLname` is to return the last name of an employer.

**Code Description**: 
The `getLname` method is a simple getter method that returns the value of the `lname` field. It does not take any parameters and its sole purpose is to provide access to the last name attribute of an Employer object. This method can be used in conjunction with other methods or as part of a larger workflow to retrieve and utilize the employer's last name for various purposes, such as displaying it on a screen or storing it in a database. \\
## Code: 
```
String getLname() {
		return lname;
	}
```