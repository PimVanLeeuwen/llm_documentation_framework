This method sets the last name of an employer in a registration system.
It returns the builder instance to allow for chaining method calls.