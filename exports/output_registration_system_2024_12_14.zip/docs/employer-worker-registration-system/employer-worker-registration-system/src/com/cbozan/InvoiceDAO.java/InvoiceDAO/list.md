`list`: The function of `list` is to retrieve a list of invoices based on the specified column name and ID.

**Parameters**:
- `String columnName`: The name of the column in the invoice table to filter by.
- `int id`: The value of the ID to filter by.

**Code Description**: 
The `list` method retrieves a list of invoices from the database based on the provided column name and ID. It uses JDBC to establish a connection to the database, creates a statement to execute a SQL query, and then executes the query to retrieve the relevant invoices. The retrieved invoices are then built using an `InvoiceBuilder` object and added to a list. If any errors occur during this process, they are caught and printed to the console. Finally, the method returns the list of invoices. \\
## Code: 
```
List<Invoice> list(String columnName, int id){
		
		List<Invoice> list = new ArrayList<>();
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM invoice WHERE " + columnName + "=" + id;
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			InvoiceBuilder builder;
			Invoice invoice;
			
			while(rs.next()) {
				
				builder = new InvoiceBuilder();
				builder.setId(rs.getInt("id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setAmount(rs.getBigDecimal("amount"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					invoice = builder.build();
					list.add(invoice);
				} catch (EntityException e) {
					System.err.println(e.getMessage());
					System.out.println("!! Invoice not added list !!");
				}
				
			}
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return list;
	}
```