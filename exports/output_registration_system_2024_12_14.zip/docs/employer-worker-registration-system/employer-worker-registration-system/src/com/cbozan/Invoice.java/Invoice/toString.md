**toString**: The function of `toString` is to return a string representation of an Invoice object, including its id, job, amount, and date.

**Code Description**: 
The `toString()` method in the Invoice class returns a string that contains the details of the invoice. This method is used to provide a human-readable representation of the object, which can be useful for debugging or logging purposes. The returned string includes the values of the id, job, amount, and date fields of the invoice. \\
## Code: 
```
String toString() {
		return "Invoice [id=" + id + ", job=" + job + ", amount=" + amount + ", date=" + date + "]";
	}
```