`getFname`: The function of `getFname` is to return the first name of an employer.

**Code Description**: 
The `getFname` method is a simple getter method that returns the value of the `fname` field. It does not take any parameters and its sole purpose is to provide access to the first name of an employer object. The method is declared as `String getFname()` indicating it will return a string value, which in this case is the first name of the employer. This method can be used by other parts of the program to retrieve and display or use the first name of an employer. \\
## Code: 
```
String getFname() {
		return fname;
	}
```