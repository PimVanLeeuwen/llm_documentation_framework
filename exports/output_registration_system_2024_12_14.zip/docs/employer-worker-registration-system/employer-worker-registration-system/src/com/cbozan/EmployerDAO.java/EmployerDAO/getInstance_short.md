This method returns a singleton instance of the EmployerDAO class.
It provides a global point of access to the EmployerDAO object, ensuring only one instance exists throughout the application.