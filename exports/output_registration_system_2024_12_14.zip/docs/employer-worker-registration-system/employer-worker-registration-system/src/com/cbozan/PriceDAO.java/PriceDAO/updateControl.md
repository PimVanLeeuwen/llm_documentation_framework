**updateControl**: The function of `updateControl` is to check if a new price record already exists in the cache with the same fulltime, halftime, and overtime values as the provided price.

**Parameters**:
`Price price`: This method takes an instance of the `Price` class as input, which contains information about the price, including fulltime, halftime, and overtime values.

**Code Description**: The `updateControl` method iterates through the cache entries and checks if any existing entry has the same fulltime, halftime, and overtime values as the provided price. If such an entry is found with a different ID, it returns false to indicate that the new price record cannot be updated due to duplication. If no duplicate entry is found, it returns true to allow the update of the price record. \\
## Code: 
```
boolean updateControl(Price price) {
		for(Entry<Integer, Price> obj : cache.entrySet()) {
			if(obj.getValue().getFulltime().compareTo(price.getFulltime()) == 0
					&& obj.getValue().getHalftime().compareTo(price.getHalftime()) == 0
					&& obj.getValue().getOvertime().compareTo(price.getOvertime()) == 0
					&& obj.getValue().getId() != price.getId()) {
				
				DB.ERROR_MESSAGE = "Bu fiyat bilgisi kaydı zaten mevcut.";
				return false;
			}
		}
		
		return true;
	}
```