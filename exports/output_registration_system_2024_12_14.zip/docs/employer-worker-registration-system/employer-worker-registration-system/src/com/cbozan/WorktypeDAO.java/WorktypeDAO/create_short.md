This method creates a new worktype in the database if it does not already exist, or updates the cache accordingly.
It returns true if the creation is successful and false otherwise.