This method sets the ID for an Employer object being built using the Builder pattern.
It returns the same Builder instance to allow chaining of further method calls.