`findById`: The function of `findById` is to retrieve a job from the database by its unique identifier.

**Parameters**:
`int id`: The ID of the job to be retrieved.

**Code Description**:
The `findById` method in the JobDAO class is used to find a job in the database based on its ID. If caching is not being used, it first calls the `list()` method to populate the cache with all jobs. It then checks if the job with the specified ID exists in the cache. If it does, it returns the cached job object. If not, it returns null, indicating that the job was not found or there is no cached result available. \\
## Code: 
```
Job findById(int id) {
		
		if(usingCache == false)
			list();
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```