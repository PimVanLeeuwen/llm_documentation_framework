`setPaytype`: The function of `setPaytype` is to set the payment type for a payment object.

**Parameters**:
`Paytype paytype`: This parameter represents the new payment type to be assigned to the payment object. It must not be null, otherwise an EntityException will be thrown.

**Code Description**: 
The `setPaytype` method takes a `Paytype` object as a parameter and assigns it to the `paytype` field of the current payment object. If the provided `Paytype` is null, it throws an `EntityException` with a message indicating that the paytype in the Payment is null. This ensures that the payment type is always valid before updating the payment object's state. \\
## Code: 
```
void setPaytype(Paytype paytype) throws EntityException {
		if(paytype == null)
			throw new EntityException("Paytype in Payment is null");
		this.paytype = paytype;
	}
```