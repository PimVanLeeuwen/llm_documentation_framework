**PaymentBuilder**: The function of `PaymentBuilder` is to create a payment object by setting various attributes such as id, worker, job, paytype, amount, and date.

**Code Description**: 
The `PaymentBuilder` class is used to construct a `Payment` object. It provides a fluent interface for setting the properties of a payment, such as its ID, associated worker, job, pay type, amount, and date. The builder pattern allows for a more readable and maintainable code by breaking down the construction process into smaller, chained method calls.

The class has two constructors: one with no arguments (default constructor) and another that takes several parameters to initialize the payment object directly. However, it's recommended to use the setter methods provided by the `PaymentBuilder` class for a more readable and maintainable code.

The `build()` method is used to create a new `Payment` object once all the required properties have been set. If any of the essential properties (worker, job, or paytype) are not set, it will throw an `EntityException`. \\
## Code: 
```
class PaymentBuilder {
		
		private int id;
		private Worker worker;
		private int worker_id;
		private Job job;
		private int job_id;
		private Paytype paytype;
		private int paytype_id;
		private BigDecimal amount;
		private Timestamp date;
		
		public PaymentBuilder() {}
		public PaymentBuilder(int id, int worker_id, int job_id, int paytype_id, BigDecimal amount, Timestamp date) {
			super();
			this.id = id;
			this.worker_id = worker_id;
			this.job_id = job_id;
			this.paytype_id = paytype_id;
			this.amount = amount;
			this.date = date;
		}
		
		public PaymentBuilder(int id, Worker worker, Job job, Paytype paytype, BigDecimal amount, Timestamp date) {
			this(id, 0, 0, 0, amount, date);
			this.worker = worker;
			this.job = job;
			this.paytype = paytype;
		}
		
		public PaymentBuilder setId(int id) {
			this.id = id;
			return this;
		}
		
		public PaymentBuilder setWorker(Worker worker) {
			this.worker = worker;
			return this;
		}
		
		public PaymentBuilder setWorker_id(int worker_id) {
			this.worker_id = worker_id;
			return this;
		}
		
		public PaymentBuilder setJob(Job job) {
			this.job = job;
			return this;
		}
		
		public PaymentBuilder setJob_id(int job_id) {
			this.job_id = job_id;
			return this;
		}
		
		public PaymentBuilder setPaytype(Paytype paytype) {
			this.paytype = paytype;
			return this;
		}
		
		public PaymentBuilder setPaytype_id(int paytype_id) {
			this.paytype_id = paytype_id;
			return this;
		}
		
		public PaymentBuilder setAmount(BigDecimal amount) {
			this.amount = amount;
			return this;
		}
		
		public PaymentBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Payment build() throws EntityException{
			if(worker == null || job == null || paytype == null)
				return new Payment(this);
			return new Payment(id, worker, job, paytype, amount, date);
		}
	}
```