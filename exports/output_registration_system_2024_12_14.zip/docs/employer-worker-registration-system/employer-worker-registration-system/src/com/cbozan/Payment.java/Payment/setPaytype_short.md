This method sets the pay type for a payment entity, throwing an exception if the input pay type is null.
The pay type is stored in the payment object after validation.