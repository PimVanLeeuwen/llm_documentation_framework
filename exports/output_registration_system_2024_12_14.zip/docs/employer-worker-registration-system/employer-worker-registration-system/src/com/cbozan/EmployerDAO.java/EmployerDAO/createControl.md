`createControl`: The function of `createControl` is to validate the creation of a new employer record.

**Parameters**:
`Employer employer`: This method takes an instance of the Employer class as input, representing the employer to be created or updated.

**Code Description**: 
The `createControl` method checks if an employer with the same first name and last name already exists in the cache. If a matching employer is found, it returns false and sets an error message indicating that the record already exists. If no matching employer is found, it returns true, allowing the creation of a new employer record. The method iterates through each entry in the cache, comparing the first name and last name of the input employer with those stored in the cache. This ensures that duplicate employers are not created, maintaining data integrity. \\
## Code: 
```
boolean createControl(Employer employer) {
		
		for(Entry<Integer, Employer> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(employer.getFname())
					&& obj.getValue().getLname().equals(employer.getLname())) {
				
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		
		return true;
	}
```