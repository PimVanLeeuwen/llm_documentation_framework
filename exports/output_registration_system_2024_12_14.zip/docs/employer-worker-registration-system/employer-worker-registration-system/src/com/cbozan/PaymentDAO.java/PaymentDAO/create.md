`create`: The function of `create` is to create a new payment record in the database.

**Parameters**:
`Payment payment`: A Payment object containing information about the worker, job, pay type, and amount to be paid.

**Code Description**:

The `create` method takes a Payment object as input and performs the following operations:

* It calls the `createControl` method to create or update the corresponding payment control in the system. If this fails, it returns false.
* It establishes a connection to the database using the `DB.getConnection()` method.
* It prepares an SQL statement to insert the new payment record into the database.
* It sets the values for worker_id, job_id, paytype_id, and amount based on the input Payment object.
* It executes the SQL statement to create the new payment record in the database.
* If the creation is successful, it retrieves the newly created payment record from the database using a SELECT query with an ORDER BY clause.
* It creates a new Payment object using the retrieved data and adds it to a cache using the `cache.put()` method.
* Finally, it returns true if the creation was successful, or false otherwise. \\
## Code: 
```
boolean create(Payment payment) {
		
		if(createControl(payment) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO payment (worker_id,job_id,paytype_id,amount) VALUES (?,?,?,?);";
		String query2 = "SELECT * FROM payment ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, payment.getWorker().getId());
			pst.setInt(2, payment.getJob().getId());
			pst.setInt(3, payment.getPaytype().getId());
			pst.setBigDecimal(4, payment.getAmount());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					PaymentBuilder builder = new PaymentBuilder();
					builder.setId(rs.getInt("id"));
					builder.setWorker_id(rs.getInt("worker_id"));
					builder.setJob_id(rs.getInt("job_id"));
					builder.setPaytype_id(rs.getInt("paytype_id"));
					builder.setAmount(rs.getBigDecimal("amount"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Payment py = builder.build();
						cache.put(py.getId(), py);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id"));
					}
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```