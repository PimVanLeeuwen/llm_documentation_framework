This method sets the ID for a payment object being built.
It returns the builder instance to allow chaining of further method calls.