`findById`: The function of `findById` is to retrieve a Price object from the cache or database by its unique identifier.

**Parameters**:
`int id`: The unique identifier of the Price object to be retrieved.

**Code Description**:

The `findById` method in the `PriceDAO` class is used to find a specific `Price` object based on its ID. If caching is disabled, it first calls the `list()` method to retrieve all prices from the database or cache. Then, it checks if the cache contains an entry for the given ID. If it does, it returns the cached `Price` object associated with that ID. If not, it returns null.

This method uses a caching mechanism to improve performance by reducing the number of database queries. If caching is enabled and the required price is already in the cache, it can be retrieved directly without querying the database. However, if the cache does not contain the required price or caching is disabled, it falls back to retrieving all prices from the database using the `list()` method.

The caching mechanism allows for efficient retrieval of individual prices by ID, making this method suitable for scenarios where frequent lookups by ID are necessary. \\
## Code: 
```
Price findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```