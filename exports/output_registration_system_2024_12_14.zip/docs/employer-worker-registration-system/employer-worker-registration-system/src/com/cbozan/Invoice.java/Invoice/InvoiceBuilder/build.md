`build`: The function of `build` is to create an instance of the Invoice class based on the provided data.

**Code Description**: 
The `build` method in the `InvoiceBuilder` class is responsible for constructing an `Invoice` object. It takes no arguments and returns a new `Invoice` instance. If the `job` field is null, it creates a default `Invoice` with the current builder's data. Otherwise, it creates a new `Invoice` with the specified `id`, `job`, `amount`, and `date`. The method throws an `EntityException` if any errors occur during the creation process. This method allows for flexible invoice construction based on different scenarios. \\
## Code: 
```
Invoice build() throws EntityException {
			if(job == null)
				return new Invoice(this);
			return new Invoice(id, job, amount, date);
		}
```