This method returns an instance of Invoice that has been initialized as empty.
The instance is a singleton, meaning only one instance exists and it's reused throughout the application.