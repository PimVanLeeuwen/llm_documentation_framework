`list`: The function of `list` is to retrieve a list of paytypes from the database or cache, depending on the system's configuration.

**Code Description**: 
The `list` method in the PaytypeDAO class retrieves a list of paytypes from either the cache or the database. If the cache is not empty and the system is configured to use it, the method returns the cached paytypes. Otherwise, it clears the cache, establishes a connection to the database, executes a SQL query to retrieve all paytypes, and populates the list with the retrieved data. The method also caches each paytype in the list for future reference. If any errors occur during this process, the method catches and handles them by displaying error messages to the user. \\
## Code: 
```
List<Paytype> list(){
		
		List<Paytype> list = new ArrayList<>();
		
		if(cache.size() != 0 && usingCache) {
			for(Entry<Integer, Paytype> obj : cache.entrySet()) {
				list.add(obj.getValue());
			}
			return list;
		}
		
		cache.clear();
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM paytype;";
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			PaytypeBuilder builder;
			Paytype paytype;
			
			while(rs.next()) {
				
				builder = new PaytypeBuilder();
				builder.setId(rs.getInt("id"));
				builder.setTitle(rs.getString("title"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					paytype = builder.build();
					list.add(paytype);
					cache.put(paytype.getId(), paytype);
				} catch (EntityException e) {
					showEntityException(e, "ID : " + rs.getInt("id") + " Title : " + rs.getString("title"));
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return list;
	}
```