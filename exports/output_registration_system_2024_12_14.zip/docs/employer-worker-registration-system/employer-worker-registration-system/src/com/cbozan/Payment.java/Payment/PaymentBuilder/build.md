`build`: The function of `build` is to create a new instance of the Payment object, either with default values or populated with data from the builder pattern.

**Code Description**: 
The `build` method in the PaymentBuilder class is responsible for creating a new Payment object. It checks if all required fields (worker, job, paytype) are set before proceeding to create the payment object. If any of these fields are missing, it returns a default Payment object with the current builder's state. Otherwise, it creates a new Payment object with the specified id, worker, job, paytype, amount, and date. This method is part of the Builder design pattern, which allows for step-by-step construction of complex objects like the Payment class. \\
## Code: 
```
Payment build() throws EntityException{
			if(worker == null || job == null || paytype == null)
				return new Payment(this);
			return new Payment(id, worker, job, paytype, amount, date);
		}
```