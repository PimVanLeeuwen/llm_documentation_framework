`create`: The function of `create` is to create a new record in the database for a given `Price` object.

**Parameters**:
`Price price`: A `Price` object containing information about fulltime, halftime, and overtime values.

**Code Description**: 
The `create` method takes a `Price` object as input and attempts to insert its details into the "price" table in the database. It first checks if a record with the same data already exists using the `createControl` method. If no duplicate is found, it proceeds to execute an SQL query to insert the new price information. The method then retrieves the newly inserted ID from the database and uses it to update the cache with the latest price details. If any errors occur during this process, the `showSQLException` method is called to display an error message to the user. Finally, the method returns a boolean value indicating whether the creation was successful or not. \\
## Code: 
```
boolean create(Price price) {
		
		if(createControl(price) == false)
			return false;
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "INSERT INTO price (fulltime,halftime,overtime) VALUES (?,?,?);";
		String query2 = "SELECT * FROM price ORDER BY id DESC LIMIT 1;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			
			pst.setBigDecimal(1, price.getFulltime());
			pst.setBigDecimal(2, price.getHalftime());
			pst.setBigDecimal(3, price.getOvertime());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				
				ResultSet rs = conn.createStatement().executeQuery(query2);
				while(rs.next()) {
					
					PriceBuilder builder = new PriceBuilder();
					builder.setId(rs.getInt("id"));
					builder.setFulltime(rs.getBigDecimal("fulltime"));
					builder.setHalftime(rs.getBigDecimal("halftime"));
					builder.setOvertime(rs.getBigDecimal("overtime"));
					builder.setDate(rs.getTimestamp("date"));
					
					try {
						Price prc = builder.build();
						cache.put(prc.getId(), prc);
					} catch (EntityException e) {
						showEntityException(e, "ID : " + rs.getInt("id"));
					}
					
				}
				
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```