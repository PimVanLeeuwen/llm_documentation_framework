`delete`: The function of `delete` is to delete an invoice from the database.

**Parameters**:
`Invoice invoice`: An object representing the invoice to be deleted, identified by its unique ID.

**Code Description**:

The `delete` method takes an `Invoice` object as input and deletes it from the database. It uses a prepared statement with a query that deletes the row where the id matches the one provided in the `invoice` parameter. The method establishes a connection to the database using the `DB.getConnection()` method, prepares the statement, sets the id of the invoice to be deleted, executes the update, and checks if any rows were affected. If rows were affected (i.e., the invoice was successfully deleted), it removes the corresponding entry from the cache. The method returns a boolean value indicating whether the deletion was successful or not.

The `delete` method catches any SQL exceptions that may occur during execution and prints the error message to the console. It also handles cases where no rows were affected, in which case it returns false, indicating that the deletion failed. \\
## Code: 
```
boolean delete(Invoice invoice) {
		
		Connection conn;
		PreparedStatement ps;
		int result = 0;
		String query = "DELETE FROM invoice WHERE id=?;";
		
		try {
			
			conn = DB.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, invoice.getId());
			
			result = ps.executeUpdate();
			
			if(result != 0) {
				cache.remove(invoice.getId());
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return result == 0 ? false : true;
		
	}
```