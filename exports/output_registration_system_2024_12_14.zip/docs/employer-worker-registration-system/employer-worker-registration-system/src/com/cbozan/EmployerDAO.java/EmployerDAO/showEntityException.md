**showEntityException**: The function of `showEntityException` is to display an error message to the user when there's an issue with adding a new entity.

**Parameters**:
- **EntityException e**: This parameter represents the exception that occurred while trying to add the entity. It contains detailed information about the error, such as its message and cause.
- **String msg**: This is a custom message provided by the developer to be displayed along with the exception details. It's used to give context to the user about what went wrong.

**Code Description**:
The `showEntityException` method takes an `EntityException` object and a custom message as parameters, then it constructs a comprehensive error message that includes the custom message, the exception's message, localized message, and its cause. This constructed message is then displayed to the user using a `JOptionPane`. The purpose of this function is to provide clear and detailed feedback to the user when there's an issue with adding a new entity, helping them understand what went wrong and potentially guiding them on how to resolve the problem. \\
## Code: 
```
void showEntityException(EntityException e, String msg) {
		String message = msg + " not added" + 
				"\n" + e.getMessage() + "\n" + e.getLocalizedMessage() + e.getCause();
			JOptionPane.showMessageDialog(null, message);
	}
```