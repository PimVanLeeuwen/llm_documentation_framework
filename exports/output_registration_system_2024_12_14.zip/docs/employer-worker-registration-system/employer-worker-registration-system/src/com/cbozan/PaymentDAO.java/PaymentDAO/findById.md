`findById`: The function of `findById` is to retrieve a payment object from the cache or database based on its unique identifier.

**Parameters**:
`int id`: The unique identifier of the payment object to be retrieved.

**Code Description**:

The `findById` method takes an integer `id` as input and attempts to retrieve a corresponding payment object from the cache. If the cache is not being used (`usingCache == false`), it first calls the `list()` method to populate the cache with all available payments. 

If the cache contains an entry for the specified `id`, the method returns the associated payment object. Otherwise, it returns null.

This approach allows for efficient retrieval of specific payment objects while also ensuring that the cache is populated and up-to-date when necessary. \\
## Code: 
```
Payment findById(int id) {
		
		if(usingCache == false)
			list();
		
		if(cache.containsKey(id))
			return cache.get(id);
		return null;
		
	}
```