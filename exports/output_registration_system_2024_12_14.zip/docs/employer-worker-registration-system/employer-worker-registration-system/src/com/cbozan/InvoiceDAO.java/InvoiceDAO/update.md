`update`: Updates an existing invoice in the database with new job ID and amount details.

**Parameters**:
`Invoice invoice`: The invoice object containing the updated job ID, amount, and other relevant details.

**Code Description**:

The `update` method is used to update an existing invoice in the database. It takes an `Invoice` object as input, which contains the updated job ID, amount, and other relevant details.

Here's a step-by-step breakdown of what the code does:

1. The method first prepares a SQL query to update the invoice table with the new job ID and amount.
2. It then establishes a connection to the database using the `DB.getConnection()` method.
3. Once connected, it creates a prepared statement (`PreparedStatement`) from the query and sets the updated job ID and amount values from the input `Invoice` object.
4. The method then executes the update query using the `executeUpdate()` method of the prepared statement.
5. If the update is successful (i.e., the result is not zero), it updates the cache with the new invoice details by calling the `cache.put(invoice.getId(), invoice)` method.
6. Finally, the method returns a boolean value indicating whether the update was successful or not.

The code also catches any SQL exceptions that may occur during the execution of the query and displays an error message using the `showSQLException()` method if necessary. \\
## Code: 
```
boolean update(Invoice invoice) {
		
		Connection conn;
		PreparedStatement pst;
		int result = 0;
		String query = "UPDATE invoice SET job_id=?,"
				+ "amount=? WHERE id=?;";
		
		try {
			conn = DB.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, invoice.getJob().getId());
			pst.setBigDecimal(2, invoice.getAmount());
			pst.setInt(5, invoice.getId());
			
			result = pst.executeUpdate();
			
			if(result != 0) {
				cache.put(invoice.getId(), invoice);
			}
			
		} catch (SQLException e) {
			showSQLException(e);
		}
		
		return result == 0 ? false : true;
	}
```