**toString**: The function of `toString` is to return a string representation of the Payment object, including its attributes.

**Code Description**: 
The `toString()` method in the Payment class returns a string that includes all the details of the payment. This string contains the id, worker name, job title, pay type, amount paid, and date of payment. The method concatenates these values with their respective keys (e.g., "id=", "worker=", etc.) to create a formatted string representation of the Payment object. \\
## Code: 
```
String toString() {
		return "Payment [id=" + id + ", worker=" + worker + ", job=" + job + ", paytype=" + paytype + ", amount="
				+ amount + ", date=" + date + "]";
	}
```