`getAmount`: The function of `getAmount` is to return the total amount associated with an invoice.

**Code Description**: 
The `getAmount` method is a simple getter that returns the value of the `amount` field. It does not perform any calculations or modifications, but rather provides direct access to the stored amount. This allows other parts of the program to retrieve and use the amount as needed. The method takes no parameters and returns a `BigDecimal` object representing the total amount. \\
## Code: 
```
BigDecimal getAmount() {
		return amount;
	}
```