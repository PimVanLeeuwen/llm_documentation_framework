This method sets the pay type ID for a payment object.
It returns the PaymentBuilder instance to enable method chaining.