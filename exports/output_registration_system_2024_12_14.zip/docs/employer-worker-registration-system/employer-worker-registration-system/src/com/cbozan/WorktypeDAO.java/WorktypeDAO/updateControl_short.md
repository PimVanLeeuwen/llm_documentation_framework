This method checks if a worktype can be updated in the system without conflicting with existing worktypes.
It returns true if no conflicts are found, and false otherwise.