This method sets the date for an Employer object being built using the EmployerBuilder class.
It returns the same builder instance to allow for chaining multiple method calls.