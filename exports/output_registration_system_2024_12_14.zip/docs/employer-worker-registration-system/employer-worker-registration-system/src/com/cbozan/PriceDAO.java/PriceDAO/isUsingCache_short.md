This method checks if cache is being used in the system.
It returns a boolean value indicating whether caching is enabled or not.