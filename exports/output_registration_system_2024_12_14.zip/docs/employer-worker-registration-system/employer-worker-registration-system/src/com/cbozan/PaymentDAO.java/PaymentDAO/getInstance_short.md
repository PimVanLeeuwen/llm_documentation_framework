This method returns a singleton instance of the PaymentDAO class.
It provides a global point of access to the PaymentDAO object, ensuring only one instance exists throughout the application.