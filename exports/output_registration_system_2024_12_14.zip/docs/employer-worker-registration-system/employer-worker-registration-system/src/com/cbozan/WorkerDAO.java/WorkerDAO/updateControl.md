**updateControl**: The function of `updateControl` is to check if a worker with the same first name, last name, and different ID already exists in the cache before updating control.

**Parameters**:
`Worker worker`: This method takes an instance of the `Worker` class as input, which contains information about the worker being updated.

**Code Description**: 
The `updateControl` method iterates through each entry in the cache using a for-each loop. For each entry, it checks if the first name, last name, and ID of the current worker match those of the worker being updated (but with a different ID). If such a match is found, it sets an error message indicating that the worker's record already exists and returns false to indicate that the update control cannot be performed. If no matching entry is found after iterating through all entries in the cache, the method returns true, indicating that the update control can proceed. \\
## Code: 
```
boolean updateControl(Worker worker) {
		for(Entry<Integer, Worker> obj : cache.entrySet()) {
			if(obj.getValue().getFname().equals(worker.getFname()) 
					&& obj.getValue().getLname().equals(worker.getLname())
					&& obj.getValue().getId() != worker.getId()) {
				DB.ERROR_MESSAGE = obj.getValue().getFname() + " " + obj.getValue().getLname() + " kaydı zaten mevcut.";
				return false;
			}
		}
		return true;
	}
```