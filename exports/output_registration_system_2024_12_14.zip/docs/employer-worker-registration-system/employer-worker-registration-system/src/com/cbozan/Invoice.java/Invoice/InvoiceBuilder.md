**InvoiceBuilder**: The function of `InvoiceBuilder` is to create an instance of the Invoice class, allowing for the incremental setting of its properties.

**Code Description**: 
The `InvoiceBuilder` class serves as a builder pattern implementation for creating instances of the `Invoice` class. It provides a fluent interface for setting various properties of the invoice, such as ID, job ID, job object, amount, and date. The builder can be used to construct an `Invoice` instance in a step-by-step manner, making it easier to create invoices with specific details.

The class has two constructors: one that takes no arguments (default constructor) and another that initializes the builder with an ID, job ID, amount, and date. There are also setter methods for each of these properties, which return the `InvoiceBuilder` instance itself, allowing for method chaining.

The `build()` method is used to create a new `Invoice` instance once all required properties have been set. If the job object has not been specified, it will be created with default values (ID = 0). The `build()` method returns an `Invoice` object or throws an `EntityException` if any of the required properties are missing.

The builder pattern is useful when creating complex objects that require multiple steps to initialize. It helps ensure that all necessary properties are set before creating the final object, reducing errors and making the code more readable. \\
## Code: 
```
class InvoiceBuilder{
		
		private int id;
		private int job_id;
		private Job job;
		private BigDecimal amount;
		private Timestamp date;
		
		public InvoiceBuilder() {}
		public InvoiceBuilder(int id, int job_id, BigDecimal amount, Timestamp date) {
			this.id = id;
			this.job_id = job_id;
			this.amount = amount;
			this.date = date;
		}
		
		public InvoiceBuilder(int id, Job job, BigDecimal amount, Timestamp date) {
			this(id, 0, amount, date);
			this.job = job;
		}
		
		public InvoiceBuilder setId(int id) {
			this.id = id;
			return this;
		}
		
		public InvoiceBuilder setJob_id(int job_id) {
			this.job_id = job_id;
			return this;
		}
		
		public InvoiceBuilder setJob(Job job) {
			this.job = job;
			return this;
		}
		
		public InvoiceBuilder setAmount(BigDecimal amount) {
			this.amount = amount;
			return this;
		}
		
		public InvoiceBuilder setDate(Timestamp date) {
			this.date = date;
			return this;
		}
		
		public Invoice build() throws EntityException {
			if(job == null)
				return new Invoice(this);
			return new Invoice(id, job, amount, date);
		}
		
	}
```