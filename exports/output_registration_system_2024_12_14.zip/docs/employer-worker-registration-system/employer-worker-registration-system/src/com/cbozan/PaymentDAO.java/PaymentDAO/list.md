**list**: Retrieves a list of payments based on the provided column names and IDs.

**Parameters**:
- `String[] columnName`: An array of column names to filter payments by.
- `int[] id`: An array of IDs corresponding to the column names in `columnName`.

**Code Description**:

The `list` method retrieves a list of payments from the database based on the provided column names and IDs. It first checks if the lengths of the `columnName` and `id` arrays are equal, returning an empty list if they are not.

It then constructs a SQL query by iterating over the `columnName` array and appending each column name with its corresponding ID to the query string. The query is executed using a database connection established through the `DB.getConnection()` method.

The results of the query are processed in a while loop, where each row is used to create a new `Payment` object using a `PaymentBuilder`. If an error occurs during this process, it is caught and printed to the console. The created payment objects are added to a list, which is returned at the end.

The method catches any SQL exceptions that may occur during query execution and prints the error message to the console. \\
## Code: 
```
List<Payment> list(String[] columnName, int[] id){
		
		List<Payment> list = new ArrayList<>();
		if(columnName.length != id.length)
			return list;
		
		Connection conn;
		Statement st;
		ResultSet rs;
		String query = "SELECT * FROM payment WHERE ";
		
		for(int i = 0; i < columnName.length; i++) {
			query += columnName[i] + "=" + id[i] + " AND ";
		}
		
		query = query.substring(0, query.length() - (" AND ".length()));
		
		try {
			conn = DB.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(query);
			
			PaymentBuilder builder;
			Payment payment;
			
			while(rs.next()) {
				
				builder = new PaymentBuilder();
				builder.setId(rs.getInt("id"));
				builder.setWorker_id(rs.getInt("worker_id"));
				builder.setJob_id(rs.getInt("job_id"));
				builder.setPaytype_id(rs.getInt("paytype_id"));
				builder.setAmount(rs.getBigDecimal("amount"));
				builder.setDate(rs.getTimestamp("date"));
				
				try {
					payment = builder.build();
					list.add(payment);
				} catch (EntityException e) {
					System.err.println(e.getMessage());
					System.out.println("!! Payment not added list !!");
				}
				
			}
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return list;
	}
```