`setAmount`: The function of `setAmount` is to set the amount of an invoice.

**Parameters**:
`BigDecimal amount`: This parameter represents the new amount to be set for the invoice. It must be a valid, non-negative number (greater than zero).

**Code Description**: 
The `setAmount` method takes a `BigDecimal` object as input and sets it as the amount of the current invoice. However, before setting the amount, it checks if the provided value is less than or equal to zero. If this condition is met, it throws an `EntityException` with a message indicating that the invoice amount cannot be negative or zero. This ensures that the amount of an invoice can never be set to a non-positive value. Once validated, the method updates the `amount` field of the current invoice object with the provided `BigDecimal` value. \\
## Code: 
```
void setAmount(BigDecimal amount) throws EntityException {
		if(amount.compareTo(new BigDecimal("0.00")) <= 0)
			throw new EntityException("Invoice amount negative or zero");
		this.amount = amount;
	}
```