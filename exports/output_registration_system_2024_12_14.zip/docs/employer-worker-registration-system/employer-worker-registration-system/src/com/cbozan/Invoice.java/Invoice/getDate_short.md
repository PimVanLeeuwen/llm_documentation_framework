This method returns the date associated with an invoice.
The date is retrieved from a Timestamp object named 'date'.