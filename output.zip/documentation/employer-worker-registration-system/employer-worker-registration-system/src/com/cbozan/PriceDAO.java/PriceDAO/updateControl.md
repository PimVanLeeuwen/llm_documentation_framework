## `updateControl`
### Behaviour: 
The `updateControl` method checks if a given `Price` object can be updated in the system.

### Parameters:
- `Price price`: The `Price` object to be checked for update.

### Code Description:

The `updateControl` method iterates through the `cache` entries and compares the provided `price` object with each cached `Price` object. It checks if the full-time, half-time, and overtime prices of the given `price` are equal to those in the cache entry, and if the IDs are different. If such an identical record is found, it sets a custom error message "Bu fiyat bilgisi kaydı zaten mevcut." (which translates to "This price information record already exists.") and returns `false`, indicating that the update cannot be performed. Otherwise, it returns `true` if the check passes without finding any identical records.

The method utilizes the following methods from the `Price` class: `getHalftime()`, `getFulltime()`, and `getOvertime()` to compare the prices.