## Expected output
`notifyAllObservers`: The function of `notifyAllObservers` is to notify all registered observers that an update has occurred.

**Code Description**: 
The `notifyAllObservers` method iterates through a list of registered observers, invoking the `update()` method on each observer. This allows all interested parties to be notified and react accordingly when changes occur within the system.
 
This approach follows the Observer design pattern, which enables loose coupling between objects that interact with each other. It allows subjects to notify multiple observers without having a direct reference to them, promoting modularity and scalability in software architecture.
 
The method's simplicity and efficiency make it suitable for applications where real-time updates are crucial, such as live data feeds, game updates, or collaborative work environments.