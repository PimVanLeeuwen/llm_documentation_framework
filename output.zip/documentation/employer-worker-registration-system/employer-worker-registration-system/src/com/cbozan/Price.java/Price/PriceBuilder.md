## PriceBuilder: 
The function of `PriceBuilder` is to construct `Price` objects with specified attributes.


## Code Description:
PriceBuilder class is a builder pattern implementation that allows for the step-by-step creation of a Price object. It provides methods to set various properties (id, fulltime, halftime, overtime, and date) of the Price object, and finally, it returns a fully constructed Price object when the build method is called.


The `PriceBuilder` class contains a constructor that can be used to start building a `Price` object from scratch. The other methods (`setId`, `setFulltime`, `setHalftime`, `setOvertime`, and `setDate`) allow for individual properties of the `Price` object to be set.

The `build` method is used to create a fully constructed `Price` object when all required fields have been specified using the setter methods. This approach helps prevent creating partially built objects or objects with missing critical information.


Each setter method (`setId`, `setFulltime`, `setHalftime`, `setOvertime`, and `setDate`) updates the corresponding property of the `PriceBuilder` instance while returning the updated builder itself. This allows for chaining these setter calls to create a fluent interface for building the `Price` object.

The `build` method, when called, returns a fully constructed `Price` object based on the settings made through the various setter methods.


## Usage:

To use this class, you would typically create an instance of the `PriceBuilder`, set the required properties using the corresponding setter methods, and finally call the `build` method to obtain the fully constructed `Price` object.

Example usage could look like this:


```java
Price price = new PriceBuilder()
    .setId(1)
    .setFulltime(new BigDecimal("10.99"))
    .setHalftime(new BigDecimal("5.49"))
    .setOvertime(new BigDecimal("2.49"))
    .setDate(new Timestamp(System.currentTimeMillis()))
    .build();
```