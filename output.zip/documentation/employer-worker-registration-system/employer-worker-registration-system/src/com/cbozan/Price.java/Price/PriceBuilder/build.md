## Expected Output
`build`: The function of `build` is to create a new instance of the `Price` object.

## Code Description:
The `build` method in the `PriceBuilder` class returns a new instance of the `Price` object. This method does not take any parameters and throws an `EntityException` if an error occurs during the creation process. The returned `Price` object is initialized with the values set in the builder, allowing for a fluent API to construct complex objects in a straightforward manner.