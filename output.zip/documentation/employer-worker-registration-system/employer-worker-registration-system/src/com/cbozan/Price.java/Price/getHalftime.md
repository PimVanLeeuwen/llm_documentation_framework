## getHalftime: 
The function of `getHalftime` is to return the halftime value.

**Code Description**: 

The `getHalftime` method in the `Price` class returns the halftime value, which is stored as a BigDecimal. This value can be retrieved and used in other parts of the program where the halftime price is needed. The method does not take any parameters and simply returns the predefined halftime value. It's likely that this method will be used to display or calculate prices based on the halftime value.