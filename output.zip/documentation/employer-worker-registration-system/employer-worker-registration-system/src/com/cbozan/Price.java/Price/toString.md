## Expected Output
**toString**: Returns a string representation of the object, containing the values of its properties.

**Code Description**: 
The `toString` method in the `Price` class returns a formatted string that displays the full-time, half-time, and overtime wages. It calls the `getFulltime`, `getHalftime`, and `getOvertime` methods to retrieve these values before concatenating them into a single string.

This allows for easy logging or display of an employee's pay information in a human-readable format.