Here are the completed templates:

`InvoiceDAOHelper`: The function of `InvoiceDAOHelper` is to provide a singleton instance of the `InvoiceDAO` class.

**Code Description**:
The `InvoiceDAOHelper` class serves as a helper for managing instances of the `InvoiceDAO` class. It uses a private static final field named `instance` to store a single instance of `InvoiceDAO`, which can be accessed through this class. The purpose of this design pattern is to ensure that only one instance of `InvoiceDAO` exists throughout the application, following the singleton pattern. This approach helps in reducing memory consumption and improving performance by avoiding multiple instances of the same DAO class.

In more detail, the code creates a new instance of `InvoiceDAO` and assigns it to the `instance` field when the class is loaded into memory. Subsequent requests for an instance are redirected to this cached instance, preventing the creation of additional instances. This behavior allows developers to easily access a shared instance of the `InvoiceDAO`, simplifying their code and promoting consistency in data access operations.

By using a singleton instance, the application can leverage the benefits of a centralized data access layer while minimizing potential issues related to instance management.