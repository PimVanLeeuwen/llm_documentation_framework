Here is the completed template:

**Behavior:** 
The function `list` returns a list of `Invoice` objects based on a specified column name and ID.

**Parameters:**

- `String columnName`: The name of the column in the `invoice` table to filter by.
- `int id`: The value to filter the `invoice` table by.

**Code Description:** 
The `list` function establishes a database connection, creates a SQL query based on the provided column name and ID, executes the query, and populates a list with `Invoice` objects. If an error occurs during execution, it is printed to the console. Finally, the populated list of invoices is returned.