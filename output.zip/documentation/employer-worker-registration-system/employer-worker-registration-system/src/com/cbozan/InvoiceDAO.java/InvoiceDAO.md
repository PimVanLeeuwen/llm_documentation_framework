**Expected Output:**

`InvoiceDAO`: The function of `InvoiceDAO` is to serve as a data access object for invoices, providing methods to interact with the invoice table in the database.

**Code Description:** The `InvoiceDAO` class is a Java implementation that encapsulates the logic for retrieving, creating, updating, and deleting invoices from a database. It uses caching to improve performance by storing frequently accessed invoices in memory. The class also provides utility methods for managing cache usage and displaying error messages.