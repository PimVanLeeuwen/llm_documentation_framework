## Expected output
`createControl`: The function of `createControl` is to create a new control for a given worker or check if the worker's registration is already in the system.

**Parameters**:
`Worker worker`: The worker object that needs to be registered or checked.

**Code Description**:
The `createControl` method takes a `Worker` object as input and checks if a worker with the same first name (`getFname()`) and last name (`getLname()`) is already present in the cache. If such a worker is found, it sets an error message indicating that the registration is already available for that worker and returns false. Otherwise, it creates a new control and returns true.

In plain text:
The `createControl` method checks if a worker with the same name as the input `worker` is already in the cache. If the worker's registration is already present, it prevents duplicate registrations by returning false and setting an error message. If the worker's registration is not found, it proceeds to create a new control for the given worker and returns true, allowing the registration process to continue.

This method ensures that workers can only register once in the system, preventing duplicate entries with the same name.