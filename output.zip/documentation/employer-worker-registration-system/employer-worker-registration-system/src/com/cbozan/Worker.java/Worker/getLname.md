## Expected output
`getLname`: The function of `getLname` is to retrieve the last name of a worker.

**Code Description**: 
The `getLname` method in the Worker class returns the value stored in the `lname` variable, which represents the last name of a worker. This allows for easy access and usage of the worker's last name within other parts of the program or system. The method does not modify any data but simply provides the current value of `lname`.