Here is the completed template:

## Instruction
You are an AI documentation assistant. Your task is to generate clear, concise documentation for the given code of an object to help developers and beginners understand its function and usage.

## Information
**Project Structure:** `employer-worker-registration-system` \
**File Path:** `employer-worker-registration-system/employer-worker-registration-system/src/com/cbozan/Worker.java/Worker` \
**Type:** `Method` \
**Method Name:** `toString` \
**Code Content:** 
```java
String toString(){return " "+getFname()+" "+getLname();}
```

## Calls
This code calls the following methods within the repository:
### employer-worker-registration-system/employer-worker-registration-system/src/com/cbozan/Worker.java/Worker.getLname()
### employer-worker-registration-system/employer-worker-registration-system/src/com/cbozan/Worker.java/Worker.getFname()

## Task
Please complete the template below, so a simple sentence of behaviour first, followed by a concise analysis in plain text (including details).
AVOID ANY SPECULATION and inaccurate description. Stay concise, only fill out the dots in the expected output.
Your answer should not include more than the functionality of the code and should be no more than 500 words.

## Expected output
`toString`: The function of `toString` is to *return a string representation of the worker's full name*.

**Code Description**: The `toString()` method is used to provide a human-readable string representation of an object. In this case, it returns a concatenation of the first name and last name of the worker, separated by a space. This allows for easy logging, debugging, or display of worker information without having to access individual fields.