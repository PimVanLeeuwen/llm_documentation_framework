## Expected output
`getFname`: The function of `getFname` is to return the first name of a worker.

**Code Description**: 
The `getFname` method is used in the context of an employer-worker registration system. It is designed to retrieve and provide the first name of a registered worker. This information is likely stored as a member variable, accessible by its corresponding getter method (`getFname`). The method itself simply returns this stored value without any modifications or processing. 

It should be used in situations where accessing the first name of a worker is necessary, such as displaying their profile details on a screen or using it for further calculations within the system.