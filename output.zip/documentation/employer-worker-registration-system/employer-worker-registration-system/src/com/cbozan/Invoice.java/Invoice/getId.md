## getId: Retrieves the Unique Identifier of an Invoice

The function `getId` is used to retrieve the unique identifier assigned to an invoice.

### Code Description:

The `getId` method is a simple getter function that returns the value of the `id` variable. It does not take any parameters and is designed to provide read-only access to the invoice's identification number.

In essence, this method allows other parts of the program to obtain the unique identifier associated with an invoice without modifying its state. This can be useful in a variety of contexts, such as data storage, retrieval, or comparison operations within the employer-worker registration system.