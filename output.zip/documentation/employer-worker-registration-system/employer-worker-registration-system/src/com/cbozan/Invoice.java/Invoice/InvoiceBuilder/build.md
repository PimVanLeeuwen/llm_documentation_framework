Here's the completed template:

**Functionality:** 
The function of `build` is to construct an `Invoice` object with a specific ID, job, amount, and date.

**Code Description:**
The `build` method in the `InvoiceBuilder` class is responsible for creating a new instance of the `Invoice` object. This method takes no parameters and returns a newly built `Invoice` object. However, if the `job` field has not been set, it will return an empty `Invoice` object with the current builder's state.

In more detail, the method first checks if the `job` field is null. If it is, the method simply returns a new `Invoice` object with the current builder's state (i.e., this builder). If the `job` field has been set, the method returns a new `Invoice` object initialized with the specified ID, job, amount, and date.

The `build` method throws an `EntityException` if any of these parameters are invalid. The purpose of this method is to encapsulate the construction logic for creating an `Invoice` object from its constituent parts.