**InvoiceBuilder**: The function of `InvoiceBuilder` is to create an instance of Invoice with the given parameters.

**Code Description**:
The `InvoiceBuilder` class is a utility class used to build an instance of `Invoice`. It provides several setter methods (`setId`, `setJob_id`, `setJob`, `setAmount`, and `setDate`) to set individual properties, as well as a `build` method to create the final `Invoice` object. The `build` method checks if the `job` property is null before creating the invoice, and uses a constructor of `Invoice` to create it.


**Method Behavior:**

### employer-worker-registration-system/employer-worker-registration-system/src/com/cbozan/Invoice.java/Invoice/InvoiceBuilder.setId
This setter method sets the `id` field of an Invoice instance.

### employer-worker-registration-system/employer-worker-registration-system/src/com/cbozan/Invoice.java/Invoice/InvoiceBuilder.setJob_id
This setter method sets the `job_id` field of an Invoice instance.

### employer-worker-registration-system/employer-worker-registration-system/src/com/cbozan/Invoice.java/Invoice/InvoiceBuilder.setJob
This setter method sets the `job` field of an Invoice instance.

### employer-worker-registration-system/employer-worker-registration-system/src/com/cbozan/Invoice.java/Invoice/InvoiceBuilder.setAmount
This setter method sets the `amount` field of an Invoice instance.

### employer-worker-registration-system/employer-worker-registration-system/src/com/cbozan/Invoice.java/Invoice/InvoiceBuilder.setDate
This setter method sets the `date` field of an Invoice instance.

### employer-worker-registration-system/employer-worker-registration-system/src/com/cbozan/Invoice.java/Invoice/InvoiceBuilder.build
The build method creates a new Invoice object with the given parameters. If job is null, it returns an Invoice object using the default constructor of the Invoice class; otherwise, it returns an Invoice object using the specified id, job, amount, and date.