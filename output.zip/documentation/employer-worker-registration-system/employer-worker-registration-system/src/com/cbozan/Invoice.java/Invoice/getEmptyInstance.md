## getEmptyInstance: Returns an empty instance of the Invoice class.

The `getEmptyInstance` method returns a pre-existing, empty instance of the Invoice class. This instance is stored in a singleton pattern and reused whenever this method is called. The returned instance does not contain any data, effectively providing a clean slate for further configuration or modification.