## Expected output
`toString`: The function of `toString` is to return a string representation of the Invoice object.


**Code Description**: The `toString` method in the `Invoice` class generates a string that displays the key details of an invoice. It takes no parameters and returns a formatted string containing the invoice's ID, job, amount, and date. This allows for easy display or logging of invoices in a human-readable format. The method utilizes the `id`, `job`, `amount`, and `date` instance variables to construct the string representation.