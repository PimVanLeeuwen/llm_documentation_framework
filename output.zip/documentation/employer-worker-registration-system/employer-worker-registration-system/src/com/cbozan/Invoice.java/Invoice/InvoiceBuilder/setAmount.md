## `setAmount`: 
Sets the amount of an invoice to a specified value.

### Parameters:
`BigDecimal amount`: The total amount of the invoice, represented as a BigDecimal object. 

### Code Description:
This method is used to set the amount field of an Invoice object. It takes a BigDecimal parameter and assigns it to the amount field. The method returns this instance (i.e., itself) so that multiple setter calls can be chained together.