**Invoice**

The function of `Invoice` is to represent a billing document for services rendered, encompassing details such as job assignments, total amount due, and date of issuance.

**Code Description**

The `Invoice` class in the employer-worker-registration-system project is designed to encapsulate essential attributes of an invoice, making it a crucial component for managing financial transactions within the system. This class extends the built-in Java functionality of serialization, allowing invoices to be easily converted into a format that can be written to a file or database.

The `Invoice` class has several key features:
- It implements the `Serializable` interface, enabling easy storage and retrieval of invoice data.
- The class contains private fields for the invoice's ID, job assignment, total amount due, and date of issuance. These fields are initialized through various constructors or setter methods to ensure accurate data representation.
- A static inner class, `InvoiceBuilder`, is used to construct instances of `Invoice` in a more streamlined manner, reducing the need for individual field assignments.
- Additionally, an `EmptyInstanceSingleton` class provides a pre-initialized instance of `Invoice` that can be used when no specific details are available or needed.