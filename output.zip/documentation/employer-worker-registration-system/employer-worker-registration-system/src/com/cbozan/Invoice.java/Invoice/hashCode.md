## Expected Output
`hashCode`: The function of `hashCode` is to generate a unique hash code for an object based on its properties. 

**Code Description**: 
The `hashCode` method in the provided code snippet generates a unique hash code for an `Invoice` object by combining the hash values of its attributes: `amount`, `date`, `id`, and `job`. This allows for efficient storage, retrieval, and comparison of objects in data structures such as sets or maps. The method returns an integer representing the calculated hash code.