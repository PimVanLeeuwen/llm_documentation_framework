## Expected output
`getLname`: The function of `getLname` is to retrieve and return the last name of an employer.

**Code Description**: The `getLname` method in the `Employer` class is a getter method that returns the value of the `lname` instance variable, which represents the last name of the employer. It takes no arguments and returns a string containing the last name. This method allows other classes to access and use the last name information without having direct access to the instance variable itself.