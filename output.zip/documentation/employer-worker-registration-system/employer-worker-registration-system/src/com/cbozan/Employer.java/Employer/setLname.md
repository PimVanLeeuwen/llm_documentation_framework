Here's the completed documentation template:

`setLname`: The function of `setLname` is to set the last name attribute of an Employer object.

**Parameters**:
- `String lname`: This parameter represents the new last name value that needs to be assigned to the Employer object. It should be a string containing the employer's last name.

**Code Description**: 
The `setLname` method updates the last name field in the Employer object by validating if it is empty or exceeds the maximum allowed length as specified in `DBConst.LNAME_LENGTH`. If either condition is met, an `EntityException` with an informative message is thrown to indicate an error. Otherwise, the new last name value is successfully assigned to the `lname` attribute of the Employer object.