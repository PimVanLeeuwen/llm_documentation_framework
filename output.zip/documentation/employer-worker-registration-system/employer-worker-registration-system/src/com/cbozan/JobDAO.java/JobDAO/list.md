## list: Retrieves a list of jobs from the database based on certain conditions.
The `list` method retrieves a list of jobs from the database and returns them in the form of a `List<Job>`.

### Behaviour Analysis:
The `list` method checks if there are existing cached jobs using the `cache.size()` and `usingCache` variables. If cache is available, it iterates through the cache entries and adds each job to the list.
If no cache is found or `usingCache` is false, it clears the cache, establishes a database connection, and executes a SQL query to select all jobs from the "job" table. The results are then used to create Job objects using the `JobBuilder`. These objects are added to the list along with caching their ID and value.
In case of an EntityException or SQLException, it shows the respective exception using helper methods.
The method returns the list of jobs.

### Code Details:
The code utilizes a cache system to store previously retrieved data. If the cache exists and is enabled, it uses the cached data instead of querying the database again. It also handles potential exceptions that may occur during the database query process. The `JobBuilder` class is used to construct Job objects from the query results.
This approach allows for efficient data retrieval, minimizes database queries when possible, and provides a robust way to handle potential errors.