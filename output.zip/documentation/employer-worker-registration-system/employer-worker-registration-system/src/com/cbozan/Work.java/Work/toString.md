## Expected Output
`toString`: The function of `toString` is to return a string representation of the Work object, including its key attributes. 

**Code Description**: 
The `toString` method in the `Work` class generates a string that includes all the essential details of an instance of work being registered. This string contains information such as the identifier (id), job title, worker associated with it, type of work (worktype), description, and date on which the work was done or scheduled.

The purpose of this method is to provide a human-readable summary of what an object of `Work` class represents in a simple text format. This can be particularly useful for debugging purposes or when displaying work information in a user-friendly interface without having to manually construct each attribute's string representation.

In essence, the `toString` method serves as an informative way to quickly understand the details associated with any specific instance of work registered within the system, making it easier to identify and manage work records.