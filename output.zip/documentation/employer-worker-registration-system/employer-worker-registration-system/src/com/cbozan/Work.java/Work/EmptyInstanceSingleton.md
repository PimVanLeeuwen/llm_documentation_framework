Here's the completed template:

**Expected Output**

`EmptyInstanceSingleton`: The function of `EmptyInstanceSingleton` is to ensure a single instance of an object is created and reused, despite multiple requests.

**Code Description**

The `EmptyInstanceSingleton` class implements the singleton design pattern. It uses a static variable to store a reference to the single instance of the `Work` class.

Here's how it works:

* The `private static final Work instance = new Work();` line creates a new instance of the `Work` class and assigns it to the `instance` variable.
* The `final` keyword ensures that the `instance` variable is initialized only once, when the class is loaded.
* The `static` keyword means that the `instance` variable is shared across all instances of the `EmptyInstanceSingleton` class.

When a new instance of `EmptyInstanceSingleton` is requested, it will return the same instance created in the first line. This prevents multiple instances from being created and reduces memory usage.